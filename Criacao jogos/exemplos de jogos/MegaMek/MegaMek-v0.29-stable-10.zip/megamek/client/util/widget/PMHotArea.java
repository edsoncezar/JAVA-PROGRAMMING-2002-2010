/**
 * MegaMek - Copyright (C) 2000-2002 Ben Mazur (bmazur@sev.org)
 * 
 *  This program is free software; you can redistribute it and/or modify it 
 *  under the terms of the GNU General Public License as published by the Free 
 *  Software Foundation; either version 2 of the License, or (at your option) 
 *  any later version.
 * 
 *  This program is distributed in the hope that it will be useful, but 
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 *  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
 *  for more details.
 */


package megamek.client.util.widget;

import java.awt.*;
import java.awt.event.*;

/**
 * Generic Hot area of PicMap component
 */

public interface PMHotArea extends PMElement{
	public static final String MOUSE_CLICK_LEFT = "mouse_click_left";
	public static final String MOUSE_CLICK_RIGHT = "mouse_click_right";
	public static final String MOUSE_DOUBLE_CLICK = "mouse_double_click";
	public static final String MOUSE_OVER = "mouse_over";
	public static final String MOUSE_EXIT = "mouse_exit";
	public static final String MOUSE_UP = "mouse_up";
	public static final String MOUSE_DOWN = "mouse_down";
	
	Cursor getCursor();
	void setCursor(Cursor c);
	Shape getAreaShape();
	void onMouseClick(MouseEvent e);
    void onMouseOver(MouseEvent e);
    void onMouseExit(MouseEvent e);
    void onMouseDown(MouseEvent e);
    void onMouseUp(MouseEvent e);
}