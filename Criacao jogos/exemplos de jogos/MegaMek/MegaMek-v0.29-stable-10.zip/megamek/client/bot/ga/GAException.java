package megamek.client.bot.ga;

public class GAException extends Exception
{
  GAException(String msg)
  {
    super(msg);
  }
}
