The file standardmaps.zip contains:

1.) all maps of Megamek 0.25.1 converted into the new map standard for Megamek 0.25.6 or        later:

	battletech.board
	citytech.board
	deepcanyon1.board + deepcanyon2.board
	deserthills.board
	desertmountain1.board + desertmountain2.board
	desertsinkhole1.board + desertsinkhole2.board
	heavyforest1.board + heavyforest2.board
	lakearea.board
	largelakes1.board + largelakes2.board
	openterrain1.board + openterrain2.board
	rivervalley.board
	rollinghills1.board + rollinghills2.board  
	scatteredwoods.board
	woodland.board

2.) 6 more original fasa maps to be used with Megamek 0.25.6 or later:

	battleforce2.board						(from map set #6)
	boxcanyon.board							(from map set #6)
	city_hills_residential1.board + city_hills_residential1.board	(from map set #3)
	cityruins.board							(from map set #2)
	wideriver.board							(from map set #6)



***Important***

As there are no real bridges in Megamek 0.25.6's Map Editor, I reduced all water hexes with roads over them to level 0



*** Installation Instructions ***

Simply unzip the contents of this file to the ../data/boards/ directory
where you have installed MegaMek.


And now, enjoy the game

			shockmilk