class Exercicio1 {
	public static void main(String args[]){
		int F [] = new int [10];
		int i = 2;
		System.out.println("F(x)=F[x-1]+F[x-2]");
		F[0] = 1;
		F[1] = 1;
		System.out.println("F1 = \t"+F[0]);
		System.out.println("F2 = \t"+F[1]);
		while ( i<10 ) {
			F[i]=F[i-1]+F[i-2];
			System.out.println("F[" + (i+1)+"]=F["+(i)+"]+F["+(i-1)+"]= 
"+(F[i-1]+F[i-2]));
			i++;
		}
	}
}
