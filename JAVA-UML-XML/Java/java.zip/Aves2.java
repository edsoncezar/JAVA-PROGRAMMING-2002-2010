/* LPT II - JAVA - FIAP

Nome do Arquivo: Aves2.java
Arquivo de Saida:

Fernando Motta Delago
Abril de 2000*/

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

class aves_mont {
 String name;
 String lugar;

 void identify () {
  System.out.println ("Descrevendo a ave");
  System.out.println ("O nome da ave e "+name);
  System.out.println ("Encontrada em "+lugar);
 }// fecha identify
}// fecha aves_mont

class extincao extends aves_mont {
 String quant;

 void particularidades () {
  System.out.println ("Esta ave esta em extincao");
  System.out.println ("Existem somente "+quant+" no mundo");
 } // fecha particularidades
} // fecha extincao

public class pesquisa2 extends java.applet.Applet {
 Font novafonte("TimesRoman",Font.BOLD,30);

public void paint ( Graphics tela ){
 tela.setFont(novafonte);
 tela.setColor(Color.red);
 tela.drawString (pesquisa);
 } // fecha paint
} // fecha pesquisa2

class pesquisa {
 public static void main (String args[]){
  aves_mont A=new aves_mont ();
  A.name="Aguia Careca";
  A.lugar="Monte Roshmor";
  extincao B=new extincao();
  B.quant="10";
  A.identify();
  System.out.println ();
  B.particularidades();
 } // fecha void main
} // fecha pesquisa
