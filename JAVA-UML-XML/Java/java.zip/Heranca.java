// LTP II - Java - FIAP
//
// nome do arquivo: heranca.java
// Arquivos de Sa�da: 	Paciente.class
//						Particular.class
//						PAS.class
//						Hospital.class
//
//
//	Fernando Motta Delago
//	Marco de 2000

class Paciente {
	String nome;
	String doenca;

	void identificacao(){
		System.out.println("Estou identificando o paciente");
		System.out.println("O nome do paciente e"+nome);
		System.out.println("O paciente esta com"+doenca);
	} // fecha identificacao
} // fecha Paciente

class Particular extends Paciente {
	String limite;

	void mostrarAtributos(){
		System.out.println("Este paciente e Particular");
		System.out.println("Seu limite de gastos e"+limite);
	} // fecha mostrar
} // fechar mostrar

class PAS extends Paciente {
	String senha;

	void identificacao(){
		System.out.println("Identificacao do PAS");
		System.out.println("Paciente do PAS"+nome);
		System.out.println("Doenca dp paciente"+doenca);
	} // fecha identificacao
	
	void mostrarAtributos(){
		System.out.println("Este paciente tem senha"+senha);
	} // fecha mostrarAtributos
} // fecha PAS

class Hospital {
	public static void main(String args[]){
		Particular A=new Particular();
		A.nome="Maria";
		A.doenca="Gripe";
                A.limite="1000,00";
	PAS B=new PAS();
		B.nome="Joao";
		B.doenca="Tuberculose";
		B.senha="10";
		A.identificacao();
		A.mostrarAtributos();
		System.out.println();
		B.identificacao();
		B.mostrarAtributos();
	} 
}
