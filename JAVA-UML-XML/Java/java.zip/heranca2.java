/* LTP II - Java - FIAP

Nome do arquivo: heranca2.java
Arquivos de Sa�da: 	aguia.class
					garca.class
					descricao.class
					Pesquisa.class
	Iury Coe
	Paulo Rog�rio
	Sandro Filipini
	Renata Canal
	Fernando Motta Delago
	Abril de 2000 */

class aguia {
	String nome;
	String tipo;

	void identificacao(){
		System.out.println("Estou identificando a ave");
		System.out.println("O nome da ave e "+nome);
		System.out.println("O tipo desta ave e de "+tipo);
	} 
} 

class descricao extends aguia {
	String desc;	
	
	void desc_ave(){
		System.out.println("Esta ave e do sexo "+desc);
	} 
} 

class garca extends aguia {
	String tamanho;

	void mostrarAtributos(){
		System.out.println("Esta ave e do Pantanal");
		System.out.println("Seu tamanho e "+tamanho);
	} 
} 

class Pesquisa {
	public static void main(String args[]){
		descricao A=new descricao();
		A.nome="Aguia Real";
		A.tipo="Rapina";
		A.desc="masculino";                
		garca B=new garca();
		B.nome="Garca Pantaneira";
		B.tipo="exotica";
		B.tamanho="1,20";
		A.identificacao();
		A.desc_ave();
		System.out.println();
		B.identificacao();
		B.mostrarAtributos();
	} 
}
