class results {
       
public static void main (String Args[]){
       double  a;
       double  b;
       a = 20;
       b = 4.5;
	   System.out.println ("Hey! Bobao, tai o resultado...");
	   System.out.println ("20+4,5="+ (a+b));
	   System.out.println ("20-4,5="+ (a-b));
	   System.out.println ("20x4,5="+ (a*b));
	   System.out.println ("20/4,5="+ (a/b));
	   }// FECHA mostra_result
}// FECHA class results


