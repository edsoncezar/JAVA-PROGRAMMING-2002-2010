
class Exercicio3{
   public static void main(String args[]){
   int L[][] = new int[3][4];
   int x = new Integer;
   int z = new Integer;
   int m = new Integer;
   int r = new Integer;
   for(x=0; x<3; x++){
	  for ( z = 0; z < 4 ; z++ ){
		if (z==0){
			r=1;}
		else{
			if (z==1){
				r = x;}
			else
				r = x
				for(m=0; m<z; m++){
					r = r * x;}
			}
		}
		L[x][y]=r
		System.out.println("F["+x+","+z+"]=\t"+L[x][z]);
    }//close for
   }//close for
  }//close void
}//close class


