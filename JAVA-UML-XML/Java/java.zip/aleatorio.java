import java.util.Random;

class Aleatorio { 
        public static void main ( String args [] ) {
        Random num1,num2;

        num1=new Random();
         
        System.out.println("Numero Aleatorio 1 : "+num1.nextDouble());

        num2=new Random (8675309);

        System.out.println("Numero Aleatorio 2 : "+num2.nextDouble());
} // fecha main ()
} // fecha classe