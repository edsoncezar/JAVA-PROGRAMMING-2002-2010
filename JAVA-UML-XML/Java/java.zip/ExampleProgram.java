// A very Simple Example 

/**  Documenta��o do objeto Java   pra se verificar como fica no Java Doc */ 
public class ExampleProgram 
{ public static void main (String [] args )
{ System.out.println ( "I'm a Simple Program " ) ; } } 



// um arquivo .java pode ter mais de uma classe mas no m�nimo uma 
// toda classe criada em Java pode ser instanciada 
// pode ser instanciada dentro dela mesma 
// Opcao opc = new opcao 
// 
//
// m�todo Main � palavra reservada . Main � especifico para chamadas do sistema operacional 
// void n�o tem retorno - main n�o pode retornar kein valor 
//  
// toda classe tem que iniciar em ma�scula se for m�nuscula da pau 
//
// String � uma classe e n�o apenas um tipo de dado 
// coloquei uma classe String [] significa que � o que vier depois s�o arrays 
// coloquei o [] depois do nome arg significa que somente o arg ser� Array o x n�o  
// ex :  String args [] x 
// 
// N�o precisei instanciar a classe System porque ela � static e instancia no momento que 
// instancio uma classe .System trata console e n�o parte gr�fica 
//
// classpath - vari�vel que diz onde est� o JAVA  o JVM precisa de vari�veis claro 

/*
   main method - serve , mais uma vez , para poder ser chamado pelo sistema operacional  
   
   o segredo est� na palavra static , tudo que est� como  Static na defini��o de uma classe 
   � na hora colocado em mem�ria quando Instanciado .  
   
   Se uma classe n�o � executada s� vai par a mem�ria quando for executado .  
   
   Todo Method ou CLass Static s� pode utilizar met�dos e classes Static . 
   
   Para comparar duas Sring voc� tem que usar um Metodo equals ( String s ) 
   quando estamos falando de uma classe . Tipos primitivos podem ser 
   comparados diretamente
   
   Somente objetos de classes de Tipo primitivo , Integer , Float , Double ... podem ser 
   definidos sem necessidade do New .  
   
   N�o posso transferir Tipos Primitivos pelo Java entre duas m�quinas. Ele s� transmite 
   atrav�s de Stream que s� transfere objects e nunca Primitivos 
   
   Existe uma classe chamada Vector que possui um m�todo addElement . Por�m o addElement 
   s� aceita  receber Object . 
   
   Quando se declara uma vari�vel Static ela passa a ser vari�vel de Classe e n�o somente
   da Inst�ncia. Quando somente declarada o objeto � somente instanciado e n�o serve para a
   Classe .  
   
   CONSTRUCTORS   
   
   No Java evento  todos s�o m�todos executados pelo sistema operacional .  
   
   N�o pode retornar valor dever� ser Void .  
   
   Tem que ter o nome nome da classe . O constructor � o m�todo com o mesmo nome da classe.  
   
   
   Falar sobre exerc�cio LessonTwoD2 
   
   
   INTERFACE   
   
   Serve para padronizar comunica��o entre classes diferentes.  
   Na programa��o  C  � o protocolo. 
   
   Vou receber uma classe que n�o conhe�o mas posso utilizar seus m�todos.  
   
   
   Exemplo :  
   
   Interface Icor 
   {  Long getCor () 
   } 
   
   class Ponto extends Object 
   { 
     inte x,y ; 
	  void  Move (int x, int y ) ; 
	  } 
	 
   class PontoCor  extends Ponto 
                   implements Icor 
				   { 
				    long   cor ;  
					long   getCor () 
					} 
					
					
	class Desenho  
	{ 
	 Ponto     p   = new Ponto () ; 
	 PontoCor  pc  = new PontoCor() ; 
	 
	 Vector v=new Vector() ; 
	 
	 v.addelement((object) p ) ;
	 v.addelement( (object) pc ) ;  
	 
	 
	 if  ( v.get(0) instance of Icor )  
	 
	      ( (Icor) v.get(0)).getCor () ; 
     	 
    	 
	 
	 
	 
/*  operandos  	 
	 == igual 
	 !  not 
	 && and 
	 || or 
*/  

	 [ classe ] instance of  [classe]  
	 [ classe ] instance of  [ interface ] 
	 
	 p instance of  Ponto ;  true 
	 pc instance of PontoCor ; true 
	 
	 
   
   
   VECTOR   
   
   Vector  v = new Vector() ; 
   v.addelement (objeto) ; 
   v.size() ;  // n�mero de elementos do vetor  
   obj = v.get( 3) ;  // vai retornar o objeto na terceira posi��o para a �rea de trabalho "obj"
   que declarei antes .  
   
    
   for ( int i=0 ; i < 10 ; i+=5 )  //encrementa de 5 em 5 
   { 
           { 
		      int  i=2 ;   
			  
			  }  
	} 
	
	CAST 
	
	int i = 2 ; 
	
	float  f = 25 ;  
	
	f= (float) i ;   // colocar entre parenteses o tipo de dado destino e a vari�vel a ser
	                    convertida .Para tipos permitidos pode ser feito com liberdade se 
						forem compat�veis. 
						
			Tipos Primitivos Hierarquia : Byte,Short,Char,Int,Long,float,double. 
			
			N�o se pode fazer Casting de Byte para Char. 
			
			f = i ; // estou descendo na estrutura o casting fica implicito 
			
			i = (int)f ; // estou subindo o casting tem que ser explicito 
			
			
	Hierarquia de Classes : 
	
	Tem que ser explicito e subindo na Hierarquia.   
	
						Opcao 
					
					Sub 	   Item  
					
	
Programa exemplo seria :  

	Opcao  opc ;  // n�o tem posi��o de mem�ria somente o JVM sabe que ele existe 
	
	Sub sub= new Sub() ;   // neste momento vai ganhar uma posicao de mem�ria 
	
	Item item = new Item() ;  // neste momento vai ganhar uma posicao de mem�ria 
	
	opc = (Opcao) Sub ;  // estou fazendo um casting da Opcao para que receba o Sub . 
	                        Tenho que usar o Casting.  
							
	Qualquer classe java pode ser feito casting para outra porque todas sao 
	heradadas da Objects.
	
	ex: 
	
	Ponto p 
	
	PntoCor  pc 
	
	v.addelement ( (
	
	
	
	
	Exerc�cio ; 
	
	Implementar com Vector ou n�o 
	
	Trem virtual vai entrar passageiro - qqer um 
	Podemos colocar Pessoas , Indigente,Passageiro,func,Billeteiro , ferrovi�rio 
	Trem emite listagem passageiro e caracter�aticas de cada 1 
	Dependendo do tipo de passageiro vai imprimir dados referentes ao tipo. 
	
	Prog principal vai imprimir o primeiro objeto dentro da classe .  
	
	Outro jeito em caso de exibi��o apenas . 
	
	  Ponto p = new  Ponto() ; 
	  System.out.println( p.getClass()) ; 
	  
	
	Objeto Trem : vai receber todos mas tem que ser pessoa , tem integracao com 
	Interface Ipessoa . Somente quem implementa Ipessoa pode entrar no trem .  
	
	Inteface = IPessoa e IPapelPessoa  
	
	Quem implementa Ipessoa - Passageiro 
	
	Vai implementar Ipessoa 
	Vai imprimir Dados de Pessoa 
	
	Funcionario Ferrovia 
	vai implementar o IPapelPessoa 
	
	Turista 
	Vai implementar o IPapelPessoa 
	
	Func, Turista , Bilheteiro vao para IPapelPessoa e sendo Ipessoa poder�o ir para o Trem
	
	O que possibilita a entrada no trem � o protocolo IPessoa  
	
	Criar a estrutura :  1 arq para cada classe , declara com as rela��es, declara interface,
	instancia do diret�rio. 
	
	Pega o arquivo main disponibilizado e executa . 
	
	Desenvolver na ordem : 
	Indigente � o mais f�cil (implementar interface) 
	Turista   
	Func Ferrovia - faz o mesmo Turista e Indigente 
	Agente Ferrovi�rio ou Bilheteiro - al�m das coisas deles fazer o que recebe por interface
	printdados , printdados extra s�o as �nicas fun��es de neg�cio - impress�o. 
	
	Passageiro - parecido com Indigente ( implementa interface) , usar cast ? )  
	
	CAP�TULO 3 -  LEXICAL STRUCTURE  
	
LITERALS 
	
	para todos os tipos de literais vc tem um m�todo especifico Value para tratar valor .
	caso contr�rio ele ir� sempre usar o endere�o de mem�ria e n�o o valor. 
	
	sempre procure na classe para verificar se tem.  
	
Boolean 
	
	boolean b ;   // tipo primitivo boolean 
	Boolean  b1 = new Boolean (true) ; 
	
	Character Literals 
	
	tipo primitivo char tem como classe String.S� pode ser igual a 1 caracter.
	Tem que ter aspas simples. 
	
	\n  ==  pular linha 
	\t  ==  tabula��o 
	
	
	default vari�vel char � vazio . 
			vari�vel int  � zero . 
	
	Integer sem executar o Constructor � nulo . 
	
	
	
STRING  
	
	Excess�o para String. 
	
	String � a �nica que redefine o toString .ToString sempre retorna o endere�o de mem�ria 
	e n�o o conte�do , aqui ser� trazido o conte�do. 
	
	
	String d = "nome "+ 10 ; 
	String n = "teste "; 
	String  c= n+ d ;  // o resultdo n�o ser� posi��es de mem�mria e sim valores 
	
	
	Cada classe tem seus m�todos e deveremos tentar encontrar se na classe tem ou n�o os 
	m�todos que procuramos.  
	
NULL LITERAL 

	
    S� serve para Classes . 
	
	Instanciou a Classe e setou null ele desaparece com o endere�o de mem�ria mas fica 
	instanciado. 
	
	Float  f ;  // alocou uma posi��o de mem�ria mas n�o sabe qual ainda 
	
	f= new float() ;  //recebeu posi�ao mem�ria
	
	f=null ; //perdeu pos mem�ria
	
	f= new float(5);  //voltou a ter pos mem�ria 
	
PACKAGE 

E pacote. Organizar o que voc� escreveu. O root indicado cont�m o package e as classes . 
Se cada classe tem um arquivo  antes da declare�ao dela deveremos especificar o seu caminho. 
c:\curso 

Comunica��o entre pacotes dever� ser feita pelo comando Import onde ser� passado o endere�o 
do Package. 


	
	
	