/*LTP II - Java - FIAP
 Nome do arquivo: contas.java
 Arquivos de Sa�da: results.class
	Iury Coe
	Paulo Rog�rio
	Sandro Filipini
	Renata Canal
	Fernando Motta Delago
	Abril de 2000 */


class results {
       
public static void main (String Args[]){
       double  a;
       double  b;
       a = 20;
       b = 4.5;
	   System.out.println ("Voce queria o resultado? Pois bem,tai...");
	   System.out.println ("20+4,5="+ (a+b));
	   System.out.println ("20-4,5="+ (a-b));
	   System.out.println ("20x4,5="+ (a*b));
	   System.out.println ("20/4,5="+ (a/b));
	   }// FECHA mostra_result
}// FECHA class results


