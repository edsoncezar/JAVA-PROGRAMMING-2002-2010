import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;

public class Alomundoii extends java.applet.Applet {
	Font novaFonte=new Font ("TimesRoman",Font.BOLD,30);

public void paint(Graphics tela) {
	tela.setFont(novaFonte);
	tela.setColor(Color.red);
	tela.drawString("Alo Mundo 2 - A Miss�o",5,40);
} // fecha paint()

} // fecha a classe
 