class FraseFeita { 
    public static void main ( String args []) {
       String frase = "\'Quem sai na chuva � pra se queimar...\'V.Matheus";

    System.out.println("A frase � : "+'\t'+frase);
    System.out.println("Comprimento da frase : \t"+frase.length());
    System.out.println("Na posicao 10 tem a letra : \t"+frase.charAt(10));
    System.out.println("Determinamos uma substring entre os caracteres 13 e 18 :\t"+
             frase.substring(13,18));
    System.out.println("O indice de caracter Q �:\t"+ frase.indexOf('Q'));
    System.out.println("A frase em maiusculas fica :\t"+ frase.toUpperCase());
} // fecha o main ()
} // fecha a classe