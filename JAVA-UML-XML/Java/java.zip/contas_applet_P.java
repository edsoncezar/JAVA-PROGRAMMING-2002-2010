import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;

public class contas_applet extends java.applet.Applet {
	Font novaFonte=new Font ("TimesRoman",Font.BOLD,30);

       double  a;
       double  b;
       a=20;
       b=4.5;
	
public void paint(Graphics tela) {
	tela.setFont(novaFonte);
	tela.setColor(Color.blue);
	tela.drawDouble((a+b),5,40);
} // fecha paint()

} // fecha a classe	   
