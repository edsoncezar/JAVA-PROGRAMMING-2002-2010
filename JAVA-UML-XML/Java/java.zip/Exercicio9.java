class Exercicio9{
	public static void main(String args[]){
		int Entrada = Integer.parseInt(args[0]);;
		int Saida = 0;
		int X = 0;
		if (Entrada==0){
			Saida=1;}
		else{
			if (Entrada==1){
				Saida=1;}
			else{
				Saida=Entrada;
				for(X=(Entrada-1);X>0;X--){
					Saida=Saida*X;}


			}
		}
		System.out.println("Fatorial de "+Entrada+" = "+Saida);
	}
}
