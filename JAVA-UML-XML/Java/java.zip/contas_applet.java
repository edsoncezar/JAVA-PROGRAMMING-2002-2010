/*LTP II - Java - FIAP
 Nome do arquivo: contas_applet.java
 Arquivos de Sa�da: contas_applet.class
	Iury Coe
	Paulo Rog�rio
	Sandro Filipini
	Renata Canal
	Fernando Motta Delago
	Abril de 2000 */

import java.awt.*;

public class contas_applet extends java.applet.Applet {
	
       Font novaFonte = new Font("TimesRoman",Font.ITALIC,14);
       int  a=20;
       float  b=4.5f;
	
public void paint(Graphics tela) {
	tela.setFont(novaFonte);
	tela.setColor(Color.blue);
	tela.drawString("Resultado da Somatoria "+(a+b),5,40);
	tela.setColor(Color.black);
	tela.drawString("Resultado da Subtracao "+(a-b),20,65);
	tela.setColor(Color.gray);
	tela.drawString("Resultado da Divisao "+(a/b),35,90);
	tela.setColor(Color.red);
	tela.drawString("Resultado da Multipicacao "+(a*b),50,115);
}

}
