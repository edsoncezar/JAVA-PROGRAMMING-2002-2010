class Exercicio5{
	public static void main(String arg[]){
		int F [] = new int[10];
		int x = 0;
		float z = 0F;
		int w = 0;
		while(x<10){
			F[x]= (x+2)*(x+2);
			w = F[x]/2;
			z = (float)F[x]/2;
				if(w == z){
					System.out.println("F["+x+"]=("+x+"+2)^2="+F[x]);
				}
			x++;
		}
	}
}

