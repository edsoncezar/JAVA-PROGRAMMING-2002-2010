class Exercicio7{
	public static void main(String args[]){
		int M[] = new int[3];
		int x=0;
		for(x=0; x<M.length;x++){
			M[x]=Integer.parseInt(args[x]);
		}
		if(M[0] > M[1]){
			if(M[0] > M[2]){
				System.out.println(M[0]);
				if(M[1] > M[2]){
					System.out.println(M[1]);
					System.out.println(M[2]);
				}
				else{
					System.out.println(M[2]);
					System.out.println(M[1]);
				}
			}
			else{
				System.out.println(M[2]);
				System.out.println(M[0]);
				System.out.println(M[1]);
			}
		}
		else{
			if(M[1] > M[2]){
				System.out.println(M[1]);
				if(M[0] > M[2]){
					System.out.println(M[0]);
					System.out.println(M[2]);
				}
				else{
					System.out.println(M[2]);
					System.out.println(M[0]);
				}
			}
			else{
				System.out.println(M[2]);
				System.out.println(M[1]);
				System.out.println(M[0]);
			}
		}
	}
}

