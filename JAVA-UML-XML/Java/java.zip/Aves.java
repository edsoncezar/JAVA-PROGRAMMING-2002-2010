
/*FIAP -  LTP  II  - JAVA
**/
class  Aves {
 String cor;
 String sexo;
 boolean fome;

 void alimentarAves() {
  if (fome==true) {
   System.out.println("Vou comer...");
   fome=false;;
   }else
     System.out.println("Nao, obrigado! Ja comi.");
     }// fecha alimentarAves

 void mostraAtributos(){
 System.out.println("Esta e uma ave"+sexo+","+cor);
 if (fome==true)
  System.out.println("A ave esta faminta!");
 else
   System.out.println("A ave esta  satisfeita.");
 }// fecha mostraAtributos

public static void main (String args[]) {
 Aves ave=new Aves();
 ave.cor="azul";
 ave.sexo="femea";
 ave.fome=true;
 System.out.println("Vou mostrar os atributos");
 ave.mostraAtributos();
 System.out.println("-------------------------");
 System.out.println("Alimentando a Ave...");
 ave.alimentarAves();
 System.out.println("Vou mostrar os atributos");
 ave.mostraAtributos();
 System.out.println("-------------------------");
 System.out.println("Alimentando a  Ave...");
 ave.alimentarAves();

   }// fecha Aves
 }  // fecha o metod main

