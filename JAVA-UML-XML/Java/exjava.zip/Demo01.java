class Demo01
  {
  public static void main(String[] argumentos)
    {
    DoisNum1 X = new DoisNum1();

    X.EntraA(5);
    X.EntraB(8);
    System.out.println("A = " + X.RetA());
    System.out.println("B = " + X.RetB());
    }
  }
