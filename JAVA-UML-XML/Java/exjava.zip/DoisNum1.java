class DoisNum1
  {
  private int A;
  private int B;

  public void EntraA (int X) {A=X;}
  public void EntraB (int X) {B=X;}
  public int  RetA() {return A;}
  public int  RetB() {return B;}
  public int  Soma() {return A+B;}
  public int  Subtrai() {return A-B;}
  public int  Multiplica() {return A*B;}
  public int  Divide() {return A/B;}
  }
