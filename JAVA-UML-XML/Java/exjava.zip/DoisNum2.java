class DoisNum2
  {
  private int A;
  private int B;

  DoisNum2(int X, int Y) {A=X; B=Y;}
  public int  RetA() {return A;}
  public int  RetB() {return B;}
  public int  Soma() {return A+B;}
  public int  Subtrai() {return A-B;}
  public int  Multiplica() {return A*B;}
  public int  Divide() {return A/B;}
  }
