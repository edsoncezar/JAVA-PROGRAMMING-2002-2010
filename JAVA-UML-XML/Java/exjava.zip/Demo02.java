class Demo02
  {
  public static void main(String[] argumentos)
    {
    DoisNum2 X = new DoisNum2(13,28);

    System.out.println("A = " + X.RetA());
    System.out.println("B = " + X.RetB());
    }
  }
