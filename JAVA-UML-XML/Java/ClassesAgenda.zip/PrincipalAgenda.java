
public class PrincipalAgenda {
	public static void main(String[] args) {
		Agenda agenda = new Agenda();
		agenda.cadastraContato("Daniela Mercury","111");
		agenda.cadastraContato("Luana Piovani","222");
		agenda.cadastraContato("Debora Secco","333");
		agenda.cadastraContato("Debora Block","444");
		agenda.cadastraContato("Ivete Sangalo","555");

		Contato contato=agenda.encontraContato("Debora Block");
		Contato[] listaContatos=agenda.encontraContatosPorParteDoNome("Deb");
		agenda.eliminaContato(contato);
		listaContatos=agenda.getTodosContatos();
	}
}
