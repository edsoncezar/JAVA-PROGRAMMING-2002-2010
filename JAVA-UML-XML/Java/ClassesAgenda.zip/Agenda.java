public class Agenda
{
    private Contato[] contatos;
    private int indiceProximoContato;
    
    public Agenda() {
    	contatos=new Contato[50];
    	indiceProximoContato=0;
    }
    
    public void cadastraContato(String nome, String telefone)  {
    		Contato contato = new Contato(nome, telefone);
    		contatos[indiceProximoContato]=contato;
    		indiceProximoContato++;
    }
    
    public Contato encontraContato(String nome) {
        Contato contato;
        for (int t=0;t < indiceProximoContato;t++) {
            contato=contatos[t];
            if (contato.getNome().equals(nome))
                return contato;
        }
        return null;
    }
    
    //Aten��o. Existe um erro neste m�todo. Tente encontr�-lo.
    public Contato[] encontraContatosPorParteDoNome(String parteNome) {
    	Contato[] contatosEncontrados = new Contato[50];
    	int indiceProximoContatoEncontrado=0;
    	Contato contato;
    	
    	for (int t=0;t < indiceProximoContato;t++) {
    		contato=contatos[t];
			if (contato.getNome().toLowerCase().indexOf(parteNome.toLowerCase()) != -1)
                contatosEncontrados[indiceProximoContatoEncontrado]=contato;
    	}
    	return contatosEncontrados;
    }
    
    public void eliminaContato(Contato contatoAeliminar) {
    	for (int t=0;t<indiceProximoContato;t++) {
    		if (contatos[t]==contatoAeliminar) {
    			for (int g=t;g<indiceProximoContato;g++) {
    				contatos[g]=contatos[g+1];
    			}
    			indiceProximoContato--;
    		}
    	}
    }
    
    public Contato[] getTodosContatos() {
    	return contatos;
    }
}
