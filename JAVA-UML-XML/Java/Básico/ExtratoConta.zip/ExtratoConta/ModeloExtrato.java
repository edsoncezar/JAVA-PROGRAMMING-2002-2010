import javax.swing.table.AbstractTableModel;

/*
 * Created on 09/11/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

/**
 * @author Familia Branqs
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class ModeloExtrato extends AbstractTableModel {

        private ContaCorrente conta;
        
        public ModeloExtrato(ContaCorrente conta) {
            this.conta=conta;
        }
        
        void atualizaExtrato(ContaCorrente conta){
            this.conta=conta;
            fireTableDataChanged();
        }
        
        public int getColumnCount() {
            return 2;
        }
        
        public int getRowCount() {
            return conta.obterNumeroUltimoMovimento()+2;
        }
        
        public Object getValueAt(int linha, int coluna) {
            MovimentoBancario movimento = conta.obterMovimentos()[linha];
            
            if (linha == conta.obterNumeroUltimoMovimento()+1)
                if (coluna==0)
                    return "Saldo final";
                else
                    return String.valueOf(conta.obterSaldo());
            
            if (coluna == 0)
                return movimento.obterDescricao();
            if (coluna == 1)
                return String.valueOf(movimento.obterValor());
            
            return "???";
            
        }
                
        public String getColumnName(int coluna) {
            if (coluna == 0)
                return "Movimento";
            if (coluna == 1)
                return "Valor";
            return "???";
        }
}
