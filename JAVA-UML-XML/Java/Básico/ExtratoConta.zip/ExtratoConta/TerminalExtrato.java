import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

public class TerminalExtrato extends JFrame {
    
    private Banco banco;
    private JLabel lblNomeCliente;
    private JTextField txtNumeroConta;
    private ModeloExtrato modelo;
    
    public TerminalExtrato(Banco banco) {
        this.banco=banco;
        
        setTitle("Terminal de extrato");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Box primeiraLinha = Box.createHorizontalBox();
        JLabel lblNumeroConta = new JLabel("N�mero da conta");
        txtNumeroConta = new JTextField("",5);
        primeiraLinha.add(lblNumeroConta);
        primeiraLinha.add(Box.createHorizontalStrut(5));
        primeiraLinha.add(txtNumeroConta);
        
        Box segundaLinha = Box.createHorizontalBox();
        JLabel lblCliente = new JLabel("Cliente:");
        lblNomeCliente= new JLabel("");
        segundaLinha.add(lblCliente);
        segundaLinha.add(Box.createHorizontalStrut(5));
        segundaLinha.add(lblNomeCliente);
        segundaLinha.add(Box.createHorizontalGlue());
        
        
        Box terceiraLinha = Box.createHorizontalBox();
        JLabel lblExtrato = new JLabel("Extrato");
        terceiraLinha.add(lblExtrato);
        terceiraLinha.add(Box.createHorizontalGlue());
        
        Box quartaLinha = Box.createHorizontalBox();
        modelo=new ModeloExtrato(new ContaCorrente(new Cliente("","0")));
        JTable tabela = new JTable(modelo);
        TableColumn coluna =tabela.getColumnModel().getColumn(0);
        coluna.setPreferredWidth(300);
        coluna = tabela.getColumnModel().getColumn(1);
        coluna.setPreferredWidth(100);

        DefaultTableCellRenderer ren = new DefaultTableCellRenderer();
        ren.setHorizontalAlignment(SwingConstants.RIGHT);
        coluna.setCellRenderer(ren);
        
        quartaLinha.add(new JScrollPane(tabela));
        

        Box linhas = Box.createVerticalBox();
        
        linhas.add(primeiraLinha);
        linhas.add(Box.createVerticalStrut(5));
        linhas.add(segundaLinha);
        linhas.add(Box.createVerticalStrut(5));
        linhas.add(terceiraLinha);
        linhas.add(Box.createVerticalStrut(5));
        linhas.add(quartaLinha);
                
        JPanel painel = new JPanel();
        painel.add(linhas);
        
        getContentPane().add(painel);
        
        pack();
        
        Toolkit ferramenta = Toolkit.getDefaultToolkit();
        Dimension tamanhoTela = ferramenta.getScreenSize();
        int alturaTela=tamanhoTela.height;
        int larguraTela=tamanhoTela.width;
        
        Dimension tamanhoJanela= getSize();
        int alturaJanela=tamanhoJanela.height;
        int larguraJanela=tamanhoJanela.width;
        
        setLocation(larguraTela-larguraJanela,0);
        
        txtNumeroConta.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                pressionouEnter();
            }
        });
    
        show();
    }
    
    public void pressionouEnter(){
        ContaCorrente conta=banco.obterContaCorrente(Integer.parseInt(txtNumeroConta.getText()));
        if (conta!=null){
            lblNomeCliente.setText(conta.obterNomeCliente());
            modelo.atualizaExtrato(conta);
        }
        else {
            lblNomeCliente.setText("Conta n�o encontrada");
            modelo.atualizaExtrato(new ContaCorrente(new Cliente("","0")));
        }
    }
    
}
