/**
 * Criado em 31/08/2004
 * @author Fernando Branquinho
 */

public class SistemaAgenda {
	
	public static void main(String[] args) {
		Agenda agenda = new Agenda();
		
		//Contatos criados automaticamente para teste
		agenda.cadastraContato("Jo�o","1111-1111");
		agenda.cadastraContato("Maria","2222-2222");
		agenda.cadastraContato("Jos� Maria","3333-3333");
		agenda.cadastraContato("Maria Jos�","4444-4444");
		
		FormPrincipal janela = new FormPrincipal(agenda);
		janela.show();
	}
}
