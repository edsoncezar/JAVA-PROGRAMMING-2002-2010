import java.util.ArrayList;

/**
 * Criado em 31/08/2004
 * @author Fernando Branquinho
 */

public class Agenda
{
    private ArrayList contatos;
    
    Agenda() {
        contatos = new ArrayList();
    }
    
    public void cadastraContato(String nome, String telefone) {
        Contato contato = new Contato(nome, telefone);
        contatos.add(contato);
    }
    
    public Contato encontraContato(String nome) {
        
        Contato contato;
        
        for (int t=0;t < contatos.size();t++) {
            contato=(Contato)contatos.get(t);
            if (contato.getNome().equals(nome))
                return contato;
        }
        
        return null;
    }
    
    public void eliminaContato(Contato contato) {
            contatos.remove(contato);
    }
    
    public ArrayList getTodosContatos() {
    	return contatos;
    }
}
