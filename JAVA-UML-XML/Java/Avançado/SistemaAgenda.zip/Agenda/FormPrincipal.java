import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Criado em 31/08/2004
 * @author Fernando Branquinho
 */

public class FormPrincipal extends JFrame {
	
	Agenda agenda;
	
	FormPrincipal(Agenda agenda) {
		this.agenda=agenda;
		
		setTitle("Agenda");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		Box menu= Box.createHorizontalBox();
		JButton btnNovoContato = new JButton("Novo contato");
		JButton btnListaContatos = new JButton("Lista contatos");
		JButton btnEncontraContato = new JButton("Encontra contato");
		JButton btnSair = new JButton("Sair");
		
		menu.add(btnNovoContato);
		menu.add(Box.createHorizontalStrut(5));
		menu.add(btnListaContatos);
		menu.add(Box.createHorizontalStrut(5));
		menu.add(btnEncontraContato);
		menu.add(Box.createHorizontalStrut(5));
		menu.add(btnSair);
		
		JPanel painel=new JPanel();
		painel.add(menu);
		
		getContentPane().add(painel,BorderLayout.CENTER);
		
		pack();
		
		btnNovoContato.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				pressionouNovoContato();
			}
		});
		
		btnListaContatos.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				pressionouListaContatos();
			}
		});
		
		btnSair.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				System.exit(0);
			}
		});
	}
	public void pressionouNovoContato() {
		FormCadastraContato janela = new FormCadastraContato(agenda);
		janela.show();
	}
	
	public void pressionouListaContatos(){
		FormListaContatos janela = new FormListaContatos(agenda);
		janela.show();
	}
	
}
