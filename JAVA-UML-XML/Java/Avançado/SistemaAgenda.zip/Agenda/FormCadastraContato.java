import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Criado em 31/08/2004
 * @author Fernando Branquinho
 */

public class FormCadastraContato extends JFrame {
	
	
	JTextField txtCampoNome;
	JTextField txtCampoTelefone;
	
	Agenda agenda;
	
	FormCadastraContato(Agenda agenda) {
		this.agenda=agenda;
		
		setTitle("Cadastra contato");
		
				
		Box primeiraLinha = Box.createHorizontalBox();
		JLabel lblNome = new JLabel("Nome:");
		txtCampoNome = new JTextField("",40);
		primeiraLinha.add(lblNome);
		primeiraLinha.add(Box.createHorizontalStrut(5));
		primeiraLinha.add(txtCampoNome);

		Box segundaLinha = Box.createHorizontalBox();
		JLabel lblTelefone = new JLabel("Telefone:");
		txtCampoTelefone = new JTextField("",20);
		segundaLinha.add(lblTelefone);
		segundaLinha.add(Box.createHorizontalStrut(5));
		segundaLinha.add(txtCampoTelefone);
		
		Box terceiraLinha = Box.createHorizontalBox();
		JButton btnIncluir = new JButton("Incluir");
		JButton btnSair = new JButton("Sair");
		terceiraLinha.add(btnIncluir);
		terceiraLinha.add(Box.createHorizontalGlue());
		terceiraLinha.add(btnSair);
		
		Box linhas = Box.createVerticalBox();
		
		linhas.add(primeiraLinha);
		linhas.add(Box.createVerticalStrut(5));
		linhas.add(segundaLinha);
		linhas.add(Box.createVerticalStrut(5));
		linhas.add(terceiraLinha);
		
		JPanel painel = new JPanel();
		painel.add(linhas);
		
		getContentPane().add(painel);
		
		pack();
		
		Toolkit ferramenta = Toolkit.getDefaultToolkit();
		Dimension tamanhoTela = ferramenta.getScreenSize();
		int alturaTela=tamanhoTela.height;
		int larguraTela=tamanhoTela.width;
		
		Dimension tamanhoJanela= getSize();
		int alturaJanela=tamanhoJanela.height;
		int larguraJanela=tamanhoJanela.width;
		
		setLocation(larguraTela/2-larguraJanela/2,alturaTela/2-alturaJanela/2);
		
		btnIncluir.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				pressionouIncluir();
			}
		});
		
		btnSair.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				dispose();
			}
		});
		
	}
	
	public void pressionouIncluir() {
		agenda.cadastraContato(txtCampoNome.getText(),txtCampoTelefone.getText());
		dispose();
	}
}
