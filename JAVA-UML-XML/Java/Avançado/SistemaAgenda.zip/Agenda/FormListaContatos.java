import java.awt.Checkbox;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Criado em 31/08/2004
 * @author Fernando Branquinho
 */

public class FormListaContatos extends JFrame {
	
	Agenda agenda;
	Box blocoContatos;
		
	public FormListaContatos(Agenda agenda){
		this.agenda=agenda;
	
		setTitle("Lista contatos");
		
		Box primeiraLinha = Box.createHorizontalBox();
		JLabel lblContatos = new JLabel("Contatos");
		primeiraLinha.add(lblContatos);
		primeiraLinha.add(Box.createHorizontalGlue());

		blocoContatos = Box.createVerticalBox();
		
		ArrayList contatos=agenda.getTodosContatos();
		
		for (int t=0;t < contatos.size();t++) {
			Contato contato=(Contato)contatos.get(t);
			String texto = contato.getNome()+"("+contato.getTelefone()+")";
			blocoContatos.add(new Checkbox(texto,false));
		}
		
		Box terceiraLinha = Box.createHorizontalBox();
		JButton btnExcluir = new JButton("Excluir");
		JButton btnSair = new JButton("Sair");
		terceiraLinha.add(btnExcluir);
		terceiraLinha.add(Box.createHorizontalGlue());
		terceiraLinha.add(btnSair);

		Box linhas = Box.createVerticalBox();
		
		linhas.add(primeiraLinha);
		linhas.add(blocoContatos);
		linhas.add(terceiraLinha);
		
		JPanel painel = new JPanel();
		painel.add(linhas);
		
		getContentPane().add(painel);
				
		pack();
		
		Toolkit ferramenta = Toolkit.getDefaultToolkit();
		Dimension tamanhoTela = ferramenta.getScreenSize();
		int alturaTela=tamanhoTela.height;
		int larguraTela=tamanhoTela.width;
		
		Dimension tamanhoJanela= getSize();
		int alturaJanela=tamanhoJanela.height;
		int larguraJanela=tamanhoJanela.width;
		
		setLocation(larguraTela/2-larguraJanela/2,alturaTela/2-alturaJanela/2);
		
		btnExcluir.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				pressionouExcluir();
			}
		});
		
		btnSair.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				dispose();
			}
		});
		
	}
		
	public void pressionouExcluir() {

		ArrayList contatos=agenda.getTodosContatos();
		
		for (int t=0; t < contatos.size();t++) {
			Contato contato = (Contato)contatos.get(t);
			Checkbox chk = (Checkbox)blocoContatos.getComponent(t);
			
			if (chk.getState())
					contatos.remove(contato);
		}
		
		dispose();
		new FormListaContatos(agenda).show();
	}
}
