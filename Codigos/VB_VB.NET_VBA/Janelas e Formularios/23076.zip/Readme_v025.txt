' ========================================================================
' Module:   CtrlResizer
' Author:   Carlo Somigliana (Italy)
' e-mail:   somic@libero.it
' Rel.  :   0.25
' Date  :   11 Aug 2002
' lang. :   Visual Basic 5.0 - 6.0
'
' Description:
'   A VB module to automatically resize controls with forms and
'   ChilForms with their MDI Forms
'   Change Maxf constant to change max AutoResizing forms
'
' Use:
'   -Add 'AutoResize' in the TAG property of the controls you want to
'   automatically resize or Set ResizeAllControls flag to TRUE to
'   automatically resize all the controls in the form.
'   -Add 'NoResize' in the TAG property of the controls you DON'T want
'   to be automatically resized
'   -Add 'NoFontResize' in the TAG property of the controls you DON'T want
'   to automatically resize the Font
'   See sample code
'
' License:
'   Free, at the condition to leave this Module as is or update
'   the Version History at any change and advise me back about it
'   (continuous improvement !?!)
'   Comments and suggestions will be appreciated
'
' Version History
'-------------------------------------------------------------------------------
' Rel.  Date          Author            Description                   Compatible
'
' 0.00  23 Apr 2001   C. Somigliana     First Issue                   -
' 0.10  04 May 2001          "          Modified for MDI Forms        OK
'                                       (req. Gawie Wolmarans)
' 0.11  13 Jul 2001          "          Forms dimensions stored       OK
'                                       only if form visible
' 0.20  11 Nov 2001          "          Fixed Bug with Line control   OK
'                                       (thanks to Massimo Riccardi)
' 0.21  17 Nov 2001          "          Added Form Font Resize        OK
' 0.22  27 Dec 2001          "          Added
'                                       -Hidden Form while Resizing   ---
'                                       -NoFontResize parameter in    OK
'                                       in .Tag to void resizing font
'                                       -DeleteFormStartDimensions    OK
' 0.23  22 Jan 2002          "          -Fixed a bug Iconizing form   OK
' 0.24  28 Apr 2002          "          -Added 'NoResize' and         OK
'                                        'NoFontResize' options
'                                       -Added check if control can't
'                                        be resized (es. Timer)
' 0.24B 02 May 2002          "          -Added SSTab support          90%
'                                       (req. by father Zdzislaw
'                                       Huber-Finland)
' 0.24C 01 Jul 2002   Kipp E. Howard    Fixed a bug in Sub            OK
'                                       SetNewControlsDimensions
'                                       (many thanks)
' 0.25  11 Aug 2002   C. Somigliana     -Hidden Form while Resizing   OK
'                                       only if form is Not Modal
'                                       -Code Cleaned Up
'===========================================================================