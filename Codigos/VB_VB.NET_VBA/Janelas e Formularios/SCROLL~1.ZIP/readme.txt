Description : Scroll text / pictures like you see in eudora using only
picture boxes

Version : VB6

Author : Shriram Kondhawekar

contact : kshriram@netscape.net

Remarks : Pls read the remarks to know what i have done on the main form