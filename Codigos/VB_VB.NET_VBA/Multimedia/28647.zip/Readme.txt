SaS's VB-OpenGL Demo 1.0

A comprehensive program that demonstrate use of OpenGL API in Visual Basic Environmnet. It covers Ligthing, Bitmap(.bmp) Texture loading using Windows API, Hi Resolution Timer support, Time-based Animations and more Advanced Topics like Multiple viewports and Mouse Picking(Mouse support for OpenGL).

Uses OpenGL 1.2 Type Library see included: tlb.htm

Important Note:
This program won't run if 'vbogl.tlb' is not found! In this case References Dialoag pops up. Click Browse to locate 'vbogl.tlb'in the Programs directory.

---------------

Contact: Saadat Ali Shah, Email:shahji_2000@yahoo.com