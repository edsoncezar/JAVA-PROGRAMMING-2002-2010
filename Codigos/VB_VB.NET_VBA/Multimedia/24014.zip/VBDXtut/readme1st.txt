VBDXtut 
submitted by william quincy
contact - info@williamquincy.com

notice the first part of the tutorial starts with "part0.rtf"