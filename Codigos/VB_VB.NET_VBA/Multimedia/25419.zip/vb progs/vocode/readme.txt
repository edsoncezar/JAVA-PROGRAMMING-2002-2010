Vocode v1.0 - Jan 2003
Daniel Chilcott danieljc@postnet.co.za

Vocode is a simple, configurable software vocoder 
that can reproduce the vocal effect that has become
popular in music. It also has many other applications.
The WaveLib module also contains many useful functions
for manipulating pcm wave files.