   title: GDI pens
  posted: by william quincy
   email: info@williamquincy.com
web site: www.williamquincy.com(follow the links to vbstuff and other freestuff)
    desc: This is a demo on using GDI pens. It shows draw style and color. It 
          also shows how to use ROP2 R2_NOT to draw the "rubber band" used in
          drawing apps. For VB6.