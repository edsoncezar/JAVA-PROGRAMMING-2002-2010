===========================================
Transform Picture !
Zoom in, zoom out and change color on fly!

This code is free to use for any purpose,
you should keep the original copyright:

Copyright (C) 2003 Free Code
http://www.emu8086.com/vb/

For comments: info@emu8086.com
===========================================


 It's not my best code :)
 but still worth looking at.
 My greatest work is "Real Show", you can
 find it on my web site:
 http://www.emu8086.com/vb/
 I wrote it both in Java and VB, so it
 can work directly from your web site !!

 I hope to update this sample, and add more effects
 in the near future!
