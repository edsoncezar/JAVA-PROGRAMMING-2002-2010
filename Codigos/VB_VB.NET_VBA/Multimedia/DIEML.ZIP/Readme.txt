|Moron Luxation	       \
|By Ben Bond		\
|		         \
|Please email me to 	  \	
|__________________________\__
\ ben_bond_junior@yahoo.com  /
 \ and tell me what ya think/
__\________________________/
			  |
and visit my site	  |
http://come.to/DieSite	  /
			 /
________________________/