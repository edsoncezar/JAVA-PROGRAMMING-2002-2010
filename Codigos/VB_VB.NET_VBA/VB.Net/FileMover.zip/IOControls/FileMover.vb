Imports System.ComponentModel.Design
Imports System.IO

Public Class FileMover
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Public Event Exception(ByVal sender As System.Object, ByVal e As ExceptionArgs)
    Public Event StatusUpdate(ByVal sender As System.Object, ByVal e As StatusUpdateArgs)

    Private _buffersize As Integer = 300000
    Public Property Buffersize() As Integer
        Get
            Return _buffersize
        End Get
        Set(ByVal Value As Integer)
            _buffersize = Value
        End Set
    End Property

    Private _sourcePath As String
    Public Property SourcePath() As String
        Get
            Return _sourcePath
        End Get
        Set(ByVal Value As String)
            If Not Value Is Nothing Then
                If File.Exists(Value) = False Then
                    RaiseException(New FileNotFoundException(Value & " not found"))
                Else
                    _sourcePath = Value
                End If
            End If
        End Set
    End Property

    Public ReadOnly Property SourceFileInfo() As System.IO.FileInfo
        Get
            If File.Exists(_sourcePath) Then
                Return New FileInfo(_sourcePath)
            End If
        End Get
    End Property

    Private _destPath As String
    Public Property DestPath() As String
        Get
            Return _destPath
        End Get
        Set(ByVal Value As String)
            _destPath = Value
        End Set
    End Property

    Public ReadOnly Property DestFileInfo() As FileInfo
        Get
            If File.Exists(_destPath) Then
                Return New FileInfo(_destPath)
            End If
        End Get
    End Property

    Protected _syncrhonizingObject As System.ComponentModel.ISynchronizeInvoke
    Public Property SynchronizingObject() As System.ComponentModel.ISynchronizeInvoke
        Get
            If _syncrhonizingObject Is Nothing And Me.DesignMode Then
                Dim designer As IDesignerHost = CType(Me.GetService(GetType(IDesignerHost)), IDesignerHost)
                If Not (designer Is Nothing) Then
                    _syncrhonizingObject = CType(designer.RootComponent, System.ComponentModel.ISynchronizeInvoke)
                End If
            End If
            Return _syncrhonizingObject
        End Get
        Set(ByVal Value As System.ComponentModel.ISynchronizeInvoke)
            If Not Me.DesignMode Then
                If Not (_syncrhonizingObject Is Nothing) And Not (_syncrhonizingObject Is Value) Then
                    Throw New Exception("Property can not be set at run-time.")
                Else
                    _syncrhonizingObject = Value
                End If
            End If
        End Set
    End Property

    Public Sub Copy()
        Try
            MoveData(FileAction.Copy)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub Move()
        Try
            MoveData(FileAction.Move)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub MoveData(ByVal Action As FileAction)
        Dim State As New ActionState
        SyncLock State
            With State
                '-- Carl Fixed bug Feb 3, 2005. Action not set
                .Action = Action

                .TotalBytes = CInt(Me.SourceFileInfo.Length)
                Try
                    .StreamIn = File.Open(Me.SourcePath, FileMode.Open, FileAccess.Read, FileShare.Read)
                Catch ex As Exception
                    Throw ex
                End Try

                Try
                    .StreamOut = File.Open(Me.DestPath, FileMode.Create, FileAccess.Write, FileShare.Read)
                Catch ex As Exception
                    .Close()
                    Throw ex
                End Try

                ReDim .Buffer(Buffersize - 1)

                Try
                    .StreamIn.BeginRead(.Buffer, 0, .Buffer.Length, AddressOf DataRead, State)
                Catch ex As Exception
                    .Close()
                    Throw ex
                End Try
            End With
        End SyncLock
    End Sub

    Private Sub DataRead(ByVal ar As IAsyncResult)
        Dim State As ActionState = DirectCast(ar.AsyncState, ActionState)
        SyncLock State
            Try
                Dim bytesread As Int32 = State.StreamIn.EndRead(ar)
                Console.WriteLine("Bytes Read: " & bytesread)
                If bytesread > 0 Then
                    State.BytesBeingWritten = bytesread
                    State.StreamOut.BeginWrite(State.Buffer, 0, bytesread, AddressOf DataWritten, State)
                End If
            Catch ex As Exception
                State.Close()
                RaiseException(ex)
            End Try
        End SyncLock
    End Sub

    Private Sub DataWritten(ByVal ar As IAsyncResult)
        Dim State As ActionState = DirectCast(ar.AsyncState, ActionState)
        SyncLock State
            With State
                Try
                    .StreamOut.EndWrite(ar)
                    .BytesWritten += .BytesBeingWritten
                    RaiseStatusUpdate(.TotalBytes, .BytesWritten)
                    If .BytesWritten = .TotalBytes Then
                        '-- Done
                        .Close()
                        If .Action = FileAction.Move Then
                            File.Delete(SourcePath)
                        End If
                    Else
                        .StreamIn.BeginRead(.Buffer, 0, .Buffer.Length, AddressOf DataRead, State)
                    End If
                Catch ex As Exception
                    .Close()
                    RaiseException(ex)
                End Try
            End With
        End SyncLock
    End Sub

    Private Sub RaiseException(ByVal ex As Exception)
        Dim e As New ExceptionArgs
        With e
            .Exception = ex
        End With
        If Me.SynchronizingObject Is Nothing Then
            OnException(e)
        Else
            Dim dlg As New ExceptionEventDelegate(AddressOf OnException)
            Dim args() As Object = {e}
            Try
                Me.SynchronizingObject.Invoke(dlg, args)
            Catch exx As Exception
                Trace.WriteLine(exx.Message)
            End Try
        End If
    End Sub

    Private Sub RaiseStatusUpdate(ByVal totalbytes As Int32, ByVal byteswritten As Int32)
        Dim e As New StatusUpdateArgs
        With e
            .BytesWritten = byteswritten
            .TotalBytes = totalbytes
        End With
        If Me.SynchronizingObject Is Nothing Then
            OnStatusUpdate(e)
        Else
            Dim dlg As New StatusUpdateEventDelegate(AddressOf OnStatusUpdate)
            Dim args() As Object = {e}
            Try
                Me.SynchronizingObject.Invoke(dlg, args)
            Catch ex As Exception
                Trace.WriteLine(ex.Message)
            End Try
        End If
    End Sub

    Private Delegate Sub ExceptionEventDelegate(ByVal e As ExceptionArgs)
    Protected Overridable Sub OnException(ByVal e As ExceptionArgs)
        RaiseEvent Exception(Me, e)
    End Sub

    Private Delegate Sub StatusUpdateEventDelegate(ByVal e As StatusUpdateArgs)
    Protected Overridable Sub OnStatusUpdate(ByVal e As StatusUpdateArgs)
        RaiseEvent StatusUpdate(Me, e)
    End Sub

    Protected Enum FileAction
        Copy
        Move
    End Enum

    Private Class ActionState

        Private _action As FileAction
        Public Property Action() As FileAction
            Get
                Return _action
            End Get
            Set(ByVal Value As FileAction)
                _action = Value
            End Set
        End Property

        Private _totalBytes As Integer
        Public Property TotalBytes() As Integer
            Get
                Return _totalBytes
            End Get
            Set(ByVal Value As Integer)
                _totalBytes = Value
            End Set
        End Property

        Private _bytesBeingWritten As Integer
        Public Property BytesBeingWritten() As Integer
            Get
                Return _bytesBeingWritten
            End Get
            Set(ByVal Value As Integer)
                _bytesBeingWritten = Value
            End Set
        End Property

        Private _bytesWritten As Integer
        Public Property BytesWritten() As Integer
            Get
                Return _bytesWritten
            End Get
            Set(ByVal Value As Integer)
                _bytesWritten = Value
            End Set
        End Property

        Private _buffer() As Byte
        Public Property Buffer() As Byte()
            Get
                Return _buffer
            End Get
            Set(ByVal Value As Byte())
                _buffer = Value
            End Set
        End Property

        Private _streamIn As Stream
        Public Property StreamIn() As Stream
            Get
                Return _streamIn
            End Get
            Set(ByVal Value As Stream)
                _streamIn = Value
            End Set
        End Property

        Private _streamOut As Stream
        Public Property StreamOut() As Stream
            Get
                Return _streamOut
            End Get
            Set(ByVal Value As Stream)
                _streamOut = Value
            End Set
        End Property

        Public Sub Close()
            If Not _streamOut Is Nothing Then
                Try
                    _streamOut.Close()
                Catch ex As Exception
                End Try
            End If
            If Not _streamIn Is Nothing Then
                Try
                    _streamIn.Close()
                Catch ex As Exception
                End Try
            End If
        End Sub
    End Class

End Class

Public Class ExceptionArgs
    Inherits System.EventArgs

    Private _exception As System.Exception
    Public Property Exception() As System.Exception
        Get
            Return _exception
        End Get
        Set(ByVal Value As System.Exception)
            _exception = Value
        End Set
    End Property

End Class

Public Class StatusUpdateArgs
    Inherits System.EventArgs

    Private _totalBytes As Integer
    Public Property TotalBytes() As Integer
        Get
            Return _totalBytes
        End Get
        Set(ByVal Value As Integer)
            _totalBytes = Value
        End Set
    End Property

    Private _bytesWritten As Integer
    Public Property BytesWritten() As Integer
        Get
            Return _bytesWritten
        End Get
        Set(ByVal Value As Integer)
            _bytesWritten = Value
        End Set
    End Property

    Public ReadOnly Property PercentComplete() As Integer
        Get
            If _totalBytes <> 0 Then
                Try
                    Dim ll As Long = 100& * _bytesWritten
                    Return CInt(ll \ _totalBytes)
                Catch ex As Exception

                End Try
            Else
                Return 0
            End If
        End Get
    End Property

End Class

