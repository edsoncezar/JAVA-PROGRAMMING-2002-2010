Public Class frmFileMover
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pb As System.Windows.Forms.ProgressBar
    Friend WithEvents txtSource As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtDest As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSrc As System.Windows.Forms.Button
    Friend WithEvents btnDest As System.Windows.Forms.Button
    Friend WithEvents chkDelete As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtBufferSize As System.Windows.Forms.TextBox
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents FileMover1 As IOControls.FileMover
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.pb = New System.Windows.Forms.ProgressBar
        Me.txtSource = New System.Windows.Forms.TextBox
        Me.txtDest = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnSrc = New System.Windows.Forms.Button
        Me.btnDest = New System.Windows.Forms.Button
        Me.chkDelete = New System.Windows.Forms.CheckBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtBufferSize = New System.Windows.Forms.TextBox
        Me.btnGo = New System.Windows.Forms.Button
        Me.FileMover1 = New IOControls.FileMover(Me.components)
        Me.SuspendLayout()
        '
        'pb
        '
        Me.pb.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pb.Location = New System.Drawing.Point(0, 171)
        Me.pb.Name = "pb"
        Me.pb.Size = New System.Drawing.Size(600, 23)
        Me.pb.TabIndex = 0
        '
        'txtSource
        '
        Me.txtSource.Location = New System.Drawing.Point(16, 32)
        Me.txtSource.Name = "txtSource"
        Me.txtSource.Size = New System.Drawing.Size(528, 23)
        Me.txtSource.TabIndex = 1
        Me.txtSource.Text = ""
        '
        'txtDest
        '
        Me.txtDest.Location = New System.Drawing.Point(16, 88)
        Me.txtDest.Name = "txtDest"
        Me.txtDest.Size = New System.Drawing.Size(528, 23)
        Me.txtDest.TabIndex = 2
        Me.txtDest.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Source File:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Destination File:"
        '
        'btnSrc
        '
        Me.btnSrc.Location = New System.Drawing.Point(552, 32)
        Me.btnSrc.Name = "btnSrc"
        Me.btnSrc.Size = New System.Drawing.Size(32, 23)
        Me.btnSrc.TabIndex = 5
        Me.btnSrc.Text = "..."
        '
        'btnDest
        '
        Me.btnDest.Location = New System.Drawing.Point(552, 88)
        Me.btnDest.Name = "btnDest"
        Me.btnDest.Size = New System.Drawing.Size(32, 23)
        Me.btnDest.TabIndex = 6
        Me.btnDest.Text = "..."
        '
        'chkDelete
        '
        Me.chkDelete.Location = New System.Drawing.Point(16, 128)
        Me.chkDelete.Name = "chkDelete"
        Me.chkDelete.Size = New System.Drawing.Size(208, 24)
        Me.chkDelete.TabIndex = 7
        Me.chkDelete.Text = "Delete Source After Copy"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(264, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Buffer Size:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtBufferSize
        '
        Me.txtBufferSize.Location = New System.Drawing.Point(360, 128)
        Me.txtBufferSize.Name = "txtBufferSize"
        Me.txtBufferSize.Size = New System.Drawing.Size(80, 23)
        Me.txtBufferSize.TabIndex = 9
        Me.txtBufferSize.Text = ""
        '
        'btnGo
        '
        Me.btnGo.Location = New System.Drawing.Point(472, 128)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.TabIndex = 10
        Me.btnGo.Text = "Go"
        '
        'FileMover1
        '
        Me.FileMover1.Buffersize = 300000
        Me.FileMover1.DestPath = Nothing
        Me.FileMover1.SourcePath = Nothing
        Me.FileMover1.SynchronizingObject = Me
        '
        'frmFileMover
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 16)
        Me.ClientSize = New System.Drawing.Size(600, 194)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.txtBufferSize)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.chkDelete)
        Me.Controls.Add(Me.btnDest)
        Me.Controls.Add(Me.btnSrc)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtDest)
        Me.Controls.Add(Me.txtSource)
        Me.Controls.Add(Me.pb)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmFileMover"
        Me.Text = "FileMover Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSrc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSrc.Click
        Dim dlgFile As New OpenFileDialog
        With dlgFile
            .FileName = "*.*"
            .Filter = "All Files (*.*)|*.*"
            .InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic)
            If .ShowDialog() = DialogResult.OK Then
                Me.txtSource.Text = .FileName
            End If
        End With
    End Sub

    Private Sub btnDest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDest.Click
        Dim dlgFile As New SaveFileDialog
        With dlgFile
            .FileName = "*.*"
            If Me.txtSource.Text <> "" Then
                If IO.File.Exists(Me.txtSource.Text) Then
                    .FileName = IO.Path.GetFileName(Me.txtSource.Text)
                End If
            End If
            .Filter = "All Files (*.*)|*.*"
            .InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            If .ShowDialog() = DialogResult.OK Then
                Me.txtDest.Text = .FileName
            End If
        End With
    End Sub

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        With FileMover1
            .Buffersize = CInt(Me.txtBufferSize.Text)
            .SourcePath = txtSource.Text
            .DestPath = txtDest.Text
            If Me.chkDelete.Checked = True Then
                .Move()
            Else
                .Copy()
            End If
        End With
    End Sub

    Private Sub FileMover1_StatusUpdate(ByVal sender As Object, ByVal e As IOControls.StatusUpdateArgs) Handles FileMover1.StatusUpdate
        pb.Value = e.PercentComplete
        If e.BytesWritten = e.TotalBytes Then
            MsgBox("Done")
        End If
    End Sub

    Private Sub FileMover1_Exception(ByVal sender As Object, ByVal e As IOControls.ExceptionArgs) Handles FileMover1.Exception
        MsgBox(e.Exception.Message)
    End Sub

    Private Sub frmFileMover_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.txtBufferSize.Text = FileMover1.Buffersize.ToString
    End Sub

End Class

