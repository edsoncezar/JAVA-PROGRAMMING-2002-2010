Imports ICSharpCode.SharpZipLib.Zip.Compression
Imports ICSharpCode.SharpZipLib.Zip.Compression.Streams
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.IO

'-- CarlsZipLib is a wrapper around the ICSharpCode.SharpZipLib to do 
'   Zip compression on any serializable object to and from either a 
'   byte array or an open stream. 
'
'   By Carl Franklin (http://weblogs.asp.net/CFranklin)

Public Class CarlsZipLib
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Public Function CompressObjectToStream(ByVal OpenStream As System.IO.Stream, ByVal AnyObject As Runtime.Serialization.ISerializable) As System.IO.Stream
        Dim d As New Deflater(Deflater.BEST_COMPRESSION)
        Dim zipper As New DeflaterOutputStream(OpenStream, d)
        Try
            Dim bytes() As Byte = SerializeObject(AnyObject)
            zipper.Write(bytes, 0, bytes.Length)
            zipper.Finish()
            zipper.Flush()
            Return OpenStream
        Catch ex As Exception
            Throw ex
        Finally
            zipper.Close()
        End Try
    End Function

    Public Function DeCompressStreamToObject(ByVal OpenStream As System.IO.Stream) As Object
        Dim unzipper As New InflaterInputStream(OpenStream)
        Dim obj As Object
        Try
            unzipper.Flush()
            unzipper.Seek(0, SeekOrigin.Begin)
            Dim bf As New BinaryFormatter
            obj = bf.Deserialize(unzipper)
            Return obj
        Catch ex As Exception
            Throw ex
        Finally
            unzipper.Close()
        End Try
    End Function

    Public Function CompressObject(ByVal AnyObject As Runtime.Serialization.ISerializable) As Byte()
        Dim mem As New MemoryStream
        Dim d As New Deflater(Deflater.BEST_COMPRESSION)
        Dim zipper As New DeflaterOutputStream(mem, d)
        Try
            Dim bytes() As Byte = SerializeObject(AnyObject)
            zipper.Write(bytes, 0, bytes.Length)
            zipper.Finish()
            zipper.Flush()
            zipper.Seek(0, SeekOrigin.Begin)
            Dim retbytes() As Byte = mem.GetBuffer
            Return retbytes
        Catch ex As Exception
            Throw ex
        Finally
            zipper.Close()
            mem.Close()
        End Try
    End Function

    Public Function DeCompressObject(ByVal Data() As Byte) As Object
        Dim mem As New MemoryStream(Data)
        Dim unzipper As New InflaterInputStream(mem)
        Dim obj As Object
        Try
            unzipper.Flush()
            unzipper.Seek(0, SeekOrigin.Begin)
            Dim bf As New BinaryFormatter
            obj = bf.Deserialize(unzipper)
            Return obj
        Catch ex As Exception
            Throw ex
        Finally
            unzipper.Close()
            mem.Close()
        End Try
    End Function

    Public Function SerializeObject(ByVal AnyObject As Runtime.Serialization.ISerializable) As Byte()
        Dim bf As New BinaryFormatter
        Dim Mem As New MemoryStream
        Try
            bf.Serialize(Mem, AnyObject)
            Return Mem.ToArray
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function DeserializeObject(ByVal bytes() As Byte) As Object
        Dim bf As New BinaryFormatter
        Dim Mem As New MemoryStream(bytes)
        Try
            Return bf.Deserialize(Mem)
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
