Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 40)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(728, 320)
        Me.DataGrid1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(184, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Get Data and Save to File"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(200, 8)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Load Dataset"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(320, 8)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(64, 23)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Clear"
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=CARLFRANKLIN;packet size=4096;integrated security=SSPI;data source" & _
        "=""."";persist security info=False;initial catalog=pubs"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(744, 368)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGrid1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim Zipper As New ZipTools.CarlsZipLib
    Dim dsAuthors As DataSet

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '-- Get a filled dataset from somewhere (you do this yourself)
        dsAuthors = New DataSet
        Dim cn As New SqlClient.SqlConnection("integrated security=SSPI;data source=""."";initial catalog=pubs")
        Dim cmd As New SqlClient.SqlCommand("SELECT * FROM authors", cn)
        Dim sa As New SqlClient.SqlDataAdapter(cmd)
        sa.MissingSchemaAction = MissingSchemaAction.AddWithKey
        sa.Fill(dsAuthors, "authors")
        '-- Bind the grid to the first table
        DataGrid1.DataSource = dsAuthors.Tables(0)
        '-- Create a file for storing the data by opening a stream
        Dim fs As New IO.FileStream("c:\mydatasaet.bin", IO.FileMode.Create)
        '-- Zip and save to disk
        Zipper.CompressObjectToStream(fs, dsAuthors)
        '-- Close the stream (The tool does not close the stream)
        fs.Close()
        '-- Done
        Beep()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '-- Open the file stream
        Dim fs As New IO.FileStream("c:\mydatasaet.bin", IO.FileMode.Open)
        '-- Return the dataset from the compressed file
        dsAuthors = CType(Zipper.DeCompressStreamToObject(fs), DataSet)
        '-- Bind the grid
        DataGrid1.DataSource = dsAuthors.Tables(0)
        '-- Close the stream
        fs.Close()
        '-- Done
        Beep()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '-- Clear the grid
        DataGrid1.DataSource = Nothing
        dsAuthors = Nothing
    End Sub

End Class





