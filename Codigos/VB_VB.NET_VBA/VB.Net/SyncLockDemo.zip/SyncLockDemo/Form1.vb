Imports System.Threading

'-- This application demonstrates the value of thread synchronization.
'   Written by Carl Franklin, of .NET Rocks! fame
'   Available online at http://www.franklins.net/dotnet
'   Listen to .NET Rocks! http://www.franklins.net/dotnetrocks

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(256, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Start"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Items.AddRange(New Object() {"10000", "100000", "1000000", "10000000", "100000000", "1000000000", "10000000000"})
        Me.ComboBox1.Location = New System.Drawing.Point(120, 64)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(304, 48)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "This demo executes a sub on three simultanous threads. The sub increments a count" & _
        "er. Select the number of iterations through the loop. No Thread Synchronization " & _
        "is used"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(256, 104)
        Me.Button2.Name = "Button2"
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Start"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(224, 40)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "This button executes the same code, only with Thread Synchronization"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Form1
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 146)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "SyncLock Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Counter As Int64
    Private Iterations As Int64
    Private SyncObj As New Object   '-- SyncLock only locks Reference Types.

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Iterations = CInt(ComboBox1.Text)
        '-- Disable the buttons
        Button1.Enabled = False
        Button2.Enabled = False
        '-- Initialize the counter
        Counter = 0
        '-- Create three new threads to run the Go subroutine
        Dim T1 As New Thread(AddressOf Go)
        Dim T2 As New Thread(AddressOf Go)
        Dim T3 As New Thread(AddressOf Go)
        '-- Start the first thread and wait 100 ms
        T1.Start()
        Thread.Sleep(100)
        '-- Start the second thread and wait 100 ms
        T2.Start()
        Thread.Sleep(100)
        '-- Start the third thread
        T3.Start()
        '-- Wait for all the threads to finish
        T1.Join()
        T2.Join()
        T3.Join()
        '-- Show the counter. 
        '   In a perfect world, we expect an even multiple of 10
        MsgBox(Counter.ToString)
        '-- Enable the buttons
        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

    Private Sub Go()
        '-- Run this demo multiple times. Each time, add a zero to the number
        '   multiplying by 10. After a while you start to have problems.
        For i As Int32 = 1 To Iterations
            Counter += 1
        Next
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Iterations = CInt(ComboBox1.Text)
        '-- Disable the buttons
        Button1.Enabled = False
        Button2.Enabled = False
        '-- Initialize the counter
        Counter = 0
        '-- Create three new threads to run the GoSync subroutine, which is synchronized
        Dim T1 As New Thread(AddressOf GoSync)
        Dim T2 As New Thread(AddressOf GoSync)
        Dim T3 As New Thread(AddressOf GoSync)
        '-- Start the first thread and wait 100 ms
        T1.Start()
        Thread.Sleep(100)
        '-- Start the second thread and wait 100 ms
        T2.Start()
        Thread.Sleep(100)
        '-- Start the third thread
        T3.Start()
        '-- Wait for all the threads to finish
        T1.Join()
        T2.Join()
        T3.Join()
        '-- Show the counter. 
        '   In a perfect world, we expect an even multiple of 10
        MsgBox(Counter.ToString)
        '-- Enable the buttons
        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

    Private Sub GoSync()
        '-- This version uses SyncLock to synchronize the threads so that
        '   only one thread at a time can execute the code in the SyncLock block.
        '   It obviously takes longer to execute, but the results are accurate.
        For i As Int32 = 1 To Iterations
            SyncLock SyncObj
                Counter += 1
            End SyncLock
        Next
    End Sub

End Class
