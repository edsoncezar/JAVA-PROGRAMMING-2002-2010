This sample project shows how to create odd-shaped form using the
Region property of a .NET Control (from which a Form is derived)

Written by Carl Franklin
Franklins.Net Hands-On .NET Training
www.franklins.net
carl@franklins.net