Imports System.Net
Imports System.IO
Imports System.Threading
Imports System.ComponentModel.Design

Public Class Downloader
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Private ev As New AutoResetEvent(False)
    Private url As String
    Private fileName As String
    Private append As Boolean
    Private _cancel As Boolean

#Region " Event Handling Code "

    Public Event DownloadStatus(ByVal PercentComplete As Int32, ByVal BytesTransferred As Int32, ByVal TotalBytes As Int32)
    Private Delegate Sub DownloadStatusDelegate(ByVal PercentComplete As Int32, ByVal BytesTransferred As Int32, ByVal TotalBytes As Int32)
    Protected Overridable Sub OnDownloadStatus(ByVal PercentComplete As Int32, ByVal BytesTransferred As Int32, ByVal TotalBytes As Int32)
        RaiseEvent DownloadStatus(PercentComplete, BytesTransferred, TotalBytes)
    End Sub

#End Region

#Region " Property Handlers "

    '-- This is required to switch the context from the socket thread to the
    '   underlying calling container's thread when raising events from the socket's
    '   receive data thread. This code comes from my friend, Chris Sells! Check
    '   out his website at http://www.sellsbrothers.com and listen to him as a 
    '   guest on my show, .NET Rocks! at http://www.franklins.net/dotnetrocks

    Private _syncrhonizingObject As System.ComponentModel.ISynchronizeInvoke

    '-- This must be set to the container control (for example, Form1 in a Windows Forms app)
    Public Property SynchronizingObject() As System.ComponentModel.ISynchronizeInvoke
        Get
            If _syncrhonizingObject Is Nothing And Me.DesignMode Then
                Dim designer As IDesignerHost = CType(Me.GetService(GetType(IDesignerHost)), IDesignerHost)
                If Not (designer Is Nothing) Then
                    _syncrhonizingObject = CType(designer.RootComponent, System.ComponentModel.ISynchronizeInvoke)
                End If
            End If
            Return _syncrhonizingObject
        End Get
        Set(ByVal Value As System.ComponentModel.ISynchronizeInvoke)
            If Not Me.DesignMode Then
                If Not (_syncrhonizingObject Is Nothing) And Not (_syncrhonizingObject Is Value) Then
                    Throw New Exception("Property can not be set at run-time.")
                Else
                    _syncrhonizingObject = Value
                End If
            End If
        End Set
    End Property
#End Region

#Region " Public Methods "
    Public Sub Cancel()
        _cancel = True
    End Sub

    Public Sub Download(ByVal url As String, ByVal FileName As String, ByVal Append As Boolean, Optional ByVal Asyncrhonous As Boolean = True)
        Me.url = url
        Me.fileName = FileName
        Me.append = Append
        If Asyncrhonous = True Then
            Dim MyThread As New Thread(AddressOf _Download)
            MyThread.Start()
        Else
            _Download()
        End If
    End Sub
#End Region

#Region " Private Methods "
    Private Sub _Download()
        _cancel = False
        Try
            '-- The state class is a context around the file being downloaded
            Dim mystate As New HTTPDownloadState
            '-- Create a web request from the URL, method = GET
            Dim req As HttpWebRequest = CType(WebRequest.Create(url), HttpWebRequest)
            req.Method = "GET"
            '-- Get the response
            mystate.Response = CType(req.GetResponse, HttpWebResponse)
            Dim bytes As Int32
            If append = True Then
                If File.Exists(fileName) Then
                    bytes = CInt(New FileInfo(fileName).Length)
                    If bytes > 0 Then
                        mystate.Response.Close()
                        req = CType(WebRequest.Create(url), HttpWebRequest)
                        req.Method = "GET"
                        req.AddRange(bytes, CInt(mystate.Response.ContentLength) - 1)
                        mystate.Response = CType(req.GetResponse, HttpWebResponse)
                        '-- Create an output stream for the local file
                        mystate.OutputStream = New FileStream(fileName, FileMode.Append)
                        mystate.BytesRead = bytes
                    Else
                        '-- Create an output stream for the local file
                        mystate.OutputStream = New FileStream(fileName, FileMode.Create)
                    End If
                Else
                    '-- Create an output stream for the local file
                    mystate.OutputStream = New FileStream(fileName, FileMode.Create)
                End If
            Else
                '-- Create an output stream for the local file
                mystate.OutputStream = New FileStream(fileName, FileMode.Create)
            End If
            mystate.TotalBytes = bytes + CInt(mystate.Response.ContentLength)
            'ProgressBar1.Maximum = mystate.TotalBytes
            '-- Get a reference to the response stream (for downloading)
            mystate.InputStream = mystate.Response.GetResponseStream
            '-- Do an asynchronous read, with a maximum of mystate.data.length number
            '   of bytes read at one time. Call GotData when one buffer has been
            '   filled.
            mystate.InputStream.BeginRead(mystate.Data, 0, mystate.Data.Length, _
              AddressOf GotData, mystate)
            '-- Wait for ev.set, which we call when the last buffer has been received
            ev.WaitOne()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub GotData(ByVal ar As IAsyncResult)
        '-- Callback for BeginRead

        '-- Get the state object associated with this read
        Dim mystate As HTTPDownloadState = CType(ar.AsyncState, HTTPDownloadState)
        '-- Get the number of bytes read
        Dim read As Int32 = mystate.InputStream.EndRead(ar)
        If read > 0 Then
            '-- Write the data to the output stream
            mystate.OutputStream.Write(mystate.Data, 0, read)
            'mystate.OutputStream.Flush()
            mystate.BytesRead += read
        End If

        If _cancel = True Then
            '-- We're done. Close the output stream.
            mystate.OutputStream.Close()
            '-- Close the input stream if it's there, and the flag lets us
            If mystate.DontCloseInputStream = False Then
                If Not mystate.InputStream Is Nothing Then
                    mystate.InputStream.Close()
                End If
            End If
            '-- close the response if it's there
            If Not mystate.Response Is Nothing Then
                mystate.Response.Close()
            End If
            _cancel = False
            '-- Call Set 
            ev.Set()
            Exit Sub
        End If

        If mystate.BytesRead >= mystate.TotalBytes Then
            read = 0
        End If

        'Dim dlg As New SetBarValueDelegate(AddressOf SetBarValue)
        'Dim args() As Object = {mystate.BytesRead}
        'Me.Invoke(dlg, args)

        '-- Raise the downloadstatus event 
        If Me.SynchronizingObject Is Nothing Then
            OnDownloadStatus(mystate.PercentComplete, mystate.BytesRead, mystate.TotalBytes)
        Else
            Dim dlg As New DownloadStatusDelegate(AddressOf OnDownloadStatus)
            Dim args() As Object = {mystate.PercentComplete, mystate.BytesRead, mystate.TotalBytes}
            SynchronizingObject.Invoke(dlg, args)
        End If

        If read > 0 Then
            '-- begin reading another buffer
            mystate.InputStream.BeginRead(mystate.Data, 0, mystate.Data.Length, AddressOf GotData, mystate)
        Else
            '-- Zero bytes read. We're done. Close the output stream.
            mystate.OutputStream.Close()
            '-- Close the input stream if it's there, and the flag lets us
            If mystate.DontCloseInputStream = False Then
                If Not mystate.InputStream Is Nothing Then
                    mystate.InputStream.Close()
                End If
            End If
            '-- close the response if it's there
            If Not mystate.Response Is Nothing Then
                mystate.Response.Close()
            End If
            '-- Call Set 
            ev.Set()
        End If
    End Sub
#End Region

End Class

