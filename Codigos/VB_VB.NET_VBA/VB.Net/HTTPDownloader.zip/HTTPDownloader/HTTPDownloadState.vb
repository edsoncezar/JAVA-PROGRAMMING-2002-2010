Imports System.Net
Public Class HTTPDownloadState

    Private _bufferSize As Integer = 32767
    Public Property BufferSize() As Integer
        Get
            Return _bufferSize
        End Get
        Set(ByVal Value As Integer)
            _bufferSize = Value
            If Data.Length = 0 Then
                ReDim Preserve _data(_bufferSize - 1)
            End If
        End Set
    End Property

    '-- receive buffer
    Private _data() As Byte
    Public Property Data() As Byte()
        Get
            If _data Is Nothing Then
                ReDim Preserve _data(_bufferSize - 1)
            End If
            Return _data
        End Get
        Set(ByVal Value As Byte())
            Data = Value
        End Set
    End Property

    '-- output stream for file that gets written
    Private _outputstream As IO.FileStream
    Public Property OutputStream() As IO.FileStream
        Get
            Return _outputstream
        End Get
        Set(ByVal Value As IO.FileStream)
            _outputstream = Value
        End Set
    End Property

    '-- input stream for data being downloaded
    Private _inputstream As IO.Stream
    Public Property InputStream() As IO.Stream
        Get
            Return _inputstream
        End Get
        Set(ByVal Value As IO.Stream)
            _inputstream = Value
        End Set
    End Property

    '-- web response
    Private _response As HttpWebResponse
    Public Property Response() As HttpWebResponse
        Get
            Return _response
        End Get
        Set(ByVal Value As HttpWebResponse)
            _response = Value
        End Set
    End Property

    '-- flag for closing the input stream after receiving all data
    Private _dontCloseInputStream As Boolean
    Public Property DontCloseInputStream() As Boolean
        Get
            Return _dontCloseInputStream
        End Get
        Set(ByVal Value As Boolean)
            _dontCloseInputStream = Value
        End Set
    End Property

    Private _bytesRead As Integer
    Public Property BytesRead() As Integer
        Get
            Return _bytesRead
        End Get
        Set(ByVal Value As Integer)
            _bytesRead = Value
        End Set
    End Property

    Private _totalBytes As Integer
    Public Property TotalBytes() As Integer
        Get
            Return _totalBytes
        End Get
        Set(ByVal Value As Integer)
            _totalBytes = Value
        End Set
    End Property

    Public Function PercentComplete() As Int32
        If TotalBytes > 0 Then
            Return CInt((BytesRead * 100) \ TotalBytes)
        Else
            Return 0
        End If
    End Function

End Class