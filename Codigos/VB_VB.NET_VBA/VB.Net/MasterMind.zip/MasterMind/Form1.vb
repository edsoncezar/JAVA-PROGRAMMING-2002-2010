Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents pbCode As System.Windows.Forms.PictureBox
    Friend WithEvents btnHide As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnHide = New System.Windows.Forms.Button
        Me.pbCode = New System.Windows.Forms.PictureBox
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(16, 600)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(64, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Test"
        '
        'btnHide
        '
        Me.btnHide.BackColor = System.Drawing.SystemColors.Control
        Me.btnHide.Location = New System.Drawing.Point(8, 560)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(104, 23)
        Me.btnHide.TabIndex = 1
        Me.btnHide.Text = "Hide Code"
        '
        'pbCode
        '
        Me.pbCode.BackColor = System.Drawing.Color.Black
        Me.pbCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbCode.Location = New System.Drawing.Point(136, 544)
        Me.pbCode.Name = "pbCode"
        Me.pbCode.Size = New System.Drawing.Size(184, 48)
        Me.pbCode.TabIndex = 2
        Me.pbCode.TabStop = False
        Me.pbCode.Visible = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.BackColor = System.Drawing.Color.SaddleBrown
        Me.ClientSize = New System.Drawing.Size(328, 600)
        Me.Controls.Add(Me.pbCode)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "MasterMind"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private pegSize As Int32 = 32
    Private smPegSize As Int32 = (pegSize \ 2) - (pegSize \ 8)
    Private pegXSpace As Int32 = 8
    Private pegYSpace As Int32 = 20
    Private grGrid, grMem As Graphics
    Private imgGrid As Image

    Private BigGridCoords(9, 3) As Point
    Private SmallGridCoords(9, 3) As Point

    Private BigGridColors(9, 3) As PegColor
    Private SmallGridColors(9, 3) As SmallPegColor

    Private CodeCoords(3) As Point
    Private CodeColors(3) As PegColor

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitializeGrid(25, 25)
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Static Done As Boolean
        If Not Done Then
            Done = True
            imgGrid = New Bitmap(Me.Width, Me.Height)
            grGrid = Me.CreateGraphics
            grMem = Graphics.FromImage(imgGrid)
            grMem.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
            DrawGrid()
            Dim X, Y As Int32
            For X = 0 To 9
                For Y = 0 To 3
                    DrawColorHole(X, Y)
                    DrawSmallHole(X, Y)
                Next
            Next
            Dim Rect As Rectangle
            Dim i As Int32
            For i = 0 To 3
                Rect = New Rectangle(CodeCoords(i).X, CodeCoords(i).Y, pegSize, pegSize)
                grMem.DrawEllipse(Pens.Black, Rect)
            Next

            Refresh()
        Else
                grGrid.DrawImage(imgGrid, 0, 0)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '-- Test the grid

        DrawColorPeg(0, 0, PegColor.Red)
        DrawColorPeg(0, 1, PegColor.Green)
        DrawColorPeg(0, 2, PegColor.Black)
        DrawColorPeg(0, 3, PegColor.Yellow)

        DrawSmallPeg(0, 0, SmallPegColor.Black)
        DrawSmallPeg(0, 1, SmallPegColor.White)
        DrawSmallPeg(0, 2, SmallPegColor.White)
        DrawSmallPeg(0, 3, SmallPegColor.Black)

        DrawColorPeg(1, 0, PegColor.Blue)
        DrawColorPeg(1, 1, PegColor.Blue)
        DrawColorPeg(1, 2, PegColor.White)
        DrawColorPeg(1, 3, PegColor.Red)

        DrawSmallPeg(1, 0, SmallPegColor.White)
        DrawSmallPeg(1, 1, SmallPegColor.White)
        DrawSmallPeg(1, 2, SmallPegColor.White)
        DrawSmallPeg(1, 3, SmallPegColor.Black)

        DrawColorPeg(2, 0, PegColor.Green)
        DrawColorPeg(2, 1, PegColor.White)
        DrawColorPeg(2, 2, PegColor.Red)
        DrawColorPeg(2, 3, PegColor.Red)

        DrawSmallPeg(2, 0, SmallPegColor.Black)
        DrawSmallPeg(2, 1, SmallPegColor.Black)
        DrawSmallPeg(2, 2, SmallPegColor.White)
        DrawSmallPeg(2, 3, SmallPegColor.White)

        DrawColorPeg(3, 0, PegColor.Yellow)
        DrawColorPeg(3, 1, PegColor.Yellow)
        DrawColorPeg(3, 2, PegColor.Blue)
        DrawColorPeg(3, 3, PegColor.White)

        DrawSmallPeg(3, 0, SmallPegColor.Black)
        DrawSmallPeg(3, 1, SmallPegColor.Black)
        DrawSmallPeg(3, 2, SmallPegColor.White)
        DrawSmallPeg(3, 3, SmallPegColor.Black)

        DrawColorPeg(4, 0, PegColor.Black)
        DrawColorPeg(4, 1, PegColor.White)
        DrawColorPeg(4, 2, PegColor.White)
        DrawColorPeg(4, 3, PegColor.Black)

        DrawSmallPeg(4, 0, SmallPegColor.White)
        DrawSmallPeg(4, 1, SmallPegColor.White)
        DrawSmallPeg(4, 2, SmallPegColor.White)
        DrawSmallPeg(4, 3, SmallPegColor.White)

        DrawColorPeg(5, 0, PegColor.Blue)
        DrawColorPeg(5, 1, PegColor.Red)
        DrawColorPeg(5, 2, PegColor.Red)
        DrawColorPeg(5, 3, PegColor.Red)

        DrawSmallPeg(5, 0, SmallPegColor.Black)
        DrawSmallPeg(5, 1, SmallPegColor.Black)
        DrawSmallPeg(5, 2, SmallPegColor.Black)
        DrawSmallPeg(5, 3, SmallPegColor.Black)

        DrawColorPeg(6, 0, PegColor.Green)
        DrawColorPeg(6, 1, PegColor.Blue)
        DrawColorPeg(6, 2, PegColor.Green)
        DrawColorPeg(6, 3, PegColor.Red)

        DrawSmallPeg(6, 0, SmallPegColor.White)
        DrawSmallPeg(6, 1, SmallPegColor.White)
        DrawSmallPeg(6, 2, SmallPegColor.White)
        DrawSmallPeg(6, 3, SmallPegColor.White)

        DrawColorPeg(7, 0, PegColor.Green)
        DrawColorPeg(7, 1, PegColor.Yellow)
        DrawColorPeg(7, 2, PegColor.Yellow)
        DrawColorPeg(7, 3, PegColor.Green)

        DrawSmallPeg(7, 0, SmallPegColor.White)
        DrawSmallPeg(7, 1, SmallPegColor.Black)
        DrawSmallPeg(7, 2, SmallPegColor.White)
        DrawSmallPeg(7, 3, SmallPegColor.Black)

        DrawColorPeg(8, 0, PegColor.White)
        DrawColorPeg(8, 1, PegColor.Blue)
        DrawColorPeg(8, 2, PegColor.Red)
        DrawColorPeg(8, 3, PegColor.Yellow)

        DrawSmallPeg(8, 0, SmallPegColor.White)
        DrawSmallPeg(8, 1, SmallPegColor.White)
        DrawSmallPeg(8, 2, SmallPegColor.Black)
        DrawSmallPeg(8, 3, SmallPegColor.Black)

        DrawColorPeg(9, 0, PegColor.Green)
        DrawColorPeg(9, 1, PegColor.Blue)
        DrawColorPeg(9, 2, PegColor.Yellow)
        DrawColorPeg(9, 3, PegColor.White)

        DrawSmallPeg(9, 0, SmallPegColor.Black)
        DrawSmallPeg(9, 1, SmallPegColor.White)
        DrawSmallPeg(9, 2, SmallPegColor.Black)
        DrawSmallPeg(9, 3, SmallPegColor.Black)

    End Sub

    Private Sub InitializeGrid(ByVal X As Int32, ByVal Y As Int32)
        '-- Initializes the coordinates based on the top x and y
        BigGridCoords(0, 0) = New Point(X, Y)
        BigGridCoords(0, 1) = New Point(BigGridCoords(0, 0).X + pegSize + pegXSpace, BigGridCoords(0, 0).Y)
        BigGridCoords(0, 2) = New Point(BigGridCoords(0, 1).X + pegSize + pegXSpace, BigGridCoords(0, 0).Y)
        BigGridCoords(0, 3) = New Point(BigGridCoords(0, 2).X + pegSize + pegXSpace, BigGridCoords(0, 0).Y)

        BigGridCoords(1, 0) = New Point(BigGridCoords(0, 0).X, BigGridCoords(0, 0).Y + pegSize + pegYSpace)
        BigGridCoords(1, 1) = New Point(BigGridCoords(1, 0).X + pegSize + pegXSpace, BigGridCoords(1, 0).Y)
        BigGridCoords(1, 2) = New Point(BigGridCoords(1, 1).X + pegSize + pegXSpace, BigGridCoords(1, 0).Y)
        BigGridCoords(1, 3) = New Point(BigGridCoords(1, 2).X + pegSize + pegXSpace, BigGridCoords(1, 0).Y)

        BigGridCoords(2, 0) = New Point(BigGridCoords(1, 0).X, BigGridCoords(1, 0).Y + pegSize + pegYSpace)
        BigGridCoords(2, 1) = New Point(BigGridCoords(2, 0).X + pegSize + pegXSpace, BigGridCoords(2, 0).Y)
        BigGridCoords(2, 2) = New Point(BigGridCoords(2, 1).X + pegSize + pegXSpace, BigGridCoords(2, 0).Y)
        BigGridCoords(2, 3) = New Point(BigGridCoords(2, 2).X + pegSize + pegXSpace, BigGridCoords(2, 0).Y)

        BigGridCoords(3, 0) = New Point(BigGridCoords(2, 0).X, BigGridCoords(2, 0).Y + pegSize + pegYSpace)
        BigGridCoords(3, 1) = New Point(BigGridCoords(3, 0).X + pegSize + pegXSpace, BigGridCoords(3, 0).Y)
        BigGridCoords(3, 2) = New Point(BigGridCoords(3, 1).X + pegSize + pegXSpace, BigGridCoords(3, 0).Y)
        BigGridCoords(3, 3) = New Point(BigGridCoords(3, 2).X + pegSize + pegXSpace, BigGridCoords(3, 0).Y)

        BigGridCoords(4, 0) = New Point(BigGridCoords(3, 0).X, BigGridCoords(3, 0).Y + pegSize + pegYSpace)
        BigGridCoords(4, 1) = New Point(BigGridCoords(4, 0).X + pegSize + pegXSpace, BigGridCoords(4, 0).Y)
        BigGridCoords(4, 2) = New Point(BigGridCoords(4, 1).X + pegSize + pegXSpace, BigGridCoords(4, 0).Y)
        BigGridCoords(4, 3) = New Point(BigGridCoords(4, 2).X + pegSize + pegXSpace, BigGridCoords(4, 0).Y)

        BigGridCoords(5, 0) = New Point(BigGridCoords(4, 0).X, BigGridCoords(4, 0).Y + pegSize + pegYSpace)
        BigGridCoords(5, 1) = New Point(BigGridCoords(5, 0).X + pegSize + pegXSpace, BigGridCoords(5, 0).Y)
        BigGridCoords(5, 2) = New Point(BigGridCoords(5, 1).X + pegSize + pegXSpace, BigGridCoords(5, 0).Y)
        BigGridCoords(5, 3) = New Point(BigGridCoords(5, 2).X + pegSize + pegXSpace, BigGridCoords(5, 0).Y)

        BigGridCoords(6, 0) = New Point(BigGridCoords(5, 0).X, BigGridCoords(5, 0).Y + pegSize + pegYSpace)
        BigGridCoords(6, 1) = New Point(BigGridCoords(6, 0).X + pegSize + pegXSpace, BigGridCoords(6, 0).Y)
        BigGridCoords(6, 2) = New Point(BigGridCoords(6, 1).X + pegSize + pegXSpace, BigGridCoords(6, 0).Y)
        BigGridCoords(6, 3) = New Point(BigGridCoords(6, 2).X + pegSize + pegXSpace, BigGridCoords(6, 0).Y)

        BigGridCoords(7, 0) = New Point(BigGridCoords(6, 0).X, BigGridCoords(6, 0).Y + pegSize + pegYSpace)
        BigGridCoords(7, 1) = New Point(BigGridCoords(7, 0).X + pegSize + pegXSpace, BigGridCoords(7, 0).Y)
        BigGridCoords(7, 2) = New Point(BigGridCoords(7, 1).X + pegSize + pegXSpace, BigGridCoords(7, 0).Y)
        BigGridCoords(7, 3) = New Point(BigGridCoords(7, 2).X + pegSize + pegXSpace, BigGridCoords(7, 0).Y)

        BigGridCoords(8, 0) = New Point(BigGridCoords(7, 0).X, BigGridCoords(7, 0).Y + pegSize + pegYSpace)
        BigGridCoords(8, 1) = New Point(BigGridCoords(8, 0).X + pegSize + pegXSpace, BigGridCoords(8, 0).Y)
        BigGridCoords(8, 2) = New Point(BigGridCoords(8, 1).X + pegSize + pegXSpace, BigGridCoords(8, 0).Y)
        BigGridCoords(8, 3) = New Point(BigGridCoords(8, 2).X + pegSize + pegXSpace, BigGridCoords(8, 0).Y)

        BigGridCoords(9, 0) = New Point(BigGridCoords(8, 0).X, BigGridCoords(8, 0).Y + pegSize + pegYSpace)
        BigGridCoords(9, 1) = New Point(BigGridCoords(9, 0).X + pegSize + pegXSpace, BigGridCoords(9, 0).Y)
        BigGridCoords(9, 2) = New Point(BigGridCoords(9, 1).X + pegSize + pegXSpace, BigGridCoords(9, 0).Y)
        BigGridCoords(9, 3) = New Point(BigGridCoords(9, 2).X + pegSize + pegXSpace, BigGridCoords(9, 0).Y)

        SmallGridCoords(0, 0).X = BigGridCoords(0, 3).X + (pegSize * 2)
        SmallGridCoords(1, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(2, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(3, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(4, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(5, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(6, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(7, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(8, 0).X = SmallGridCoords(0, 0).X
        SmallGridCoords(9, 0).X = SmallGridCoords(0, 0).X

        SmallGridCoords(0, 0).Y = BigGridCoords(0, 0).Y
        SmallGridCoords(1, 0).Y = BigGridCoords(1, 0).Y
        SmallGridCoords(2, 0).Y = BigGridCoords(2, 0).Y
        SmallGridCoords(3, 0).Y = BigGridCoords(3, 0).Y
        SmallGridCoords(4, 0).Y = BigGridCoords(4, 0).Y
        SmallGridCoords(5, 0).Y = BigGridCoords(5, 0).Y
        SmallGridCoords(6, 0).Y = BigGridCoords(6, 0).Y
        SmallGridCoords(7, 0).Y = BigGridCoords(7, 0).Y
        SmallGridCoords(8, 0).Y = BigGridCoords(8, 0).Y
        SmallGridCoords(9, 0).Y = BigGridCoords(9, 0).Y

        SmallGridCoords(0, 1).X = SmallGridCoords(0, 0).X + (pegSize \ 2)
        SmallGridCoords(1, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(2, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(3, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(4, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(5, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(6, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(7, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(8, 1).X = SmallGridCoords(0, 1).X
        SmallGridCoords(9, 1).X = SmallGridCoords(0, 1).X

        SmallGridCoords(0, 1).Y = BigGridCoords(0, 0).Y
        SmallGridCoords(1, 1).Y = BigGridCoords(1, 0).Y
        SmallGridCoords(2, 1).Y = BigGridCoords(2, 0).Y
        SmallGridCoords(3, 1).Y = BigGridCoords(3, 0).Y
        SmallGridCoords(4, 1).Y = BigGridCoords(4, 0).Y
        SmallGridCoords(5, 1).Y = BigGridCoords(5, 0).Y
        SmallGridCoords(6, 1).Y = BigGridCoords(6, 0).Y
        SmallGridCoords(7, 1).Y = BigGridCoords(7, 0).Y
        SmallGridCoords(8, 1).Y = BigGridCoords(8, 0).Y
        SmallGridCoords(9, 1).Y = BigGridCoords(9, 0).Y

        SmallGridCoords(0, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(1, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(2, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(3, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(4, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(5, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(6, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(7, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(8, 2).X = SmallGridCoords(0, 0).X
        SmallGridCoords(9, 2).X = SmallGridCoords(0, 0).X

        SmallGridCoords(0, 2).Y = SmallGridCoords(0, 0).Y + (pegSize \ 2)
        SmallGridCoords(1, 2).Y = SmallGridCoords(1, 0).Y + (pegSize \ 2)
        SmallGridCoords(2, 2).Y = SmallGridCoords(2, 0).Y + (pegSize \ 2)
        SmallGridCoords(3, 2).Y = SmallGridCoords(3, 0).Y + (pegSize \ 2)
        SmallGridCoords(4, 2).Y = SmallGridCoords(4, 0).Y + (pegSize \ 2)
        SmallGridCoords(5, 2).Y = SmallGridCoords(5, 0).Y + (pegSize \ 2)
        SmallGridCoords(6, 2).Y = SmallGridCoords(6, 0).Y + (pegSize \ 2)
        SmallGridCoords(7, 2).Y = SmallGridCoords(7, 0).Y + (pegSize \ 2)
        SmallGridCoords(8, 2).Y = SmallGridCoords(8, 0).Y + (pegSize \ 2)
        SmallGridCoords(9, 2).Y = SmallGridCoords(9, 0).Y + (pegSize \ 2)

        SmallGridCoords(0, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(1, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(2, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(3, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(4, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(5, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(6, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(7, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(8, 3).X = SmallGridCoords(0, 1).X
        SmallGridCoords(9, 3).X = SmallGridCoords(0, 1).X

        SmallGridCoords(0, 3).Y = SmallGridCoords(0, 2).Y
        SmallGridCoords(1, 3).Y = SmallGridCoords(1, 2).Y
        SmallGridCoords(2, 3).Y = SmallGridCoords(2, 2).Y
        SmallGridCoords(3, 3).Y = SmallGridCoords(3, 2).Y
        SmallGridCoords(4, 3).Y = SmallGridCoords(4, 2).Y
        SmallGridCoords(5, 3).Y = SmallGridCoords(5, 2).Y
        SmallGridCoords(6, 3).Y = SmallGridCoords(6, 2).Y
        SmallGridCoords(7, 3).Y = SmallGridCoords(7, 2).Y
        SmallGridCoords(8, 3).Y = SmallGridCoords(8, 2).Y
        SmallGridCoords(9, 3).Y = SmallGridCoords(9, 2).Y

        Dim i, j As Int32

        For i = 0 To 3
            CodeCoords(i).Y = pbCode.Top + 10
        Next
        CodeCoords(0).X = pbCode.Left + 10
        CodeCoords(1).X = CodeCoords(0).X + 10 + pegSize
        CodeCoords(2).X = CodeCoords(1).X + 10 + pegSize
        CodeCoords(3).X = CodeCoords(2).X + 10 + pegSize

        For i = 0 To 9
            For j = 0 To 3
                SmallGridColors(i, j) = SmallPegColor.Null
            Next
        Next

    End Sub

    Private Sub HitTest(ByVal x As Int32, ByVal y As Int32, ByRef BigGrid As Boolean, ByRef SmallGrid As Boolean, ByRef Code As Boolean, ByRef GridX As Int32, ByRef GridY As Int32)
        Dim bounds1, bounds2, bgX, bgY, sgX, sgY, cx, cy As Int32
        For bounds2 = 0 To 9
            For bounds1 = 0 To 3
                bgX = BigGridCoords(bounds2, bounds1).X
                bgY = BigGridCoords(bounds2, bounds1).Y
                sgX = SmallGridCoords(bounds2, bounds1).X + (pegSize \ 8)
                sgY = SmallGridCoords(bounds2, bounds1).Y + (pegSize \ 8)

                If x > bgX Then
                    If x < bgX + pegSize Then
                        '-- Found an X hit
                        If y > bgY Then
                            If y < bgY + pegSize Then
                                '-- Got a hit!
                                BigGrid = True
                                GridX = bounds2
                                GridY = bounds1
                                Exit Sub
                            End If
                        End If
                    End If
                End If
                If x > sgX Then
                    If x < sgX + smPegSize Then
                        '-- Found an X hit 
                        If y > sgY Then
                            If y < sgY + smPegSize Then
                                SmallGrid = True
                                GridX = bounds2
                                GridY = bounds1
                            End If
                        End If
                    End If
                End If
            Next
        Next
        For bounds1 = 0 To 3
            cx = CodeCoords(bounds1).X
            cy = CodeCoords(bounds1).Y
            If x > cx Then
                If x < cx + pegSize Then
                    If y > cy Then
                        If y < cy + pegSize Then
                            Code = True
                            GridX = bounds1
                        End If
                    End If
                End If
            End If
        Next
    End Sub

    Private Sub DrawGrid()
        Dim Margin As Int32 = pegSize \ 2
        Dim clr As Color = Color.Peru
        Dim p As New Pen(clr)
        Dim i, w, h As Int32
        w = BigGridCoords(0, 3).X - BigGridCoords(0, 0).X + pegSize + (Margin * 2)
        h = pegSize + Margin
        For i = 0 To 9
            grMem.DrawRectangle(p, BigGridCoords(i, 0).X - Margin, BigGridCoords(i, 0).Y - (Margin \ 2), w, h)
        Next
    End Sub

    Private Sub DrawColorHole(ByVal GridX As Int32, ByVal GridY As Int32)
        Dim Rect As New Rectangle(BigGridCoords(GridX, GridY).X, BigGridCoords(GridX, GridY).Y, pegSize, pegSize)
        grMem.DrawEllipse(Pens.Black, Rect)
    End Sub

    Private Sub DrawSmallHole(ByVal GridX As Int32, ByVal GridY As Int32)
        Dim Rect As New Rectangle(SmallGridCoords(GridX, GridY).X + (pegSize \ 8), SmallGridCoords(GridX, GridY).Y + (pegSize \ 8), smPegSize, smPegSize)
        grMem.DrawEllipse(Pens.Black, Rect)
    End Sub

    Private Sub DrawCodePeg(ByVal GridX As Int32, ByVal Color As PegColor)
        Dim Rect As New Rectangle(CodeCoords(GridX).X, CodeCoords(GridX).Y, pegSize, pegSize)
        Dim clrLight, clrDark As Color

        Select Case Color
            Case PegColor.Black
                clrLight = Drawing.Color.FromArgb(100, 100, 100)
                clrDark = Drawing.Color.Black
            Case PegColor.Blue
                clrLight = Drawing.Color.DeepSkyBlue
                clrDark = Drawing.Color.DarkBlue
            Case PegColor.Green
                clrLight = Drawing.Color.Lime
                clrDark = Drawing.Color.DarkGreen
            Case PegColor.Red
                clrLight = Drawing.Color.Red
                clrDark = Drawing.Color.FromArgb(150, 0, 0)
            Case PegColor.White
                clrLight = Drawing.Color.White
                clrDark = Drawing.Color.LightGray
            Case PegColor.Yellow
                clrLight = Drawing.Color.Yellow
                clrDark = Drawing.Color.DarkOrange
        End Select
        CodeColors(GridX) = Color
        Dim br As New Drawing2D.LinearGradientBrush(Rect, clrLight, clrDark, Drawing2D.LinearGradientMode.ForwardDiagonal)
        grMem.FillEllipse(br, Rect)
        Invalidate(Rect)
    End Sub

    Private Sub DrawColorPeg(ByVal GridX As Int32, ByVal GridY As Int32, ByVal Color As PegColor)
        Dim Rect As New Rectangle(BigGridCoords(GridX, GridY).X, BigGridCoords(GridX, GridY).Y, pegSize, pegSize)
        Dim clrLight, clrDark As Color

        Select Case Color
            Case PegColor.Black
                clrLight = Drawing.Color.FromArgb(100, 100, 100)
                clrDark = Drawing.Color.Black
            Case PegColor.Blue
                clrLight = Drawing.Color.DeepSkyBlue
                clrDark = Drawing.Color.DarkBlue
            Case PegColor.Green
                clrLight = Drawing.Color.Lime
                clrDark = Drawing.Color.DarkGreen
            Case PegColor.Red
                clrLight = Drawing.Color.Red
                clrDark = Drawing.Color.FromArgb(150, 0, 0)
            Case PegColor.White
                clrLight = Drawing.Color.White
                clrDark = Drawing.Color.LightGray
            Case PegColor.Yellow
                clrLight = Drawing.Color.Yellow
                clrDark = Drawing.Color.DarkOrange
        End Select
        BigGridColors(GridX, GridY) = Color
        Dim br As New Drawing2D.LinearGradientBrush(Rect, clrLight, clrDark, Drawing2D.LinearGradientMode.ForwardDiagonal)
        grMem.FillEllipse(br, Rect)
        Invalidate(Rect)
    End Sub

    Private Sub DrawSmallPeg(ByVal GridX As Int32, ByVal GridY As Int32, ByVal Color As SmallPegColor)
        Dim Rect As New Rectangle(Me.SmallGridCoords(GridX, GridY).X + (pegSize \ 8), SmallGridCoords(GridX, GridY).Y + (pegSize \ 8), smPegSize, smPegSize)
        Select Case Color
            Case SmallPegColor.Black
                grMem.FillEllipse(Brushes.Black, Rect)
            Case SmallPegColor.White
                grMem.FillEllipse(Brushes.White, Rect)
            Case SmallPegColor.Null
                Dim br As New SolidBrush(Me.BackColor)
                grMem.FillEllipse(br, Rect)
                DrawSmallHole(GridX, GridY)
                br.Dispose()
        End Select
        SmallGridColors(GridX, GridY) = Color
        Invalidate(Rect)
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        Dim GridX, GridY As Int32
        Dim BigGrid, SmallGrid, Code As Boolean
        HitTest(e.X, e.Y, BigGrid, SmallGrid, Code, GridX, GridY)
        If BigGrid Then
            Select Case BigGridColors(GridX, GridY)
                Case PegColor.Null
                    DrawColorPeg(GridX, GridY, PegColor.Black)
                Case PegColor.Black
                    DrawColorPeg(GridX, GridY, PegColor.White)
                Case PegColor.White
                    DrawColorPeg(GridX, GridY, PegColor.Red)
                Case PegColor.Red
                    DrawColorPeg(GridX, GridY, PegColor.Green)
                Case PegColor.Green
                    DrawColorPeg(GridX, GridY, PegColor.Blue)
                Case PegColor.Blue
                    DrawColorPeg(GridX, GridY, PegColor.Yellow)
                Case PegColor.Yellow
                    DrawColorPeg(GridX, GridY, PegColor.Black)
            End Select

        ElseIf SmallGrid Then
            Select Case SmallGridColors(GridX, GridY)
                Case SmallPegColor.Black
                    DrawSmallPeg(GridX, GridY, SmallPegColor.White)
                Case SmallPegColor.Null
                    DrawSmallPeg(GridX, GridY, SmallPegColor.Black)
                Case SmallPegColor.White
                    DrawSmallPeg(GridX, GridY, SmallPegColor.Null)
            End Select
        ElseIf Code Then
            Select Case CodeColors(GridX)
                Case PegColor.Null
                    DrawCodePeg(GridX, PegColor.Black)
                Case PegColor.Black
                    DrawCodePeg(GridX, PegColor.White)
                Case PegColor.White
                    DrawCodePeg(GridX, PegColor.Red)
                Case PegColor.Red
                    DrawCodePeg(GridX, PegColor.Green)
                Case PegColor.Green
                    DrawCodePeg(GridX, PegColor.Blue)
                Case PegColor.Blue
                    DrawCodePeg(GridX, PegColor.Yellow)
                Case PegColor.Yellow
                    DrawCodePeg(GridX, PegColor.Black)
            End Select
        End If
    End Sub

    Private Sub btnHide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHide.Click
        Select Case btnHide.Text
            Case "Hide Code"
                btnHide.Text = "Show Code"
                pbCode.Visible = True
            Case "Show Code"
                btnHide.Text = "Hide Code"
                pbCode.Visible = False
        End Select
    End Sub
End Class

Public Enum PegColor
    Null
    Black
    White
    Red
    Yellow
    Blue
    Green
End Enum

Public Enum SmallPegColor
    Black
    White
    Null
End Enum