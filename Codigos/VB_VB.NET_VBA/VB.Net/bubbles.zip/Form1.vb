'--------------------------------------------------------------------------------
'
'   BUBBLES!
'   by Carl Franklin (carl@franklins.net)
'   v1.0 released Sunday, May 18, 2003
'   v1.1 released Monday, May 19, 2003
'       Fixed math bug calculating the note
'   v1.2 released Friday, May 23, 2003
'       Again fixed math bug... couldn't reproduce, but made code safer
'
'   This is a fun program for babies and toddlers that draws random
'   filled circles on the screen and plays notes via MIDI. You can
'   specify the instrument, channel, and patch number in the config
'   file. Please modify the source all you want to, but leave this 
'   text at the top. Original source is at http://www.franklins.net/bubbles.zip
'
'   Learn Intermediate and Advanced Visual Basic.NET hands-on from Carl Franklin!
'   Details at http://www.franklins.net
'
'--------------------------------------------------------------------------------
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Instrument1 As CarlsMIDITools.Instrument
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Instrument1 = New CarlsMIDITools.Instrument(Me.components)
        '
        'Instrument1
        '
        Me.Instrument1.Engaged = False
        Me.Instrument1.FilterAfterTouch = True
        Me.Instrument1.InputChannel = CType(0, Byte)
        Me.Instrument1.InputDeviceName = ""
        Me.Instrument1.NoteDuration = 0
        Me.Instrument1.OutputChannel = CType(0, Byte)
        Me.Instrument1.OutputDeviceName = ""
        Me.Instrument1.Transpose = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(424, 264)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"

    End Sub

#End Region

    Private gr As Graphics
    Private Rect As Rectangle
    '-- For generating random locations and colors
    Private Rnd As New Random
    '-- For calculating Pitch
    Private ScrHeight As Int32 = Screen.PrimaryScreen.WorkingArea.Height

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '-- Solid black screen
        Me.BackColor = Color.Black
        Me.WindowState = FormWindowState.Maximized

        Try
            With Instrument1
                '-- Read the instrument name from the config file
                '   Example: "Microsoft GS Wavetable SW Synth"
                .OutputDeviceName = DeviceName
                '-- Zero-based (0-15)
                .OutputChannel = OutputChannel
                '-- This opens the instrument for input and/or output
                .Engaged = True
                '-- Make sure we're at full volume
                .SetVolume(127)
                '-- Change the patch. 46 (GM Harp) is the default
                .ChangePatch(PatchNumber)
                '-- If you set this, the control sends a note-off after NoteDuration seconds
                .NoteDuration = 1
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        '-- Draw a random bubble at this coordinate
        DrawBubble(e.X, e.Y)
    End Sub

    Private Sub DrawBubble(ByVal x As Int32, ByVal y As Int32)
        If x < 0 Then x = 0
        If y < 0 Then y = 0
        '-- Red, Green, Blue, Width, Height
        Dim R, G, B, W, H As Int32
        '-- Create a graphics object if it doesn't exist
        If gr Is Nothing Then
            gr = Me.CreateGraphics
        End If
        '-- Get random color values
        R = Rnd.Next(0, 255)
        G = Rnd.Next(0, 255)
        B = Rnd.Next(0, 255)
        '-- Create a new brush from the random color values
        Dim C As Color = Color.FromArgb(R, G, B)
        Dim BR As New SolidBrush(C)
        '-- Get random bubble width
        W = Rnd.Next(1, 300)
        '-- Create a rectangle around the current mouse position
        Rect.X = x - (W \ 2)
        Rect.Y = y - (W \ 2)
        Rect.Width = W
        Rect.Height = W
        '-- Draw the filled "bubble"
        gr.FillEllipse(BR, Rect)
        '-- Get rid of the brush
        BR.Dispose()
        '-- Calculate and play the note from the y coordinate with a low velocity (32)
        Dim bigval As Long = y * 127
        Dim note As Int32 = 127 - (bigval \ (ScrHeight - 1))
        If note > 255 Then note = 255
        If note < 0 Then note = 0
        Dim bnote As Byte = CByte(note)
        Try
            Instrument1.PlayNote(bnote, 32)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        If e.Button = MouseButtons.Left Then
            Me.Refresh()        '-- Left button clears the screen
        ElseIf e.Button = MouseButtons.Right Then
            Application.Exit()  '-- Right button exits
        End If
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        '-- Draw a random bubble when a key is pressed
        Dim x, y As Int32
        x = Rnd.Next(0, Me.Width - 1)
        y = Rnd.Next(0, Me.Height - 1)
        DrawBubble(x, y)
    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        '-- Escape exits
        If e.KeyChar = Chr(27) Then
            Application.Exit()
        End If
    End Sub

    '-- Readonly properties that read from the config file
    Public ReadOnly Property DeviceName() As String
        Get
            Dim DN As String = Configuration.ConfigurationSettings.AppSettings.Get("DeviceName")
            If DN = "" Then
                '-- Return the first available output device.
                Return Instrument1.OutDeviceNames(0)
            Else
                Return DN
            End If
        End Get
    End Property

    Public ReadOnly Property OutputChannel() As Int32
        Get
            Return CInt(Configuration.ConfigurationSettings.AppSettings.Get("OutputChannel"))
        End Get
    End Property

    Public ReadOnly Property PatchNumber() As Int32
        Get
            Dim PN As Int32 = CInt(Configuration.ConfigurationSettings.AppSettings.Get("PatchNumber"))
            If PN = 0 Then
                Return 46   '-- General MIDI Harp
            Else
                Return PN
            End If
        End Get
    End Property

End Class
