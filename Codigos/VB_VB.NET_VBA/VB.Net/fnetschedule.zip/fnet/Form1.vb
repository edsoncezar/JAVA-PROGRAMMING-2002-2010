Imports System.Net
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnPrevious As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents pbLocation As System.Windows.Forms.PictureBox
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnPrevious = New System.Windows.Forms.Button
        Me.btnNext = New System.Windows.Forms.Button
        Me.btnQuit = New System.Windows.Forms.Button
        Me.lblInfo = New System.Windows.Forms.Label
        Me.pbLocation = New System.Windows.Forms.PictureBox
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(16, 8)
        Me.PictureBox1.Size = New System.Drawing.Size(208, 56)
        '
        'btnPrevious
        '
        Me.btnPrevious.Enabled = False
        Me.btnPrevious.Location = New System.Drawing.Point(16, 224)
        Me.btnPrevious.Size = New System.Drawing.Size(80, 24)
        Me.btnPrevious.Text = "Previous"
        '
        'btnNext
        '
        Me.btnNext.Enabled = False
        Me.btnNext.Location = New System.Drawing.Point(104, 224)
        Me.btnNext.Size = New System.Drawing.Size(56, 24)
        Me.btnNext.Text = "Next"
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(168, 224)
        Me.btnQuit.Size = New System.Drawing.Size(56, 24)
        Me.btnQuit.Text = "Quit"
        '
        'lblInfo
        '
        Me.lblInfo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblInfo.ForeColor = System.Drawing.Color.Lime
        Me.lblInfo.Location = New System.Drawing.Point(16, 72)
        Me.lblInfo.Size = New System.Drawing.Size(128, 136)
        '
        'pbLocation
        '
        Me.pbLocation.Location = New System.Drawing.Point(152, 72)
        Me.pbLocation.Size = New System.Drawing.Size(72, 72)
        Me.pbLocation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        '
        'Form1
        '
        Me.BackColor = System.Drawing.Color.Black
        Me.Controls.Add(Me.pbLocation)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.PictureBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Franklins.Net"

    End Sub

#End Region

    Dim dtSchedule As DataTable
    Dim CurIndex As Int32 = 0

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Cursor.Current = Cursors.WaitCursor
        Dim ws As New net.franklins.www.Schedule
        dtSchedule = ws.GetSchedule.Tables(0)
        If dtSchedule.Rows.Count > 0 Then
            ShowCurrent()
        End If
    End Sub

    Private Sub ShowCurrent()
        Cursor.Current = Cursors.WaitCursor
        lblInfo.Text = dtSchedule.Rows(CurIndex)("Class")
        LoadPictureFromURL(pbLocation, dtSchedule.Rows(CurIndex)("LocationGraphic"))
        If CurIndex = 0 Then
            btnPrevious.Enabled = False
        Else
            btnPrevious.Enabled = True
        End If
        If CurIndex < dtSchedule.Rows.Count - 1 Then
            btnNext.Enabled = True
        Else
            btnNext.Enabled = False
        End If
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        Application.Exit()
    End Sub

    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        If CurIndex > 0 Then
            CurIndex -= 1
            ShowCurrent()
        Else
            Beep()
        End If
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        If CurIndex < dtSchedule.Rows.Count - 1 Then
            CurIndex += 1
            ShowCurrent()
        Else
            Beep()
        End If
    End Sub

    Private Sub LoadPictureFromURL(ByVal pb As PictureBox, ByVal URL As String)
        Dim MyStream As Stream
        Try
            '-- Create request and response objects
            Dim Request As HttpWebRequest = CType(WebRequest.Create(URL), HttpWebRequest)
            Dim Response As HttpWebResponse = CType(Request.GetResponse(), HttpWebResponse)
            '-- Get the response back as a Stream
            MyStream = Response.GetResponseStream()
            '-- Create a bitmap from that Stream
            Dim Bm As Bitmap = New Bitmap(MyStream)
            '-- Set the bitmap into the Picturebox
            pb.Image = Bm
            '-- Close the stream
            MyStream.Close()
        Catch ex As Exception
            If Not MyStream Is Nothing Then
                MyStream.Close()
            End If
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
