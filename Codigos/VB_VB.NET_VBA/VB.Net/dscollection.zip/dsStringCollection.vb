Imports System.Data
Public Class dsStringCollection
    Private ds As DataSet
    Private dt As DataTable
    Private mvarZeroBased As Boolean

    Public Property ZeroBased() As Boolean
        Get
            Return mvarZeroBased
        End Get
        Set(ByVal Value As Boolean)
            mvarZeroBased = Value
        End Set
    End Property

    Public Function DataArray() As Array
        Return dt.Rows(0).ItemArray
    End Function

    Public Property DataTable() As DataTable
        Get
            Return dt
        End Get
        Set(ByVal Value As DataTable)
            dt = Value
        End Set
    End Property

    Public Property DataSet() As DataSet
        Get
            Return ds
        End Get
        Set(ByVal Value As DataSet)
            ds = Value
        End Set
    End Property

    Public ReadOnly Property Count() As Integer
        Get
            Return dt.Rows.Count
        End Get
    End Property

    Public Sub Add(ByVal Value As String)
        dt.Columns.Add("", GetType(String))
        If dt.Rows.Count = 0 Then
            Dim dr As DataRow
            Dim Values(0) As String
            Values(0) = Value
            dt.Rows.Add(Values)
        Else
            dt.Rows(0)(dt.Columns.Count - 1) = Value
        End If
    End Sub

    Public Sub Add(ByVal Value As String, ByVal Key As String)
        dt.Columns.Add(Key, GetType(String))
        If dt.Rows.Count = 0 Then
            Dim dr As DataRow
            Dim Values(0) As String
            Values(0) = Value
            dt.Rows.Add(Values)
        Else
            dt.Rows(0)(Key) = Value
        End If
    End Sub

    Public Sub Remove(ByVal Index As Integer)
        If mvarZeroBased = False Then
            Index = Index - 1
        End If
        Try
            dt.Columns.Remove(Index)
        Catch Ex As Exception
            Throw Ex
        End Try
    End Sub

    Public Sub Remove(ByVal Key As String)
        If dt.Columns.Contains(Key) = True Then
            Try
                dt.Columns.Remove(Key)
            Catch Ex As Exception
                Throw Ex
            End Try
        Else
            Throw New Exception("Key not found")
        End If
    End Sub

    Default Public Property Item(ByVal Index As Integer) As String
        Get
            If mvarZeroBased = False Then
                Index = Index - 1
            End If
            If dt.Columns.Count >= Index - 1 Then
                Try
                    Return dt.Rows(0)(Index)
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Item " & Index.ToString & " does not exist.")
            End If
        End Get
        Set(ByVal Value As String)
            If mvarZeroBased = False Then
                Index = Index - 1
            End If
            If dt.Columns.Count >= Index - 1 Then
                Try
                    dt.Rows(0)(Index) = Value
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Item " & Index.ToString & " does not exist.")
            End If
        End Set
    End Property

    Default Public Property Item(ByVal Key As String) As String
        Get
            Dim Index As Integer
            If dt.Columns.Contains(Key) Then
                Try
                    Return dt.Rows(0)(Key)
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Key '" & Key & "' does not exist.")
            End If
        End Get
        Set(ByVal Value As String)
            If dt.Columns.Contains(Key) Then
                Try
                    dt.Rows(0)(Key) = Value
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Key '" & Key & "' does not exist.")
            End If
        End Set
    End Property

    '-- Required for For/Each
    Public Function GetEnumerator() As System.Collections.IEnumerator
        Return dt.Rows(0).ItemArray.GetEnumerator
    End Function

    Public Sub New(ByVal AnyDataSet As DataSet, ByVal TableName As String)
        ds = AnyDataSet
        dt = ds.Tables("TableName")
    End Sub

    Public Sub New(ByVal ThisTable As DataTable)
        ds = New DataSet()
        dt = ThisTable
        ds.Tables.Add(dt)
    End Sub

    Public Sub New()
        ds = New DataSet()
        dt = ds.Tables.Add("default")
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
        dt = Nothing
        ds = Nothing
    End Sub
End Class
