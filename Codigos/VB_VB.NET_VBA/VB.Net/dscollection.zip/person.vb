Public Class person
    Private mvarFirstName As String
    Private mvarLastName As String
    Public Property FirstName() As String
        Get
            Return mvarFirstName
        End Get
        Set(ByVal Value As String)
            mvarFirstName = Value
        End Set
    End Property
    Public Property LastName() As String
        Get
            Return mvarLastName
        End Get
        Set(ByVal Value As String)
            mvarLastName = Value
        End Set
    End Property
End Class
