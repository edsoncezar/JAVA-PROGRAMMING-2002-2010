Imports System.Data
Public Class dsCollection
    '------------------------------------------------------------------
    '   dsCollection looks like a VB6 collection to the calling
    '   program, but underneath it uses a DataSet to store
    '   the collection data. You get the VB6 compatibility
    '   and convenience of the collection with the power of
    '   the .NET DataSet.
    '
    '   Follow these steps before using:
    '   
    '   1)  Do a search and replace on the word 'person'
    '       Change it to the class of object that this collection 
    '       will hold. 
    '
    '   2)  Change the word dsCollection above to a name that 
    '       makes sense for your application.
    '
    '   3)  Save as a new .vb file. Now you can re-use it.
    '
    '   You may use and redistribute this code as long as you do not
    '   charge money for it in any way, even as part of another 
    '   product.
    '
    '   Want to learn VB.Net hands-on with me? 
    '   Come to one of my VB.Net Master Classes and let me show you
    '   the way to .NET Nirvana
    '   Details at http://www.franklins.net/
    '
    '   Carl Franklin
    '   carl@franklins.net
    '
    '   Versions:
    '       6-29-01     1.0     Original offering.
    '------------------------------------------------------------------

    Private ds As DataSet
    Private dt As DataTable
    Private mvarZeroBased As Boolean

    Public Property ZeroBased() As Boolean
        Get
            Return mvarZeroBased
        End Get
        Set(ByVal Value As Boolean)
            mvarZeroBased = Value
        End Set
    End Property

    Public Function DataArray() As Array
        Return dt.Rows(0).ItemArray
    End Function

    Public Property DataTable() As DataTable
        Get
            Return dt
        End Get
        Set(ByVal Value As DataTable)
            dt = Value
        End Set
    End Property

    Public Property DataSet() As DataSet
        Get
            Return ds
        End Get
        Set(ByVal Value As DataSet)
            ds = Value
        End Set
    End Property

    Public ReadOnly Property Count() As Integer
        Get
            Return dt.Rows.Count
        End Get
    End Property

    Public Sub Add(ByVal Value As person)
        dt.Columns.Add("", GetType(person))
        If dt.Rows.Count = 0 Then
            Dim dr As DataRow
            Dim Values(0) As person
            Values(0) = Value
            dt.Rows.Add(Values)
        Else
            dt.Rows(0)(dt.Columns.Count - 1) = Value
        End If
    End Sub

    Public Sub Add(ByVal Value As person, ByVal Key As String)
        dt.Columns.Add(Key, GetType(person))
        If dt.Rows.Count = 0 Then
            Dim dr As DataRow
            Dim Values(0) As person
            Values(0) = Value
            dt.Rows.Add(Values)
        Else
            dt.Rows(0)(Key) = Value
        End If
    End Sub

    Public Sub Remove(ByVal Index As Integer)
        If mvarZeroBased = False Then
            Index = Index - 1
        End If
        Try
            dt.Columns.Remove(Index)
        Catch Ex As Exception
            Throw Ex
        End Try
    End Sub

    Public Sub Remove(ByVal Key As String)
        If dt.Columns.Contains(Key) = True Then
            Try
                dt.Columns.Remove(Key)
            Catch Ex As Exception
                Throw Ex
            End Try
        Else
            Throw New Exception("Key not found")
        End If
    End Sub

    Default Public Property Item(ByVal Index As Integer) As person
        Get
            If mvarZeroBased = False Then
                Index = Index - 1
            End If
            If dt.Columns.Count >= Index - 1 Then
                Try
                    Return dt.Rows(0)(Index)
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Item " & Index.ToString & " does not exist.")
            End If
        End Get
        Set(ByVal Value As person)
            If mvarZeroBased = False Then
                Index = Index - 1
            End If
            If dt.Columns.Count >= Index - 1 Then
                Try
                    dt.Rows(0)(Index) = Value
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Item " & Index.ToString & " does not exist.")
            End If
        End Set
    End Property

    Default Public Property Item(ByVal Key As String) As person
        Get
            Dim Index As Integer
            If dt.Columns.Contains(Key) Then
                Try
                    Return dt.Rows(0)(Key)
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Key '" & Key & "' does not exist.")
            End If
        End Get
        Set(ByVal Value As person)
            If dt.Columns.Contains(Key) Then
                Try
                    dt.Rows(0)(Key) = Value
                Catch Ex As Exception
                    Throw Ex
                End Try
            Else
                Throw New Exception("Key '" & Key & "' does not exist.")
            End If
        End Set
    End Property

    '-- Required for For/Each
    Public Function GetEnumerator() As System.Collections.IEnumerator
        Return dt.Rows(0).ItemArray.GetEnumerator
    End Function

    Public Sub New(ByVal AnyDataSet As DataSet, ByVal TableName As String)
        ds = AnyDataSet
        dt = ds.Tables("TableName")
    End Sub

    Public Sub New(ByVal ThisTable As DataTable)
        ds = New DataSet()
        dt = ThisTable
        ds.Tables.Add(dt)
    End Sub

    Public Sub New()
        ds = New DataSet()
        dt = ds.Tables.Add("default")
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
        dt = Nothing
        ds = Nothing
    End Sub
End Class
