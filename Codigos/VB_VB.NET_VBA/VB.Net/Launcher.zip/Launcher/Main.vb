Imports System.Net
Imports System.IO
Imports ICSharpCode.SharpZipLib
Module Main

    '-- To publish a Windows application using this tool, change the four varaiables below
    '   to reflect the files and directories, then create a setup program for Launcher.exe 
    '   but give it the name of your application, not the launcher. 


    '-- These four variables are the only thing you change to customize this app!

    '-- URL to the zip file containing the app
    Private ZipURL As String = "http://carl.franklins.net/testapp.zip"
    '-- Local zip file name to save it to
    Private LocalZipFile As String = Application.StartupPath & "\testapp.zip"
    '-- Local dir where the .exe will reside
    Private LocalExeDir As String = Application.StartupPath & "\testapp"
    '-- Local .exe filename
    Private LocalExeFile As String = LocalExeDir & "\testapp.exe"

    '----------------------------------------------------------------------------


    '-- This is used to synchronize the thread
    Private ev As New System.Threading.AutoResetEvent(False)

    Sub Main()

        Dim downloaded As Boolean = False
        '-- Do we not have ANY zip file locally?
        If File.Exists(LocalZipFile) = False Then
            Try
                '-- Download the zip file
                Download(ZipURL, LocalZipFile)
                downloaded = True
                '-- Save the last access date/time of the file
                SaveSetting(Application.ProductName, "Settings", "ZipLastModified", GetFileDateTime(ZipURL).ToString)
            Catch ex As Exception
                If MsgBox("There was a problem downloading the application. Would you like to see the error message returned by the downloader?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    MsgBox(ex.Message & vbCrLf & ex.StackTrace)
                    If ex.Message.IndexOf("(404) Not Found") > -1 Then
                        MsgBox("Basically, this means that you should try again later. If this problem persists, contact the software vendor")
                    End If
                End If
                Exit Sub
            End Try
        Else

            Try
                '-- We have a zip file. Look up the zip file date/time in the settings
                Dim last As DateTime = CType(GetSetting(Application.ProductName, "Settings", "ZipLastModified", DateTime.MinValue.ToString), DateTime)
                '-- get the file date/time of the file on the website
                Dim lastweb As DateTime = GetFileDateTime(ZipURL)
                '-- Is there a newer version on the website?
                If last < lastweb Then
                    If MsgBox("A new version is available. Would you like to download it?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        '-- Download the zip file
                        Download(ZipURL, LocalZipFile)
                        downloaded = True
                        '-- Save the last access date/time of the file
                        SaveSetting(Application.ProductName, "Settings", "ZipLastModified", GetFileDateTime(ZipURL).ToString)
                    End If
                End If
            Catch ex As Exception
                If MsgBox("There was a problem downloading the new version. Would you like to see the error message returned by the downloader?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    MsgBox(ex.Message & vbCrLf & ex.StackTrace)
                End If
                If MsgBox("Would you like to go ahead and use the version you already have installed?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                    Exit Sub
                Else
                    '-- Fall through - using the current version
                End If
            End Try
        End If

        '-- If we downloaded a new file, unzip it
        If downloaded Then
            '-- zFile represents the zip file
            Dim zfile As New Zip.ZipFile(LocalZipFile)
            '-- The enumerator is required to walk through the files
            Dim en As IEnumerator = zfile.GetEnumerator

            Try
                '-- Extract Directories first

                '-- Make sure the dir for the local .exe exists
                If Directory.Exists(LocalExeDir) = False Then
                    Directory.CreateDirectory(LocalExeDir)
                End If

                '-- Go through each entry (file or dir) in the zip file
                Do
                    '-- Did we read a new entry?
                    If en.MoveNext() Then
                        '-- Get the current entry
                        Dim entry As Zip.ZipEntry = CType(en.Current, Zip.ZipEntry)
                        '-- Is this entry a directory?
                        If entry.IsDirectory Then
                            '-- Create it
                            Directory.CreateDirectory(LocalExeDir & "\" & entry.Name)
                        End If
                    Else
                        '-- Done
                        Exit Do
                    End If
                Loop

                '-- Reset the enumerator, so we can start at the first entry again
                en.Reset()

                '-- The st Stream is used to read data from each file entry in the zip
                Dim st As Stream

                '-- Loop through each entry to extract files
                Do
                    If en.MoveNext() Then
                        '-- Get the current entry
                        Dim entry As Zip.ZipEntry = CType(en.Current, Zip.ZipEntry)
                        '-- Is this entry a file?
                        If Not entry.IsDirectory Then
                            '-- grab the input stream (file data in the zip file)
                            st = zfile.GetInputStream(entry)
                            '-- ExtractFileFromZip writes from the input stream asynchronously to the disk.
                            ExtractFileFromZip(st, LocalExeDir & "\" & entry.Name)
                        End If
                    Else
                        '-- Done
                        Exit Do
                    End If
                Loop
            Catch ex As Exception
                MsgBox("Error extracting zip data" & vbCrLf & ex.Message)
                Exit Sub
            Finally
                zfile.Close()
            End Try
        End If

        '-- Now that the files are in place, launch the executable
        Try
            Dim p As New Process
            With p.StartInfo
                .FileName = LocalExeFile
                .WorkingDirectory = LocalExeDir
                .WindowStyle = ProcessWindowStyle.Normal
            End With
            p.Start()
        Catch ex As Exception
            MsgBox("There was an error trying to launch the application. This is probably because some or all of the files required were not downloaded. Please try again later. If this problem persists, contact your software vendor.")
        End Try
    End Sub

    Public Sub Download(ByVal Url As String, ByVal FileName As String)
        Try
            '-- The state class is a context around the file being downloaded
            Dim mystate As New State
            '-- Create an output stream for the local file
            mystate.OutputStream = New FileStream(FileName, FileMode.Create)
            '-- Create a web request from the URL, method = GET
            Dim req As HttpWebRequest = CType(WebRequest.Create(Url), HttpWebRequest)
            req.Method = "GET"
            '-- Get the response
            mystate.Response = CType(req.GetResponse, HttpWebResponse)
            '-- Get a reference to the response stream (for downloading)
            mystate.InputStream = mystate.Response.GetResponseStream
            '-- Do an asynchronous read, with a maximum of mystate.data.length number
            '   of bytes read at one time. Call GotData when one buffer has been
            '   filled.
            mystate.InputStream.BeginRead(mystate.Data, 0, mystate.Data.Length, _
              AddressOf GotData, mystate)
            '-- Wait for ev.set, which we call when the last buffer has been received
            ev.WaitOne()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function GetFileDateTime(ByVal URL As String) As DateTime
        '-- This code gets a response, but does not download, opting 
        '   instead to read the last modified date/time on the file.
        Try
            '-- Create a web request from the URL, method = GET
            Dim req As HttpWebRequest = CType(WebRequest.Create(URL), HttpWebRequest)
            req.Method = "GET"
            '-- Get the response
            Dim resp As HttpWebResponse = CType(req.GetResponse, HttpWebResponse)
            '-- Get the last modified date/time
            Dim last As DateTime = resp.LastModified
            '-- close the response
            resp.Close()
            Return last
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Sub GotData(ByVal ar As IAsyncResult)
        '-- Callback for BeginRead

        '-- Get the state object associated with this read
        Dim mystate As State = CType(ar.AsyncState, State)
        '-- Get the number of bytes read
        Dim read As Int32 = mystate.InputStream.EndRead(ar)
        If read > 0 Then
            '-- Write the data to the output stream
            mystate.OutputStream.Write(mystate.Data, 0, read)
            '-- begin reading another buffer
            mystate.InputStream.BeginRead(mystate.Data, 0, mystate.Data.Length, AddressOf GotData, mystate)
        Else
            '-- Zero bytes read. We're done. Close the output stream.
            mystate.OutputStream.Close()
            '-- Close the input stream if it's there, and the flag lets us
            If mystate.DontCloseInputStream = False Then
                If Not mystate.InputStream Is Nothing Then
                    mystate.InputStream.Close()
                End If
            End If
            '-- close the response if it's there
            If Not mystate.Response Is Nothing Then
                mystate.Response.Close()
            End If
            '-- Call Set 
            ev.Set()
        End If
    End Sub

    Public Sub ExtractFileFromZip(ByVal Input As Stream, ByVal FileName As String)
        Try
            '-- The state class is a context around the file being downloaded
            Dim mystate As New State
            '-- This flag tells the code not to close the input stream when done with it.
            mystate.DontCloseInputStream = True
            '-- Create a stream for writing the file to disk
            mystate.OutputStream = New FileStream(FileName, FileMode.Create)
            '-- Save the 
            mystate.InputStream = Input
            mystate.InputStream.BeginRead(mystate.Data, 0, mystate.Data.Length, AddressOf GotData, mystate)
            ev.WaitOne()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

End Module

Public Class State
    '-- receive buffer
    Private _data(8191) As Byte
    Public Property Data() As Byte()
        Get
            Return _data
        End Get
        Set(ByVal Value As Byte())
            Data = Value
        End Set
    End Property

    '-- output stream for file that gets written
    Private _outputstream As IO.FileStream
    Public Property OutputStream() As IO.FileStream
        Get
            Return _outputstream
        End Get
        Set(ByVal Value As IO.FileStream)
            _outputstream = Value
        End Set
    End Property

    '-- input stream for data being downloaded
    Private _inputstream As IO.Stream
    Public Property InputStream() As IO.Stream
        Get
            Return _inputstream
        End Get
        Set(ByVal Value As IO.Stream)
            _inputstream = Value
        End Set
    End Property

    '-- web response
    Private _response As HttpWebResponse
    Public Property Response() As HttpWebResponse
        Get
            Return _response
        End Get
        Set(ByVal Value As HttpWebResponse)
            _response = Value
        End Set
    End Property

    '-- flag for closing the input stream after receiving all data
    Private _dontCloseInputStream As Boolean
    Public Property DontCloseInputStream() As Boolean
        Get
            Return _dontCloseInputStream
        End Get
        Set(ByVal Value As Boolean)
            _dontCloseInputStream = Value
        End Set
    End Property

End Class