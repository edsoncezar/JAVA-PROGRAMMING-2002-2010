Take the __VIEWSTATE data out of the browser and persist it on 
the server.

Thanks to Dino Esposito for showing me how to do this in his 
article for MSDN Magazine at the following URL:

http://msdn.microsoft.com/msdnmag/issues/03/02/CuttingEdge/

I translated the code into VB.NET and modified it to use 
Session variables instead of writing to files on disk.

---------------------------------------------------------------

To use this technology:

In your ASP.NET project, add a reference to my ServerViewState.dll

Change your Inherits statement on your webform pages from:

	Inherits System.Web.UI.Page
	
to

	Inherits ServerViewState.ServerViewStatePage
	
That's it!

Enjoy this code, and please send me email if you have made 
modifications or have enhanced this in any way!

Carl Franklin
carl@franklins.net

