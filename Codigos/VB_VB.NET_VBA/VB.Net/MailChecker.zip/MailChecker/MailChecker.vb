Imports System.Net
Imports System.Net.Sockets
Public Class MailChecker
    Private Sock As Socket

    Public Function CheckEmail(ByVal Email As String, ByVal MyDnsServer As String) As String
        '-- Returns OK if the email exists, otherwise returns an error message
        Dim Domain As String
        Dim MailServer As String
        Dim Recv As String
        Dim Msg As String

        Dim dnsChecker As New DNSObjects.DNSQuery()
        Dim AtPos As Int32 = Email.IndexOf("@")

        dnsChecker.DNSServer = MyDnsServer
        If AtPos > 0 Then
            Domain = Email.Substring(AtPos + 1)
            If dnsChecker.GetMXRecords(Domain) = True Then
                MailServer = dnsChecker(0)
                If MailServer.Length > 0 Then
                    Try
                        Dim ep As EndPoint = New IPEndPoint(Dns.Resolve(MailServer).AddressList(0), 25)
                        Sock = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                        Sock.Connect(ep)
                        Recv = GetReceivedData()
                        If Recv.StartsWith("220") Then
                            Send("HELO emailchecker.com" & vbCrLf)
                            Recv = GetReceivedData()
                            If Recv.StartsWith("250") Then
                                Send("MAIL FROM: checker@emailchecker.com" & vbCrLf)
                                Recv = GetReceivedData()
                                If Recv.StartsWith("250") Then
                                    Send("RCPT TO: " & Email & vbCrLf)
                                    Recv = GetReceivedData()
                                    If Recv.StartsWith("250") Then
                                        Msg = "OK"
                                    Else
                                        Msg = "BAD Email Address not verified"
                                    End If
                                Else
                                    Msg = "ERR MAIL FROM: checker@emailchecker.com returned the following message: " & vbCrLf & Recv
                                End If
                            Else
                                Msg = "ERR HELO emailchecker.com returned the following message: " & vbCrLf & Recv
                            End If
                        End If
                        Send("QUIT" & vbCrLf)
                        GetReceivedData()
                        Sock.Shutdown(SocketShutdown.Both)
                        Sock.Close()
                    Catch ex As Exception
                        Return "ERR Socket Exception" & vbCrLf & ex.Message
                    End Try
                Else
                    Msg = "ERR No Mail Server found"
                End If
            Else
                Msg = "ERR Could not query DNS Server"
            End If
        Else
            Msg = "ERR Bad Email Address Format. No @ found."
        End If
        Return Msg

    End Function

    Private Sub Send(ByVal Data As String)
        Sock.Send(String2bArray(Data), Data.Length, SocketFlags.None)
    End Sub

    Private Function GetReceivedData() As String
        '-- 15 second timeout.
        Dim ExitTime As DateTime = DateAdd(DateInterval.Second, 15, Now)
        Do Until Sock.Poll(100, SelectMode.SelectRead) = True
            System.Threading.Thread.Sleep(1)
            If Now > ExitTime Then
                Return ""
            End If
        Loop
        Dim NumBytes As Int32 = Sock.Available
        If NumBytes > 0 Then
            Dim buffer(NumBytes - 1) As Byte
            Dim Received As Int32 = Sock.Receive(buffer)
            If Received > 0 Then
                Return bArray2String(buffer)
            End If
        End If
    End Function

    Private Function String2bArray(ByVal Data As String) As Byte()
        Return New System.Text.ASCIIEncoding().GetBytes(Data)
    End Function

    Private Function bArray2String(ByVal bytes() As Byte) As String
        Return New System.Text.ASCIIEncoding().GetString(bytes)
    End Function

End Class
