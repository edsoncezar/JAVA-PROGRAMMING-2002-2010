<Serializable()> Public Class Instrument
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            Me.Close()
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

#End Region

#Region " Private Declarations and Events "

    '-- Returns True if one or more MIDI ports are open
    Private _Engaged As Boolean = False

    '-- Device numbers used internally
    Private _OutputDeviceID As Int32 = -1
    Private _InputDeviceID As Int32 = -1

    '-- MIDI Input and Output port handles returned by Windows
    Private hMidiOUT As Integer
    Private hMidiIN As Integer

    '-- This tool has an automatic note shutoff feature. When you set the 
    '   NoteDuration property, you can just call PlayNote and the notes will
    '   be cut off (NOTE_OFF sent) after NoteDuration number of seconds
    Private notesToTurnOff As New ArrayList
    Public Structure NotesOff
        Public Note As Byte
        Public ShutoffTime As DateTime
    End Structure

    '-- Receive event happens on all MIDI data when there is no output device open
    Public Event Receive(ByRef Channel As Byte, ByRef Status As Byte, ByRef Data1 As Byte, ByRef Data2 As Byte, ByRef Data3 As Byte)
    '-- NoteOn event happens on Note On commands when there is no output device open
    Public Event NoteOn(ByRef Channel As Byte, ByRef Note As Byte, ByRef Velocity As Byte, ByRef Cancel As Boolean)
    '-- NoteOff event happens on Note Off commands when there is no output device open
    Public Event NoteOff(ByRef Channel As Byte, ByRef Note As Byte, ByRef Velocity As Byte, ByRef Cancel As Boolean)

#End Region

#Region " Open, Close, and MIDI Exception "

    '-- This delegate is used for the MIDI callback function
    Private dlgMIDIIn As New MidiDelegate(AddressOf MidiInProc)

    '-- This is a private function to open and close a MIDI Input port. 
    Private Function OpenMIDIInPort(ByRef DeviceID As Integer, ByVal Open As Boolean) As Int32
        Dim midiError As Integer
        If Open = True Then
            '-- This call opens the MIDI port using a callback function (MidiInProc)
            midiError = midiInOpen(hMidiIN, DeviceID, dlgMIDIIn, 0, CALLBACK_FUNCTION)
            If midiError <> MMSYSERR_NOERROR Then
                ThrowMidiException("midiIN_Open", midiError)
            Else
                midiError = midiInStart(hMidiIN)
                If midiError <> MMSYSERR_NOERROR Then
                    ThrowMidiException("midiIN_Start", midiError)
                End If
            End If
        Else
            If hMidiIN <> 0 Then
                midiError = midiInStop(hMidiIN)
                If midiError <> MMSYSERR_NOERROR Then
                    ThrowMidiException("midiIN_Start", midiError)
                Else
                    midiError = midiInClose(hMidiIN)
                    If midiError <> MMSYSERR_NOERROR Then
                        ThrowMidiException("midiIN_Close", midiError)
                    Else
                        hMidiIN = 0
                    End If
                End If
            End If
        End If
        Return hMidiIN
    End Function

    '-- This function opens a MIDI Output port. No callback is needed
    Private Function OpenMIDIOutPort(ByRef DeviceID As Integer, ByVal Open As Boolean) As Int32
        Dim midiError As Integer
        If Open = True Then
            midiError = midiOutOpen(hMidiOUT, DeviceID, VariantType.Null, 0, CALLBACK_NULL)
            If midiError <> MMSYSERR_NOERROR Then
                ThrowMidiException("midiOUT_Open", midiError)
            End If
        Else
            If hMidiOUT <> 0 Then
                midiError = midiOutClose(hMidiOUT)
                hMidiOUT = 0
                If midiError <> MMSYSERR_NOERROR Then
                    ThrowMidiException("midiOUT_Close", midiError)
                End If
            End If
        End If
        Return hMidiOUT
    End Function

    '-- Code to get the last MIDI message and throw as an exception
    Private Sub ThrowMidiException(ByRef InFunct As String, ByRef MMErr As Int32)
        Dim Msg As String = Space(255)
        If InStr(1, InFunct, "out", CompareMethod.Text) = 0 Then
            midiInGetErrorText(MMErr, Msg, 255)
        Else
            midiOutGetErrorText(MMErr, Msg, 255)
        End If
        Msg = InFunct & vbCrLf & Msg & vbCrLf
        Select Case MMErr
            Case MMSYSERR_NOERROR : Msg = Msg & "no error"
            Case MMSYSERR_ERROR : Msg = Msg & "unspecified error"
            Case MMSYSERR_BADDEVICEID : Msg = Msg & "device ID out of range"
            Case MMSYSERR_NOTENABLED : Msg = Msg & "driver failed enable"
            Case MMSYSERR_ALLOCATED : Msg = Msg & "device already allocated"
            Case MMSYSERR_INVALHANDLE : Msg = Msg & "device handle is invalid"
            Case MMSYSERR_NODRIVER : Msg = Msg & "no device driver present"
            Case MMSYSERR_NOMEM : Msg = Msg & "memory allocation error"
            Case MMSYSERR_NOTSUPPORTED : Msg = Msg & "function isn't supported"
            Case MMSYSERR_BADERRNUM : Msg = Msg & "error value out of range"
            Case MMSYSERR_INVALFLAG : Msg = Msg & "invalid flag passed"
            Case MMSYSERR_INVALPARAM : Msg = Msg & "invalid parameter passed"
            Case MMSYSERR_HANDLEBUSY : Msg = Msg & "handle being used simultaneously on another thread (eg callback)"
            Case MMSYSERR_INVALIDALIAS : Msg = Msg & "Specified alias not found in WIN.INI"
            Case MMSYSERR_LASTERROR : Msg = Msg & "last error in range"
        End Select
        Throw New Exception(Msg)
    End Sub

#End Region

#Region " Callbacks and Finalizer "

    '-- This is the Input proc that gets called when MIDI Data is received from the
    '   input device.
    Protected Sub MidiInProc(ByVal MidiInHandle As Int32, ByVal NewMsg As Int32, ByVal Instance As Int32, ByVal wParam As Int32, ByVal lParam As Int32)
        Dim chan As Byte
        Dim Msg As Byte
        Dim Status As Byte
        Dim Data1 As Byte
        Dim Data2 As Byte
        Dim Data3 As Byte
        Dim MidiStatus As Integer
        Dim Cancel As Boolean

        '-- We're only interested in MIDI Data messages
        If NewMsg = MM_MIM_DATA Then
            '-- Parse the data into a message byte and three data bytes
            SplitInt32(wParam, Msg, Data1, Data2, Data3)
            '-- The message byte is a combination of the channel and a Status byte. Parse
            SplitByte(Msg, chan, Status)

            Trace.WriteLine(" In: " & chan.ToString & " " & Status.ToString & " " & Data1.ToString & " " & Data2.ToString & " " & Data3.ToString)

            '-- Is this coming in on our Input Channel?
            If chan = _InputChannel Then

                '-- What MIDI Command was sent?
                Select Case Status
                    Case NOTE_ON, NOTE_OFF
                        '-- Transpose the note
                        Dim DTest As Int32 = CInt(Data1) + Transpose
                        If DTest < 0 Then
                            DTest = 0
                        ElseIf DTest > 127 Then
                            DTest = 127
                        End If
                        Data1 = GetByte(DTest)
                        '-- No output device?
                        If hMidiOUT = 0 Then
                            '-- Fire the appropriate event
                            If Status = NOTE_ON Then
                                RaiseEvent NoteOn(chan, Data1, Data2, Cancel)
                            ElseIf Status = NOTE_OFF Then
                                RaiseEvent NoteOff(chan, Data1, Data2, Cancel)
                            End If
                        Else
                            '-- Change the channel to the output channel
                            chan = _OutputChannel
                        End If
                    Case CHANNEL_PRESSURE '-- Channel Pressure
                        If FilterAfterTouch = True Then
                            '-- Cancel this data
                            Cancel = True
                        ElseIf hMidiOUT = 0 Then
                            '-- No output device. Fire the Receive event
                            RaiseEvent Receive(chan, Status, Data1, Data2, Data3)
                        Else
                            '-- Change the channel to the output channel
                            chan = _OutputChannel
                        End If
                    Case Else
                        If hMidiOUT = 0 Then
                            '-- No output device. Fire the Receive event
                            RaiseEvent Receive(chan, Status, Data1, Data2, Data3)
                        Else
                            '-- Change the channel to the output channel
                            chan = _OutputChannel
                        End If
                End Select
            End If

            '-- Prepare the message 
            NewMsg = StuffByte(Status, chan)
            lParam = StuffInt32(CByte(NewMsg), Data1, Data2, Data3)

            '-- The programmer can set Cancel to true to cancel this note.
            If Cancel = False Then
                If hMidiOUT <> 0 Then
                    '-- We have an output device!
                    Trace.WriteLine("Out: " & chan.ToString & " " & Status.ToString & " " & Data1.ToString & " " & Data2.ToString & " " & Data3.ToString & " lParam=" & lParam.ToString)
                    '-- Send the MIDI data out the output device
                    midiOutShortMsg(hMidiOUT, lParam)
                End If
            End If
        End If

    End Sub

    '-- This is called by the thread to shut off a note after it has played.
    '   Only called when NoteDuration is set to non-zero
    Protected Sub ShutoffNoteCallback()
        Dim no As NotesOff
        Dim there As Boolean
        Dim Msg As Byte
        Dim MidiMsg As Int32

        Do Until _Engaged = False
            SyncLock notesToTurnOff
                If notesToTurnOff.Count > 0 Then
                    no = CType(notesToTurnOff(0), NotesOff)
                    there = True
                Else
                    there = False
                End If
            End SyncLock

            If there Then
                Do Until Now >= no.ShutoffTime
                    Threading.Thread.Sleep(1)
                    If _Engaged = False Then
                        notesToTurnOff.Clear()
                        ev.Set()
                        Exit Sub
                    End If
                Loop
                Msg = StuffByte(GetByte(MIDIStatusMessages.NoteOff), _OutputChannel)
                MidiMsg = StuffInt32(Msg, no.Note, 64, 0)
                Try
                    midiOutShortMsg(hMidiOUT, MidiMsg)
                Catch ex As Exception
                    Exit Do
                End Try
                SyncLock notesToTurnOff
                    notesToTurnOff.RemoveAt(0)
                End SyncLock
            End If
            Threading.Thread.Sleep(1)
        Loop
        notesToTurnOff.Clear()
        ev.Set()
    End Sub

    Protected Overrides Sub Finalize()
        '-- This is required so that the delegate is not garbage collected
        GC.KeepAlive(dlgMIDIIn)
        MyBase.Finalize()
    End Sub

#End Region

#Region " Numeric Conversion Utilities "

    Public Function StuffByte(ByVal nib1 As Byte, ByVal nib2 As Byte) As Byte
        '-- Stuffs two 4-bit values into a byte
        Dim _16 As Byte = 16
        Return (nib1 * _16) + nib2
    End Function

    Public Sub SplitByte(ByVal OneByte As Byte, ByRef nib1 As Byte, ByRef nib2 As Byte)
        '-- Splits a byte into two 4-bit values
        Dim _15 As Byte = 15
        Dim _16 As Byte = 16

        nib1 = OneByte And _15
        nib2 = OneByte \ _16
    End Sub

    Public Function StuffInt32(ByVal B1 As Byte, ByVal B2 As Byte, ByVal B3 As Byte, ByVal B4 As Byte) As Int32
        '-- Stuffs four bytes into an Int32
        Dim ret As Integer
        Dim b() As Byte = {B1, B2, B3, B4}
        ret = BitConverter.ToInt32(b, 0)
        Return ret
    End Function

    Public Sub SplitInt32(ByVal Data As Integer, ByRef B1 As Byte, ByRef B2 As Byte, ByRef B3 As Byte, ByRef B4 As Byte)
        '-- Splits an Int32 into four bytes
        Dim b() As Byte = BitConverter.GetBytes(Data)
        B1 = b(0)
        B2 = b(1)
        B3 = b(2)
        B4 = b(3)
    End Sub

#End Region

#Region " Public Methods "

    '-- Return an InstrumentData object, containing only the 
    '   property settings of this instrument
    Public Function GetSettings() As InstrumentData
        Dim Data As New InstrumentData
        With Data
            .FilterAftertouch = Me.FilterAfterTouch
            .InputChannel = Me.InputChannel
            .InputDeviceName = Me.InputDeviceName
            .LocalControl = Me.LocalControl
            .NoteDuration = Me.NoteDuration
            .OutputChannel = Me.OutputChannel
            .OutputDeviceName = Me.OutputDeviceName
            .PatchNumber = Me.PatchNumber
            .SendPatchChangeOnOpen = Me.SendPatchChangeOnOpen
            .Transpose = Me.Transpose
            .Volume = Me.Volume
        End With
        Return Data
    End Function

    '-- Applies the settings from an InstrumentData object and
    '   opens the MIDI port
    Public Sub SetSettings(ByVal Instrument As InstrumentData)
        Dim Open As Boolean = _Engaged
        Close()
        With Instrument
            Me.FilterAfterTouch = .FilterAftertouch
            Me.InputChannel = .InputChannel
            Me.InputDeviceName = .InputDeviceName
            Me.LocalControl = .LocalControl
            Me.NoteDuration = .NoteDuration
            Me.OutputChannel = .OutputChannel
            Me.OutputDeviceName = .OutputDeviceName
            Me.PatchNumber = .PatchNumber
            Me.Transpose = .Transpose
            Me.SendPatchChangeOnOpen = .SendPatchChangeOnOpen
            Me.Volume = .Volume
        End With
        If Open = True Then
            Try
                Me.Open()
            Catch ex As Exception
                Throw ex
            End Try
        End If
    End Sub

    '-- Open both input and output devices
    Public Sub Open()
        If _OutputDeviceID = -1 And _InputDeviceID = -1 Then
            Throw New Exception("You must specify an Input Device, Output Device, or both")
        End If

        '-- Close the instrument if its already open
        Try
            If _Engaged = True Then
                Me.Close()
            End If
        Catch ex As Exception
            Throw ex
        End Try

        '-- Open the new port
        Try
            '-- Only do this if we're not already engaged
            If _Engaged = False Then
                '-- Input Device
                If _InputDeviceID <> -1 Then
                    hMidiIN = OpenMIDIInPort(_InputDeviceID, True)
                End If
                '-- Output Device
                If _OutputDeviceID <> -1 Then
                    hMidiOUT = OpenMIDIOutPort(_OutputDeviceID, True)
                End If
                '-- Engage
                _Engaged = True
                '-- Apply properties
                LocalControl = _LocalControl
                If _sendPatchChangeOnOpen = True Then
                    PatchNumber = _PatchNumber
                End If
                Volume = _Volume
                '-- Write to trace log
                Trace.WriteLine("------------------------------------")
                Trace.WriteLine("Device Open at " & Now.ToString)
                Trace.Indent()
            End If
        Catch ex As Exception
            Throw New Exception("Error opening MIDI port" & vbCrLf & ex.Message, ex)
        End Try
    End Sub

    '-- Close both input and output devices
    Public Sub Close()
        Try
            If _Engaged = True Then
                '-- Send all notes off
                AllNotesOff()
                '-- Let the NoteDuration thread finish
                If _NoteDuration > 0 Then
                    ev.WaitOne()
                End If
                '-- Close the input device
                If hMidiIN <> 0 Then
                    hMidiIN = OpenMIDIInPort(_InputDeviceID, False)
                End If
                '-- Close the output device
                If hMidiOUT <> 0 Then
                    hMidiOUT = OpenMIDIOutPort(_OutputDeviceID, False)
                End If
                '-- Set Engaged to False
                _Engaged = False

                Trace.Unindent()
                Trace.WriteLine("Device Closed at " & Now.ToString)
                Trace.WriteLine("------------------------------------")
            End If
        Catch ex As Exception
            Throw New Exception("Error closing MIDI Port" & vbCrLf & ex.Message, ex)
        End Try
    End Sub

    '-- Sends MIDI Data
    Public Sub Send(ByVal Channel As Byte, ByVal Status As Byte, Optional ByVal Data1 As Byte = 0, Optional ByVal Data2 As Byte = 0, Optional ByVal Data3 As Byte = 0)
        Dim MidiMsg As Integer
        Dim CmdAndChannel As Byte
        CmdAndChannel = StuffByte(Status, Channel)
        MidiMsg = StuffInt32(CmdAndChannel, Data1, Data2, Data3)
        midiOutShortMsg(hMidiOUT, MidiMsg)
    End Sub

    '-- Send MIDI Data by specifying a message from an Enumeration
    Public Sub SendMessage(ByVal Msg As MIDIStatusMessages, Optional ByRef Data1 As Byte = 0, Optional ByVal Data2 As Byte = 0, Optional ByVal Data3 As Byte = 0)
        Dim MidiMsg As Integer
        Dim CmdAndChannel As Byte
        CmdAndChannel = StuffByte(GetByte(Msg), OutputChannel)
        MidiMsg = StuffInt32(CmdAndChannel, Data1, Data2, Data3)
        midiOutShortMsg(hMidiOUT, MidiMsg)
    End Sub

    '-- Send a controller change by using an Enumeration
    Public Sub SendControllerChange(ByVal Controller As MIDIControllers, ByRef Data1 As Byte, Optional ByVal Data2 As Byte = 0)
        Dim MidiMsg As Integer
        Dim CmdAndChannel As Byte
        CmdAndChannel = StuffByte(GetByte(MIDIStatusMessages.ControllerChange), OutputChannel)
        MidiMsg = StuffInt32(CmdAndChannel, GetByte(Controller), Data1, Data2)
        midiOutShortMsg(hMidiOUT, MidiMsg)
    End Sub

    '-- Return a list of the input device names as a string array
    Public Shared Function InDeviceNames() As String()
        Dim num As Integer
        Dim i As Integer
        Dim Caps As MIDIINCAPS
        Dim names() As String

        num = midiInGetNumDevs
        If num > 0 Then
            ReDim names(num - 1)
            For i = 0 To num - 1
                midiInGetDevCaps(i, Caps, Len(Caps))
                names(i) = Caps.szPname
            Next
        End If
        Return names
    End Function

    '-- Return a list of output device names as a string array
    Public Shared Function OutDeviceNames() As String()
        Dim num As Integer
        Dim i As Integer
        Dim Caps As MIDIOUTCAPS
        Dim names() As String

        num = midiOutGetNumDevs
        If num > 0 Then
            ReDim names(num - 1)
            For i = 0 To num - 1
                midiOutGetDevCaps(i, Caps, Len(Caps))
                names(i) = Caps.szPname
            Next
        End If
        Return names
    End Function

    '-- Change the patch (output) by providing a GM Instrument name using an Enum
    Public Sub ChangePatchGM(ByVal Instrument As GMInstruments)
        Try
            Me.PatchNumber = GetByte(Instrument)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Change the patch (output) by GM name
    Public Sub ChangePatchGM(ByVal GMPatchName As String)
        Try
            Me.PatchNumber = GetByte(Array.IndexOf(Me.GMInstrumentNames, GMPatchName))
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Send the AllSoundOff (panic) message
    Public Sub AllSoundOff()
        Dim Msg As Byte
        Dim MidiMsg As Int32
        If _Engaged = False Then Exit Sub
        Try
            Msg = StuffByte(GetByte(MIDIStatusMessages.ChannelModeMessage), _OutputChannel)
            MidiMsg = StuffInt32(Msg, &H78, 0, 0)
            midiOutShortMsg(hMidiOUT, MidiMsg)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Reset all the output controllers
    Public Sub ResetAllControllers()
        Dim Msg As Byte
        Dim MidiMsg As Int32
        If _Engaged = False Then Exit Sub
        Try
            Msg = StuffByte(GetByte(MIDIStatusMessages.ChannelModeMessage), _OutputChannel)
            MidiMsg = StuffInt32(Msg, &H79, 0, 0)
            midiOutShortMsg(hMidiOUT, MidiMsg)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Turn off all notes currently playing
    Public Sub AllNotesOff()
        Dim Msg As Byte
        Dim MidiMsg As Int32
        If _Engaged = False Then Exit Sub
        Try
            Msg = StuffByte(GetByte(MIDIStatusMessages.ChannelModeMessage), _OutputChannel)
            MidiMsg = StuffInt32(Msg, &H7B, 0, 0)
            midiOutShortMsg(hMidiOUT, MidiMsg)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Play a note by number (0-127), specifying a velocity value (0-127)
    Public Sub PlayNote(ByVal Note As Byte, ByVal Velocity As Byte)
        Dim Msg As Byte
        Dim MidiMsg As Int32

        If _Engaged = False Then Exit Sub
        Msg = StuffByte(GetByte(MIDIStatusMessages.NoteOn), _OutputChannel)
        MidiMsg = StuffInt32(Msg, GetByte(Note + _Transpose), Velocity, 0)
        Try
            midiOutShortMsg(hMidiOUT, MidiMsg)
            If _NoteDuration > 0 Then
                Dim no As NotesOff
                no.Note = GetByte(Note + _Transpose)
                no.ShutoffTime = DateAdd(DateInterval.Second, _NoteDuration, Now)
                SyncLock notesToTurnOff
                    notesToTurnOff.Add(no)
                End SyncLock
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '-- Stop playing a note by passing the note number (0-127) and optionally velocity (0-127)
    Public Sub StopNote(ByVal Note As Byte, Optional ByVal Velocity As Byte = 64)
        Dim Msg As Byte

        Dim MidiMsg As Int32

        If _Engaged = False Then Exit Sub
        Msg = StuffByte(GetByte(MIDIStatusMessages.NoteOff), _OutputChannel)
        MidiMsg = StuffInt32(Msg, GetByte(Note + _Transpose), Velocity, 0)
        Try
            midiOutShortMsg(hMidiOUT, MidiMsg)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub


#End Region

#Region " Property Handlers "

    '-- Boolean that the programmer can use for any reason.
    '   I use it to persist the state of a leslie simulator
    '   for Native Instruments' B4 Virtual Organ
    Private _UserDefinedBool1 As Boolean
    Public Property UserDefinedBool1() As Boolean
        Get
            Return _UserDefinedBool1
        End Get
        Set(ByVal Value As Boolean)
            _UserDefinedBool1 = Value
        End Set
    End Property

    '-- Boolean that the programmer can use for any reason.
    Private _UserDefinedBool2 As Boolean
    Public Property UserDefinedBool2() As Boolean
        Get
            Return _UserDefinedBool2
        End Get
        Set(ByVal Value As Boolean)
            _UserDefinedBool2 = Value
        End Set
    End Property

    '-- Setting this to a valid text file name turns on tracing.
    '   You can use this to monitor data and events as they 
    '   happen in real time.
    Private _OutputTraceLogFile As String
    Public Property OutputTraceLogFile() As String
        Get
            Return _OutputTraceLogFile
        End Get
        Set(ByVal Value As String)
            Try
                If Value Is Nothing Then
                    If Trace.Listeners.Count > 0 Then
                        Trace.Listeners(0).Close()
                        Trace.Listeners.Clear()
                    End If
                    _OutputTraceLogFile = Value
                ElseIf Value = "" Then
                    If Trace.Listeners.Count > 0 Then
                        Trace.Listeners(0).Close()
                        Trace.Listeners.Clear()
                    End If
                    _OutputTraceLogFile = Value
                Else
                    Trace.Listeners.Add(New TextWriterTraceListener(Value))
                    Trace.AutoFlush = True
                    _OutputTraceLogFile = Value
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Set
    End Property

    '-- When True, a patch change is sent when the output device is open
    Private _sendPatchChangeOnOpen As Boolean = True
    Public Property SendPatchChangeOnOpen() As Boolean
        Get
            Return _sendPatchChangeOnOpen
        End Get
        Set(ByVal Value As Boolean)
            _sendPatchChangeOnOpen = Value
        End Set
    End Property

    '-- Turns local control off and on
    Private _LocalControl As Boolean = True
    Public Property LocalControl() As Boolean
        Get
            Return _LocalControl
        End Get
        Set(ByVal Value As Boolean)
            If _Engaged = True Then
                Dim Msg As Byte
                Dim MidiMsg As Int32
                Try
                    Msg = StuffByte(GetByte(MIDIStatusMessages.ChannelModeMessage), _OutputChannel)
                    If Value = True Then
                        MidiMsg = StuffInt32(Msg, &H7A, &H7F, 0)
                    Else
                        MidiMsg = StuffInt32(Msg, &H7A, 0, 0)
                    End If
                    midiOutShortMsg(hMidiOUT, MidiMsg)
                Catch ex As Exception
                    Throw New Exception("Error setting Local Control: " & ex.Message, ex)
                End Try
            End If
            _LocalControl = Value
        End Set
    End Property

    '-- Set to a number of semitones less than or greater than zero
    '   to transpose output notes up or down
    Private _Transpose As Int32 = 0
    Public Property Transpose() As Int32
        Get
            Return _Transpose
        End Get
        Set(ByVal Value As Int32)
            _Transpose = Value
        End Set
    End Property

    '-- When True, aftertouch (channel pressure) on the input device
    '   is ignored
    Private _FilterAfterTouch As Boolean = True
    Public Property FilterAfterTouch() As Boolean
        Get
            Return _FilterAfterTouch
        End Get
        Set(ByVal Value As Boolean)
            _FilterAfterTouch = Value
        End Set
    End Property

    '-- When you set the NoteDuration property, you can just call 
    '   PlayNote and the notes will be cut off (NOTE_OFF sent) 
    '   after NoteDuration number of seconds
    Private _NoteDuration As Int32 = 0
    Public Property NoteDuration() As Int32
        Get
            Return _NoteDuration
        End Get
        Set(ByVal Value As Int32)
            If Value > 0 Then
                Dim T As New Threading.Thread(AddressOf ShutoffNoteCallback)
                T.Start()
            End If
            _NoteDuration = Value
        End Set
    End Property
    '-- Event used to communicate from the ShutoffNoteCallback sub
    Private ev As New Threading.AutoResetEvent(False)

    '-- Returns True if there are devices open
    Public ReadOnly Property Engaged() As Boolean
        Get
            Engaged = _Engaged
        End Get
    End Property

    '-- Lets you specify an output device by name
    Private _OutputDeviceName As String = ""
    Public Property OutputDeviceName() As String
        Get
            Return _OutputDeviceName
        End Get
        Set(ByVal Value As String)
            If Value Is Nothing Then Exit Property
            Dim i As Int32
            _OutputDeviceID = -1
            Dim devices() As String = Me.OutDeviceNames
            If Not devices Is Nothing Then
                For i = 0 To devices.Length - 1
                    If Not devices(i) Is Nothing Then
                        If devices(i).ToLower = Value.ToLower Then
                            _OutputDeviceName = Value
                            _OutputDeviceID = i
                            Exit For
                        End If
                    End If
                Next
            End If
        End Set
    End Property

    '-- Lets you specify an input device by name
    Private _InputDeviceName As String = ""
    Public Property InputDeviceName() As String
        Get
            InputDeviceName = _InputDeviceName
        End Get
        Set(ByVal Value As String)
            If Value Is Nothing Then Exit Property
            Dim i As Int32
            _InputDeviceID = -1
            Dim devices() As String = Me.InDeviceNames
            If Not devices Is Nothing Then
                For i = 0 To devices.Length - 1
                    If Not devices(i) Is Nothing Then
                        If devices(i).ToLower = Value.ToLower Then
                            _InputDeviceName = Value
                            _InputDeviceID = i
                            Exit For
                        End If
                    End If
                Next
            End If
        End Set
    End Property

    '-- Specify the zero-based MIDI channel on the output device
    Private _OutputChannel As Byte = 0
    Public Property OutputChannel() As Byte
        Get
            OutputChannel = _OutputChannel
        End Get
        Set(ByVal Value As Byte)
            _OutputChannel = Value
        End Set
    End Property

    '-- Specify the zero-based MIDI channel on the input device
    Private _InputChannel As Byte = 0
    Public Property InputChannel() As Byte
        Get
            InputChannel = _InputChannel
        End Get
        Set(ByVal Value As Byte)
            _InputChannel = Value
        End Set
    End Property

    '-- Sets the volume of the output device
    Private _Volume As Byte = 127
    Public Property Volume() As Byte
        Get
            Return _Volume
        End Get

        Set(ByVal Value As Byte)
            _Volume = Value
            If _Engaged = True Then
                Try
                    Dim Msg As Byte
                    Dim MidiMsg As Int32
                    Msg = StuffByte(GetByte(MIDIStatusMessages.ControllerChange), _OutputChannel)
                    MidiMsg = StuffInt32(Msg, 7, Value, 0)
                    midiOutShortMsg(hMidiOUT, MidiMsg)
                Catch ex As Exception
                    Throw New Exception("Error setting Volume: " & ex.Message, ex)
                End Try
            End If
        End Set
    End Property

    '-- Sets the patch number for the output device
    Private _PatchNumber As Byte = 0
    Public Property PatchNumber() As Byte
        Get
            Return _PatchNumber
        End Get
        Set(ByVal Value As Byte)
            _PatchNumber = Value
            If _Engaged = True Then
                Try
                    Dim Msg As Byte
                    Dim MidiMsg As Int32
                    Msg = StuffByte(GetByte(MIDIStatusMessages.ProgramChange), _OutputChannel)
                    MidiMsg = StuffInt32(Msg, Value, 0, 0)
                    midiOutShortMsg(hMidiOUT, MidiMsg)
                Catch ex As Exception
                    Throw ex
                End Try
            End If
        End Set
    End Property

#End Region

#Region " Shared Arrays "

    '-- General MIDI Instrument Names
    Public Shared GMInstrumentNames() As String = _
    {"AcousticGrandPiano", _
    "BrightAcousticPiano", _
    "ElectricGrandPiano", _
    "HonkyTonkPiano", _
    "ElectricPiano1", _
    "ElectricPiano2", _
    "Harpsichord", _
    "Clavi", _
    "Celesta", _
    "Glockenspiel", _
    "MusicBox", _
    "Vibraphone", _
    "Marimba", _
    "Xylophone", _
    "TubularBells", _
    "Dulcimer", _
    "DrawbarOrgan", _
    "PercussiveOrgan", _
    "RockOrgan", _
    "ChurchOrgan", _
    "ReedOrgan", _
    "Accordion", _
    "Harmonica", _
    "TangoAccordion", _
    "AcousticGuitarNylon", _
    "AcousticGuitarSteel", _
    "ElectricGuitarJazz", _
    "ElectricGuitarClean", _
    "ElectricGuitarMuted", _
    "OverdrivenGuitar", _
    "DistortionGuitar", _
    "GuitarHarmonics", _
    "AcousticBass", _
    "ElectricBassFinger", _
    "ElectricBassPick", _
    "FretlessBass", _
    "SlapBass1", _
    "SlapBass2", _
    "SynthBass1", _
    "SynthBass2", _
    "Violin", _
    "Viola", _
    "Cello", _
    "Contrabass", _
    "TremoloStrings", _
    "PizzicatoStrings", _
    "OrchestralHarp", _
    "Timpani", _
    "StringEnsemble1", _
    "StringEnsemble2", _
    "SynthStrings1", _
    "SynthStrings2", _
    "ChoirAahs", _
    "VoiceOohs", _
    "SynthVoice", _
    "OrchestraHit", _
    "Trumpet", _
    "Trombone", _
    "Tuba", _
    "MutedTrumpet", _
    "FrenchHorn", _
    "BrassSection", _
    "SynthBrass1", _
    "SynthBrass2", _
    "SopranoSax", _
    "AltoSax", _
    "TenorSax", _
    "BaritoneSax", _
    "Oboe", _
    "EnglishHorn", _
    "Bassoon", _
    "Clarinet", _
    "Piccolo", _
    "Flute", _
    "Recorder", _
    "PanFlute", _
    "BlownBottle", _
    "Shakuhachi", _
    "Whistle", _
    "Ocarina", _
    "Lead1Square", _
    "Lead2Sawtooth", _
    "Lead3Calliope", _
    "Lead4Chiff", _
    "Lead5Charang", _
    "Lead6Voice", _
    "Lead7Fifths", _
    "Lead8BassPluslead", _
    "Pad1NewAge", _
    "Pad2Warm", _
    "Pad3Polysynth", _
    "Pad4Choir", _
    "Pad5Bowed", _
    "Pad6Metallic", _
    "Pad7Halo", _
    "Pad8Sweep", _
    "FX1Rain", _
    "FX2Soundtrack", _
    "FX3Crystal", _
    "FX4Atmosphere", _
    "FX5Brightness", _
    "FX6Goblins", _
    "FX7Echoes", _
    "FX8SciFi", _
    "Sitar", _
    "Banjo", _
    "Shamisen", _
    "Koto", _
    "Kalimba", _
    "Bagpipe", _
    "Fiddle", _
    "Shanai", _
    "TinkleBell", _
    "Agogo", _
    "SteelDrums", _
    "Woodblock", _
    "TaikoDrum", _
    "MelodicTom", _
    "SynthDrum", _
    "ReverseCymbal", _
    "GuitarFretNoise", _
    "BreathNoise", _
    "Seashore", _
    "BirdTweet", _
    "TelephoneRing", _
    "Helicopter", _
    "Applause", _
    "Gunshot"}

#End Region

End Class

#Region " Enums "

Public Enum MIDIStatusMessages
    NoteOff = CByte(&H8)
    NoteOn = CByte(&H9)
    PolyphonicKeyPressure = CByte(&HA)
    ControllerChange = CByte(&HB)
    ProgramChange = CByte(&HC)
    ChannelPressure = CByte(&HD)
    PitchBend = CByte(&HE)
    ChannelModeMessage = CByte(&HB)
End Enum

Public Enum MIDIControllers
    ModWheel = CByte(1)
    BreathController = CByte(2)
    FootController = CByte(4)
    PortamentoTime = CByte(5)
    MainVolume = CByte(7)
    Balance = CByte(8)
    Pan = CByte(10)
    ExpressionController = CByte(11)
    DamperPedal = CByte(64)
    Portamento = CByte(65)
    Sostenuto = CByte(66)
    SoftPedal = CByte(67)
    Hold2 = CByte(69)
    ExternalEffectsDepth = CByte(91)
    TremeloDepth = CByte(92)
    ChorusDepth = CByte(93)
    DetuneDepth = CByte(94)
    PhaserDepth = CByte(95)
    DataIncrement = CByte(96)
    DataDecrement = CByte(97)
    AllNotesOff = CByte(123)
End Enum

Public Enum GMInstruments
    AcousticGrandPiano
    BrightAcousticPiano
    ElectricGrandPiano
    HonkyTonkPiano
    ElectricPiano1
    ElectricPiano2
    Harpsichord
    Clavi
    Celesta
    Glockenspiel
    MusicBox
    Vibraphone
    Marimba
    Xylophone
    TubularBells
    Dulcimer
    DrawbarOrgan
    PercussiveOrgan
    RockOrgan
    ChurchOrgan
    ReedOrgan
    Accordion
    Harmonica
    TangoAccordion
    AcousticGuitarNylon
    AcousticGuitarSteel
    ElectricGuitarJazz
    ElectricGuitarClean
    ElectricGuitarMuted
    OverdrivenGuitar
    DistortionGuitar
    GuitarHarmonics
    AcousticBass
    ElectricBassFinger
    ElectricBassPick
    FretlessBass
    SlapBass1
    SlapBass2
    SynthBass1
    SynthBass2
    Violin
    Viola
    Cello
    Contrabass
    TremoloStrings
    PizzicatoStrings
    OrchestralHarp
    Timpani
    StringEnsemble1
    StringEnsemble2
    SynthStrings1
    SynthStrings2
    ChoirAahs
    VoiceOohs
    SynthVoice
    OrchestraHit
    Trumpet
    Trombone
    Tuba
    MutedTrumpet
    FrenchHorn
    BrassSection
    SynthBrass1
    SynthBrass2
    SopranoSax
    AltoSax
    TenorSax
    BaritoneSax
    Oboe
    EnglishHorn
    Bassoon
    Clarinet
    Piccolo
    Flute
    Recorder
    PanFlute
    BlownBottle
    Shakuhachi
    Whistle
    Ocarina
    Lead1Square
    Lead2Sawtooth
    Lead3Calliope
    Lead4Chiff
    Lead5Charang
    Lead6Voice
    Lead7Fifths
    Lead8BassPluslead
    Pad1NewAge
    Pad2Warm
    Pad3Polysynth
    Pad4Choir
    Pad5Bowed
    Pad6Metallic
    Pad7Halo
    Pad8Sweep
    FX1Rain
    FX2Soundtrack
    FX3Crystal
    FX4Atmosphere
    FX5Brightness
    FX6Goblins
    FX7Echoes
    FX8SciFi
    Sitar
    Banjo
    Shamisen
    Koto
    Kalimba
    Bagpipe
    Fiddle
    Shanai
    TinkleBell
    Agogo
    SteelDrums
    Woodblock
    TaikoDrum
    MelodicTom
    SynthDrum
    ReverseCymbal
    GuitarFretNoise
    BreathNoise
    Seashore
    BirdTweet
    TelephoneRing
    Helicopter
    Applause
    Gunshot
End Enum

#End Region

<Serializable()> Public Class InstrumentData
    Public Name As String
    Public InputDeviceName As String
    Public OutputDeviceName As String
    Public InputChannel As Byte
    Public OutputChannel As Byte
    Public NoteDuration As Int32
    Public SendPatchChangeOnOpen As Boolean
    Public LocalControl As Boolean
    Public FilterAftertouch As Boolean = True
    Public Transpose As Int32
    Public PatchNumber As Byte
    Public Volume As Byte = 127
End Class
