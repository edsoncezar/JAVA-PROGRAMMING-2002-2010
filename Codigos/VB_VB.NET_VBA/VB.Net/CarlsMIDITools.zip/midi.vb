Option Strict Off
Option Explicit On 
Imports System.Runtime.InteropServices

Module midi
    ' this module containes all midi API functions
    Public Function GetByte(ByVal obj As Object) As Byte
        Dim b As Byte
        If IsNumeric(obj) = False Then
            b = 0
        Else
            Select Case CInt(obj)
                Case Is < 0
                    b = 0
                Case Is > 255
                    b = 255
                Case Else
                    b = CByte(obj)
            End Select
        End If
        Return b
    End Function

    Public Const MAXPNAMELEN As Short = 32 '  max product name length (including NULL)

    Structure MIDIEVENT
        Dim dwDeltaTime As Integer '  Ticks since last event
        Dim dwStreamID As Integer '  Reserved; must be zero
        Dim dwEvent As Integer '  Event type and parameters
        <VBFixedArray(1)> Dim dwParms() As Integer '  Parameters if this is a long event
        Public Sub Initialize()
            ReDim dwParms(1)
        End Sub
    End Structure

    Structure MIDIHDR
        Dim lpData As String
        Dim dwBufferLength As Integer
        Dim dwBytesRecorded As Integer
        Dim dwUser As Integer
        Dim dwFlags As Integer
        Dim lpNext As Integer
        Dim Reserved As Integer
        Dim dwOffset As Integer
        <VBFixedArray(4)> Dim dwReserved() As Integer

        Public Sub Initialize()
            ReDim dwReserved(4)
        End Sub
    End Structure

    Structure MIDIINCAPS
        Dim wMid As Short
        Dim wPid As Short
        Dim vDriverVersion As Integer
        <VBFixedString(MAXPNAMELEN), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst:=MAXPNAMELEN)> Public szPname As String
    End Structure

    Structure MIDIOUTCAPS
        Dim wMid As Short
        Dim wPid As Short
        Dim vDriverVersion As Integer
        <VBFixedString(MAXPNAMELEN), System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst:=MAXPNAMELEN)> Public szPname As String
        Dim wTechnology As Short
        Dim wVoices As Short
        Dim wNotes As Short
        Dim wChannelMask As Short
        Dim dwSupport As Integer
    End Structure

    Structure MIDIPROPTEMPO
        Dim cbStruct As Integer
        Dim dwTempo As Integer
    End Structure

    Structure MIDIPROPTIMEDIV
        Dim cbStruct As Integer
        Dim dwTimeDiv As Integer
    End Structure

    Structure MIDISTRMBUFFVER
        Dim dwVersion As Integer '  Stream buffer format version
        Dim dwMid As Integer '  Manufacturer ID as defined in MMREG.H
        Dim dwOEMVersion As Integer '  Manufacturer version for custom ext
    End Structure

    ' MIDI API Functions for Windows 95
    Declare Function midiConnect Lib "winmm.dll" (ByVal hmi As Integer, ByVal hmo As Integer, ByRef pReserved As Int32) As Integer
    Declare Function midiDisconnect Lib "winmm.dll" (ByVal hmi As Integer, ByVal hmo As Integer, ByRef pReserved As Int32) As Integer
    Declare Function midiInAddBuffer Lib "winmm.dll" (ByVal hMidiIN As Integer, ByRef lpMidiInHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiInClose Lib "winmm.dll" (ByVal hMidiIN As Integer) As Integer
    Declare Function midiInGetDevCaps Lib "winmm.dll" Alias "midiInGetDevCapsA" (ByVal uDeviceID As Integer, ByRef lpCaps As MIDIINCAPS, ByVal uSize As Integer) As Integer
    Declare Function midiInGetErrorText Lib "winmm.dll" Alias "midiInGetErrorTextA" (ByVal err_Renamed As Integer, ByVal lpText As String, ByVal uSize As Integer) As Integer
    Declare Function midiInGetID Lib "winmm.dll" (ByVal hMidiIN As Integer, ByRef DeviceName As String) As Integer
    Declare Function midiInGetNumDevs Lib "winmm.dll" () As Integer
    Declare Function midiInMessage Lib "winmm.dll" (ByVal hMidiIN As Integer, ByVal Msg As Integer, ByVal dw1 As Integer, ByVal dw2 As Integer) As Integer
    'Declare Function midiInOpen Lib "winmm.dll" (ByRef lphMidiIn As Integer, ByVal uDeviceID As Integer, ByVal dwCallback As Int32, ByVal dwInstance As Integer, ByVal dwFlags As Integer) As Integer

    Public Delegate Sub MidiDelegate(ByVal MidiInHandle As Int32, ByVal wMsg As Int32, ByVal Instance As Int32, ByVal wParam As Int32, ByVal lParam As Int32)
    Declare Function midiInOpen Lib "winmm.dll" (ByRef lphMidiIn As Integer, _
        ByVal uDeviceID As Integer, <MarshalAs(UnmanagedType.FunctionPtr)> ByVal dwCallback As MidiDelegate, _
        ByVal dwInstance As Integer, ByVal dwFlags As Integer) As Integer

    Declare Function midiInPrepareHeader Lib "winmm.dll" (ByVal hMidiIN As Integer, ByRef lpMidiInHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiInReset Lib "winmm.dll" (ByVal hMidiIN As Integer) As Integer
    Declare Function midiInStart Lib "winmm.dll" (ByVal hMidiIN As Integer) As Integer
    Declare Function midiInStop Lib "winmm.dll" (ByVal hMidiIN As Integer) As Integer
    Declare Function midiInUnprepareHeader Lib "winmm.dll" (ByVal hMidiIN As Integer, ByRef lpMidiInHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiOutCacheDrumPatches Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByVal uPatch As Integer, ByRef lpKeyArray As Integer, ByVal uFlags As Integer) As Integer
    Declare Function midiOutCachePatches Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByVal uBank As Integer, ByRef lpPatchArray As Integer, ByVal uFlags As Integer) As Integer
    Declare Function midiOutClose Lib "winmm.dll" (ByVal hMidiOUT As Integer) As Integer
    Declare Function midiOutGetDevCaps Lib "winmm.dll" Alias "midiOutGetDevCapsA" (ByVal uDeviceID As Integer, ByRef lpCaps As MIDIOUTCAPS, ByVal uSize As Integer) As Integer
    Declare Function midiOutGetErrorText Lib "winmm.dll" Alias "midiOutGetErrorTextA" (ByVal err_Renamed As Integer, ByVal lpText As String, ByVal uSize As Integer) As Integer
    Declare Function midiOutGetID Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByRef DeviceName As String) As Integer
    Declare Function midiOutGetNumDevs Lib "winmm" () As Short
    Declare Function midiOutGetVolume Lib "winmm.dll" (ByVal uDeviceID As Integer, ByRef lpdwVolume As Integer) As Integer
    Declare Function midiOutLongMsg Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByRef lpMidiOutHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiOutMessage Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByVal Msg As Integer, ByVal dw1 As Integer, ByVal dw2 As Integer) As Integer
    Declare Function midiOutOpen Lib "winmm.dll" (ByRef lphMidiOut As Integer, ByVal uDeviceID As Integer, ByVal dwCallback As Integer, ByVal dwInstance As Integer, ByVal dwFlags As Integer) As Integer
    Declare Function midiOutPrepareHeader Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByRef lpMidiOutHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiOutReset Lib "winmm.dll" (ByVal hMidiOUT As Integer) As Integer
    Declare Function midiOutSetVolume Lib "winmm.dll" (ByVal uDeviceID As Integer, ByVal dwVolume As Integer) As Integer
    Declare Function midiOutShortMsg Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByVal dwMsg As Integer) As Integer
    Declare Function midiOutUnprepareHeader Lib "winmm.dll" (ByVal hMidiOUT As Integer, ByRef lpMidiOutHdr As MIDIHDR, ByVal uSize As Integer) As Integer
    Declare Function midiStreamClose Lib "winmm.dll" (ByVal hms As Integer) As Integer
    Declare Function midiStreamOpen Lib "winmm.dll" (ByRef phms As Integer, ByRef puDeviceID As Integer, ByVal cMidi As Integer, ByVal dwCallback As Integer, ByVal dwInstance As Integer, ByVal fdwOpen As Integer) As Integer
    Declare Function midiStreamOut Lib "winmm.dll" (ByVal hms As Integer, ByRef pmh As MIDIHDR, ByVal cbmh As Integer) As Integer
    Declare Function midiStreamPause Lib "winmm.dll" (ByVal hms As Integer) As Integer
    'Declare Function midiStreamPosition Lib "winmm.dll" (ByVal hms As Integer, ByRef lpmmt As MMakePiano, ByVal cbmmt As Integer) As Integer
    Declare Function midiStreamProperty Lib "winmm.dll" (ByVal hms As Integer, ByRef lppropdata As Byte, ByVal dwProperty As Integer) As Integer
    Declare Function midiStreamRestart Lib "winmm.dll" (ByVal hms As Integer) As Integer
    Declare Function midiStreamStop Lib "winmm.dll" (ByVal hms As Integer) As Integer

    ' General error return values
    Public Const MMSYSERR_BASE As Short = 0
    Public Const MMSYSERR_NOERROR As Short = 0 '  no error
    Public Const MMSYSERR_ERROR As Integer = (MMSYSERR_BASE + 1) '  unspecified error
    Public Const MMSYSERR_BADDEVICEID As Integer = (MMSYSERR_BASE + 2) '  device ID out of range
    Public Const MMSYSERR_NOTENABLED As Integer = (MMSYSERR_BASE + 3) '  driver failed enable
    Public Const MMSYSERR_ALLOCATED As Integer = (MMSYSERR_BASE + 4) '  device already allocated
    Public Const MMSYSERR_INVALHANDLE As Integer = (MMSYSERR_BASE + 5) '  device handle is invalid
    Public Const MMSYSERR_NODRIVER As Integer = (MMSYSERR_BASE + 6) '  no device driver present
    Public Const MMSYSERR_NOMEM As Integer = (MMSYSERR_BASE + 7) '  memory allocation error
    Public Const MMSYSERR_NOTSUPPORTED As Integer = (MMSYSERR_BASE + 8) '  function isn't supported
    Public Const MMSYSERR_BADERRNUM As Integer = (MMSYSERR_BASE + 9) '  error value out of range
    Public Const MMSYSERR_INVALFLAG As Integer = (MMSYSERR_BASE + 10) '  invalid flag passed
    Public Const MMSYSERR_INVALPARAM As Integer = (MMSYSERR_BASE + 11) '  invalid parameter passed
    Public Const MMSYSERR_HANDLEBUSY As Integer = (MMSYSERR_BASE + 12) '  handle being used

    '  simultaneously on another
    '  thread (eg callback)
    Public Const MMSYSERR_INVALIDALIAS As Integer = (MMSYSERR_BASE + 13) '  "Specified alias not found in WIN.INI
    Public Const MMSYSERR_LASTERROR As Integer = (MMSYSERR_BASE + 13) '  last error in range

    '  flags for dwFlags field of MIDIHDR structure
    Public Const MHDR_DONE As Short = &H1S '  done bit
    Public Const MHDR_PREPARED As Short = &H2S '  set if header prepared
    Public Const MHDR_INQUEUE As Short = &H4S '  reserved for driver
    Public Const MHDR_VALID As Short = &H7S '  valid flags / ;Internal /

    '  flags used with waveOutOpen(), waveInOpen(), midiInOpen(), and
    '  midiOutOpen() to specify the type of the dwCallback parameter.
    Public Const CALLBACK_TYPEMASK As Integer = &H70000 '  callback type mask
    Public Const CALLBACK_NULL As Short = &H0S '  no callback
    Public Const CALLBACK_WINDOW As Integer = &H10000 '  dwCallback is a HWND
    Public Const CALLBACK_TASK As Integer = &H20000 '  dwCallback is a HTASK
    Public Const CALLBACK_FUNCTION As Integer = &H30000 '  dwCallback is a FARPROC

    '  manufacturer IDs
    Public Const MM_MICROSOFT As Short = 1 '  Microsoft Corp.

    '  product IDs
    Public Const MM_MIDI_MAPPER As Short = 1 '  MIDI Mapper
    Public Const MM_WAVE_MAPPER As Short = 2 '  Wave Mapper

    Public Const MM_SNDBLST_MIDIOUT As Short = 3 '  Sound Blaster MIDI output port
    Public Const MM_SNDBLST_MIDIIN As Short = 4 '  Sound Blaster MIDI input port
    Public Const MM_SNDBLST_SYNTH As Short = 5 '  Sound Blaster internal synthesizer
    Public Const MM_SNDBLST_WAVEOUT As Short = 6 '  Sound Blaster waveform output
    Public Const MM_SNDBLST_WAVEIN As Short = 7 '  Sound Blaster waveform input

    Public Const MM_ADLIB As Short = 9 '  Ad Lib-compatible synthesizer

    Public Const MM_MPU401_MIDIOUT As Short = 10 '  MPU401-compatible MIDI output port
    Public Const MM_MPU401_MIDIIN As Short = 11 '  MPU401-compatible MIDI input port

    Public Const MM_PC_JOYSTICK As Short = 12 '  Joystick adapter

    Public Const MIDI_IO_STATUS As Short = &H20
    Public Const MM_MIM_OPEN As Short = &H3C1S '  MIDI input
    Public Const MM_MIM_CLOSE As Short = &H3C2S
    Public Const MM_MIM_DATA As Short = &H3C3S
    Public Const MM_MIM_LONGDATA As Short = &H3C4S
    Public Const MM_MIM_ERROR As Short = &H3C5S
    Public Const MM_MIM_LONGERROR As Short = &H3C6S
    Public Const MM_MIM_MOREDATA As Short = &H3CC

    Public Const MM_MOM_OPEN As Short = &H3C7S '  MIDI output
    Public Const MM_MOM_CLOSE As Short = &H3C8S
    Public Const MM_MOM_DONE As Short = &H3C9S

    '----------------------------------------------------------------

    'MIDI Mapper
    Public Const MIDI_MAPPER As Short = -1

    '  flags for wTechnology field of MIDIOUTCAPS structure
    Public Const MOD_MIDIPORT As Byte = 1 '  output port
    Public Const MOD_SYNTH As Byte = 2 '  generic internal synth
    Public Const MOD_SQSYNTH As Byte = 3 '  square wave internal synth
    Public Const MOD_FMSYNTH As Byte = 4 '  FM internal synth
    Public Const MOD_MAPPER As Byte = 5 '  MIDI mapper

    '  flags for dwSupport field of MIDIOUTCAPS
    Public Const MIDICAPS_VOLUME As Byte = &H1 '  supports volume control
    Public Const MIDICAPS_LRVOLUME As Byte = &H2 '  separate left-right volume control
    Public Const MIDICAPS_CACHE As Byte = &H4

    '' MIDI Controller Numbers Constants
    Public Const MOD_WHEEL As Byte = 1
    Public Const BREATH_CONTROLLER As Byte = 2
    Public Const FOOT_CONTROLLER As Byte = 4
    Public Const PORTAMENTO_TIME As Byte = 5
    Public Const MAIN_VOLUME As Byte = 7
    Public Const BALANCE As Byte = 8
    Public Const PAN As Byte = 10
    Public Const EXPRESS_CONTROLLER As Byte = 11
    Public Const DAMPER_PEDAL As Byte = 64
    Public Const PORTAMENTO As Byte = 65
    Public Const SOSTENUTO As Byte = 66
    Public Const SOFT_PEDAL As Byte = 67
    Public Const HOLD_2 As Byte = 69
    Public Const EXTERNAL_FX_DEPTH As Byte = 91
    Public Const TREMELO_DEPTH As Byte = 92
    Public Const CHORUS_DEPTH As Byte = 93
    Public Const DETUNE_DEPTH As Byte = 94
    Public Const PHASER_DEPTH As Byte = 95
    Public Const DATA_INCREMENT As Byte = 96
    Public Const DATA_DECREMENT As Byte = 97

    ' MIDI status messages
    Public Const NOTE_OFF As Byte = &H80
    Public Const NOTE_ON As Byte = &H90
    Public Const POLY_KEY_PRESS As Byte = &HA0
    Public Const CONTROLLER_CHANGE As Byte = &HB0
    Public Const PROGRAM_CHANGE As Byte = &HC0
    Public Const CHANNEL_PRESSURE As Byte = &HD0
    Public Const PITCH_BEND As Byte = &HE0

End Module
