Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 192)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Encrypt"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(16, 8)
        Me.TextBox1.MaxLength = 9999999
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(384, 176)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(104, 192)
        Me.Button2.Name = "Button2"
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Decrypt"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(192, 192)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(320, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 226)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Encryption"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private dp As New DPAPIHelper.DataProtection(Application.ProductName)
    Private Encrypted, Decrypted As String
    Private filename As String = "c:\encrypted.txt"
    Private ms As Int64
    Private mgTimer As New MattGriffith.Diagnostics.PerfTimer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        mgTimer.Start(True)
        Encrypted = dp.Encrypt(TextBox1.Text, DPAPIHelper.DataProtection.Store.User)
        mgTimer.Stop()
        ms = mgTimer.ElapsedMilliseconds
        Dim sw As New StreamWriter(filename)
        sw.Write(Encrypted)
        sw.Close()
        TextBox1.Text = ""
        Label2.Text = ms.ToString & " ms"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If Encrypted = "" Then
            If File.Exists(filename) Then
                Dim sr As New StreamReader(filename)
                Encrypted = sr.ReadToEnd
                sr.Close()
            End If
        End If
        mgTimer.Start(True)
        Decrypted = dp.Decrypt(Encrypted, DPAPIHelper.DataProtection.Store.User)
        mgTimer.Stop()
        ms = mgTimer.ElapsedMilliseconds
        TextBox1.Text = Decrypted
        Encrypted = ""
        Label2.Text = ms.ToString & " ms"
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label1.Text = TextBox1.Text.Length.ToString & " bytes"
    End Sub
End Class
