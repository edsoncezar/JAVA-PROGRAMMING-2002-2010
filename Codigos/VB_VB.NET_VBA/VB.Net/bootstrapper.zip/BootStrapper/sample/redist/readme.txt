dotnetfx.exe, the .NET redistributable runtime goes here.
You can download this from:

http://msdn.microsoft.com/downloads/default.asp?url=/downloads/sample.asp?url=/msdn-files/027/001/829/msdncompositedoc.xml
