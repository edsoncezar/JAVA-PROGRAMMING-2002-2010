This source code is for PowerBasic PBWin version 7.0
You can obtain the compiler at www.powerbasic.com

Carl