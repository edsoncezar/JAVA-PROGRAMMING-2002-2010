Public Class SelectForm
    Inherits System.Windows.Forms.Form

    '-- This form allows the user to select a rectangle. 
    '   It raises an event (Rectangle Selected) when the user has selected a rectangle
    '   Written by Carl Franklin (http://www.franklins.net) 
    '   Host of .NET Rocks! - http://www.franklins.net/dotnetrocks and http://msdn.microsoft.com/dotnetrocks
    '   Email Carl at carl@franklins.net
    '   Version 1.0 released May 8, 2004

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(243, 225)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    '-- Used to save the location where the mouse was first clicked
    Private downX As Int32 = -1
    Private downY As Int32
    '-- The rectangle that defines the form
    Private formRect As Rectangle
    '-- The last rectangle selected
    Private lastRect As Rectangle
    '-- These represent the size of the non-client area (the titlebar)
    Private nonClientWidth As Int32 = Me.Width - (Me.ClientSize.Width + 2)
    Private nonClientHeight As Int32 = Me.Height - (Me.ClientSize.Height + 2)

    '-- This event is raised when the user has selected a rectangle
    Public Event RectangleSelected(ByVal sender As System.Object, ByVal e As CarlsForms.RectangleSelectedArguments)

    '-- This property turns selecting on and off
    Private _allowSelect As Boolean
    Public Property AllowSelect() As Boolean
        Get
            Return _allowSelect
        End Get
        Set(ByVal Value As Boolean)
            If Value = True Then
                Me.Cursor = Cursors.Cross
            Else
                Me.Cursor = Cursors.Default
            End If
            _allowSelect = Value
        End Set
    End Property

    Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
        If AllowSelect = True Then
            '-- Save the position of the cursor
            downX = CInt(e.X)
            downY = CInt(e.Y)
            '-- Get the client rectangle relative to the screen
            Dim pt As New System.Drawing.Point(Me.Left + nonClientWidth, Me.Top + nonClientHeight)
            formRect = New Rectangle(pt, Me.ClientSize)
        End If
        MyBase.OnMouseDown(e)
    End Sub

    Protected Overrides Sub OnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
        If AllowSelect = True Then
            '-- Selected?
            If downX > -1 Then
                '-- Get the current Rectangle
                Dim ThisX As Int32 = Me.Left + nonClientWidth + downX
                Dim ThisY As Int32 = Me.Top + nonClientHeight + downY
                Dim ThisRect As New Rectangle(ThisX, ThisY, e.X - downX, e.Y - downY)

                '-- Insure that the rectangle bottom and height are within the client area
                If ThisRect.Bottom > formRect.Bottom Then
                    ThisRect.Height = (formRect.Bottom - ThisY) - 2
                ElseIf ThisRect.Bottom < formRect.Top Then
                    ThisRect.Height = (formRect.Top - ThisY) - 2
                End If

                '-- Insure that the rectangle right and width are within the client area
                If ThisRect.Right > formRect.Right Then
                    ThisRect.Width = (formRect.Right - ThisX) - 2
                ElseIf ThisRect.Right < formRect.Left Then
                    ThisRect.Width = (formRect.Left - ThisX) - 2
                End If

                '-- Did we draw a rectangle before?
                If lastRect.X <> 0 Then
                    '-- Yes. Draw the last rectangle again to erase it
                    ControlPaint.DrawReversibleFrame(lastRect, System.Drawing.Color.Black, FrameStyle.Dashed)
                End If
                '-- Draw the new rectangle
                ControlPaint.DrawReversibleFrame(ThisRect, System.Drawing.Color.Black, FrameStyle.Dashed)
                '-- The last rectanle is now the current rectangle
                lastRect = ThisRect
            End If
        End If
        MyBase.OnMouseMove(e)
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
        If AllowSelect = True Then
            '-- Erase the last rectangle
            ControlPaint.DrawReversibleFrame(lastRect, System.Drawing.Color.Black, FrameStyle.Dashed)
            '-- Reinitialize the mouse location
            downX = -1
            downY = 0
            '-- Create arguments for the RectangleSelected event
            Dim args As New RectangleSelectedArguments
            '-- Adjust the rectangle from screen coordinates
            lastRect.Offset(-(Me.Left + nonClientWidth), -(Me.Top + nonClientHeight))
            '-- Set the Rect property of the arguments and raise the event
            args.Rect = lastRect
            RaiseEvent RectangleSelected(Me, args)
            '-- Reset lastRect
            lastRect.X = 0
        End If
        MyBase.OnMouseUp(e)
    End Sub

End Class

Public Class RectangleSelectedArguments
    Inherits System.EventArgs

    Private _rect As Rectangle
    Public Property Rect() As Rectangle
        Get
            Return _rect
        End Get
        Set(ByVal Value As Rectangle)
            _rect = Value
        End Set
    End Property
End Class