Public Class frmMain
    Inherits CarlsForms.SelectForm

    '-- This Demo uses CarlsForms.SelectForm as a base class.
    '   SelectForm lets the user select a rectangle ala rubberbanding
    '   and raises the event RectangleSelected when the user lifts the mouse button
    '   This demo lets the user draw new buttons on the form, and wires them to an event handler
    '   Written by Carl Franklin (http://www.franklins.net) 
    '   Host of .NET Rocks! - http://www.franklins.net/dotnetrocks and http://msdn.microsoft.com/dotnetrocks
    '   Email Carl at carl@franklins.net
    '   Version 1.0 released May 8, 2004

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnDrawButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnDrawButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnDrawButton
        '
        Me.btnDrawButton.Location = New System.Drawing.Point(24, 16)
        Me.btnDrawButton.Name = "btnDrawButton"
        Me.btnDrawButton.Size = New System.Drawing.Size(144, 23)
        Me.btnDrawButton.TabIndex = 0
        Me.btnDrawButton.Text = "Draw Button"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.Add(Me.btnDrawButton)
        Me.Name = "frmMain"
        Me.Text = "SelectForm Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private buttonCount As Int32 = 0

    Private Sub btnDrawButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDrawButton.Click
        '-- Set AllowSelect to True to let the user select a rectangle
        Me.AllowSelect = True
    End Sub

    Private Sub frmMain_RectangleSelected(ByVal sender As Object, ByVal e As CarlsForms.RectangleSelectedArguments) Handles MyBase.RectangleSelected
        '-- Number of buttons created
        buttonCount += 1
        '-- Create a new button
        Dim b As New Button
        '-- You should call SuspendLayout before adding and removing controls
        Me.SuspendLayout()
        '-- Set the default properties  
        With b
            .Location = New System.Drawing.Point(e.Rect.Left, e.Rect.Top)
            .Size = New Size(e.Rect.Width, e.Rect.Height)
            .Name = "Button" & buttonCount.ToString
            .TabIndex = buttonCount
            .Text = .Name
        End With
        '-- Wire up the Event handler
        AddHandler b.Click, AddressOf Button_Click
        '-- Add to the Controls collection
        Me.Controls.Add(b)
        '-- Disable selecting
        Me.AllowSelect = False
        '-- All done
        Me.ResumeLayout()
    End Sub

    Private Sub Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '-- This handler handles Click events for all dynamic buttons
        Dim btn As Button = CType(sender, Button)
        MsgBox("You clicked " & btn.Name)
    End Sub

End Class
