Hi this zip file contains two projects one is server project named NetWorkManager and another is client's(node) Project Named Message Box.
these projects can be used in any systems which connected by a LAN net work or even in a single personal computer . This very use full for a person who managing many computer's  connected via LAN , like in a internet cafe or training centers. The managing person can send message to the user about their time is over or any, and wait for their reply, if user refused or ignored , the manager can shutdown user's system from the server without reaching the user's PC. 
this projects developed in 32 bit VB6.
 Author: Cm.Shafi, Kuzhippuram
Email: cmshafi@yahoo.com
web: www.geocities.com/cmshafi