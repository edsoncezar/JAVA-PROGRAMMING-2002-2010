Tiny Server v1.0.5
By Saurabh

This is a very basic http server that as of now supports only the GET request. It also does not support any server side processing. This server can accept multiple requests at once. The server is only 44 kb. Currently the configuration section is not working. The default page and webpage directory can be configured by editing the server.ini file. The message window provides details of connections and errors if any. The server has been configured to accept a maximum of 100 connections. I have used the Winsock control in VB. I am providing the source code with this. The server can be used for testing websites on a local network before uploading to the Internet. This is the first version I am releasing, so I know there will be a lot of bugs. Feel free to write to me at saurabh@yep.com for bug reports and suggestions.

Features to be added future versions -
* CGI Support
* POST support
* Remote administration (Show or hide server, change config etc)
* Request Logging
