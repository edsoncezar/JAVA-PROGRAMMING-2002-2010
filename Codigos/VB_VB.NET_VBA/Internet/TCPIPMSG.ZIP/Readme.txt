--- (c) 1999 ---
Programmed By: FataLErroR
Date Released: 9-11-99
Version: 1.0

A Simple Network Instant Message Program written
with Winsock under Visual Basic 5.0

Any bugs/comments/questions/source code
Email: FataLErruR@hotmail.com

(WinSock and Visual Basic are trademarks of Miscrosoft(c))