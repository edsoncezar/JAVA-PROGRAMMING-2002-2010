ReadMe File For CpuUsage ver 1.00
---------------------------------
CpuUsage - utility to monitor system performances by moti bani     

1.
* All rights reserved - you may only use  this   software  for      *
* personal needs. Since This is a freeware you can use it at your   *
* own risk.The Author specifically disclaims all warranties,        *
* express or							    *
* implied, and all liability, including consequential and           *
* other indirect damages, for the use of this software,             *
* including liability for infringement of any proprietary           *
* rights, and including the warranties of merchantability	    *
* and fitness for a particular purpose.  The Author does not        *
* assume any responsibility for any errors which may                *
* appear in this software nor any responsibility to update it.      *

2.
This package include article from Microsoft(r) about
Win32 Application Programming Interface (API), that describe how to
access the Performance Registry 

3.
For bugs report or any comments or new ideas you can email me at :  
 - motibani@netvision.net.il           
 - mfc@hotmail.co.il
