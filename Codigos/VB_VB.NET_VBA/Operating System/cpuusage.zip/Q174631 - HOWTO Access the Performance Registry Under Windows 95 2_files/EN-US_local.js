var ToolBar_Supported = ToolBar_Supported ;
if (ToolBar_Supported != null && ToolBar_Supported == true)
{
	//To Turn on/off Frame support, set Frame_Supported = true/false.
	/* Code added below to test to see if this should be treated as being in a frameset or not (a-peterh)*/
	strQueryString = document.location.search;
	strQueryString = strQueryString.toUpperCase();
	if (strQueryString.indexOf("?FR=1") != -1 || strQueryString.indexOf("&FR=1") != -1)
		Frame_Supported = true;
	else
		Frame_Supported = false;


	// Customize default ICP menu color - bgColor, fontColor, mouseoverColor
	setDefaultICPMenuColor("#000000", "white", "red");

	// Customize toolbar background color
	setToolbarBGColor("white");

	// display ICP Banner
	setICPBanner("http://support.microsoft.com/library/images/support/pss_EN-US.gif","/isapi/gosupport.asp?target=/directory/default.asp","Microsoft Product Support Services") ;
	
	//***** Add ICP menus *****
	//Home
	addICPMenu("HomeMenu", "Home", "Support&nbsp;Home","/isapi/gosupport.asp?target=/directory/default.asp");
	addICPSubMenu("HomeMenu","Support&nbsp;Home","/isapi/gosupport.asp?target=/directory/default.asp");
	addICPSubMenu("HomeMenu","microsoft.com","/isapi/gomscom.asp?target=/");

	//Self Support
	addICPMenu("SelfSuppMenu", "Self Support", "Self Support","/isapi/gosupport.asp?target=/directory/self.asp?SD=GN");
	addICPSubMenu("SelfSuppMenu","Searchable&nbsp;Knowledge&nbsp;Base","/isapi/gokbsearch.asp?target=/kb/c.asp?ln=en-us");
	setICPSubMenuWidth("SelfSuppMenu","relative","0.7");
	addICPSubMenu("SelfSuppMenu","Download&nbsp;Center","/isapi/gomscom.asp?target=/downloads/search.asp");
	addICPSubMenu("SelfSuppMenu","FAQs&nbsp;by&nbsp;Product","/isapi/gosupport.asp?target=/directory/faqs.asp?SD=GN"); 

	//Assisted Support
	addICPMenu("AssistMenu", "Assisted&nbsp;Support", "Assisted Support","/isapi/gosupport.asp?target=/directory/getitem.asp?item=AD");
	addICPSubMenu("AssistMenu","Assisted&nbsp;Support&nbsp;Directory","/isapi/gosupport.asp?target=/directory/getitem.asp?item=AD");
	addICPSubMenu("AssistMenu","Online&nbsp;Support&nbsp;Requests","/isapi/gosupport.asp?target=/directory/getitem.asp?item=OS&SD=GN");
	addICPSubMenu("AssistMenu","Phone&nbsp;Numbers ","/isapi/gosupport.asp?target=/directory/getitem.asp?item=PH&SD=GN");

	//Custom Support
	addICPMenu("CustomMenu", "Custom&nbsp;Support","Comprehensive&nbsp;support&nbsp;customized&nbsp;by&nbsp;customer&nbsp;type","/isapi/gosupport.asp?target=/directory/customer.asp");
	//setICPSubMenuWidth("CustomMenu","relative","0.9");
	//addICPSubMenu("CustomMenu","Developers","/isapi/gosupport.asp?target=/servicedesks/msdn/default.htm");
	//addICPSubMenu("CustomMenu","IT&nbsp;Professionals","/isapi/gosupport.asp?target=/technet/support/default.htm");	//addICPSubMenu("CustomMenu","Resellers&nbsp;&amp;&nbsp;Consultants","/isapi/gosupport.asp?target=/servicedesks/directaccess/default.htm");
	//addICPSubMenuLine("CustomMenu");
	//addICPSubMenu("CustomMenu","MCSP","https://mcsp.microsoft.com/support");	
	//addICPSubMenu("CustomMenu","Computer&nbsp;Manufacturers","https://www.msbpn.com/oem/");	
	//addICPSubMenu("CustomMenu","Premier","https://servicedesk.one.microsoft.com/premier/");	


}




