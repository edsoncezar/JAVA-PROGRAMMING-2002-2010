
NAME: H.R. Renuka Prasad

     I developed this code on 6th Jan 2002
     
     This is my life first programme launching on the web

     This Programme  is totally FREE to use and  modify i.e. you can do
whatever you want with it. You do not need to mention my name or anything.
On the other hand, I would appreciate if you send me a feedback
to the following e-mail: polestar@rediffmail.com 

my web-site under construction
visit www.geocities.com/prarex

NOTE: IF YOU USE THIS CODE FOR COMMERCIAL POURPOUS THEN PLEASE 
SEND ME US $20.00 TO THE FOLLOWING ADDRESS:

   To
     H.R. RENUKA PRASAD
     #280, C-2, 2ND STAGE, 3RD PHASE,
     4 TH MAIN , 2ND CROSS
     B.D.A LAYOUT, DOMLUR
     BANGALORE
     KARNATAKA
     INDIA
     PINCODE -560071