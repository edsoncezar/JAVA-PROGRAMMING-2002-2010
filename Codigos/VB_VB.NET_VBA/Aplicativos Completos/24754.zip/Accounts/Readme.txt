				Accounting made simple
			----------------------------------------

Instructions:

1)	Double click on the accounts icon in the start menu

2)	You will be directed to a login screen. There are two users:
		
		i) Pumsman
		ii)Turf Squad
	The passwords for these respectivly are "shit" and 'muzik'.

3)