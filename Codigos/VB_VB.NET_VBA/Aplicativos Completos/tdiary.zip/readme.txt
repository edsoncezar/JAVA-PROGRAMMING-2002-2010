hi friends Sujit here

i hope u will find this program very useful and easy to use.
i know u r smart enough to figure out how to use it.
but there are some special aspects that may need a word of clarification.
this program was compiled using VISUAL BASIC 6.0
and it needs VISUAL BASIC 6.0 virtual machine
which is a dll (dynamic link library) named MSVBVM60.DLL.
u will need this dll to run this program.
furthuremore it requires Microsoft Jet Database Engine
to access the data stored in telephon.suj file.
This file is also required to run this program or this program will crash.
If u have Microsoft Access u have MS JET DBEngine already cauz access
also uses this dll for data access.

some limitations of the program

You can edit any field of record except Telephone Number cauz
this is primary key field. u know what it is if u have ever worked with
access. this field is used to sort and search through all the data in 
the database. if u want to modify the contents of telephone number 
field delete the whole record and then enter again the whole 
record. that's preety simple.


that's all.

the program is preety simple

i have locked the telephone number field so u will not be able to edit
this field in between. except u r entering a new record.
this field will be unlocked for that time.

click on new menu and fill in a new record
and when u r done click on the save button.
remember all other fields can be blank except telephone number.

select the record using the combo box field Name and
click on delete the record.

if u want to update a modified record click on update menu. 
or toolbar button.

in case u find any bugs or u have any comments. or if u do any
drastic changes or improvements in the basic structure of the app.
in that case plz mail me at sujit0@usa.net or 
visit my website: http://www.sujitonline.com

good luck
Sujit Manolikar 
my irc nick is _NoBody_      	you know that pals :)