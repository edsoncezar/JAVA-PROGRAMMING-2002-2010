/*******************
filename:	arr_test.c
author: 	sujit manolikar
date:		Wednesday, August 08, 2001
time:		9:17:58 PM
purpose:	test program for array handling functions declared in array.h
email:		sujitmanolikar@yahoo.com
website:	http://www.geocities.com/sujitmanolikar
******************/

#include <stdio.h>
#include "array.h"

int main() {
  int arr[5], i;
  int ops[] = { 12, 14, 142, 21 };
  int opers[] = { '+', '-', '*' };

  for (i = 0; i < 5; i++) {
    printf("enter value for element %d: ", i);
    scanf("%d", &arr[i]);
  }

  /* call the function that separates zeroes at the end of the array */
  sort_out_zeroes(arr, 5);

  for (i = 0; i < 5; i++)
    printf("%d\n", arr[i]);

  print_expression(ops, opers, 3);
  printf("\n");

  return 0;
}
