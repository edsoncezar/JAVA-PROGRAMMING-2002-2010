/*******************
filename:	array.h
author: 	sujit manolikar
date:		Wednesday, August 08, 2001
time:		9:12:55 PM
purpose:	file containing declaration of the functions for handling
		arrays in "expression evaluator"
email:		sujitmanolikar@yahoo.com
website:	http://www.geocities.com/sujitmanolikar
******************/

#ifndef ARRAY_H
#define ARRAY_H

void sort_out_zeroes(int array[], const int elements);

/* build the expression from the arrays of operands and operators */
void print_expression(const int operands[], const int operators[], 
		      const int n_operators);

#endif /* ARRAY_H */
