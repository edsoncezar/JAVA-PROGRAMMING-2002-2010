/********************
filename:        evaluate.h
author:          sujit manolikar
purpose:         contains declaration of a vital function that evaluates
                 expressions
date:            09-08-2001
time:            8:50 pm
email:           sujitmanolikar@yahoo.com
website:         http://www.geocities.com/sujitmanolikar
********************/

#ifndef EVALUATE_H
#define EVALUATE_H

void evaluate(int operands[], int operators[], int n_operators);
int urgent(int op1, int op2);
int is_operator_valid(int op);

#endif /* EVALUATE_H */
