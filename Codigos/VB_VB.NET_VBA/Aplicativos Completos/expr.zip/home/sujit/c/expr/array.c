/*******************
filename:	array.c
author: 	sujit manolikar
date:		Wednesday, August 08, 2001
time:		9:17:58 PM
purpose:	definition of the functions declared in array.h
email:		sujitmanolikar@yahoo.com
website:	http://www.geocities.com/sujitmanolikar
******************/

#include <stdio.h>
#include "array.h"

/*	sorts out zeroes that are set when the operation is performed on 
	operators and operands. check evaluate() to see the code
*/
void sort_out_zeroes(int array[], const int elements) {
  int i, j;

  /* check if there is any zero between two operands or operators */
  for (i = 0; i < elements; i++)
    if (array[i] == 0) /* if there is one */
      for (j = i + 1; j < elements; j++) /* loop for next valid operand */
		if (array[j] != 0) { /* and exchange it with that zero */
			array[i] = array[j];
			array[j] = 0;
			break; /* come out of the inner loop */
		}
}


/* rebuild the expression i. e. merge the operands and operators */
/* merging is not actually performed; just print them like that */
void print_expression(const int operands[], const int operators[], 
		      const int n_operators) {
  int i;

  for (i = 0; i < n_operators && operators[i] != 0; i++)
    printf("%d %c ", operands[i], operators[i]);

  /* operators are always more by 1 than operators */
  printf("%d \n", operands[i]);
}
