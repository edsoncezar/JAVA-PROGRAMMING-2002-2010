/*******************
filename:	expr.c
author: 	sujit manolikar
date:		Thursday, August 09, 2001
time:		9:06:33 AM
purpose:	main source file for the "expression evaluator"
email:		sujitmanolikar@yahoo.com
website:	http://www.geocities.com/sujitmanolikar
******************/

#include <stdio.h>
#include <stdlib.h>

#include "array.h"
#include "evaluate.h"

/* let's get jiggy with it :)) */
int main(int argc, const char *argv[]) {
  /* pointers to hold arrays of operators and operands */
  int *operands, *operators;
  int n_operators, n_operands; /* number of operators and operands */
  int i, j, k;

  if (argc == 1) { /* if no expression is passed on command line */
    printf("expression evaluator\n");
    printf("syntax: expr <expression>\n");
    printf("e. g. expr 12 + 18 \"*\" 50 / 2\n");
    return 0;
  }

  /* argc should be even for obvious reasons */
  /* e. g. expr 12 + 12 : argc = 4, expr 12 + 12 / 2 : argc = 6	*/
  /* but expr 12 + : argc = 3, which is of course an invalid expression */
  if (argc % 2 != 0) {
    printf("syntax error!\n");
    return -1;
  }

  /* calculate how many operands and operators are there in expression */
  /* so that we can allocate exact amount of memory to hold them */
  n_operands = argc / 2; /* quite obvious just take any example in mind */
  n_operators = n_operands - 1; /* this is too */

  /* allocate memory */
  if (! (operators = (int *) malloc(sizeof(int) * n_operators))) {
    printf("memory allocation failed!\n");
    return -1;
  }

  if (! (operands = (int *) malloc(sizeof(int) * n_operands))) {
    printf("memory allocation failed!\n");
    free(operators);
    return -1;
  }

  /* parse the command line for operands and operators */
  for (i = 2, j = 0, k = 0; i <= argc; i++)
    if (i % 2 == 0) /* args whose index is even number is an operand */
      operands[j++] = atoi(argv[i - 1]);
    else /* or it's an operator */
      if (is_operator_valid(argv[i - 1][0]))
	operators[k++] = argv[i - 1][0];
      else {
	printf("invalid operator\n");
	return -1;
      }

  /* evaluate the expression */
  evaluate(operands, operators, n_operators);

  /* free the allocated memory */
  free(operators);
  free(operands);

  return 0;
}
