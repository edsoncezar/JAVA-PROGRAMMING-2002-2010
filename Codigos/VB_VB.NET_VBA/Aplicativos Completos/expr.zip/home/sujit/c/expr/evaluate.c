/********************
filename:         evaluate.c
author:           sujit manolikar
purpose:          definition of the functions declared in evaluate.h
date:             09-08-2001
time:             9:00 pm
email:            sujitmanolikar@yahoo.com
website:          http://www.geocities.com/sujitmanolikar
********************/

#include <stdio.h>
/* #include <math.h> */

#include "array.h"
#include "evaluate.h"

#define MAX_OPERS 6 /* number of operators */

/* symbol table for the program. contains allowable operators */
static const int symtab[] = { '/', '%', '*', '^', '+', '-' };

/* is the given operator valid? */
int is_operator_valid(int op) {
  int i;
  for (i = 0; i < MAX_OPERS; i++)
    if (op == symtab[i])
      return 1;

  return 0;
}

/* compute the n ^ p */
int pow(int n, int p) {
  int power = 1;

  while (p >= 1) {
    power *= n;
    p--;
  }

  return power;
}

/*	decide whose precedence is more between two operators
	it uses a very simple logic.

	if both the operators are same, it doesn't matter which is evaluated first
	so simply return 1.
	else scan the symbol table each time checking if any one of the specified
	operators is encountered. if yes return the appropriate value.
*/
int urgent(int op1, int op2) {
  int i;

  if (op1 == op2)
    return 1;

  for (i = 0; i < MAX_OPERS; i++)
    if (op1 == symtab[i])
      return 1;
    else if (op2 == symtab[i])
      return -1;
}

/*	this is the core recursive function of the program
	it accepts array containing operands, operators and number of operators
	and returns the value after evaluating the expression

	it uses a very simple logic
	it performss the most urgent operation to be performed
	and calls it self recursively
*/
void evaluate(int operands[], int operators[], int n_operators) {
  int most_urgent = 0; /* index of most urgent operator in the array */
  int i;

  /* is the operators array empty? */
  if (operators[0] == 0) {
    return;
  }

  /* calculate the most urgent operation to be performed */
  for (i = 1; i < n_operators || operators[i] != 0; i++)
    if (urgent(operators[most_urgent], operators[i]) == -1)
      most_urgent = i;

  switch (operators[most_urgent]) {
  case '+':
    /* store the result in the first operand itself and set the
	   second operand and operator to 0; so we can later remove it
	   using sort_out_zeroes() function
    */ 
    operands[most_urgent] += operands[most_urgent + 1];
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

  case '-':
    operands[most_urgent] -= operands[most_urgent + 1];
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

  case '/':
    operands[most_urgent] /= operands[most_urgent + 1];
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

  case '*':
    operands[most_urgent] *= operands[most_urgent + 1];
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

  case '%':
    operands[most_urgent] %= operands[most_urgent + 1];
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

  case '^': /* power computation */
    operands[most_urgent] = pow(operands[most_urgent], operands[most_urgent + 1]);
    operands[most_urgent + 1] = operators[most_urgent] = 0;
    break;

    default:
    printf("invalid operator\n");
    return;
  }

  /* sort out operators and operands who have been used and set to zero */
  sort_out_zeroes(operands, n_operators + 1);
  sort_out_zeroes(operators, n_operators);

  /* print the expression again to be a little verbose */
  print_expression(operands, operators, n_operators);

  /* make a recursive call to evaluate */
  evaluate(operands, operators, n_operators);
}
