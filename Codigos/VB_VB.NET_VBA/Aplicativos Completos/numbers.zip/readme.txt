		----THIS IS A BETA VERSION----

Zip file contains:

readme.txt	:	this document

numbers.dll 	:	dll compiled from numbers.c
libnumbers.a	:	import library for GNU C Compiler to link with 
			numbers.dll

numbers.h	:	header file for the exported functions
numbers.c	:	the only source file for the dll
numbers.def	:	definition file for the functions exported from dll

makefile	:	makefile for the GNU Make

test.c		:	a test program for the dll

This dll was compiled with mingw32 compiler,
which is a port of the original GNU C compiler (gcc).
but because this is written in ANSI C it will compile 
on any compiler without much efforts. 
I have also tested this using Borland Free C++ Compiler 
but not that thoroughly.

Dll exports functions such as ReverseNumber, 
CountDigits which you can call from your application 
or dll, that's why i call it a NUMBER CRUNCHING LIBRARY. 
That's all, also read the NUMBERS.C file even if you 
don't intend to modify the code. which has valuable 
comments on how to call functions and other details.

You are likely to find bugs in this dll cause i have 
not thoroughly tested it. some functions may even have 
serious bugs or may not work correctly at all. i have 
already found a couple of such bugs. i am onto them. 
after all this is just a beta version. 
all the functions are not documented completely. 
so you will have to figure out what is happening 
yourself. i found it urgent to fix the serious bugs 
rather than documenting the working functions.

in case of any bugs and comments feel free to 
email me at:

		sujit0@usa.net
also keep looking at http://www.sujitonline.com for future updated versions.