#include"numbers.h"
#include<stdio.h>

/*this is just a test program for the numbers.dll*/
int main() {
	ulong number = 012345, outnum;

	/* ReverseNumber() Demo */
	printf("number before ReverseNumber() = %ld\n", number);
	outnum = ReverseNumber(number);
	printf("number after ReverseNumber() = %ld\n", outnum);
	
	/* ExchangeDigits() Demo */
	printf("number before ExchangeDigits() = %ld\n", number);
	outnum = ExchangeDigits(number, 4, 2);
	printf("number after ExchangeDigits() = %ld\n", outnum);
	
	/* CountDigits() demo */
	printf("number passed CountDigits() = %ld\n", number);
	outnum = CountDigits(number);
	printf("total digits in number = %ld\n", outnum);
	
	return 0;
}