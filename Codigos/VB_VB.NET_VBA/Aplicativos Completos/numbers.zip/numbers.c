/*******************
filename:	numbers.c
author: 	sujit manolikar
date:		30-10-2000
time:		9:11:14 AM
purpose:	main source file for the "numbers.dll".
email:		sujit0@usa.net
website:	www.sujitonline.com
******************/

/*
i actually wanted to write a permutation library. i am still working on it,
but the functions in the same file began to create "code bloat" so i 
decided to write this dll so that i will be concentrated on the permutation
library itself and it will cut down the complexion dramatically. and it 
worked. i wrote this dll to be used by another dll called "permute.dll"
which permutes the number passed to it. but this dll can also be used by
another applications or dll's.

WARNING:
	this library works with only unsigned numbers (specially unsigned long)
	do not try to pass signed numbers to the functions in this library,
	forget the floating point numbers
	otherwise the functions may behave incorrectly	
*/

#include"numbers.h"

/*function prototype of the functions that are not listed in numbers.h*/
/*this function is not exported from the dll*/
ulong Raise(ulong num, uint power);


/*
function name:		CountDigits
function purpose:	counts the digits in the given number
					e. g. CountDigits(3456) will return 4

algorithm:
	any number divided by 10 looses it's last digit in C. 
	e. g. 123 / 10 = 12, 456 / 10 = 45;
	function goes on loosing digits and incrementing counter until
	the number becomes zero, and returns the counter which is the number
	of digits in the number
*/
uint CountDigits(ulong num) {
	uint count = 0;

	while (num != 0) {
		num /= 10; /*divide number by 10 so it will loose one last digit*/
		count++;
	}
	return count;
}


/*
function name:		Raise
function purpose:	raises the given number to the given strength
					e. g. Raise(2, 4) will return 16

algorithm:
	function goes on multiplying the given number with itself for
	the given power or given times and collecting the value in temp
	then returns the temp
*/
ulong Raise(ulong num, uint power) {
	int i;
	ulong temp = 1;

	/*error checking*/
	if (num == 0 || power == 0)
		return 0;
	
	for (i = 1; i <= power; i++)
		temp = temp * num;

	return temp;
}


/*
function name:		GetDigit
function purpose:	function returns digit in given number which is at the
					given position
					e. g. GetDigit(456, 2) will return 5

algorithm:
	
*/
uint GetDigit(ulong num, uint pos) {
	/*get total number of digits in number*/
	uint digits = CountDigits(num);

	/*error checking*/
	if (num == 0 || pos == 0 || pos > digits)
		return 0;


	/*check if the digits is not equal to pos
	if yes then last digit is asked so skip the divide operation*/
	if (digits != pos)
		num /= Raise(10, digits - pos);

	return num % 10;
}


/*
function name:		ExchangeDigits
function purpose:	exchanges digits in number passed by their positions
					in passed number 
					e. g. ExchangeDigits(1234, 1, 3) returns 3214

algorithm:
	
*/
ulong ExchangeDigits(ulong num, uint pos1, uint pos2) {
	uint digits = CountDigits(num); /*total number of digits in passed num*/

	/*for the digits on the passed number*/
	uint digit1, digit2;
	ulong m1, m2; /*for the multiples of the both digits*/

	/*error checking e. g. wrong argument passing*/
	if (pos1 == pos2 || num == 0 || pos1 == 0 || pos2 == 0 || pos1 > digits || pos2 > digits) 
		return 0;


	/*extract the actual digits from the original number*/
	digit1 = GetDigit(num, pos1);
	digit2 = GetDigit(num, pos2);

	/*calculate the multiples of 10 according to places*/
	m1 = Raise(10, (digits - pos1));
	m2 = Raise(10, (digits - pos2));

	/*now the actual exchange takes place*/
	/*code is preety confusing, not for me of course*/

	num -= digit1 * m1;
	num += digit2 * m1;

	num -= digit2 * m2;
	num += digit1 * m2;

	return num;
}


/*
function name:		GetNumberToLeftOfPos
function purpose:	returns the number to the left of given position
					in a given number
					e. g. GetNumberToLeftOfPos(123, 3) returns 12

algorithm:
	
*/
ulong GetNumberToLeftOfPos(ulong num, uint pos) {
	ulong retnum = 0, mul = Raise(10, pos - 2);
	int i;

	/*error checking*/
	if (num == 0 || pos == 0 || pos > CountDigits(num))
		return 0;

	
	for (i = 1; i < pos; i++) {
		retnum += GetDigit(num, i) * mul;
		mul /= 10;
	}

	return retnum;
}


/*
function name:		GetNumberToRightOfPos
function purpose:	returns the number to the right of a given position
					in a given number
					e. g. GetNumberToRightPos(123, 3) returns 3

algorithm:
	
*/
ulong GetNumberToRightOfPos(ulong num, uint pos) {
	uint i = pos, digits = CountDigits(num);
	ulong retnum = 0, mul = Raise(10, digits - pos);

	/*error checking*/
	if (num == 0 || pos == 0 || pos > CountDigits(num))
		return 0;


	while (i <= digits)	{
		retnum += GetDigit(num, i++) * mul;
		mul /= 10;
	}

	return retnum;
}


/*	
function name:		InsertNumber
function purpose:	inserts given number in between the given number
					at a given position
					e. g. InsertNumber(1234, 3, 54) will return 125434
algorithm:
	
*/
ulong InsertNumber(ulong num, uint pos, ulong insertnumber) {
	/*for the digits to push to left after insertion*/
	ulong leftnumber = GetNumberToLeftOfPos(num, pos);
	ulong rightnumber = GetNumberToRightOfPos(num, pos);
	
	ulong retnum; /*return value*/
	uint digits = CountDigits(rightnumber);
	ulong raisenum = Raise(10, digits);
	
	/*error checking*/
	if (num == 0 || pos == 0 || pos > digits)
		return 0;
	
	
	retnum = insertnumber * raisenum + rightnumber;

	digits = digits + CountDigits(insertnumber);
	raisenum = Raise(10, digits);

	retnum += (leftnumber * raisenum);

	return retnum;
}


/*
function name:		DeleteDigit
function purpose:	deletes a single digit from given number at given pos
					e. g. DeleteDigit(7689, 2) will return 789

algorithm:
	
*/
ulong DeleteDigit(ulong num, uint pos) {
	ulong rightnumber = GetNumberToRightOfPos(num, pos + 1);
	ulong leftnumber = GetNumberToLeftOfPos(num, pos);
	ulong retnum; /*number to return*/
	ulong raisenum = Raise(10, CountDigits(num) - 2);

	/*error checking*/
	if (num == 0 || pos == 0 || pos > CountDigits(num))
		return 0;


	retnum = leftnumber * raisenum + rightnumber;

	return retnum;
}


/*
function name:		ReverseNumber
function purpose:	function reverses the given number
					e. g. ReverseNumber(123) will return 321

algorithm:
	function first counts the total number of digits in digits variable,
	the it raises 10 to the power of total digits - 1
*/
ulong ReverseNumber(ulong num) {
	uint digits = CountDigits(num);
	ulong multiple, retnum = 0;
	uint digit;

	/*error checking*/
	if (num == 0)
		return 0;
	
	multiple = Raise(10, digits - 1);

	while (num > 0) {
		digit = num % 10;
		retnum += digit * multiple;
		num /= 10;
		multiple /= 10;
	}

	return retnum;
}