/*check if the file has not been declared earlier*/
#ifndef NUMBERS_H
#define NUMBERS_H

typedef unsigned int uint;
typedef unsigned long ulong;

/*declarations of all the functions*/
uint CountDigits(ulong num);

uint GetDigit(ulong num, uint pos);
ulong ExchangeDigits(ulong num, uint pos1, uint pos2);
ulong DeleteDigit(ulong num, uint pos);
ulong GetNumberToLeftOfPos(ulong num, uint pos);
ulong GetNumberToRightOfPos(ulong num, uint pos);
ulong InsertNumber(ulong num, uint pos, ulong number);
ulong ReverseNumber(ulong num);

#endif /*NUMBERS_H*/
