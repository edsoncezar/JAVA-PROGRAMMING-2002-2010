HyperLink ActiveX Control

This is a very simple ActiveX control written in 
VB 6.0. This simulates HyperLink in web browsers. 
You might have seen many applications offering some 
such links in the about box of the application. 
Coding that is very simple. All you
have to do is call a Win32 API named ShellExecute with
the site name as argument and the shell will redirect
the url to the browser or anything as per your system.
but why code it again 
and again just use this ActiveX control whenever you 
want to add links to your about box or anywhere else.

how to use:

just drag the control onto your form. set the Text 
property and URL property of the control to whatever
you want. run the application. that's it. the control
also raises one event viz. Click. which occurs after
the control has called the ShellExecute. just in case
you want to do anything other. you will also find a
test project in the zip file. check it out.

if you don't want the sources then copy hlink.ocx file
into your system directory and register that ocx file.
that you can do with regsvr32 or from within the VB IDE.
(Who doesn't know that!!!)

that's it.

if you have any comments or encounter any bugs then
please let me know.

my email address is: root@sujitonline.com
and my home site is: http://www.sujitonline.com

or you can try to contact me online on IRC. my IRC nick
is _NoBody_