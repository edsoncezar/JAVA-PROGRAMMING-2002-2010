Data-Flow Visual Programming Language
Open Source ! Visual Basic Free Code !
version 1.881

web:
         http://www.emu8086.com/vb/

email:
         info@emu8086.com


VISUAL BASIC FREE CODE
======================

This code is for Visual Basic 6.0 or up.

To avoid errors, open "TZGroup.vbg"  !

and not "*.vbp" files !!

There are two project in this group.


THE PURPOSE
===========

Data-Flow Visual Programming Language allows
to run basic algorithms in a visual way. All you
have to do is to place program blocks on screen,
connect them with lines (arrows) and run. You
can also run it in step by step mode (when
delay is set to maximum).


DISTRIBUTION
============

Program is FREE to distribute on any
kind of media without modifications.


END USER LICENSING AGREEMENT
============================

This program is FREEWARE!

THIS SOFTWARE IS PROVIDED AS-IS, WITHOUT
WARRANTY OF ANY KIND. THE AUTHOR SHALL NOT
BE HELD LIABLE FOR ANY DAMAGE TO YOU, YOUR
COMPUTER, OR TO ANYONE OR ANYTHING ELSE,
THAT MAY RESULT FROM ITS USE, OR MISUSE.

Special thanks to Yuri Margolin !


CONTACT
============================
web: http://www.emu8086.com/vb/
email: info@emu8086.com



Alexander Popov Emulation Soft (C) 2002-2003 All rights reserved.
http://www.emu8086.com/vb/
