Program:
TextEd

Author:
Sanjay Karsan

Contact:
sankalpha@hotmail.com

Program Info:
This Program Is A Simple Text Editor, With Advanced Features.