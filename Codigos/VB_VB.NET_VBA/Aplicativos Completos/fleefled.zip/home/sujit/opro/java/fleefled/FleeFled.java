/*******************
filename:	FleeFled.java
author: 	sujit manolikar
date:		Sunday, December 30, 2001
time:		10:44:43 PM
purpose:	main source file for the FleeFled game
email:		sujitmanolikar@yahoo.com
website:	http://www.geocities.com/sujitmanolikar
******************/

import java.awt.*;
import java.applet.*;
import java.awt.event.*;

//FleeFled game
public class FleeFled extends Applet implements ActionListener {
	
	//buttons, labels, textfields, etc
	private Button Matrix[][], Restart;
	private Label lblOn, lblOff, Message;
	private TextField txtOn, txtOff;

	//this method counts how many buttons are On i.e. red in color
	private int countOn() {
		int i, j, count = 0;

		for (i = 0; i < Matrix.length; i++)
			for (j = 0; j < Matrix.length; j++)
				if (Matrix[i][j].getBackground() == Color.red)
					count++;
		return count;
	}

	//this method toggles color of a given button
	private void toggleColor(Button b) {
		if (b.getBackground() == Color.black)
			b.setBackground(Color.red);
		else
			b.setBackground(Color.black);
	}
				

	public void init() { //create everything and display it
		int i, j;
		Matrix = new Button[5][5];
		
		txtOn = new TextField(2);
		txtOn.setText(Integer.toString(0));
		
		txtOff = new TextField(2);
		txtOff.setText(Integer.toString(25));
		
		lblOn = new Label("Lights On");
		lblOff = new Label("Lights Off");
		Message = new Label("         ");

		Restart = new Button("Restart");
		
		Restart.addActionListener(this);
		
		//create a 5 X 5 matrix of buttons
		for (i = 0; i < Matrix.length; i++)
			for (j = 0; j < Matrix.length; j++) {
				Matrix[i][j] = new Button(" ");
				Matrix[i][j].setBackground(Color.black);
				add(Matrix[i][j]);
				Matrix[i][j].addActionListener(this);
			}
		
		//add additional controls
		add(lblOn);
		add(txtOn);
		add(lblOff);
		add(txtOff);
		add(Restart);
		add(Message);
	} //end of init()

	public void actionPerformed(ActionEvent ae) {
		int i, j;
		
		//this sets Matrix[][] to initial configuration; all "F"
		if (ae.getSource() == Restart) {
			txtOn.setText(Integer.toString(0));
			txtOff.setText(Integer.toString(25));
			
			for (i = 0; i < Matrix.length; i++)
				for (j = 0; j < Matrix.length; j++)
					Matrix[i][j].setBackground(Color.black);

			//empty message so that alignment isn't disturbed
			Message.setText("              ");
		}
		
		//compute the index of Button that was clicked
		for (i = 0; i < Matrix.length; i++)
			for (j = 0; j < Matrix.length; j++) {
				if (ae.getSource() == Matrix[i][j]) {
					toggleColor(Matrix[i][j]); //change the color
					
					//change the color of adjacent buttons also
					//but after checking the boundries
					if (i < 4)
						toggleColor(Matrix[i+1][j]);
					
					if (j < 4)
						toggleColor(Matrix[i][j+1]);

					if (i > 0)
						toggleColor(Matrix[i-1][j]);
					
					if (j > 0)
						toggleColor(Matrix[i][j - 1]);
				}
			}

		int On = countOn();
		
		//update the display
		txtOn.setText(Integer.toString(On));
		txtOff.setText(Integer.toString(25 - On));

		if (On == 25) //if all the buttons are red, user has won
			Message.setText("Congratulations!");
		
	}
}

//<applet code=FleeFled height=275 width=125></applet>
