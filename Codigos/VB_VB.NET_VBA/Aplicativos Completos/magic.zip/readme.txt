Hi

Ever wanted to hide windows you did not want you boss/parents to
see while u r working(or playing!!!),magic windows let's u hide/unhide windows with
ease.Just a simple program which made me realise that windows os though the best
desktop os in the market is hardly any good when it comes to security.Please do send me your comments at 
venky_dude@yahoo.com

bye
venky

 