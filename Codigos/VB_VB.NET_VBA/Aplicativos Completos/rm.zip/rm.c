/*
author:		sujit manolikar
filename:	rm.c
date:		Saturday, March 10, 2001
time:		4:34:25 PM
purpose:	main source file for the rm.exe utility

bugs, comments:	sujit0@usa.net
website:		www.sujitonline.com
*/

/*
features:

overcomes the dos "del" command which can delete only one file at a time
"rm" can delete multiple files given on command line
wildcards also accepted
tested with Turbo C++ 3.0 for dos
*/

/*
portability:

completely written in ANSI C so will not cause porting problems,
all you have to do is just include proper headers as per ur OS and change
the way finding of files is done. e.g. on linux you may want to use 
functions like opendir(), closedir() etc. or on Win32 you may want to use
direct API's as FindFirst(), FindNext() etc. 

didn't find any time to port this on linux... sorry
*/

/*
revision:

file exclusion facility added, which can exclude particular file names
especially while using wild cards from the file list to be deleted
e.g. at prompt you might say --> 

			rm *.jpg *.bmp -e myown.bmp mygirl.jpg

this will delete all bmp and jpg files except myown.bmp and mygf.jpg
WARNING: you CAN'T use wildcards in the exclusion list

date:		Friday, March 16, 2001
time:		4:31:43 PM
*/

/*
wishlist:

i wish adding wildcard functionality in the file exclusion list
e. g. you might then say -->
		
		rm *.* -e *.txt *.imp

this will delete all the files except all the .txt and .imp files
*/

#include<stdio.h>
#include<errno.h>
#include<dir.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

/*declare the functions*/
void delfile(const char filename[]);
int isexcluded(const char filename[], int argc, const char *argv[]);
int exlist_index(int argc, const char *argv[]);


int main(int argc, char *argv[]) {
	int i;
	/*point where the deletion list ends i. e. at "-e" flag*/
	int dellist_end;
	
	struct ffblk findinfo; /*structure for findfirst()*/

	/*show the program information is no file is specified at prompt*/
	if (argc <= 1) {
		printf("Sujit file deletion utility\n");
		printf("syntax: rm <file list> -e <exclusion list>\n");
		printf("e.g. rm temp.txt unused.exe\n");
		printf("e.g. rm *.txt -e imp.txt useful.txt\n");
		return 0;
	}

	dellist_end = exlist_index(argc, argv);
	/*loop for each file name on command line*/
	for (i = 1; i < dellist_end; i++) {
		/*find the first file with findfirst()*/
		if (findfirst(argv[i], &findinfo, 0)) {
			printf(argv[i]);
			printf(": no such files found.\n");
		} else {
			if (! isexcluded(findinfo.ff_name, argc, argv))
				delfile(findinfo.ff_name);
			else {
				printf(findinfo.ff_name);
				printf(": skipped, file is in the exclusion list.\n");
			}

			/*loop for more files with findnext()*/
			while (! findnext(&findinfo)) {			
				if (! isexcluded(findinfo.ff_name, argc, argv))
					delfile(findinfo.ff_name);
				else {
					printf(findinfo.ff_name);
					printf(": skipped, file is in the exclusion list.\n");
				}

			} /*while (!findnext()*/
		} /*else*/
	} /*for (i = 1; i <= del_end -1... */
	return 0;
}


/*
function name:		delfile
function purpose:	actually deletes files on the hard drive
					e. g. delfile("c:\unused.txt") will delete unused.txt
					on root directory

algorithm:
	calls remove macro to delete the file, remove sets the errno if it
	detects any error while deleting file, function checks if the errno
	is set, if yes then it displays appropriate messages on screen
*/
void delfile(const char filename[]) {
	if (remove(filename) == 0) { /*file deleted successfully?*/
		printf(filename);
		printf(": deleted successfully.\n");
	}
	else {
	   /*print messages as per errno set by remove()*/
	   switch (errno) {	
			case ENOENT:
				printf(filename);
				printf(": file does not exist.\n");
				break;

			case EACCES: 
				printf(filename);
				printf(": file is probably locked. access is denied.\n");
				break;
		}
	}
}


/*
function name:		isexcluded
function purpose:	checks if the file is in the exclusion list 
					returns true if file is in the exclusion list
					or false if it isn't in the exclusion list
					e. g. isexcluded("sujit.txt", argc, argv) will return
					true if the sujit.txt is in the exclusion list 
					i. e. after the "-e" flag

algorithm:
	function first gets the index in the argv[] where exclusion list
	begins i. e. after "-e" flag by calling "exlist_index" function
	then it goes on comparing the filename passed to it with all the
	files in the exclusion list untill the end of the argv[] if it detects
	a matching filename in the exclusion list it returns true else false
*/
int isexcluded(const char filename[], int argc, const char *argv[]) {
	int ex_index = exlist_index(argc, argv);
	int i;

	/*check if the file is included in exclusion list*/
	for (i = ex_index; i < argc; i++) {
		if (strcmpi(argv[i], filename) == 0)
			return TRUE;
	}
	return FALSE;
}


/*
function name:		exlist_index
function purpose:	returns index in argv[] from where exclusion list 
					starts	i. e. the point where it detects "-e" flag

algorithm:
	function parses the command line i. e. argv[] checking for exclusion
	and returns the index after it detects the "-e" flag or it just returns
	argc because the return value is used for finding files 
	see function main() above
*/
int exlist_index(int argc, const char *argv[]) {
	int i;
	for (i = 1; i < argc; i++) {
		if (strcmpi(argv[i], "-e") == 0) /*point on exclude list starts*/
			return i;
	}
	return argc;
}