/*
  test suit for the input() function which take input of a matrix
  and output() function which outputs a matrix i. e. prints it on screen
*/
#include <stdio.h>

#include "matrix.h"

int main() {
  order morder = { 3, 3 };
  int matrix[3][3];

  input(&matrix[0][0], morder);
  output(&matrix[0][0], morder);

  return 0;
}
