/*
  test suit for the multiply() function defined in mult.c which multiplies
  two matrices
*/

#include <stdio.h>
#include "matrix.h"

int main() {
  /* orders of the two matrices */
  const order ord1 = { 2, 3 }, ord2 = { 3, 2 };

  /* actual matrices */
  int mat1[ord1.rows][ord1.cols], mat2[ord2.rows][ord2.cols];

  const order res_order = { 2, 2 }; /* order of the resultant matrices */
  int result[res_order.rows][res_order.cols];
  
  input(&mat1[0][0], ord1);
  output(&mat1[0][0], ord1);

  input(&mat2[0][0], ord2);
  output(&mat2[0][0], ord2);

  multiply(&mat1[0][0], ord1, &mat2[0][0], ord2, &result[0][0]);
  output(&result[0][0], res_order);

  return 0;
}
