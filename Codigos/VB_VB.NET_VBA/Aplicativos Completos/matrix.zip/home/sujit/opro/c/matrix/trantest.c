/* test suit for the transpose() function */

#include <stdio.h>
#include "matrix.h"

int main() {
  order ord = { 3, 3 };
  int matrix[3][3];

  input(&matrix[0][0], ord);
  output(&matrix[0][0], ord);

  printf("computing the transpose...\n");
  transpose(&matrix[0][0], &ord);
  output(&matrix[0][0], ord);

  return 0;
}
