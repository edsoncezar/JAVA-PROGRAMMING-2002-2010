/*
   implementation of all the arithmetic functions on matrices
   such as add(), subtract(), etc, declared in matrix.h
*/

#include "matrix.h"

/* adds two matrices into third one, all matrices should be of equal order */
void add(const int *mat1, const int *mat2, int *result, order morder) {
  int i, j, sub;

  for (i = 0; i < morder.rows; i++)
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      result[sub] = mat1[sub] + mat2[sub];
    }
}

/* subtracts second matrix from first and stores result in *result* matrix */
/* all matrices should be of equal order */
void subtract(const int *mat1, const int *mat2, int *result, order morder) {
  int i, j;

  /* as we need to access a matrix, which is a two dimensional array in C,
     through a pointer to the address of the first element i.e. [0][0]
     element we need to compute the address of the [i][j]th element
     in reference to the pointer to the first element
  */
  int sub;

  for (i = 0; i < morder.rows; i++)
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      result[sub] = mat1[sub] - mat2[sub];
    }
}

void multiply(const int *mat1, order ord1, const int *mat2, order ord2,
	      int *result) {
  int i, j; /* array indices */
  int k;
  int element; /* product of rows and cols will be summed up in this */

  /* check if the two matrices can be multiplied or not.
     matrices are subject to multiplication iff
     first matrix's cols = second matrix's rows
  */
  if (ord1.cols != ord2.rows)
    return;

  for (i = 0; i < ord1.rows; i++)
    for (j = 0; j < ord2.cols; j++) {
      element = 0;
      for (k = 0; k < ord1.cols; k++)
	element += mat1[ord1.cols * i + k] * mat2[ord2.cols * k + j];

      result[ord2.cols * i + j] = element;
    }
}
