/*
  test suit for the add() function which adds two matrices
*/
#include <stdio.h>

#include "matrix.h"

int main() {
  const order morder = { 2, 3 };

  /* matrices needed for addition */
  int mat1[morder.rows][morder.cols];
  int mat2[morder.rows][morder.cols];
  int result[morder.rows][morder.cols];

  input(&mat1[0][0], morder);
  output(&mat1[0][0], morder);
  printf("\n");

  input(&mat2[0][0], morder);
  output(&mat2[0][0], morder);
  printf("\n");

  /* add the two matrices and store the result into result[][] matrix */
  add(&mat1[0][0], &mat2[0][0], &result[0][0], morder);
  output(&result[0][0], morder);

  return 0;

}
