Hi

IENanny lets u block any website locally allowing you to restrict people from going to sites 
u don't want them to go.It uses Api functions to detect whether IE is running and when an un authorised site
is visited it goes to the default page nope.htm .To block a site just add the site to the list box
for example if u want to block access to all of yahoo's site just enter yahoo.com. Or if u want to block only the chat stuff
just enter chat.yahoo.com .Please leave your comments 
and suggestions.It will be very useful for me to further develop this program

 
bye
venky

 