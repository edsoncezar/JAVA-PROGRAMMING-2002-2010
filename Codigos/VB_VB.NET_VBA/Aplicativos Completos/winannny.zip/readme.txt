Hi People
Welcome to Website Downloader . Just enter the  URL  of the   website  you  want  to download and all the links in the webpage will be downloaded including any image files . The program is still in the development stage .In order for the software to work copy the gif89.dll into the windows\system directory,go to the dos prompt and chage to window\system directory and register the dll by typing the foll at the dos prompt Regsvr32 gif89.dll.Please report all bugs and suggestions regarding this software to venky_dude@yahoo.com.I would really appreciate any comments/suggestions regarding this program.

Updates in this version

U need not type in the whole url i.www.xyz.com will do
u can select the type of files you want to download
u can select how many files you want to download.
U can download asp files.

