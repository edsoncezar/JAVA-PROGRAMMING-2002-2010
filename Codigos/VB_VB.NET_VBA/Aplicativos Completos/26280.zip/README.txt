FacuzSkinMaker v1.0.1

This great code creates Winamp 2 Skins with a lot of effect, 
in some easy steps.
You can load your favourite image in BMP,JPG,GIF,WMF or EMF format, 
make your skin with rounded corners or transparent, 
change colours, fonts and cursor pointers and more!



if you like this code, for any question & suggestion
please-please-please write me!

e-mail: facuz@email.it
http://members.xoom.it/fakuz