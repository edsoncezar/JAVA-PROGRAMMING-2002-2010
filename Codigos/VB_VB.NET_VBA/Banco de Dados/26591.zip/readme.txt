Periodic Table of the Elements v1.0

This program is a simple example of an application of the ADO data control provided with Visual Basic 6. The Source code can be used in other projects, but please do not directly modify the contained project or database file in anyway. I spent an hour making the database!

If you have any problems or spot a bug with the program, please email me at joshuamanson@clear.net.nz with details abou the problem or bug, and what you did to find the bug so I can post a fix.

Thankyou for downloading!

joshuamanson@clear.net.nz