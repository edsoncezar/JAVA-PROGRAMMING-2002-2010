'*************************************************************************************
'Project Summary -- LoginDemo
'*************************************************************************************
' This form is a part of a project I wrote for my freinds for their project work. I will
' upload the complete project after their exams are over (for obvious reasons!)...
'
' Actually its a Cyber Cafe Management Program Project. This particular form was meant
' for login for the customers registered in cyber cafe. When customers put in their login
' details , they are checked to the Customer table in the table. If their info are matched
' then they are logged in and a browser window opens and a timer is started which calculates
' how much time they use the internet.And the billing is done accordingly.
' Well here the Web Browser and billing form is not present as this just a demo to
' How to check login details with Access and VB.
'
' You can replace the Exit button with a New User Button which will help the user to
' create a new User.
'
' The code is free for you to modify, copy , distribute .. But dont use it for Aircraft
' flying or something .. :-) just joking....
'
' This code is meant for a tutorial on VB's strengths and I hope you 'll find it helpful.
' Please send me comments on my page ie:
'
' www.programmersheaven.com/shahab
'
' Ok bye now ...
' S Shahab Jafri
'
' By the way some valid CustIds and Passwords are as follows'
'____________________
' CustId   | Password
' ___________________
' 1        | espn   |
' 2        | cool   | 
' 3        | Zenith |
' ___________________ 
'
' You can find them in the Customer table.
