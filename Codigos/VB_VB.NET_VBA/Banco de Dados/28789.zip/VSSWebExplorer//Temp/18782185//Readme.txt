1) Register IASPParser2.dll on your machine
2) Run Parser.exe
3) Select the DSN from menu
4) DSN must be  of MS SQL server
5) ENter File Name in the  text box
6) Click Parse