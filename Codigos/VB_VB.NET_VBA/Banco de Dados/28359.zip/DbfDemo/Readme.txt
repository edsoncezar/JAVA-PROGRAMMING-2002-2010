Extract the file into 
C:\Program Files\Microsoft Visual Studio\VB98\DbfDemo
and double click on the dbfDemo.vbp file
