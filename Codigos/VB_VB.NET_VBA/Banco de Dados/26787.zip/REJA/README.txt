REJA Version 1.00 (video rental application)

FEATURES
* a web page like design
* a voice guide (Johnny)
* background sounds (midi)
* precise search result(s)
* auto-update rental service
* auto-fix runtime errors
* built in security alarm
* program blocking (when incorrect password (3x))
* can access Windows Calculator (calc.exe) and Notepad (notepad.exe) for computations and writing notes

IMPORTANT
* recommended screen area (1024 by 768)
* stored photos shouldn't be deleted











R - aphael Martin
E - nrico Lorenzo
J - ade Juliano
A - iza Belarmino