VB FILE LISTER For Windows 95/NT
---------------------------------

YOU MUST HAVE VISUAL BASIC 4.0 OR HIGHER INSTALLED ON YOUR MACHINE FOR THE APPLICATION
 TO RUN

Here is a simple little program that Microsoft must have forgot
to put in Visual Basic 4.0.  I created it because Visual Basic has 
a poor source printout capability.  This program will read and produce 
a nice formatted listing of any Visual Basic .frm or .bas source file


TO INSTALL THIS PROGRAM
------------------------------------------
1) Unzip the LIST.ZIP file onto your hard drive

2) Run LIST.EXE to start the program

3) I have included the project source in case you want to modify the program.
  You must use the visual basic 4.0 32 bit compiler for this program to compile
 properly.
 


THIS PROGRAM IS VERY SIMPLE TO USE
----------------------------------------------------------
1) Run the program

2) Check the indent box if you want VB File Lister to peform it's automatic formatting
 of your source or leave it blank if you want to list the source as it was keyed.

3) Next, key in the VBP File name.  For example, if your project file is LIST.VBP,
 then key in LIST This is optional.  You may leave it blank.

4) Finally, find the source file that you want to print and select it using the mouse.

5) THAT'S IT!  it should print to your default windows printer.