
VB-6.0 (PRINTfrm) For Windows 95/98/NT (& Win XP ??)	Ver. 1.01.0001
-----------------------------------------------------------------------------------------

	This program was originally called VB FILE LISTER. It is the original source code
	for the "PRINTfrm" program which has been greatly modified for VB Ver 6.0.
	See original "README-org.txt"

-----------------------------------------------------------------------------------------

	Have you ever wanted to print just a portion of your source code
	for trouble shooting?

	Have you ever wanted to label each page with program's name source file, with date
	and time plus date and time printed with page no.?

	Well, here it is!

	The following must be the 1st four characters on any line.

	To break up the source code into logical pages;
	insert ('***) at a place of your choice, usually before a subroutine
	before the line count reaches 68.

	Place ('---) to inhibit printing usually on a line by itself.

	Place ('+++) to re-enable printing usually on a line by itself.

	Placeing ('---) on line by itself with out a following line ('+++)
	will skip remainder of source code printout.


	Added title printout with print date & time for each page. VER. 1.0.8
	Added a no print routine to inhibit printing between '--- and '+++. VER. 1.01.0001

YOU MUST HAVE VISUAL BASIC (6.0) OR HIGHER INSTALLED ON YOUR MACHINE FOR
THE APPLICATION TO RUN. (Do not know about eariler versions.)

This program will read and produce a listing of a ver.6.0 Visual Basic .frm source file.
(Do not know about eariler versions.)

****************************************************************************************

TO INSTALL THIS PROGRAM
	Unzip the (PRINTfrm.ZIP) file onto your hard drive

THIS PROGRAM IS VERY SIMPLE TO USE.

1) Edit your source code using the above '***, '---, '+++.

2) Run the program PRINTfrm.EXE.

3)Click on PRINT SUBS & FUNCTIONS to toggle yes or no. (default = NO)

4) Using the mouse, select the drive letter,
   then the folder of your VB program that you want to print.

5) Finally, select the program.frm file that you want to print using the mouse.

6) THAT'S IT!  it should print to your default windows printer.



README-FIRST.TXT	' VER. 1.01.0001         01/MAY/03
