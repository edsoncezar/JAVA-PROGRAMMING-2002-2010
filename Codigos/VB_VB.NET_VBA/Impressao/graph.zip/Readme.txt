

Purpose :

Make a graph from database record and either send it to a printer 
directly selecting many print options or copy it in any file on disc.
This project also gives you print preview option for A4 size paper and
you can set your graph anywhere on the page.Also if you want to change
graph's height or width you can change.Zooming effect is also given 
using hsrollbar.

Disclaimer :

This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form and modify it but please
mention me if you make any other modification so that i will have a chance
to share our knowledge.You can reach me at

 umesh909@yahoo.com
