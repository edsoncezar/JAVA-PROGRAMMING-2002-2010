I was looking for a good print preview module
in anywhere, but I didn't find it. Therefore I decided
to write my own routines.
The result is this PrinterEx class that can be 
embedded in any other project.

Features includes see in the sample. 
You can add to your report images, graphs, tables.



I you have any improvement or idea for the component
let me know and I'll try to incorporate it.
Thanks.

Khachatryan Ashot
XAshot@yahoo.com