'    =======================================
'    Ping Pong with Artificial Intelligence
'    =======================================
'
'
'    IMPORTANT: open "Group.vbg"
'          (Visual Basic Group Project), because
'           there are 2 projects.
'
'
'    Play against human or computer opponent.
'    Artificial Intelligence is emulated by
'    your computer, it is possible to make
'    computer to play against itself.
'
'    Multiple number of balls can be used in
'    a game (up to 7 balls).
'
'    Use [A]-[Z] to control left player's bar,
'    and [']-[/] to control right player's bar.
'
'    Screen-shot: AEPong.gif
'
'
'    Visit my Homepage:
'    http://www.geocities.com/emu8086/vb/
'
'
'    Last Update: Saturday, July 20, 2002
'
'
'    Copyright 2002 Alexander Popov Emulation Soft.
'               All rights reserved.
'        http://www.geocities.com/emu8086/
