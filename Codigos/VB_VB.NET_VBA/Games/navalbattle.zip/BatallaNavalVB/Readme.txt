The Naval Battle game's source code. It was coded with Visual basic 6 by Pablo Ignacio M�rquez. The sorce code is freeware, do whatever you want with it ;).

You can contact me at gulfas_morgolock@hotmail.com.



 