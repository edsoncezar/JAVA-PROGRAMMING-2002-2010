
**********************************************
		TICTACTOE
	By Barima Kwarteng
**********************************************

This is a freeware program and is free for
modification.

email address: amirabj@yahoo.com
mail box : Barima Kwarteng
	   P.O.Box 1477
	   Tema,Ghana(West Africa)
