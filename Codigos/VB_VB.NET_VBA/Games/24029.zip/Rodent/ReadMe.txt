Readme.txt

Welcome to Rodent's Revenge 2000 programmed
	 by James Emmrich:
http://www26.brinkster.com/jemmrich
         and Alexander Popov:
http://www.geocities.com/emu8086/


The Basics:
The point of the whole game is to turn all cats into cheese 
and then eat the cheese to get points. Once done, a new wave of cats
appear and each wave increasing by one cat. To turn the cats 
to cheese, you must block all cats on all their 8 sides using the 
pushable bushes. When a cat has been trapped, they go to sleep. 
Careful though, untrapping a cat will make him active again! Every 
15 moves the cats make the player gets five points, and for each 
cheese eaten, the player gets a cool 50 points!

After all five waves have been completed you will move onto a new
game field to play on which is not yet been finished. Each new field
increases the difficulty and introduces new obstacles too!


Current Features:
* The first wave of cats is playable - each wave has 10 cats
* User can set levels of difficulty - Snail, Slow, Medium, 
  Fast, Blazing, and Suicide
* Player has only three lives
* High Scores!

Features Comming Soon:
* Mouse traps!
* Ball of purple yarn!
* If player sits to long (to reap rewards) more cats will join! :)
* Automatic Field Generation!!!
* Tiles will not be "hard coded"!
* Compiled help on how to play - with strategies!
* Improved Cat AI!!

Final Notes:
This game has been tested on Windows XP.
It most likely will work on all modern and
previous versions of windows.

Please report bugs!!
