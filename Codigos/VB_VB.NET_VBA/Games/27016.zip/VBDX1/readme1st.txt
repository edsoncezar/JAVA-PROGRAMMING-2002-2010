****READ ALL OF ME***
   title: VBDX
  posted: by william quincy on or about 06APR03
   email: info@williamquincy.com
web site: www.williamquincy.com(follow the links
          to vbstuff and other freestuff)
    desc: Updated version of VBDX(1.0.0)
          The reason that this is Version 1.0
          is that modVBDX is now well tested
          and acceptible to be beyond Beta. 
          That does not mean that it has no bugs
          or that it lacks room for improvement.
          It is still and always will be a WIP.
          Please be sure to read ReadMe.txt in
          this directory.

          I think that I am giving you some
          good stuff here. But if you do not
          read all of the documentation then
          you may not be able to get it fully.
          Please read everthing. I know I can 
          get long winded and it is a lot to
          read through, but it will be worth it.

