Welcome to the read me file for VBDX version 1.0

I know that I can get long winded so I'll try not to this time. Please read this entire file though. I may save you some time.
If you like also read thegame.txt and QandA.txt

CONTENTS

   I. Why
  II. New to version 1.0
 III. The shell
  IV. The game
   V. Coding conventions
  VI. TODO's and future plans

I. Why
The purpose of VBDX was to help my nephew to learn programming and game programming. That is why VBDX and VBDXtut exist. He quickly lost interest in programming. Oh, well. But, I was just playing around with the library one day and decided that it was pretty good for quick little 2-D games. So, I thought that I would start using it. What I wanted was a skeleton template that I could just plug stuff into. So that is what it is.

II. New to version 1.0
I have made changes to modVBDX. The changes are backwards compatible(I think) so if you are already using it then you can just replace the file and go.

The changes are as follows:

Create surface subs now sets colorkey automatically to magenta. You can still set it to black if you want, by calling SetTransColor. But, if you want magenta then you can omit the call.

In VBDXtut I used the Win32 function Sleep. Sleep is kind of prone to locking up the system. So I added the sub MyWait.

I also added the ability to get keypresses as strings. Look in GameMain sub HighScoreInputName to see an example of use.

I added the sub lngGetFPS it supercedes GetFPS and you should use it from now on. GetFPS is still there so you won't need to change existing code.

Other changes
When I use OOP I rate how well designed an object is by encapsulation and its independence. The objects that come with VBDX are not scoring well by that standard. Some require other objects and some require VBDX. Some can be used in any DirectX project some can only be used with VBDX.

clsBitmapFont and clsDXSprite can both be used only with VBDX. You can make them independent by passing a RECT and replacing rClipRect with it. Now, you pass a surface to their draw method. This is a lot better. Because you can always just draw a different surface for different reasons. For example, the menu in the game shell has a red font. If you put the mouse pointer over a menu then it is green. You just change the surface that is blt'ed from. This would also be good if you had different enemies that all had the same attributes. Also, this way it saves memory. IF YOU HAVE ALREADY BEEN USING EITHER CLASS YOU WILL NEED TO CHANGE YOUR CODE. Sorry, bout that. But, I had to change all my code as well. The reason they were the way they were before was to make it easy for my nephew. That is no longer an issue. They are still very easy to use anyway. You have to do a little more work setting them up and shutting them down, but they are better.

Also, added are modExplosions, modMenu, and modHUD. modMenu, and modHUD depend on clsBitmapFont, and can be used only with VBDX, unless you alter the classes. modExplosions depends on clsDXSprites and can be used in any DirectX project. I will leave it up to you to figure out how to use them. I think that they meet my goals quite well in that they are very easy to use.

GameMain is also improved. Now it has the menu, game frame, HUD, high score, and credits already built in. You can easily customize them to suit your needs.

frmScreenShot is a quick and easy screen capture device. It depends on VBDX but can be made more independent simply by passing a directX surface to the sub.

modPlayer1 is for the game only and not considered part of the game shell. The way you got it, it can be fairly easily altered. But, I suggest you start from scratch.

III. The shell(P.S. disreguard this-game shell is in ..\template)
The shell is in GameMain. I wanted to distribute the shell and the game. But, in the interest of size I am releasing only the game. Before you do anything you should copy every thing to another folder and strip out the stuff about Player1 so that you just have the menu, HUD, empty game loop, high score and credits. Then you can use that as a template. When you make a game just customize the menus and stuff and plug you game code into Do_Frame. I'm sorry that you have to do this but I tried to keep what you got as small as possible and still give example of how to use some of the features of VBDX.

IV. The game
Don't have much here yet. The first thing you get is the splash screen. It asks for Windowed mode and if you want to use vidmem. Then you have the menu. modMenu Menus are easy, look at the code. If you select play. Then you will get "little man". You can walk him left or right with the arrow keys. Make him jump by pressing the space bar. Press 'B' to fire a grenade. If you fire a grenade you get 10 points. This is so you can test high scores. The HUD is displayed. And you can use the mouse pointer and click on little man to hurt him. Notice that his health meter is actually a string. The characters in the bitmap for '#','$', and '%' are replaced with the meter image. Press 'S' to take a screen shot.

Don't forget to play around on the ice.

V. Coding conventions
I started out not following my usual conventions. And now I have to try and phase them in as I modify and improve things. So, this is what I usually follow and what future versions of the game and library will(attempt) to follow.

1.)Hungarian notation
   long        lng
   single      sin
   integer     int
   byte        byt
   string      str
   arrays      [typ]ar example: bytar is an array of bytes
   UDT/class   example: clsDXSprite would be spr

2.)naming
I try to use descriptive names no matter how long it is. The length of a name does not effect anything in the compiled exe, so I see no point in using abbreviated names.

When naming subs, functions and class methods I do it like this ExampleFunction(). You will find some of the subs in VBDX use _ to separate words. That is from when it was a class module and I used to name methods like this: Example_Method, and member vars like this: m_intVar. I don't do that any more.(the _ is too much extra typing. Lazy, huh?)

Sometimes, if the return type of a function is important I will do this lngExampleFunction() As long. But, I only do it if it seems important. I should get off the fence and either do it or not.

When a function will fill an arguments value I prefix the argument with RET and explicitly declare pass by reference. That is something I'm just starting. ExampleSub(byref RETintVar as integer) 

I also try to stick to for loops, and will occasionally use Do While loops. I seldom touch other types of loops.

I try to keep code as simple as possible. Most of the code is If statements, for loops, and switch statements. I will rarely attempt to "get fancy" with VB. It would defeat the purpose of BASIC, imho.

I use global variables a bit excessively. But if I follow Hungarian notation, good naming, and plan things out well I never have problems from it.

I only use goto for error trapping.

I will have 100 exits from a sub if it makes things easier.

VI. TODO's and future plans
I would like to make the library better. But, don't know when I will work on it. It definatly, at least, needs a blit flip(mirror) function.(did it last minute see clsDXSprite)

The rest of what I will work on is the game. By working on it I will add components to the library. Like maps, messages, ect.

I would like to gather a collection of GPL and public domain art work and sounds.

One of the reasons I distribute this is to get you to contribute, as well. With maybe hundreds of people working on the library and games then in no time it could be really great. So, whatever else is added is highly up to you. E-Mail me with changes you make. I assume that williamquincy.com will be the place of offical release. But, if some one wants to assume the reponsible of deteriming what will make it to the offical release and make thier site the offical site, let me know. I just need to know that you will keep it the offical site for as long as people use it.
