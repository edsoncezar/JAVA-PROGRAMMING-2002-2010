ReadMe.txt for VBDX

'**********************************************
'IMPORTANT-
'READ ALL TEXT FILES FULLY
'including last minute changes.txt
'**********************************************

I have been seen around Linuxland since Christmas(mostly playing with KBASIC). But, I am home now, as of 24Mar03. What is in this package is what I have updated since then. Note, that I had planned on uploading the contents of the .\GameDemo directory before I had the map editor and tile engine. But, I had a few days of free time and couldn't stop working(well playing). So, the Beta release of the tile engine is also here. Remember that it is very early. But, that is kind of good because you can get in at ground floor and take it from there to get exactly what you want.

Here is how the directory is set up.

VBDX1(main)
.clsBitmapFont.cls(major update-does not maintain backwards compatibility-sorry)
.clsDXSprite.cls(major update-does not maintain backwards compatibility-sorry)
.clsMap.cls(the new map class)
.DXSMP3.cls
.modHighScore.bas(no longer a class)
.modMenu.bas(new easy to use game menu screen)
.modVBDX.bas(minor updates-maintains backwards compatibility)
.modHud.bas(new easy to use HUD)
.modExplosion(new reusable explosion-for VBDX only-will require changes for other DX project)
.frmScreenShot.frm(new quick and dirty screen shot device)

All of these files are the VBDX 'core'. What I used to do was just copy all of this around to where I had projects. But, now I have a lot of VBDX projects. So, obviously I had to stop that and put some order into my chaos. What I do now is create sub directories here and put my projects in there. Then, I add these files to my project. (I know, I should have been doing that all along.) I suggest that you do the same. Just remember not to make game specific changes to VBDX core files. And as you change them run and test your other projects.

Then there is also the sub directories. They are GameDemo, MapDemo, Mapeditor. Each has it own documentation. Please read all of it, as it will save you some time and frustration.  The documentation in GameDemo discusses changes to VBDX. Start with GameDemo. When you feel like you understand it well, then look at MapEditor. Definatly read its documentation. Then, go on to MapDemo.

You will also find .\template. That is a mostly empty game shell. With menu, HUD, and high score built in. Use it as a template to start a new project.

And, finally, there is .\modCard. It is a GDI card library and has nothing to do with VBDX. It is the best designed card library I have. But, make sure you read its documentation .

P.S.
I'm not making any promise, but because a lot of people downloaded the first release, I want to make a proper reference for VBDX, in html format. So, check my site in a while to see if I have it.

Thank you.
