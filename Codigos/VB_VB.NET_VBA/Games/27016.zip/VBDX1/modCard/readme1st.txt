   title: modCard
  posted: by william quincy on or about 31MAR03
   email: info@williamquincy.com
web site: www.williamquincy.com(follow the links
          to vbstuff and other freestuff)
    desc: An easy to use bas file for making
          card games. I know most of you won't
          but do your self a favor and read
          AboutmodCard.txt for more info.
          This is a work in progress.
 license: GPL