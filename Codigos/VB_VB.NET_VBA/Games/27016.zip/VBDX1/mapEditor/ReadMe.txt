VBDX tile engine(class clsMap)
Be sure to read about the editor in editor.txt.

NOTE for clarification: When I say tile I mean a tile in the map. When I say cell I mean a rectangular region in a bitmap or direct draw surface that represents a tile.

This just describes the map class. The way it is designed is that you can have as many layers as you want. Each layer has its own DirectDrawSurface, and the bitmap, for the surface, MUST BE 10 CELLS WIDE.(If you have more than ten cells) For example, if your tile size is 32x32 then the bitmap must be 320 pixels wide. If you only had two cells, for example, then make the bitmap 64x32. CELLSPERROW is a constant in the class that you can change or add it to the layer UDT.

If you have only one layer then the map class is quite fast. If you have more it is still fast. The way, I think, it will be used the most is either, one layer maps or three layer maps. On a three layer map you will have layer 0 as a parallax layer, as the sky, for example. Layer 1 will be the main layer. And layer 2 will be the topmost layer. Layer 2 will draw over the sprites making it appear as if they are behind it.(you achieve this by drawing layer1, then draw the sprites, then draw layer2.-ofcourse)

If you make the 0th layer a parallax background, then make the tile large like 320x240, maybe larger even. The tiles, on any level can be any size, within reason. They must be > 4x4. Who would have tiles smaller than that anyway? Most tile engines restrict you to tile sizes of powers of 8. Not this. You can have your tile 53x72 if that's what you want. Make sure that the maps dimensions are at least the size of the map rect(i.e. tile width(height) * map width(height) > map rect width(height)). If it is not, the engine will still function but will start drawing the map again from the top or left edge, until it fills map rect.

It will be best if you do stick to powers of 8 though. Also, the larger the tiles the faster it will be. I think that for all but the parallax layer you should use 32x32 or 64x64. 64x64 is a bit faster, but rather large for a resolution of 640x480.

If you make a three layer map and have the parallax layer tiles large and have the third layer with a limited number of tiles that exist, then three layers is not much different, speed wise, than a single layer map. If you make a simple platform game, like Mario, so that mostly the parallax layer is drawn then you will get a very fast map.

Also, for extra speed get two variables that define what is on the screen and only do collision detection and AI and stuff on objects that are on the screen.

About the SetMapRect method. You pass it width and height. This is so you can leave an area to the right or below the map for drawing stats or what ever. The top and left corner of the map is always the top left corner(0,0) of the primary surface. However, I was thinking ahead. If you look at the code you will find that there is a RECT that defines the map rect. What you can do, and I will for a future release, is add the ability to set the top and left properties of the rect. Then you can make a split screen multiplayer game. You will have to  alter the entire class by adding the top and left to any code that deals with position. For example Xoffset will always have to have map rect .left added to it. But, once it is implemented it will be cool. And very easy to make split screen multiplayer games.

I think that this is a very fast tile engine, for VB, and it is still early. After we fix it up and develop it further, it will be excellent. I think we are heading in the right direction and I am happy with what we've got thus far.
-----------------------------------------

Preliminary file format

intNumberOfLayers As Integer
layLayers() As layer

that's it. When we save, we write number of layers, then we just write layLayers().
------------------------------------------

Preliminary class and UDT's

Private Type MapTile
   intNumber As Integer
   intSpecial1 As Integer
   intSpecial2 As Integer
   intSpecial3 As Integer
   intCollision As Integer
   boolColorKey As Boolean
   boolVisible As Boolean
   boolExists As Boolean
End Type

First of all, this needs to be public in a bas file so that each loop we can just call one method that returns an entire tile. Instead of calling all the Get and Set methods one at a time.

intNumber:
is the cell number from the image

intSpecial1, 2, and 3:
intSpecial1 will be used enemy start point (1-99) will be reserve for just that. 1 will be player start. 2-99 will be enemies. Any number above 99 can be used for anything. Except 1000. Which is used for animated tiles. If intSpecial1 is 1000, then call AnimateTiles(). It will increase the intNumber member + 1. Until it is above the number of frames, in the animation, as specified in intSpecial3. Then it will go back to the first frame, as specified in intSpecial2. So to make an animated tile that starts a tile 16 and has four frames set tile like this. intNumber = 16: intSpecial2 = 16: intSpecial3 = 3(four frames): intSpecial1 = 1000.(look for the torch in Castle1.qmap in the editor to see animated tiles).

The values can be any legal integer. I suggest you use the same value to mean the same thing every time. Make a bas file and define constants like this: ICE = 100: HURTPLAYER = 101: ect. Then, in the editor,  put 100 in intSpecial1 and the friction differential in intSpecial2. You get the idea.

You can do almost anything. Write a function called DoSpecialTile(or something). You can model it after the AnimateTile method. Or, for things like ice and damage player that will be used in most games, go ahead and add the code directly to the AnimateTile  method. Then it will be automatic in every game. But, you could make magnets, propellers, fuel stations, lights(if we ever get a good lighting engine going), whatever your mind can think of.

(I used to have a great dynamic lighting engine in a C dll. I can�t find it. But, I can tell you this, DON�T bother writing one using VB. You could make one. And get fairly good results, but not great(not good enough for more than one, very small light on the screen at once). I promise. If you think that that is incorrect, then PLEASE prove me wrong.)(I don�t want to discourage anyone. I think you should write a dynamic lighting engine.)

intCollision:
I haven't written the collision code yet, but this is what I am planning. Actually, the collision code should be game specific, so I may not add it to the class. Notice, that the map editor only sets to all or none. So change it if you need to.

0=none; 1=left; 2=top; 3=right; 4=bottom 5=all 6=TopLeft to BottomRight diaganol; 7=TopRight to BottomLeft diagonal.

boolColorKey:
If we want transparent tile.

boolVisible:
Should we draw this tile. This is different from boolExists uses more memory but will be faster. May remove this.(P.S. this was a part of the initial design and I have made the tile engine a lot differently than I have in the past. I am leaving it, though. Because, you can have a tile that exists, and therefore effects our Virtual World, but can't be seen.)

boolExists:
Does it exist.


Private Type layer
   lngTileSizeX As Long
   lngTileSizeY As Long
   lngWidth As Long
   lngHeight As Long
   lngPixelWidth As Long
   lngPixelHeight As Long
   XOffset As Long
   YOffset As Long
   OnScreenX As Long
   OnScreenY As Long
   lngScrollSpeed As Long
   boolParrallax As Boolean
   mtileTiles() As MapTile '2d array
   strImageFileName As String
End Type

lngTileSizeX and lngTileSizeY are width and height of tile, in pixels.

lngWidth and lngHeight are width and height of the layer, in tiles.

lngPixelWidth  and lngPixelHeight are the width and height of the layer, in pixels. They will be calculated when map is loaded.

XOffset and YOffset is what pixel in the layer is at 0,0 of screen.

OnScreenX and OnScreenY are placeholders for the number of tiles that fit on the screen. They will be filled when we load a map. And make the code a lot faster.  

lngScrollSpeed tells how fast the layer scrolls. I think if it is negative it will scroll the wrong way, but, I haven't tested it. It might just mess up. I don't think it should.

boolParrallax (see, I have two r's, not going to bother fixing it now.) This is for parallax scrolling. If it is true then the scroll map methods will roll over to 0 when the edge of the map is reached. If it is false then the scroll methods will stop at the edge of the map.


mtileTiles() array of tiles.

strImageFileName file name of bmp. example use "xxx.bmp" This is the name of the file to create the surface with.

Read the class file for all the methods the most important ones to start with are the draw, scroll, animate, load and save, and the set map rect methods.
