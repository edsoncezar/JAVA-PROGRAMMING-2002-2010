<NOTE: THIS TEXT IS ALSO IN COMMENTS IN THE MAIN FORM'S CODE>

 ****************************************
 * Brad's Card Demo                     *
 * by: Brad B., Jr.                     *
 * comments? -->  bradb_jr@hotmail.com  *
 * **************************************
 
    This card demo/tutorial covers most of the major things
    you might need when beginning a new card game.
 
    Each card in the deck(s) is stored in an array
    called TheDeck(416). The 416 allows for up to
    eight decks to be used. I don't use TheDeck(0)
    so that recalling the cards is easier to uderstand.
 
    I don't include more than what I have for a very
    specific reason. Each card game has it's own set
    of rules. If I give you too much, then my tutorial
    becomes useless because you will have to sift through
    too much information to get to the core of a card game
 
    That core is all I included in the tutorial...
        1. How to call the Cards.dll/Cards32.dll
        2. How to use the functions in the .dll file
        3. How to initialize your deck(s)
        4. How to shuffle cards
        5. How to draw, flip, and invert cards on a form
    One major thing that I didn t include is
        1. How to find out which card is clicked.
        I didn't include this because it is totally
        dependant on the positioning and offset of
        the cards on the form. However, here is a brief
        description of how to do it:
            In the Form_MouseDown event you use the X and Y
            values to locate where the mouse is. You will use
            the location of your hand and your offset to find
            out if a card was clicked and which card that was.
 
            For some games, you might not even need to check
            which card was clicked. For example, I am currently
            working on a BlackJack game that I use command buttons
            to control Hit/Stand/Deal/Quit and I never once have to
            click a card.
 
 -------------------------------------------------------------
 
    Here is a description of the functions in the dll
    cdtInit - This function initializes the deck
        FORMAT FOR USAGE:
           cdtInit cWidth, cHeight
        EXPLANATION:
            doing this will store the width and height of
            the cards in cWidth and cHeight respectively.
            These values are good for the MouseDown events.
            You would use them to help determine which card
            is being clicked.
 
    cdtTerm - This function Terminates the .dll
        FORMAT FOR USAGE:
            Private Sub Form_Unload
                cdtTerm
            End Sub
        EXPLANATION:
            this function in used simply to release the
            memory being used by the program. The "Format
            For Usage" section shows this function in the
            Form_Unload sub because that is the most common
            and best place for it.
 
    cdtDraw - Draw cards at default size
        FORMAT FOR USAGE:
            cdtDraw Me.hdc, X, Y, cardnumber, howtoshow, bgcolor
        EXPLANATION:
            this function draws the card[cardnumber] in the position
            on the form that you specify[X,Y], with the background
            color you prefer[bgcolor - generally it's vbWhite]. The
            howtoshow is 0 if you are showing the face, 1 if you are
            showing the back, and 2 if you are showing the face inverted.
 
    cdtDrawExt - Draw cards at variable sizes
        FORMAT FOR USAGE:
            cdtDrawExt Me.hdc, X, Y, dx, dy, cardnumber, howtoshow, bgcolor
        EXPLANATION:
            this function is exactly the same as cdtDraw, except that
            you can change the dimensions (height and width) of the card
            using the dx and dy values.
 
 
    Thank you for using my Demo,
    Brad