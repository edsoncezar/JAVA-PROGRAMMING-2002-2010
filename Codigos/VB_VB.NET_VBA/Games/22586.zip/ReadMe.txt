'    =======================================
'           Solve a picture Puzzle
'    =======================================
'
'
'    IMPORTANT: open "Group1.vbg"
'          (Visual Basic Group Project), because
'           there are 2 projects.
'
'
'    This game allows you to select any picture
'    from your hard-drive, divide it into specified
'    number of pieces. Your mission is to make this
'    image back. A simple puzzle game, you know for
'    for kids :)
'
'
'    Screen-shot: puzzle.gif
'
'
'    Visit my Homepage:
'    http://www.geocities.com/emu8086/vb/
'
'
'    Last Update: Saturday, July 20, 2002
'
'
'    Copyright 2002 Alexander Popov Emulation Soft.
'               All rights reserved.
'        http://www.geocities.com/emu8086/
