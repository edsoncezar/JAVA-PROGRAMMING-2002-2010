'    =======================================
'            On-Screen Ping Pong
'    =======================================
'
'    This is an two player ping-pong. Play
'    ping pong among all other windows
'    on your system. Use [A]-[Z] to control
'    left player's bar, and [']-[/] to control
'    right player's bar.
'
'    Visit my Homepage:
'    http://www.geocities.com/emu8086/vb/
'
'
'    Last Update: Saturday, July 20, 2002
'
'
'    Copyright 2002 Alexander Popov Emulation Soft.
'               All rights reserved.
'        http://www.geocities.com/emu8086/
