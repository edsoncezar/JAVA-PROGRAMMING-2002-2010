=======================================
 Boulder Dash returns in Visual Basic!
=======================================

This is an educational Boulder Dash clone.

The purpose of the game is to make a word
by moving letter blocks. You can also
eat diamonds. There are stones to
make your mission harder.


There are two projects in this pack:

   BOULDER.VBP   - the game.

   EDITOR.VBP     - level editor.


Bolder Dash Homepage:
http://www.geocities.com/emu8086/vb/


Last Update: Thursday, July 04, 2002


Copyright 2002 Alexander Popov Emulation Soft.
           All rights reserved.
    http://www.geocities.com/emu8086/



