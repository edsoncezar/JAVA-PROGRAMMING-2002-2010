Linked List Library for Visual Basic

Instructions:
1. Extract LinkedList.cls and Node.cls to your program's project directory
2. Click Project -> Add Class Module from the Menu of Visual Basic
3. Click Existing and choose the file

Repeat step 2 and step 3 above until all the two files(LinkedList.cls and Node.cls) are added to your project.



Author: Alvin Lau
Homepage: programming.freewebspace.com
Email: alvinlau1175@hongkong.com