This example shows you how you can implement the 'Queue' dat structure in VB.
It contains the CQueue class that works with Variant data type but to speed up
your applications you should change this class by changing the Variant to
Long/String/.... or what you'll need. Use it for free and give it for free to
every one who needs it. :-)