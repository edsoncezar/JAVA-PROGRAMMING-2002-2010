This example shows how you can read properties of an array
that are not available from VB with tools VB gives us.
The CArrayProperties class can be used to create other classes
to access data directly in memory. This will speed up your
applications and you'll be able to write some sort/merge/search/copy
functions that will help your programming.