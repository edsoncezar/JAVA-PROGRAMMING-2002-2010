// Desktop.cpp: implementation of the CDesktop class.
//
//////////////////////////////////////////////////////////////////////
/**********************************************************
*
*	File:								DESKTOP.CPP
*
*	Description:				Implementation of the CDesktop class
*
*	Author/Programmer:	�ke Strandberg	
*	
*	Last modified: 			18/1-2003		
*
*                             
*	=============================********====================
*										   C++
*	================************=============================	
*             
* ===========*****=========================================	
*						Copyright � 2000-2003.  �ke Strandberg
************************************************************/

// Custom includes
#include "stdafx.h"
#include "Desktop.h"


/****************** Construction *************************************************/
CDesktop::CDesktop():	m_ZERO(TEXT("0")),
											m_SUBKEY_TILEWALLPAPER( TEXT("TileWallpaper") ),
											m_SUBKEY_WALLPAPERSTYLE( TEXT("WallpaperStyle") ),
											m_SUBKEY_WALLPAPER( TEXT("Wallpaper") ),
											m_HKEY_CURRENT_USER_SUBKEY(TEXT("Control Panel\\Desktop"))
{
	
	this->m_bIsOldSettings=FALSE;
	
} // CDesktop::CDesktop()
/**********************************************************************************/

/************* Destruction*********************************************************/
CDesktop::~CDesktop()
{

	// Free memory
	DELETE_ARRAY(this->m_szOldWallpaper);
	DELETE_ARRAY(this->m_szOldWallPaperStyle);
	DELETE_ARRAY(this->m_szOldTileWallPaper);

} // CDesktop::~CDesktop()
/***********************************************************************************/



BOOL CDesktop::GetWindowsRegister(VOID)
{
	HKEY hKey			=	NULL;
	DWORD dwType	= 0; 
	DWORD dwSize=	0; 
	DWORD dwDisposition=0;

	if(RegCreateKeyEx(	HKEY_CURRENT_USER, 
									m_HKEY_CURRENT_USER_SUBKEY, 
									0, 
									NULL, 
									REG_OPTION_NON_VOLATILE, // default
									KEY_CREATE_SUB_KEY | KEY_ALL_ACCESS, 
									NULL, 
									&hKey, 
									&dwDisposition) != ERROR_SUCCESS) return FALSE;
	
	
	// Get size
	if( ::RegQueryValueEx(hKey,
												this->m_SUBKEY_WALLPAPER,NULL,
												&dwType,
												(LPBYTE)NULL,
												&dwSize) != ERROR_SUCCESS) return FALSE;

	// Clean up
	DELETE_ARRAY(this->m_szOldWallpaper);
	// Allocate buffer
	m_szOldWallpaper = new TCHAR[dwSize];

	// Get bitmap path and filename
	if( ::RegQueryValueEx(hKey,
												this->m_SUBKEY_WALLPAPER,NULL,
												&dwType,
												(LPBYTE)this->m_szOldWallpaper,
												&dwSize) != ERROR_SUCCESS) return FALSE;

	


	// Get size
	if( ::RegQueryValueEx(hKey,
												this->m_SUBKEY_TILEWALLPAPER,NULL,
												&dwType,
												(LPBYTE)NULL,
												&dwSize) != ERROR_SUCCESS) return FALSE;
	
	// Clean up
	DELETE_ARRAY(this->m_szOldTileWallPaper);
	// Allocate buffer
	m_szOldTileWallPaper = new TCHAR[dwSize];

	// Get data
	if( ::RegQueryValueEx(hKey,
												this->m_SUBKEY_TILEWALLPAPER,NULL,
												&dwType,
												(LPBYTE)this->m_szOldTileWallPaper,
												&dwSize) != ERROR_SUCCESS) 	return FALSE;
	



	if(IsOsMinWin98OrMinWinnt5())
	{
		// Get Sizeof buffer
		if( ::RegQueryValueEx(hKey,
													this->m_SUBKEY_WALLPAPERSTYLE,NULL,
													&dwType,
													(LPBYTE)NULL,
													&dwSize) != ERROR_SUCCESS) return FALSE;


		// Clean up
		DELETE_ARRAY(this->m_szOldWallPaperStyle);
		// Allocate buffer
		m_szOldWallPaperStyle = new TCHAR[dwSize];

		// Get data
		if( ::RegQueryValueEx(hKey,
													this->m_SUBKEY_WALLPAPERSTYLE,NULL,
													&dwType,
													(LPBYTE)this->m_szOldWallPaperStyle,
													&dwSize) != ERROR_SUCCESS) return FALSE;

	} // if(IsOsMinWin98OrMinWinnt5())



	::RegCloseKey(hKey);


	m_bIsOldSettings = TRUE; 

	
	return TRUE;// // Save old settings - Success

} // BOOL CDesktop::GetRegisterValue(VOID)


BOOL	CDesktop::IsOsMinWin98OrMinWinnt5(VOID)
{
		OSVERSIONINFO osvi;
		ZeroMemory(&osvi,sizeof(OSVERSIONINFO));
		osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

		BOOL bOsInfoSuccess = GetVersionEx(&osvi);
		
		
		switch(osvi.dwPlatformId)
		{

			case VER_PLATFORM_WIN32_WINDOWS:
			{
				if(osvi.dwMajorVersion == 4 && osvi.dwMinorVersion == 0)
				{
					// "Windows 95"
					return FALSE;
				}
				break;
			} // case VER_PLATFORM_WIN32_WINDOWS:
			


			case VER_PLATFORM_WIN32_NT:
			{
				if(osvi.dwMajorVersion == 3)
				{
					// "Windows NT 3"
					return FALSE;
				}
				else if(osvi.dwMajorVersion == 4)
				{
					// "Windows NT 4"
					return FALSE;
				}

				break;
			}// case VER_PLATFORM_WIN32_NT:


			
		}// switch(osvi.dwPlatformId)
		



		//////////////////////////////////////////////////////
		// Windows 2000, Windows XP, Windows 98 or Windows ME
		//////////////////////////////////////////////////////
		return TRUE;
		
} // BOOL	CDesktop::IsOsWindows95(VOID)



BOOL	CDesktop::SetWindowsRegister(LPCTSTR lpcTileWallPaperValue, LPCTSTR lpcWallPaperStyleValue)
{
	HKEY hKey=NULL;
	DWORD dwDisposition=0;

	if(RegCreateKeyEx(	HKEY_CURRENT_USER, 
									m_HKEY_CURRENT_USER_SUBKEY, 
									0, 
									NULL, 
									REG_OPTION_NON_VOLATILE, 
									KEY_CREATE_SUB_KEY | KEY_ALL_ACCESS, 
									NULL, 
									&hKey, 
									&dwDisposition) != ERROR_SUCCESS) return FALSE;
	

	/******************************************************************************** 
		Edit windows register settings in : [HKEY_CURRENT_USER\Control Panel\Desktop] 
		Value name : "TileWallpaper"
	*********************************************************************************/
	if(::RegSetValueEx(	hKey,
										this->m_SUBKEY_TILEWALLPAPER,
										0,
										REG_SZ,
										(CONST BYTE *)lpcTileWallPaperValue,
										MAX_SIZE) != ERROR_SUCCESS) return FALSE;
	


	/*********************************************************************************
		Edit windows register settings in : [HKEY_CURRENT_USER\Control Panel\Desktop] 
		Value name :"WallpaperStyle"
	**********************************************************************************/
	if(IsOsMinWin98OrMinWinnt5())
		if(::RegSetValueEx(	hKey,
										this->m_SUBKEY_WALLPAPERSTYLE,
										0,
										REG_SZ,
										(CONST BYTE *)lpcWallPaperStyleValue,
										MAX_SIZE) != ERROR_SUCCESS) return FALSE;
		
	RegCloseKey(hKey);

	// SUCCESS
	return TRUE;
} // BOOL	CDesktop::SetWindowsRegister(LPCTSTR lpcTileWallPaperValue, LPCTSTR lpcWallPaperStyleValue)





BOOL	CDesktop::MySystemParametersInfo(LPCTSTR lpcBmpFile)
{
	/*******************************************************************************************
		Edit windows register settings in : [HKEY_CURRENT_USER\Control Panel\Desktop] 
		Value name : "Wallpaper"
	********************************************************************************************/

	return (::SystemParametersInfo(	SPI_SETDESKWALLPAPER,0,(TCHAR*)lpcBmpFile,SPIF_SENDCHANGE|SPIF_UPDATEINIFILE));
	
}// BOOL	CDesktop::MySystemParametersInfo(LPCTSTR lpcBmpFile) 


/***********************************************************************************************
 *
 *  NAME:           SetDesktopWallpaper(...)
 *
 *  DESCRIPTION:    Change desktop wallpaper..
 *
 *                  Remove desktop wallpaper: SetDesktopWallpaper("", CDesktop::None )
 *
 *  PARAMETERS:     lpcFileName - bitmap filename, uState - ShowStatus
 *
 *  RETURNS:        TRUE	- Wallpaper has been changed 
 *                  FALSE - Error 
 *
 ************************************************************************************************/
BOOL CDesktop::SetDesktopWallpaper(LPCTSTR lpcBmpFileName,enum CDesktop::ShowStatus uState)
{
	TCHAR szWallPaperStyle[MAX_SIZE]={0}; // ("0","1" 0r "2") + Null character
	TCHAR szTileWallPaper[MAX_SIZE]={0};	//	("0","1" 0r "2") + Null character
	HBITMAP hBmpHandle = NULL;

	if (uState != None && uState != Restored)
	{
			// Check if bitmap file exist and if it's valid

			// If the function(LoadImage(...)) fails, the return value is NULL
			hBmpHandle = (HBITMAP)LoadImage(GetModuleHandle(NULL), lpcBmpFileName, IMAGE_BITMAP, 0, 0, LR_DEFAULTSIZE | LR_LOADFROMFILE);
			//
			if (hBmpHandle)
			{
				//Bitmap is OK

				//Free system resources
				BOOL s = DeleteObject (hBmpHandle);
				//
			}
			else
			{
				// No bitmap
				//
				return FALSE;
			} // If hBmpHandle != 0 Then
    
	} //  if (uState != None && uState != Restored)

	switch(uState)
	{
		case Centered: // 0
		{	
			::lstrcpyn(szWallPaperStyle,this->m_ZERO,MAX_SIZE);
			::lstrcpyn(szTileWallPaper,m_ZERO,MAX_SIZE);
			break;
		}
		case Tiled:		// 1
		{	
			::lstrcpyn(szWallPaperStyle,m_ZERO,MAX_SIZE);
			::lstrcpyn(szTileWallPaper,TEXT("1"),MAX_SIZE);
			break;
		}
		case Stretch: // 2
		{
			if(this->IsOsMinWin98OrMinWinnt5())
			{
				::lstrcpyn(szWallPaperStyle,TEXT("2"),MAX_SIZE);
				::lstrcpyn(szTileWallPaper,m_ZERO,MAX_SIZE);
			}
			else
				// Win NT 3, Win NT 4 or Win 95
				return FALSE;

			break;

		}
		case None:			// 3
		{
			::lstrcpyn(szWallPaperStyle,m_ZERO,MAX_SIZE);
			::lstrcpyn(szTileWallPaper,m_ZERO,MAX_SIZE);
			break;
		}
		case Restored:	// 4
		{
			return (this->Restore());
		}
		default: 
		{
			return FALSE;
		}
	
	}// switch(uState)

		
	if( ! this->GetWindowsRegister() ) return FALSE;

	
	if (uState != None)
	{
		if( ! this->SetWindowsRegister(szTileWallPaper,szWallPaperStyle) )return FALSE;

		if( !this->MySystemParametersInfo(lpcBmpFileName) ) return FALSE;
		
	}
	else
	{
		if( ! this->SetWindowsRegister(szTileWallPaper,szWallPaperStyle) )return FALSE;

		if( !this->MySystemParametersInfo( TEXT("") ) ) return FALSE;
	}

	// ("Wallpaper has been changed");
	return(TRUE);

} // BOOL CDesktop::SetDesktopWallpaper(LPCTSTR lpcBmpFileName, UINT uState)





BOOL CDesktop::Restore(VOID)
{
	if( ! this->m_bIsOldSettings) 
		return FALSE;

	if( ! this->SetWindowsRegister(this->m_szOldTileWallPaper,this->m_szOldWallPaperStyle) )
		return FALSE;

	if( ! this->MySystemParametersInfo(this->m_szOldWallpaper) )
		return FALSE;

	// Free memory 
	DELETE_ARRAY(m_szOldWallpaper);
	// 
	this->m_bIsOldSettings=FALSE; 
	
	return TRUE;
} // BOOL CDesktop::Restore(VOID)



