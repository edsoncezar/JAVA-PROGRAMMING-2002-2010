//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDCENTER                        2
#define IDSBS                           3
#define IDTILE                          3
#define IDNONE                          4
#define IDCANCEL1                       5
#define IDI_ICON_MAIN                   101
#define IDR_MENU2                       103
#define IDB_800x600                     104
#define IDB_1024x768                    105
#define IDB_SMALL                       106
#define IDD_DIALOG1                     128
#define IDSTRETCH                       1001
#define IDC_EDIT1                       1002
#define IDC_UNDO                        1005
#define IDC_STATIC1                     1007
#define IDC_RADIO2                      1009
#define IDC_CENTERED                    1009
#define IDC_NONE                        1010
#define IDC_TILED                       1011
#define IDC_STRETCHED                   1012
#define IDC_RESTORE                     1013
#define IDC_SET                         1014
#define ID_ABOUT                        40004
#define MENU_CLOSE                      40012
#define MENU_ABOUT                      65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
