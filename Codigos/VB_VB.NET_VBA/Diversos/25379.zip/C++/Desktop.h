////////////////////////////////////////////////////////////
/***********************************************************
*
*	File:								DESKTOP.H
*
*	Description:				Interface for the CDesktop class.
*
*	Author/Programmer:	�ke Strandberg	
*	
*	Last modified: 			18/1-2003		
*
*	=========================================================
*	================++++++++++++++++++++=====================	
* ======++++++===============================++++++========	
*						Copyright � 2000-2003.  �ke Strandberg
************************************************************/

#if !defined(AFX_DESKTOP_H__79405100_326A_44FD_B0EE_FA0B4394C9B6__INCLUDED_)
#define AFX_DESKTOP_H__79405100_326A_44FD_B0EE_FA0B4394C9B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef MAX_SIZE
#define MAX_SIZE 2
#endif // MAX_SIZE

#ifndef DELETE_ARRAY 
#define DELETE_ARRAY(ptr)\
if (ptr) \
{delete[] (ptr); (ptr) = 0;} 
#endif // #ifndef DELETE_ARRAY 

class CDesktop  
{
public:

	enum ShowStatus{	Centered, // CENTER == 0 by default
										Tiled,
										Stretch,
										None,
										Restored
									};// enum ShowStatus
	CDesktop();
	virtual ~CDesktop();
	
	BOOL SetDesktopWallpaper(LPCTSTR lpcFileName, enum CDesktop::ShowStatus uState);
	// public:

private:
	
	BOOL		m_bIsOldSettings;
	LPCTSTR m_HKEY_CURRENT_USER_SUBKEY;
	LPCTSTR m_SUBKEY_TILEWALLPAPER;
	LPCTSTR m_SUBKEY_WALLPAPERSTYLE;
	TCHAR		*m_szOldTileWallPaper; 
	TCHAR		*m_szOldWallpaper;
	TCHAR		*m_szOldWallPaperStyle;
	LPCTSTR m_SUBKEY_WALLPAPER;
	LPCTSTR m_ZERO;

	
	BOOL	GetWindowsRegister(VOID);
	BOOL	IsOsMinWin98OrMinWinnt5(VOID);
	BOOL	MySystemParametersInfo(LPCTSTR lpcBmpFile);
	BOOL	Restore(VOID);
	BOOL	SetWindowsRegister(LPCTSTR lpcTileWallPaperValue, LPCTSTR lpcWallPaperStyleValue);
	
// private:

};

#endif // !defined(AFX_DESKTOP_H__79405100_326A_44FD_B0EE_FA0B4394C9B6__INCLUDED_)
