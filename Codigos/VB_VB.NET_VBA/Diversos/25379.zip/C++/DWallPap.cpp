// DWallPap.cpp : Defines the entry point for the application.
//
//===============================================
/************************************************
*
*	File:								DWALLPAP.CPP
*
*	Description:				
*
*	Author/Programmer:	�ke Strandberg	
*	
*	Last modified: 			12/1-2003		
*
*	Email:							ake.programmer@swipnet.se
*																			
**************************************************/
//================================================

// custom
#include "stdafx.h"
#include "desktop.h"
#include "resource.h"

// Global
HWND g_hWndDialog=NULL;
CDesktop g_objDesktop; // Must be GLOBAL, if we use private class member function g_objDesktop.Restore()



BOOL  CALLBACK DialogProc(
				HWND hwndDlg,  // handle to dialog box
				UINT uMsg,     // message
				WPARAM wParam, // first message parameter
				LPARAM lParam  // second message parameter
				)

{
	const int MAX = 100;
	char text[MAX] = {0};
	HWND hwndTextBox = NULL;
	BOOL bSuccess=FALSE;
	
	switch(uMsg)
	{
		case WM_INITDIALOG:
		{
			::g_hWndDialog = hwndDlg;
			break;
		} // case WM_INITDIALOG:
		
		case WM_DESTROY: 
		{
			PostQuitMessage(0);   
			break;				
		} // case WM_DESTROY: 

		case WM_CLOSE: 
		{
			::DestroyWindow(g_hWndDialog);   
			break;				
		} // 	case WM_CLOSE: 


		case WM_COMMAND:
		{
			switch( wParam ) 
			{

				case IDCANCEL1:
				{
						EndDialog(hwndDlg, TRUE );
						return TRUE;
				} // 	case IDCANCEL1:


				case IDC_SET:
				{
					BOOL bIsChecked = FALSE;
					UINT iIndex=0;
				
					const UINT uCtrlIDs[1][5] = {{IDC_CENTERED,IDC_TILED,IDC_STRETCHED,IDC_NONE,IDC_RESTORE}};
				
				
					for(iIndex = CDesktop::Centered; iIndex <= CDesktop::Restored; iIndex++)
					{
						bIsChecked = ::IsDlgButtonChecked(::g_hWndDialog,uCtrlIDs[0][iIndex]);
						if(bIsChecked)break;
					}

					::LockWindowUpdate(::g_hWndDialog);// Stop flicker

					hwndTextBox = GetDlgItem(hwndDlg,IDC_EDIT1);
				
					if(CDesktop::None != (CDesktop::ShowStatus)iIndex)
					{
						if(GetWindowText(hwndTextBox,text,MAX))
							bSuccess=g_objDesktop.SetDesktopWallpaper(text,(CDesktop::ShowStatus)iIndex);
					}
					else
						bSuccess=g_objDesktop.SetDesktopWallpaper(TEXT(""),(CDesktop::ShowStatus)iIndex);


			
					if(bSuccess)
						MessageBox(0,TEXT("Wallpaper has been changed"),TEXT("Message: SUCCESS"),MB_OK);
					else
						MessageBox(0,TEXT("Error"),TEXT("Message: ERROR"),MB_ICONEXCLAMATION);

					::LockWindowUpdate(0);

					break;
				}// case IDC_SET:

			} // switch( wParam ) 

     break;
      
		} // case WM_COMMAND: 

		default: 
		{
			break;
		}
	}								


		return FALSE;

} // DialogProc(...)


/***************************
creates a modal dialog box 
****************************/
void MyDialogBox(int ID)
{
	int iDialogRet = 0;

	iDialogRet = DialogBox(	GetModuleHandle(0), 
													MAKEINTRESOURCE(ID), 
													NULL, 
													(DLGPROC)DialogProc);	
		

}	// void CreateDialogBox(int ID)




/***********************************************************************/
/*********************** Entry point ***********************************/
/***********************************************************************/
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR     lpCmdLine,
                   int       nCmdShow)
{
	MyDialogBox(IDD_DIALOG1);
	
	return 0;
} // WinMain(...)






