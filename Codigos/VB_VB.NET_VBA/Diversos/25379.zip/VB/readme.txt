Name:	�ke Strandberg
Country: Sweden
Email: 	ake.programmer@swipnet.se




Description of file:
Change desktop wallpaper with code.