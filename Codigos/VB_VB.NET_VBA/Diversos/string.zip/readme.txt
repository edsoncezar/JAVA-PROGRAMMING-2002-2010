Author:		Win Swarr
email:		win_swarr@hotmail.com,  wms12@columbia.edu
File:		String.bas
Purpose:	Contains functions for manipulating long strings.  