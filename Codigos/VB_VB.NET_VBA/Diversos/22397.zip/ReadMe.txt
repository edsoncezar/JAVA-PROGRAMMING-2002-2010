'    =======================================
'     3-D rotating cube (Incomplete)
'    =======================================
'
'    I just tried to rotate a 3-D cube,
'    this is what I got, pretty interesting... :)
'
'    Visit my Homepage:
'    http://www.geocities.com/emu8086/vb/
'
'
'    Last Update: Thursday, July 11, 2002
'
'
'    Copyright 2002 Alexander Popov Emulation Soft.
'               All rights reserved.
'        http://www.geocities.com/emu8086/
