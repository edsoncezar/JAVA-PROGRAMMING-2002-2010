waynespangler@hotmail.com.
DirPath
Gets a path and lets you create a new one.