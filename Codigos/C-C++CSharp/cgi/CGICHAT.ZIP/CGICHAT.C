/*
CGI Chat Room Version 1.0
Written by: James Becwar < becwar@mosquitonet.com >
on Sunday, March 16, 1997
in Ansi C 
Freeware.
*/

#include <stdio.h>
#include <stdlib.h>


int getmess(void);    //gets the messages.....
int printhtml(void);  //prints the html pages....
int printchatfile(void); //prints the chat file

FILE *chat;    //file pointer for the chat file..
FILE *coun;    //file pointer for the counter so the chat files is not too long
char *chatd;   //charecter pointer to chat env.
char *name;    //"                  " name env.

int main(void) {
	
	getmess();     //dumb I know but this code base has been though a lot...
    return 0;
}

printhtml(){
	printf("content type: text/html\n\n");  //YOU MUST KEEP THIS. It tells the server what mine type it is....
	printf("<HTML>"                         //all of this to the ; is the html page....
	"<HEAD>"
	"<TITLE>Fairnet Chat Room!</TITLE>"
    "</HEAD>"
	"<BODY>"
	"<P>"
	"<CENTER><H1>Fairnet Chat Room:</H1></CENTER>"
	"<HR>"
	"<FORM ACTION=\"cgichat.exe\" METHOD=\"POST\" ENCTYPE=\"application/x-www-form-urlencoded\">"
	"<P>"
	"Name:<Br><INPUT NAME=\"name\" VALUE=\"Your Name\" MAXLENGTH=\"30\" SIZE=25>"
	"<BR>"
	"Text:<BR>"
	"<TEXTAREA NAME=\"chat\" ROWS=4 COLS=40>"
	"</TEXTAREA>"
	"<P>"
	"<INPUT TYPE=SUBMIT VALUE=\"Say it!\"><INPUT TYPE=RESET VALUE=\"Opps!\">"
	"<HR>"
	"</FORM>");
    
    printchatfile();

	printf("</BODY></HTML>");
    return 0;
}

printchatfile() {
	if((chat=fopen("c:\\cgichat\\chat.dat", "r")) == NULL){   //trys to open chat.dat change this to your path
		printf("<h1>COULD NOT OPEN chat.dat FILE FOR CHAT DATA!!!!!!</H1>");
	}else{
		register char ch;           //puts in to cpu regester so it is very very very fast
		ch = getc(chat);
			while(ch != EOF ){
				printf("%c", ch);    //prints file one charecter at a time....
				ch = getc(chat);
			}
		fclose(chat);
	}
	return 0;
}

getmess(){
	chatd=getenv("CHAT");   //gets chat or CHAT enverment (via post....)
	if(chatd == NULL){      // if nothing to to be said redisplay the html page...
		//printf("\n\n\n\nCHAT == NULL\n\n\n");    //for debuging....
		printhtml();
		return 0;
	}else{
		int count;             //used to see how many enterys....
		//printf("\n\n\n\nchat arg-> %s\n\n\n\n", chatd);
		
		if((coun=fopen("c:\\cgichat\\coun.dat", "r")) == NULL){   //another path to change...
		    	printf("could not open coun.dat for reading....");
		    }else{
		    	fscanf(coun,"%i", &count);
		        fclose(coun);
		        //printf("\n\n\ncoun is:-> %i\n\n\n", count);  //debuging....
		    }
		 if(count >= 20){	//if the file is 20 entrys log then it will be delated.  NOTE: you can rase or lower this nummber...
		 	count = 0;
		    remove("chat.dat");   //delets the file...
		    chat=fopen("c:\\cgichat\\chat.dat" , "w");//makes new one
		    fclose(chat);
		    remove("chat.dat");
		    coun = fopen("c:\\cgichat\\coun.dat" , "w");
		    fprintf(coun, "%i", count);
		    fclose(coun);
		  }else{
		    ++count;                  // count = count + 1 (the increment op is a processer op so this is much faster.)
		    remove("coun.dat");                   //same as above....
		    coun = fopen("c:\\cgichat\\coun.dat" , "w");
		    fprintf(coun, "%i", count);
		    fclose(coun);
		    }
		}
		name = getenv("NAME");           //gets the name.
		
		if(name==NULL){      //just in case some one entered a blank line....
			name[0]='a';
			name[1]='\0';
			}
		if((chat=fopen("c:\\cgichat\\chat.dat" , "a"))==NULL){
			printf("COULDN'T OPEN chat.dat FOR APPEND!!!!!!");
		}else{
			fprintf(chat, "%s>%s<p>", name, chatd);    //formater for printing the chat enterys. currnenty is in form name>message you can change this....
			fclose(chat);
		}
		printhtml(); //updates the user.....
		return 1;    // errorlevel 1 = data written. errorlevel 0 = screan updated...
}
		
			