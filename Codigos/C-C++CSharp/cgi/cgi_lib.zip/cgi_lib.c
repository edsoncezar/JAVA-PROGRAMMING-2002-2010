#include <stdio.h>
#include <stdlib.h>

void init_html_tags(char *title);
void end_html_tags();
int cgi_parser(char ***cgi_a, char ***cgi_v);

main()
{
	char **cgi_a, **cgi_v;	/* === Pointers to arguments and their values === */
	int i, j;				/* === Counters === */
		
	init_html_tags("Demo CGI script!");

	j = cgi_parser(&cgi_a, &cgi_v);	
	if (j == -1)
		exit(1);

	for (i = 0; i < j; i++)
		fprintf(stdout, "%s=%s<BR>", cgi_a[i], cgi_v[i]);

	end_html_tags();
}

/*
 * FUNCTION init_html_tags
 *
 * Description:		Function sends to STDOUT initial HTML tags.
 * Parameters:		Pointer to title of the site as character array.
 * Return value:	None.
 */
void init_html_tags(char *title)
{
	fprintf(stdout, "Content-type: text/html\n\n");
	fprintf(stdout, "<HTML>\n");
	fprintf(stdout, "<HEAD>\n");
	fprintf(stdout, "<TITLE>%s</TITLE>\n", title);
	fprintf(stdout, "</HEAD>\n");
}

/*
 * FUNCTION end_html_tags
 *
 * Description:		Function sends to STDOUT closing HTML tags.
 * Parameters:		None.
 * Return value:	None.
 */
void end_html_tags()
{
	fprintf(stdout, "</BODY>\n");
	fprintf(stdout, "</HTML>\n");
}		 
		 
/*
 * FUNCTION cgi_parser
 *
 * Description:		Function Parsing the data sent to cgi script.
 * Parameters:		Pointers to array of strings.
 * Return value:	Number of pairs. -1 if error ocured during processing.
 */
int cgi_parser(char ***cgi_a, char ***cgi_v) 
{
	char *p_cl;				/* === Pointer to content lenght === */
	char *p_rm;				/* === Pointer to request method === */
	char *p_cin_line;		/* === Content of sent data === */
	char s_buff[3];			/* === Special character buffer === */
	int n_of_d;				/* === # of doubles === */
	int n_of_char;			/* === # of characters === */
	int c;					/* === Character read from stdin === */
	int i;					/* === Counter === */
	int index_of_args;		/* === Index to array of arguments === */
	int index_of_values;	/* === Index to array of arguments values === */
	int arg_val_tag;		/* === Indicator of using arg/val: 0-arg, 1-val === */

	/* ============================================ */
	/* === Reading of characters sent to script === */
	/* ============================================ */
	p_rm = getenv("REQUEST_METHOD");

	if(strcmp(p_rm, "POST") == 0)
	{		
		p_cl = getenv("CONTENT_LENGTH");
		n_of_char = atoi(p_cl);
		if((p_cin_line = (char *) malloc((n_of_char + 2) * sizeof(char))) != NULL)
		{
			for(i = 0; i < n_of_char; i++)
			{		
				c = getc(stdin);
				p_cin_line[i] = c;
			}
			p_cin_line[i++] = '&';
			p_cin_line[i] = '\0';

		}
		else
			return(-1);
	}

	/* ============================================================================ */
	/* === Calculating # of pairs and alocation of array of pointers to strings === */
	/* ============================================================================ */
	i = 0;
	n_of_d = 0;

	while( *(p_cin_line	+ i) != '\0' )
	{
		if( *(p_cin_line + i) == '=' )
				n_of_d++;
		i++;
	}				

	if((*cgi_a = (char **) malloc(n_of_d * sizeof(char *))) == NULL)
		return(-1);
	if((*cgi_v = (char **) malloc(n_of_d * sizeof(char *))) == NULL)
		return(-1);
	
	/* ============================================ */
	/* === Alocation of requested # of pointers === */
	/* ============================================ */
	i = 0;
	n_of_char = 0;
	index_of_args = 0;
	index_of_values = 0;

	while( *(p_cin_line + i) != '\0')
	{		
		if( *(p_cin_line + i) != '=' && *(p_cin_line + i) != '&')
		{
			n_of_char++;	
			if( *(p_cin_line + i) == '%' )
				n_of_char -= 2;
		}		
		else
		{
			if( *(p_cin_line + i) == '=')
			{			
				if(((*cgi_a)[index_of_args]  = (char *) malloc((n_of_char + 1) * sizeof(char))) == NULL)
					return(-1);	
				index_of_args++;	
			}		

			if( *(p_cin_line + i) == '&')
			{			
				if(((*cgi_v)[index_of_values]  = (char *) malloc((n_of_char + 1)* sizeof(char))) == NULL)
					return(-1);	
				index_of_values++;	
			}		
			n_of_char = 0;
		}		

		i++;
	}

	/* ================================================== */
	/* === Filling up the arguments and values arrays === */
	/* ================================================== */
	i = 0;
	n_of_char = 0;
	arg_val_tag = 0;
	index_of_args = 0;
	index_of_values = 0;

	while( *(p_cin_line + i) != '\0')
	{		
		if( *(p_cin_line + i) != '=' && *(p_cin_line + i) != '&')
		{
			if(arg_val_tag == 0)
			{
				if( *(p_cin_line + i) == '+' )
				{
					strcpy(s_buff, " ");
					strcat( (*cgi_a)[index_of_args], s_buff);
					n_of_char++;
				}
				else if( *(p_cin_line + i) == '%' )
				{
					s_buff[0] = *(p_cin_line + ++i);
					s_buff[1] = *(p_cin_line + ++i);
					s_buff[2] = '\0';
					sscanf(s_buff, "%X", &c);
					(*cgi_a)[index_of_args][n_of_char++] = c;
				}
				else 
					(*cgi_a)[index_of_args][n_of_char++] = *(p_cin_line + i); 
			}
			else
			{
				if( *(p_cin_line + i) == '+' )
				{
					strcpy(s_buff, " ");
					strcat( (*cgi_v)[index_of_values], s_buff);
					n_of_char++;
				}
				else if( *(p_cin_line + i) == '%' )
				{
					s_buff[0] = *(p_cin_line + ++i);
					s_buff[1] = *(p_cin_line + ++i);
					s_buff[2] = '\0';
					sscanf(s_buff, "%X", &c);
					(*cgi_v)[index_of_values][n_of_char++] = c;
				}
				else
					(*cgi_v)[index_of_values][n_of_char++] = *(p_cin_line + i); 
			}								
		}		
		else
		{
			if( *(p_cin_line + i) == '=')
			{			
				(*cgi_a)[index_of_args][n_of_char] = '\0'; 
				arg_val_tag = 1;		
				n_of_char = 0;
				index_of_args++;
			}		

			if( *(p_cin_line + i) == '&')
			{			
				(*cgi_v)[index_of_values][n_of_char] = '\0'; 
				arg_val_tag = 0;		
				n_of_char = 0;
				index_of_values++;
			}		
		}	
		i++;	
	}

	/* =================================== */
	/* === Freeing up allocated memory === */
	/* =================================== */
	free(p_cin_line);

	/* ========================= */
	/* === Return # of pairs === */
	/* ========================= */
	return(n_of_d);
}

