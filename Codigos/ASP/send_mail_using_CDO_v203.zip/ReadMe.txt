Surf-net e-mail form v2.3 using the standard ASP CDO Component


The Surf-net e-mail v2.3 form is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without permission.             **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail



The  e-mail form uses ASP and must be run through a web sever supporting ASP and the CDO component.

Windows 2000 comes with Microsoft's Web Sever, IIS 5, which can be installed through Add and Remove Programs in the Control Panel. 

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.

Sorry Microsoft's personal Web sever under win 98 does support ASP but does not come with the CDO e-mail component.



Using the e-mail form

Unzip all the files to the same directory

Files must be run through an ASP enabled web sever supporting CDO (The CDO component is standard with IIS, sorry there is no CDO component on Win98 Personal web server)

The script uses the standard CDO component which is installed by default in IIS

All you should need to do to use this script on your site is place your e-mail address into the strMyEmailAddress string at the top of the send_email.asp page

If you want to also send the e-mail to more than one person (i.e. Carbon Copy (CC)) then place other e-mail addresses in the strCCEmailAddress indicated at the top of the send_email.asp page. You can send more than one Carbon Copy by placing ';' between the e-mail addresses. i.e. person_one@mydomain.com;person_two@mydomain.com

All validation that the form has been filled in correctly is done by JavaScript in a function at the top of the contact.htm page




If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ

