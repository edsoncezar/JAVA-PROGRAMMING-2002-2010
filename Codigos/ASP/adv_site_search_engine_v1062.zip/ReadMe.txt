Surf-net Advanced site search engine realease v1.62 beta


The Surf-net advanced site search engine v1.62 beta is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without permission.             **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail



The site search engine uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the site search engine


Unzip all the files to the same directory

Files must be run through an ASP enabled web sever

The site_search.asp file needs to be in the root directory of your website to be able to search all files on your site


Near the beginning of the script you can put how many results you want shown on each page

You can also set the file extension types you want the script to search, seperated by commas, the default is, htm, html, asp, shtml

You can also enter the names of the folders, seperated by commas, you don't want searched like adminstration folders or the cgi_bin

You can also enter the names of the files, (include the extension type ie .htm) seperated by commas, of the files you don't want searching like asp files that are only used for processing forms etc.

The speed at which the searching is done depends on how many files there are to search on the site.

The  website search engine uses the Regular Expressions component which is needs to VBScript 5.0 scripting engine, which older servers may not support.  



Tip

The following tips will give more descriptive results from the site search engine also they will give your site higher ratings by search engines like Google, AstaVista, Lycos, etc.


Make sure each page of your site has a title otherwise the script will return a 'no title' for the page. Titles should be standard HTML titles as follows: -

<title>PLACE YOUR PAGE TITLE HERE</title>


make sure that each page has a meta description of what the page contains otherwise the results will return 'There is no description for this page'. Meta descritions should be standard HTML meta tags that the Internet search engines read: -

<meta name="Description" content="PLACE PAGE DESCRIPTION HERE">




If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ

