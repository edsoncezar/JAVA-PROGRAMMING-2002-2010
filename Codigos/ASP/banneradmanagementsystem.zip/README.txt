*********************************************************
WEBSITE CONTRIBUTOR
Banner Ad Management System
*********************************************************

 Author: Michael Wright 
 E-mail: michael_wright@lineone.net
 Date: 08/03/2001
 Languages: ASP (vbscript), HTML
 License: GNU GPL License version 2 (see COPYING.txt)

*********************************************************

INTRODUCTION

This is a typical Banner Ad Management System which includes the banner retrieval,
randomize and output include file (banners.shtml) to display the banners on your
website.  Also included is the management system called Banner Admin from
WEBSITE CONTRIBUTOR allowing you to add, edit or delete your banners for your
website (you must also use FTP to upload your banners).

You are free to change any of the files included but we ask you to keep the command
lines within the Banner Admin code files as below:

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=4,0,0,0"
 id=index width="220" height="90" border="1">
              <param name=movie value="http://themikester.co.uk/websitecontributor/websitecontributor.swf">
              <param name="BGCOLOR" value="#6699FF">
              <embed src="http://themikester.co.uk/websitecontributor/websitecontributor.swf"
 swliveconnect=false loop=true quality=high salign=TL
 type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?
P1_Prod_Version=ShockwaveFlash" width="220" height="90" bgcolor="#6699FF" border="1">
                <noembed><font size="+1">WEBSITE CONTRIBUTOR</font></noembed> 
              </embed> 
</object>

Apart for that, you can do whatever.  If you wish to distribute your own version then
you must include the original Authors along with yours and provide the code (please
see COPYING.txt for more detail cos I can't explain it that easily).

CONTENTS OF ZIP FILE

banner1.gif (practice banner)
banner2.gif (practice banner)
banner3.gif (practice banner)
banner4.gif (practice banner)
banner5.gif (practice banner)
banners.mdb (MS Access 97 database for storing the banner information) 
banners.shtml (include file as main banner code)
default.asp (a simply example for display the random ads)
default.gif (default practice banner)
README.txt (this file)
admin/add_banner.asp (to add a banner within Banner Admin)
admin/clearpixel.gif (for html adjustments)
admin/default.asp (start page of Banner Admin)
admin/delete_banner.asp (to delete a banner within Banner Admin)
admin/edit_banner.asp (to edit a banner within Banner Admin)
admin/edit_banner2.asp (to edit a banner within Banner Admin)
admin/line.gif (Banner Admin line graphic)
admin/main.asp (to access all Banner Admin options)
admin/thanks.asp (to confirm the completion of Banner Admin options)
admin/websitecontributor.swf (Banner Admin flash animation)

INSTALLATION

First unzip all the contents of the zip file (which this README file is included) to a
directory on your hard drive preferably called banners.  The zip file should have now
also created a sub-folder called admin.  The first folder holds the banner ad code and
data, and the admin folder holds the Banner Admin files.

Now use an FTP client to access your webspace for uploading the files.  The webserver
MUST support ASP (vbscript)/MS Access 97/SHTML include files and for best results be 
configured for DSN-Less DB connections.  If your server does not support DSN-less DB 
connections (like Dellhost.com) then you need to create a DSN for the banners.mdb database
and change the code files appropriately. If your server does not support .shtml include
files then simply change the file extension to suit your own needs but remember what
you did for when you go to display the random banner.

Once you've got the right webserver simply create a directory called banners and a sub-directory
within it called admin.  Now upload the files provided to the appropriate directories.

Now look at the code file default.asp (not the one in the admin directory), you will see
that the banners.shtml is used as an include file and you simply call Rnd_Banner() in ASP
delimiters (<% %>) to display a random banner.  You can now modify one of your current 
web files to display a random banner.  You can also change the other code and files included,
to customize for your own needs.

That's it, enjoy!

CREDITS

All programming and documentation written by Michael Wright

IN NEXT VERSION

- Hit counter for banners (both impression and click-thru)
- Hit counter Admin
- Banner Admin code comments
- More banner implementation methods
- Whatever you create for us!

LINKS

Please visit www.themikester.co.uk to view the latest information on this project and
other Open Source projects.  We also have Uncut News & Opinions, Open Web Development,
Open MP3 Music, Bitch About Stuff and much more.