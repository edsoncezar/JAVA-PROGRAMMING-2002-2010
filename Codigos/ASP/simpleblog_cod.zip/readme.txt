ASP Simple Blog

Copyright (c) 2003
J�hann Rafnsson
www.johann.tk
All rights reserved.

This script can be used for personal use as long as the banner and the copyright notice is not removed.


Requirements:

	Microsoft IIS 4.0+ webserver (or Microsoft personal web server)
	IUSR write permission on "db" directory


Features:

	- Easy to use admin interface with login
	- Included comments system with emoticons, easily add/remove emoticons
	- Very easy setup
	- blog page can contain last x number of blogs, last 7 days or last 30 days
	- archives links by month
		

The application is written in asp and requires write permission on the database file (access database).

Simple Blog features an admin interface where the owner can insert, update and publish his/her blogs.
Other features includecomments with emoticons, adding and removing emoticons from the system is as easy
as just adding/removing gif images from the "emoticons" directory.
The owner can edit/delete comments from the admin interface.

Installing is very easy, relatively no coding knowledge is required, apart from some knowledge of HTML.
Default.asp is the template page and can be designed in any way, the only thing needed to activate
Simple Blog are the two include lines at the very top of the document, and two asp function calls.

Installation

1. Unzip contents to a directory on your webserver, make sure "db" dir has write access.

2. Make sure the two include lines are at the top of document (default.asp).

3. This line should be placed where you want the blogs to appear:
   <% Call getBlogs() %>
    

4. This line should be placed where you want the archives links to appear:
   <% call getArchives() %>

To access the admin interface, open http://www.yourwebserver.com/simpleblog/admin and login using admin/user.

To change login information, open admin/login.asp in notepad or some other editor and make the changes in line 5.

