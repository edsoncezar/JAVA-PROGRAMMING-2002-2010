//Fun��o para escutar o qruivo de som
function escutar(){
som = document.cartao.musica.value
if(som == 0){
alert("Nenhuma m�sica foi selecionada!");
}
else{
window.open("ouvir.asp?som=" + som,"popup", "width=200, height=100");
}
}


//Fun��o para visulizar o cart�o
function visualizar(){
var campos = "";
var erro = false;

//Verifica o campo nome
if(document.cartao.nome.value == ""){
erro = true;
campos += "\n - Nome"
}
//Verifica o campo para
if(document.cartao.para.value == ""){
erro = true;
campos += "\n - Para"
}
//Verifica o campo assunto
if(document.cartao.assunto.value == ""){
erro = true;
campos += "\n - Assunto"
}
//Verifica o campo mensagem
if(document.cartao.mensagem.value == ""){
erro = true;
campos += "\n - Mensagem"
}

//Exibe as mensagens de erro
if(erro == true){
alert("Antes de visualizar o cart�o preencha\n            os campos abaixo!\n" + campos);
}
else{
var nome = document.cartao.nome.value;
var _para = document.cartao.para.value;
var assunto = document.cartao.assunto.value;
var fonte = document.cartao.fonte.value;
var mensagem = document.cartao.mensagem.value;
var musica = document.cartao.musica.value;
var img = document.cartao.img.value;
var tamanho = document.cartao.tamanho.value;

window.open("visualizar.asp?nome=" +nome+ "&_para=" +_para+ "&assunto=" +assunto+ "&fonte=" +fonte+ "&mensagem=" +mensagem+ "&img=" +img+"&musica="+musica+"&tamanho="+tamanho,"popup", "width=450, height=500");
}
}



function verificar(msg){
var campos = "";
var erro = false;

//Verifica o campo nome
if(document.cartao.nome.value == ""){
erro = true;
campos += "\n - Nome"
}
//Verifica o campo email
if(document.cartao.de_email.value == ""){
erro = true;
campos += "\n - E-mail"
}
//Verifica o campo para
if(document.cartao.para.value == ""){
erro = true;
campos += "\n - Para"
}
//Verifica o campo para_email
if(document.cartao.para_email.value == ""){
erro = true;
campos += "\n - E-mail"
}
//Verifica o campo assunto
if(document.cartao.assunto.value == ""){
erro = true;
campos += "\n - Assunto"
}
//Verifica o campo mensagem
if(document.cartao.mensagem.value == ""){
erro = true;
campos += "\n - Mensagem"
}
//Exibe as mensagens de erro
if(erro == true){
alert("Antes de Enviar o cart�o preencha\n            os campos abaixo!\n" + campos);
return false;
}
else{
//janela de confirma��o
if(window.confirm(msg)){
return true;
}
else{
return false;
}
}
}