UNZIP all the files, keeping the folder intact.  If you do not have winzip, download it for free off winzip.com.

This is the first version of the email pranker.  Please abide these simple rules:

1)  Leave the Gamezoner.com text link at the bottom of each page alone!
2)  You MAY edit any file how you wish, as long as the Gamezoner text link is still VISIBLE on each page
3)  Do NOT email me about bugs, questions support etc, use the forums.  Your post will be read.  The forum are located on the main page of gamezoner.com
4)  You may NOT dustribute this zip file on your web site, nor may you put your name on it in any place or form, to suggest that you developed the script.

Index.asp is the start page

I know the code is very messy at the moment, but it works nice and looks good!  You may need to spend a bit of time suiting it for your needs.

FAQ:

	It wont work!
		Make sure you have web space which supports ASP, and CDONTS.  Without these 
		two specifications the prank emailer most definalty will not work.

	I have another Question!
		Use the forums on Gamezoner.com

CREDITS:

	Thanks to webwizguide.info for developing the email functions
	Visit webwizguide.info for more free ASP scripts

	Gamezoner.com In puttin all the scriptlets together

