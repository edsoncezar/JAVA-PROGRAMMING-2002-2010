CoolCaf�

--------------------------------------
-- New language module - Portuguese --
--------------------------------------

Thanks to Marcos Vin�cius de Souza for this Portuguese translation of CoolCaf�.

Installation
------------

1- Make a backup copy of chat12.mdb
2- Copy the file portuguese.asp in the coolcafe directory
3- In your browser, type the URL http://www.yoursite.com/coolcafe/portuguese.asp,
   where you will replace www.yoursite.com by your site URL
4- Delete the file portuguese.asp from your site
5- Thats it! You now have a Portuguese version of CoolCaf� thanks to Marcos Vin�cius de Souza


www.coolcafe.ca
