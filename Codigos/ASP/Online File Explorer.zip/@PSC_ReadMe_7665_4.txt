Title: Online File Explorer
Description: This is an Example of Server Side XML & XSLT With CSS, Javascript and HTML. It takes an XML File with Data collected about each file and folder in a directory. The Data collection was done with an other application that I wrote, email me for info about that... The output from this is a Explorer style looking window. see screen shot below. if you dont have an IIS Web Server to try this out you can goto http://camalotdesigns.com/pscode/ for a live demo.
Please leave your comments and let me know what you think.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7665&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
