
//Function to check form is filled in correctly before submitting
function CheckForm () {
	
	var errorMsg = "";
	
	//Check for an Author
	if (document.frmJournal.author.value==""){
		errorMsg += "\n\tAuthor \t- Entre com o nome do Autor";
	}
	
	//Check for an Journal Title
	if (document.frmJournal.title.value==""){
		errorMsg += "\n\tTitle \t\t- Entre com um t�tulo para o post";
	}
	
	//Check for journal Item
	if (document.frmJournal.journalItem.value==""){
		errorMsg += "\n\tJournal Item \t- Enter a Journal Item to post";
	}
	
	//If there is a problem with the form then display an error
	if (errorMsg != ""){
		msg = "____________________________________________________________________\n\n";
		msg += "Your Journal Item has not been submitted because there are problem(s) with the form.\n";
		msg += "Please correct the problem(s) and re-submit the form.\n";
		msg += "____________________________________________________________________\n\n";
		msg += "The following field(s) need to be corrected: -\n";
		
		errorMsg += alert(msg + errorMsg + "\n\n");
		return false;
	}
	
	return true;
}

//Have the propmt box turned on by default
var promptOn = true;


//Function to turn on or off the prompt box
function PromptMode(selectMode){
	
	if (selectMode.options[selectMode.selectedIndex].value == 0){
		promptOn = false;
	}
	else{
		promptOn = true;
	}
}


// Function to add the code for bold italic centre and underline, to the journalItem
function AddMessageCode(code, promptText, InsertText, eleNum) {

	if (code != "") {
		if (promptOn == true){
			insertCode = prompt(promptText + "\n<" + code + ">xxx</" + code + ">", InsertText);
				if ((insertCode != null) && (insertCode != "")){
					document.frmJournal.elements[eleNum].value += "<" + code + ">" + insertCode + "</" + code + ">";
				}
		}
		else{
			document.frmJournal.elements[eleNum].value += "<" + code + "></" + code + ">";
		}
	}
				
	document.frmJournal.elements[eleNum].focus();
}






//Function to add the URL, indent, list, and Email code to the elements[eleNum]
function AddCode(code, eleNum) {

	//For the URL code
	if ((code != "") && (code == "URL")) {
		insertText = prompt("Entre com o texto para o link", "");
			
			if ((insertText != null) && (insertText != "") && (code == "URL")){
				insertCode = prompt("Entre com a URL pra criar o link", "http://");
					
					if ((insertCode != null) && (insertCode != "") && (insertCode != "http://")){					
						document.frmJournal.elements[eleNum].value += '<a href="' + insertCode + '">' + insertText + '</a>';
					}
			}
	}
	
	
	//For the email code
	if ((code != "") && (code == "EMAIL")) {
		insertText = prompt("Entre com o texto para o link de email", "");
			
			if ((insertText != null) && (insertText != "")){
				insertCode = prompt("Entre com o endere�o de email", "");
					
					if ((insertCode != null) && (insertCode != "")){					
					document.frmJournal.elements[eleNum].value += '<a href="mailto:' + insertCode + '">' + insertText + '</a>';
				}
			}
	}
	
	//For the image code
	if ((code != "") && (code == "IMAGE")) {	
		insertCode = prompt("Entre com a URL da imagem", "http://");
					
			if ((insertCode != null) && (insertCode != "")){					
			document.frmJournal.elements[eleNum].value += '<img src="' + insertCode + '" border="0">';
		}			
	}
	
	//For the list code
	if ((code != "") && (code == "LIST")) {
		if (promptOn == true){
			listType = prompt("Lista ordenada \nEnter \'1\' Numere ou deixe em branco para usar bullets", "");
			
			while ((listType != null) && (listType != "") && (listType != "1")) {
				listType = prompt("ERRO! \'1\' Numere ou deixe em branco para usar bullets","");               
			}
			
			if (listType != null) {			
				var listItem = "1";
				var insertCode = "";
				
				while ((listItem != "") && (listItem != null)) {
					listItem = prompt("Deixe em branco para finalizar a lista",""); 
					if (listItem != "") {             
						insertCode += "<li>" + listItem + "</li>"; 
					}                   
				} 
				
				if (listType == "") {
					document.frmJournal.elements[eleNum].value += "<ul>" + insertCode + "</ul>";
				} else {
					document.frmJournal.elements[eleNum].value += "<ol>" + insertCode + "</ol>";
				} 
				
			}
		}
		else{
			document.frmJournal.elements[eleNum].value += "<ul><li> </li><li> </li><li> </li></ul>";
		}			
	}
	
				
	document.frmJournal.elements[eleNum].focus();
}

//Function to open preview post window
function OpenPreviewWindow(){

	strTitle = escape(document.frmJournal.titulo.value);
	strMessage = escape(document.frmJournal.journalItem.value);
	strAutor = escape(document.frmJournal.nome.value);
	strHora = escape(document.frmJournal.hora.value);
	document.cookie = "Title=" + strTitle
   	document.cookie = "JournalItem=" + strMessage
	document.cookie = "Autor=" + strAutor
	document.cookie = "Hora=" + strHora
   	
   	openWin('preview.asp','preview','toolbar=0,location=0,status=0,menubar=0,scrollbars=1,resizable=0,width=435,height=300')
}

//Function to open pop up window
function openWin(theURL,winName,features) {
  	window.open(theURL,winName,features);
}
	
// -->
