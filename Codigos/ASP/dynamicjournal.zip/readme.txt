TheJournal
-----------------------------------------------------------------------
Version 1.0 comprises of 4 mainsections:                               

 +Main: here is wher you select the entry you want to view..it then    
  posts a string to the next section in the viewing area...
 
 +View: Using the id from the record set it displays the entry you 
  wanted on a whole page. Independantly.

 +Admin: This is where you can remove the entries that you do not want   
  any longer.

 +Submit: Here is where you submit your data to the databese.
  At this stage my main concern is the fact that I have to use multiple   
  text boxes to do one entry (as the record fields can only hold 255     
  characters) and also the single quote causes the database to     
  malfunction.

I will look into these problems in the next version.
-----------------------------------------------------------------------

Created 02 June 2000