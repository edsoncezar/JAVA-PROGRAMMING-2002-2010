/****** Object:  Stored Procedure dbo.sp_addAdvertLink    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_addAdvertLink]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_addAdvertLink]
GO

/****** Object:  Table [dbo].[easyAds]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[easyAds]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[easyAds]
GO

/****** Object:  Table [dbo].[easyAds]    Script Date: 6/11/2001 5:42:02 AM ******/
CREATE TABLE [dbo].[easyAds] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[display_date] [datetime] NOT NULL ,
	[display_time] [datetime] NOT NULL ,
	[display_month] [varchar] (20) NOT NULL ,
	[display_day] [varchar] (20) NOT NULL ,
	[usr_ip_address] [varchar] (255) NULL ,
	[usr_browser] [varchar] (255) NULL ,
	[display_adName] [varchar] (255) NULL ,
	[usr_referer] [varchar] (255) NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[easyAds] WITH NOCHECK ADD 
	CONSTRAINT [PK_easyAds] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

/****** Object:  Stored Procedure dbo.sp_addAdvertLink    Script Date: 6/11/2001 5:42:41 AM ******/
CREATE PROCEDURE sp_addAdvertLink
(
@m1	DateTime,
@m2	DateTime,
@m3	VarChar(20),
@m4	VarChar(20),
@m5	VarChar(255),
@m6	VarChar(255),
@m7	VarChar(255),
@m8	VarChar(255)
)
AS
INSERT INTO
easyAds
(
display_date, display_time, display_month, display_day,
usr_ip_address, usr_browser, display_adName, usr_referer
)
VALUES
(
@m1, @m2, @m3, @m4, @m5, @m6, @m7, @m8
)



GO
