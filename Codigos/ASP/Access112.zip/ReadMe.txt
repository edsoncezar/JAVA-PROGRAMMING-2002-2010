ZixForum - Ver 1.12 
Update to Ver 1.12 - 2002-02-28
Just read the help files, located in dir ZixHelp.

Good Luck with your ZixForum!

/ZixForum