***********************************************************************************************
 FileUpload Object v2.6
   support@aspemporium.com
   http://www.aspemporium.com/
***********************************************************************************************


 FileUpload v2.6 Release Notes
 =============================
 The following bugs were repaired from version 2.5.0:

 FileUpload Class > ProcessUpload Method

	- repaired bug preventing the proper 
	  counting of form inputs
	
 FO_Processor Class > BuildUploadRequest_ASCII Method
 FO_Processor Class > BuildUploadRequest Method

	- added code to append form inputs if 
	  more than one input has the same name
	- added check to prevent appending if 
	  the input is an input of type file



 QUICK INSTALL
 =============================

 1.) - extract zip file to somewhere. It will create a directory called
       fileupload_20
     - inside that directory there will be 4 folders.
       > the code folder contains all the source code and testing asp and htm pages.
       > the db folder contains the database used in one of the tester apps.
       > the documentation folder contains the reference for the fileupload system.
       > the uploads folder is where uploads will be stored by one of the tester apps.
     - you should upload the fileupload_20 folder to the root of your testing space
       on your server. example: http://127.0.0.1/fileupload_20/
     - you can navigate to the code directory with your browser and click on any file
       that begins with the word form_ to test.
     - all documentation is in the documentation folder. That folder doesn't need to
       be stored on the server. You should keep the documentation on your development
       machine or wherever else you are writing your code.

 2.) all documentation is in the FileUploadv25_SDK.chm file. You must have
     html help installed on your home computer or where ever it is where you
     write code. Do not store the chm file on your server. 

 3.) reading the documentation is a great place to go for help.
     otherwise, post in the forum for this example (link in the docs)