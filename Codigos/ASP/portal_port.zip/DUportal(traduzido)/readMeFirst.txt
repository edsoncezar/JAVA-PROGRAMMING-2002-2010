DUresources.com - 11/09/2001
--------------------------------------------------------------
Terms and Instruction on how to install DUportal - Version 1.0
--------------------------------------------------------------

A. CREDIT AND LINK:
  
    DUportal is a free application. Credit and link back to DUresources Web site is required if you use this application as     it is, regarding its design, codes and graphics.

B. SUPPORT:

    There is no email or phone support for all free applications listed on DUresources Web site. However you can post your       questions, comments and requests on the Web site of DUresources, its forums and all other related newsgroups on the World     Wide Web.

C. INSTALL AND SET UP:

    1. Database: 

       - DUportal uses Access 97 for its database. If you plan to upgrade DUportal database to SQL Server, post your question          in the DUportal Forum on DUresources Web site. Other users will help you with this.

       - When uploading DUportal to your Web Hosting, be sure to place DUportal.mdb file into a read-able and write-able          directory assigned by you or your Web Host Server Admin. 

    2. Connection:

        - DUportal.zip contains a folder named Connections. There is an ASP file in this folder named connDUportal.asp
    
        - After you have placed all files and database file into their directory, open connDUportal.asp in UltraDev, Dreamweaver, Notepad, etc. Below is the codes inside this file:



                     <%
                      ' FileName="Connection_ado_conn_string.htm"
                      ' Type="ADO"
                      ' HTTP="false"
                      ' Catalog=""
                      ' Schema=""
                       MM_connDUportal_STRING = "Driver={Microsoft Access Driver                                                                   (*.mdb)};DBQ=C:\Files\Websites\DUportal\database\DUportal.mdb"
                     %>




        - What you need to modify is the last line, excluding %>:



                      MM_connDUportal_STRING = "Driver={Microsoft Access Driver                                                                    (*.mdb)};DBQ=C:\Files\Websites\DUportal\database\DUportal.mdb"








        - Explaining the line:
                      
                      DUportal, uses MS Access Driver ot is Access 97 Database. The path to the Access database file is, as in my computer: 

                      
                      C:\Files\Websites\DUportal\database\DUportal.mdb


         - Here is the directory structure in my C: drive, for your reference:

                      C: 
                         Folder: Files
                                 Folder: DUportal
                                         Folder: DUhome
                                                 File: default.asp
                                                 File: register.asp
                                                 .................
                                         Folder: DUdirectory
                                                 .................

                                         .........................

                                         Folder: database (this folder is set as read-able and write-able)
                                                 File: DUportal.mdb

                                         ..........................

                                         Folder: Connections
                                                 File: connDUportal.asp




           - If you know the absolute path and directory where your files are, use the above connection, for example:


                     C:\InetPub\domain\DUportal\database\DUportal.mdb (for database)

                     C:\InetPub\domain\DUportal\default.asp       (default page)

                     C:\InetPub\domain\DUportal\DUdirectory\default.asp   (for other files)
                     ...............................................asp

                     OR                 


                     C:\Sites\username\database\DUportal.mdb (for database)

                     C:\Files\username\files\default.asp   (default page)

                     C:\Files\username\files\default.asp   (for other files)


            - If you don't know the absolute path, use Server.Mappath



                     MM_connDUportal_STRING = "DRIVER={Microsoft Access Driver (*.mdb)};DBQ="&                      Server.MapPath("username\database\DUportal.mdb") 


                     OR


                    MM_connDUportal_STRING = "DRIVER={Microsoft Access Driver (*.mdb)};DBQ="&                                          Server.MapPath("domain\DUportal\database\DUportal.mdb") 


           
D. DESIGN (CONTENT, LAYOUT, COLOR, FONT, ETC):

      1. Content:

             - DUportal uses include files as modules. Whichever section (module) that you do nit want to be on DUportal, remove it, for example, on the default.asp page inside DUhome folder, it displays the category of links, hot links and new links, like this:

                                  <!--#include file="../DUdirectory/inc_directory.asp" -->
				  <!--#include file="../DUdirectory/inc_dir_new.asp" -->
				  <!--#include file="../DUdirectory/inc_dir_hot.asp" -->



             - If you dont want to list hottest links on this page, remove it.

                                  <!--#include file="../DUdirectory/inc_directory.asp" -->
				  <!--#include file="../DUdirectory/inc_dir_new.asp" -->


             - This applies to all other page. The file that you most likely want to change the content is the inc_left.asp file. This file is displayed on the left of every page. For example, if you dont want to have NEWS on your site, open this file and remove any include line such: inc_news_a-name.asp



     2. Layout:

             - By using include files and moving them around, you can place each module anywhere you want to. Remember that any include file starts with inc_short_module-name_a-name.asp must be placed in the inc_left.asp file.


     3. Color and font:

            - Open default.css file from folder CSS in Notepad, if you can. Dreamweaver and UltraDev will open it in a dialog box which makes it hard to modify the codes in the stylesheet file.

            - Here's what in that file; read the comment above each style:


**************************************************************************************************
<style TYPE="text/css">

THIS IS FOR ALL LINKS IN THE APPLICATION

DIV.Links		A   	       	{color:	#009999; text-decoration:none}
DIV.Links		A:link			{color:	#009999; text-decoration:none}
DIV.Links		A:visited		{color:	#009999; text-decoration:none}
DIV.Links		A:hover 		{color: #FF0000; text-decoration:none}


THIS IS FOR FORM FIELDS. I HAVE NOT APPLIED THIS STYLE TO FORMS IN THIS APPLICATION. IF YOU WANT TO USE IT, PLACE class = "fields" AT THE END OF HTML CODE FOR A FORM FIELD

.Fields {
border: 1px #666666 groove;
; background-color: #CCCCCC
; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: xx-small; background-position: center center
; font-weight: bold; color: #009999
}


THIS IS FOR BUTTONS IN FORM. I HAVE NOT APPLIED THIS STYLE TO FORMS IN THIS APPLICATION. IF YOU WANT TO USE IT, PLACE class = "buttons" AT THE END OF HTML CODE FOR A FORM BUTTON

.Buttons {
border: 1px #666666 groove;
; background-color: #009999
; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: xx-small; background-position: center center
; font-weight: bold
; color: #00FF00; height: auto; width: auto
}


BACK GROUND OF BANNER AND SOME OTHER BARS. AS DEFAULT, THIS IS THE DARKER GREEN COLOR, OR COLOR OF ULTRADEV SOFTWARE
.bg_banner { background-color: #009999 }

BACKGROUND OF NAVIGATION BAR AND SOME OTHER; AS DEFAULT IT IS THE LIGHTER GREEN COLOR OR COLOR OF DREAMWEAVER SOFTWARE
.bg_navigator { background-color: #00CC99}

BACK GROUND OF LOGIN BAR AND SOME OTHER. THIS IS A LIGHT GREY COLOR.
.bg_login { background-color: #CCCCCC }

</style>
*********************************************************************************************************


E. NOTES

       If there's anything else missing in this Readme file, please post it at DUresources Web site and I will include it in here for other users in the future. 

       Thank you 
       Quy To
       
================================================
DUresources.com, home of Dreamweaver and UltraDev users
Creator of DUpoll, DUclassifieds, DUforum, DUcomment, DUrating, DUshop@amazon, DUdirectory and DUportal

Dallas, Texas, USA November 2001

                   

         

                      
                        

                     
