----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------



Database Summary Info


summary:
===============

Database Summary Info

If you use OLEDB to power your database connections, most likely 
you can use this example to find out everything there is to know 
about any database on your server. First we empower a little used 
component called adox.catalog to get a list of every table in the 
db and then run a quick function to return the field names and field 
data types of every table, creating a good-enough database summary. 






documentation:
===============
Please view the db_info.asp file for the complete exposed 
interface definition.



installation:
===============
1.) determine what type of database you will be using to test the
example. If you choose SQL Server, you will need the following
files from the download package:
	examples.sql
	db_info.asp

If you choose MS Access, you will need the following files:
	mydata.mdb
	db_info.asp


2.) Skip this step if you are using MS Access.
if you are using SQL server, open the examples.sql file in
query analyser and run it to set up the test table. Then
open db_info.asp in notepad and find this line:

	objConn.Open "provider=microsoft.jet.oledb.4.0;data source=" & server.mappath("./mydata.mdb") & ";"

you must change that line representing the database connection
string to point to your sql server. MS Access users don't need
to change anything to run the example. You must place your database 
connection string there for the example to work and then save the 
file (SQL server only).


3.) place the required files from step 1 into any directory on the server.


4.) navigate to db_info.asp on your website with your web browser to test.


known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


