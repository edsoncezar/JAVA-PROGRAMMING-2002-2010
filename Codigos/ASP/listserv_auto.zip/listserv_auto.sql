/****** Object:  Stored Procedure dbo.sp_AddMailRecip    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_AddMailRecip]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_AddMailRecip]
GO

/****** Object:  Stored Procedure dbo.sp_GetMailRecips    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_GetMailRecips]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_GetMailRecips]
GO

/****** Object:  Stored Procedure dbo.sp_RemMailRecip    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_RemMailRecip]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_RemMailRecip]
GO

/****** Object:  Stored Procedure dbo.sp_RemMailRecipByID    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_RemMailRecipByID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_RemMailRecipByID]
GO

/****** Object:  Table [dbo].[autoResponder]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[autoResponder]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[autoResponder]
GO

/****** Object:  Table [dbo].[autoResponder]    Script Date: 6/11/2001 5:41:51 AM ******/
CREATE TABLE [dbo].[autoResponder] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[IPaddress] [varchar] (255) NOT NULL ,
	[emailAddress] [varchar] (255) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[autoResponder] WITH NOCHECK ADD 
	CONSTRAINT [PK_autoResponder] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO


/****** Object:  Stored Procedure dbo.sp_AddMailRecip    Script Date: 6/11/2001 5:42:42 AM ******/

CREATE PROCEDURE sp_AddMailRecip
(
@mIPAddr	VarChar(255), 
@mEmailAddr	VarChar(255)
)
AS
INSERT INTO
autoResponder
(
IPaddress, emailAddress
)
VALUES
(
@mIPAddr, @mEmailAddr
)


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_GetMailRecips    Script Date: 6/11/2001 5:42:47 AM ******/



CREATE PROCEDURE sp_GetMailRecips
AS
SELECT
emailAddress, ID
FROM
autoResponder





GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_RemMailRecip    Script Date: 6/11/2001 5:42:54 AM ******/

CREATE PROCEDURE sp_RemMailRecip
(
@mEmailAddr	VarChar(255)
)
AS
DELETE
FROM
autoResponder
WHERE
emailAddress = @mEmailAddr



GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_RemMailRecipByID    Script Date: 6/11/2001 5:42:55 AM ******/



CREATE PROCEDURE sp_RemMailRecipByID
(
@mID		Int
)
AS
DELETE
FROM
autoResponder
WHERE
ID = @mID





GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO
