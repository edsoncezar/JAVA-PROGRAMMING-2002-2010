----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

Autoresponder and Listserv.



summary:
===============
Two part system consisting of:
1.) an app that allows a user to add or remove their email address
    from a mailing list database.
2.) an app that allows an administrator to manage existing email
    addresses and send out a newsletter to everyone in the mailing
    list database.



documentation:
===============
Both the autoresponder and listserv are VBScript classes and behave
like objects in VBScript. Each class exposes properties and methods
that can be used programmatically in VBScript code. Explicit 
documentation for each object's interface can be found here:
	AutoResponder Object
		docs_autoresponder.txt
	ListServ Object
		docs_listserv.txt


installation:
===============
1.) determine what database you will be using. The type of database
    you choose determines what files you will need from the download
    package and how much preparation is involved before the software
    can be used without errors. Most examples come configured to run
    with the provided MS Access test database with no recoding necessary.

	> MS Access (DB provided in download)
	  ----------------------------------------------
		required files from download package:
			autoresponder.asp
			listserv.asp
			mydata.mdb

		* The asp files have been pre-configured to work
		  with the included MS Access database. The database is 
		  in Access 2000 format. MS Access 97 specific editions
		  of the database are not supported for use on the web 
		  but are available for downloading at the link below. 
		  You should use the 97 version only to view the 
		  structure of the database and only if you do not have
		  MS Access 2000 installed. The server does not need to
		  be running any version of MS Access to be able to read
		  the MS Access 2000 database.

		  http://www.aspemporium.com/aspEmporium/downloads/myData_db.asp

		* ms access databases require read/write/modify permissions
		  in the directory where they live to work properly. It is 
		  up to you to provide a directory with adequate read/write 
		  permissions for the database.

	> SQL Server (sql scripts provided in download)
	  ----------------------------------------------
		required files from download package:
			autoresponder.asp
			listserv.asp
			listserv_auto.sql

		* sql server users must first run the listserv_auto.sql
		  script via query analyzer to set the database up
		  with the necessary objects. Please check to make
		  sure that nothing already exists in the database
		  with the same name because they will be dropped
		  in favor of new definitions in this script once 
		  it is run. By the time you realize you made a 
		  mistake, the script will have already run and you
		  cannot undo...

		* sql server users are responsible for populating
		  the newly created tables (if any) on your own.
		  via enterprise manager, you can import records from
		  the provided MS Access test database directly into
		  the newly created objects.

		* sql server users must change the database connection
		  string so that it does not use the provided MS Access
		  database but instead uses the database that you ran
		  the examples.sql script in. Please view the reference
		  for the object in question for more information on 
		  changing the database connection properties for both
		  apps (see documentation above).


2.) open the listserv.asp file and find the procedure labeled:
	Private Sub SendMail()
    you must edit that procedure to reflect your mail server's information.
    instructions on what to change is in the source code within that
    procedure.


3.) open the autoresponder.asp file and find the procedure labeled:
	Private Function SendMail(byVal EMAIL)
    you must edit that procedure to reflect your mail server's information.
    instructions on what to change is in the source code within that
    procedure.


4.) place the required files from step 1 into the same directory 
    on the server. (sql server users: you can discard listserv_auto.sql 
    after you run it with query analyzer.) 


5.) navigate to autoresponder.asp on your website with your web browser 
    to see the client interface part (autoresponder system) and to
    listserv.asp to see the administrative part of (listserv system).


6.) it is up to you to password protect or otherwise prevent users from
    accessing the listserv component of this system.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


