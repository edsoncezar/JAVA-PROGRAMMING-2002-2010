DONHEY MANAGER V2
The Donhey Manager is a one page asp script wich uses the filesystemobject to be a very usefull and extensive filemanager through the browser. 
It supports asp, html, htm, acl, js, asa, txt, inc, log for editing and creating and the access mdb format for viewing.
All other files that exist on the server can be deleted, renamed and the information about them can be accessed. 
The Donhey Manager can be easely installed on the server by uploading the asp and image files to the server. The page automatically initializes itself. The only thing you have to do is edit the image location variable. You can change the name and location of the script to whatever you want.

Features
- Easy installation
- Almost like Windows explorer
- File/Directory search
- Edit/create asp, html, htm, acl, js, asa, txt, inc, log files.
- View microsoft access mdb files
- wide browser support

System requerements
- ASP capable server
- Script engine version 5 or higher
- Filesystemobject installed
- For viewing mdb files: the ODBC drivers installed
There is a testing script included in the package.

For installation details see the script. Just open it up dan read the start. If you want to redistribute this software. You may, If you keep the contents of this package intact AND notify me.

Happy Managing.
Regards,

Don Heijmans
Donhey ASP software website
d.heijmans@chello.nl

Tannhauserstraat 135
7323 DN Apeldoorn
The Netherlands