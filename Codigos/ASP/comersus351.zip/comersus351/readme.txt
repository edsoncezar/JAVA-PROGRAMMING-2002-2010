Comersus 3.51
Sophisticated e-commerce Open Source
CopyRight � 2000/1, Rodrigo S. Alhadeff, All rights reserved
____________________________________________________________


Read Comersus documentation in comersus3.pdf file
You will need Acrobat Reader, download it from 
http://www.adobe.com/products/acrobat/readstep.html

Notes: 
- Remove previous version before installing current version

Most important folders:
/store Storefront root folder
/wap WAP catalog root folder 

Free third party packages
- Languages          http://www.comersus.com/downl/languages.zip
- SQL Server Scripts http://www.comersus.com/downl/sqlscripts.zip

Technical questions
http://forum.comersus.com

Comersus Add-ons 
http://store.comersus.com

_____________________________________________________________


Date       Version  Obs
_____________________________________________________________
13/07/2001 3.51     Minor patches in encryption, selectShipment,
                    and Tax calculation

13/07/2001 3.50     New shipping policies depending on State, 
		    Zip and country. New Tax policies depending
		    on product, state, zip and country.
		    Discount per quantity bug fixed, Shipping
		    payment discount filter bug fixed, RC4 quotes
		    removing fixed, Boolean fields compatible with
		    SQL Server, Country Codes & States with 
		    dropdown, Querystring encryption, More 
		    fraud protections, Force to select 
		    Optionals setting, Image not available in
		    viewitem script
		    

01/06/2001 3.45     Discounts per quantity, Free Advanced Search
		    Max Quantity for add item, delivering time
		    estimation, List Old Carts in customers menu,
		    Stock and Sales update in autoupdateorderstatus,
		    bug fixed in search more than two 
		    words for Netscape (page 2 or more), Dynamic 
		    General Conditions, Portuguese Language added,
		    Form quantity in viewitem configurable, Header 
		    and Footer design simplified, Language fix in 
		    order tracking
		    
15/05/2001 3.40     Opt Advanced search package, Sell Digital 
 	            feature with automatic distribution of serials, 
		    download links, etc, Same OpenDb script for
		    all modules, easy add-ons installation, BtoB
		    special prices, SecurePay Payment Gateway added,
		    CSS font styles for the whole store, new cart 
		    schema for same product added, Wap <p> bugs 
		    fixed, add categories and BtoB price in Tiny 
		    Admin, discounts weight depending bug solved


20/04/2001 3.36     Order & customer prefix, Fraud Prevention 
	            package, Dynamic store news page, email to a 
	            friend, minimum purchase, customer registration 
	            form, pagination in products section of 
		    comersus_listcategoriesandproducts.asp
		    Order tracking in WAP store

15/04/2001 3.35     Unlimited categories levels, category navigator
		    list orders in Tiny admin, Wish List, 
		    add to cart from listing

08/04/2001 3.34     SQL Server Scripts included, encryption
		    modules for sensitive data, related 
		    products opt package, off line opt payment

27/03/2001 3.33     User utilities menu, optionals bug fixed
		    for several products of same ID, sslUrl 
		    field in payments can be zero length, Tiny 
		    Admin Utility VbScript error validation,
		    Newsletter, Allow new customer register 
		    setting, Product customer reviews

16/03/2001 3.32     Validate 100% VbScript, Multiple Header 
                    and footer styles, TAX per state, 
                    more discount features

09/03/2001 3.31     Tax bug fixed, free multilanguage package
		    order prefix, more discounts features, 
		    billing & shipping address, Access 97 &
		    2000 compatible
		    
18/02/2001 3.30     Wap access to catalogue, configurable
	            currency format and decimal sign, 
	            delete products in Tiny Admin, Discounts
	            functionality, autoupdate order status
	            script for Payment Gateways

01/02/2001 3.29     Date Format Settings, unexcpected inputs 
		    validation. Multiple e-mail components 
		    settings for Jmail, CDONTS, ASPmail, 
		    Persits ASPmail. Multiple database
		    connection strings, Order Tracking

29/11/2000 3.28	    Bug in optional with decimal price to add 
		    (truncation), allow payment discount
		    Bug in total options, Small random in 
		    saveorder to get  idOrder.	

23/11/2000 3.22	    Basic Stock functionality (viewItem, 
		    settings, saveorder)			    

22/11/2000 3.21     SaveOrder fixed bugs in Payment-Email-Text, 
		    orderForm Ssn field bug

09/11/2000 3.20     ListProductsBySubCategory added, veristore 
		    modified, DSN less connection
                    database structure in english, Includes 
                    File instead of Includes Virtual
                    Cleanner code, more english comments, 
                    SaveOrder prepared to huge traffic

17/10/2000 3.15     MultiLanguage Support

11/10/2000 3.10     More english documentation

08/10/2000 3.01     Spanish messages in user screens, some 
		    open connections without closeDb		    
		    Error in next screen for 
		    listProductsByCategory and searchItems

01/10/2000 3.00     Original release. 
		    Bug in currency type fields in Access 
		    database, no comments in source 		    		    

_____________________________________________________________
		                        		    
Comersus 
Av. Corrientes 3019, of.11 (1193)
Buenos Aires - Argentina
E-mail info@comersus.com
Web http://www.comersus.com
Phone (5411) 154-175-4717 