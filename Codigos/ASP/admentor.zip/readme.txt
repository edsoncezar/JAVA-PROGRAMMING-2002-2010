AdMentor foi desenvolvido por Stefan Holmberg, webmaster@aspcode.net
Traduzido e reconfigurado para o portugu�s por Serial Link, www.seriallink.com.


D�vida ou sugest�es escreva para:

	graccula@serialLink.com (Renato Graccula)
	aspbr@grupos.com.br (Lista onde o assunto come�ou)

Ou contacte o site original em ingl�s:
http://www.aspcode.net

O site do AdMentor � is http://www.aspcode.net/products/admentor


Current version is 2.20

The code is written by Stefan Holmberg
Contributors:
Shawn Willmon ( shawn@vicad.com ) - traceclicks code in admentordb.asp for version 1.11
Jeroen Roeper ( http://www.free4u2.com ) - some graphics and also security aspects 

Documentation is available ( online version only ) at: http://www.aspcode.net/products/admentor

Traduzido para Portugu�s por:
http://www.seriallink.com



