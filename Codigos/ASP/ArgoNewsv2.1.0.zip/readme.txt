**********************************************
*                                            *
* ArgoNews v2.1 readme                       *
*                                            *
* Current Version:  2.1.0 (07.08.2001)       *
* Author:           Adam Argo                *
* Email:            apollyon@apollyon.net    *
* Homepage:         http://www.apollyon.net/ *
* Date:             07.08.2001 @ 04:06 PM    *
* License:          Shareware ($10)          *
*                                            *
**********************************************

------------------
-- Introduction --
------------------

ArgoNews was created as an alternative to all the clunky free news scripts coded in ASP.  Most other news systems were designed with one section in mind, giving little choice in how content could be displayed.  ArgoNews was created to be able to add more than one section with different formats.  It also features multiple logins, template code generation, and a very easy-to-use interface.

------------------
-- Requirements --
------------------

Server:      IIS5
Permissions: Read/Write
The administration backend has only been tested on IE 5.5 - it should work on other browsers too, though.

-----------------
-- User Levels --
-----------------

1 - Can post/edit items, upload images, and change personal login info.
2 - Can post/edit/delete items, upload and delete images, and change personal login info.
3 - Can post/edit/delete items, upload and delete images, add or delete categories and change personal login info.
4 - Can post/edit/delete items, upload and delete images, add or delete categories, generate code, and add/edit/delete all logins.

--------------------
-- Category Types --
--------------------

Gallery - Fields: Image Name, Caption.  Can be edited or deleted.  This category type is used for creating an archive of images for your site.

Guestbook - Fields: Name, Email, Message, IP.  Can be deleted.  This is for creating a guestbook or other item that you want site visitors to add to.

News - Fields: Author, Email, Date, Time, Headline, Content, Sticky.  Can be edited or deleted.  This category type is used for creating daily news or other things for your site.

Static - Fields: Content.  Can be edited.  Static is for creating HTML pages that are updated through a database.  There is only one page per category.  To delete a static page, you must delete its entire category.

------------------
-- Installation --
------------------

Upload contents into a separate directory on your server named "ArgoNews", "Admin", etc., or the "CGI-BIN" directory if that is the only place you have write access.  Edit the "siteconfig.asp" file for your personal preferences, and then update the "dbconn.asp" file with the location of your database.  It is a good idea to change the name and/or path of your database for security reasons.  After you're finished, open the "default.asp" file in your browser and login using user/password "admin".  From here, you can change/delete/create logins.  It is recommended to either delete the default admin account or change its password.

----------------------------------
-- Upgrading from version 2.0.x --
----------------------------------

After uploading all the new files, type "%yourargonewsdir%/upgrade.asp" and fill in the names of up to five "news" categories and a guestbook name.  Press submit, and it will add the needed fields to your database.  It is recommended to delete upgrade.asp and upgrade2.asp after you are finished upgrading your database.

-----------
-- Usage --
-----------

One category is already created, titled "News".  It is in the top section of the left menu.  To add an item to it, click "News".  At the top of the page, click "Add".  Type in your headline and content, and you're done!  ArgoNews automatically inserts the date, time, your name, and your email.

To edit an item within a category that allows it, click the "edit" button on the right side of the page next to the one you want to change.  A page will come up with the current contents of that page (headline/content/image name/caption only).  Change the fields as you want and press up "update".  Voila!  You have updated your item.

To delete an item if it is allowed, click the delete button to the right of your screen next to the item you want to get rid of.  The page will refresh, and your entry will be gone.

To add a category, click the "Add Category" link on the right side of the page.  Choose a name for the category and select its type from the pulldown menu (type definitions can be read above).  Press submit, and your new category is there!

To delete a category, click the "Delete Category" link on the right side of the page.  Click the link for the category you want to delete.  REMEMBER: DELETING A CATEGORY DELETES ALL THE ITEMS INSIDE OF IT!

To add a login, click "Add Login" on the right.  Enter the name, email, password twice, and user level for the new login.  Press "Add it!" and your new login is ready to go.

To edit a login, click "Modify Logins" and press "Edit" on the right side.  You can change the password and email address.  If you update the email address, you also must reenter the password or create a new one and the user level.

To delete a login, click "Modify Logins" and press delete.  The login you have chosen is gone.

To log out of the system, press the "Log out" button on the left side.

There is a page system in place that will allow you to change pages when there are more than the set amount of entries.

To upload an image, click "Image Upload" on the left.  Press the "browse" button to select the image that you want, and then press upload.  The image is uploaded to the image directory you set in your siteconfig.asp file.  Larger images may take some time to upload.  Note that images are uploaded using the FileSystemObject rather than putting them in a database, so if you move your website, make sure you have all the uploaded images.

To delete an image, click "Current Images" and select the one you want to delete by clicking the "delete" link next to it.

-----------------
-- Sticky news --
-----------------

New in 2.1.0 is the advent of "sticky" news, or news that will stay at the top regardless it's post date.  To make news sticky, select "Yes" from the pulldown box when creating or editing news.  It's that simple.  However, when searching news, items that are "sticky" will not be displayed because they are at the top of your page anyway.  You could probably code around it, but I thought it was best to not have it searched.

-------------------
-- Viewimage.asp --
-------------------

When you click on an image from a gallery, the viewimage.asp window will pop up with the image in its full size.  In a gallery, the width is restricted to 120 - too small usually.

-----------------------------
-- Generating Display Code --
-----------------------------

To generate code to display in a template with, simply log in as a level 4 user and click the "Generate Code" link.  From there, choose where you want the new file/what it's called and where the database and other files shown on the screen will be in relation to it (this is a MUST).  Press "Generate it!" and your code will be done.  The file checks for already existing files... if you are trying to overwrite a previous file, make sure to delete it before generating the new code.  You can add that code any way you want to to your template... SSI or just paste your template around, etc.  Keep in mind that if you use SSI, the included file must be in the same directory as the main include, else you have to update the generated file with the location of the database in relation to the file that includes it.

------------------
-- Known Issues --
------------------

If you delete all the login accounts before logging out, you can still add another one to correct this.  If you log out and have deleted all logins, you must install a fresh database file or manually update yours and reupload it.

There are issues with creating a new category that has the same name as an existing category  If you get a HTTP 500 error, press back and enter a new name.

Small hacks in the generated file code may be necessary to correct appearance issues for your site's template.  Simply edit the generated code and make sure that the fields are inside the loops.

---------------------
-- Release History --
---------------------

v2.0 - Initial Release
v2.0.1 - Fixed bug for date/time when adding content.  Users must now enter password for account when editing or deleting logins.  Fixed login bug when re-entering the admin site.
V2.0.2 - Added multiple-level access system.
V2.0.3 - Added the generate code system.
V2.0.4 - Added the search feature to the Gallery, Guestbook, and News category types.
V2.1.0 - Added "sticky" news, guestbook IP logging, image upload/delete, revamped searching, major improvements to generated code, all around tweaks, added an upgrade script.

--------------------
-- Included Files --
--------------------

addcat.asp
addcontent.asp
addlogin.asp
adovbs.inc
ArgoNews.mdb
dbconn.asp
default.asp
deletecat.asp
deletecontent.asp
deletelogin.asp
editcontent.asp
editlogin.asp
generatecode.asp
guestbookadd.asp
login.asp
logout.asp
main.asp
readme.txt
security.asp
siteconfig.asp
styles.css
upgrade.asp
upgrade2.asp
upload.asp
viewimage.asp
images/background.gif