Title: Database Access System
Description: A complete system to Access database via Web.
This little system allow you to add/modify/delete records via web from any kind of Access database.
It works with IIS or PWS.
The idea has been to create some asp pages which receive their inputs from a database, in order to access other tables or queries.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7730&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
