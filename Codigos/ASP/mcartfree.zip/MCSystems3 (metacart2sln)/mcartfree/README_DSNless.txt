-----------------------------
END-USER LICENSE AGREEMENT
-----------------------------

Use of the MetaCart Free eCommerce Shopping Cart Application
for Small Businesses and Developers with DSN-less Connection, is
governed by the terms of this End-User License Agreement
(the Agreement).

By purchasing and downloading this software you agree
to the terms and conditions of this Agreement.

------------------------------
TERMS AND CONDITIONS
------------------------------
METALINKS.COM GRANTS TO THE LICENSEE A NON-EXCLUSIVE,
NON-SUBLICENSABLE, NON-EXCLUSIVE, NONTRANSFERABLE LICENSE
TO INSTALL AND USE THIS APPLICATION ON A SINGLE COMPUTER.
THE CODE IN THE APPLICATION MAY BE MODIFIED FOR USE IN SETTING
UP A SINGLE STOREFRONT ON THE WORLDWIDE WEB. LICENSEE MAY MAKE
A COPY OF THE APPLICATION FOR BACK-UP AND ARCHIVAL PURPOSES,
PROVIDED THAT ANY COPY MUST CONTAIN ALL PROPRIETARY NOTICES
INCLUDED WITH THE APPLICATION. LICENSEE IS PROHIBITED FROM SELLING
OR DISTRIBUTING THE APPLICATION IN ANY MANNER.

Disclaimer of Warranty. THIS APPLICATION IS PROVIDED "AS IS,"
WITHOUT A WARRANTY OF ANY KIND. ALL EXPRESS OR IMPLIED
REPRESENTATIONS AND WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
NON-INFRINGEMENT, ARE HEREBY EXCLUDED.

THERE IS LIMITED PERSONAL SUPPORT FOR THIS APPLICATION AND
IS ONLY AVAILABLE VIA E-MAIL OR THROUGH POSTINGS TO THE
METALINKS.COM GUEST BOOK. USERS MAY E-MAIL MESSAGES ABOUT ANY BUGS,
ERRORS, FIXES OR ENHANCEMENTS TO WEBMASTER@METALINKS.COM FOR
POSTING TO THE METACART MASTER DOWNLOAD FILE AND THE
METALINKS.COM WEBSITE. ADDITIONALLY, USERS MAY POST MESSAGES,
QUESTIONS AND COMMENTS TO METALINKS.COM'S GUEST BOOK AT
HTTP://METALINKS.COM/GUESTS_FRM.HTM.

Limitation of Liability. METALINKS.COM AND ITS LICENSORS SHALL
NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE OR ANY THIRD
PARTY AS A RESULT OF USING �OR DISTRIBUTING THIS APPLICATION.
IN NO EVENT WILL METALINKS.COM OR ITS LICENSORS BE LIABLE FOR
ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
THE USE OF OR INABILITY TO USE THE SOFTWARE, EVEN IF METALINKS.COM
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Indemnification. METALINKS.COM WILL NOT HAVE ANY LIABILITY
TO LICENSEE FOR, AND LICENSEE WILL DEFEND AND HOLD METALINKS.COM
HARMLESS AGAINST, ANY CLAIM, EXPENSE, JUDGMENT, LIABILITY, OR LOSS
(INCLUDING ATTORNEYS' FEES AND EXPERT WITNESSES' EXPENSES) BASED ON
LICENSEE'S USE OF ANY CONTENT, ARISING FROM ANY INTELLECTUAL PROPERTY
CLAIM (INCLUDING PATENT, TRADEMARK, COPYRIGHT, OR TRADE SECRET
INFRINGEMENT), ANY RIGHT OF PUBLICITY OR PRIVACY CLAIM, OR ANY
DEFAMATION OR UNFAIR COMPETITION CLAIM.

----------------------------------------
DOWNLOAD PACKAGE CONTENTS & INSTRUCTIONS
----------------------------------------

The MetaCart Free download package consists of the End-User License
Agreement, a set of Active Server Page (ASP) files and a Microsoft
Access 97 database. The ASP files process customer
requests, generate the product pages and order processing based
on the database. Active Server Pages also require that the FrontPage server
extensions be installed on the NT(IIS)4.0 or 5.0 Server.

You may edit the HTML as you see fit to match your site. You can
edit the ASP files with any HTML editor that doesn't change or
overwrite code. Unless you are an experienced ASP programmer, be
careful editing code other than HTML. The source code is commented
throughout and indicates where changes may or should be made. The
package, when unzipped, includes the following folders and files:

-----FOLDERS------ 

1. database - this folder contains metacart.mdb, a MS Access 97 database,
the same one used in the MetaCart e-Shop demo on MetaLinks.com's WWW site.
You may convert this database to an Access 2000 database. It is also recommended that
you password protect the database. Coding for password protection is included
in the db.asp and global.asa files. Substitute your password for the word "foo" in both 
files (recommend you use at least eight characters). Permissions for the database folder 
and the database must be set to Read, Write and Execute Scripts for the browser 
(anonymous user). Setting the wrong permissions on these two items will generate an
"updateable query" error when the Add To Cart button is clicked.

Here are some additional resources for more information about connecting to databases
for Visual InterDev and FrontPage users:

a. FRONT PAGE USERS

"Using Active Server Pages to Display Microsoft Data"
See http://msdn.microsoft.com/workshop/languages/fp/dev/dbasp.asp

"Using Databases with Microsoft FrontPage 2000"
http://msdn.microsoft.com/workshop/c-frame.htm#/workshop/languages/fp/default.asp
In the table of contents, click the plus-sign icon for "FrontPage 2000 White Papers"
to expand its menu. Click the whitepaper, "Using Databases." You may have to click on
it twice to get it to open.

b. VISUAL INTERDEV USERS

"Connecting to a Database"
http://msdn.microsoft.com/library/devprods/vs6/vinterdev/vidref/vihowconnectingtodatabase.htm

"Adding a Data Connection to a Database"
http://msdn.microsoft.com/library/devprods/vs6/vstudio/vdbref/dvhowaddingdataconnectiontodatabaseproject.htm

2. images - this folder contains all the images used in the demo application.

---------FILES ------  

1. README_DSNless.txt - The End-User License Agreement plus application instructions.

2. default.asp - The top-level page and shopping cart entry page
to your business.

3. Default.htm - This is a dummy Default.htm page for those users who will be using
Visual InterDev to deploy their web to a remote server using the Copy Web Application
option. There is a bug in VI that renames default.asp to Default.htm on the target server
and all the references in other pages that refer to default.asp. This will keep this
from happening during deployment. Once deployed, you may delete this page.

4. global.asa - a page containing special event handlers.

IMPORTANT NOTE: The global.asa file needs to be in the root directory
of the MetaCart ASP web application (that means in the metacart folder, which also needs to contain
the images folder, and the files with .asp and .inc extensions) in order to function properly. 
You may move the database folder and database out of the metacart folder into
the root directory of your website upon deployment to a remote server (be sure to
read the commented lines in the db.asp and global.asa files to reset the path correctly).
The global.asa file also includes code for tracking how many users are currently on your
site. The number of current users is displayed on your main entry page
(default.asp) with code referencing the code in the global.asa file. 

NOTE: USE NOTEPAD TO EDIT THE GLOBAL.ASA FILE. FRONTPAGE TRIES TO PUT HTML TAGS IN IT, 
VISUAL INTERDEV DOES NOT. 

5. db.asp - an include file that uses an OLEDB Provider and the Server.MapPath to 
establish the DSN-less connection string to the database. Duplicate code can also
be found in the global.asa file. If you edit the path to the database in the db.asp
file, make the same changes to the global.asa file.

6. adovbs.inc - an include file from Microsoft containing commonly used
constants and variables from the ActiveX Data Objects (ADO) library.

7. productsByCategory.asp - accessed from the main entry page, this
page displays a list of products in a particular category or catalog.
This page contains code that allows you to limit the number of products
displayed on the page. This is particularly useful if you have a
large number of products. For demonstration purposes, the number of
products displayed per pages is set at 5. You may set this number as
appropriate for your situation.     

8. product.asp - depending on the product the user selected from
productsByCategory.asp, this page displays the item, description, price and
image of the product selected and allows the user to add the item to their
shopping basket.

9. addToCart.asp - confirms customer has added item to cart and allows
users to review the items in their basket and proceed to check-out
or continue shopping.

10. reviewOrder.asp - allows user to review their order, change and update
it, delete it, or proceed to check-out.

11. checkout.asp - allows customer a final opportunity to review and
change their order before filling out their payment and shipping information.
This file also contains code for figuring shipping and tax
charges. It currently is set for a 0.08 (8%) tax rate and 0.05 (5%) shipping
charge rate. You should change the tax rate and shipping charges 
to fit your needs for your state or province. IN AN ACTUAL PRODUCTION
ENVIRONMENT, THIS FILE AND THE validateOrder.asp FILE SHOULD ONLY BE ACCESSED
THROUGH A SSL CONNECTION ON YOUR PRODUCTION SERVER TO SAFEGUARD CUSTOMER
AND CREDIT CARD INFORMATION. 

12. validateOrder.asp - contains code to validate information entered
by the customer in the checkout.asp page, including a credit card validator, 
then posts the customer's order to the database for fulfillment
processing, and displays a thank-you message for his or her order.
IN AN ACTUAL PRODUCTION ENVIRONMENT,THIS PAGE AND THE checkout.asp PAGE
SHOULD ONLY BE ACCESSED THROUGH A SSL CONNECTION ON YOUR PRODUCTION SERVER TO
SAFEGUARD CUSTOMER AND CREDIT CARD INFORMATION. 

13. search.asp - allows customer to search your store's catalogs from any
page by category, product name, product description, or price level.

14. searchAction.asp - contains code that returns the results of the
customer's search.
	
15. moreinfo.asp - the page in the demo site containing general information
about the MetaCart application.

16. checkcc.asp - an include file that contains credit card validation code
based on the Luhn Modulus 10 method.
	
-----------------------------------
Copyright � 2000-2001 metalinks.com
MetaCart2 / MPOWER / MPOWERMENT are proprietary to MetaLinks.com