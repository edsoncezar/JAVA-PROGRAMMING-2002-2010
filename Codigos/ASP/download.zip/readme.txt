ASP Download Manager (BETA) for IIS 4.0+

Version: v1.0      
Author : Keith Ollerton (ollertonk@postmaster.co.uk)
            F1-Computer Solutions (c) 2000 

Last Modified: 29/09/2000
All rights reserved.
-----------------------------

ASP Banner Rotator was tested under IIS 4.0 on a Windows NT 4.0 (SP5)

   
Please send bug reports, comments, etc to ollertonk@postmaster.co.uk

This version of ASP banner Rotator may be used and modified free of charge 
by anyone so long as this copyright notice and the comments above 
remain intact.  By using this code you agree to indemnify 
Keith Ollerton from any liability that might arise
from its use.                                                  
                                                                            
Selling the code for this program without prior written consent is     
expressly forbidden. 

This is a beta release meant for testing only until this line is removed by the author.

Some portions of this code were derived from examples provided by
www.asp101.com - an excellent site for those new to ASP.

Change Log:

	1.0 - Inital Release


This zip file contains:

download.asp 		-	The main asp file that does all the
				work.  Rename this to anything you 
				see fit.

download.mdb		-	Microsoft Access97 database that holds 
				all the details of your download files
				and click information.


readme.txt		-	This file.


Setting it all up
=================

Just unzip the files into a directory, set the database path at the top
of download.asp to point to the local location of the download.mdb file.

Populate the database with the values for your download files. Just change the values in the "downloads" table (all the field names are 
self explanatory).  The DownloadID field is a AutoNumber field to
ensure that no two files get the same ID.

You can then call the ASP from another page by using a link such
as:

http://your_server/download.asp?DownloadID=x

where x is the ID number of a particular file to download.

The "monitor" table then records the IP address and time / date of
each click on a download link.  Also, if the DownloadID requested
is not found a record is still entered showing the missing ID
number but a value of TRUE is put into the MonitorError field.
found 