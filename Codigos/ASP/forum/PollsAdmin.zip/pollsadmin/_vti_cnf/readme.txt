vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_DEV-SERVER
vti_timecreated:TR|31 Jul 2001 09:11:43 -0000
vti_timelastmodified:TR|01 Sep 2001 10:29:13 -0000
vti_filesize:IR|1991
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|01 Sep 2001 10:29:09 -0000
vti_modifiedby:SR|IUSR_STATION2
