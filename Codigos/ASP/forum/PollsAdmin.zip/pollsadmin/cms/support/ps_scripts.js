var preLoadStr = new Array();
function preLoadImages()
{
	if(preLoadStr.length > 0)
	{
		for(var i=0; i<preLoadStr.length; i++)
		{
			eval(preLoadStr[i]);
		}
	}
}

function changeStyle(obj, st)
{
	obj.className=st;
}

function switchLang (src, trg) 
{
	var s = document.location.search;
	if (s != "") {
		s = s.substr(s.indexOf("?")+1);
		var a = s.split("&");
		for (var i=0; i<a.length; i++) {
			if (a[i].toLowerCase().indexOf("lang_id") == 0) {
				a[i]= "lang_id=" + (trg=="en" ? 1 : 0);
			}
		}
		document.location = document.location.protocol + "//" + 
							document.location.hostname + 
							document.location.pathname + "?" + a.join("&");
	}
	else {
		document.location = document.location.href + "?lang_id=" + (trg=="en" ? 1 : 0);
	}
/*
  src = src + "/";
  trg = trg + "/";
  var str=new String(document.location);
	var i=str.lastIndexOf(src);
  if (i != -1) 
    document.location = str.substring(0,i) + trg + str.substr(i+src.length);
*/
}
