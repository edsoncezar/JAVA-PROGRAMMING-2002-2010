vti_encoding:SR|utf8-nl
vti_author:SR|IUSR_DEV-SERVER
vti_modifiedby:SR|IUSR_DEV-SERVER
vti_timecreated:TR|31 Jul 2001 09:32:08 -0000
vti_timelastmodified:TR|31 Jul 2001 09:32:08 -0000
vti_cacheddtm:TX|31 Jul 2001 09:32:08 -0000
vti_filesize:IR|5088
vti_extenderversion:SR|4.0.2.4426
vti_backlinkinfo:VX|
