<!--

/*
Configure menu styles below
NOTE: To edit the link colors, go to the STYLE tags and edit the ssm2Items colors
*/
YOffset=53; // no quotes!!
XOffset=0;
staticYOffset=30; // no quotes!!
slideSpeed=20 // no quotes!!
waitTime=100; // no quotes!! this sets the time the menu stays out for after the mouse goes off it.
menuBGColor="lightgrey";
menuIsStatic="yes"; //this sets whether menu should stay static on the screen
menuWidth=150; // Must be a multiple of 10! no quotes!!
menuCols=2;
hdrFontFamily="verdana";
hdrFontSize="2";
hdrFontColor="LightGrey";
hdrBGColor="#202050";
hdrAlign="left";
hdrVAlign="center";
hdrHeight="15";
linkFontFamily="Verdana";
linkFontSize="2";
linkFontColor="#FFFFFF";
linkBGColor="#202050";
linkOverBGColor="#507070";
linkTarget="_top";
linkAlign="Left";
barBGColor="#202050";
barFontFamily="Verdana";
barFontSize="2";
barFontColor="cornsilk";
barVAlign="center";
barWidth=24; // no quotes!!
barText="MANAGER"; // <IMG> tag supported. Put exact html for an image to show.

///////////////////////////

// ssmItems[...]=[name, link, target, colspan, endrow?] - leave 'link' and 'target' blank to make a header

ssmItems[0]=["Polls", "", ""] //create header
ssmItems[1]=["   Statistics", "/pollsadmin/cms/stats/stats_list.asp", "_PA_main"]
ssmItems[2]=["   Manipulate", "/pollsadmin/cms/poll/poll_list.asp", "_PA_main"]
ssmItems[3]=["   Preview", "/pollsadmin/cms/preview/default.asp", "_PA_main"]

ssmItems[4]=["", "", ""] //create empty line

ssmItems[5]=["Community", "", ""] //create header
ssmItems[6]=["   Users", "/pollsadmin/cms/user/user_list.asp", "_PA_main"]
ssmItems[7]=["   Visitors", "/pollsadmin/cms/visitor/visitor_list.asp", "_PA_main"]

ssmItems[8]=["", "", ""] //create empty line

ssmItems[9]=["Mail", "", ""] //create header
ssmItems[10]=["   Direct Mail", "/pollsadmin/cms/directmail/dmail_list.asp", "_PA_main"]

ssmItems[11]=["", "", ""] //create empty line

ssmItems[12]=["Access", "", ""] //create header

ssmItems[13]=["   Login", "/pollsadmin/cms/login/login_form.asp", "_PA_main", 1, "no"] //create two column row
ssmItems[14]=["   Logout", "/pollsadmin/cms/login/logout.asp", "_PA_main",1]

buildMenu();

	<!--#include virtual="/pollsadmin/cms/support/manager_menu.inc"-->
//-->