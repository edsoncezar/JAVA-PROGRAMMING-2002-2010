<SCRIPT LANGUAGE=javascript>
<!--

if (isIE()) {	
	var oPopup = window.createPopup();
	document.oncontextmenu = function() { dopopup(event.x,event.y); return false; }
	document.onmousedown = click;
}

function isIE() {
	if (window.navigator.appName=="Microsoft Internet Explorer" && 
		window.navigator.appVersion.substring(window.navigator.appVersion.indexOf("MSIE")+5, window.navigator.appVersion.indexOf("MSIE")+8) >=5.5) {
		return true;
	}
	return false;
}

function dopopup(x,y) {
	if(!isIE())
		return;

	var type=document.getElementById("menugenerator").value;
	var printtarget=document.getElementById("printtarget").value;
	var html;
	
	switch (type) { 
		case "new" :
			html="new";
			break; 

		case "edit" : 
		 	html+='<TABLE STYLE="border:1pt solid #808080" BGCOLOR="#CCCCCC" WIDTH="140" HEIGHT="160" CELLPADDING="0" CELLSPACING="1">';
		 	html+='<ST'+'YLE TYPE="text/css">\n';
		 	html+='a:link {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
		 	html+='a:visited {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
		 	html+='td {font-size:8pt;}\n';
		 	html+='</ST'+'YLE>\n';
		 	html+='<SC'+'RIPT LANGUAGE="JavaScript">\n';
		 	html+='\n<'+'!--\n';
		 	html+='window.onerror=null;\n';
		 	html+='/'+' -'+'->\n';
		 	html+='</'+'SCRIPT>\n';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i1" ONMOUSEOVER="document.all.i1.style.background=\'#CFD6E8\';document.all.i1.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i1.style.background=\'#CCCCCC\';document.all.i1.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.history.go(1);">&nbsp;<IMG SRC="/cms/menu2/images/menuselect.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Submit2</TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i2" ONMOUSEOVER="document.all.i2.style.background=\'#CFD6E8\';document.all.i2.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i2.style.background=\'#CCCCCC\';document.all.i2.style.border=\'1pt solid #CCCCCC\';" ONCLICK="javascript:window.parent.open('project_print_form.asp?pro_id=1', '_blank');">&nbsp;<IMG SRC="/cms/menu2/images/menusource.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Remove</TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC"><IMG SRC="/cms/menu2/images/pixel.gif" WIDTH="130" HEIGHT="1"></TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i3" ONMOUSEOVER="document.all.i3.style.background=\'#CFD6E8\';document.all.i3.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i3.style.background=\'#CCCCCC\';document.all.i3.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.print();">&nbsp;<IMG SRC="/cms/menu2/images/menuprint.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Print</TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i4" ONMOUSEOVER="document.all.i4.style.background=\'#CFD6E8\';document.all.i4.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i4.style.background=\'#CCCCCC\';document.all.i4.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.print();">&nbsp;<IMG SRC="/cms/menu2/images/menuprint.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Print All</TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC"><IMG SRC="/cms/menu2/images/pixel.gif" WIDTH="130" HEIGHT="1"></TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i5" ONMOUSEOVER="document.all.i5.style.background=\'#CFD6E8\';document.all.i5.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i5.style.background=\'#CCCCCC\';document.all.i5.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.parent.history.back();">&nbsp;<IMG SRC="/cms/menu2/images/menuback.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Back</TD></TR>';

		 	html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i7" ONMOUSEOVER="document.all.i7.style.background=\'#CFD6E8\';document.all.i7.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i7.style.background=\'#CCCCCC\';document.all.i7.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.parent.location.href;">&nbsp;<IMG SRC="/cms/menu2/images/menurefresh.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Refresh</TD></TR>';

		 	html+='</TABLE>';
			break; 
		case "list" : 
			html+='<TABLE STYLE="border:1pt solid #808080" BGCOLOR="#CCCCCC" WIDTH="140" HEIGHT="100" CELLPADDING="0" CELLSPACING="1">';
			html+='<ST'+'YLE TYPE="text/css">\n';
			html+='a:link {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
			html+='a:visited {text-decoration:none;font-family:Arial;font-size:8pt;}\n';
			html+='td {font-size:8pt;}\n';
			html+='</ST'+'YLE>\n';
			html+='<SC'+'RIPT LANGUAGE="JavaScript">\n';
			html+='\n<'+'!--\n';
			html+='window.onerror=null;\n';
			html+='/'+' -'+'->\n';
			html+='</'+'SCRIPT>\n';

			html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i1" ONMOUSEOVER="document.all.i1.style.background=\'#CFD6E8\';document.all.i1.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i1.style.background=\'#CCCCCC\';document.all.i1.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.history.go(1);">&nbsp;<IMG SRC="/cms/menu2/images/menuselect.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;New</TD></TR>';

			html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i4" ONMOUSEOVER="document.all.i4.style.background=\'#CFD6E8\';document.all.i4.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i4.style.background=\'#CCCCCC\';document.all.i4.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.print();">&nbsp;<IMG SRC="/cms/menu2/images/menuprint.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Print All</TD></TR>';

			html+='<TR><TD STYLE="border:1pt solid #CCCCCC"><IMG SRC="/cms/menu2/images/pixel.gif" WIDTH="130" HEIGHT="1"></TD></TR>';

			html+='<TR><TD STYLE="border:1pt solid #CCCCCC" ID="i7" ONMOUSEOVER="document.all.i7.style.background=\'#CFD6E8\';document.all.i7.style.border=\'1pt solid #737B92\';" ONMOUSEOUT="document.all.i7.style.background=\'#CCCCCC\';document.all.i7.style.border=\'1pt solid #CCCCCC\';" ONCLICK="window.parent.location.href=window.parent.location.href;">&nbsp;<IMG SRC="/cms/menu2/images/menurefresh.gif" WIDTH="12" HEIGHT="12" BORDER="0" HSPACE="0" VSPACE="0" ALIGN="absmiddle">&nbsp;Refresh</TD></TR>';

			html+='</TABLE>';
			break; 
		case "remrep" : 
			html="edit";
			break; 
		default : 
			html=type;
	} 
			
	var oPopupBody = oPopup.document.body;
	oPopupBody.innerHTML = html;
	
	switch (type) {
		case "edit" :
			oPopup.show(x, y, 140, 160, document.body);
			break;
		case "list" :
			oPopup.show(x, y, 140, 100, document.body);
			break;
	}
}

function click(e) {
	if(!isIE())
		return;
	if (event.button==2||event.button==3) {
		dopopup(event.x-1,event.y-1);
	}
}

//-->
</SCRIPT>
