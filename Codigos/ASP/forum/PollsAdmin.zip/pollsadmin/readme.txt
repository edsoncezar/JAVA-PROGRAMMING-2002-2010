Users Guide
------------------
Welcome to Polls Admin v1.2!

Requirements
--------------------
IIS or PWS, Microsoft Access 2000, (you can easily go to Access 97 if you want).
It would be nice to have in your computer the latest MDAC from microsoft.
The poll works great with 2.5 mdac.

Setting Up
---------------
1) Extract the files from the zip file in a folder that will be UNDER the root.
The folder name should definately be "pollsadmin".

2) Please include in your global.asa the following line: (as is)

<!--METADATA TYPE="TypeLib" NAME="Microsoft ActiveX Data Objects 2.5 Library" UUID="{00000205-0000-0010-8000-00AA006D2EA4}" VERSION="2.5"-->

It's a replacement for adovbs.inc. Or else you'll have to include adovbs.inc in all the .asp pages.

3) In the folder pollsadmin/cms/support/ and in the file utils.inc there is the function openDB.
You declare there where you mdb is located.

4) The default path for administration is pollsadmin/cms and 
for the public part pollsadmin/pub/poll_form.asp

5) The poll should start to work with at least 2 poll titles. The best is to enter in the
database and add some hits "manually"! for the first poll (which is closed).

New Stuff.
---------------
Ok the new stuff. 
1) The code has been organized into functions.
2) You can add, edit or delete any poll.
3) The visible poll on the public part is always the one with the most recent date of creation.
4) There is a CMS part for the admin(s). Default username and pass are: admin, sa
5) You can choose a poll with 2, 3 of 4 questions.
6) You can view statistics of hits. There are also printer-friendly pages for the statistics.
7) There is a mailing list! Through CDONTS the visitor is asked if he wants to be emailed with the
final results when the poll is closed!
8) You can customize the look of the public colors of the poll! (4 predefined sets of colors)

Please feel free to mail me at pbarbalias@hotmail.com
I would be very happy to get a card if you have the time to send one!
This is my address:

Panagiotis Barbalias,
Priamou 22,
Ag. Dimitrios,
17343,
Athens,
Greece

Version 3.0 will be developed if people will ask for it!
There is ready code to upgrade the Polls Admin to work with XML/XSL.
I would love to hear your opinion.