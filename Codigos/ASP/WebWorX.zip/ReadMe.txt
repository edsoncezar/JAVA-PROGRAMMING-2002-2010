#########
Features:
#########
Fully Database driven Web Site.
Ability to set membership requirement on any page.
ToolTips displayed on Hyperlinks.

##########
What's New
##########
Music has been added.
Voice Chat / Text has been added. (Compliments of HearMe.com)
Profanity checking has been added.
BlackListing has been added. (either by Email or IP Address)

In order use this App her is what you have to do:
***************************************************************
DO NOT ATTEMPT TO RUN THE APP UNTIL YOU COMPLETED THE FOLLOWING
***************************************************************
1. Unzip the WebWorX.zip file into a temorary Directory eg C:\TEMP\WebFiles
2. Using Visual Interdev or the WebSite Admnistrator - Create a NEW Web and call it WebWorX.
2. Add ALL the files in the "Images, General, Members" Directories to the Project.
3. Copy ALL the files in the "_Components" Directory to a Directory of your choice and REGISTER them with REGSVR32.exe
4. Copy the "WebWorX.mdb" Database into a Directory of your choice.
5. Create an ODBC DataSource called "mdbGoldWorX" and point to the DataBase.
6. Edit the "Params" Table in the Database and input your WebSite information.
7. Edit the "Global.asa" and change the "DevIP" and "WebIP" Application variables to YOUR IP Addresses.
8. Change the Setup Subroutine in "Global.asa" to reflect your choice of Database (You may upsize to SQL for your live site)
9. Create a Directory under the "ROOT" of the "INetPub" (or whatever you have called it) and name it "Common". eg: C:\InetPub\wwwroot\Common
10. Copy ALL the files in the "_Common" Directory to the one created in Step 9.

UNLESS YOU ARE AN ADVANCED DEVELOPER DO NOT CHANGE THE LOCATIONS OF THESE FILES

Notes:
(A) If you want to call the Web anything else but WebWorX then you will have rename ALL the INCLUDE Statements to reflect this.
(B) If you require support for this app then it is on a per pay basis.

So enjoy!
Brian Gillham.
WebMaster@FailSafe.co.za
