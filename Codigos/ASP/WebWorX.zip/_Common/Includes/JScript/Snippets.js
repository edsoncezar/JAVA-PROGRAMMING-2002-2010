// ##################
//  Global Functions
// ##################

var ROOT = "/WebWorX/";
var isNS4 = !(document.layers == null);
var isIE4 = !(document.all    == null);
var ItIs4 = (isNS4 || isIE4);
var isMac = (navigator.appVersion.indexOf("Mac") != -1) ?	true:false;
var isMnu = (isNS4 || (isIE4 && !isMac)) ?	true:false;

function ShowIt(id)
{	if		(isNS4) document.layers[id].visibility = "show"
	else if	(isIE4) document.all[id].style.visibility = "visible"
}

function HideIt(id)
{	if		(isNS4) document.layers[id].visibility = "hide"
	else if	(isIE4) document.all[id].style.visibility = "hidden"
}

function IgnoreIt()
{
}

function launch(newURL, newName, newFeatures, orgName)
{
	var remote = open(newURL, newName, newFeatures);
	if (remote.opener == null)
		remote.opener = window;
	remote.opener.name = orgName;
	return remote;
}

function ShowSiteMap()
{	var prms = "alwaysLowered,alwaysRaised=1,height=600,width=138,channelmode=0,dependent=1,directories=0,fullscreen=0,location=0,menubar=0,resizable=0,scrollbars=0,status=0,toolbar=0";
	if (ItIs4) SiteMap = launch(ROOT.concat("SiteMap.asp"), "SiteMap", prms, "main");
}
		
function RefreshFrame(FrameName, PageName)
{
	eval("parent." + FrameName + ".location='" + PageName + "'");
}

//set the below to the image you wish to use as the "new" image
var imagetag='<img src="' + ROOT.concat('Images/Common/New.gif') + '">'
var today=new Date()
function ExpireAt(expiredate)
{
	var expire=new Date(expiredate)
	if (today.getTime()<= expire.getTime())
	document.write(imagetag)
}

function PlaySound(midFile)
{
	if (midFile == "")	midFile = GetSndFile();
	if (isIE4)
		document.write('<bgsound src=' + '"' + midFile + '"' + ' loop="0">')
	else if (isNS4)
		document.write('<embed src="' + midFile + '" name="midSound" hidden="true" autostart="true" loop="no" border="0" width="2" height="2">')
	return midFile;
}

function GetSndFile()
{
	var BaseDir = "/Common/Includes/Sounds/"
	var sound1  = "clCandleWind.mid";
	var sound2  = "clIF.mid";
	var sound3  = "clPowerOfLove.mid";
	var sound4  = "clStreetsOfPhilli.mid";
	var sound5  = "clTheBoxer.mid";
	var sound6  = "mv2001.mid";
	var sound7  = "mv20Fox.mid";
	var sound8  = "mvExodus.mid";
	var sound9  = "mvGhostBusters.mid";
	var sound10 = "mvJurrasic.mid";
	var sound11 = "mvSchindler.mid";
	var sound12 = "mvTitanic.mid";
	var x = Math.round(Math.random()*11)
	if (x==0)		x = sound1;
	else if (x==1)	x = sound2;
	else if (x==2)	x = sound3;
	else if (x==3)	x = sound4;
	else if (x==4)	x = sound5;
	else if (x==5)	x = sound6;
	else if (x==6)	x = sound7;
	else if (x==7)	x = sound8;
	else if (x==8)	x = sound9;
	else if (x==9)	x = sound10;
	else if (x==10)	x = sound11;
	else			x = sound12;
	return BaseDir + x;
}

// #####################
// SiteMap Menu Specific
// #####################
function ToggleDisplay(oButton, oItems)
{
	if (isIE4)
	{
		if ((oItems.style.display == "") || (oItems.style.display == "none"))
		{
			oItems.style.display = "block";
			oButton.src = ROOT.concat("Images/Common/Minus.gif");
		}	else {
			oItems.style.display = "none";
			oButton.src = ROOT.concat("Images/Common/Plus.gif");
		}
	}
	else if (isNS4)
	{
		// ShowIt("'" + oItems + "'")
	}
}

function handleMouseover() {
	eSrc = window.event.srcElement;
	eSrcTag=eSrc.tagName.toUpperCase();
	if (eSrcTag=="DIV" && eSrc.className.toUpperCase()=="CLSTOCHEAD")	eSrc.style.textDecoration = "underline";
	if (eSrcTag=="LABEL") eSrc.style.color="#FF0000";
}

function handleMouseout() {
	eSrc = window.event.srcElement;
	eSrcTag=eSrc.tagName.toUpperCase();
	if (eSrcTag=="DIV" && eSrc.className.toUpperCase()=="CLSTOCHEAD")	eSrc.style.textDecoration = "";
	if (eSrcTag=="LABEL") eSrc.style.color="";
}

document.onmouseover=handleMouseover;
