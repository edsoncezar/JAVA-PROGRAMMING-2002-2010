//----------------------------------
// Routine to flash background color
//----------------------------------
function BlinkIt()
{	Intrvl=0;
	for(nTimes = 0; nTimes < 3; nTimes++)
	{	Intrvl += 200;
		setTimeout("document.bgColor='#000000';", Intrvl);
		Intrvl += 200;
		setTimeout("document.bgColor='#FF0000';", Intrvl);
	}
	setTimeout("document.bgColor='#FFFFFF';", Intrvl);
}

//----------------------------------
// Floating Menu Routines
//----------------------------------
var isNav = (navigator.appName.indexOf("Netscape")  != -1);
var isIE  = (navigator.appName.indexOf("Microsoft") != -1);
var isOn  = false
nsValue   = (document.layers);
check     = "no";
xpos1     =  1;	// make this the left pixel value for object1 below
ypos1     =  1;	// make this the top pixel value for object1 below
xpos11    = -50;
ypos11    = -50;
Xpos      =  5;
Ypos      =  5;

function CheckVersion4()
{	var	x = navigator.appVersion;
		y = x.substring(0,4);
	if (y >= 4) SetVariables(); MoveTB();
}

function SetVariables()
{	if (navigator.appName == "Netscape")
	{	h = ".left="; v = ".top="; dS = "document."; sD = "";}
	else
	{	h = ".pixelLeft = "; v=".pixelTop=";dS="";sD=".style";}
	objectX = "object11"
	XX      = -70;
	YY      = -70;
	OB      = 11;
}

function setObject(a)
{	objectX = "object" + a;
	OB      = a;
	XX      = eval("xpos" + a);
	YY      = eval("ypos" + a);
}

function getObject()
{	if (isNav) document.captureEvents(Event.MOUSEMOVE);	}

function releaseObject()
{	if (isNav) document.releaseEvents(Event.MOUSEMOVE);
	check   = "no";
	objectX = "object11";
	document.close();
}
function ShowTB()
{	if (isNav) document.object1.visibility = "show";
	else object1.style.visibility = "visible";
	isOn = true;
	document.onmousemove = MoveHandler;
	document.onclick     = getObject;
	document.ondblclick  = releaseObject;
}

function HideTB()
{	if (isNav) document.object1.visibility = "hide";
	else object1.style.visibility = "hidden";
	isOn = false;
	document.onmousemove = null;
	document.onclick     = null;
	document.ondblclick  = null;
}

function MoveTB()
{	eval(dS + objectX + sD + h + Xpos);
	eval(dS + objectX + sD + v + Ypos);
}

function MoveHandler(e)
{	Xpos = (isIE) ? event.clientX : e.pageX;
	Ypos = (nsValue) ? e.pageY : event.clientY;
	if (check == "no")
	{	diffX = XX-Xpos;
		diffY = YY-Ypos;
		check = "yes";
		if (objectX == "object11") check = "no";
	}
	Xpos+=diffX;
	Ypos+=diffY;
	if (OB=="1") xpos1 = Xpos, ypos1 = Ypos;
	MoveTB();
}

if (isNav)
{	document.captureEvents(Event.CLICK);
	document.captureEvents(Event.DBLCLICK);
}