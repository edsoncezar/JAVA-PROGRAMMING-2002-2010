// create NS cross-browser object
function SafeNewObject(obj)
{	this.obj          = obj;		// cannot assign object directly to "this"
	this.name         = obj.name;
	this.objHide      = objHide;
	this.objShow      = objShow;
	this.objGetLeft   = objGetLeft;
	this.objGetTop    = objGetTop;
	this.objSetTop    = objSetTop;
	this.objSetLeft   = objSetLeft;
	this.objSetZIndex = objSetZIndex;
}

// NEW FUNCTION - objSetZIndex
function objSetZIndex(zindex)
{	this.obj.zIndex = zindex;	}

// hide element
function objHide()
{	this.obj.visibility = "hidden";	}

// show element
function objShow()
{	this.obj.visibility = "inherit";	}

// element's left position
function objGetLeft()
{	return this.obj.left;	}

// element's top position
function objGetTop ()
{	return this.obj.top;	}

// set element's top position
function objSetTop(top)
{	this.obj.top = top;	}

// set element's left position
function objSetLeft(left)
{	this.obj.left = left;	}

// function to instantiate equalizer objects
function SafeCreateObjects()
{	SafeObjs = new Array(document.layers.length);
	for (i = 0; i < document.layers.length; i++)      
	// check to see if Netscape assigned block
	if (document.layers[i].id.substring(0,3) != "_js") 
	SafeObjs[document.layers[i].id] = new SafeNewObject(document.layers[i]);
}
