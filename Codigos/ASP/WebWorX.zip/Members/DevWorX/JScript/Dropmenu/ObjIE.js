// create IE DHTML equalizer object
function SafeNewObject(obj)
{	this.obj          = obj.style;
	this.name         = obj.id;
	this.objHide      = objHide;
	this.objShow      = objShow;
	this.objGetLeft   = objGetLeft;
	this.objGetTop    = objGetTop;
	this.objSetTop    = objSetTop;
	this.objSetLeft   = objSetLeft;
	this.objSetZIndex = objSetZIndex;
}

// NEW FUNCTION
function objSetZIndex(zindex)
{	this.obj.zIndex = zindex;	}


// hide element
function objHide()
{	this.obj.visibility = "hidden";	}

// show element
function objShow()
{	this.obj.visibility = "inherit";	}

// element's left position
function objGetLeft()
{	return this.obj.pixelLeft;	}

// element's top position
function objGetTop ()
{	return this.obj.pixelTop;	}

// set element's top position
function objSetTop (top)
{	this.obj.pixelTop = top;	}

// set element's left position
function objSetLeft(left)
{	this.obj.pixelLeft = left;	}

// function to create named and un-named objects
function SafeCreateObjects()
{	TheElements = document.all.tags("DIV");
	SafeObjs = new Array();
	for (i = 0; i < TheElements.length; i++)
	{	if (TheElements[i].id != "")
		{	SafeObjs[TheElements[i].id] = new SafeNewObject(TheElements[i]);
		}
	}
}
