EZsite WebNotes


===================================================================
THE OnLineDocumentation.htm FILE WILL INSTRUCT YOU ON GETTING
EZsite WebNotes WORKING ON YOUR SYSTEM. The OnLineDocumentation.htm
CAN BE FOUND IN THE DIRECTORY WHERE YOU INSTALLED EZsite WebNotes
===================================================================

With EZsite WebNotes you can quickly post information to a selected area 
of any web page. Just place a server-side component (no client-side ActiveX, 
VBscript, Java, or Javascript) on your web page, use the WebNote Manager 
through your own browser to enter a note, and it's posted immediately! 


Requirements:
- IIS 3 or IIS 4 with Active Server Pages.
- An ODBC datasource. Sample Access (.mdb) is supplied. The ODBC datasource
  must be named "DSNWebNotes".
- Any browser. Support for frame is preferable.
- For this version, ASP's Session state must be enabled.


Current Version: 1.0

Instructions:
Your initial account name is 'account'
Your initial password is 'password'

You can load the OnLineDocumentation.htm and  WebNotesDemo2.asp files in your browser
to see a demo web page using WebNotes.

To create your own web page using WebNotes simply
place two lines of asp code in the area you want to
display WebNotes (using WebNotes in a Table is sometimes
best).

   Here are the two lines of code that will display WebNotes:
	--------------------------------------------------------
	<%
	Set ObjWebNotes = Server.CreateObject("EZsite.WebNotes")
	ObjWebNotes.ShowWebNotes
	%>
	--------------------------------------------------------

If you use the group option when creating or editing
a WebNote, you can show only those notes with this
group number by using it as a argument when calling
WebNotes.

   Here only the WebNotes with a group number one will
   be displayed:
	--------------------------------------------------------
	<%
	Set ObjWebNotes = Server.CreateObject("EZsite.WebNotes")
	ObjWebNotes.ShowWebNotes(1)
	%>
	--------------------------------------------------------

If you have more than one area in your web page that
displays various groups of WebNotes you can create
the WebNotes object once and then call the display method 
multiple times.


   In one part of your web page:
	--------------------------------------------------------
	<%
	Set ObjWebNotes = Server.CreateObject("EZsite.WebNotes")
	ObjWebNotes.ShowWebNotes(1)
	%>
	--------------------------------------------------------

   In another part of your web page:
	--------------------------------------------------------
	<%
	ObjWebNotes.ShowWebNotes(4)
	%>
	--------------------------------------------------------


Upsizing to Microsoft SQL Server:

MS SQL server can be used with EZsite WebNotes by doing the following:
- Create a database named WebNotes.
- Run the batch file "createMSSQL.bat"
	- This file can be found in the Database directory
		<InstallPath>\Database
	- This will create the appropriate tables and populate them with data.
	- Edit the file to change the username and password to the database if necessary.
- Finally create a DSN in ODBC which uses this database.
	- Be sure to check the checkbox "Change the default database to:"
	- Set the default database to WebNotes
- Name the Data Source Name DSNWebNotes.


Possible Error Messages:
E R R O R : [Microsoft][ODBC Microsoft Access 97 Driver] '(unknown)' isn't a valid path.

This typically means that your ODBC datasource is not correctly configured.
To correct this:
- Open the Control Panel
- Select "ODBC"
- Click on the "System DSN" Tab
- If there is an existing DSN called "DSNWebNotes", select it and click on
	"Configure..."
- If there is no existing DSN called "DSNWebNotes", Click on the "Add..."
	button, and then select "Microsoft Access Driver"
- The Data Source name should be: "DSNWebNotes" (without quotation marks).
- Using the "Select..." button to find the WebNotes.mdb file.
	- This is typically in
	 "C:\database"
- Click "OK" twice to dismiss the dialog boxes




For more information:
http://www.dougdean.com

Copyright (c), 1998 Doug Dean Software & Consulting