/****** Object:  Table dbo.AccountTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.AccountTable') and sysstat & 0xf = 3)
	drop table dbo.AccountTable
GO

/****** Object:  Table dbo.ColorTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.ColorTable') and sysstat & 0xf = 3)
	drop table dbo.ColorTable
GO

/****** Object:  Table dbo.ExampleFlagTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.ExampleFlagTable') and sysstat & 0xf = 3)
	drop table dbo.ExampleFlagTable
GO

/****** Object:  Table dbo.FontTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.FontTable') and sysstat & 0xf = 3)
	drop table dbo.FontTable
GO

/****** Object:  Table dbo.NoteTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.NoteTable') and sysstat & 0xf = 3)
	drop table dbo.NoteTable
GO

/****** Object:  Table dbo.StyleTable     ******/
if exists (select * from sysobjects where id = object_id('dbo.StyleTable') and sysstat & 0xf = 3)
	drop table dbo.StyleTable
GO

/****** Object:  Table dbo.AccountTable     ******/
CREATE TABLE dbo.AccountTable (
	AccountID int IDENTITY (1, 1) NOT NULL ,
	AccountName varchar (50) NULL ,
	AccountPassword varchar (50) NULL ,
	TimeStamp datetime NULL ,
	SecurityCode datetime NULL ,
	AccountGroupID numeric(18, 0) NULL ,
	CONSTRAINT PK_AccountTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		AccountID
	)
)
GO

/****** Object:  Table dbo.ColorTable     ******/
CREATE TABLE dbo.ColorTable (
	ColorID int IDENTITY (1, 1) NOT NULL ,
	ColorName varchar (50) NULL ,
	ColorCode varchar (50) NULL ,
	CONSTRAINT PK_ColorTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		ColorID
	)
)
GO

/****** Object:  Table dbo.ExampleFlagTable     ******/
CREATE TABLE dbo.ExampleFlagTable (
	ID int IDENTITY (1, 1) NOT NULL ,
	ExampleFlag numeric(18, 0) NULL ,
	CONSTRAINT PK_ExampleFlagTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		ID
	)
)
GO

/****** Object:  Table dbo.FontTable     ******/
CREATE TABLE dbo.FontTable (
	FontID int IDENTITY (1, 1) NOT NULL ,
	FontName varchar (50) NULL ,
	CONSTRAINT PK_FontTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		FontID
	)
)
GO

/****** Object:  Table dbo.NoteTable     ******/
CREATE TABLE dbo.NoteTable (
	NoteID int IDENTITY (1, 1) NOT NULL ,
	StyleID numeric(18, 0) NULL ,
	GroupID numeric(18, 0) NULL ,
	TitleText varchar (100) NULL ,
	HyperText varchar (100) NULL ,
	HREF varchar (50) NULL ,
	NoteBeginDate datetime NULL ,
	NoteEndDate datetime NULL ,
	NoteOrder numeric(18, 0) NULL ,
	NoteTimeStamp datetime NULL ,
	BodyText text NULL ,
	CONSTRAINT PK_NoteTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		NoteID
	)
)
GO

/****** Object:  Table dbo.StyleTable     ******/
CREATE TABLE dbo.StyleTable (
	StyleID int IDENTITY (1, 1) NOT NULL ,
	StyleName varchar (50) NULL ,
	EZtimeStamp datetime NULL ,
	NoteWidth varchar (50) NULL ,
	NoteBorderWidth varchar (50) NULL ,
	NoteBorderColor varchar (50) NULL ,
	NoteAlign varchar (50) NULL ,
	Note3DBorderWidth varchar (50) NULL ,
	NoteEndSpace varchar (50) NULL ,
	TitleBackGroundColor varchar (50) NULL ,
	TitleTextColor varchar (50) NULL ,
	TitleTextSize varchar (50) NULL ,
	TitleTextFont varchar (50) NULL ,
	TitleTextBold varchar (50) NULL ,
	TitleTextItalic varchar (50) NULL ,
	TitleTextAlign varchar (50) NULL ,
	Title3DBorderWidth varchar (50) NULL ,
	TitlePadding varchar (50) NULL ,
	TitleMargin varchar (50) NULL ,
	BodyBackGroundColor varchar (50) NULL ,
	BodyTextColor varchar (50) NULL ,
	BodyTextSize varchar (50) NULL ,
	BodyTextFont varchar (50) NULL ,
	BodyTextBold varchar (50) NULL ,
	BodyTextItalic varchar (50) NULL ,
	BodyTextAlign varchar (50) NULL ,
	Body3DBorderWidth varchar (50) NULL ,
	BodyPadding varchar (50) NULL ,
	NoticeLifeTime varchar (50) NULL ,
	NoticeCaption varchar (100) NULL ,
	NoticeDateFormat varchar (50) NULL ,
	NoticePosition varchar (50) NULL ,
	NoticeTextColor varchar (50) NULL ,
	NoticeTextSize varchar (50) NULL ,
	NoticeTextFont varchar (50) NULL ,
	NoticeTextBold varchar (50) NULL ,
	NoticeTextItalic varchar (50) NULL ,
	CONSTRAINT PK_StyleTable_1__10 PRIMARY KEY  CLUSTERED 
	(
		StyleID
	)
)
GO
