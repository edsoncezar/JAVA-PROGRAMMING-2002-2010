This doesn't have any docs except for what's in the code - that's why it's an alpha.
The alpha2 version (this one) actually works completely (at least as anticipated). The
alpha1 version was missing the full results and some other things and was just a headache.

INSTALLATION:
============

Unzip this into a directory and call webvote20a2.asp to get it started - it should work
from there. Enjoy.

PS -
==
I've included an article of gratuitus advertising, put it on your site if you like.
It's 468x60wt2000.gif.