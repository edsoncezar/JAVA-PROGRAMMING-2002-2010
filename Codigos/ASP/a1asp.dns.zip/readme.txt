a1asp.dns -- domain name resolution and reverse resolution
Copyright (C) Alex Popkov, 2001


PURPOSE

This component provides two functions for DNS lookups (forward and reverse).


COST

This component is free.


NO WARRANTIES

Bacause this component is free, no support provided and no updates/bugfixes available.
As usual, you use this software on your own risk and I am not responsible
for any sort of damage including software/hardware glitches, a finansial loss etc.


INSTALLATION

As usual.


USAGE

1) Create an instance:

	set obj = CreateObject( "a1asp.env" )

2) Forward DNS lookup:
	host = "www.microsoft.com"
	addr = obj.DNSLookup( cstr(host) )

3) Reverse DNS lookup:
	addr = "64.176.74.101"
	host = obj.ReverseDNSLookup( cstr(addr) )

4) Notes:
	- both of these functions return empty string "" if a lookup has been unsuccessfull.
	- do not forget about cstr() in function call -- it is important.

A test script dns.vbs is included as well as test page dns.asp.


CONTACTS

Visit http://a1lab.com

--
