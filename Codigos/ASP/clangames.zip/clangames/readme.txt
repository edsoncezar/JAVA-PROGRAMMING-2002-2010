Clangames - Copyright 2001 Michael Marshall
http://www.blue-army.net/scripts/

Version 2.2
3 June 2001

Changes
-------

Version 2.2

This is a major bug fix release, your current clangames
installation MUST be overwritten for it to work correctly.
N.B Backup your config.asp first and copy its details into 
the new config.asp.

- admin_matches.asp date bug fix for non-us date formats
- admin_news.asp date bug fix for non-us date formats
- all pages - added cookie security added
- admin pages - new security level added - moderator - 
  admin all pages but profiles
- results.asp - added abilty to have colour coded results 
  (win, lose, draw colours)

Version 2.1
- players.asp bug fix

Version 2.0
- 1st release

Intro
-----

Clangames was written way back in mid 2000 by 
Michael Marshall ([B-A]Mikey) for the [B-A] TFC 
clan's web site.  There didn't seem to be any scripts 
around to fit what [B-A] needed so he decided to 
make his own.  These scripts are coded from scratch 
using ASP and all copyright belongs to Michael Marshall.�

Features
--------

Basically this suite of scripts can form the 
basis for your clan web site, all that is missing 
is the forum really!

* Individual logins -  add a userid/password for 
  each of your clan players, they can then edit 
  their profile, assign themselves to match, check 
  results and a whole lot more.

* Power users - The admin can assign users as admin 
  level so they may add/delete/edit matches/results 
  and add news, maps etc.

* Match Scheduler - Add a match in the future (or past 
  if you simply want to add a result), then players from 
  your clan can login and assign themselves to a match 
  (I can play, I cannot play etc).

* Results - When a match has been scheduled it 
  automatically goes into the results section after the 
  game has been played.  An admin edits the match result 
  and it is displayed on this page.  Stats are given for 
  the clan as a whole and for individual clan battle histories.

* News - Add/edit/delete news which can be included on any 
  page (along with headlines).

* Member list - A list of all the current members in the 
  clan with emails, icq, profile etc.

Requirements
------------

* NT or Win2k based Web Server�
* ASP�
* ADO 2
* Filesystem Object
* Read/Write access to web dir by IIS_USER
* 2mb free disk space
* Ability to use notepad to edit a config file :P

Simple Instructions
-------------------

* Unzip clangames.zip to a directory on your web server.

* Edit config.asp in your fave editor (Notepad is suggested).

* Most of the editing of the config.asp is self explanitory, 
  however I suggest you rename the clangames.mdb to a more hard
  to guess name (such as clangames19345.mdb), this will stop people 
  downloading your database.

* Headers and Footers - a blank header.asp and a blank footer.asp 
  has already been created for you.  To make clangames look like 
  your website, simply alter the header.asp and footer.asp (the 
  best way to surround this system is to enclose it in a cell).

* Load up the index.asp file in your browser, login as your hard
  coded user/password.

* Add an admin user

* Log out then log back in with the admin user.

* Add any maps your clan plays and all your members names into 
  the profiles section.

* Finished!�

Important - Including News
--------------------------

First of all load up headlines_template.asp into notepad and alter /index.asp to be your webpage with the news on (could be /yourhomepage/news.asp etc).

The 2 templates for news and the headlines are pretty simple, if you wish to edit how these are displayed then simply edit the news_template.asp and headlines_template.asp files (build on the simple ones but be careful, there is ASP code in these templates, read the comments at the beginning of each file).

Once you have the right template set up, simple use a #include to include the news onto your web site.

E.g. 
<!-- #include virtual="/clangames/news.txt" -->    (Includes main news)
<!-- #include virtual="/clangames/headlines.txt" -->    (Includes headlines)

The above assumes you installed the clangames script into a folder called /clangames/.

Additional Information
----------------------

There are a few clever bits to these scripts.  If you wish just to display the results for a particular mod then use the following syntax:

http://www.blue-army.net/clangames/results.asp?mod=tfc
http://www.blue-army.net/clangames/results.asp?mod=cs 

Also you can include a list of the upcoming games for the next 7 days by using the following Javascript (where /clangames/ is your clangames directory - change the mod= to display the games for a particular mod you play).

<script language="JavaScript" src="/clangames/js_matches.asp?mod=tfc"></script>

