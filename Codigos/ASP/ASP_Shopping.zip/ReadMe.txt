Name: Shopping Cart with Intranet
Programmer: Christian Remington http://www.accessdeveloper.com
Languages: ASP(Classic), HTML, etc.
Database: Microsoft Access 2000
Description: This example demonstrates a fictitious shopping cart including an intranet(or administrative backend). 
Date: 3/17/00

****All I ask is that you keep my name as one of the programmers.****
****Please, don't email me asking for help with this script. Thanks.****


Instructions: Place all files in the same directory/folder. Enjoy.



