Most of the codes are extracted from HOTMAIL and YAHOO!. I had modified some lines. 

To see the example please open index.htm file.

If you get problem report me at npguy@my-deja.com, npguy@hotmail.com

Good Luck!!