AJ | Hit Counter v2.0
By: Adam Jarret

Place the line
<!--#include file="ajhit.asp"-->
at the top of any asp page you want the hits to be counted. If you place the counter on more then one page the data will reflect the combined hits on all pages counted.

To view how many hits you have, the IP of the person who visited the page and the date on which they visited open the �ajhit_admin.asp� file in a compatible browser.

NEW!!! � Now a text counter can be displayed on the page! Place the line
<!--#include file="ajhit_count.asp"-->
at the top of the page you want to display the number of hits on. Then to display the number, pasted the line 
<% response.write ("<p align=left><font size=2 face=Verdana color=#000000>Total Hits:" & rSum & "</font></p>") %>
in the html where you want the number to appear on the page.

Example:

<html>
<head><title>AJ | View Hits (Detailed)</title></head>
<body text=#000000 link=#000066 alink=#000066 vlink=#000066>
<table border="1" width="100%"><tr>
    <td><% response.write ("<p align=left><font size=2 face=Verdana color=#000000>Total Hits:" & rSum & "</font></p>") %></td></tr>
</table>
</body>
</html>


As far as installation goes this script is basically ready to go as is. All you need to do is set the path of the database in the �ajhit.asp� and �ajhit_admin.asp� files. There are notes in the source code of the respective files if you need help on this. Upload all files and make sure write permissions are set on the database.

You are free to distribute this source code as long as you give me credit and put a link to RandomRavings.cjb.net on your Website.

---
Questions, Complaints Compliments and Bugs can be sent to kerplunk420@hotmail.com 
