Create Table messages
	(
	message_id int Not Null Identity (1, 1),
	forum_id int Not Null,
	thread_id int Not Null,
	thread_parent int Not Null,
	thread_level int Not Null,
	message_author varchar(50) Not Null,
	message_author_email varchar(50) Null,
	message_author_notify bit Not Null Constraint DF_messages_message_author_notify Default (0),
	message_timestamp datetime Not Null,
	message_subject varchar(50) Not Null,
	message_body text Not Null
	)
Go
Alter Table messages Add Constraint
	PK_messages Primary Key Nonclustered
	(
	message_id
	)
Go
Create Nonclustered Index IX_messages_mid On messages
	(
	message_id
	)
Go
Create Nonclustered Index IX_messages_tid On messages
	(
	thread_id
	)
Go
Create Nonclustered Index IX_messages_fid On messages
	(
	forum_id
	)
Go
Create Nonclustered Index IX_messages_fid-tp On messages
	(
	forum_id,
	thread_parent
	)
Go
