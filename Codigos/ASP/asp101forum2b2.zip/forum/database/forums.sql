Create Table forums
	(
	forum_id int Not Null Identity (1, 1),
	forum_name varchar(50) Not Null,
	forum_description varchar(50) Not Null,
	forum_start_date datetime Null,
	forum_grouping char(10) Null
	)
Go
