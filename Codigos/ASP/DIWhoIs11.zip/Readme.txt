www.WebTest2000.com presents --

DIWhoIs v1.1
============

DIWhoIs is a simple COM object that can be used in ASP (or anywhere for that matter)
to display the whois lookup information for a particular domain. DIWhoIs is very 
simple to use with IIS / ASP, VB, C++ or Delphi.

INSTALLATION
------------
1. Simply copy DIWhoIs.dll into a directory that has Execute permissions allowed for
IUSR_SERVERNAME. A perfect location is your \WINNT\System32 directory.

2. You must register the com object by going to a DOS prompt, finding the location
where the .dll resides and typing

         C:>regsvr32 DIWhoIs.dll

3. Call DIWhoIs from your scripts!

DIWhoIs Properties and Methods
------------------------------

Properties:
Host - the whois server (defaults to whois.internic.net)
Port - the port to connect to (defaults to 43)
Domain - the domain you want to lookup
Results - standard results using CRLF to end a line
HTMLResults - HTML formatted results using <BR> to end a line

Methods:
Lookup - Performs a whois lookup using Host, Port and Domain. Places the results
  in Results and HTMLResults properties

ASP Scripting Examples
----------------------

  set mWhoIs = Server.CreateObject("DIWhoIS.DiWhoIs")
  mWhoIs.Host = "whois.internic.net"
  mWhoIs.Port = 43
  mWhoIs.Domain = "dyessindustries.com"
  mWhoIs.Lookup
  response.write mWhoIs.Result

Troubleshooting
---------------
Access Denied: if you get an access denied error, you didn't give IUSR_SERVERNAME
where SERVERNAME is the NETBIOS name of your server, execute permissions on the 
DIWhoIs.dll file.

