This is a very basic up and download component. Developed to give you an idea of how to set a binary stream and download files. Full source code is included in this zip file. 

Disclaimer: Use at your own risk, Patrick Santry assumes no responsibilty for the use of this object.


Sample routines that you insert into your ASP code:

Sub UploadFile
	Set ObjUpload = Server.CreateObject("WinASP.FileAction") 
    ObjUpload.DoUpload(Request("Path"))
    Set ObjUpload = Nothing
End Sub
'_____________________________________________________

Sub DownloadFile
	Set ObjDownload = Server.CreateObject("WinASP.FileAction") 
	ObjDownload.Download = True
	ObjDownload.MIMEType = True
	ObjDownload.DoDownload Request("File"), Request("Path")
	Set ObjDownload = Nothing
End Sub

To register the included DLL for use in your ASP.

Go to the command prompt and type:
regsvr32 <drive>:\FileLocation\WinASP.dll