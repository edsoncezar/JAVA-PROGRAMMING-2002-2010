

<script LANGUAGE="JScript"><!--

 function AbortEntry(sMsg, eSrc)
 {
  window.alert(sMsg);
  eSrc.focus();
 }

 function HandleError(eSrc)
 {
  var val = parseInt(eSrc.value);
  if (isNaN(val))
  {
   return AbortEntry("Must be a numeric number.", eSrc);
  }

  if (val <= 0) 
  {
   return AbortEntry("Please enter a positive number.", eSrc);
  }
 
  if (val = "") 
  {
   return AbortEntry("This field is required.", eSrc);
  }
 }
  
//-->
</script>



