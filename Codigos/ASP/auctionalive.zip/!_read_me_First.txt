
Welcome to Auction aLive! from KnightZone.com


The best FREE server based, live action, database auction application you 
will find anywhere.



Application Requirements:
Server software capable of ASP support with DNS-less database access. 
Browser capable of viewing frames and using javascript. 
A list of items to be auctioned. 
A list of bidders to purchase those items. 
Access from system admin to write to and delete from databases. 
Microsoft operating system preferred, ( 95,98,NT,2000 Pro,XP Pro ) 
Introduction: 
This software application was not intended for over the web transactions. It has 
NO security features built-in to protect your data. You could probably call this 
a proprietory stand-alone application. However, it has many features built in for 
it's intended purpose. It's purpose was to monitor and record a live auction with 
real people all in the same room. You know the old fashioned way. I searched the 
net over trying to find a FREE software application which did this. I came up empty 
in my search, so I decided to write my own which you have graciously downloaded and 
are viewing now. This application requires human interaction during a live auction. 
As the auctioneer is selling items, someone sits at the computer and inputs the data 
as it is being sold. Then after the auction is over all bidders have to come by and 
checkout with the computer to get their receipt before they can leave with their 
purchased items. You know, the old fashioned way. I had a friend of mine approach 
me about writting a piece of software for a local charity auction to record 
transactions for the auction as it was going on, LIVE!. I informed him that I 
write web applications and software and that I would try it. I saw it as a 
challenge. I had never seen such an application like this done before so I pulled 
out my source code editor and went to work. What makes this application special is 
it's ability to function without all the special coding required by the end 
user, YOU. You do not have to know the first thing about source coding to operate 
this application. Just unzip it, extract it into your web folder and start the 
application. Simple as 1, 2, 3. So here we are.



Set-Up Instructions: 
Find on your local hard drive, the directories or folders that can be reached with 
a browser through the http://127.0.0.0 address while running your server software. 
You can use Microsoft's Personal Web Server among others. Create a folder or 
directory somewhere called "auction". So you will eventually access this 
application by directing your browser to http://127.0.0.0/auction/default.asp. 
Be sure to have your web server application running before accessing this page 
as you will get an error if you click on the links from that page without the 
server running. Next, empty the contents of the "auctionalive.zip" into the 
folder you just created. A blank access database will be included in this folder 
which will store all the data neccessary to operate your auction. The database 
name is "auctionalive.mdb" and is included in the downloaded zip file. Be sure 
to access your server admin functions to allow read/write/execute/delete 
functionality to the database file. If you do not do this you will receive 
an error when you try to write or delete from the database. You do not have to 
create a DNS connection in your server software as I have written in DNS-less 
connection code already into the application. Simplicity is the key word here, 
I've tried to make this application as dummy-proof as possible and still try to 
accomplish it's intended parameters. I often refer to this simplicity outlook 
as the "KISS" profile which means, "Keep It Simple Stupid". Once you have done 
all of the preceding steps, you are now ready to start the application.



Starting the Application:
Open your browser and type in the url location of the "default.asp" file which 
you placed in the web server folders. If you named it the same as mine, then you 
should reach the default page from this url: 

http://127.0.0.0/auction/default.asp

Unless of course you placed it somewhere else which you will have to type in the 
exact location for your own system as I do not know where you placed it. I'm here, 
you're there, how am I supposed to know that. REMEMBER: You HAVE to start your 
server software before running this application. If not, you will not be able 
to access the database. Once you have typed in your url and opened up the 
default page, you will see the "Auction aLive" banner in the top frame along 
with a list of links underneath the banner which will guide you through the 
application. DO NOT run this application without the frameset. You WILL NOT 
be able to navigate between sections. I tried my best to place the top frame 
links in chronological order as to the way a real live auction would take 
place from left to right. The main page link will take you back to the main 
area where you can receive helpful information and disclaimer statements 
concerning the application. You will also be presented with an e-mail address 
to send your technical questions to. However, I will do my best to answer 
them as I may not know everything, like "Why is the sky blue?". You will have 
to seek a higher authority than me to answer that one. Next thing you need to 
do is to enter all the auction items you intend to sell into the database. 
NOTE: Please be sure to tag each item with a different "Item Number". You may 
enter as many items as you like into the database as far as your memory, your 
operating system and Microsoft's limits on Access Databases goes. However, I 
will remind you that the more items you have in your database the slower the 
processing will be for the application. As the VB routines can get somewhat 
complex at times. So I would suggest that if you have more than 400-500 items 
for sale you may want to use a different application. Once you have tagged 
all your items with a "NUMERIC" number (NO ALPHA). Be sure to enter this 
number into the "Item Number" field along with the asking price of each item. 
The asking price should also be "NUMERIC" with NO dollar sign ($). Then enter 
a very brief description of this item. Brief, I mean as in under 75 characters. 
Yes you may use alpha characters in this field. But please be descriptive of 
each item as the description will be printed on the bidder's paid receipt at 
the end of the auction. The "Owner Info" field is strictly for admin only as 
it will show up in the database listings but not on the bidder's receipt. A 
good example of what this field is used for is to explain a little more detail 
about the item. Say for instance, you had an item for sale that had a 
description like this: "Full Sofa and Love Seat Living Room Set". Well you 
could also go into further detail with the owner category by saying: "It was 
once owned by Prince Charles and Princess Diana of Wales". To denote that 
it's value has increased for some people who may intend to bid higher now 
that they know where it came from. The "Owner Info" field is used for this 
purpose. However, you may leave it blank if you wish. But the other 3 input 
fields are required to operate the database properly. Once you have entered 
your required fields then click the "Enter Item" button. Once you click the 
button you should see your item listed in the table listing below. Please 
note that the "Bidder Number" and "Sell Price are empty. As these will remain 
empty until the item is sold. You will also see the Item Number, Asking Price, 
Description and Owner Info listed. Once you start entering data, I have 
included a last 3 scroll listing which will help you remember where you are 
in entering your items so you do not have to go to another screen to find out 
what was the last thing you entered. This is done by writing a time signature 
from your operating system into a separate column for each item. Then it is 
sorted from the SQL Query by the time signature. So if you want to skip 
around items you may do so. You do not have to enter items in numerical 
order. Once you entered all the items in your auction, then click on the 
view all link which will show a listing in Item Number Sequence. You can 
also use this link to visually check to see if you have left any items out 
of the auction. If your auction coordinator needs a complete listing of 
their auction this is the perfect place to get it. If you are unhappy with 
some entries in the item listing or you have entered the data wrong, you 
have an opportunity to delete that entry by clicking the "Delete Item" from 
any page where it is displayed. Clicking the admin link gives you the 
opportunity to delete all items or bidders or both as desired. But be careful 
using thes procedure as they will delete your entire database if not used correctly. 
Back in the view all screen Scan the list down until you find the item number you 
want to delete. Then click the "Delete" button to delete it from the database. 
You may delete more than one if you wish, however remember to keep track of 
which ones you delete for you have to re-input those item numbers once again 
in the Item Info section. If you do not your database will have numerical 
holes in sequence. Once you visually checked out each item and concluded the 
item listing as satisfactory then you are ready to move on to the bidders info 
link in the top frame. Click on the "Bidder Info" link and start inputting data 
into the bidders section just like you entered into the item section. The bidder 
numbers do not have to be in numerical order. Say for instance you have "Fred" 
who comes to every auction you have and he always uses the same bidder number, 
149 which stands for his birthday of January of 1949. Well you can assign that 
bidder number to him and nobody else can use it. It might be a good time to 
mention that bidder paper forms should be filled out by each bidder before 
the auction starts. These bidder forms contain the data which you will need 
to add them to the database. So you are pre populating the bidder database 
before the bidding starts. If a bidder comes in late, you have the option 
to click the bidder info link in the top frame and add them in just a few 
seconds. Once again enter the bidder number as "NUMERIC" NOT "ALPHA". 
These Item numbers and bidder numbers can be up to 12 digits each. The 
bidder's phone number, name and address IS REQUIRED as well as the bidder 
number. Just in case you have someone skip out on you after the auction, 
you will have the information neccessary to give to the proper authorities. 
After you have entered at least one bidder, the bottom half of you browser 
should show a listing of the last 3 bidders you entered. If you want to 
see a numerical listing, click on the "View All" link and see all bidders 
listed in the database. This normally is done when you have finished 
inputting all the bidders for your auction. Then you can tell how many 
people will be bidding from the detailed listing. Probably 99% of the 
time you will wait until the day of the auction to enter this information 
about the bidders. As you will probably not know who is going to show up 
until right before your auction starts. If you have made any human errors 
in typing or bidder numbers, you need to fix it before the auction starts. 
As when the auction starts you will be busy inputting data into the database 
as each item is sold. Once you are satisfied with your bidder info, it is 
time to get your auctioneer in motion. When you are ready to start click 
on the "Auction" link in the top frame. You will see your input data fields 
for each item selling in your auction. As the auctioneer sells each item, 
quickly enter the item number, the price and the bidder number of the bidder 
who bid the highest for that item. Once that item is sold then click the 
"Item Sold" button and that info is sent to the database for bidder 
checkout at a later time. If you have breaks in your auction, you may 
click on the "Auction Status" link in the top frame to keep an eye on 
stats of how many items are left to sell and how well you are doing. 
Once your auction starts again then click back to the "Auction" link and 
continue to input data as each item is sold. WARNING: I cannot be responsible 
if you enter the wrong data. "To err is human" If you enter the wrong data 
during the auction, a listing of the last 2 items is listed in this window 
just for that purpose. Each time you input a transaction item, look below 
to see if what you typed in is what is written to the database. If not then 
you need to correct this problem. This is simply done by clicking the 
"Delete Sale" link and retyping the info over again with the correct data 
this time. Javascript and VB Script error handling will not allow you to 
enter the same item number or bidder number twice. But it is best if you 
DON'T MAKE ERRORS DURING THE AUCTION. Take your time, nobody is going 
anywhere. Normally an auctioneer will take 2-3 minutesor more for each 
item. A normal person can enter each item in 20 seconds. So time is on 
your side. But just in case you need it, ask the auctioneer to momentarily 
pause to adjust your entries. Then continue on. Once your last item sells 
on the auction you are now ready for checkouts. Click the "Bidder Checkout" 
link in the top frame and as each bidder gives you their number type it in 
and you will be able to see a complete listing of everything they purchased 
in the auction including the totals. If they just want to see their bill, 
you may print this frame for that purpose and move on to the next bidder. 
If they are ready to checkout then tell them what they owe you for the 
purchases and receive the money, check or other and enter the amount 
paid into the "Payment Amount" field. If they are paying by check, then 
list the check number for reference and accounting purposes later just 
in case that check does not clear the bank. Once you have entered this 
data then click the "Post Payment" button. This application also allows 
for a partial payment. Say for instance, Fred overshoot his wallet when 
he bought that Deer Head mounted on the hat rack. And Fred wants to pay 
you some now and then come back and pay the rest tomorrow or the next day. 
This application allows you to post his payment while still showing an 
outstanding balance on his receipt. Once you click the post payment button 
then this page is the page you print in the frameset to give to him so he 
can show that he did partially pay for his Deer Head. If he did pay his 
entire balance then the receipt will show a Zero $0 balance. Then Fred 
can leave with his merchandise. Continue this until all bidders have 
checked out. Once all bidders have checked out then click on the 
"Auction Status" link and then the Outstanding Receivables by Bidder 
to see which bidders have purchased items but not checked out yet. 
Each bidder who has not checked out yet will have a Zero $0 balance 
in the "Amount Paid" column. If a bidder did not purchase anything, 
they wil be left out of this report. If there is a zero there then 
they purchased something but have not paid for it yet. Once you checked 
out all your bidders and completely satisfied all bidders have taken 
care of their purchases then you can relax and click the "Auction Status" 
link in the top frame to get a more detailed accounting view of your auction. 
Who knows you may have made a little money. But in my neck of the woods, 
I don't see how! Once your auction is completed and all bidders have paid 
out their accounts. Now would be a good time to back up your database to 
an archive for future reference. I'm sure you know how to copy a file from 
windows explorer and rename it to an archive. Once you have archived your 
database file. Then come back the to browser application and click the 
"Admin" link in the top frame and click each category "Items" and Bidders" 
and click "Delete All" from the listing and you will clean out your database 
for your next auction. This will erase every entry in the database so 
BE CAREFUL to back up your database file before doing your delete. Now you 
can go help Fred load his Deer Head into the back of his rusty pick-up truck 
cause the auction is over. If you later wish to restore this auction database 
then retrieve the archived database file and place it back into the auction 
folder and rename it back to "auctionalive.mdb" and return to the default.asp 
page and all your data can be retrived including all status reports. But 
nothing can be recovered if you delete any information before backing up or 
archiving your database file.



Technical Support:
Please send all technical support questions to admin@knightzone.com. Or if you 
have any suggestions on how to make this application more user friendly or 
with more added features, I'm all ears. I may not have thought of everything, 
I get real bogged down when I'm working 3-4 projects at the same time. So 
send me your comments including reporting bugs....If I have left something 
out it may be due to the applications intended parameters set before development.



About the Programmer:
Everything you want to know about Jeff Knight can be found here: 
http://www.knightzone.com, that is as simple as I know how to say it.



Application Customization: 
If you feel the need to change certain portions of this app, feel free 
to do so. But if you take my work and tell everyone you did it, I hope 
you stand real tall in front of God one day. One thing I do not want you 
to change is the "Auction aLive" KnightZone.com Banner in the top frame or 
the knightzone.com link in the footer on each page. Please leave this as is. 
The only way I get any recognition from this application is the 
advertisement in the top frame. So please do not remove it as I hope to 
get future work projects from it's display. Auction aLive is under copyright 
protection as it has been applied for. Copyright � 2002 
KnightZone.com, Jeff Knight.



Registration:
There is no registration for this application. It is a freeware application and 
freely downloadable from fine web resources web sites. However, if you use the 
program and feel guilty because you didn't pay for it, I'll gladly accept 
contributions in any amount (U.S. Dollars of course). Send any contributions to:

Jeff Knight
KnightZone.com
595 Porter Swamp Road
Cerro Gordo, NC 28430



Beta Testing and Bugs:
This application was cross browser tested in IE 6 and Netscape 4.7 with default 
browser settings. Other browsers were not tested. If you know of any browser 
bugs in this application, please send me your comments and I'll try to correct 
them before the next version's release date. If you have another OS other 
than a Microsoft product and have problems running this app, let me know. 
As it was not tested with multiple Operating Systems or different server 
software platforms. I cannot say what may happen if you do not use and 
implement the application as instructed in this set-up guide. Like I said, 
right now I do not know of any bugs in this version, but I'm sure someone 
somewhere will find some. This application WILL NOT RUN on Windows XP Home 
Edition. Because XP Home Edition does not have server software support. If 
you are running XP you will need to upgrade to the XP Professional OS or a 
version of Windows that has server software support. This application can 
also be run on top of all known versions of Microsoft IIS, ver. 3+ with 
service pack.



Disclaimer:
This is freeware and does not have any warranties either written, stated 
or implied. We are not responsible for it's use and deployment by you or 
any third parties whether it be loss of data or hardware or mental illness. 
This product is an "AS IS" product and should be used as such. What do you 
want from me? It's FREE! I didn't charge you a dime for it.



Benediction:
I would like to take just a moment to Thank You personally for downloading 
this application and I hope it serves both of us well. As I know of no other 
FREE product which was designed with this applications parameters. Once again 
this is not an Internet Application it is made for a stand alone PC running 
server software during a live auction with real people. It is NOT an online 
application like E-Bay. Feel free to pass any work projects on my way. I need 
to buy some things for the kids. Enjoy!

 

Auction aLive Software Application � 2002
Designed and Developed by www.KnightZone.com � All Rights Reserved


