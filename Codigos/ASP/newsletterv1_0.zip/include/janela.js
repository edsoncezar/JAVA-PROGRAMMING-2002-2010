function Email() {
rv=window.open("adicionar.asp?modo=Email",null,"height=250,width=420,center=1,scroll=0,help=0,status=0");
}
function Gerar() {
rv=window.open("gerar.asp",null,"height=250,width=420,center=1,scroll=0,help=0,status=0");
}