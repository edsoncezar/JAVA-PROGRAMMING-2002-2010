Title: Meta Tag Generator v1.0
Description: I've searched here on PSC in the ASP /VbScript section for a meta tag generator and there was nothing. So here is one Meta Tag Generator!
Just fill in the form, hit the button, and you got your meta tags just like that! After this, just select the generated code and copy it into your Web page! Simple!
Please vote for this code!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7855&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
