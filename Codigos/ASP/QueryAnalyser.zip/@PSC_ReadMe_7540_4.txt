Title: QueryAnalyzer
Description: This code is in Beta stage and used like a QueryAnalyzer, it got a update feature but it wont work for the moment. The code will only work with MS SQL server and is only tested with IE 5.5.
You have to set write permissions on the servers catalog.
Please email me the bugs and other request asap.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7540&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
