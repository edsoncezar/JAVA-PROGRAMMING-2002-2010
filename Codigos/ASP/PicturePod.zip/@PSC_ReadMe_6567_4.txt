Title: PicturePod
Description: Creates a pop-up window to display an image viewer on a website. The viewer can then move backwards and/or forwards through the images. Useful if you need to create multiple pop-up image viewers as it uses a single ASP page and XML files to generate the HTML file. An example is given which can be used as your starting point.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6567&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
