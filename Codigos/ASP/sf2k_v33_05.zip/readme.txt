'#################################################################################
'## Copyright (C) 2000-02 Michael Anderson, Pierre Gorissen,
'##                       Huw Reddick and Richard Kinser
'##
'## This program is free software; you can redistribute it and/or
'## modify it under the terms of the GNU General Public License
'## as published by the Free Software Foundation; either version 2
'## of the License, or any later version.
'##
'## All copyright notices regarding Snitz Forums 2000
'## must remain intact in the scripts and in the outputted HTML
'## The "powered by" text/logo with a link back to 
'## http://forum.snitz.com in the footer of the pages MUST
'## remain visible when the pages are viewed on the internet or intranet.
'## 
'## This program is distributed in the hope that it will be useful,
'## but WITHOUT ANY WARRANTY; without even the implied warranty of
'## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'## GNU General Public License for more details.
'## 
'## You should have received a copy of the GNU General Public License
'## along with this program; if not, write to the Free Software
'## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
'## 
'## Support can be obtained from support forums at:
'## http://forum.snitz.com 
'##
'## Note: We can NOT answer Support Questions via e-mail !
'##
'## Correspondence and Marketing Questions can be sent to:
'## reinhold@bigfoot.com
'## 
'## or
'## 
'## Snitz Communications 
'## C/O: Michael Anderson
'## PO Box 200
'## Harpswell, ME 04079
'#################################################################################


0. Table of Contents
==================================================================================

0. Table of Contents
1. Snitz Forums 2000 Version 3.3.05 Introduction
2. Installation Instructions
3. Donations
4. In Closing...


1. Snitz Forums 2000 Version 3.3.05 Introduction
==================================================================================

Thank you for downloading the Snitz Forums from http://forum.snitz.com. If you 
downloaded this zip-file from an other site, please check http://forum.snitz.com 
for the latest official release.

This version again has a lot of bug fixes and also has a couple of exciting new features
like full topic moderation, topic-archiving and enhanced Board/Category/Forum/Topic subscription

The version has been tested with the folowing databases:
* Access 97 / Access 2000 / Access 2002
* SQL Server 6.5 / SQL Server 7 / SQL Server 2000
* MySql version 3.22 and the 3.23 beta

on Windows 95, 98, ME, NT 4, Windows 2000, Windows XP and on Linux with Chili!Asp

Developed by Michael Anderson <reinhold@bigfoot.com> and Pierre Gorissen 
<p_gorissen@hotmail.com>, and the support group at http://forum.snitz.com.


2. Installation Instructions
==================================================================================

1. Unzip Files:

   a. The sf2k_v33_05.zip file should be unzipped into a folder on your pc. 
      (i.e. c: \Snitz\)

   b. The tools.zip file (located inside the zip file) contains a
      Access 97 database. If you want to use Access as database, this file 
      should also be unzipped in the folder.

2. Open the config.asp file in your favorite text editor 
   (DO NOT USE FRONTPAGE FOR THIS !).

   a. Remove the ' in front of the "strDBType" variable with the database type you 
      want to use.

   b. Update the "strConnString" variable with the correct path to were your .MDB file 
      if going to be on the server or to the SQL-server database
      Make sure you remove the ' in front of the variablestring you want to use.

   c. If you need to rename the prefix on your tables, then update the 
      "strTablePrefix" variable as appropriate. For a first install the default 
      setting doesn't need to be changed.

   d. If you are sharing a member list with another version of these forums, then
      update the "strMemberTablePrefix" to point to that list in the same Database.
      For a first install the default setting doesn't need to be changed.

3. Upload the Files: 

   a. All files (except for the snitz_forums_2000.mdb file should be uploaded to a directory on your server. 
      (usually /forum/)

** If you want to upgrade an existing database/forum, then proceed with step 5.

** If you want to use a SQL-Server or MySql database, you have to create an empty 
   database at the server first, then proceed with step 5.

** If you want to use a Access proceed with step 4.

4. Upload the database
   
   The snitz_forums_2000.mdb file needs to be uploaded into a directory where 
   the directory permissions have been set to read/write, i.e. a cgi-bin/ or 
   fpdb/ folder.  Also, it's advisable to make sure this directory is not 
   accessible by the web to stop people downloading the database. Bottom line, 
   set up the "IUSR_YOURMACHINENAME" account (or EVERYONE) to have full control 
   of that file/directory outside of your web server (most secure).

5. Test/complete the installation

   Open the setup page in your web browser:

   http://<yourservername>/<forumdirectoryname>/setup.asp

   The setup pages will lead you through the upgrade or install steps.
   If you are using Access the setup page should respond saying installation was completed.
   Upgrade of the database is supported for Version 3.0 RC 1 and newer.
   Remember to always make a backup of you database first, before upgrading it!!!

6. After the forum is installed you can log in as the administrator:

   a. username = "Admin"
   b. password = "admin"

   Then you will need to click on the "Admin Options" link at the top right of the
   page. Then log in again:

   a. username = "Admin"
   b. password = "admin"

   Now, change the settings to match your mail server and web site colors.
   Also it is wise to change the default administrator password to something only 
   you know !

7. Now change the default admin-password by clicking on the Profile link in the top-menu.


That should be it. Any problems please contact us at the Support Forums: 
http://forum.snitz.com

If you don't have an email component, John Penfold <asp@asp-dev.com> 
http://www.asp-dev.com) recommends W3Jmail from http://www.dimac.net.
It's good and free!



3. Donations
==================================================================================
Information on donations can be found at: http://forum.snitz.com/donations.asp

Any Donations can be sent to:
Snitz Communications 
C/O Michael Anderson
PO Box 200
Harpswell, ME 04079

or

You can use your Credit Card or E-Check at PayPal via our web site:
http://forum.snitz.com/donations.asp

PayPal is an easy way to send donations over the internet for free. You can use a 
credit card or bank account! It's fast, free and secure. 
(Even supports international users)


4. In Closing...
==================================================================================

If you have any problems, find any bugs or have suggestions (for improvement or 
otherwise) please use the support forum at http://forum.snitz.com to communicate 
your issue(s) with us.

Snitz Forums 2000 is a product of the combined work of many individuals that 
contributed over 1200 hours of non-funded development time. All of them deserve 
full credit for this wonderful product's existence. 

To name a few key developers/facilitators:

Owners:
Michael Anderson (reinsnitz)
Pierre Gorissen (gor)

Lead Developers:
Huw Reddick (HuwR)
Richard Kinser (Richard Kinser)
Sue Crocker (heptite)
John Miller Jr (John)

Development Team Members:
Dave (Davio), David Maxwell (davemaxwell), Dion Rentos (Kal Corp), 
Doug Gorin (Doug G), Geoff R (GeoffR), Jeffrey Alen Stana (jEFF), 
Josh Pape (Josh), Kerry (Kerry), Luis Romao (zecompadre), M Houston (Sparty), 
Matt (Matt), Matthew (Matthew), Nathan LeMesurier (Nathan L), 
Richard Hay (anotherwin95), Scott Lemieux (slemieux), Tim Teal (tteal), 
(animedj), (BogieMan), (brkonthru), (BuffyNET), (Da Stimulator), (isuru), 
(mrWize), (Sabre Cat), (Smiddy), (Spoon), Kuai Ser Leng (Sting-),
B�lent �zden (Bozden)

It wouldn't be here today if it weren�t for all of those mentioned and many more 
that were not.

==================================================================================

Additionaly, Snitz Forums 2000 was originally based on another product called 
ASP-DEv Forums (http://www.asp-dev.com), which was the work of John Penfold 
<asp@asp-dev.com>, Tim Teal <tteal@tealnet.com> and all the people of the ASP-DEV 
development group (http://www.asp-dev.com).

NOTE: The product now has very little in common with the original application, but 
as a courtousy to the original developer who asks not for any recognition, we 
mention his original work.

==================================================================================

Cheers!

Reinsnitz (Mike Anderson)
http://forum.snitz.com
reinhold@bigfoot.com
><)))'>

"For God so loved the world 
that he gave his one and only Son, 
that whoever believes in him 
shall not perish but have eternal life."   

                           - John 3:16 (NIV)