// originally all these functions were in the toolbar, but then they weren't available while the toolbar was reloading

function set_choice(ID,type,value,show) { // this is used by the choose page

	// the show/location= lines could be removed, or made to open in a new window
	
	if (parent.contemplate_main.document.contemplate.choices.length > 1) {
		parent.contemplate_main.document.contemplate.choices[ID].checked = 1;
	} else {
		parent.contemplate_main.document.contemplate.choices.checked = 1;
	}

	if (type == "template") {
		
		parent.template = value;
		parent.args = "";
		parent.page_name = "";
		parent.base_page = "";
		
		if (show) { popup("../../contemplate/assembler." + parent.script_extension + "?template=" + value, 650, 500); }
	
	} else {
	
		definition = parent.page_definitions[ID];
		parent.template = definition.substr(9, definition.indexOf("&")-9);
		parent.args = definition.substr(definition.indexOf("&")+1);
		if ((parent.action == "edit")||(parent.action == "delete")) {
			parent.page_name = value;
		} else {
			parent.base_page = value;
		}

		if (show) { popup("../../contemplate/assembler." + parent.script_extension + "?page=" + value, 650, 500); }
	
	}
	
}

function check_name() { // this is used by the name page
	
	new_name = parent.contemplate_main.document.contemplate.page_name.value;
	new_name_compare = new_name.replace(/\w/g, ""); // remove all allowed characters

	if (new_name_compare.length) {
		alert("Page names can't contain the following characters: '" + new_name_compare + "'. Please enter a new name.");
		return false;
	} 
	
	if ((parent.action == 'page')||(parent.action == 'template')) {
	
		needle = "," + new_name + ",";
		//haystack = "," + parent.page_names.join(",") + ","; // to do why doesn't WinIE like the join method here? the next 8 lines are a workaround
		// we could either try the join with no separator (comma is the default), or write a custom join function to use instead
		haystack = "";
		for (i=0; i<parent.page_names.length; i++) {
			haystack += parent.page_names[i];
			if (i < (parent.page_names.length - 1)) {
				haystack += ",";
			}
		}
		haystack = "," + haystack + ",";
	
		if (haystack.indexOf(needle) != -1) {
			alert("A page called " + new_name + " already exists. If you wish to edit that page, return to the first step and select the third option.");
			return false;
		}
	
	}
	
	return true;
	
}

// originally, the load_menu() and clear_menu() were stored in this file, but for some reason setting menu options
// in another frame crashed Mac IE; we had to move the functions to assembler, so that the functions and the
// menus they set are on the same page

function show_stored(tag_name, args) {

	eval("this_type_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_type");
	eval("this_file_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_file");
	eval("this_field_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_field");
	eval("this_form_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_form");
	
	args = args.split(",");
	this_type = args[0]; this_file = args[1]; this_field = args[2]; this_form = args[3];
	
	if (this_type == "-1") {
	
		this_type_menu.selectedIndex = 0;

	} else if (this_type == "none") {
	
		this_type_menu.selectedIndex = get_position(this_type, parent.tag_types) + 1;

	} else {
	
		if (this_file.indexOf("../") == -1) { this_file = "../content/" + this_file; } // add the default folder name if needed
		
		this_type_menu.selectedIndex = get_position(this_type, parent.tag_types) + 1;
		set_type(tag_name);
		
		this_file_menu.selectedIndex = get_position(this_file, parent.content_files) + 1;
		set_file(tag_name);

		this_file_nopunctuation = this_file;
		this_file_nopunctuation = (this_file_nopunctuation.split(".")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split("/")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split(" ")).join("_");
		this_file_nopunctuation = this_file_nopunctuation.replace(/^_*(.*)_*$/, "$1");
		eval("this_fields_isset = (typeof(" + this_file_nopunctuation + "_fields) != 'undefined')");
		if (this_fields_isset) {
			eval("this_field_menu.selectedIndex = get_position(this_field, parent." + this_file_nopunctuation + "_fields) + 1");
			set_field(tag_name);

			this_field_nopunctuation = this_field;
			this_field_nopunctuation = (this_field_nopunctuation.split(".")).join("_");
			this_field_nopunctuation = (this_field_nopunctuation.split("/")).join("_");
			this_field_nopunctuation = (this_field_nopunctuation.split(" ")).join("_");
			this_field_nopunctuation = this_field_nopunctuation.replace(/^_*(.*)_*$/, "$1");
			eval("this_forms_isset = (typeof(" + this_file_nopunctuation + "_" + this_field_nopunctuation + "_forms) != 'undefined')");
			if (this_forms_isset) {
				eval("this_form_menu.selectedIndex = get_position(this_form, parent." + this_file_nopunctuation + "_" + this_field_nopunctuation + "_forms) + 1");
			}
		
		}
		
	}
	
}

function inspect_content(tag_name) {
	
	eval("this_type_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_type");
	eval("this_file_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_file");
	eval("this_field_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_field");
	eval("this_form_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_form");
	
	this_type = this_type_menu.options[this_type_menu.selectedIndex].value;
	this_file = this_file_menu.options[this_file_menu.selectedIndex].value;
	this_field = this_field_menu.options[this_field_menu.selectedIndex].value;
	this_form = this_form_menu.options[this_form_menu.selectedIndex].value;
	
	if ((this_type != "-1")&&(this_file != "0")) {
		this_args = this_type + "," + this_file;
		if ((this_type == "field")||(this_type == "form")) { this_args += "," + this_field; }
		if (this_type == "form") { this_args += "," + this_form; }
		popup("../assembler." + parent.script_extension + "?template=../contemplate/formulator/inspect.html&main=" + this_args, 650, 500);
	} else {
		alert("Please set these menus before inspecting the content.");
	}	
	
}

function set_type(tag_name) {
	
	eval("this_type_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_type");
	eval("this_file_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_file");
	eval("this_field_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_field");
	eval("this_form_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_form");
	
	this_type = this_type_menu.options[this_type_menu.selectedIndex].value;
	
	if ((this_type == "file")||(this_type == "field")||(this_type == "form")||(this_type == "random")) {
		this_files_isset = (typeof(parent.content_files) != 'undefined');
		if (this_files_isset) {
			parent.contemplate_main.load_menu(this_file_menu, 'File...', parent.content_files);
		} else {
			parent.contemplate_main.clear_menu(this_file_menu, '(none available)');
		}
	} else if (this_type == "none") {
		parent.contemplate_main.clear_menu(this_file_menu, '(not needed)');
	}
	
	parent.contemplate_main.clear_menu(this_field_menu, '(not needed)');
	parent.contemplate_main.clear_menu(this_form_menu, '(not needed)');
	
}

function set_file(tag_name) {
	
	eval("this_type_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_type");
	eval("this_file_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_file");
	eval("this_field_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_field");
	eval("this_form_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_form");
	
	this_type = this_type_menu.options[this_type_menu.selectedIndex].value;
	this_file = this_file_menu.options[this_file_menu.selectedIndex].value;
	
	if ((this_type == "field")||(this_type == "form")) {
		this_file_nopunctuation = this_file;
		this_file_nopunctuation = (this_file_nopunctuation.split(".")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split("/")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split(" ")).join("_");
		this_file_nopunctuation = this_file_nopunctuation.replace(/^_*(.*)_*$/, "$1");
		eval("this_fields_isset = (typeof(" + this_file_nopunctuation + "_fields) != 'undefined')");
		if (this_fields_isset) {
			eval("parent.contemplate_main.load_menu(this_field_menu, 'Field...', parent." + this_file_nopunctuation + "_fields)");
		} else {
			parent.contemplate_main.clear_menu(this_field_menu, '(none available)');
		}
	}
	
}

function set_field(tag_name) {
	
	eval("this_type_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_type");
	eval("this_file_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_file");
	eval("this_field_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_field");
	eval("this_form_menu = parent.contemplate_main.document.contemplate_" + tag_name + ".embed_form");
	
	this_type = this_type_menu.options[this_type_menu.selectedIndex].value;
	this_file = this_file_menu.options[this_file_menu.selectedIndex].value;
	this_field = this_field_menu.options[this_field_menu.selectedIndex].value;

	if (this_type == "form") {
		this_file_nopunctuation = this_file;
		this_file_nopunctuation = (this_file_nopunctuation.split(".")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split("/")).join("_");
		this_file_nopunctuation = (this_file_nopunctuation.split(" ")).join("_");
		this_file_nopunctuation = this_file_nopunctuation.replace(/^_*(.*)_*$/, "$1");
		this_field_nopunctuation = this_field;
		this_field_nopunctuation = (this_field_nopunctuation.split(".")).join("_");
		this_field_nopunctuation = (this_field_nopunctuation.split("/")).join("_");
		this_field_nopunctuation = (this_field_nopunctuation.split(" ")).join("_");
		this_field_nopunctuation = this_field_nopunctuation.replace(/^_*(.*)_*$/, "$1");
		eval("this_forms_isset = (typeof(" + this_file_nopunctuation + "_" + this_field_nopunctuation + "_forms) != 'undefined')");
		if (this_forms_isset) {
			eval("parent.contemplate_main.load_menu(this_form_menu, 'Form...', parent." + this_file_nopunctuation + "_" + this_field_nopunctuation + "_forms)");
		} else {
			parent.contemplate_main.clear_menu(this_form_menu, '(none available)');
		}
	}
	
}

function popup(source,width,height) {
	now = new Date()
	window_name = now.getTime()
	popup_window = window.open(source,window_name,"width="+String(width)+",height="+String(height)+",location=no,menubar=no,directories=no,toolbar=no,scrollbars=yes,resizable=yes,status=yes");
	popup_window.focus()
}

function get_position(string, array) {
	for (i=0; i < array.length; i++) {
		//if (array[i].substr(array[i].length - string.length, array[i].length) == string) {
		if (array[i] == string) {
			return i;
			break;
		}
	}
	return -1;
}
