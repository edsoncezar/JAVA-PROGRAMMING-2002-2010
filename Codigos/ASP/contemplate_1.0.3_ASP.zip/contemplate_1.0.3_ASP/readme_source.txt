Contemplate Source Code

To start building a site with Contemplate, add this folder to the root level of your site,
then create directories called "content" and "templates." See the online documentation at 
http://www.typea.net/software/contemplate for instructions about what to put into those
directories.

To use the Reporter component of Contemplate, make the contemplate/reporter/data directory
world-writable. To use the Formulator component, make the contemplate/pages.txt and
contemplate/pages.txt.backup files world-writeable. To use the Flattener component, create
a directory called flattened and make it world-writeable.
