Send Mail Using ActiveX dll 
By Jorge Cisneros
jorgeci@hotmail.com


	You can send mail using the server that you want, please configure the server in
the ASP file. The ActiveX dll was made with VB6 SP3, you will need the  winsock  control 
ver 6.0 SP3 to run the program. 

	You need to register the dll in you server using regsvr32.exe proyect.dll

	Note: In this version you can only send mail using plain text



History
Fecha		Ver	Comments
========================================================================================
19/01/200 	1.0 	None, Is the start of the proyect.