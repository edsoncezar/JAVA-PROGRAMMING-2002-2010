Title: Send Mail using ActiveX DLL
Description: You can send e-mail whom ever you want from who ever you want, using wich ever server you want
This program uses my own control Active X, in the zip you can find the source code.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6177&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
