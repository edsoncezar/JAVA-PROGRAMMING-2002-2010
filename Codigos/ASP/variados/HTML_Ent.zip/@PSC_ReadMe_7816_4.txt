Title: HTML Entity Decoding
Description: To decode the standard HTML entities. Most useful while you need to update the database but you receive the html entities from the textarea. The most effecient code available here.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7816&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
