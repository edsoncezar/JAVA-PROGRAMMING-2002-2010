var VIEW_FULL    = "./Xsl/FileList.xsl";
var VIEW_DRIVE   = "./Xsl/DriveList.xsl";

var ActiveFileList = null;

function pgLoad() {
	pgResize();
	var html = null;
	
	if (SRV_DRIVELIST == "local") {
		var oXML = getDriveListXML();
		var oXSL = xmlCreateDocument(null);
		oXSL.load(VIEW_DRIVE);
		html = oXML.transformNode(oXSL);	
	} else {
		html = xmlXSLT(SRV_DRIVELIST, VIEW_DRIVE);
	}
	
	setDriveC(DriveList_Left,  html, cnFileList_Left);
	setDriveC(DriveList_Right, html, cnFileList_Right);
		
	setTimeout("cnFileList_Left.load('c:\\\\');", 10);
	setTimeout("cnFileList_Right.load('c:\\\\');", 10);
	
	cnFileList_Left.isActive = true;
	ActiveFileList = cnFileList_Left;
}

function setDriveC(td, html, owner) {
	td.innerHTML = html;
	sel = td.childNodes.item(0);
	sel.label = document.all[td.label];
	sel.FileList = owner;
	owner.DriveList = sel;
	for(i=0; i<sel.options.length; i++) {
		if(sel.options[i].value.toLowerCase() == "c") {
			sel.selectedIndex = i;
			break;
		}
	}
	setDriveLabel(sel);
}

function setDriveLabel(sel){
	var txt    = sel.options[sel.selectedIndex].VolumeName;
	var aSpace = sel.options[sel.selectedIndex].AvailableSpace;
	var tSpace = sel.options[sel.selectedIndex].TotalSize;
	
	txt = "[" + (txt == "" ? "none" : txt) + "] ";
	aSpace = new Number( (aSpace > 0) ? Math.round(aSpace/1024) : 0).toLocaleString();
	tSpace = new Number( (tSpace > 0) ? Math.round(tSpace/1024) : 0).toLocaleString();
	aSpace = aSpace.replace(/\.00$/, "");
	tSpace = tSpace.replace(/\.00$/, "");
	sel.label.innerHTML = txt + aSpace + " of " + tSpace + " k free";
}

function setListLabel() {
	try {
		var aList = ActiveFileList;
		var pList = getUnActiveList();
		document.all[aList.PathLabelID].innerHTML = aList.getPath();
		document.all[aList.PathLabelID].className = "ActivePathLabel";
		document.all[pList.PathLabelID].innerHTML = pList.getPath();
		document.all[pList.PathLabelID].className = "UnActivePathLabel";
	} catch (e) {}
}

function hndOnDriveChange(evt) {
	evt = evt ? evt : window.event;
	var sel = evt.srcElement;
	setDriveLabel(sel);
	sel.FileList.load(sel.options[sel.selectedIndex].value + ":\\");
}

function getUnActiveList() {
	return (ActiveFileList == cnFileList_Left ? cnFileList_Right : cnFileList_Left);
}

function pgResize() {
	var h = document.body.clientHeight - 62;
	cnFileList_Left.style.pixelHeight  = h;
	cnFileList_Right.style.pixelHeight = h;
}

function pgKeyDown(evt) {
	evt = evt ? evt : window.event;
	var code  = evt.keyCode;
	var codes = new Array(38, 40, 13, 45, 46, 9, 114, 115, 116, 117, 118, 119);

	if(evt.altKey) {
		switch(code) {
			case 51 : hndActionView();    break; //Alt + 3;
			case 52 : hndActionEdit();    break; //Alt + 4;
			case 53 : hndActionCopy();    break; //Alt + 5;
			case 54 : hndActionRenMove(); break; //Alt + 6;
			case 55 : hndActionMkDir();   break; //Alt + 7;	
			case 56 : hndActionDelete();  break; //Alt + 8;					
		}
	}

	switch (code) {
		case 114 :
			hndActionView();
			break;
		case 115 :
			hndActionEdit();
			break;	
		case 116 :
			hndActionCopy();
			break;	
		case 117 :
			hndActionRenMove();
			break;	
		case 118 :
			hndActionMkDir();
			break;	
		case 119 :
			hndActionDelete();
			break;												
		case 38  : 
			ActiveFileList.goPrev();
			break; // Up Arrow
		case 40 : 
			ActiveFileList.goNext();
			break; // Down Arrow
		case 13 : 
			ActiveFileList.Open();
			break; // Enter
		case 45 : 
			ActiveFileList.Select();
			break; // Insert
		case 46  : 
		case 119 :
			hndActionDelete();
			break; // Delete
		case 9 : 
			if (cnFileList_Left.isActive) {
				cnFileList_Right.isActive = true;
			} else {
				cnFileList_Left.isActive = true;
			}
			break; // Tab
	} 

	for(var i=0; i<codes.length; i++) {
		if (code == codes[i]) {
			evt.cancelBubble = true;
			evt.returnValue  = false;
			return false;
		}	
	}
}

function hndActionView() {
	ActiveFileList.view();
}

function hndActionEdit() {
	ActiveFileList.edit();
}

function hndActionCopy(path) {
	var list = getUnActiveList();
	var dest = null;
	var dest1= path ? path : list.getPath();
	dest = self.showModalDialog("Copy.html", dest1+"\\", "center:yes;scroll:no;resizable:no;status:no;dialogWidth:400px;dialogHeight:110px");
	if (dest != null) {
		if(ActiveFileList.copy(dest)) {
			list.update();
		}
	}
}

function hndActionRenMove(path) {
	var list = getUnActiveList();
	var dest = null;
	var dest1= path ? path : list.getPath();
	dest = self.showModalDialog("RenMove.html", dest1+"\\", "center:yes;scroll:no;resizable:no;status:no;dialogWidth:400px;dialogHeight:110px");
	if (dest != null) {
		if(ActiveFileList.move(dest)) {
			list.update();
		}
	}
}

function hndActionMkDir() {
	var name  = self.showModalDialog("NewDirectory.html", "", "center:yes;scroll:no;resizable:no;status:no;dialogWidth:400px;dialogHeight:110px");
	if (name != null) {
		ActiveFileList.mkdir(name);
		var list = getUnActiveList();
		if(list.getPath()==ActiveFileList.getPath()) {
			list.update();
		}
	}
}

function hndActionDelete() {
	 if(self.confirm("Do you really want to delete the selected file ?")) {
	 	ActiveFileList.remove();
		var list = getUnActiveList();
		if(list.getPath()==ActiveFileList.getPath()) {
			list.update();
		}	 	
	 }
}

function hndActionExit() {
	self.close();
}

function goRoot(name) {
	var list = document.all[name];
	var sel  = list.DriveList;
	list.load(sel.options[sel.selectedIndex].value + ":\\");
}

function goParent(name) {
	var list = document.all[name];
	list.load(list.getParentPath());
}
