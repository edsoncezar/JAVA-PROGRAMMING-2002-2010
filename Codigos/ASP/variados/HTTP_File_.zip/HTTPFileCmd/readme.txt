											HTTP File Commander
											
	"HTTP File Commander" is a DHTML remote file management tool. The server side is an ASP based service. 
The client side is just Internet Explorer. You can copy, delete, move, and edit files on remote 
computer the same way you it on a local one. 

Requirements:
	Server side :
		- MS XML 4.0;
		- Windows Script Host 5.6;
		- MDAC 2.6;
		- IIS 5.0

	Client side :
		- IE 5.0 - 6.0;
		- MS XML 4.0 or 3.0;
		- Windows Script Host 5.6 for HTA version;

	This application has two modes: HTA amd HTML. You can run the HTA application with or without server. 
HTML application always requires a server.
	
Run HTA application and connect to server :		
> CD .\Tools\HTTPFileCmd 
> START HTTPFileCmd.hta -url:http://<HOST>/<PATH>/	

Run HTA application in local mode :
> CD .\Tools\HTTPFileCmd 
> START HTTPFileCmd.hta	



Maxim Kazitov
Home page : http://mvkazit.port5.com/demo/HTTPFileCmd/
e-mail    : mvkazit@tut.by	