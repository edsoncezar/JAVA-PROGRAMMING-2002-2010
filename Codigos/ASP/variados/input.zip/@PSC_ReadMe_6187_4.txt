Title: A Free for all links page
Description: This is a really basic engine that allows anyone visiting your page to add a link!!. On the output screen it displays every link in a database, whilst the input screen ...well inputs it. This script is good for begginers and easy to develop for advanced users!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6187&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
