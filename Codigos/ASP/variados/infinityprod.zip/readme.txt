Author: 100% by Kaustav Acharya
Email:  excalibur@palebluedot.net
Homepage URL: http://www.angelfire.com/biz6/infinityprod

You can change any of the colors, names, pictures, etc, but please give
me credit that you used my script. Thanks a lot!

Modificaitons/Updates:

------------------------------------------------------------------------------------------
January  06-14, 2001: 
		   Produced better output from user input, i.e. if the user does not put
		   in a name, or email address, the HTML output does not display them onto 
		   the entries page, and if the user puts in an email address, it validates 
		   it. Also, if there are no entries in the guestbook, it tells the viewer 
		   that there are no entries in the Guestbook.
------------------------------------------------------------------------------------------				   
December 25, 2000: Cleaned up HTML output. Seems to be much cleaner now.
------------------------------------------------------------------------------------------
November 26, 2000: Completed Script for the 1st time...many modifications to be made 
		   soon.
------------------------------------------------------------------------------------------