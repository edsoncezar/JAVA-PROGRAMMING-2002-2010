=========================================================================
= 		a.shopKart 2.0 Free Version	       			=
= minor version: 2.0.3 				       			=
= (recalculate function revised - comma as decimal separator bug fixed)	=
=========================================================================

--------------------------------------------------------
TERMS OF USE
In order to use the cart you must agree to the following terms of use:
You may:
	Use this version as the basis for your own web site.
You must:
	Mention that you are using a.shopKart
	2.0 when you are doing so in your web site. Include a link to http://www.URLogy.com/ when using a.shopKart.
You may not:
	Sell this software without written permission from URLogy.
	Use this software to build your own version of a shopping cart and sell it without written permission from URLogy.
	Imply by any means that this is your software.
	Re-distribute this software or make it available for download from your site without written consent from URLogy.com.
	We are not responsible for any errors/bugs. This software is offered to you as-is, without any guarantee.

--------------------------------------------------------

In this zipped file there are two directories
- eposter - the demo site
- ashopKart20 - the shopping cart files to use as a basis for your site

- You should make sure the path to the database is correct. 
This path can be found in the db.asp file. Make sure the variable strConn refers to your database location.

- There is one database, in Access 2000 format:
	scart.mdb in Access 20000
	the database is also available for download in Access 97 format

- To receive an email message for each order, you must specify your email address on line 92,
page process.asp.
--------------------------------------------------------

To get information on how to use a.shopKart 2.0 please go to
http://www.URLogy.com/asp/ashopkart.asp
These pages are updated regurlarly.
For help, please see the page http://www.URLogy.com/asp/faq.asp 

This file has been updated on 7-Nov-2000.

========================================================
(c) 1998-2000 Katrien De Graeve
katrien@URLogy.com