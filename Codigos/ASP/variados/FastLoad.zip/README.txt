FastLoad version 1.0

~~~~~~~~~~~~~~~~~~~~~~(Files)~~~~~~~~~~~~~~~~~~~~~~

HTML
BOTTEXT
TOPTEXT
DOWNLOAD.ASP

~~~~~~~~~~~~~~~~~(Download 2001 Setup)~~~~~~~~~~~~~~~~~

Step 1: Edit HTML,BOTTEXT, and TOPTEXT.

Step 2:Upload them to your zips dir.

Step 3:Change all url to http://www.yoursite.com/dir/to/zips/download.asp?File=file name here

Example: http://www.site.com/zips/download.asp?File=bigworld.zip

For more help AIM me at kantlivelong
~~~~~~~~~~~~~~~~~~~~~(Disclaimer)~~~~~~~~~~~~~~~~~~~~~

This script is FREEWARE you may distibute this for a non-profit use.