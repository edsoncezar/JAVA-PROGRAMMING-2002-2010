Title: Dynamic refreshable Option Select
Description: Option Select 19 July 2002
Description
Works off ASP to dynamically create an array of categories and sub categories that the client can use to refresh a drop down menu on the clients computer.
Requirements:
ASP, HTML, Javascript
Licence
Free
Requests
If you use the code please fill out one of my medical survey forms at http://www.allourhealth.com
Your improvements would be appreciated.
 
Automatic form validator:
The module required to build the insert statement is missing.
You need to write a VBA program to hold the properties for each table using the format shown.
A working example can be seen at:
http://www.allourhealth.com

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7714&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
