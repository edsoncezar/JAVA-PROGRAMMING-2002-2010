**************************************
*	include-TopRating.asp	     *
**************************************

All you need :

1) Change Default const on line 4 to 7 in include-TopRating.asp

2) Change the Connection string on line 8 to where you put TopRating.mdb

3) Manage your data online with DBManager.asp
   http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?lngWId=4&txtCodeId=6879

4) Use TopRating this way in all your web pages :

	<!-- #include file="include-TopRating.asp" -->
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
	<HTML>
	<HEAD>
	< % subMetaTag() % >
	</HEAD>

	<BODY BGCOLOR="BLACK">

	< % subFirst200Chrs() % >

	Your page here

	</BODY>
	</HTML>




As an independant e-commerce consultant from Montreal, I have built and 
designed many websites and e-commerces in Canada and would be interrested in
developping for American businesses.  If you are interrested in my services,
please contact me.


Simon La Rochelle
info@simon-larochelle.com