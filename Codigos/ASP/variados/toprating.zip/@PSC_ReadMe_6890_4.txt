Title: TopRating : Catch robots queries and Generate MetaTags+FirstChrs
Description: This is an include file that catch robot's queries to your site and generate MetaTags and First 200 words in the page (only if robot, so your user will see no change).
This code is based on TopRating.mdb : so you can generate mutiple combinaison of MetaTag+FirstChrs.
This is a great code to centralize MetaTag gestion.
Since this is version 1.0.1, I'll be happy to upgrade my code with your comment.
Simon
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6890&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
