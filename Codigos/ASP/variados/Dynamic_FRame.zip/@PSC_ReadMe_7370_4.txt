Title: Dynamic FRAME PAGE
Description: **UPDATED 3/23/2002 **
Here is code that show, how to have PAGE with frames, define its frame pages dynamically acording to paramethers included in the calling URL. 
Attachment file contains COMPLETE example of the code. Code is short, simple and effective.
Check also my home page for updated version of the example:
http://www.benchmarking.fi/programming/?mainframepage=programming/ASP/tipsandtricks/index.htm
UPDATED VERSION INCLUDES ASP,VbScript and JavaScript versions.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7370&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
