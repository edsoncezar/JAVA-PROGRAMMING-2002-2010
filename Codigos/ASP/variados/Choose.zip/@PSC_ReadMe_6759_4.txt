Title: Choose a news feed
Description: This is an adaptation of the first news feed script , this allows users to select which feed they want to view , in this example we have 10 selections but on Moreovers site you can choose from 330. You can test this out first if you want by going to http://asp.myscripting.com/selectafeed.asp
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6759&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
