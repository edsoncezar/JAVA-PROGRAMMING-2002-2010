Title: Check for New Hotmail Using MSN Messenger and Microsoft Agent
Description: This VBScript checks for Microsoft Agent on the users system and if present then checks for MSN Messenger. IF this is present then the script checks the users Hotmail account and then the Microsoft Agent character reports to the user of any Hotmail info. To use this script you will need Microsoft Agent + Merlin.acs - as well as MSN Messenger. Can easily be converted to either VB, Delphi or Javascript
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6598&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
