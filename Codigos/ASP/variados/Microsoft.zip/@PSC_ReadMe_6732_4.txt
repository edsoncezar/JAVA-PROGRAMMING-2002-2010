Title: Microsoft News Grabber v1.0
Description: Goes out to Microsofts web site and get the current news off the site. It then saves a file on the your server that tells the script when to update the news(in days). It Creates the file if it doesn't exist, if it does exist it hust overwrites the old data. it save the news to another file so it will just get the information from that file instead of going to Microsofts web site every time. 
It uses clsWhois by Lewis Moten. found on http://planetsourcecode.com to get the informaation from the web site.
Check out ClsWhois here http://www.planetsourcecode.com/xq/ASP/txtCodeId.6655/lngWId.4/qx/vb/scripts/ShowCode.htm
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6732&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
