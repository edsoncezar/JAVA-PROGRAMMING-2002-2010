Title: Image Randomizer v1.1
Description: Randomizes images on your web page so that viewers will see a different picture each visit or refresh. I did this script to add a little diversity to my personal site. UPDATED NOW - even easier to select images for random display!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7672&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
