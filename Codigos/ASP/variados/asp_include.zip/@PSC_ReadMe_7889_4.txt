Title: asp include file to handle form parameters Collection Encapsulation
Description: This is a simple include file to handle any data submitted from a form either it was sent by post or get method.
The code receive the name-value pares that sent by any method and replace any [ � ] with [ _ ] that can be harmful to SQL statements and with this code you can leave long syntax
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7889&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
