Title: Quick Messages v1.01
Description: Allows users to post short message and image on you're website, with text wrapping to avoid overspill. The process's are done on one page, allowing the user to post and view his/her message instantly. The latest version includes IP logging and blocking of you�re users, allowing you to ban troublemakers for as long as you see fit. All information is stored in a text file rather than a database.. Allowing you to edit/delete messages posted.. via a remote HTML page, on a text area.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7768&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
