QUICK MESSAGES V1.01 


THIS ZIP FILE CONTAINS THE FOLLOWING FILES:

saVE.ASP
sOURCE.TXT
TEST.ASP
QC.CSS
SOURCE2.TXT
SOURCE3.TXT
EDIT.ASP

 
The ASP files are created to be run once modified, to modify them you simply have to alter the server path to match your own.  Example being:

../private/textfile.txt

The source files show a simple explanation of the source code, although they are not very detailed they show the basics of whats happening.  

They only other modifications that may need doing are HTML code, you should check this as I may have missed something out.
