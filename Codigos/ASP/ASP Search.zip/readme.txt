ASP Search Engine 

based on code supplied by Scott A. Moss - www.vbstuff.cjb.net
at PSC. For documentation see the original version. 
The code have been revised by Chavdar Yordanov. Some bugs have been removed - the Input past end of file error and the unexpected stop of the search process due to reaching the maximum number of records, because the counter counted the unmatched documents too. 

For any comments, email me to chavdar_jordanov@yahoo.com
Happy coding!