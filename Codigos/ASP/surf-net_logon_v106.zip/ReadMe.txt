Surf-net password logon realease v1.6 beta


The Surf-net password logon v1.6 beta is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without permission.             **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail



The logon uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.





Using the password logon


ALL PASSWORDS ARE(LOWER CASE):- letmein   

Unzip all the files to the same directory

Files must be run through an ASP enabled web sever

Session cookies must be enabled for the script to work

Default.htm is the first page to run

To login use the following (case sensitive): -

Username: guest
paswword: letmein


The Access 2000 Users Database is also password protected with the following password: -

password: letmein



To add further pages inside the password proteceted area add the following line of code to the top of each asp page but NOT within any asp (place it just before the <HTML> tag at the top of your page):-

<!--#include file="is_user_authorised.inc" -->


As the 'is_user_authorised.inc' file is written in asp, any pages within your password protected area must have the extension .asp to make any asp run otherwise you will just enter the page as normal.

Once logged in the password protected pages in your site can be anywhere, just make sure the path to the file <!--#include file="is_user_authorised.inc" --> is correct. ie. <!--#include file="another_folder/is_user_authorised.inc" -->





How it works


I have added this bit to make customization easier.


1. First you need to login in using the login form (This is the default.htm page).

2. When the form is submitted it is passed to the script �check_user.asp� script. 

3. This then checks the database for the username and checks the password against the password entered. 

4. If the username is not found or the password does not match a session variable is set to False and the user is redirected to the unauthorised user page.

5. If the username is found with matching password a session variable is set to True and the user is passed to the authorised user page.

6. At the top of the authorised user page (this must have the extension .asp) there is the following line: -

<!--#include file="is_user_authorised.inc" -->

This line calls a small piece of asp that checks to see if the session variable is set to True, if it is not or it does not exist (meaning the person has not logged in) the user is passed to the unauthorised user page.

If the session variable is true the page then loads up as normal.






If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ

