WebNews 1.0b
============
www.dyessindustries.com/webtest

Files included in this distrobution --

WebNews Architecture
--------------------

WebNews is divided into 2 middle tier applications (referring to 3 tier arch.),
  or 2 client applications (referring to client server model), and one back-end
  Access 97 database (not a true back end like SQL Server or Oracle, but it
  mimics appropriatly for this architecture.).

Clients:
  NewsReader.asp (this is what your users see)
	NewsAddArticle
  NewsAddarticle.asp (this is your maint form)
	NewsEditArticle.asp
	NewsArticleUpdate.asp
Back End:
  News.mdb

Reader Section
--------------
The reader section is the part of WebNews used to display approved articles, and
accept new articles from your users. This section of WebNews is what your users
see when they hit your site.

NewsReader.asp		- This file displays the list of articles and allows users
			   to enter news. This is the starting point of the News.
NewsAddArticle.asp	- This file uses an HTML form to allow users to propose a new
			   article for review.

Review Section
--------------
The review section allows you or your webmaster to review submitted articles
from any browser. You can modify any text, toggle 'Live' status, set an expiration
date, or delete any article in the database.

NewsReview.asp		- This file displays all the articles which exist in the
			   database in a summary format. Each article summary has an
			   [Edit] button which moves you to the NewsEditArticle.asp
			   page.
NewsEditArticle.asp	- This contains the HTML form which allows you to change any value
			   in the news article which you chose in the NewsReview.asp
			   page. You can edit, toggle live status, or delete the article
			   presented in this form.
NewsArticleUpdate.asp	- This ASP file updates any changes or deletes the article, 
			   depending on the option you chose, and checks the values
			   for validity (i.e. correct date formatting). Once the
		 	   changes are accepted, or altered to suit the database
			   data types, they are stored and the user is redirected back
		 	   to NewsReview.asp

Installation
============

Although this looks much better with surrounding HTML, this can be used as a stand alone.

Step 1 Option A: ASP Stand Alone Installation
=============================================
Copy NEWS.ASP, INDEX.ASP, NEWSREADER.ASP, and NEWSADDARTICLE.ASP, NEWSREVIEW.ASP,
  NEWSEDITARTICLE.ASP, and NEWSARTICLEUPDATE.ASP into your web root 
  directory. 
You are all done. Make sure your server looks for INDEX.ASP. If it looks for another file,
  such as HOME.ASP or DEFAULT.ASP, rename INDEX.ASP accordingly.
To enter the maintanence form, load NEWSREVIEW.ASP into your browser 
	(i.e. www.dyessindustries.com/webtest/newsreview.asp)
It is highly recommended that you change the name of the NEWSREVIEW.ASP file to something
  else (so everyone who has installed WebNews doesn't know how to edit your articles).
  When changing the name of NEWSREVIEW.ASP, make sure you change the mNewsReviewPage
  variable to the new name in the beginning of the NEWSREVIEW.ASP file.

Step 2 Option B: NetObjects ASP Integrated Installation
=======================================================
This component can be integrated into popular HTML editors such as NetObjects Fusion.
I suggest integrating this into an existing HTML document so you can add your personal
  look. Since I use NetObjects Fusion to design my site look, I will demonstrate 
  using v4.0.

1)  You will not need INDEX.ASP, this is simply a re-director to NEWSREADER.ASP
2)  Create your home page that has a link to your news page
3)  Create your news page, and add an External HTML document (located on the Advanced
     Toolbar) Place NEWSREADER.ASP as the External HTML file.
4)  Make the External HTML box the width of your Layout. (stretch the box to the edges)
5)  Save the newsreader page
6)  Create your add article page (this page allows users to propose an article)
7)  Add an External HTML document again, making sure it stretches to the edges). Place
     NEWSADDARTICLE.ASP as the External HTML file.
8) Create your add article page (this allows users to propose their own articles).
     Place NEWSADDARTICLE.ASP as the External HTML file.
9) Edit NEWSREADER.ASP to set global variables (Go to Step 3: Setting Global Variables)

** NOTE: Make sure you DON'T publish News.mdb every time you update your site.
		This will OVERWRITE any data stored on the server (i.e. News Articles)
		You should only put it on the site once.

Step 2 Option C: Standard HTML Integrated Installation
======================================================
1) You will not need INDEX.ASP, this is simply a re-director to NEWSREADER.ASP
2) Create your home page.
3) Create a news and append NEWSREADER.ASP to the end of it. Make the first
     line (before the <HTML> tag = "<% Response.Buffer=True %>" (do not include quotes)
4) Create an add article page and append NEWSADDARTICLE.ASP to the end of it. 
5) Edit NEWSREADER.ASP to set global variables (Go to Step 3: Setting Global Variables)

Step 3: Setting Global Variables
================================
1) Open NEWS_READER.ASP into your HTML editor.
2) Search for the following code near the top of the document

  '***** Global Location Variables *****'
  mBaseDir = "/"
  mNewsReaderPage = "NewsReader.asp"
  mNewsAddArticlePage = "NewsAddArticle.asp"

3) They are set to the stand alone installation. The variables are used in the following
	manner:

  mBaseDir: 		This is where Messages.mdb is located. You must use a relative path, such
			as '/WebHome/' or '/Home/'.
  mNewsReader:  	This is where NEWSREADER.ASP is located. You need to include the
			directory and filename, such as 'News/newsreader.asp' or
			'NewsSeciton/newsreader.asp'. You can name NEWSREADER.ASP anything
			you like as long as the .ASP name matches this variable.
  mNewsAddArticle:	This is where NEWSADDARTICLE.ASP is located. You need to include
			the directory and filename, such as 
			'News/AddArticle/NewsAddARticle.asp' or 
			'AddArticle/NewsAddArticle.asp'

EXAMPLE of SETTING GLOBAL VARIABLES:

Site Structure:

	Home (Index.Asp) - accessed by www.myhomepage.com
	  -Aboutus (AboutUs.Asp)
	  -Feedback (Feedback.Asp)
	  -WebNews (NewsReader.Asp)
	     -AddArticle (NewsAddArticle.Asp)
	  -Links (Links.Asp)

Here, the mBaseDir would be "/" designating that the Messages.mdb is located where your 
  home page (Index.Asp, Home.Asp, Default.Asp, etc.) resides.
The mNewsReaderPage would be 'WebNews/NewsReader.asp' because the newsreader.asp file
  is in the WebNews directory, which is in your Home directory.
the mNewsAddArticlePage would be 'WebNews/AddArticle/NewsAddArticle.asp' because the 
  NewsAddArticle.asp file is in
  in the AddARticle directory, which is in the WebNews directory, which is in your
  Home directory.
