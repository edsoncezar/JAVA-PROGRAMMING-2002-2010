/****** Object:  Table [dbo].[linkRanking]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[linkRanking]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[linkRanking]
GO

/****** Object:  Table [dbo].[linkRanking]    Script Date: 6/11/2001 5:42:14 AM ******/
CREATE TABLE [dbo].[linkRanking] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[address] [varchar] (255) NOT NULL ,
	[clicks] [int] NOT NULL ,
	[title] [varchar] (255) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[linkRanking] WITH NOCHECK ADD 
	CONSTRAINT [DF__linkRanki__click__173876EA] DEFAULT (0) FOR [clicks],
	CONSTRAINT [PK_linkRanking] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO
