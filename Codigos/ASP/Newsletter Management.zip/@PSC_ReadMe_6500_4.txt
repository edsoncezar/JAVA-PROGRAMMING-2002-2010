Title: Newsletter Management beta 0.1
Description: Beta Version of a Newsletter Management Script I am working on. In this version you can offer to add new addresses to a mailing list (from your existing website) with just a small bit of javascript. You can compose, send, archive and read Newsletters you write. Please read the readme before you put this on your server...and reate it, if It get's rated well enough I will continue to develop it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6500&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
