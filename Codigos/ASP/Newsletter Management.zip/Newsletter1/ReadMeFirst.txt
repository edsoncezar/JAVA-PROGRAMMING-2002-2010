Newsletter beta v0.1 by NexusJnr

This readme file is only temporary until I complete a full one.

To get this service up and running on your server you need to:

edit the SMTP address and your email address in the settings.inc file
once that has been done you can upload the scripts to a folder in your directory, preferablY called "Newsletter".

The script explains how to gett users to add themselves to the database from any website.

You must add at least one email address before you try to submit a letter.

Future updates:

I am working on the following

Remove address Suport
List all email addresses subscribed
Edit old newsletters
Remove archived newsletters
View all newsletters archived in menu (not just last 6)
Admin verification (stop users getting into the system that should not be there)

If you can think of any modifications or have any problems mail me at 

nexusjnr@hotmail.com