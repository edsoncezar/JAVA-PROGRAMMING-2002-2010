mysub version 3 - april 2001
extract all files to a folder in the server.
it will create folder for admin pages,images and database.
make sure you have write permissions in db directory.
open index.asp in the folder and another index.asp in the admin folder.
elad rosenberg
