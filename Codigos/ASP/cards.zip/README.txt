Postcard server version 1 by esn.
http://www.justasp.net
info@justasp.net
asp@esn.gr
*************************************************************

=Reqierments=
this app uses 2 components for uploading an for sending mail
but can also work without the upload component as long as your image and sound files
are already on the server.
1) asp smart Upload http://www.aspsmart.com
2) asp smart mail http://www.aspsmart.com


=install and configure=
1) if your regional setting are set to US or your date format is mm/dd/yy
then edit /admin/menu.asp  line 19 an change the link to clean-us-regional.asp
instead of clean.asp 

2) open your browser and point to /admin/main.asp >> setting
there you must enter your mail server and the url to the postcard app.
username : admin
password: 123

all done

