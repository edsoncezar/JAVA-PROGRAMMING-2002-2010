/****** Object:  Table [dbo].[Autorizacoes]    Script Date: 08/01/00 17:12:55 ******/
CREATE TABLE [dbo].[Autorizacoes] (
	[indice] [int] IDENTITY (1, 1) NOT NULL ,
	[status_autorizacao] [int] NULL ,
	[codigo_autorizacao] [varchar] (300) NULL ,
	[tipo_cartao] [varchar] (50) NULL ,
	[nome_cartao] [varchar] (50) NULL ,
	[prazo] [varchar] (10) NULL ,
	[string_autorizacao] [varchar] (300) NULL ,
	[codigo_pedido] [int] NULL ,
	[nome_cliente] [varchar] (100) NULL ,
	[email_cliente] [varchar] (100) NULL ,
	[status_captura] [int] NULL ,
	[string_captura] [varchar] (300) NULL ,
	[assinatura_captura] [varchar] (300) NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Categorias]    Script Date: 08/01/00 17:12:56 ******/
CREATE TABLE [dbo].[Categorias] (
	[codigo_categoria] [int] NOT NULL ,
	[nome_categoria] [varchar] (50) NOT NULL ,
	[descricao_categoria] [varchar] (300) NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Pedido_Item]    Script Date: 08/01/00 17:12:56 ******/
CREATE TABLE [dbo].[Pedido_Item] (
	[codigo_pedido] [int] NOT NULL ,
	[codigo_produto] [int] NOT NULL ,
	[quantidade] [int] NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Pedidos]    Script Date: 08/01/00 17:12:57 ******/
CREATE TABLE [dbo].[Pedidos] (
	[codigo_pedido] [int] NOT NULL ,
	[data_pedido] [smalldatetime] NULL ,
	[nome] [varchar] (100) NULL ,
	[cgccpf] [varchar] (100) NULL ,
	[rua] [varchar] (100) NULL ,
	[cidade] [varchar] (50) NULL ,
	[estado] [varchar] (2) NULL ,
	[cep] [varchar] (10) NULL ,
	[pais] [varchar] (50) NULL ,
	[telefone] [varchar] (50) NULL ,
	[email] [varchar] (50) NULL ,
	[subtotal] [float] NULL ,
	[taxa_envio] [float] NULL ,
	[total] [float] NULL ,
	[forma_pagamento] [varchar] (15) NULL ,
	[cartao_encrypt] [varchar] (250) NULL ,
	[instrucoes] [varchar] (300) NULL ,
	[atendido] [bit] NOT NULL ,
	[pago] [bit] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Produtos]    Script Date: 08/01/00 17:12:57 ******/
CREATE TABLE [dbo].[Produtos] (
	[codigo_produto] [int] NOT NULL ,
	[codigo_categoria] [int] NOT NULL ,
	[nome_produto] [varchar] (100) NOT NULL ,
	[descricao_produto] [varchar] (250) NOT NULL ,
	[preco_unitario] [float] NOT NULL ,
	[url_imagem] [varchar] (100) NOT NULL ,
	[disponivel] [bit] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Autorizacoes] WITH NOCHECK ADD 
	CONSTRAINT [PK_Autorizacoes] PRIMARY KEY  NONCLUSTERED 
	(
		[indice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Categorias] WITH NOCHECK ADD 
	CONSTRAINT [PK_Categorias] PRIMARY KEY  NONCLUSTERED 
	(
		[codigo_categoria]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Pedido_Item] WITH NOCHECK ADD 
	CONSTRAINT [PK_Pedido_Item] PRIMARY KEY  NONCLUSTERED 
	(
		[codigo_pedido],
		[codigo_produto]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Pedidos] WITH NOCHECK ADD 
	CONSTRAINT [DF_Pedidos_atendido] DEFAULT (0) FOR [atendido],
	CONSTRAINT [DF_Pedidos_pago] DEFAULT (0) FOR [pago],
	CONSTRAINT [PK_Pedidos] PRIMARY KEY  NONCLUSTERED 
	(
		[codigo_pedido]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Produtos] WITH NOCHECK ADD 
	CONSTRAINT [PK_Produtos] PRIMARY KEY  NONCLUSTERED 
	(
		[codigo_produto],
		[codigo_categoria]
	)  ON [PRIMARY] 
GO

