This is a simple yet effective password protection script that protects your pages from prying eyes.

It allows you to define different levels of access to the pages, for example to administrators and not to standard users.

If the login fails, the user is presented with the log in form again.
If the login is successful, all content in between the function displaypage() is shown. This example includes a menu area for use only in the secure part of the site.

Included in the zip file are:-

db1.db
default.asp
inc_password.asp
inc_func_displayloggedout.asp
inc_secure_menu.asp

The database has two entries...

UserName	guest	password	guest	Access	user
Password	asp	password	asp	Access 	admin

The following lines must be included in this order in each page just after the body tag, that you wish to restrict user access to.

<!--#include file="inc_password.asp" -->
<!--#include file="inc_func_displayloggedout.asp" -->
<% function displaypage() %>
<!--#include file="inc_secure_menu.asp" -->

and 

<% end function %>

needs to go just before the close </body> tag.

The database connection is provided by the following string.  You may need to edit this to suit your needs.

"Driver={Microsoft Access Driver (*.mdb)};DBQ=C:\Inetpub\wwwroot\paswordscript\cgi-bin\db1.mdb"

Andrew Cheal
akcheal@hotmail.com
www.dotdragnet.co.uk - AceC