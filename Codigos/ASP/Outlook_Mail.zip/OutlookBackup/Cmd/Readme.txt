
Export folders list to XML file :
	folders_list.bat Folders.xml

Export folders list to Text file :
	folders_list.bat Folders.txt

Print folders list to console :	
	folders_list.bat

Make new backup :
	make_backup.bat <BACKUP_NAME> <FOLDERS_LIST>


How to make new backup :

1. create a folders list 
   > folders_list.bat folders.txt;
   
2. edit folders.txt;

3. delete previous backup 
   > RD /S /Q .\..\Backup\backup.0001
   
4. create new backup
   > make_backup.bat backup.0001 folders.txt
   
How to convert XML Backup to HTML
	> backup2html.bat <BACKUP_NAME> <HTML_PATH> 

