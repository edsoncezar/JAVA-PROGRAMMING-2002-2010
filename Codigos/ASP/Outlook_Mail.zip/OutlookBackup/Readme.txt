										Outlook mail backup


"Outlook Mail Backup" is a CDO based program which exports Microsoft Outlook mail 
(not Outlook Express one) to XML based backup. By using HTML based mail viewer you can 
navigate through you backup and search mail by keywords. 

Requirements: 
- IE 5.0 - 6.0;
- Windows Script Host 5.6;
- MS XML 4.0 or 3.0;
- IIS 5.0

To make new backup : 
	backup_new.bat 

To manage your backup list : 
	backup_mgr.bat 

To view backed-up mail : 
	backup_view.bat 


Maxim Kazitov
Home page : http://mvkazit.port5.com/demo/OutlookBkp/
e-mail    : mvkazit@tut.by	
