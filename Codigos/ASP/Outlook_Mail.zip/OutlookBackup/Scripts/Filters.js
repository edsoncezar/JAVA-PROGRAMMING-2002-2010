/******************************************************************************
	File   : Filters.js
	Author : Maxim Kazitov
	E-Mail : mvkazit@tut.by
******************************************************************************/

/******************************************************************************
						FolderFilter Object
******************************************************************************/

function jsFolderFilter() {
	this.inputs  = new Array();
	this.folders = new Array();
	this.add              = jsFolderFilter_add;
	this.getChildByPath   = jsFolderFilter_getChildByPath;
	this.getParentsByPath =	jsFolderFilter_getParentsByPath;
	this.getItemByPath    =	jsFolderFilter_getItemByPath;
	this.isSelected       =	jsFolderFilter_isSelected;
}

function jsFolderFilter_add(inp) {
	with(this) {
		inputs.push(inp);
	}
}

function jsFolderFilter_getChildByPath(_path) {
	with(this) {
		var items = new Array();
		for(var i=0; i<inputs.length;i++) {
			if (inputs[i].path.indexOf(_path, 0)!=-1) {
				items.push(inputs[i]);
			}		
		}
		return items;
	}
}

function jsFolderFilter_getItemByPath(_path) {
	with(this) {
		for(var i=0; i<inputs.length;i++) {
			if (inputs[i].path == _path) {
				return inputs[i];
			}		
		}
		return null;
	}
}

function jsFolderFilter_getParentsByPath(_path) {
	with(this) {
		var items = new Array();
		var pPath = _path;
		while(pPath.lastIndexOf("/")>0) {
			items.push(getItemByPath(pPath = pPath.substr(0, pPath.lastIndexOf("/"))));
		}
		return items;
	}
}

function jsFolderFilter_isSelected(_path) {
	with(this) {
		for(var i=0; i<inputs.length;i++) {
			if ((inputs[i].path == _path)&&(inputs[i].checked)){
				return true;
			}		
		}
		return false;
	}
}

/******************************************************************************
						AddressFilter Object
******************************************************************************/

function jsAddressFilter() {
	this.inputs = new Array();
	this.add = jsAddressFilter_add;
	this.isSelected = jsAddressFilter_isSelected;
}

function jsAddressFilter_add(inp) {
	with(this) {
		inputs.push(inp);
	}
}

function jsAddressFilter_isSelected(_path) {
	with(this) {
		for(var i=0; i<inputs.length;i++) {
			if ((inputs[i].path == _path)&&(inputs[i].checked)){
				return true;
			}		
		}
		return false;
	}
}

/******************************************************************************
						FilterItem Object
******************************************************************************/

function jsFilterItem(_path, _checked) {
	this.path    = _path;
	this.checked = _checked;
}
