/******************************************************************************
	File   : OutlookMail.js
	Author : Maxim Kazitov
	E-Mail : mvkazit@tut.by
******************************************************************************/

var MAIL_DELETE  = 3;
var MAIL_OUTBOX  = 4;
var MAIL_SENT    = 5;
var MAIL_INBOX   = 6;
var MAIL_DRAFT   = 16;
var MAIL_FOLDERS = new Array (MAIL_INBOX, MAIL_SENT, MAIL_DELETE, MAIL_DRAFT);
var LAST_INDEX   = 0;

var outlookApp    = null; 
var mapiNS        = null; 

var fltFolder  = null;
var fltAddress = null;

/*************************************************************************************************************
							Common Functions
**************************************************************************************************************/
function generateName(prefix) {
	LAST_INDEX++;
	var name = new String(LAST_INDEX);
	while(name.length<10) {
		name = "0" + name;
	}
	return prefix + "." + name;
}

function getFolderName() {
	return generateName("Folder") ;
}

function getMailName() {
	return generateName("Mail") ;
}

function createFolder (path) {
	try {
		var fsObject  = new ActiveXObject("Scripting.FileSystemObject"); 
		if (!fsObject.FolderExists(path)){
			fsObject.CreateFolder(path);
		}
	} catch (e) {
		dbgOut.printException("Can't create folder : " + path, e);
	}
	return path;
}

function getLocalPath(path) {
	return  (  ( new String(path)) .slice(PATH_DATA.length) ).replace(/\\/gi, "/");				
}	

function oeInitializeGlobal() {
	dbgOut.println("Initialize Outlook session...");
	outlookApp = new ActiveXObject("Outlook.Application"); 
	mapiNS     = outlookApp.getNameSpace("MAPI"); 
	LAST_INDEX = 0;
}

/*************************************************************************************************************
							oeMailItem Object
**************************************************************************************************************/
function oeMailItem(_mailItem, _path) {
	this.mailItem = _mailItem;
	this.mailName = getMailName();
	this.path     = _path + "/"+this.mailName;
	this.xmlDoc   = null;
}

oeMailItem.prototype={
	constructor:oeMailItem, 
		
	createXML:function() {
		with(this) {
			var root = null;
			try {
				xmlDoc  = xmlCreateDocument("MailItem");
				root    = xmlDoc.documentElement;	
			} catch (e) {
				dbgOut.printException("Can't create XML document", e);
				return null;
			}
			
			try {		
				root.appendChild(createXMLElement("Path", getLocalPath(path), "Text"));
	
				try {
					root.appendChild(createXMLElement("EntryID", mailItem.EntryID, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'EntryID' property ", e);
				}
		
				try {
					root.appendChild(createXMLElement("Size", mailItem.Size, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'Size' property ", e);
				}
		
				try {
					root.appendChild(createXMLElement("BodyFormat", mailItem.BodyFormat, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'BodyFormat' property ", e);
				}
		
				try {
					root.appendChild(createXMLElement("To", mailItem.To, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'To' property ", e);
				}
				
				try {
					root.appendChild(createXMLElement("CC", mailItem.CC, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'CC' property ", e);
				}
				
				try {
					root.appendChild(createXMLElement("BCC", mailItem.BCC, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'BCC' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("Companies", mailItem.Companies, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'Companies' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("CreationTime", mailItem.CreationTime, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'CreationTime' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("DeferredDeliveryTime", mailItem.DeferredDeliveryTime, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'DeferredDeliveryTime' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("SentOn", mailItem.SentOn, "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'SentOn' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("ReceivedTime",  mailItem.ReceivedTime,  "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'ReceivedTime' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("SenderName",  mailItem.SenderName,           "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'SenderName' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("ReceivedByName",       mailItem.ReceivedByName,       "Text"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'ReceivedByName' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("Subject",  mailItem.Subject,  "CDATA"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'Subject' property ", e);
				}
	
				try {
					root.appendChild(createXMLElement("Body", mailItem.Body, "CDATA"));
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'Body' property ", e);
				}
				
				var recipients = xmlDoc.createElement("Recipients");
				root.appendChild(recipients);
				
				try {
					var n = this.mailItem.Recipients.Count;
		
					if(n>0){
						for(var j=1; j<=n; j++) {
							try {
								var recipient     = xmlDoc.createElement("Recipient");
								var address_entry = xmlDoc.createElement("AddressEntry");
		
								recipients.appendChild(recipient);
								recipient.appendChild(address_entry);
					
								var item = mailItem.Recipients.Item(j);
								
								recipient.appendChild(createXMLElement("Name",        item.Name,    "Text"));
								recipient.appendChild(createXMLElement("Address",     item.Address, "Text"));
								address_entry.appendChild(createXMLElement("EntryID", item.AddressEntry.ID,   "Text"));
								address_entry.appendChild(createXMLElement("Type",    item.AddressEntry.Type, "Text"));
							} catch (e) {
								dbgOut.printExcetption("Can't extract 'Recipient' property ", e);
							}
						}
					}
				} catch (e1) {
					dbgOut.printExcetption("Can't extract 'Recipient List' ", e1);
				}
				try {
					var attach = xmlDoc.createElement("Attachments");
					var files  = xmlDoc.createElement("FileList");
					
					n = mailItem.Attachments.Count;
					root.appendChild(attach);
					attach.appendChild(createXMLElement("Count", n, "Text"));
					
					attach.appendChild(files);
					if(n>0){
						for(var j=1; j<=n; j++) {
							files.appendChild(createXMLElement("File", mailItem.Attachments.Item(j).FileName, "Text"));
						}
					}
				} catch (e) {
					dbgOut.printExcetption("Can't extract 'Attachment' property ", e);
				}
			} catch (exc){
				dbgOut.printException("Can't extract data from MailItem ", exc);
				dbgOut.printException("MailItem path : "+path, null);
				return null;
			}
			return xmlDoc;
		}
	},
	
	createXMLElement:function(_name, _value, _type) {
		with (this) {
			try {
				var elem = xmlDoc.createElement(_name);
				switch (_type) {
	   				case "Text" :
						var content = xmlDoc.createTextNode(_value)
						elem.appendChild(content)   			
	       				break;
	   				case "CDATA" :
						var content = xmlDoc.createCDATASection(_value)
						elem.appendChild(content)   			
	       				break;
				}
			} catch (e) {
 				dbgOut.printException("Can't create XML element", e);
 				dbgOut.printException("Node name  : "+ _name,  null);
 				dbgOut.printException("Node type  : "+ _type,  null);
 				dbgOut.printException("Node value : "+ _value, null);
			}
		} 		
		return elem;
	},
	
	save:function() {
		with(this) {
			createFolder(path)
			saveXML(path);
			saveHTMLBody(path);
			saveAttachments(path);
		}
	},
	
	saveHTMLBody:function(_path) {
		with(this) {
			var name = _path + "/mail.body.html";
			try {
				var fsObject  = new ActiveXObject("Scripting.FileSystemObject"); 
		 		var tfObject  = fsObject.CreateTextFile(name, true, false);
		 		var html = new String(mailItem.HTMLBody);
				for(var j=1; j<=mailItem.Attachments.Count; j++) {
					var a_name =  mailItem.Attachments.Item(j).FileName;
			 		html = html.replace(/src\=\"cid\:(.*?)"/i, "src='" + a_name + "'", 1);
				}
		 		mailItem.HTMLBody = html;
				tfObject.Write(html);
 				tfObject.Close();			
 			} catch (e) {
 				dbgOut.printException("Can't save HTML body in file : "+name, e);
 			}
		}
	},

	
	saveAttachments:function(_path) {
		with(this) {
			try {
				var n = mailItem.Attachments.Count;
				if(n<=0) {
					return true;
				}
				dbgOut.println("Attachments count :" +mailItem.Attachments.Count);
				for(var j=1; j<=mailItem.Attachments.Count; j++) {
					var a_name =  mailItem.Attachments.Item(j).FileName;
					var name = _path + "/" + a_name;
					try {
						mailItem.Attachments.Item(j).SaveAsFile(name);
					} catch(e1) {
	 					dbgOut.printException("Can't save attachment : " + a_name, e1);
	 					dbgOut.printException("File name : " + name, null);
					}
				}
			} catch (e) {
				dbgOut.printException("Can't save attachments", e);
			}
		}
	},

	saveXML:function() {
		with(this) {
			var name = path + "/mail.xml";
			try {
				createXML().save(name);
			} catch(e) {
 				dbgOut.printException("Can't save XML in file : "+name, e);
			}
		}
	}
};


/*************************************************************************************************************
									oeMailFolder Object							
**************************************************************************************************************/
function oeMailFolder(_folder, _path, _oePath) {
	this.oePath         = _oePath+ "/" + _folder.Name;
	this.mailFolder     = _folder;
	this.fileFolderName = getFolderName();
	this.mailFolderName = _folder.Name;
	this.parentPath     = _path;
	this.path           = this.parentPath + "/" + this.fileFolderName;
}

oeMailFolder.prototype={
	constructor:oeMailFolder, 
	
	save:function() {
		with(this){
			if (fltFolder) {
				if(!fltFolder.isSelected(oePath)) {
//					debugger;
					dbgOut.println("Skip : "+oePath);
					return false;				
				}
			}
			
			dbgOut.println("Export : "+oePath);
			
			createFolder(path);
			var oXML = getXML();
			oXML.save(path + "/folder.xml");
			
			try {
				var items = mailFolder.Items;
				if(items.Count>0) {
					dbgOut.println("MailItems Count : " +items.Count);
					for(var i=1; i<=items.Count; i++) {
						var item = new oeMailItem(items(i), path);
						item.save(path);
					}
				}
			} catch (e) {
				dbgOut.printException("Can't export mail items ", e);
			} 
			
			var folders = mailFolder.Folders;
			if(folders.Count>0) {
				dbgOut.println("SubFolders Count : " + folders.Count);
				for(var i=1; i<=folders.Count; i++) {
					try {
						var folder = new oeMailFolder(folders(i), path, oePath);
						folder.save();
					} catch (e) {
						dbgOut.printException("Can't save subfolder ", e);
					}
				}
			}
		}
	},
	
	getXML:function() {
		with(this) {
			var oXML  = xmlCreateDocument("Folder");
			xmlAppendChild(oXML, oXML.documentElement, "Name",          mailFolderName);
			xmlAppendChild(oXML, oXML.documentElement, "FolderName",    fileFolderName);
			xmlAppendChild(oXML, oXML.documentElement, "Path",          getLocalPath(path));
			return oXML;
		}
	}
}

/*************************************************************************************************************
							oeMapiNS Object
**************************************************************************************************************/
function oeMapiNS() {

}

oeMapiNS.prototype={
	constructor:oeMapiNS,
	
	getFoldersTreeXML:function() {
		var folders = mapiNS.Folders();
		var oXML    = xmlCreateDocument("FolderList");
		var xmlRoot = oXML.documentElement;
		dbgOut.println("Load folders tree...");
		
		for(var i=1; i<=folders.Count; i++) {
			getSubTree(folders.Item(i), "", xmlRoot); 
		}
		
		function getSubTree(folder, parentPath, parentNode) {
			try {
				var path = parentPath + "/" +folder.Name;
				var node = xmlAppendChild(oXML, parentNode, "Folder", null);
				dbgOut.println(path);
				xmlAppendChild(oXML, node, "Name", folder.Name);
				xmlAppendChild(oXML, node, "Path", path);
				
				var sFolders = folder.Folders();
				var nodeList = xmlAppendChild(oXML, node, "FolderList", null);
				for(var i=1; i<=sFolders.Count; i++) {
					getSubTree(sFolders.Item(i), path, nodeList); 
				}
			} catch (e) {}
		}
		return oXML;
	},
	
	getAddressListsXML:function() {
		dbgOut.println("Load Address lits ...");
		var aLists  = mapiNS.AddressLists;	
		var oXML    = xmlCreateDocument("AddressLists");
		var xmlRoot = oXML.documentElement;
		for(var i=1; i<=aLists.Count; i++) {
			var aList = aLists.Item(i);
			dbgOut.println(aList.Name);
			var xList = xmlAppendChild(oXML, xmlRoot, "AddressList", null);
			xmlAppendChild(oXML, xList, "Name", aList.Name);
		}
		return oXML;
	}
} 
	

/*************************************************************************************************************
							Export Address Book
**************************************************************************************************************/
function exportAddressBook(path) {
	dbgOut.println("Export Address Lists ...");
	var aLists  = mapiNS.AddressLists;	
	var oXML    = xmlCreateDocument("AddressLists");
	var xmlRoot = oXML.documentElement;
	
	for(var i=1; i<=aLists.Count; i++) {
		var aList = aLists.Item(i);
		
		if (fltAddress) {
			if(!fltAddress.isSelected(aList.Name)) {
				dbgOut.println("Skip : "+aList.Nam);
				continue;				
			}
		}
		
		var xList = xmlAppendChild(oXML, xmlRoot, "AddressList", null);
		xmlAppendChild(oXML, xList, "Name", aList.Name);
		var xAddressEntries = xmlAppendChild(oXML, xList, "AddressEntries", null);
		var aAddressEntries = aList.AddressEntries;
		
		dbgOut.println("Export : "+aList.Name +" (" + aAddressEntries.Count + ")");
		
		for(var j=1; j<=aAddressEntries.Count; j++) {
			var xAddressEntry = xmlAppendChild(oXML, xAddressEntries, "AddressEntry", null);
			var aEntry = aAddressEntries.item(j);
			xmlAppendChild(oXML, xAddressEntry, "Name",    aEntry.Name);
			xmlAppendChild(oXML, xAddressEntry, "Address", aEntry.Address);
		}
	}
	var xmlName = path + "/AddressBook.xml";
	dbgOut.println("Save : "+xmlName);
	oXML.save(xmlName);
}

