/******************************************************************************
	File   : XmlMail.js
	Author : Maxim Kazitov
	E-Mail : mvkazit@tut.by
******************************************************************************/

/******************************************************************************
				XML Mail Backup
*******************************************************************************/
function xmBackup(_path) {
	this.path = _path;
}

xmBackup.prototype={
	constructor:xmBackup,
	
	makeIndex:function() {
		with(this) {
			try {
				dbgOut.println("Index folders tree...");
				var oXML = getFolderTreeXML(null, null, null);
				oXML.save(path + "/FoldersTree.xml");

				var oFileSys    = new ActiveXObject("Scripting.FileSystemObject");
				var	oFolder     = oFileSys.GetFolder(path);
				var oSubFolders = new Enumerator(oFolder.SubFolders);
				for (; !oSubFolders.atEnd(); oSubFolders.moveNext()) {
					(new xmFolder(oSubFolders.item())).makeIndex();
				}
			} catch (e) {
				dbgOut.printException("Can't index folders tree ", e);
			}
		}
	},
	
	getFolderTreeXML:function(xml, parent, _path) {
		dbgOut.println("Index folder : "+_path);
		
		var oXML        = xml!=null    ? xml : xmlCreateDocument("FolderList");		
		var xmlRoot     = parent!=null ? parent : oXML.documentElement;
		var path        = _path != null ? _path : this.path;
		var oFileSys    = new ActiveXObject("Scripting.FileSystemObject");
		var	oFolder     = oFileSys.GetFolder(path);
		var oSubFolders = new Enumerator(oFolder.SubFolders);
		
		for (; !oSubFolders.atEnd(); oSubFolders.moveNext()) {
			var sFolder = oSubFolders.item();
			
			if((new String(sFolder.Name)).indexOf("Folder.")==0) {
				try {
					var sXML = xmlCreateDocument(null);
					sXML.load(path + "/"+sFolder.Name + "/folder.xml");
					var node = xmlRoot.appendChild(sXML.documentElement);
					this.getFolderTreeXML(oXML, xmlAppendChild(oXML, node, "FolderList", null), path + "\\"+sFolder.Name);
				} catch(e) {
					dbgOut.printException("Can't add folder to tree", e);
				}
			}
		}
		return oXML;
	}
}

/******************************************************************************
				XML Mail Folder Object
*******************************************************************************/
function xmFolder(_folder) {
	this.folder = _folder;	
}

xmFolder.prototype={
	constructor:xmFolder, 
	
	makeIndex:function() {
		with(this) {
			try {
				dbgOut.println("Index folder : " + folder.Path);
				var oXML        = new ActiveXObject("Msxml2.DOMDocument");		
				var xmlRoot     = oXML.createElement("MailList");
				var oSubFolders = new Enumerator(folder.SubFolders);
				var outFile     = folder.path+"/mail_index.xml";
				oXML.appendChild(xmlRoot);
				
				for (; !oSubFolders.atEnd(); oSubFolders.moveNext()) {
					var sFolder = oSubFolders.item();
					if((new String(sFolder.Name)).indexOf("Mail.")==0) {
						var miXML = (new xmMailItem(sFolder)).getIndexXML();
						if(miXML!= null){
							xmlRoot.appendChild(miXML); 
						}
					} else {
						(new xmFolder(sFolder)).makeIndex();
					}
				}
				oXML.save(outFile);
				oXML = null;
			} catch (e) {
				dbgOut.printException("Can't index folder : "+folder.Path, e);
			}
		}		
	}
}
	
/******************************************************************************
						XML MailItem
******************************************************************************/
function xmMailItem(_folder) {
	this.folder = _folder;	
}

xmMailItem.prototype={
	constructor:xmMailItem, 
	
	getIndexXML:function() {
		with(this) {
			var mailXML      = new ActiveXObject("Msxml2.DOMDocument");		
			var indexXML     = new ActiveXObject("Msxml2.DOMDocument");		
			var xsltMailItem = new ActiveXObject("Msxml2.DOMDocument");		
			xsltMailItem.load(PATH_XSLT+"/Mail2Index.xsl");
			try {
				mailXML.load(folder.Path+"/mail.xml");
				mailXML.transformNodeToObject(xsltMailItem, indexXML);
				if(indexXML.documentElement != null) {
					var path     = ((new String(folder.Path)).slice(PATH_DATA.length)).replace(/\\/gi, "/");				
					var pathXML  = indexXML.createElement("Path");
					pathXML.text = path;
					indexXML.documentElement.appendChild(pathXML);
				}
				return indexXML.documentElement;
				
			} catch (e) {
				dbgOut.printException("Can't index mail items ", e);
				dbgOut.printException("path :"+folder.Path, null);
				return null;
			} finally {
				mailXML      = null;
				indexXML     = null;
				xsltMailItem = null;
			}
		}
	}
}
