/******************************************************************************
	File   : FileUtils.js
	Author : Maxim Kazitov
	E-Mail : mvkazit@tut.by
******************************************************************************/

function createFolder(name) {
	var f   = null;
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	try {
		f   = fso.CreateFolder(name);
	} catch (e) {
		dbgOut.printException("Can't create folder : "+name);
		return null;
	}
	return f;
}

function saveText(file_name, text) {
	try {
		var fso = new ActiveXObject("Scripting.FileSystemObject")
		var f = fso.CreateTextFile(file_name, true, false);
		f.Write(text);
		f.Close();
	} catch (e) {
		dbgOut.printException("Can't save file ("+file_name+") ", e);
	}
}

function getFileExt(file_name) {
	var text = new String(file_name);
	var idx  = text.lastIndexOf(".");
	var ext  = (text.substr(idx+1, text.length - (idx+1))).toLowerCase();
	return ext;
} 

function getFolderPath(_folder) {
	var fso = new ActiveXObject("Scripting.FileSystemObject")
	var f = fso.GetFolder(_folder);
	return f.path;
}