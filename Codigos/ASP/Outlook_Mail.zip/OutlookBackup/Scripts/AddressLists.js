var outlookApp = new ActiveXObject("Outlook.Application"); 
var mapiNS     = outlookApp.getNameSpace("MAPI"); 

var folders = mapiNS.Folders();


function exportAddressBook(path) {
	var aLists  = mapiNS.AddressLists;	
	var oXML    = xmlCreateDocument("AddressLists");
	var xmlRoot = oXML.documentElement;
	
	for(var i=1; i<=aLists.Count; i++) {
		var aList = aLists.Item(i);
		WScript.Echo("Address List : "+aList.Name);
		var aAddressEntries = aList.AddressEntries;
		
		for(var j=1; j<=aAddressEntries.Count; j++) {
			var aEntry = aAddressEntries.item(j);
			WScript.Echo("\t"+aEntry.Name);
			WScript.Echo("\t"+aEntry.Address);
		}
	}
}
