/******************************************************************************
	File   : XmlUtils.js
	Author : Maxim Kazitov
	E-Mail : mvkazit@tut.by
******************************************************************************/
function xmlCreateDocument(rootName) {
	var xml = null;
	try {
		xml = new ActiveXObject("Msxml2.DOMDocument");
	} catch (e) {
		dbgOut.printException("Can't create 'Msxml2.DOMDocument' ", e);
	}
	
	xml.async           = false;
	xml.validateOnParse = false; 
	
	if(rootName != null) {
		var root = xml.createElement(rootName);
		xml.appendChild(root);
	}
	return xml;
}

function xslCreateDocument(file) {
	var xml = null;
	try {
		xml = new ActiveXObject("Msxml2.DOMDocument");
	} catch (e) {
		dbgOut.printException("Can't create 'Msxml2.DOMDocument' ", e);
	}
	
	xml.async           = false;
	xml.validateOnParse = false; 
	xml.load(file);
		
	return xml;
}

function loadXMLDocument(file) {
	return xslCreateDocument(file);
}

function xmlAppendChild(xml, parent, name, value) {
	var item  = xml.createElement(name);
	if(value != null) {
		item.text = value;
	}
	parent.appendChild(item);
	
	return item;
}

function xml2html(xml_src, xsl_src) {
	var oXSL = xmlCreateDocument(null);
	var oXML = xmlCreateDocument(null);
	oXSL.load(xsl_src);
	oXML.load(xml_src);
	var html = oXML.transformNode(oXSL);
	
	return html;
}
