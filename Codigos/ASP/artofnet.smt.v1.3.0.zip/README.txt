==========================================
=		INFO                     =
========================================================================
 I stared working on a new application called RAIP (Rhwy's Art Of 
 Internet Portal). It is globaly a Portal, in PHP-nuke style, but with more
 flexibility: interface in html/css, coding in ASP/PHP/JSP, with an XML/XSL
 layer between.
 I am searching people who wants to be involded in this project because even if I can
 do all the parts of this work it is always better to have various minds brainstorming
 together. These participations could be: graphics & design, asp, php, jsp/servlets(I am 
 not so good in XML manipulation in servlets...), XSL integration, SQL manipulation, 
 translation, concepts designer, site news, contact and more...

 PLEASE SEND A MAIL TO rui@artofnet.com with RAIP in subject

 Status:
 tow collateral works: a documentation file which describes all the solution is
 on going, a first portal template is being done (in PHP/MySQL) to see the implementation
 design and needs. 
=========================================================================