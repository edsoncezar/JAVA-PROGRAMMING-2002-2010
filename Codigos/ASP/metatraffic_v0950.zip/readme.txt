MetaTraffic v0.950 Pre-Release
Metasun Software
http://www.metasun.com

Licensing
---------

MetaTraffic is distributed as freeware with some restrictions. Please make sure you read the license.txt file for full details. Please pay attention to Sections 1 and 2.

Overview
--------

MetaTraffic is a web site statistics application developed in pure ASP. This is a pre-release version; some functionality has been removed.

See the web site for full details. (http://www.metasun.com)

Contents
--------

* readme.txt - This file
* calendar.asp - Calendar popup that allows you to pick dates for your reports
* class.asp - MetaTraffic class that does all the dirty work
* config.asp - Configuration file that includes database information
* default.asp - Page that generates the reports
* track.asp - Tracking script that needs to included in your asp pages or redirected through to log activity to the database
* db.mdb - MS Access database
* metatraffic.sql - SQL Script for creating table in SQL Server database
* help.htm - help file
* license.txt - MetaTraffic software license agreement
* spacer.gif
* calendar.gif
* metatraffic.gif

Total: 13 files

Version History
---------------

v0.950 - Dec 9th, 2002
* Added keyword report
* Added support for MS Access databases on shared paths
* Optimized data analysis functions to speed up report generation
* Enhanced report design
* Added graphing to most reports
* Fixed a javascript bug that prevented date selection using Netscape
* Added numbering to most reports
* Added license.txt and detailed copyright information in all the files
* Added help for reports
* Changed blnGenerateData to intAnalyzeData and changed its configuration options for more flexibility on when data analysis occurs

v0.900 - Nov 13th, 2002
* Added SQL Server support
* Cleaned up presentation of default.asp to use stylesheet properties

v0.861 - Nov 8th, 2002
* Changed database date formatting to use International Standard ISO 8601 date format

v0.860 - Nov 6th, 2002
* Several bug fixes and code optimizations
- Rewrote all code to support locales which can be specificed in the config file
- Session duration is now a configurable item in the config file

v0.850 - Oct 28th, 2002
* Several bug fixes and code optimizations
 - Fixed several bugs with date formatting
 - Moved database connection code into clsMetaTraffic class
 - Moved page logging code into clsMetaTraffic class 
 - Enhanced config.asp file to make it easier to setup absolute paths and virtual / relative paths for connecting to the database
 - Truncate logging data if it exceeds any database field lengths
* Added new configuration option - site aliases

v0.801 - Oct 7th, 2002
* Fixed a minor bug that caused incorrect Visitor statistics

v0.800 - Oct 2nd, 2002
* First Pre Release Version

Requirements
------------

Mandatory Server Requirements

* IIS 5.0  hosted web site that supports ASP 3.0 and Visual Basic Scripting Edition v5

--MS ACCESS--
* Microsoft Jet OLEDB v4.0 drivers installed on IIS machine (for accessing the MS Access database)
* Read / Write permissions on the MS Access database (db.mdb)

--SQL SERVER--
* SQL Server 7 / 2000 Server with SQL Server drivers installed on IIS Machine
* DataReader / DataWriter permissions on PageLog table by SQL Server login specified in the configuration

Optional Server Requirements

* Reverse DNS Lookup enabled in IIS -- Shows the hostname of the visitor in the Who's Online report
(See http://support.microsoft.com/default.aspx?scid=kb;en-us;Q245574 for more information on enabling reverse DNS lookups in IIS.)

Client Requirements

* IE 6.0 and Netscape 6.2 have been tested to work properly with MetaTraffic's report generator. Some javascript and stylesheet properties may cause problems in earlier browser versions.

Installing the Report Generator
-------------------------------

1. Extract the contents of the zip file into a folder called metatraffic.

2. Modify config.asp as nessasary. Default installations with an MS Access database will not usually require any modification.

3. Upload the folder to your web site.

Setting Up SQL Server
---------------------

If you would like to use SQL Server as your database, you will need to run the metatraffic.sql file using SQL Server Query Analyzer. This will create the table nessasary for logging and reporting web activity. Make sure the database is set to whatever database you want the table created on in before you run the script. Once the table is created, create a user or use an existing SQL Server login account that has datareader/datawriter priviledges on that database. Do not use the SA account other than for testing purposes. Make sure the account that has proper privilidges on the database is setup in the config.asp file.

Setting Up Tracking 
-------------------

The file that logs activity to the database is called track.asp. This file can be used in several different ways depending on what type of file you want to track. (See examples below.)

If you are NOT using the ASP method shown below, you must pass one or more querystring variables to track.asp in order to tell it what filename you are tracking and redirect the user to a file when it's done. These are: r (redirect) and f (file). These can be used in conjunction with each other but at least one must be present otherwise all your page views will show up as /track.asp.

** ASP PAGES (.asp)

To track your .ASP files, add the following code to any .ASP page that you want to track:

<% Server.Execute("metatraffic/track.asp") %> 

Or a virtual file path like this:

<% Server.Execute("/metatraffic/track.asp") %>

** TRACKING NON-ASP FILES (.htm, .exe, .zip, etc)

You can also track files that aren't web pages by linking to them in your web page with HTML. The link would look like this:

<a href="metatraffic/track.asp?r=/downloads/somefile.zip">Download somefile.zip</a>

This would track downloads of somefile.zip that existed in a virtual folder called downloads.  Once track.asp logs the activity, the user is redirected to whatever file you specify.

Upgrading From Previous Versions
--------------------------------

v0.900 --> v0.950:

Every file has been updated except the database. You will need to update all your files except db.mdb and metatraffic.sql and ensure the configuration in config.asp is correct. To generate keyword information for past data, change the config setting intAnalyzeData to 3 temporarily and run keyword reports for past data. After this is done once, you will have the keyword information for past data and it is recommended you change the intAnalyzeData setting back to 1.

v0.861 --> v0.900: 

The following files need to be updated:

* config.asp - You will need to update your configuration in the new config file
* default.asp
* class.asp
* track.asp

Migrating MS Access to SQL Server:
* Once the SQL Server database is created, use Enterprise Manager's data import wizard to import your MS Access database. (This was successfully tested under SQL Server 2000.)

v0.860 --> v0.861: 

The following files need to be updated:

* class.asp

Troubleshooting Common Problems
-------------------------------

The most common problem that occurs when setting up MetaTraffic with an MS Access database is an error that says: "Operation must use an updateable query." This is caused by the Internet Guest account (IUSR_MACHINE) not having write permissions on the database file (db.mdb). Please see the following Microsoft support article for more information:

http://support.microsoft.com/default.aspx?scid=kb;en-us;Q175168

Security Considerations
-----------------------

If you are using MS Access as your database, it is not a good idea to have it in a publicly accessible folder such as in your web site content directory. It is recommended that you move it to a folder on your server that is not accessible via your web site. However, the Internet Guest account (IUSR_MACHINE) of your web server must have read and write permissions on the database file.

Known Limitations
-----------------

It is not recommended that you change the intAnalyzeData variable from the default. (Until MetaTraffic v1.0) Changing this option from the default can cause odd reporting behavior and slow generation of reports.

Support
-------

If you have support requests, please visit our site at www.metasun.com and post a message in the support forum.