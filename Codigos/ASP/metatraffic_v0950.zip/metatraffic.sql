CREATE TABLE [dbo].[PageLog] (
	[pl_datetime] [datetime] NULL ,
	[pl_referrer] [varchar] (255) NULL ,
	[pl_ipaddress] [varchar] (50) NULL ,
	[pl_scriptname] [varchar] (255) NULL ,
	[pl_useragent] [varchar] (255) NULL ,
	[pl_querystring] [varchar] (255) NULL ,
	[pl_sessionid] [varchar] (50) NULL ,
	[pl_remotehost] [varchar] (255) NULL ,
	[pl_referrerdomain] [varchar] (150) NULL ,
	[pl_referrerurl] [varchar] (255) NULL ,
	[pl_keywords] [varchar] (100) NULL ,
	[pl_language] [varchar] (50) NULL ,
	[pl_languageactual] [varchar] (50) NULL ,
	[pl_os] [varchar] (50) NULL ,
	[pl_browser] [varchar] (50) NULL ,
	[pl_browsertype] [varchar] (50) NULL 
) ON [PRIMARY]
GO