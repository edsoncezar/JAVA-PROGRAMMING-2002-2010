'==============================================================================================
'	ArtOfNet::Server Management Tools
'==============================================================================================
'	This script is a part of a multiscript package, all the scripts can be found on
'	http://www.artofnet.com and made by rui@artofnet.com. You are free to use this script
'	as long as you provide this copyright information
'	(c) 2000-2002 ArtOfNet.com
'==============================================================================================
'	$Author: Admin $
'	$Date: 22/06/02 1:34 $
'	$Revision: 1 $
==========================================================


==========================================
=		ArtOfNet.POrtal INFO          =
========================================================================
 It is a new portal application in asp 3 but that use our 
 framework in order to develop it like asp.net...It provide usual 
 functions of comunity portals. If you want to work on it or develop
 new modules (like SMT which is a full administrative module integrated), 
 just write me at rui@artofet.com With ArtOfNet.Portal in subject.

STATUS:
 - 2002-06-24
   the version 1.0 of the portal and the framework is online



==========================================
=		RAIP INFO                     =
========================================================================
 I stared working on a new application called RAIP (Rhwy's Art Of 
 Internet Portal). It is globaly a Portal, in PHP-nuke style, but with more
 flexibility: interface in html/css, coding in ASP/PHP/JSP, with an XML/XSL
 layer between.
 I am searching people who wants to be involded in this project because even if I can
 do all the parts of this work it is always better to have various minds brainstorming
 together. These participations could be: graphics & design, asp, php, jsp/servlets(I am 
 not so good in XML manipulation with servlets...), XSL integration, SQL manipulation, 
 translation, concepts designer, site news, contact and more...

 PLEASE SEND A MAIL TO rui@artofnet.com with RAIP in subject

 Status:
- 2002-06-24
 The portal is temporaly out because I don't have time to work on it
-2001-10-05
 the demo portal is quite working on http://www.raip.net, it is not fully achieved
 but the bases are here, plus a news system with comments and rss backend, a newsletter, 
 a box system and an internal messaging system. All these are working on php/mysql,
 but some asp classes are also yet working.

-Started 2001-08-31
 tow collateral works: a documentation file which describes all the solution is
 on going, a first portal template is being done (in PHP/MySQL) to see the implementation
 design and needs. 
=========================================================================