XcCal - A Basic Website Calendar
--------------------------------

 XcCal displays a simple calendar on a web page. It shows the 
current day highlighted. It can be fully integrated into your
website and maintain a 100% seamless look. It utilizes an HTML 
document template to do this. You create a HTML document using
any HTML editor you like and insert a special COMMENT tag into
the document where you want the calendar to appear at. You put 
the XcCal.asp file, and your custom HTML template, usually 
called XcCal.htm, in the same directory within your website.
Then, in the rest of your website, you just reference the 
XcCal.asp document, and it will automatically build the
calendar using your custom template.

Requirements
------------
XcCal is an Active Server Page script application for your website. 
It requires your website to be hosted on Microsoft Internet Information
Server, or equivelent. Ask your ISP if they support Active Server Pages.
If they don't, find one that is. See our website for our recommendations.


Creating the Template
---------------------

1) Create a new XcCal.htm file in your HTML Editor (FrontPage, Notepad, whatever...).

2) Where you want the calendar to appear, put the tags "<COMMENT>XCCAL</COMMENT>".
   (Note: the tags don't include the quote marks)

3) Link to the XcCal.ASP file, not the XcCal.htm file, in the rest of your website.

4) Upload both XcCal.asp and XcCal.htm to the same directory on your website.


Support
-------
XcCal is a freely available script. You can freely use this script on your own
website. Support for this script is provided via a message board on our web site.
Visit http://www.xcent.com/products.htm 