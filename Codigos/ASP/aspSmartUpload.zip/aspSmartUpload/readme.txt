--------------------------------------
aspSmartUpload 2.03
README.TXT
--------------------------------------
Date last modified : Feb 1, 2000
Copyright 2000, ADVANTYS
--------------------------------------
http://www.aspSmart.com
support@aspSmart.com
--------------------------------------

aspSmartUpload
--------------
- Please read legal.htm before installing and using the component.

Install Instructions
--------------------
- the /help/setup.htm file contains install instructions.

Requirements
------------
- the /help/requirements.htm contains conditions of use for the aspSmartUpload component.

Component objects help
----------------------
- the /help/SmartUploadObjects.htm file is a full aspSmartUpload on-line documentation.

