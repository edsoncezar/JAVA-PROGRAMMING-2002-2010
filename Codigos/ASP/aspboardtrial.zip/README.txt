READ ME - ASP Message Board Trial v1.0 
Tipped Cow Development/Adrenalin Labs
http://www.tippedcow.com/
http://dstoflet.calweb.com/
support@tippedcow.tzo.com

PLEASE READ the license_agreement.txt before installing!

Installion:

Basically the installation is very straight forward. We've removed the global.asa file because the seemed to cause the most problems. Just unzip into a directory and setup the "web settings" from the main page and your all set.

1]  Unzip all the files in the "aspboard" directory into a directory on your web server. B

That's basically all you have to do with the web server and files. You will need ADMIN access to your forums so:

1]  Click "login" from the default page. Enter user: admin / pass: admin. You can now create/delete/edit/whatever from these screens. Delete the "Forum One" forum and create your own. 

Please enjoy the ASP Message Board!

======================================================================

- Jeff Wood, Tipped Cow Development, http://www.tippedcow.com/.
/ Darryl Stoflet, Adrenalin Labs, http://dstoflet.calweb.com