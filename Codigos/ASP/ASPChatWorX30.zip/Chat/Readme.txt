###################
# ASPChatWorX 3.0 #
###################
This Source Code is FREE!
Our only request is that you keep the Banner in Place.
Add ALL the Files to a Directory of your Choice. eg: /MyWeb/Chat/
Add the following line to the top of your global.asa file:

<OBJECT	RUNAT=Server
	SCOPE=Application
	ID=ASPChat
	PROGID="Scripting.Dictionary">
</OBJECT>

<OBJECT	RUNAT=Server
	SCOPE=Application
	ID=ASPChatTime
	PROGID="Scripting.Dictionary">
</OBJECT>

Add the follwing line to Application Startup in global.asa
<SCRIPT LANGUAGE="VBScript" RUNAT="Server">
Sub Application_OnStart
	Application( "SwearWords" ) = Split("FUCK SHIT ASSHOLE NIGGER IDIOT CUNT KUNT ARSE KAFFIR HONKY WETBACK", " ")
End Sub
</SCRIPT>