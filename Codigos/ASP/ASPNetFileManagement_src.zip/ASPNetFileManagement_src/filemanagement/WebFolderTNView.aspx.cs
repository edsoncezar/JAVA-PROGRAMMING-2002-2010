using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO ; 
using System.Configuration ;
using Utility.Web ;

namespace filemanagement
{
	/// <summary>
	/// Summary description for WebFolderTNView.
	/// </summary>
	public class WebFolderTNView : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.Label LabelMsg;
//		private string root ;
		protected UCMainMenu UCMainMenu1 ;
		protected System.Web.UI.WebControls.DataList DataList1;

		private string RootPath
		{
			get 
			{ 
				if ( ViewState["RootPath"] == null )
					return ConfigurationSettings.AppSettings["Root"] ;
				else
					return ViewState["RootPath"] as string ;
			}

			set 
			{
				ViewState["RootPath"] = value ;
			}
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			LabelMsg.Text = string.Empty ;

			if (!IsPostBack)
			{
				this.RegisterClientScriptBlock("ChangeTitle", string.Format( "<script>document.title='{0} - ' + document.title;</script>", ConfigurationSettings.AppSettings["company"] ) ) ;
				
				this.RootPath = Request["path"] ;

				this.BindGrid() ;
				
				DataList1.Caption = string.Format("Path : {0}", this.RootPath ) ;

				if ( string.Compare(this.RootPath, ConfigurationSettings.AppSettings["Root"], true) != 0 )
					UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkLevelUp).NavigateUrl = this.Request.Path + "?path=" + Server.UrlEncode(Directory.GetParent(this.RootPath).FullName) ;
				else
					UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkLevelUp).Visible = false ;

				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkHome).NavigateUrl =  this.Request.Path ;
				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperlinkListView).NavigateUrl = "WebFolder.aspx?" + this.Request.QueryString ;

				if ( Request["Error"] != null )
					LabelMsg.Text = Request["Error"] ;
			}

		}

		private void BindGrid()
		{
			try
			{
				DataList1.DataSource = CacheManager.GetFileItems(this.RootPath, false) ;
				DataList1.DataBind() ;
			}
			catch ( UnauthorizedAccessException )
			{
				this.LabelMsg.Text = "Sorry! You are not allowed to access this folder." ;
				return ;
			}
			
		}

		protected string FormatSize(object file)
		{
			FileSystemInfoExtend FileSystemInfoEx = file as FileSystemInfoExtend ;
			if ( FileSystemInfoEx == null )
				return "" ;

			if ( !FileSystemInfoEx.IsDirectory )
				return string.Format("{0:N0} KB", (FileSystemInfoEx.Size / 1024.0f)) ; 
				
			else
				return string.Empty ;
		}

		protected string FormatLink(object file)
		{
			FileSystemInfoExtend FileSystemInfoEx = file as FileSystemInfoExtend ;
			if ( FileSystemInfoEx == null )
				return "" ;

			string FileFullName = Server.UrlEncode(FileSystemInfoEx.FullName) ;

			if ( FileSystemInfoEx.IsDirectory )
				return string.Format("{0}?path={1}", this.Request.Path, FileFullName ) ;
			else 
				return string.Format("{0}?file={1}", "FileSender.aspx", FileFullName ) ;
		}

		protected string FormatThumbnail(object file)
		{
			FileSystemInfoExtend FileSystemInfoEx = file as FileSystemInfoExtend ;
			if ( FileSystemInfoEx == null )
				return string.Empty ;

			string ImageSourceLink = string.Empty ;
			string FileFullName = Server.UrlEncode(FileSystemInfoEx.FullName) ;

			if ( FileSystemInfoEx.IsDirectory )
				ImageSourceLink = string.Format("ShowItem.aspx?FileFullname={0}",  WebUtility.FolderImagePath ) ;
			else if ( FileSystemInfoEx.Name.ToLower().EndsWith(".jpg") 
				|| FileSystemInfoEx.Name.ToLower().EndsWith(".gif") 
				|| FileSystemInfoEx.Name.ToLower().EndsWith(".bmp") 
				|| FileSystemInfoEx.Name.ToLower().EndsWith(".png") 
				|| FileSystemInfoEx.Name.ToLower().EndsWith(".tif") 
				) 
				// Show file thumbnail
				ImageSourceLink = string.Format("ShowItem.aspx?Thumbnail=Y&TNSize=50&FileFullname={0}", FileFullName ) ;
			else 
			{
				// Show file icon
				ImageSourceLink = string.Format("ShowFileIcon.aspx?FileFullname={0}&Size=Large", FileFullName) ;
			}

			return ImageSourceLink ;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
