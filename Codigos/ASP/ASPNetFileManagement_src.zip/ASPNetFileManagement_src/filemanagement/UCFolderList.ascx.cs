namespace filemanagement
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Configuration ;

	/// <summary>
	///		Summary description for UCFolderList.
	/// </summary>
	public class UCFolderList : System.Web.UI.UserControl
	{
		protected Microsoft.Web.UI.WebControls.TreeView TreeView1;

		string _InitialSelection ; 
		public string InitialSelection
		{
			set { _InitialSelection = value ; }
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				// Put user code to initialize the page here
				string RootFolder = ConfigurationSettings.AppSettings["root"] ;

				// Create root node 
				Microsoft.Web.UI.WebControls.TreeNode node = new Microsoft.Web.UI.WebControls.TreeNode() ;
				node.Text = RootFolder ;
				node.NodeData = RootFolder ;
				this.TreeView1.Nodes.Add(node) ;
				this.CheckSelection(node) ;

				// Build tree
				this.AddNodesToTreeView(node, RootFolder) ;
			}
		}

		private void CheckSelection(Microsoft.Web.UI.WebControls.TreeNode NodeToCheck)
		{
			if( _InitialSelection != null && NodeToCheck.NodeData.ToLower() == _InitialSelection.ToLower() )
			{
				Microsoft.Web.UI.WebControls.TreeNode NodeParent = NodeToCheck.Parent as Microsoft.Web.UI.WebControls.TreeNode ;
				while (NodeParent != null)
				{
					NodeParent.Expanded = true ;
					NodeParent = NodeParent.Parent as Microsoft.Web.UI.WebControls.TreeNode ;
				}

				NodeToCheck.Expanded = true  ;
				this.TreeView1.SelectedNodeIndex = NodeToCheck.GetNodeIndex() ;
			}
		}

		private void AddNodesToTreeView(Microsoft.Web.UI.WebControls.TreeNode ParentNode, string CurrentFolder)
		{
			FileSystemInfosExtend items = CacheManager.GetFileItems(CurrentFolder, false) ;
			foreach(FileSystemInfoExtend item in  items)
			{
				Microsoft.Web.UI.WebControls.TreeNode node = new Microsoft.Web.UI.WebControls.TreeNode() ;
				node.Text = item.Name ;
				node.NodeData = item.FullName ;
				ParentNode.Nodes.Add(node) ;
				this.CheckSelection(node) ;

				// Recursively adding file items 
				if (item.IsDirectory)
					this.AddNodesToTreeView(node, item.FullName) ;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


	}
}
