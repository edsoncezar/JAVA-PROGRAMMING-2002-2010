using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls ;
using System.Web.UI.HtmlControls ;

namespace Utility.Web
{
	/// <summary>
	/// Summary description for WebUI.
	/// </summary>
	public class WebUI
	{
		static public void ConfigCancelLink( HyperLink link )
		{
			// At command to Back link
			HttpRequest Request = HttpContext.Current.Request ; 
			if ( Request.UrlReferrer != null &&  Request.UrlReferrer.PathAndQuery != "")
				link.NavigateUrl = Request.UrlReferrer.PathAndQuery ; 
			else
			{
				link.NavigateUrl = "#" ;
				link.Attributes["onClick"] = "javascript:history.back();return false;" ;
			}
		}

		static public void ConfigBackLink( HyperLink link )
		{
			// Back only link
			link.NavigateUrl = "#" ;
			link.Attributes["onClick"] = "javascript:history.back();return false;" ;
		}

		static public void ConfigPrint( WebControl control )
		{
			control.Attributes["onClick"] = "javascript:window.print();return false;" ;
		}

		static public string FormatClientString(string InString)
		{
			return InString.Replace("'", @"\'") ;
		}

		static public void SetLabelForInput(System.Web.UI.WebControls.Label LabelControl, System.Web.UI.Control InputControl)
		{
			HtmlGenericControl labelFor = new HtmlGenericControl("label") ;
			LabelControl.Controls.Add(labelFor) ;

			labelFor.Attributes["FOR"] = InputControl.ClientID ;
			labelFor.InnerHtml = LabelControl.Text ;
		}

		static public void SendMessageAtClientSide(System.Web.UI.Page page, string Message )
		{
			Message = WebUI.FormatClientString(Message) ;
			string script = string.Format("alert('{0}');", Message) ;
			page.RegisterStartupScript(Guid.NewGuid().ToString(), WebUI.FormatClientScriptBlock(script)) ;
		}

		static public void ConfirmBeforePostForm( WebControl control, string Message )
		{
			Message = WebUI.FormatClientString(Message) ;
			string script = string.Format("javascript:return confirm('{0}');", Message) ;
			control.Attributes["onClick"] = script ;
		}

		static public string GetImageSourceLink(string RegionCode, string ItemCode, bool Thumbnail, int ThumbnailSize, bool RefreshCache, int CacheTimeout)
		{
			return string.Format("ImageHttpHandler.axd?ImageId={0}:{1}&Thumbnail={2}&TNSize={3}&RefreshCache={4}&CacheTimeout={5}", RegionCode, ItemCode, Thumbnail?"Y":"N", ThumbnailSize, RefreshCache?"Y":"N", CacheTimeout) ;
		}

		static public string GetImageSourceLinkInModelessDialog(System.Web.UI.Page page, string RegionCode, string ItemCode, bool Thumbnail, int ThumbnailSize, bool RefreshCache, int CacheTimeout)
		{
			string OpenModelessDiaglogFuncName = "__diorOpenModelessDialog" ;
			// Register showModelessDiaglog function used by src link
			WebUI.RegisterOpenModelessDialogScript(page,  OpenModelessDiaglogFuncName) ;
			// Get image link
			string FollowLink = WebUI.GetImageSourceLink(RegionCode, ItemCode, Thumbnail, ThumbnailSize, RefreshCache, CacheTimeout) ;

			return string.Format("javascript:{0}(\"{1}\");",OpenModelessDiaglogFuncName, FollowLink) ;
		}

		static public string GetImageSourceLinkInModelDialog(System.Web.UI.Page page, string RegionCode, string ItemCode, bool Thumbnail, int ThumbnailSize, bool RefreshCache, int CacheTimeout)
		{
			string OpenModelDiaglogFuncName = "__diorOpenModelDialog" ;
			// Register showModelDiaglog function used by src link
			WebUI.RegisterOpenModelDialogScript(page,  OpenModelDiaglogFuncName) ;
			// Get image link
			string FollowLink = WebUI.GetImageSourceLink(RegionCode, ItemCode, Thumbnail, ThumbnailSize, RefreshCache, CacheTimeout) ;

			return string.Format("javascript:{0}(\"{1}\");",OpenModelDiaglogFuncName, FollowLink) ;
		}

		static public string GetModelessDialogFuncScript(string FuncName)
		{
 			return	WebUI.FormatClientScriptBlock(string.Format("function {0}(url) {{window.showModelessDialog(url);}}", FuncName)) ;
		}
		
		static public string GetModelDialogFuncScript(string FuncName)
		{
			return	WebUI.FormatClientScriptBlock(string.Format("function {0}(url) {{window.showModalDialog(url);}}", FuncName)) ;
		}

		static public string GetOpenWindowFuncScript(string FuncName)
		{
			return	WebUI.FormatClientScriptBlock(string.Format("function {0}(url) {{window.open(url);}}", FuncName)) ;
		}

		static public void RegisterOpenModelessDialogScript(System.Web.UI.Page page, string FuctionName)
		{
			if (!page.IsClientScriptBlockRegistered(FuctionName))
			{
				if (VersionOfBrowser(page) >= 5.0)
					page.RegisterClientScriptBlock(FuctionName, WebUI.GetModelessDialogFuncScript(FuctionName)) ;
				else
					page.RegisterClientScriptBlock(FuctionName, WebUI.GetOpenWindowFuncScript(FuctionName)) ;
			}
		}

		static public void RegisterOpenModelDialogScript(System.Web.UI.Page page, string FuctionName)
		{
			if (!page.IsClientScriptBlockRegistered(FuctionName))
			{
				if (VersionOfBrowser(page) >= 5.0)
					page.RegisterClientScriptBlock(FuctionName, WebUI.GetModelDialogFuncScript(FuctionName)) ;
				else
					page.RegisterClientScriptBlock(FuctionName, WebUI.GetOpenWindowFuncScript(FuctionName)) ;
			}
		}


		static public void RegisterCheckMonthAndDayValidator(System.Web.UI.Page page, string FuctionName, string MonthControlID, string DayControlID)
		{
			if (!page.IsStartupScriptRegistered(FuctionName))
			{
				string FunctionStatement = 
					"function {0}(source, arguments){{" 
					+ "	var monthVal = parseInt(document.all['{1}'].value) ;" 
					+ "	var dayVal = parseInt(document.all['{2}'].value) ;" 
//					+ "	window.status = monthVal + ' ' + dayVal ;" 
					+ "	if (monthVal==2) " 
					+ "		arguments.IsValid = dayVal > 0 && dayVal <= 29 ;" 
					+ "	else if (monthVal==1 || monthVal==3 || monthVal==5 || monthVal==7 || monthVal==8 || monthVal==10 || monthVal==12) " 
					+ "		arguments.IsValid = dayVal > 0 && dayVal <= 31 ; " 
					+ "	else arguments.IsValid = dayVal > 0 && dayVal <= 30 ; }}" ;

				FunctionStatement = string.Format(
					FunctionStatement
					, FuctionName, MonthControlID, DayControlID) ;
					
				page.RegisterStartupScript(FuctionName, WebUI.FormatClientScriptBlock(FunctionStatement)) ;
			}
		}


		static public double VersionOfBrowser(System.Web.UI.Page page)
		{
			double BrowserVer = 3 ;
			try
			{
				BrowserVer = Double.Parse(page.Request.Browser.Version) ; 
			}
			catch {}
			return BrowserVer ;
		}

		static string GetSafeString(string WhatToSay)
		{
			return WhatToSay.Replace("'", "''" ) ; 
		}
		
		static public void TellSomethingBeforeGotoLocation(System.Web.UI.Page page, string WhatToSay, string NextURL )
		{
			string scriptString = string.Format("alert('{0}');window.location.href='{1}';", GetSafeString(WhatToSay), NextURL) ;
			scriptString = FormatClientScriptBlock( scriptString ) ;
			page.RegisterStartupScript(Guid.NewGuid().ToString(), scriptString) ;
		}

		static public void TellCompletedAndPageBack( System.Web.UI.Page page, string WhatToSay)
		{
			string scriptString = FormatClientScriptBlock(string.Format("alert('{0}');history.back();", GetSafeString(WhatToSay))) ;
			page.RegisterStartupScript(Guid.NewGuid().ToString(), scriptString) ;
		}

		static public void TellCompletedAndBack( System.Web.UI.Page page, string WhatToSay, string BackToURL )
		{
			HttpRequest Request = HttpContext.Current.Request ; 

			if ( BackToURL != null && BackToURL != "" )
				TellSomethingBeforeGotoLocation(page, WhatToSay, BackToURL) ;
			else if (Request.UrlReferrer != null &&  Request.UrlReferrer.PathAndQuery != "")
				TellSomethingBeforeGotoLocation(page, WhatToSay, Request.UrlReferrer.PathAndQuery) ;
			else 
				TellCompletedAndPageBack(page, WhatToSay) ;
		}
	
	
		/// <summary>
		/// Fill list control with day of month number
		/// </summary>
		/// <param name="list">List control</param>
		static public void FillWithDays(System.Web.UI.WebControls.DropDownList list)
		{
			for ( int i = 1 ; i <= 31 ; ++i )
				list.Items.Add( i.ToString() ) ;
		}

		static public void FillWithMonthNumber(System.Web.UI.WebControls.DropDownList list)
		{
			for ( int i = 1 ; i <= 12 ; ++i )
				list.Items.Add( i.ToString() ) ;
		}

		static public void FillWithPossibleBirthYear(System.Web.UI.WebControls.DropDownList list)
		{
			int startYY = 1850 ;
			for ( int i = startYY ; i <= DateTime.Today.Year ; ++i )
				list.Items.Add( string.Format("{0:D}", i ) ) ;
		}

		static public void ForcePageRefresh(System.Web.UI.Page page)
		{
			// Preventing a Document From Being Cached
			page.Response.AppendHeader("Expires", "0") ;
		}

		static public string AppendLangAndSiteToQueryString(string PathAndQuery, string Lang, string Site)
		{
			if ( PathAndQuery.IndexOf("?") > -1 )
				return string.Format("{0}&Lang={1}&Site={2}", PathAndQuery, Lang, Site) ;
			else
				return string.Format("{0}?Lang={1}&Site={2}", PathAndQuery, Lang, Site) ;
		}

		static public void SetLabelMessage(System.Web.UI.WebControls.Label Msg, string Message)
		{
			string SaveMsgClass = Msg.CssClass ;
			Msg.CssClass = "information" ; 
			Msg.Text = Message ;
			Msg.CssClass = SaveMsgClass   ;
		}

		static public string FormatClientScriptBlock(string ScriptStatementBlock)
		{
			return string.Format("\n<script language=\"javascript\" type=\"text/javascript\">\n<!-- \n {0} \n // -->\n</script>\n", ScriptStatementBlock) ;
		}

		 static public void SetFocus(System.Web.UI.Control controlToFocus )
		 {
			string scriptFunction = string.Format("document.getElementById('{0}').focus();", controlToFocus.ClientID) ;
			if (!controlToFocus.Page.IsStartupScriptRegistered("__focus"))
				controlToFocus.Page.RegisterStartupScript("__focus", FormatClientScriptBlock(scriptFunction) ) ;
		 }

	
//		static  public void BuildPageIndexBar(System.Web.UI.Page page, System.Collections.ICollection CollectionOfItems, System.Web.UI.WebControls.WebControl panel)
//		{
//			ISupportCurrentPageIndex PageSupportCurrentPageIndex = page as ISupportCurrentPageIndex ;
//			if (PageSupportCurrentPageIndex == null)
//				throw new ArgumentException("Page not implements ISupportCurrentPageIndex interface!", "page") ;
//
//			int TotalPages = CollectionOfItems.Count / PageSupportCurrentPageIndex.ListPageSize ;
//			if (TotalPages * PageSupportCurrentPageIndex.ListPageSize < CollectionOfItems.Count)
//				++TotalPages ; 
//				
//			for(int pageIndex = 0; pageIndex < TotalPages; ++pageIndex)
//			{
//				if ( pageIndex == PageSupportCurrentPageIndex.CurrentPageIndex )
//				{
//					
//					HtmlGenericControl PageControl = new HtmlGenericControl("span") ;
//					PageControl.InnerHtml = string.Format("{0}", pageIndex+1)  ;
//
//					PageControl.Style["Width"] = "10" ;
//
//					panel.Controls.Add(PageControl) ;
//				}
//				else
//				{
//					HyperLink PageControl = new HyperLink();
//					string NewQueryString = AddQueryParameter(page.Request, "PageIndex", pageIndex.ToString()) ;
//					PageControl.NavigateUrl = page.Request.Path + "?" + NewQueryString ;
//					PageControl.Text = string.Format("{0}", pageIndex+1) ;
//					PageControl.ToolTip = string.Format("Go to page {0}", pageIndex+1) ;
//
//					PageControl.Style["Width"] = "10" ;
//
//					panel.Controls.Add(PageControl) ;
//				}
//				
//			}
//		}

		static public string AddQueryParameter(HttpRequest Request, string ParamName, string ParamValue)
		{
			string NewQueryString = string.Format("{0}={1}&", ParamName, ParamValue) ;
					
			foreach(string key in Request.QueryString.Keys)
			{
				if (key.ToLower() != ParamName.ToLower()) 
					NewQueryString += string.Format("{0}={1}&", key, Request.QueryString[key]) ;
			}

			NewQueryString = NewQueryString.TrimEnd('&') ;

			return NewQueryString ;
		}

		static public string AddQueryParameter(string QueryString, string ParamName, string ParamValue)
		{
			string[] QueryArray = QueryString.TrimStart('?').TrimEnd('&').Split('&') ;
			
			string NewQueryString = string.Format("{0}={1}&", ParamName, ParamValue) ;
					
			foreach(string KeyValuePair in QueryArray)
			{
				string [] ItemPair = KeyValuePair.Split('=') ;
				if ( ItemPair.Length==2 && ItemPair[0].ToLower() != ParamName.ToLower())
				{
					NewQueryString += string.Format("{0}={1}&", ItemPair[0], ItemPair[1]) ;
				}
			}
			return NewQueryString.TrimEnd('&') ;
		}

		static public void SetSelectedItem(System.Web.UI.WebControls.ListControl list, string PreferredItemValue)
		{
			if ( PreferredItemValue != null)
			{
				foreach(ListItem listItem in list.Items)
				{
					if (listItem.Value.ToLower() == PreferredItemValue.ToLower() )
					{
						listItem.Selected = true ;
						break ;
					}
				}
			}
		}

		public static void AddPageLabel(System.Web.UI.WebControls.DataGridItem Item)
		{
			if ( Item.ItemType ==  ListItemType.Pager ) 
			{
				Label LabelPage =  new Label();
				LabelPage.Text = "PAGE " ;
				LabelPage.CssClass = "PagerPageLabel" ;
				Item.Controls[0].Controls.AddAt(0, LabelPage) ;
			}
		}

	}


}
