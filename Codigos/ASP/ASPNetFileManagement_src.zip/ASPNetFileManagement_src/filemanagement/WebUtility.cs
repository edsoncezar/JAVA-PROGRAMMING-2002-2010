using System;
using System.Web;
using Utility ;

namespace Utility.Web
{
	/// <summary>
	/// Summary description for WebUtility.
	/// </summary>
	public class WebUtility
	{
		public static HttpContext Ctx
		{
			get { return HttpContext.Current ; }
		}

		public static string EncodedMapPath(string PathIn)
		{
			return Ctx.Server.UrlEncode(Ctx.Server.MapPath(PathIn)) ;
		}

		public static string FolderImagePath
		{
			get { return WebUtility.EncodedMapPath("images/folder.gif") ; }
		}

		public static string DocumentImagePath
		{
			get { return WebUtility.EncodedMapPath("images/document.gif") ; }
		}

	}
}
