using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO ; 
using System.Configuration ;
using Utility.Web ;

namespace filemanagement
{
	/// <summary>
	/// Summary description for WebFolder.
	/// </summary>
	public class WebFolder : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Label LabelMsg;
		protected System.Web.UI.WebControls.HyperLink HyperLinkHome;
		protected System.Web.UI.WebControls.HyperLink HyperLinkLevelUp;
		protected UCMainMenu UCMainMenu1 ;
		protected System.Web.UI.WebControls.HyperLink HyperLinkImage;
		protected System.Web.UI.HtmlControls.HtmlInputFile fileInput;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidatorFile;
		protected System.Web.UI.HtmlControls.HtmlInputButton buttonFileUpload;
		protected System.Web.UI.WebControls.Button ButtonCopy;
		protected System.Web.UI.HtmlControls.HtmlInputButton ButtonRefresh ;
		protected System.Web.UI.WebControls.HyperLink HyperLinkThumbnail;
		
		private bool _RefereshCache ;
		private bool RefereshCache 
		{
			set { _RefereshCache = value ; }
			get { return _RefereshCache ; }
		}

		private string RootPath
		{
			get 
			{ 
				if ( ViewState["RootPath"] == null )
					return ConfigurationSettings.AppSettings["Root"] ;
				else
					return ViewState["RootPath"] as string ;
			}

			set 
			{
				ViewState["RootPath"] = value ;
			}
		}

		protected bool HasEmailService
		{
			get 
			{
				if ( ConfigurationSettings.AppSettings["HasEmailService"] != null 
					&& ConfigurationSettings.AppSettings["HasEmailService"].ToLower() == "true" ) 
					return true ;
				else
					return false ;
			}
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			LabelMsg.Text = string.Empty ;

			if (!IsPostBack)
			{
				this.Form1.Attributes["onsubmit"] = "return __checkInputScript();" ; 
				this.RootPath = Request["path"] ;
				DataGrid1.Caption = string.Format("Path : {0}", this.RootPath) ;
				this.BindGrid() ;

				// Hide UP-1-Level link if it is configured root
				if ( string.Compare(this.RootPath, ConfigurationSettings.AppSettings["Root"], true) != 0 )
					UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkLevelUp).NavigateUrl = this.Request.Path + "?path=" + Server.UrlEncode(Directory.GetParent(this.RootPath).FullName) ;
				else
					UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkLevelUp).Visible = false ;

				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkHome).NavigateUrl =  this.Request.Path ;
				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperlinkThumbnail).NavigateUrl = "WebFolderTNView.aspx?" + this.Request.QueryString ;

				if ( Request["Error"] != null )
					LabelMsg.Text = Request["Error"] ;

				this.buttonFileUpload.Attributes["onclick"] = "return buttonFileUpload_onclick();" ; 
			}

			// Need to render each time including postback!
			this.RenderClientScript() ;
		}

		private void RenderClientScript()
		{
			string clientEventHandlersJS = WebUI.FormatClientScriptBlock(
				"function buttonFileUpload_onclick() {\n"
					+ "var filename = document.getElementById('fileInput').value ;\n"
					+ "rg = /^\\s*$/ig ;\n" 
					+ "if (filename.length==0 || filename.match(rg)!=null)\n"
					+ "{\n"
					+ "	alert('No filename specified!') ;\n"
					+ 	"return false ;\n"
					+ "}\n"
					+ "}\n") ;

			if (!this.IsClientScriptBlockRegistered("clientEventHandlersJS"))
				this.RegisterClientScriptBlock("clientEventHandlersJS", clientEventHandlersJS) ;
		}

		private void BindGrid()
		{
			try
			{
				DataGrid1.DataSource = CacheManager.GetFileItems(this.RootPath, this.RefereshCache) ;
				DataGrid1.DataBind() ;
			}
			catch ( UnauthorizedAccessException )
			{
				this.LabelMsg.Text = "Sorry! You are not allowed to access this folder." ;
				return ;
			}
		}

		protected string FormatSize(object file)
		{
			FileSystemInfoExtend FileSystemInfoEx = file as FileSystemInfoExtend ;
			if ( FileSystemInfoEx == null )
				return "" ;

			if ( !FileSystemInfoEx.IsDirectory )
				return string.Format("{0:N0} KB", (FileSystemInfoEx.Size / 1024.0f)) ; 
				
			else
				return string.Empty ;
		}

		protected string FormatLink(object file)
		{
			FileSystemInfoExtend FileSystemInfoEx = file as FileSystemInfoExtend ;
			if ( FileSystemInfoEx == null )
				return "" ;

			string FileFullName = Server.UrlEncode(FileSystemInfoEx.FullName) ;

			if ( FileSystemInfoEx.IsDirectory )
				return string.Format("{0}?path={1}", this.Request.Path, FileFullName ) ;
			else 
			{
				return string.Format("{0}?file={1}", "FileSender.aspx", FileFullName ) ;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DataGrid1_PageIndexChanged);
			this.ButtonCopy.Click += new System.EventHandler(this.ButtonCopy_Click);
			this.buttonFileUpload.ServerClick += new System.EventHandler(this.buttonFileUpload_ServerClick);
			this.ButtonRefresh.ServerClick += new System.EventHandler(this.ButtonRefresh_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void DataGrid1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			this.SaveSelectedItemKey() ;

			this.DataGrid1.CurrentPageIndex = e.NewPageIndex ;
			this.BindGrid() ;

			this.SetSelectedItem() ;
		}

		private void buttonFileUpload_ServerClick(object sender, System.EventArgs e)
		{
			for(int i = 0; i < Request.Files.Count ; ++i)
			{
				HttpPostedFile file = Request.Files[i] as HttpPostedFile;
				string path = string.Format(@"{0}\{1}", this.RootPath.TrimEnd('\\'), Path.GetFileName(file.FileName)) ;
				file.SaveAs(path) ; 
			}

			ButtonRefresh_ServerClick(this, EventArgs.Empty) ;

		}

		private void ButtonRefresh_ServerClick(object sender, System.EventArgs e)
		{
			// Refresh list
			this.RefereshCache = true ;
			this.BindGrid() ;
		}

		private void ButtonCopy_Click(object sender, System.EventArgs e)
		{
			this.SaveSelectedItemKey() ;
			ArrayList FileItemPaths = this.SelectedKey ;

			if (FileItemPaths.Count > 0)
			{
				Context.Items["SourceItems"] = FileItemPaths ; 
				Server.Transfer("FileCopy.aspx") ;
			}
		}

		private void SetSelectedItem()
		{
			if (this.SelectedKey != null)
			{
				ArrayList arrayList =  this.SelectedKey  ;

				foreach(DataGridItem listItem in this.DataGrid1.Items)
				{
					if (listItem.ItemType == ListItemType.AlternatingItem
						|| listItem.ItemType == ListItemType.Item)
					{
						CheckBox selected = listItem.FindControl("Select") as CheckBox ;
						string keyItem = DataGrid1.DataKeys[listItem.ItemIndex] as string ;
						if (!selected.Checked && arrayList.Contains(keyItem))
							selected.Checked = true ;
					}
				}
			}
		}

		private void SaveSelectedItemKey()
		{
			ArrayList arrayList =  this.SelectedKey  ;

			foreach(DataGridItem listItem in this.DataGrid1.Items)
			{
				if (listItem.ItemType == ListItemType.AlternatingItem
					|| listItem.ItemType == ListItemType.Item)
				{
					CheckBox selected = listItem.FindControl("Select") as CheckBox ;
					
					string keyItem = DataGrid1.DataKeys[listItem.ItemIndex] as string ;

					if (selected.Checked && !arrayList.Contains(keyItem))
						arrayList.Add(keyItem) ;

					if (!selected.Checked && arrayList.Contains(keyItem) )
						arrayList.Remove(keyItem) ;
				}
			}
			this.SelectedKey = arrayList ;
		}

		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			WebUI.AddPageLabel(e.Item) ;
		}

		private ArrayList SelectedKey
		{
			set 
			{
				ViewState["SelectedKey"] = value ;
			}

			get
			{
				if ( ViewState["SelectedKey"] == null )
					return new ArrayList() ;
				else
					return ViewState["SelectedKey"] as ArrayList ;
			}
		}
	}
}
