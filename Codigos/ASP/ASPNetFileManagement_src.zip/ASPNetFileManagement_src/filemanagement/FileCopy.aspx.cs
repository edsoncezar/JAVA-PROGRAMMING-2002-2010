using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration ;
using System.IO ;
using Utility.Web ;

namespace filemanagement
{
	/// <summary>
	/// Summary description for FileCopy.
	/// </summary>
	public class FileCopy : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ListBox ListBoxSourceItems;
		protected UCMainMenu UCMainMenu1 ;
		protected System.Web.UI.WebControls.Button ButtonUp1Level;
		protected System.Web.UI.WebControls.Label LabelMsg;
		protected System.Web.UI.WebControls.Button ButtonHome;
		protected System.Web.UI.WebControls.Button ButtonCancel;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		private string RootPath
		{
			get 
			{ 
				if ( ViewState["RootPath"] == null )
					return ConfigurationSettings.AppSettings["Root"] ;
				else
					return ViewState["RootPath"] as string ;
			}
			set 
			{
				ViewState["RootPath"] = value ;
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				ArrayList FileItemPaths = Context.Items["SourceItems"] as  ArrayList ;

				if (FileItemPaths == null || FileItemPaths.Count==0)
					throw new ArgumentNullException("FileItemPaths", "FileItemPaths NOT specified in Context.Items") ;
				
				foreach(string FileItemPath in FileItemPaths)
					this.ListBoxSourceItems.Items.Add(FileItemPath) ;

				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperlinkSearch).Visible = false ;
				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperlinkListView).Visible = false ;
				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperlinkThumbnail).Visible = false ;
				UCMainMenu1.GetMenuItem(UCMainMenu.MainMenuItems.HyperLinkLevelUp).Visible = false ;

				this.RootPath = Request["path"] ; 
				this.BindFolderList() ; 

			}
		}

		private void BindFolderList()
		{
			try
			{
				FileSystemInfosExtend  folders = CacheManager.GetFileItems(this.RootPath, false).Folders ;
				this.DataGrid1.DataSource = folders ;
				this.DataGrid1.DataBind() ;
			}
			catch ( UnauthorizedAccessException )
			{
				this.LabelMsg.Text = "Sorry! You are not allowed to access this folder." ;
				return ;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataGrid1.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DataGrid1_ItemCommand);
			this.DataGrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemDataBound);
			this.DataGrid1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			this.ButtonHome.Click += new System.EventHandler(this.ButtonHome_Click);
			this.ButtonUp1Level.Click += new System.EventHandler(this.ButtonUp1Level_Click);
			this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ButtonHome_Click(object sender, System.EventArgs e)
		{
			this.RootPath = ConfigurationSettings.AppSettings["Root"] ; 
			this.BindFolderList() ; 
		}

		private void ButtonUp1Level_Click(object sender, System.EventArgs e)
		{
			if ( this.RootPath != ConfigurationSettings.AppSettings["Root"] )
			{
				this.RootPath = Directory.GetParent(this.RootPath).FullName ;
				this.BindFolderList() ; 
			}
		}

		private void DataGrid1_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if ( e.CommandName == "Subfolder" )
			{
				string PathSelected = DataGrid1.DataKeys[e.Item.ItemIndex] as string ;
				if ( PathSelected != null )
				{
					this.RootPath = PathSelected ;
					this.BindFolderList() ; 
				}
			}
		}

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int FileCount = 0 ;
			string PathSelected = DataGrid1.DataKeys[DataGrid1.SelectedIndex] as string;
			string PathSource ;
			PathSource = Path.GetDirectoryName(this.ListBoxSourceItems.Items[0].Value) ;
			if ( PathSelected != null )
			{
				foreach(ListItem SourceFileItem in this.ListBoxSourceItems.Items)
					FileCount += this.CopyFile(SourceFileItem.Value, PathSelected) ;

				string TellUserSomething = string.Format("{0} file(s) copied from {1} to {2}" 
					, FileCount
					, PathSource.Replace(@"\", @"\\")
					, PathSelected.Replace(@"\", @"\\")) ;

				WebUI.TellCompletedAndBack(this
					, TellUserSomething
					, "WebFolder.aspx?path=" + Server.UrlPathEncode(PathSource.Replace(@"\", @"\\"))) ;
			}
		}

		private int CopyFile(string SourceFile, string DestinationPath)
		{
			int FileCount = 0 ;
			// Is SourceFile file or folder(directory) name?
			if (File.Exists(SourceFile))
			{
				File.Copy(SourceFile
					, DestinationPath 
					+ Path.DirectorySeparatorChar 
					+ Path.GetFileName(SourceFile)
					, true) ;
				++FileCount ;
			}
			else if (Directory.Exists(SourceFile))
			{
				// Create the detsination sub-folder(subdirectory) first
				DirectoryInfo directoryInfo  = new DirectoryInfo(SourceFile) ;
				string DestinationSubDirectory = DestinationPath + Path.DirectorySeparatorChar +  directoryInfo.Name ;
				if (!Directory.Exists(DestinationSubDirectory))
					Directory.CreateDirectory(DestinationSubDirectory) ;

				// Copy all items under this folder(directory) to detsination sub-folder(subdirectory)
				FileSystemInfo[] fileinfos = directoryInfo.GetFileSystemInfos() ;
				foreach(FileSystemInfo fileinfo in fileinfos)
				{
					FileCount += this.CopyFile(fileinfo.FullName, DestinationSubDirectory) ;
				}
			}
			else
				throw new System.IO.FileNotFoundException("File not found!", SourceFile) ;

			return FileCount ;
		}

		private void ButtonCancel_Click(object sender, System.EventArgs e)
		{
			string PathSource ;
			PathSource = Path.GetDirectoryName(this.ListBoxSourceItems.Items[0].Value) ;
			Response.Redirect("WebFolder.aspx?path=" + Server.UrlPathEncode(PathSource.Replace(@"\", @"\\"))) ;

		}

		private void DataGrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				LinkButton ButtonSelect = e.Item.Controls[1].Controls[0] as LinkButton ;
				if (ButtonSelect != null && ButtonSelect.CommandName == "Select")
				{
					string DestPath = ((FileSystemInfoExtend)e.Item.DataItem).FullName  ;
					WebUI.ConfirmBeforePostForm(ButtonSelect
						, string.Format("Sure to copy file(s) to {0}?", DestPath.Replace(@"\", @"\\")) ) ;
				}
			}		
		}
	}
}
