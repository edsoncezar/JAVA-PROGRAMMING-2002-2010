namespace filemanagement
{
	using System;
	using System.Drawing;
	using System.Drawing.Imaging;
	using System.Web;
	using System.IO ;

	/// <summary>
	///		Summary description for UCShowItem.
	/// </summary>
	public class UCShowItem : System.Web.UI.UserControl
	{

		private void Page_Load(object sender, System.EventArgs e)
		{
			string FileFullName = string.Format("{0}", Request["FileFullName"] ) ;

			if ( FileFullName != ""  )
			{
				
				Bitmap bmp  ;

				ImageFormat ImgTypeFormat = ImageFormat.Jpeg ;  // Final render as format
				Response.ContentType = string.Format("image/{0}", ImgTypeFormat) ;

				try 
				{
					bmp = new Bitmap(FileFullName) ;
				}
				catch
				{
					// NOT a valid image file!
					bmp = new Bitmap(50, 50) ;
					using (Graphics g = Graphics.FromImage(bmp))
					{
						SolidBrush drawBrush = new SolidBrush(Color.White);
						g.FillRectangle(drawBrush, 0, 0, bmp.Width, bmp.Height) ;
						drawBrush.Dispose() ; 
						
						drawBrush = new SolidBrush(Color.Gold);
						Font font = new Font("Arial", 30, GraphicsUnit.Pixel) ;
						g.DrawString("?",  font, drawBrush, 10, 10) ;
						font.Dispose() ;
						drawBrush.Dispose() ; 
					}
				}
				
				if (string.Format("{0}", Request["Thumbnail"]).ToUpper()=="Y")
				{
					
					System.Drawing.Image.GetThumbnailImageAbort myCallback =
						new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);

					double scale ;
					double TNSize = 120d ;
					if ( Request["TNSize"] != null ) 
					{
						try 
						{
							TNSize = int.Parse((string) Request["TNSize"]) ;
						}
						catch
						{
							TNSize = 120 ;
						}
					}

					if ( TNSize >= bmp.Width && TNSize >= bmp.Height ) 
					{
						// Too small to scale!
						bmp.Save(Response.OutputStream, ImgTypeFormat) ;
						goto Exit_Cleanup ;
					}
					else
					{
						if ( bmp.Width > bmp.Height ) 
							scale = bmp.Width==0 ? 0 : TNSize / bmp.Width ;
						else
							scale = bmp.Height==0 ? 0 : TNSize / bmp.Height ;
					}

					int width = (int)(scale*bmp.Width) ;
					int height= (int)(scale*bmp.Height);
					width=width==0?1:width;
					height=height==0?1:height;

					System.Drawing.Image imgThumbnail ;
					if ( TNSize <= 120 )
						imgThumbnail = bmp.GetThumbnailImage(width, height, myCallback, IntPtr.Zero) ;
					else 
					{
						// Better to scale original image when larger image is needed
						imgThumbnail = new Bitmap(width, height); 
						Graphics g = Graphics.FromImage(imgThumbnail);

						g.DrawImage(bmp, new Rectangle(0,0,width,height)
							, 0, 0, bmp.Width, bmp.Height
							, GraphicsUnit.Pixel ) ;
						g.Dispose() ;
					}

					imgThumbnail.Save(Response.OutputStream, ImgTypeFormat) ;
					imgThumbnail.Dispose() ;
				}
				else
					// Full size image
					bmp.Save(Response.OutputStream, ImgTypeFormat) ;

			Exit_Cleanup:
				bmp.Dispose() ; 
			}			
		}

		public bool ThumbnailCallback()
		{
			return false;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
