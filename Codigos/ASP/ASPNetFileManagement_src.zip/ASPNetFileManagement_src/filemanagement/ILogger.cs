using System;

namespace Utility
{
	/// <summary>
	/// Summary description for ILogger.
	/// </summary>
	public interface ILogger
	{
		void Write(string MessageLine) ;
	}
}
