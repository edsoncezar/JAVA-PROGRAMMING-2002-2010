using System;
using System.IO;
using System.Collections ;
using System.Threading ;

namespace filemanagement
{
	/// <summary>
	/// Summary description for FileInfosExtend.
	/// </summary>
	public class FileSystemInfosExtend : ICollection	
	{
		private FileSystemInfoExtend[] _files ;
		
		public FileSystemInfosExtend(FileSystemInfo[] files)
		{
			lock(SyncRoot)
			{
				_files = new FileSystemInfoExtend[files.Length] ;
				for (int i = 0 ; i < files.Length ; i++)
					_files[i] = new FileSystemInfoExtend(files[i]) ;
			}
		}

		private FileSystemInfosExtend(FileSystemInfoExtend[] files)
		{
			lock(SyncRoot)
			{
				_files = new FileSystemInfoExtend[files.Length] ;
				files.CopyTo(this._files, 0) ;
			}
		}

		public FileSystemInfosExtend Folders
		{
			get 
			{
				ArrayList folderAL = new ArrayList() ;
				foreach(FileSystemInfoExtend fileItem in this._files)
				{
					if (fileItem.IsDirectory)
						folderAL.Add(fileItem) ;
				}

				FileSystemInfoExtend[] folderArray = (FileSystemInfoExtend[])folderAL.ToArray(typeof(FileSystemInfoExtend)) ;

				FileSystemInfosExtend folders =  new FileSystemInfosExtend(folderArray ) ;

				return folders ;
			}
		}


		#region IEnumerable Members
		public IEnumerator GetEnumerator()
		{
			lock(SyncRoot)
			{
				return _files.GetEnumerator() ;
			}
		}
		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				return true ;
			}
		}

		public int Count
		{
			get
			{
				lock (SyncRoot)
				{
					return _files.Length ;
				}
			}
		}

		public void CopyTo(Array array, int index)
		{
			lock (SyncRoot)
			{
				_files.CopyTo(array, index) ;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this;
			}
		}

		#endregion
	}

	public class FileSystemInfoExtend : SimpleFileInfoBase
	{	
		private FileSystemInfo _file ;

		public FileSystemInfoExtend(FileSystemInfo	file)
		{
			_file = file ; 
		}

		override public string Name 
		{
			get { return _file.Name ; }
		}

		override public string FullName
		{
			get { return _file.FullName ; } 
		}

		public bool IsDirectory
		{
			get { return (_file.Attributes & FileAttributes.Directory)==FileAttributes.Directory ; }
		}

		public bool HasSubdirectory
		{
			get
			{
				return this.IsDirectory &&
					Directory.GetDirectories(this.FullName).Length > 0 ; 
			}
		}

		public string Type
		{
			get { return this.IsDirectory?"Dir":"File" ; }
		}

		override public long Size
		{
			get 
			{
				if ( this.IsDirectory )
					return 0L ;
				else
					return ((FileInfo)_file).Length  ;
			}
		}

		override public DateTime LastWriteTime
		{
			get { return _file.LastWriteTime ; }
		}

	}

	abstract public class SimpleFileInfoBase
	{
		public abstract string Name { get ; }
		public abstract string FullName { get ; }
		public abstract DateTime LastWriteTime { get ; } 
		public abstract long Size { get ; }
	}
}
