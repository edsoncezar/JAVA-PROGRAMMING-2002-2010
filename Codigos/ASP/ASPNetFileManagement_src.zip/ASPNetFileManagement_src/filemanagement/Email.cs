using System;
using System.Text ;
using System.Web.Mail ; 
using System.Threading ;
using System.Configuration ;
using Utility ;

namespace Utility.Web
{
	/// <summary>
	/// Email - SMTP email wrapper.
	/// </summary>
	public class Email
	{
		public enum BodyFormatType { Html, Text }

		private string _mailServer ;
		private string _authUser ;
		private string _authPassword ;
		private Encoding _bodyEncoding ; 
		private BodyFormatType _bodyFormat ;
		private MailPriority _priority ; 
		private string _attach = ""  ; 
		private string _UrlContentBase = "" ; 
		
		private ILogger _Logger = null ;

		public Email()
		{
			this._mailServer = "localhost";
			this._bodyEncoding = Encoding.UTF8 ; 
			this._bodyFormat = BodyFormatType.Html ; 
			this._priority = MailPriority.Normal ; 
		}
		
		public void Send(string sTo, string sFrom, string sSubject, string sBody, string sCc, string sBcc)
		{
			this.Send(sTo, sFrom, sSubject, sBody, sCc, sBcc, true) ;
		}

		public void Send(string sTo, string sFrom, string sSubject, string sBody, string sCc, string sBcc, bool SendByThreadInPool)
		{
			MailMessage mailMessage = new MailMessage();

			mailMessage.To =  sTo ; 
			mailMessage.From =  sFrom ;
			mailMessage.Subject = sSubject ; 
			mailMessage.Body =  sBody ; 
			mailMessage.UrlContentBase = _UrlContentBase ; 

			mailMessage.Priority = this._priority ; 
			mailMessage.BodyEncoding = this._bodyEncoding ; 

			if (_bodyFormat == BodyFormatType.Html  )
				mailMessage.BodyFormat = MailFormat.Html;
			else			
				mailMessage.BodyFormat = MailFormat.Text;
         
			if (_attach != "")
			{
				char[] delim = new char[] {','};
				foreach (string sSubstr in _attach.Split(delim))
				{
					MailAttachment MyAttachment = new MailAttachment(sSubstr);
					mailMessage.Attachments.Add(MyAttachment);
				}
			}

			if ( _authUser != null && _authUser != "" )
			{
				mailMessage.Fields[@"http://schemas.microsoft.com/cdo/configuration/sendusername"] = _authUser ; 
				mailMessage.Fields[@"http://schemas.microsoft.com/cdo/configuration/sendpassword"] =  _authPassword ; 
				mailMessage.Fields[@"http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"] = 1  ; // Use basic (clear-text) authentication
			}	
			
			SmtpMail.SmtpServer = _mailServer ; 

			if (!SendByThreadInPool) 
			{
				SmtpMail.Send( mailMessage ) ;

				if (this._Logger != null) 
				{
					string messageInfo = string.Format("From:{0}\tTo:{1}\tSubject:{2}", mailMessage.From, mailMessage.To, mailMessage.Subject) ;
					this._Logger.Write(messageInfo + " completed successfully.") ;
				}
			}
			else
			{
				// Use Thread pool to give immediate UI response
				if (!ThreadPool.QueueUserWorkItem(new WaitCallback(Start), mailMessage))
					throw new  ApplicationException("Cannot queue task to send email.") ;
			}
		}

		private void Start(object mailMessage)
		{
			MailMessage message = mailMessage as MailMessage ; 
			if (message != null)
			{
				string messageInfo = string.Format("From:{0}\tTo:{1}\tSubject:{2}", message.From, message.To, message.Subject) ;
				try
				{
					SmtpMail.Send( message  );
					
					if (this._Logger != null) 
						this._Logger.Write(messageInfo + " completed successfully.") ;
				}
				catch(Exception excpt)
				{
					if (this._Logger != null) 
					{
						this._Logger.Write(messageInfo + " failed.") ;
						this._Logger.Write(excpt.ToString()) ;
					}
					else
						// Re-throw the exception ;
						throw ;
				}
			}
		}

		public ILogger Logger
		{
			get 
			{
				return this._Logger ; 
			}
			set 
			{
				this._Logger = value ;
			}
		}

		public string SMTPServer		
		{
			get { return _mailServer ; } 
			set 
			{ 
				if ( _mailServer != null && _mailServer != "" )
					_mailServer = value ; 
			} 
		}

		public string SMTPUser
		{
			set 
			{ 
				_authUser = value ; 
			} 
			get { return _authUser  ; } 
		}

		public string SMTPPassword
		{
			set { _authPassword = value ; } 
		}

		public string Attachment
		{
			set { _attach = value ; } 
		}

		public MailPriority Priority 
		{
			set { _priority = value ; } 
		}

		public Encoding BodyEncoding 
		{
			set { _bodyEncoding = value ; }
		}

		public BodyFormatType BodyFormat 
		{
			set { _bodyFormat = value ; }
			get { return _bodyFormat ; }
		}

		public string UrlContentBase
		{
			set { _UrlContentBase = value ;}
		}
	}	 
}
