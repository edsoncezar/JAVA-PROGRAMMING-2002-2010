using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace filemanagement
{
	/// <summary>
	/// Summary description for ShowFileIcon.
	/// </summary>
	public class ShowFileIcon : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			string FileFullName = string.Format("{0}", Request["FileFullName"] ) ;
			string Size = string.Format("{0}", Request["Size"] ) ;
			
			IconHandler.IconSize IconSizeUsed = 
				Size.ToLower()=="large" || Size == "" ? 
				IconHandler.IconSize.Large 
				: IconHandler.IconSize.Small ;

			Response.ClearHeaders() ;
			Response.ClearContent() ;

			System.Drawing.Icon icon ;
			System.IO.FileInfo fileinfo = new System.IO.FileInfo(FileFullName) ; 

			// icon = IconHandler.IconHandler.AssociatedIconFromFile(fileinfo.FullName) ;
			icon = IconHandler.IconHandler.GetAssociatedIcon(fileinfo.FullName, IconSizeUsed) ;
			if ( icon != null )
			{
				Response.ContentType = "image/x-icon" ;
				string TempFileName = fileinfo.Extension != ""?fileinfo.Name.Replace(fileinfo.Extension,".ico"):fileinfo.Name+".ico" ;
				Response.AppendHeader("Content-Disposition", string.Format("inline;filename=\"{0}\"", TempFileName)) ;
				icon.Save(Response.OutputStream) ;			
				icon.Dispose() ;
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
