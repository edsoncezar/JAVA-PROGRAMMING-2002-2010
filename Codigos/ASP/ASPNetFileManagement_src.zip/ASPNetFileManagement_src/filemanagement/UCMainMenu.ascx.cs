namespace filemanagement
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for UCMainMenu.
	/// </summary>
	public class UCMainMenu : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.HyperLink HyperLinkHome;
		protected System.Web.UI.WebControls.HyperLink HyperlinkSearch;
		protected System.Web.UI.WebControls.HyperLink HyperlinkListView;
		protected System.Web.UI.WebControls.HyperLink HyperlinkThumbnail;
		protected System.Web.UI.WebControls.Label LabelTextWelcome;
		protected System.Web.UI.WebControls.HyperLink HyperLinkLevelUp;

		public enum MainMenuItems { HyperLinkHome, HyperlinkSearch, HyperLinkLevelUp, HyperlinkListView, HyperlinkThumbnail } 

		public HyperLink GetMenuItem(MainMenuItems MenuItemId)
		{
			return this.FindControl( Enum.GetName(typeof(MainMenuItems), MenuItemId)) as HyperLink ;
		}

		public string WelcomeText
		{
			set { ViewState["WelComeText"] = value ; }
			get { 
				string welcome = string.Format("{0}", ViewState["WelComeText"]) ;
				if ( welcome == string.Empty ) 
				{
					string WhoRU = System.Security.Principal.WindowsIdentity.GetCurrent().Name; 
					if ( WhoRU.LastIndexOf(@"\") > -1 ) 
						WhoRU = WhoRU.Substring( WhoRU.LastIndexOf(@"\") + 1) ;

					welcome  = string.Format("Welcome, {0}", WhoRU) ; 
				}
				return welcome ;
					  
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
				LabelTextWelcome.Text = this.WelcomeText ;
		}

		public void HideMenuItem(MainMenuItems MenuItemId)
		{
			if(this.GetMenuItem(MenuItemId) != null)
				this.GetMenuItem(MenuItemId).Visible = false ;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
