using System;
using System.Drawing;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Text ;

namespace IconHandler
{
	public enum IconSize : uint
	{
		Small = 0x0, //16x16
		Large = 0x1  //32x32
	}

	public class IconHandler
	{
		public static IntPtr GetAssociatedIconHandle(string Filename, IconSize size) // Filename - the file name to get icon from
		{
			IntPtr hImgSmall; //the handle to the system image list
			IntPtr hImgLarge; //the handle to the system image list
			SHFILEINFO shinfo = new SHFILEINFO();

			if ( size == IconSize.Small )
				hImgSmall = Win32.SHGetFileInfo(Filename, 0
					, ref shinfo,(uint)Marshal.SizeOf(shinfo)
					, Win32.SHGFI_ICON |Win32.SHGFI_SMALLICON);
			else
				hImgLarge = Win32.SHGetFileInfo(Filename, 0
					, ref shinfo, (uint)Marshal.SizeOf(shinfo)
					, Win32.SHGFI_ICON | Win32.SHGFI_LARGEICON);

			return shinfo.hIcon ;
		}
		
		public static Icon GetAssociatedIcon(string Filename, IconSize size) // Filename - the file name to get icon from
		{
			return Icon.FromHandle(GetAssociatedIconHandle(Filename, size)) ;
		}

	}

	[StructLayout(LayoutKind.Sequential)]
	public struct SHFILEINFO
	{
		public IntPtr hIcon;
		public IntPtr iIcon;
		public uint dwAttributes;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
		public string szDisplayName;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
		public string szTypeName;
	};

	internal class Win32
	{
		public const uint SHGFI_ICON = 0x100;
		public const uint SHGFI_LARGEICON = 0x0; // 'Large icon
		public const uint SHGFI_SMALLICON = 0x1; // 'Small icon

		[DllImport("shell32.dll", CharSet=CharSet.Unicode)]
		public static extern IntPtr SHGetFileInfo(
			[MarshalAs(UnmanagedType.LPWStr)]  // Use wide chars 
			string pszPath
			, uint dwFileAttributes
			, ref SHFILEINFO psfi
			, uint cbSizeFileInfo
			, uint uFlags);
	}

}