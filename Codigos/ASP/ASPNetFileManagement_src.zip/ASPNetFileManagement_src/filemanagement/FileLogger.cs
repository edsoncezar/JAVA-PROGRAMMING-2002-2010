using System ;

namespace Utility
{
	public class FileLogger:ILogger
	{
		static public void AppendToFile(string FileName, string TextLine)
		{
			using (System.IO.StreamWriter sw =  System.IO.File.AppendText(FileName) )
			{
				try 
				{
					sw.WriteLine(TextLine) ;
				}
				finally
				{
					sw.Close() ;
				}
			}
		}


		public static void AppendToFileWithTime(string FileName, string TextLine)
		{
			AppendToFile(FileName
				, string.Format("{0}\t{1}"
				, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
				, TextLine)) ;
		}


		private string _Filename ; 

		public FileLogger(string Filename)
		{
			this._Filename = Filename ;
		}

		#region ILogger Members

		public void Write(string MessageLine)
		{
			 AppendToFileWithTime(this._Filename, MessageLine) ;
		}

		#endregion
	}


}