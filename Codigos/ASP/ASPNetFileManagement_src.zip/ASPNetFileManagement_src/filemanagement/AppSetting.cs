using System;
using System.Configuration;
using System.Web;

namespace filemanagement
{
	/// <summary>
	/// Summary description for AppSetting.
	/// </summary>
	public class AppSetting
	{
		public AppSetting()
		{
		}

		static public string Company
		{
			get 
			{
				return ConfigurationSettings.AppSettings["company"] ;
			}
		}

		static public string GetLogFilename()
		{
			string fileName = System.Configuration.ConfigurationSettings.AppSettings["FileManagementSiteLog"] ; 

			// Set default name
			if (fileName == null || fileName == string.Empty) 
				fileName = "FileManagementSiteLog.txt" ;  

			// Build filename pattern (Basenameyyyy-MM-dd.ext)
			if ( fileName.LastIndexOf(".") > -1 )
				fileName = string.Format("{0}{1}{2}"
					, fileName.Substring(0, fileName.LastIndexOf("."))
					, DateTime.Today.ToString("yyyy-MM-dd")
					, fileName.Substring(fileName.LastIndexOf("."))) ;
			else
				fileName = string.Format("{0}{1}"
					, fileName
					, DateTime.Today.ToString("yyyy-MM-dd")) ;

			return HttpContext.Current.Server.MapPath(fileName) ;
		}

		static public int ApplicationCacheTimeOut
		{
			get 
			{
				string CacheTimeOut = ConfigurationSettings.AppSettings["ApplicationCacheTimeOut"] ;
				if ( CacheTimeOut != null && CacheTimeOut != string.Empty )
					return int.Parse(CacheTimeOut) ;  
				else
					return 30 ; // In 30 minutes 
			}
		} 

		static public bool SendByThreadInPool
		{
			get 
			{
				return ConfigurationSettings.AppSettings["SendByThreadInPool"] == null 
					|| ConfigurationSettings.AppSettings["SendByThreadInPool"].ToLower() != "false" ;
			}
		}
	}
}
