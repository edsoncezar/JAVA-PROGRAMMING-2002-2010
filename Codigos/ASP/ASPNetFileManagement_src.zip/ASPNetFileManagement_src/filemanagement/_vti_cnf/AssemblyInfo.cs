vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Jul 2004 06:00:54 -0000
vti_extenderversion:SR|4.0.2.7802
vti_cacheddtm:TX|11 Jul 2004 06:00:54 -0000
vti_filesize:IR|2781
