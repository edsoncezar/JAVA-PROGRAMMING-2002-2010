vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Jan 2005 17:51:48 -0000
vti_extenderversion:SR|4.0.2.7802
vti_cacheddtm:TX|04 Nov 2004 06:43:41 -0000
vti_filesize:IR|954
