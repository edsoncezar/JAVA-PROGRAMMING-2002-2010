vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Feb 2005 18:35:44 -0000
vti_extenderversion:SR|4.0.2.7802
vti_cacheddtm:TX|04 Nov 2004 06:52:58 -0000
vti_filesize:IR|5229
