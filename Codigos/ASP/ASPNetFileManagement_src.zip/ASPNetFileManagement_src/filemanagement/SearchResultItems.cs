using System;
using System.Data ;
using System.Collections ;
using System.Threading ;


namespace filemanagement
{
	/// <summary>
	/// Summary description for SearchResultItems.
	/// </summary>
	public class SearchResultItems : ICollection
	{
		private ArrayList _SearchResultItems ;

		public SearchResultItems(DataTable ResultDataTable)
		{
			_SearchResultItems = new ArrayList() ;
			_SearchResultItems.Clear() ;
			foreach ( DataRow row in ResultDataTable.Rows )
				_SearchResultItems.Add( new SearchResultItem(row) ) ;
		}

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			lock(SyncRoot) 
			{
				return this._SearchResultItems.GetEnumerator() ;
			}
		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				return true ;
			}
		}

		public int Count
		{
			get
			{
				lock(SyncRoot) 
				{
					return this._SearchResultItems.Count ;
				}
			}
		}

		public void CopyTo(Array array, int index)
		{
			lock(SyncRoot) 
			{
				this._SearchResultItems.CopyTo(array, index) ;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this ;
			}
		}
		#endregion
	}

	public class SearchResultItem : SimpleFileInfoBase	
	{
		private string _Name ;
		private string _FullName ;
		private DateTime _LastWriteTime ;
		private long _Size ;

		public SearchResultItem(DataRow row)
		{
			_Name = row["Filename"]==DBNull.Value?string.Empty:(string)row["Filename"] ; 
			_FullName = row["Path"]==DBNull.Value?string.Empty:(string)row["Path"] ; 
			_LastWriteTime = row["Write"]==DBNull.Value?DateTime.MinValue:(DateTime)row["Write"] ; 
			_Size = row["Size"]==DBNull.Value?0L:(long)row["Size"] ; 
		}

		override public string Name { get {return _Name ; } }
		override public string FullName { get { return _FullName; } }
		override public DateTime LastWriteTime { get { return _LastWriteTime ; } } 
		override public long Size { get { return _Size ; } }

	}
}
