using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO ;

namespace filemanagement
{
	/// <summary>
	/// Summary description for FileSender.
	/// </summary>
	public class FileSender : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			string FileFullPath = string.Format("{0}", Request["file"]) ;
			if ( FileFullPath == "" )
				return ;

			FileInfo fileInfo =  new FileInfo(FileFullPath) ;
			if ( !fileInfo.Exists ) return ;

			Response.ClearHeaders() ;
			Response.ClearContent() ;

			switch ( fileInfo.Extension.ToLower()  )
			{
				case ".htm" :
				case ".html" :
				case ".asp" :
				case ".aspx" :
				case ".xml":
					goto Send_File;
				
				case ".txt":
				case ".ini":
				case ".log":
					Response.ContentType = "text/plain" ;
					goto Add_Disposition_Inline;
				

				case ".jpg":
					Response.ContentType = string.Format("image/JPEG;name=\"{0}\"", fileInfo.Name) ; 
					goto Add_Disposition_Inline;

				case ".gif":
				case ".png":
				case ".bmp":
					Response.ContentType = string.Format("image/{0};name=\"{1}\""
						, fileInfo.Extension.TrimStart('.')
						, fileInfo.Name) ; 
					goto Add_Disposition_Inline;

				case ".tif":
					Response.ContentType = string.Format("image/tiff;name=\"{0}\"", fileInfo.Name) ; 
					goto Add_Disposition_Inline;

				case ".doc":
					Response.ContentType = "Application/msword";
					goto Add_Disposition_Inline;

				case ".xls":
					Response.ContentType = "Application/x-msexcel";
					goto Add_Disposition_Inline;

				case ".pdf":
					Response.ContentType = "Application/pdf";
					goto Add_Disposition_Inline;

				case ".ppt":
				case ".pps":
					Response.ContentType = "Application/vnd.ms-powerpoint";
					goto Add_Disposition_Inline;

				case ".zip":
					Response.ContentType = "application/x-zip-compressed" ;
					goto Add_Disposition_Attachment;

				// Others as attachment only!
				default: 
					goto Add_Disposition_Attachment;
			}

			Add_Disposition_Attachment:
				Response.AppendHeader("Content-Disposition", string.Format("attachment;filename=\"{0}\"", fileInfo.Name)) ;
				goto Send_File;

			Add_Disposition_Inline:
				Response.AppendHeader("Content-Disposition", string.Format("inline;filename=\"{0}\"", fileInfo.Name)) ;
				goto Send_File;

			Send_File:

				try
				{
					Response.WriteFile(FileFullPath) ;
				}
				catch (UnauthorizedAccessException)
				{
					string query = Request.UrlReferrer.Query ;
					int i = query.ToLower().IndexOf("error=") ;
					if ( i > -1 )
					{
						int j = query.IndexOf("&", i) ;
						if ( j > -1 )
							query = query.Remove(i, j-i+1) ;
						else
							query = query.Remove(i, query.Length-i) ;
					}

					if ( query == "" ) 
						query = "?" ;
					else if (!query.EndsWith("&"))
						query += "&" ;

					Response.Redirect( Request.UrlReferrer.LocalPath 
					+ query 
					+ string.Format("Error=You are not allow to access file {0}."
						, fileInfo.Name)) ;
				}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
