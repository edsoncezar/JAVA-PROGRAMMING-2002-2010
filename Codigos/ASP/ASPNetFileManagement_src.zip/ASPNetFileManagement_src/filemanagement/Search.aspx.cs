using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration ;
using Utility.Web ;


namespace filemanagement
{
	/// <summary>
	/// Summary description for Search.
	/// </summary>
	public class Search : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button ButtonSearch;
		protected System.Web.UI.WebControls.TextBox TextBoxSearch;
		protected System.Web.UI.WebControls.Label LabelMsg;
		protected System.Web.UI.WebControls.Label LabelSearch;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected UCMainMenu UCMainMenu1 ;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			LabelMsg.Text = "" ;
			if ( !IsPostBack)
			{
				UCMainMenu1.HideMenuItem (UCMainMenu.MainMenuItems.HyperLinkLevelUp) ;
				UCMainMenu1.HideMenuItem (UCMainMenu.MainMenuItems.HyperlinkThumbnail);
				UCMainMenu1.HideMenuItem (UCMainMenu.MainMenuItems.HyperlinkListView);

				if ( Request["Error"] != null )
					LabelMsg.Text = string.Format("{0}", Request["Error"]) ;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ButtonSearch.Click += new System.EventHandler(this.ButtonSearch_Click);
			this.DataGrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.DataGrid1_ItemCreated);
			this.DataGrid1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DataGrid1_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ButtonSearch_Click(object sender, System.EventArgs e)
		{
			if ( TextBoxSearch.Text.Trim() != "" ) 
			{
				ViewState["SearchText"] = TextBoxSearch.Text ;
				DataGrid1.CurrentPageIndex = 0 ; 
				this.BindGrid() ;
			}
			else
				LabelMsg.Text = "Please enter search string." ;
		}

		private void BindGrid()
		{
			// String to be searched
			string SearchText = (string)ViewState["SearchText"] ;

			// Use the configured root path
			string RootPath = ConfigurationSettings.AppSettings["Root"] ;  

			try
			{
				// XML Webservice
				localhost.FileSearch FileSearcherInst = new localhost.FileSearch() ;
				FileSearcherInst.Credentials = System.Net.CredentialCache.DefaultCredentials ;

				DataTable results =  FileSearcherInst.Search(RootPath, SearchText).Tables[0] ;
				SearchResultItems searchResultItems = new SearchResultItems(results) ;
				DataGrid1.DataSource = searchResultItems  ;
				DataGrid1.DataBind();
		
				if ( searchResultItems.Count == 0 )
					this.LabelMsg.Text = "No document found." ;
				else if ( searchResultItems.Count == 1 )
					this.LabelMsg.Text = "1 document found." ;
				else
					this.LabelMsg.Text = string.Format("{0:N0} documents found.", searchResultItems.Count) ;
			}
			catch ( Exception excpt)
			{
				this.LabelMsg.Text = "Error occurred! "  + excpt.ToString();
				return ;
			}
		}

		protected string FormatSize(object file)
		{
			SearchResultItem ResultItem = file as SearchResultItem ;
			if ( ResultItem == null )
				return "" ;

			return string.Format("{0:N0} KB", (ResultItem.Size / 1024.0f)) ; 
		}

		protected string FormatLink(object file)
		{
			SearchResultItem ResultItem = file as SearchResultItem ;
			if ( ResultItem == null )
				return "" ;

			string FileFullName = Server.UrlEncode(ResultItem.FullName) ;

			return string.Format("{0}?file={1}", "FileSender.aspx", FileFullName ) ;
		}

		private void DataGrid1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DataGrid1.CurrentPageIndex = e.NewPageIndex ;
			this.BindGrid() ;
		}

		private void DataGrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			WebUI.AddPageLabel(e.Item) ;
		}
	}
}
