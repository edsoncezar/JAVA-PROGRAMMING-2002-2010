using System;
using System.Web ;
using System.Web.Caching ;
using System.IO ;

namespace filemanagement
{
	/// <summary>
	/// CacheManager - Cache manager for Application Objects
	/// </summary>
	public class CacheManager
	{

		static public FileSystemInfosExtend GetFileItems(string CurrentRootPath, bool RefreshCache)
		{
			// Format cache key as FileSystemInfosExtend:{CurrentRootPath}
			string keyName = string.Format("FileSystemInfosExtend:{0}",  CurrentRootPath) ;
			if ( RefreshCache || HttpContext.Current.Cache[keyName] == null ) 
			{
				// Remove previous cached item
				if ( HttpContext.Current.Cache[keyName] != null ) 
						HttpContext.Current.Cache.Remove(keyName) ;

				DirectoryInfo CurrentRoot = new DirectoryInfo(CurrentRootPath) ;
				FileSystemInfo[] files = CurrentRoot.GetFileSystemInfos() ;
				FileSystemInfosExtend FileInfosEx = new FileSystemInfosExtend(files) ;

				// Create cache item
				HttpContext.Current.Cache.Insert(
					keyName
					, FileInfosEx
					, null
					, DateTime.Now.Add(TimeSpan.FromMinutes(AppSetting.ApplicationCacheTimeOut))
					, Cache.NoSlidingExpiration) ;
			}

			return HttpContext.Current.Cache[keyName] as FileSystemInfosExtend ;
		}

	}
}
