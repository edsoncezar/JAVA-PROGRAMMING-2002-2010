using System;
using System.Data.OleDb ;
using System.Data ;

namespace SearchingService
{
	/// <summary>
	/// Summary description for FileSearcher.
	/// </summary>
	internal class FileSearcher 
	{
		private string _Catalog ; // Catalog Name		
		private string _Query ; // Search query 
		private string _Scope ;

		public string Catalog 
		{
			get { return _Catalog ; }
		}

		public string Scope
		{
			get { return _Scope ; }
		}

		public string Query 
		{
			get { return _Query ; }
		}

		private string Root
		{
			set 
			{
				_Scope = string.Format("{0}", value ) ;
				if (_Scope != "") _Scope = string.Format("'\"{0}\"'", _Scope) ;
			}
		}
		
		public FileSearcher()
		{
			this._Catalog  = System.Configuration.ConfigurationSettings.AppSettings["IndexCatalog"] ;
			if ( this._Catalog == null )
				this._Catalog = "system" ; // default
		}

		public DataSet Search(string RootPath, string TextToSearch)
		{
			this.Root = RootPath ;
			_Query = string.Format( "Select DocTitle, DocSubject, Filename, Size, Path, Write From Scope({0}) where FREETEXT('\"{1}\"') OR CONTAINS(Filename,'\"*{1}*\"')", _Scope, TextToSearch) ;
				
/*
 * "Provider=MSIDXS;Data Source=myCatalog;Locale Identifier=nnnn;"
 * Provider Specifies the OLE DB Provider for Microsoft Indexing Service. 
 * Typically this is the only keyword specified in the connection string. 
 * Data Source Specifies the Indexing Service catalog name. If this keyword 
 * is not specified,  the default system catalog is used. 
 * Locale Identifier Specifies a unique 32-bit number (for example, 1033) 
 * that specifies preferences related to the user's language. 
 * These preferences indicate how dates and times are formatted, 
 * items are sorted alphabetically, strings are compared, and so on. 
 * If this keyword is not specified, the default system locale identifier is used. 
 *
*/
				// string connstring = "Provider=MSIDXS.1;Integrated Security .='';Data Source="+_Catalog ;
				string connstring = "Provider=MSIDXS;Data Source="+_Catalog ;
				using ( OleDbConnection conn = new OleDbConnection(connstring) ) 
				{
					OleDbDataAdapter DataAdapter = new OleDbDataAdapter(_Query, conn);
					DataSet DataSetSearchResult = new DataSet();
					DataAdapter.Fill(DataSetSearchResult, "SearchResults");

					return DataSetSearchResult  ;
				}
		}
	}
}
