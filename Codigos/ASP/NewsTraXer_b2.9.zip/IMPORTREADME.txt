Before running this make sure of the following:

1)Make sure this script is located in the NewsTraXer main folder
2)You made a backup of your old news file (ntrax.mdb)
3)You copy your old ntrax.mdb file to the DBase folder and name it old.mdb
4)You unzipped the new ntrax.mdb file into the DBase folder