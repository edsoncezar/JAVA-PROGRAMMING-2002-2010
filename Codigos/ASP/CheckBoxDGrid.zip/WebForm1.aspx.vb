Imports System.Data
Imports System.Data.OleDb

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents cmdSelectAll As System.Web.UI.WebControls.Button
    Protected WithEvents dgMain As System.Web.UI.WebControls.DataGrid

    Dim oDataView As DataView
    Protected WithEvents cmdFindSelected As System.Web.UI.WebControls.Button
    Dim sConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False; Data Source=C:\Projects\demo\db.mdb;"


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        RefreshGrid()
        If Not Page.IsPostBack Then
            dgMain.DataBind()
        End If

    End Sub



#Region "Selection Handling"
    Private Sub cmdSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSelectAll.Click
        selectAll()
    End Sub

    Private Sub selectAll()
        Dim oDataGridItem As DataGridItem
        Dim chkExport As System.Web.UI.WebControls.CheckBox

        If cmdSelectAll.Text = "+" Then
            For Each oDataGridItem In dgMain.Items

                chkExport = oDataGridItem.FindControl("chkExport")
                chkExport.Checked = True
            Next

            cmdSelectAll.Text = "-"
        Else
            For Each oDataGridItem In dgMain.Items
                chkExport = oDataGridItem.FindControl("chkExport")
                chkExport.Checked = False
            Next
            cmdSelectAll.Text = "+"
        End If
    End Sub
#End Region

#Region "Refresh DataGrid"

    '//-------------------------------------------------------------------------------------
    '// Sub zum aktuallisieren des DataGrid Controlls

    Private Sub RefreshGrid()
        Dim oConnection As OleDbConnection
        Dim oCommand As OleDbDataAdapter
        Dim oDataSet As New DataSet()

        Try
            Dim sSQL As String = "Select * from tblNames order by Name"
            oConnection = New OleDbConnection(sConnectionString)
            oCommand = New OleDbDataAdapter(sSQL.ToString, oConnection)
            oCommand.Fill(oDataSet, "tblNames")
            oDataView = New DataView(oDataSet.Tables("tblNames"))
            dgMain.DataSource = oDataView
            oConnection.Close()

        Catch ex As Exception
            '// Place Error Handling here
        End Try
    End Sub
#End Region

    Private Sub cmdFindSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFindSelected.Click

        Dim oDataGridItem As DataGridItem
        Dim chkExport As System.Web.UI.WebControls.CheckBox
        Dim oExArgs As New System.Collections.ArrayList()
        Dim sID As String
        
        For Each oDataGridItem In dgMain.Items

            chkExport = oDataGridItem.FindControl("chkExport")
            If chkExport.Checked Then
                sID = CType(oDataGridItem.FindControl("lblColumn"), Label).Text
                oExArgs.Add(sID)
            End If
        Next

    End Sub
End Class
