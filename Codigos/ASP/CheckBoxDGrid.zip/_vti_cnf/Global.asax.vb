vti_encoding:SR|utf8-nl
vti_author:SR|Administrator
vti_modifiedby:SR|Administrator
vti_timecreated:TR|15 Dec 2002 19:51:26 -0000
vti_timelastmodified:TR|15 Dec 2002 19:51:26 -0000
vti_cacheddtm:TX|15 Dec 2002 19:51:26 -0000
vti_filesize:IR|1800
vti_extenderversion:SR|4.0.2.6513
vti_backlinkinfo:VX|
