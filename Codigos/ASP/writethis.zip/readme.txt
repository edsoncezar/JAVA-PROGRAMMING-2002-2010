********************************************************** * writeTHIS version 
1.3 by adam stokes * this program is free so do what you want just leave copyright 
please * visit http://xs-optix.com/ for more free applications and updates! * 
visit http://xs-optix.com/ubb/cgi-bin/ultimate.cgi * for any questions or comments 
you may have! ********************************************************** To INSTALL: 
1) Unzip the zip file into it's own directory (i.e. yourdomain.com/writeTHIS) 
2) create a images directory within your 'writethis' directory and place images 
there 3) open up your browser once files are uploaded and run writethis/protect.html 
the default name and pwd is 'admin' *To change password and name just open up 
your tablusers.mdb and edit there then upload *i will incorporate that in the 
next version so you can do it via web. 4) now all items will be shown on article.asp, 
so edit that anyway you wish just dont touch the scripting! all items copyright 
2000 adam stokes. thanks for using writeTHIS ..a cow goes moo...