Title: PSC Newest Submission Grabber
Description: This Script will go out to planetsourcecode.com and retrieve the newest submissions. It saves the data it got in a text file so we don't get the info every time the page loads. It will get the submissions from ALL Worlds on PSC. After it gathers the data it strips All the HTML from it. Then it will out put the submission in a table for easy display. See Screen Shot for Output.
Ive Uploaded it in zip format now for eazy download.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7113&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
