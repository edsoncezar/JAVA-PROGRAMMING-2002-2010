----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

SQLServerTools Object v1.1



summary:
===============
Encapsulates various useful SQL Server routines.


documentation:
===============
This file is considered to be the documentation for this example
as well as any notes in the source code of cls_sqlservertools.asp



installation:
===============
1.) required files from download package:
	cls_sqlservertools.asp
	sqlservertools.asp
	sp_Admin_ExampleTablesDependencies.sql
		
		* cls_sqlservertools.asp
			this file is the re-usable VBScript class.
			it should be included into any asp page that
			needs it's functionality. This file includes
			the properties and methods sheet for the object.
		
		* sqlservertools.asp
			this file is an example of what has to happen
			in each page that calls the class above.

		* sp_Admin_ExampleTablesDependencies.sql
			the stored procedure that the class works with.
			this procedure must be installed before running
			the class.
			


2.) place the required files from step 1 into the root directory 
    on the server and run any *.sql scripts against your sql server
    database.


3.) navigate to sqlservertools.asp on your website with your 
    web browser to test.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/



Version History:
===============
	1.1   2/21/2003
		added recordset state check to prevent bombing if a 
		table was returned that had no stored procedures. in 	
		this case, the returned recordset is closed but previous 
		versions of the software didnt bother to check for that 
		condition which would result in an "recordset is closed" 
		error whenever the BOF or EOF properties were checked in 
		the recordset loop.

	1.0   6/11/2001
		initial release



Properties:
===============
	ConnString[ = string]
		Sets/Returns a string representing a valid db conn string
		accessing an sql server.

	ConnUser[ = string]
		Sets/Returns a string representing a valid db user account
		for the sql server or database specified in ConnString.

	ConnPass[ = string]
		Sets/Returns a string representing a valid db account 
		password for the user account specified in ConnUser.



Methods:
===============
	GetTableDependencies()
		returns void. Uses response.write to output data.
		Retrieves a list of all user tables in the database
		and their dependencies (stored procedures, etc...)



Required database objects:
===============
	see sp_Admin_ExampleTablesDependencies.sql
