CREATE PROCEDURE sp_Admin_ExampleTablesDependencies
AS
/*
All variables in TSQL must be declared and are "probably"
case sensitive. For this I need to declare 1 variable and 
one cursor variable.
Variables in sql server work like variables in any
other language. The cursor variable is different.
A cursor allows you to work with the
recordset of a given sql statement from within a 
procedure. Depending on the type of cursor you use,
you can do the same stuff as you can do with the 
ADO objects such as movenext, etc... 

The first is a working string type variable...
*/
DECLARE @mSrvName varchar(128)

/*
sysobjects is a table found in every database that
keeps a record on what objects are available in that particular
db. Each object has a type. For this, I want all tables that
I created. That type is 'U' for 'user table'. 
I also prefaced all my aspemporium system type tables with 'AE_' 
(those ones I use to make ASP Emporium work and are not examples)
so I'll be excluding those since none of the examples use those
tables... and there is another table called 'dtproperties' that
I'll be canning as well. The results set for that sql statement
is placed into the AllTables cursor variable.
*/
DECLARE AllTables CURSOR FOR
	SELECT
	name
	FROM
	sysobjects
	WHERE
	type = 'U'
	AND
	name NOT LIKE 'AE_%'
	AND
	name <> 'dtproperties'
	ORDER BY
	name


/*
this works just like you would do it in vbscript with ado.
first you need to open the recordset and then loop through
the results and then close the rs and set it to nothing.
*/
OPEN AllTables

/*
the cursor type I specified is forward only so the first
record is immediately available. Can't go backwards,
can't update with this cursor type. Can only go forward
and it's read only.

the fetch statement is the key to getting crap back from 
the recordset you just opened. It can be used a bunch of
different ways. It will produce a single RS if you call it
like this:
FETCH NEXT FROM AllTables

But if you add the 
[INTO [@localvar1[, @localvar2[, ...]]]]
part on to the end, you can place the values of each field
into local variables so you can use them in the stored procedure.
The @localvar1, etc part above represents the select list that
you used to declare the cursor with. This way of using fetch
doesn't produce a recordset. So it's possible to examine 
tables and do whatever and not return a recordset so long 
as the examination occurs within TSQL such as in a stored 
procedure. So let's review what we got so far:

1.) declare cursor
    DECLARE cursorvarname CURSOR FOR
       SELECT field1, field2 FROM table

2.) open rs
    OPEN cursorvarname

3.) retrieve goodies from first row
    FETCH NEXT FROM AllTables
        INTO @field1var, @field2var

*/
FETCH NEXT FROM AllTables
	INTO @mSrvName


/*
after you get the first record's fields with fetch
you need to start a loop to loop through each record's
fields. @@FETCH_STATUS is a cursor function that 
returns an integer and can have one of 3 values:
0  FETCH statement was successful. 
-1 FETCH statement failed or the row was beyond the result set. 
-2 Row fetched is missing. 

This loop will execute as long as the last fetch didn't 
generate an error. So if we got the first row, the loop 
will start.
*/
WHILE @@FETCH_STATUS = 0
BEGIN
	/*
	This part of the procedure is where the 
	"baby's breath" is... The next 2 lines were the
	only reason that I even bothered using a cursor
	for this procedure.

	Anyways. We got the name of the current row's
	table from sysobjects stored into the @mSrvName
	variable. First thing I want to do is return
	a recordset with 2 fields and only 1 record.
	The record will contain the table name and 'user table'
	and it's type. This is only done to match the results
	set for sp_depends when it returns info for tables...
	*/
	SELECT @mSrvName as name, 'user table' as type

	/*
	so we just returned 1 recordset times however many times 
	we loop through... and I'm not done yet. This is a totally
	useless app right now. It doesn't do anything. Time to
	put the bang in. For my bang I'll call the sp_depends 
	system stored procedure. You input a table name, you get
	a recordset back of all stored procedures that are dependent
	on that table - crutial information! Dependent means that
	the stored procedure is querying, updating or otherwise
	actively using that table and needs it to work properly.
	sp_depends returns different results sets based on what
	type of object is entered as the argument. For table names,
	it's name and type. Type is always 'stored procedure' and
	name is the complete name of the stored procedure...
	IE: owner.procedurename
	
	Calling sp_depends will add yet another recordset to 
	the mix. That's 2 recordsets per loop and the number 
	of loops = the number of tables in the db. Seems like 
	it would be slow as hell and impossible to use with 
	ADO and ASP or VB. Wrong. Truth is, it's fast as (insert 
	explicitive here) and can be used via ADO by calling the 
	NextRecordset method of the last active recordset (see 
	the corresponding example that uses this procedure via 
	ASP using VBScript).
	*/
	EXEC sp_depends @mSrvName

	/*
	remember that we just got dependencies for the last 
	successful fetch. Now we need to get the current table 
	by doing a fetch in the loop
	*/
	FETCH NEXT FROM AllTables
		INTO @mSrvName

	/*
	the END statement when used with WHILE and preceeded by
	BEGIN acts like loop in vbscript. Repeat over and over
	again until all example tables have gone through the loop
	and we've returned around 28 recordsets or so as of June
	2001 at the asp emporium. Definitely seems like 28 recordsets
	would be slow. It's not. Trust me. SQL Server hauls ass
	and by using nextrecordset, we can do all the display work
	in only one quick db connection.
	*/
END

/*
Close cursor. It's important to free up cursors before returning
control to the ADO objects if you want everything to work right.
Since usually ADO specifies the type of cursor it wants and we 
don't want to pass back a cursor that's different or not what
ADO is expecting... Sounds like bluescreen territory. Stay away
by closing and deallocating the cursor.
*/
CLOSE AllTables

/*
DEALLOCATE is equivalent to nothing and is used to dead a cursor.
Peace. It's gone...
*/
DEALLOCATE AllTables