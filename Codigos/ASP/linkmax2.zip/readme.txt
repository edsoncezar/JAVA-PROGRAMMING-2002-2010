LinkMax2 version 1.0 by WebAvail Productions (http://www.webmaster-solutions.com/products)

*** License:

You may edit this script to suit your needs as long as you follow these rules:

1. The link and text in bottom.inc reading 'Powered by LinkMax2 & WebAvail Productions'
   May not be edited, removed, made illegible due to font and or color modifications.

2. If you do not use bottom.inc you must include the text and link in the listing page.

3. You may not take credit for the development of this script.

*** Files:

addlink.asp         ... Add link form for users
addlinkexec.asp     ... Executes the addition of new links
admin.asp           ... Administration (Use this file to administer the system)
admin-approve.asp   ... Admin file (approves links)
admin-catedit.asp   ... Admin file (edits categories)
admin-linkedit.asp  ... Admin file (edits links)
admin-links.asp     ... Admin file (edits links)
admin-main.asp      ... Admin file (Quick Help)
admin-menu.asp      ... Admin file (Menu)
admin-supp.asp      ... Admin file (Sponsor: Flicks Software http://www.flicks.com)
admin-system.asp    ... Admin file (System Editor)
admin-top.htm       ... Admin file (Top Frame)
bottom.inc          ... Bottom include file
connection.inc      ... Connection String
data.mdb            ... Database (Access 97)
default.asp         ... Default listing file
passcheck.asp       ... Password Checker
redir.asp           ... Redirection script
top.inc             ... Top include file
linktemp.inc        ... Link Template
readme.txt          ... This file

*** Installation:

Simply unzip linkmax2.zip into a specified virtual directory
for example: http://yourcompany.com/linkmax2


*** Notes:
When you setting up links for the listing they should be:

http://yourcompany.com/linkmax2
OR
http://yourcompany.com/linkmax2/default.asp

To access the admin area the url would be:
http://yourcompany.com/linkmax2/admin.asp

