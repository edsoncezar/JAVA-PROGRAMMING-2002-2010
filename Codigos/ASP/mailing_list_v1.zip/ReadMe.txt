Web Wiz Guide ASP Mailing List realease v1 beta


The Web Wiz Guide ASP Mailing List v1 beta is written by Bruce Corkhill

****************************************************************************************
**  Copyright Notice                                                                  **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                                **
**  This script is free to use and alter as much as you like.                         **
**  You may not resell or redistribute this script without permission by the author.  **
**  You may not pass the script off as your own work.                                 **
**  You must levae all the link buttons to http://www.webwizguide.com in place.       **
**  Use this script at your own risk						      **
****************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.webwizguide.com/forum 

your questions will be answered there NOT by e-mail



The ASP Mailing List uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the ASP Mailing List


Unzip all the files to the same directory as you wish to show the mailing list in

Files must be run through an ASP enabled web sever

The default.asp page is only to show you the script running.

If you wish to add the Form to allow uer site visitor to join your mailing list into your homepage or another page on the site make sure the page has the extension .asp and place the following lines in the palce on the page where you wish the form to be displayed: -

<!-- Start Mailing List Include File -->
<!--#include file="mailing_list.inc" -->
<!-- End mailing list Include File -->

You can then delete the page default.asp as it will no longer be needed. 

However, make sure all the files conatined in this zip file are in the same directory as the page you want to show the form allowing your users to sign up in.



You can Admimister the ASP Mailing List through the page Admin.htm

The default username and passowrd for the admin.htm administration page is: -

	Username - administartor
	Password - letmein

Form the adminstartion files you can can set up the script and send e-mails to everyone on the mailing list.


If you are having problems with the ASP Mailing List running then edit the file common.inc with note pad where you can select to use a diffrent OBDC database driver or use DSN if you are able to setup DSN on your web server.

If you move the Mailing List database to another directory then place the new path into the common.inc file.




If you recieve the following error: -

Microsoft OLE DB Provider for ODBC Drivers error '80004005' 
[Microsoft][ODBC Microsoft Access Driver] Operation must use an updateable query.

This means that the directory the database is in does not have the right permissions to be able to write to the database. 

If you are running the web server yourself and using the NTFS file system then there is an FAQ page at, http://www.webwizguide.com/asp/FAQ, on how to change the server permissions on Win2k/NT4.  

If you are not running the server yourself then you will need to contact the server's adminstrator and ask them to change the permissions otherwise you cannot update a database.



If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.webwizguide.com/asp/FAQ

