WebExplorer Free - A powerful asp tool for managing remote files with an user-friendly web interface
November 2002 - Version 2.0
Copyright � 2000-2003 by Cem Alacayir

Copyright notice:
WebExplorer Free is a freeware with open source code. 
As long as you keep the copyright message, you can 
play with the code for your own purposes but you can
not distribute the altered version. You can not sell 
WebExplorer Free or use it for commercial purposes.
Please contact me for commercial uses.

Errors, comments or suggestions : contact@wexfms.com
Visit the web page for updates and support : http://www.wexfms.com

Server requirements:
------------------------
-IIS/PWS 
-Microsoft Windows Script 5.1+ 
 Here: http://msdn.microsoft.com/downloads/default.asp?url=/downloads/sample.asp?url=/msdn-files/027/001/733/msdncompositedoc.xml
-Microsoft Data Access Components (MDAC) 2.5+
 Here: http://www.microsoft.com/data
-No 3rd party components are required 

Client requirements:
------------------------
-Any recent browser should work ok (javascript and session-state cookies should be enabled)

Setup:
------------------------
Just upload the contents of the distribution to a folder in your web root like "wexfree", no other configurations are required.
Default password is "tester". Edit "config.asp" to customize the settings which are explained by comments.
