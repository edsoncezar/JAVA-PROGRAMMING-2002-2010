// create an internet session
CInternetSession csiSession;

// parse URL to get server/object/port
CString sGetFromURL ( "http://aspwire.com/getnews.asp?site=secret&lang=1&cnt=10" ); 

if ( !AfxParseURL ( sGetFromURL, dwServiceType, sServerName, sObject, nPort ) )
	throw;

// open HTTP connection
CHttpConnection* pHTTPServer = NULL;

pHTTPServer = csiSession.GetHttpConnection ( sServerName, nPort );

// get HTTP object
CHttpFile* pFile = NULL;

pFile = pHTTPServer->OpenRequest ( CHttpConnection::HTTP_VERB_GET, sObject, NULL, 1, NULL, NULL, INTERNET_FLAG_RELOAD );

pFile->SendRequest();

// open file to store raw data into
CStdioFile cfRaw ( "News.txt", CFile::modeCreate | CFile::modeReadWrite );

TCHAR sRaw [1024];

// transfer the data into our local file
while ( pFile->ReadString ( sRaw, 1023 ) )
	cfRaw.WriteString ( sRaw );

// I've finished with the HTTP objects
// so close them
pFile->Close();
pHTTPServer->Close();
