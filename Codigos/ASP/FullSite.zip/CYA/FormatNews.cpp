// open file to store formatted data into
TCHAR* sNewsFile = _T( "News.asp" );
CStdioFile cfASP ( sNewsFile, CFile::modeCreate | CFile::modeWrite );

// output the static part of the asp file - the function declaration, 
// the ASPWire image and the heading
cfASP.WriteString ( _T("<%\nfunction ShowNews ( )\n{\n") );
cfASP.WriteString ( _T("\tOut('<a href=\"http://aspwire.com/\"><img src=\"images/ASPWireNews.gif\" alt=\"News from ASPWire\" border=0></a>');\n") );
cfASP.WriteString ( _T("\tOut('&nbsp;&nbsp;&nbsp;(<a href=\"GetNews.asp\">Read how this is done</a>)<p>');\n") );
cfASP.WriteString ( _T("\tOut('<table width=\"100%\">');\n") );

cfRaw.SeekToBegin ();

CString sLine;
bool bNewRow = true;

for (int i=0; ; i++)
{
	if ( FALSE == cfRaw.ReadString ( sLine ) )
		break;

	switch ( i % 4 )
	{
	case 0:		// URL
		cfASP.WriteString ( _T("\tOut('") );

		if ( bNewRow )
			cfASP.WriteString ( _T ( "<tr>" ) );

		bNewRow = !bNewRow;

		cfASP.WriteString ( _T("<td>&#149;&nbsp;<a href=\"") );
		cfASP.WriteString ( sLine );
		cfASP.WriteString ( _T("\" target=\"CYAExternal\">") );
		break;

	case 3:		// title
		sLine.Replace ( "'", "\\'" );
		cfASP.WriteString ( sLine );
		cfASP.WriteString ( _T("</a></td>") );

		if ( bNewRow )
			cfASP.WriteString ( _T ( "</tr>" ) );

		cfASP.WriteString ( _T("');\n") );
		break;
	}
}

cfASP.WriteString ( _T("\tOut('</table>');\n") );
cfASP.WriteString ( _T("}\n%>") );


// close files
cfRaw.Close ();
cfASP.Close ();

