// now upload file to my website
if ( !AfxParseURL ( sSendToURL, dwServiceType, sServerName, sObject, nPort ) )
	throw;

// open FTP connection
pFTPServer = csiSession.GetFtpConnection ( sServerName, _T( "username" ), _T( "password" ), nPort );

// change to utils folder
pFTPServer->SetCurrentDirectory ( _T( "utils" ) );

// put the new file in the folder
pFTPServer->PutFile ( sNewsFile, sNewsFile );
