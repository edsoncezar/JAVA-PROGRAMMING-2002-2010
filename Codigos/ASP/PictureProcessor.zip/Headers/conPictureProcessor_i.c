/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Apr 23 23:28:34 2001
 */
/* Compiler settings for D:\DR0WN\conPictureProcessor\conPictureProcessor.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IPictureProcessor = {0x4FC80610,0x9B91,0x4202,{0xBB,0x3F,0x28,0x7C,0x76,0xA2,0x7E,0xA4}};


const IID LIBID_COMOBJECTSNETLib = {0x561162B1,0x83BA,0x4956,{0x89,0xFB,0x97,0xBF,0xE8,0xB8,0xA1,0x97}};


const CLSID CLSID_PictureProcessor = {0xD44550B9,0xEEF6,0x4983,{0x89,0x91,0x2B,0x8A,0x24,0xC6,0xF1,0x49}};


#ifdef __cplusplus
}
#endif

