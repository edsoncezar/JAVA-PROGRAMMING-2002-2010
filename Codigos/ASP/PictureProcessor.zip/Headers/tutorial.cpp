// tutorial.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <objbase.h>
#include <oleauto.h>
#include <comdef.h>

#include "codes.h"
#include "conPictureProcessor.h"
#include "conPictureProcessor_i.c"

void ShowError(IUnknown* pUnk)
{
	BSTR w = L"";
	IErrorInfo* pErr=NULL;
	::GetErrorInfo(NULL,&pErr);
	pErr->GetDescription(&w);
	char* s=(char*)malloc(sizeof(char)*100);
	wcstombs(s, w, 100);
	cout << "Error: " << s << endl;

}

int main(int argc, char* argv[])
{	
	IUnknown *pUnk=NULL;
	IPictureProcessor *pPict=NULL;
	HRESULT hr=S_OK;

// Initialize COM library
	hr = CoInitialize(NULL);
	if (FAILED(hr)) 
	{
		cout << "Error: can\'t initialize COM library :( " << endl;
		return -1;
	}

// Trying to create instance of the object
	hr = CoCreateInstance(CLSID_PictureProcessor, NULL, CLSCTX_INPROC_SERVER, IID_IUnknown, (void**)&pUnk);
    if (FAILED(hr)) 
    {
       cout << "Error: can\'t create instance of PictureStretcher :( " << endl;
       return -1;
    }

// Querying IPictureProcessor interface
	hr = pUnk->QueryInterface(IID_IPictureProcessor,(void**)&pPict);
	if (FAILED(hr)) 
    {
       cout << "Error: can\'t query interface IPictureStretcher :( " << endl;
       return -1;
    }

// We don't need it no more...
	pUnk->Release();
	pUnk=NULL;

// Now let's work with the component:

// Loading picture from file. Note: filename must be in unicode (BSTR)

	wchar_t fname[] = L"testload.jpg";
	hr = pPict->LoadFromFile(fname);
	if (FAILED(hr))
	{
		ShowError(pPict);
		pPict->Release();
		return -1;
	}
	else 
	  cout << "Success: file loaded!" << endl;
	
// Resizing the picture. Let's reduce the size in 2 times

	long x, y;
	pPict->get_Height(&x);
	pPict->get_Width(&y);
	x=x/2;
	y=y/2;
	hr = pPict->Resize(x,y);
	if (FAILED(hr))
	{
		ShowError(pPict);
		pPict->Release();
		return -1;
	}
	else cout << "Success: file resized" << endl;
	
// Now save the result to file resized.jpg
	wchar_t fnamejpeg[] = L"resized.jpg";
	hr = pPict->SaveToFileAsJpeg(fnamejpeg);
	if (FAILED(hr))
	{
		ShowError(pPict);
		pPict->Release();
		return -1;
	}
	else cout << "Success: file saved" << endl;
	
// Now let's rotate the picture on 60 degrees and set background color to white
	
	double pi = 3.1416;
	double angle = (pi/180)*60;

	UINT color = RGB(255,255,255);
	pPict->put_BackGroundColor(color);
	hr = pPict->Rotate(angle);
	if (FAILED(hr))
	{
		ShowError(pPict);
		pPict->Release();
		return -1;
	}
	else cout << "Success: file rotated" << endl;

// Now save the result to file rotated.bmp 
	wchar_t fnamebmp[] = L"rotated.bmp";
	hr = pPict->SaveToFileAsBmp(fnamebmp);
	if (FAILED(hr))
	{
		ShowError(pPict);
		pPict->Release();
		return -1;
	}
	else cout << "Success: file saved" << endl;

// Releasing the instance of Picture Processor
	pPict->Release();

// Uninitialize COM library
	CoUninitialize();
	
	return 0;
}

