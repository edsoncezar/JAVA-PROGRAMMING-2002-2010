//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: PICPROC_E_PICTURE_LOAD_FAIL
//
// MessageText:
//
//  Can't load picture from file
//
#define PICPROC_E_PICTURE_LOAD_FAIL      -536870399L

//
// MessageId: PICPROC_E_PICTURE_SAVE_FAIL
//
// MessageText:
//
//  Can't save picture to file
//
#define PICPROC_E_PICTURE_SAVE_FAIL      -536870398L

//
// MessageId: PICPROC_E_PICTURE_TO_ASP_FAIL
//
// MessageText:
//
//  Can't save picture to ASP document stream
//
#define PICPROC_E_PICTURE_TO_ASP_FAIL    -536870397L

//
// MessageId: PICPROC_E_RESIZE_FAIL
//
// MessageText:
//
//  Error occured during resizing
//
#define PICPROC_E_RESIZE_FAIL            -536870396L

//
// MessageId: PICPROC_E_NO_PICTURE
//
// MessageText:
//
//  You are trying to do some actions, but picture is not loaded
//
#define PICPROC_E_NO_PICTURE             -536870395L

//
// MessageId: PICPROC_E_ROTATE_FAIL
//
// MessageText:
//
//  Error occured during rotating
//
#define PICPROC_E_ROTATE_FAIL            -536870394L

