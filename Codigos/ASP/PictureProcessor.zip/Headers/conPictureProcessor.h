/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Apr 23 23:28:34 2001
 */
/* Compiler settings for D:\DR0WN\conPictureProcessor\conPictureProcessor.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __conPictureProcessor_h__
#define __conPictureProcessor_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IPictureProcessor_FWD_DEFINED__
#define __IPictureProcessor_FWD_DEFINED__
typedef interface IPictureProcessor IPictureProcessor;
#endif 	/* __IPictureProcessor_FWD_DEFINED__ */


#ifndef __PictureProcessor_FWD_DEFINED__
#define __PictureProcessor_FWD_DEFINED__

#ifdef __cplusplus
typedef class PictureProcessor PictureProcessor;
#else
typedef struct PictureProcessor PictureProcessor;
#endif /* __cplusplus */

#endif 	/* __PictureProcessor_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IPictureProcessor_INTERFACE_DEFINED__
#define __IPictureProcessor_INTERFACE_DEFINED__

/* interface IPictureProcessor */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPictureProcessor;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4FC80610-9B91-4202-BB3F-287C76A27EA4")
    IPictureProcessor : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadFromFile( 
            BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveToFileAsJpeg( 
            BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Resize( 
            int Width,
            int Height) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Quality( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Quality( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Height( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Width( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SmoothFactor( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SmoothFactor( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_OptimizationOn( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_OptimizationOn( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OnStartPage( 
            /* [in] */ IUnknown __RPC_FAR *piUnk) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OnEndPage( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveToASPDocumentAsJpeg( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveToFileAsBmp( 
            BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Rotate( 
            double angle) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BackGroundColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_BackGroundColor( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPictureProcessorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPictureProcessor __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPictureProcessor __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPictureProcessor __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadFromFile )( 
            IPictureProcessor __RPC_FAR * This,
            BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveToFileAsJpeg )( 
            IPictureProcessor __RPC_FAR * This,
            BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Resize )( 
            IPictureProcessor __RPC_FAR * This,
            int Width,
            int Height);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Quality )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Quality )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Height )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Width )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SmoothFactor )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SmoothFactor )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_OptimizationOn )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_OptimizationOn )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ BOOL newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OnStartPage )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ IUnknown __RPC_FAR *piUnk);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OnEndPage )( 
            IPictureProcessor __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveToASPDocumentAsJpeg )( 
            IPictureProcessor __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveToFileAsBmp )( 
            IPictureProcessor __RPC_FAR * This,
            BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Rotate )( 
            IPictureProcessor __RPC_FAR * This,
            double angle);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BackGroundColor )( 
            IPictureProcessor __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BackGroundColor )( 
            IPictureProcessor __RPC_FAR * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IPictureProcessorVtbl;

    interface IPictureProcessor
    {
        CONST_VTBL struct IPictureProcessorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPictureProcessor_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPictureProcessor_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPictureProcessor_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPictureProcessor_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPictureProcessor_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPictureProcessor_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPictureProcessor_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPictureProcessor_LoadFromFile(This,filename)	\
    (This)->lpVtbl -> LoadFromFile(This,filename)

#define IPictureProcessor_SaveToFileAsJpeg(This,filename)	\
    (This)->lpVtbl -> SaveToFileAsJpeg(This,filename)

#define IPictureProcessor_Resize(This,Width,Height)	\
    (This)->lpVtbl -> Resize(This,Width,Height)

#define IPictureProcessor_get_Quality(This,pVal)	\
    (This)->lpVtbl -> get_Quality(This,pVal)

#define IPictureProcessor_put_Quality(This,newVal)	\
    (This)->lpVtbl -> put_Quality(This,newVal)

#define IPictureProcessor_get_Height(This,pVal)	\
    (This)->lpVtbl -> get_Height(This,pVal)

#define IPictureProcessor_get_Width(This,pVal)	\
    (This)->lpVtbl -> get_Width(This,pVal)

#define IPictureProcessor_get_SmoothFactor(This,pVal)	\
    (This)->lpVtbl -> get_SmoothFactor(This,pVal)

#define IPictureProcessor_put_SmoothFactor(This,newVal)	\
    (This)->lpVtbl -> put_SmoothFactor(This,newVal)

#define IPictureProcessor_get_OptimizationOn(This,pVal)	\
    (This)->lpVtbl -> get_OptimizationOn(This,pVal)

#define IPictureProcessor_put_OptimizationOn(This,newVal)	\
    (This)->lpVtbl -> put_OptimizationOn(This,newVal)

#define IPictureProcessor_OnStartPage(This,piUnk)	\
    (This)->lpVtbl -> OnStartPage(This,piUnk)

#define IPictureProcessor_OnEndPage(This)	\
    (This)->lpVtbl -> OnEndPage(This)

#define IPictureProcessor_SaveToASPDocumentAsJpeg(This)	\
    (This)->lpVtbl -> SaveToASPDocumentAsJpeg(This)

#define IPictureProcessor_SaveToFileAsBmp(This,filename)	\
    (This)->lpVtbl -> SaveToFileAsBmp(This,filename)

#define IPictureProcessor_Rotate(This,angle)	\
    (This)->lpVtbl -> Rotate(This,angle)

#define IPictureProcessor_get_BackGroundColor(This,pVal)	\
    (This)->lpVtbl -> get_BackGroundColor(This,pVal)

#define IPictureProcessor_put_BackGroundColor(This,newVal)	\
    (This)->lpVtbl -> put_BackGroundColor(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_LoadFromFile_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    BSTR filename);


void __RPC_STUB IPictureProcessor_LoadFromFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_SaveToFileAsJpeg_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    BSTR filename);


void __RPC_STUB IPictureProcessor_SaveToFileAsJpeg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_Resize_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    int Width,
    int Height);


void __RPC_STUB IPictureProcessor_Resize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_Quality_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_Quality_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_put_Quality_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IPictureProcessor_put_Quality_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_Height_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_Height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_Width_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_Width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_SmoothFactor_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_SmoothFactor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_put_SmoothFactor_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IPictureProcessor_put_SmoothFactor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_OptimizationOn_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_OptimizationOn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_put_OptimizationOn_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IPictureProcessor_put_OptimizationOn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_OnStartPage_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [in] */ IUnknown __RPC_FAR *piUnk);


void __RPC_STUB IPictureProcessor_OnStartPage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_OnEndPage_Proxy( 
    IPictureProcessor __RPC_FAR * This);


void __RPC_STUB IPictureProcessor_OnEndPage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_SaveToASPDocumentAsJpeg_Proxy( 
    IPictureProcessor __RPC_FAR * This);


void __RPC_STUB IPictureProcessor_SaveToASPDocumentAsJpeg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_SaveToFileAsBmp_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    BSTR filename);


void __RPC_STUB IPictureProcessor_SaveToFileAsBmp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_Rotate_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    double angle);


void __RPC_STUB IPictureProcessor_Rotate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_get_BackGroundColor_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IPictureProcessor_get_BackGroundColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPictureProcessor_put_BackGroundColor_Proxy( 
    IPictureProcessor __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IPictureProcessor_put_BackGroundColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPictureProcessor_INTERFACE_DEFINED__ */



#ifndef __COMOBJECTSNETLib_LIBRARY_DEFINED__
#define __COMOBJECTSNETLib_LIBRARY_DEFINED__

/* library COMOBJECTSNETLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_COMOBJECTSNETLib;

EXTERN_C const CLSID CLSID_PictureProcessor;

#ifdef __cplusplus

class DECLSPEC_UUID("D44550B9-EEF6-4983-8991-2B8A24C6F149")
PictureProcessor;
#endif
#endif /* __COMOBJECTSNETLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
