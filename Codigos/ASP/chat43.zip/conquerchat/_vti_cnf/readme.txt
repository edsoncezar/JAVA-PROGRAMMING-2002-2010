vti_encoding:SR|utf8-nl
vti_author:SR|SCANNET02\\theill
vti_modifiedby:SR|SCANNET02\\theill
vti_timecreated:TR|27 Jan 2001 19:28:57 -0000
vti_timelastmodified:TR|07 Mar 2003 02:09:51 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.5526
vti_nexttolasttimemodified:TR|20 Oct 2002 18:44:43 -0000
vti_syncwith_10.0.0.2\:80:TR|08 Jan 2002 16:59:51 -0000
vti_syncwith_localhost\:80:TR|01 Aug 2002 16:53:48 -0000
vti_filesize:IR|4692
vti_cacheddtm:TX|07 Mar 2003 02:09:51 -0000
