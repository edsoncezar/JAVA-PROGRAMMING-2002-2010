vti_encoding:SR|utf8-nl
vti_author:SR|SCANNET02\\theill
vti_modifiedby:SR|SCANNET02\\theill
vti_timecreated:TR|02 Nov 2002 18:02:55 -0000
vti_timelastmodified:TR|22 Jan 2003 01:22:42 -0000
vti_backlinkinfo:VX|asp/conquerchat.asp
vti_extenderversion:SR|4.0.2.5526
vti_nexttolasttimemodified:TR|02 Nov 2002 18:20:24 -0000
vti_cacheddtm:TX|22 Jan 2003 01:22:42 -0000
vti_filesize:IR|3976
vti_sourcecontrolversion:SX|V1
vti_sourcecontrolcookie:SX|fp_internal
