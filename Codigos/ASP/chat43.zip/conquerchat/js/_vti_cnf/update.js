vti_encoding:SR|utf8-nl
vti_author:SR|SCANNET02\\theill
vti_timecreated:TR|14 Apr 2002 20:43:00 -0000
vti_timelastmodified:TR|09 Mar 2003 22:49:32 -0000
vti_backlinkinfo:VX|conquerchat/logout.asp conquerchat/users.asp conquerchat/window.asp conquerchat/message.asp conquerchat/private.message.asp conquerchat/private.asp conquerchat/rooms.asp
vti_extenderversion:SR|4.0.2.5526
vti_nexttolasttimemodified:TR|24 Nov 2002 13:50:24 -0000
vti_syncwith_localhost\:80:TR|05 Jun 2002 17:34:52 -0000
vti_filesize:IR|2795
vti_cacheddtm:TX|24 Nov 2002 13:50:44 -0000
vti_sourcecontrolversion:SX|V1
vti_sourcecontrolcookie:SX|fp_internal
