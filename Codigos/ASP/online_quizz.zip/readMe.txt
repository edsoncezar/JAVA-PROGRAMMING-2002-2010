extract all the files in folder. 

For admin 

login  : admin
password : master