#################################################################################
## Copyright (C) 2000  Gateserver
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## LICENSE.TXT for more deatils.
##
## Questions or Comments can be directed to:
## http://www.gateserver.com
## 
## Correspondence can be sent to:
## damion@gateserver.com
## 
## Any additional Contributions/Comments/Questions can be sent to:
## Gateserver
## P.O. Box 808
## Scotch Plains, NJ 07076
#################################################################################

1. Active Resource Index v1.1
============================================

Thank you for purchasing Active Resource Index.

We have implemented many features that we hope will meet and go beyond
your needs. Please email us to let us know of any additional improvements
we could make for any future versions. We are very interested in hearing
from you and serving you better.

Please leave our gateserver name active on the pages so that we
can receive proper credit for our work. This will also help others
find us more easily. The gateserver.gif graphic is very small and
should be included with every copy of this program it is REQUIRED
and must remain visible on the ARI generated pages.

Installing
----------
Please visit our website for detailed installation instructions and other
important information <http://www.gateserver.com>

If you are an expert and do not need detailed instructions see the Setup.asp
file directly. There are a few instructions inside for you to get started quickly.

Thank You,
Gateserver
http://www.gateserver.com

