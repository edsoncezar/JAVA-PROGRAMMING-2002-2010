smNews

Installation instructions:
* Unzip all files to a directory on your web site.
* Place the database in a directory for which the IUSR account has read/write permissions, preferably outside the web structure.
* Set the path to the database in news.asp,  line 36.
* In the "config variables" section (lines 32-67), set the administrative password, page size, and database table names.
* Off you go!

smNews is a free news script with a web-based administration interface which allows the addition of comments to news articles. It was intended to have clean, readable code, avoiding feature bloat.

Features:
* Comments engine to allow comments to be posted, edited and deleted.
* Edit and delete posted articles.
* News archive shows titles of older news items.

Suggested customisations/modifications (or, my "to do" list for the next version):
* User management system (smUser?), to allow hosted user biographies.
* Email support, utilising popular components such as CDONTS and JMail, enabling email notification of new headlines.

Before you begin on these mods, please check with me ( sean@tombstone.org.uk ) first, as I may have already begun work on it.

smNews should be fairly simple to install/run, and please contact me ( sean@tombstone.org.uk ) for any further information.

Copyright notice is at the top of news.asp, and license.txt contains a copy of the GPL.

Sean