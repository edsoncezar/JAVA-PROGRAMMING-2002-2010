myImages - Elad Rosenberg March 2001
-------------------------------------
asp photo album
-------------------------------------
extract the files to a folder in the server. (ie : myimages)
open config.inc and replace the paths to your paths:

<%
basePath = "f:/inetpub/wwwroot/myimages/"
Bvpath = "http://nyx/myimages/images/"
%>

the basepath is the phy. path to the application folder.

the bvpath is the virtual path to the images folder.(all images will be under images
directory which created by the zip file - DON'T change it's name[from images to something else])
now run the index file:
http://www.yourServer.com/myimages/index.asp

you can upload images inside "images" folder and create sub folders inside
images folder.(physically or by FTP)

--------------- adding headers ------------------------------------------
you can add description for each folder:
write a text description and save the file as "header.txt".
put it in the specific directory and that's it!
the name MUST be header.txt and you can enter sperate header.txt file for
each folder.
--------------------------------------------------------------------------
restrictions:
* all images and sub Folders should be under the "images" folder (which
is under "myimages" main folder - you can name the main folder in any name you want except "images"! i.e: myAlbum/images or myimages/images)

* images and folders names should be in english and withOut any speces and
special chars.

hopes u like it...
elad
