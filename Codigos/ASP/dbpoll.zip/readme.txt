


Note: Import the sample database to your FP web and name your    
  connection "DBPOLL", import the other 2 files.


       Gilberto Padilla
       
        gil98@jps.net 