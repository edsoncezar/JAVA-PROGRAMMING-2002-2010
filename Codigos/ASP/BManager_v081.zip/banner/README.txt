INSTALLING
1) Put the banner.mdb database in your database directory and set 
include/inc_database.asp to your database location.
2) Set the path in include/inc_settings.asp
3) Set your language in include/inc_locale.asp (only italian and 
english for now)

Access BannerManager as Admin with
Username: admin
Password: admin

Report any bug to BM sourceforge project manager, thanks!
Eduard Roccatello

Support the project, visit: http://www.pcimprover.it
If you have some problem please contact info@pcimprover.it