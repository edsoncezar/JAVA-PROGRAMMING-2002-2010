Installation of PacMail is simple.

First, if you open the database dont delete any tables. you may notice by extensive examination of the code there are 2 extra tables. These are in place so that when V 2 is released you won't need to change the database at all. Thus you can keep your existing list in tact. V 2 will allow for multiple mailing lists.


Now, there are two files that are of importance.

Conn.asp
and
accessDriverConn.asp

Conn.asp uses Jet 4.0 to connect.
accessDriverConn.asp uses the msaccess driver to connect to the databse.
If you want to use the access driver then rename accessDriverConn.asp to Conn.asp
If you are unsure if your server has Jet 4.0 contact your support. I reccomend using Jet...


Drop the mail list into the web. I recomend for security reasons you imediatley change the email and password. This is done by pointing the browser to:
http://www.yoursite.com/maillist/login.htm

The initial email is me@me.com This is your log in name. The default password is 123456
Log in and then click on Edit Admin Defaults. 

The first text box is where you will change the password. The second is for changing your email.

The 3rd box is your default signiture. This will be attached to ALL emails sent to your mailing list.

Now then, if you have email ads you want to include in each mailing, the next 4 boxes is where you add these. You can add none, any, or all, it's up to you. If you want NO ADS delete whats in these boxes.

The last box is kind of a normal thing in reputable email lists. It tells the person how to unsubscribe or be removed from the list. This will have to be done manually at this time. In the future this will be automated.

Thats it for the defaults.

If you want to ADD EDIT or DELETE people, from the main page click on Add Or Edit Users

To edit or delete enter the email you are wanting to see. Then click submit. You will then be given the info for that email address to either edit or delete.

To add a user, enter the email, first and last names and click Add.

Thats all for administering the subscribers.

Now to send your mail. From the main page click on Send Mail

Simply fill out the subject and enter your message and click Preview Now. This will allow you to see the mail before you send it. This way you have a chance to correct any mistakes.

Of course people need to know you HAVE a mailing list to join. Here's how to do it:

Place this inbetween the <HEAD> tags on the page you want a link for visitors to join the mailing list.

<script>
function openit(){
var which="/maillist/join.htm"
whichit=window.open(which,"","width=400,height=255")
}
</script>

Place the link anywhere in the body where you want it to show up.
<a href="javascript:openit()">Join Our Mailing List!</a>

This will open a small window to subscribe. After the fill out thier name and email it will automatically add them to the database so they will get an email each time you send one.


Thats it,
Happy Mailing!!!!!!