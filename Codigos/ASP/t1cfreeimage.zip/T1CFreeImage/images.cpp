// Images.cpp : Implementation of CImages
#include "stdafx.h"
#include "T1CFreeImage.h"
#include "Images.h"

#include "gdfonts.h"

/////////////////////////////////////////////////////////////////////////////
// CImages

STDMETHODIMP CImages::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IImages
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CImages::CreateImage(int w, int h)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	int white;

	img = gdImageCreate(w, h);
	white = gdImageColorAllocate(img, 255, 255, 255);
	
	return S_OK;
}


STDMETHODIMP CImages::SetColor(int R, int G, int B)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	color = gdImageColorAllocate(img, R, G, B);	
	
	if (color == (-1)) {
        color = gdImageColorAllocate(img, R, G, B);
        color = gdImageColorClosest(img, R, G, B);
	}


	return S_OK;
}

STDMETHODIMP CImages::DrawLine(int x1, int y1, int x2, int y2)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	gdImageLine(img, x1, y1, x2, y2, color);	

	return S_OK;
}

STDMETHODIMP CImages::SaveToFile(BSTR strFile)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	FILE *out;
	CHAR	*lpString;
	int		iMessageSize;

	iMessageSize=wcslen(strFile)+1;
	lpString = new CHAR[iMessageSize];

	// Change the Message From Unicode to MBCS
	if (WideCharToMultiByte(CP_ACP,0,strFile,-1,lpString,iMessageSize,NULL,NULL)==FALSE)
	{
		return(S_FALSE);
	}	

	out = fopen(lpString, "wb");
	/* Write PNG */
	gdImagePng(img, out);
	fclose(out);	

	delete lpString;


	return S_OK;
}

STDMETHODIMP CImages::DrawText(int x, int y, BSTR str)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	CHAR	*lpString;
	int		iMessageSize;

	iMessageSize=wcslen(str)+1;
	lpString = new CHAR[iMessageSize];

	// Change the Message From Unicode to MBCS
	if (WideCharToMultiByte(CP_ACP,0,str,-1,lpString,iMessageSize,NULL,NULL)==FALSE)
	{
		return(S_FALSE);
	}	

	gdImageString(img, gdFontSmall, x, y, (unsigned char *)lpString, color);
	
	delete lpString;

	return S_OK;
}
