// Images.h : Declaration of the CImages

#ifndef __IMAGES_H_
#define __IMAGES_H_

#include "resource.h"       // main symbols
#include "gd.h"       // gd library


/////////////////////////////////////////////////////////////////////////////
// CImages
class ATL_NO_VTABLE CImages : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CImages, &CLSID_Images>,
	public ISupportErrorInfo,
	public IDispatchImpl<IImages, &IID_IImages, &LIBID_T1CFREEIMAGELib>
{
public:
	CImages()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IMAGES)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CImages)
	COM_INTERFACE_ENTRY(IImages)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IImages
public:
	STDMETHOD(DrawText)(/*[in]*/ int x,/*[in]*/ int y,/*[in]*/ BSTR str);
	int color;
	gdImagePtr img;
	STDMETHOD(SaveToFile)(/*[in]*/ BSTR strFile);
	STDMETHOD(DrawLine)(/*[in]*/ int x1, /*[in]*/ int y1, /*[in]*/ int x2, /*[in]*/ int y2);
	STDMETHOD(SetColor)(/*[in]*/ int R, /*[in]*/ int G, /*[in]*/ int B);
	STDMETHOD(CreateImage)(/*[in]*/ int w, /*[in]*/ int h);
};

#endif //__IMAGES_H_
