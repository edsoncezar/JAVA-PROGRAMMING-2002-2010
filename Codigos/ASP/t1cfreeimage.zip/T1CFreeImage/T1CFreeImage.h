/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Mar 28 14:01:15 2001
 */
/* Compiler settings for C:\DevStudio\My projects\ActiveX\T1CFreeImage\T1CFreeImage\T1CFreeImage.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __T1CFreeImage_h__
#define __T1CFreeImage_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IImages_FWD_DEFINED__
#define __IImages_FWD_DEFINED__
typedef interface IImages IImages;
#endif 	/* __IImages_FWD_DEFINED__ */


#ifndef __Images_FWD_DEFINED__
#define __Images_FWD_DEFINED__

#ifdef __cplusplus
typedef class Images Images;
#else
typedef struct Images Images;
#endif /* __cplusplus */

#endif 	/* __Images_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IImages_INTERFACE_DEFINED__
#define __IImages_INTERFACE_DEFINED__

/* interface IImages */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IImages;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("049BDB3C-1DF6-11D5-8E3D-0080AD705C3E")
    IImages : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateImage( 
            /* [in] */ int w,
            /* [in] */ int h) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetColor( 
            /* [in] */ int R,
            /* [in] */ int G,
            /* [in] */ int B) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawLine( 
            /* [in] */ int x1,
            /* [in] */ int y1,
            /* [in] */ int x2,
            /* [in] */ int y2) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveToFile( 
            /* [in] */ BSTR strFile) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawText( 
            /* [in] */ int x,
            /* [in] */ int y,
            /* [in] */ BSTR str) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IImagesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IImages __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IImages __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IImages __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IImages __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IImages __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IImages __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IImages __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateImage )( 
            IImages __RPC_FAR * This,
            /* [in] */ int w,
            /* [in] */ int h);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetColor )( 
            IImages __RPC_FAR * This,
            /* [in] */ int R,
            /* [in] */ int G,
            /* [in] */ int B);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawLine )( 
            IImages __RPC_FAR * This,
            /* [in] */ int x1,
            /* [in] */ int y1,
            /* [in] */ int x2,
            /* [in] */ int y2);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveToFile )( 
            IImages __RPC_FAR * This,
            /* [in] */ BSTR strFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawText )( 
            IImages __RPC_FAR * This,
            /* [in] */ int x,
            /* [in] */ int y,
            /* [in] */ BSTR str);
        
        END_INTERFACE
    } IImagesVtbl;

    interface IImages
    {
        CONST_VTBL struct IImagesVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IImages_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IImages_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IImages_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IImages_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IImages_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IImages_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IImages_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IImages_CreateImage(This,w,h)	\
    (This)->lpVtbl -> CreateImage(This,w,h)

#define IImages_SetColor(This,R,G,B)	\
    (This)->lpVtbl -> SetColor(This,R,G,B)

#define IImages_DrawLine(This,x1,y1,x2,y2)	\
    (This)->lpVtbl -> DrawLine(This,x1,y1,x2,y2)

#define IImages_SaveToFile(This,strFile)	\
    (This)->lpVtbl -> SaveToFile(This,strFile)

#define IImages_DrawText(This,x,y,str)	\
    (This)->lpVtbl -> DrawText(This,x,y,str)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImages_CreateImage_Proxy( 
    IImages __RPC_FAR * This,
    /* [in] */ int w,
    /* [in] */ int h);


void __RPC_STUB IImages_CreateImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImages_SetColor_Proxy( 
    IImages __RPC_FAR * This,
    /* [in] */ int R,
    /* [in] */ int G,
    /* [in] */ int B);


void __RPC_STUB IImages_SetColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImages_DrawLine_Proxy( 
    IImages __RPC_FAR * This,
    /* [in] */ int x1,
    /* [in] */ int y1,
    /* [in] */ int x2,
    /* [in] */ int y2);


void __RPC_STUB IImages_DrawLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImages_SaveToFile_Proxy( 
    IImages __RPC_FAR * This,
    /* [in] */ BSTR strFile);


void __RPC_STUB IImages_SaveToFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImages_DrawText_Proxy( 
    IImages __RPC_FAR * This,
    /* [in] */ int x,
    /* [in] */ int y,
    /* [in] */ BSTR str);


void __RPC_STUB IImages_DrawText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IImages_INTERFACE_DEFINED__ */



#ifndef __T1CFREEIMAGELib_LIBRARY_DEFINED__
#define __T1CFREEIMAGELib_LIBRARY_DEFINED__

/* library T1CFREEIMAGELib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_T1CFREEIMAGELib;

EXTERN_C const CLSID CLSID_Images;

#ifdef __cplusplus

class DECLSPEC_UUID("049BDB3D-1DF6-11D5-8E3D-0080AD705C3E")
Images;
#endif
#endif /* __T1CFREEIMAGELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
