----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

DirectoryBrowser Object



summary:
===============
Enhanced Web Site Directory Browsing

Browse through your entire web site with this system. 
Allows unrestricted surfing of your entire web site and 
all of it's sub directories - all from this one file! 
If you ever wanted to know how to sort data returned by 
the Scripting.FileSystemObject, this example is for you. 

This is Version 2.0 of the Complete Web Site Directory 
Browsing example, updated 12/22/00, and now known as the 
DirectoryBrowser Object. 

Includes the following new and improved features, not found 
in version 1: 
	Code fully encapsulated into a VBScript Class 

	Dynamic location menu with link support 

	Sorting of files by Name, Type, Date, Size. Ascending
	and Descending sort types currently supported. 

	Uses custom ADO recordsets to sort and store file 
	system data temporarily on the fly without a database! 

	Security Hole Fixed Thanks to mrv@giganetstore.com 
	for pointing out a security hole in the system.




documentation:
===============
DirectoryBrowser is a vbscript class and behaves like an object in vbscript.
It exports several methods to allow programmers to work with the file system
to create a navigatible html display. Please view cls_directorybrowser.asp 
file for the complete exposed interface definition.



installation:
===============
1.) you will need the cls_directorybrowser.asp and the directorybrowser2.asp file


2.) place the required files from step 1 into any directory on the server.


3.) navigate to directorybrowser2.asp on your website with your web browser to test.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


