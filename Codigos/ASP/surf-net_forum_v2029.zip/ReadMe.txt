Surf-net Forum realease v2.29 beta


The Surf-net Forum v2.29 beta is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without permission.             **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!



If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail



The hit counter uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the Forum

Unzip all the files keeping them in there zipped directories.

Files must be run through an ASP enabled web sever.

The Forum can be configured online by using the files in the configuration folder. By running the defualt.asp file in the cofigartion folder you will be given a set of options from which you can turn on e-mail notifcation, customise the forum by changing the colours of the forum, enter fourm names and descriptions, and change the username and password of the forum adminstrator(which is highly recommened for higher security). 

Once the forum is configured using the files in the configuration folder you should remove the configuration folder and all the files within it from your web server as it could be a security risk if a user where to stumble across it.


To Administer the database you will need to login to the Forum with the username (unless you change thses settings though the configuration files): -

Administrator

and with the password: -

Letmein

One you have logged in as Administrator you can then Edit or Delete any posts in the forum. I would recommend that you change the password, this can be done by clicking on the Edit Profile button shown at the top of the forum once you have logged in.




If you are having problems with the forum running then edit the file common.inc with note pad where you can select to use a diffrent OBDC database driver or use DSN if you are able to setup DSN on your web server.



If you recieve the following error: -

Microsoft OLE DB Provider for ODBC Drivers error '80004005' 
[Microsoft][ODBC Microsoft Access Driver] Operation must use an updateable query.

This means that the directory the database is in does not have the right permissions to be able to write to the database. 

If you are running the server yourself then you can change the permissions by right clicking on the folder containing the database and choose sharing, then choose permissions, add IUser_yourcomputername with the permssion set to allow change.

If you are not running the server yourself then you will need to contact the server's adminstrator and ask them to change the permissions otherwise you cannot update a database.




If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ


If I have missed anything out or any bugs then please let me know by e-mailing me at asp@surf-net.co.uk