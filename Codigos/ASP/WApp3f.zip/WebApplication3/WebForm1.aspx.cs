using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Text;


namespace WebApplication3
{
	/// <summary>
	/// Summary description for WebForm1.
	/// A sample C# ASP.NET project that demonstrates basic datagrid/dataset
	/// editing, filtering, deleting, selecting, paging and sorting
	/// Tested against SQL7 Pubs database on Windows XP Pro, IE5.0 and NS4.7
	/// You may need to edit the connection string on your development station.
	/// To FIND_ALL, click clear and then click filter.
	/// The code in this project is for educational use only and no warranty
	/// is implied or expressed for any other use.
	/// All Rights Reserved
	/// 6/24/2002
	/// This version using FlowLayout and nested Tables for compatibility with
	/// Netscape 4.7
	/// This version checks for invalid page index and resets edit index
	/// This version adds client side JavaScript support on delete.
	/// JeffLouie@compuserve.com
	/// </summary>

	public class WebForm1 : System.Web.UI.Page
	{
		// Note that we bind DataGrid to a DataView to support sorting.

		protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected WebApplication3.DataSet1 dataSet11;
		protected DataView view;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Button buttonFilter;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label6; 
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.Label Label10;
		protected System.Web.UI.WebControls.Label Label18;
		protected System.Web.UI.WebControls.Button buttonClear;
		protected System.Web.UI.WebControls.TextBox textBoxID;
		protected System.Web.UI.WebControls.TextBox textBoxLast;
		protected System.Web.UI.WebControls.TextBox textBoxFirst;
		protected System.Web.UI.WebControls.TextBox textBoxAddress;
		protected System.Web.UI.WebControls.TextBox textBoxCity;
		protected System.Web.UI.WebControls.TextBox textBoxState;
		protected System.Web.UI.WebControls.TextBox textBoxZip;
		protected System.Web.UI.WebControls.TextBox textBoxPhone;
		protected System.Web.UI.WebControls.TextBox textBoxContract;
		protected System.Web.UI.WebControls.TextBox textBoxMessage;
		protected System.Web.UI.WebControls.Button buttonAdd;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;

		// There are three non data columns in the data grid
		protected const int NUM_LINK_COLUMNS= 3;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			// This code execute evertime

			// This line of code refreshes the data set on
			// every page load. 
			sqlDataAdapter1.Fill(dataSet11);

			//You may need to persist the
			// dataset to the ViewState or Session to support
			// optimistic concurrency
			/*
			if (Session["dataSet"] != null) 
			{
				dataSet11= (DataSet1)Session["dataSet"];
			}
			else 
			{
				sqlDataAdapter1.Fill(dataSet11);
				Session["dataSet"]= dataSet11;
			}
			*/
		
			view = dataSet11.Tables[0].DefaultView;
			textBoxMessage.Text= "";
		
			// This code executes the first time only
			if (!IsPostBack)
			{								
				ViewState["LastSortOrder"]="ASC";
				ViewState["LastSortColumn"]= "au_id";
				ViewState["LastFilter"]= "";
				view.Sort = "au_id"+ " ASC";
				DataGrid1.DataBind();
			}
			else 
			// This code executes only on post back
			{
				string lastSortColumn= (string)ViewState["LastSortColumn"];
				string lastSortOrder= (string)ViewState["LastSortOrder"];
				string lastFilter= (string)ViewState["LastFilter"];
				view.Sort= lastSortColumn+ " "+ lastSortOrder;
				view.RowFilter= lastFilter;
			}
		}

		// Our UTILITY functions. 

		// Convert doubles single quotes for use
		// in an SQL statement
		protected string Convert(string inString) 
		{
			return inString.Replace("'","''");
		}
 
		// ResetPageIndex resets invalid page index to last page
		// ASSERT grid and view NOT NULL
		protected void ResetPageIndex(DataGrid grid, DataView view) 
		{
			// check for invalid page index
			// Page index is zero based
			if ((grid.CurrentPageIndex != 0) && (((grid.CurrentPageIndex)*grid.PageSize)>= view.Count)) 
			{
				// invalid so leave at last page
				if ((view.Count % grid.PageSize)== 0) // ends on page border
				{ 
					grid.CurrentPageIndex= (view.Count/grid.PageSize)-1;
				}
				else // partial page
				{
					grid.CurrentPageIndex= (view.Count/grid.PageSize);
				}
			}
		}

		// Nothing here but EVENT HANDLERS

		protected void DataGrid1_Edit(Object sender, DataGridCommandEventArgs e) 
		{
			DataGrid1.EditItemIndex = e.Item.ItemIndex;
			ResetPageIndex(DataGrid1,view);
			DataGrid1.DataBind();
		}

		protected void DataGrid1_Cancel(Object sender, DataGridCommandEventArgs e) 
		{
			DataGrid1.EditItemIndex = -1;
			ResetPageIndex(DataGrid1,view);
			DataGrid1.DataBind();
		}
 
		protected void DataGrid1_Update(Object sender, DataGridCommandEventArgs e) 
		{   
			string debug="No Errors On Update.";
			int numCols = e.Item.Cells.Count;

			// Gets the value of the key field of the row being updated
			string key = DataGrid1.DataKeys[e.Item.ItemIndex].ToString();

			// Finds the row in the dataset table that matches the 
			// one the user updated in the grid. This example uses a 
			// special Find method defined for the typed dataset, which
			// returns a reference to the row.
			DataRow dr= dataSet11.authors.FindByau_id(key);

			// Update the dataSet. Skip non data columns in data grid.
			// Note use of generic index, not column names.
			try 
			{				
				for (int i=NUM_LINK_COLUMNS; i<numCols; i++) //skip non data columns
				{
					String colvalue =((TextBox)e.Item.Cells[i].Controls[0]).Text;
					dr[i-NUM_LINK_COLUMNS]= colvalue;
				}
				sqlDataAdapter1.Update(dataSet11);
				DataGrid1.EditItemIndex = -1;  // leave user in edit mode on exception
			}
			catch (Exception exc)
			{
				debug= exc.Message;
			}
			// Refresh the grid
			ResetPageIndex(DataGrid1,view);
			DataGrid1.DataBind();
			textBoxMessage.Text= debug;
		}

		// adds workaround for javascript post back bug by disabling
		// delete event handler if selected row is in edit mode
		protected void DataGrid1_Delete(Object sender, DataGridCommandEventArgs e)
		{
			if (DataGrid1.EditItemIndex == e.Item.ItemIndex) 
			{
				ResetPageIndex(DataGrid1,view);
				textBoxMessage.Text= "WARNING: Unable to delete record in edit mode!\rPlease Cancel Edit Mode.";
				return;
			}

			string key = DataGrid1.DataKeys[e.Item.ItemIndex].ToString();
			string debug= "No errors.";
			// Updates the dataset table
			try 
			{	
				DataRow dr= dataSet11.authors.FindByau_id(key);
				dr.Delete();
				sqlDataAdapter1.Update(dataSet11);
			}
			catch (Exception exc)
			{
				sqlDataAdapter1.Fill(dataSet11);  //if Update fails, refresh dataset
				debug= exc.Message;
			}
			// check for invalid page index
			ResetPageIndex(DataGrid1,view);
			DataGrid1.EditItemIndex = -1;
			DataGrid1.DataBind();
			textBoxMessage.Text= debug;
		}

		protected void DataGrid1_Sort(Object sender, DataGridSortCommandEventArgs e) 
		{
			string newSortColumn= e.SortExpression.ToString();
			string newSortOrder="ASC";  // default
			string lastSortColumn= (string)ViewState["LastSortColumn"];
			string lastSortOrder= (string)ViewState["LastSortOrder"];

			if (newSortColumn.Equals(lastSortColumn) && lastSortOrder.Equals("ASC")) 
			{
				newSortOrder= "DESC";	
			} // else {newSortOrder="ASC";}

			ViewState["LastSortOrder"]= newSortOrder;
			ViewState["LastSortColumn"]= newSortColumn;

			view.Sort= newSortColumn+ " "+ newSortOrder;
			DataGrid1.EditItemIndex = -1;
			DataGrid1.CurrentPageIndex= 0;  // goto first page
			DataGrid1.DataBind();
		}

		protected void DataGrid1_Page(Object sender, DataGridPageChangedEventArgs e) 
		{
				DataGrid1.CurrentPageIndex= e.NewPageIndex;
				DataGrid1.EditItemIndex = -1;
				ResetPageIndex(DataGrid1, view);
				DataGrid1.DataBind();
		}
 
		protected void buttonAdd_Click(object sender, System.EventArgs e)
		{
			string debug= "No errors on INSERT.";
			// Insert new row into the dataset table
			try 
			{	
				DataRow dr= dataSet11.authors.NewRow();
				
				dr["au_id"]= textBoxID.Text;
				dr["au_lname"]= textBoxLast.Text;
				dr["au_fname"]= textBoxFirst.Text;
				dr["address"]= textBoxAddress.Text;
				dr["city"]= textBoxCity.Text;
				dr["state"]= textBoxState.Text;
				dr["phone"]= textBoxPhone.Text;
				dr["zip"]= textBoxZip.Text;
				dr["contract"]= textBoxContract.Text;

				dataSet11.Tables[0].Rows.Add(dr);
				sqlDataAdapter1.Update(dataSet11);
			}
			catch (Exception exc)
			{
				debug= exc.Message;
			}

			// Refresh the grid
			DataGrid1.EditItemIndex = -1;
			ResetPageIndex(DataGrid1, view);
			DataGrid1.DataBind();
			textBoxMessage.Text= debug;
		}

		// Dynamically create an SQL WHERE statement
		protected void buttonFilter_Click(object sender, System.EventArgs e)
		{
			string @au_id= Convert(textBoxID.Text);
			string @au_lname= Convert(textBoxLast.Text);
			string @au_fname= Convert(textBoxFirst.Text);
			string @address= Convert(textBoxAddress.Text);
			string @city= Convert(textBoxCity.Text);
			string @state= Convert(textBoxState.Text);
			string @zip= Convert(textBoxZip.Text);
			string @phone= Convert(textBoxPhone.Text);

			// Use StringBuilder to concatenate strings
			StringBuilder sb=	new StringBuilder("(au_id LIKE '");
			sb.Append(@au_id);
			sb.Append("%' OR au_id IS NULL) AND (au_lname LIKE '");
			sb.Append(@au_lname);
			sb.Append("%' OR au_lname IS NULL) AND (au_fname LIKE '");
			sb.Append(@au_fname);
			sb.Append("%' OR au_fname IS NULL) AND (phone LIKE '");
			sb.Append(@phone);
			sb.Append("%' OR phone IS NULL) AND (address LIKE '");
			sb.Append(@address);
			sb.Append("%' OR address IS NULL) AND (city LIKE '");
			sb.Append(@city);
			sb.Append("%' OR city IS NULL) AND (state LIKE '");
			sb.Append(@state);
			sb.Append("%' OR state IS NULL) AND (zip LIKE '");
			sb.Append(@zip);
			sb.Append("%' OR zip IS NULL)");
			try 
			{
				bool isContract= Boolean.Parse(textBoxContract.Text);
				if (isContract) 
				{
					sb.Append( " AND (contract = 1 OR contract IS NULL)");
				}
				else 
				{
					sb.Append(" AND (contract = 0 OR contract IS NULL)");
				}
			}
			catch{}
			
			string s= sb.ToString();  
			ViewState["LastFilter"]= s;  // persist filter on postback
			view.RowFilter= s;
			DataGrid1.EditItemIndex = -1;
			DataGrid1.CurrentPageIndex= 0;  // important! goto first page
			DataGrid1.DataBind();
		} 

		// clear textBoxes for INSERT or FILTER
		protected void buttonClear_Click(object sender, System.EventArgs e)
		{
			textBoxID.Text= "";
			textBoxLast.Text= "";
			textBoxFirst.Text= "";
			textBoxAddress.Text= "";
			textBoxCity.Text= "";
			textBoxState.Text= "";
			textBoxPhone.Text= "";
			textBoxZip.Text= "";
			textBoxContract.Text= "";
		}

		// This just demonstrates how to trap SELECT item
		// Note that we trim extra spaces so as not to confuse FILTERING
		protected void Item_Click(Object sender, DataGridCommandEventArgs e) 
		{
			if (((LinkButton)e.CommandSource).CommandName == "SelectItem") 
			{
				string key = DataGrid1.DataKeys[e.Item.ItemIndex].ToString();
				string debug= "";
				// Fills text boxes with data in row
				// TextBox.Text Setter converts " to &quot; Cool!
				try 
				{	
					DataRow dr= dataSet11.authors.FindByau_id(key);
					textBoxID.Text= dr["au_id"].ToString().TrimEnd(' ');
					textBoxLast.Text= dr["au_lname"].ToString().TrimEnd(' ');
					textBoxFirst.Text= dr["au_fname"].ToString().TrimEnd(' ');
					textBoxAddress.Text= dr["address"].ToString().TrimEnd(' ');
					textBoxCity.Text= dr["city"].ToString().TrimEnd(' ');
					textBoxState.Text= dr["state"].ToString().TrimEnd(' ');
					textBoxPhone.Text= dr["phone"].ToString().TrimEnd(' ');
					textBoxZip.Text= dr["zip"].ToString().TrimEnd(' ');
					textBoxContract.Text= dr["contract"].ToString().TrimEnd(' ');
				}
				catch (Exception exc)
				{
					debug= exc.Message;
				}
				textBoxMessage.Text= debug;
			}
		}
		
		// adapted from "Wicked Code" Jeff Prosise MSDN August 2002
		// note the cast to the base class WebControl which should succeed with
		// Button or LinkButton
		// note that I moved the delete button to column one to get the index
		// to work even in edit mode
		// however this method still FAILS in edit mode due to post back bug which calls
		// delete event handler in edit mode even on cancel!
		protected void DataGrid1_ItemCreated(Object sender, DataGridItemEventArgs e) 
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				LinkButton button = (LinkButton) e.Item.Cells[0].Controls[0];
				button.Attributes.Add("onclick", "return confirm (\"Really? Delete? \");");
			}
		}

		// End EVENT HANDLERS. Thats it for now. Have fun! Jeff

		// WIZARD CODE BELOW, LOOK BY EXPANDING, BUT DON'T TOUCH <g>

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.dataSet11 = new WebApplication3.DataSet1();
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
			this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
			this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
			this.buttonFilter.Click += new System.EventHandler(this.buttonFilter_Click);
			// 
			// sqlDataAdapter1
			// 
			this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
			this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
			this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
			this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "authors", new System.Data.Common.DataColumnMapping[] {
																																																				 new System.Data.Common.DataColumnMapping("au_id", "au_id"),
																																																				 new System.Data.Common.DataColumnMapping("au_lname", "au_lname"),
																																																				 new System.Data.Common.DataColumnMapping("au_fname", "au_fname"),
																																																				 new System.Data.Common.DataColumnMapping("phone", "phone"),
																																																				 new System.Data.Common.DataColumnMapping("address", "address"),
																																																				 new System.Data.Common.DataColumnMapping("city", "city"),
																																																				 new System.Data.Common.DataColumnMapping("state", "state"),
																																																				 new System.Data.Common.DataColumnMapping("zip", "zip"),
																																																				 new System.Data.Common.DataColumnMapping("contract", "contract")})});
			this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = @"DELETE FROM authors WHERE (au_id = @Original_au_id) AND (address = @Original_address OR @Original_address IS NULL AND address IS NULL) AND (au_fname = @Original_au_fname) AND (au_lname = @Original_au_lname) AND (city = @Original_city OR @Original_city IS NULL AND city IS NULL) AND (contract = @Original_contract) AND (phone = @Original_phone) AND (state = @Original_state OR @Original_state IS NULL AND state IS NULL) AND (zip = @Original_zip OR @Original_zip IS NULL AND zip IS NULL)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_id", System.Data.SqlDbType.VarChar, 11, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_id", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_address", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "address", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_fname", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_fname", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_lname", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_lname", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_city", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "city", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_contract", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "contract", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_phone", System.Data.SqlDbType.VarChar, 12, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "phone", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_state", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "state", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_zip", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "zip", System.Data.DataRowVersion.Original, null));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "data source=(local);initial catalog=pubs;persist security info=False;user id=sa;w" +
				"orkstation id=SONY;packet size=4096";
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO authors(au_id, au_lname, au_fname, phone, address, city, state, zip, contract) VALUES (@au_id, @au_lname, @au_fname, @phone, @address, @city, @state, @zip, @contract); SELECT au_id, au_lname, au_fname, phone, address, city, state, zip, contract FROM authors WHERE (au_id = @au_id) ORDER BY au_id";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_id", System.Data.SqlDbType.VarChar, 11, "au_id"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_lname", System.Data.SqlDbType.VarChar, 40, "au_lname"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_fname", System.Data.SqlDbType.VarChar, 20, "au_fname"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@phone", System.Data.SqlDbType.VarChar, 12, "phone"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@address", System.Data.SqlDbType.VarChar, 40, "address"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@city", System.Data.SqlDbType.VarChar, 20, "city"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@state", System.Data.SqlDbType.VarChar, 2, "state"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@zip", System.Data.SqlDbType.VarChar, 5, "zip"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@contract", System.Data.SqlDbType.Bit, 1, "contract"));
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT au_id, au_lname, au_fname, phone, address, city, state, zip, contract FROM" +
				" authors";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE authors SET au_id = @au_id, au_lname = @au_lname, au_fname = @au_fname, phone = @phone, address = @address, city = @city, state = @state, zip = @zip, contract = @contract WHERE (au_id = @Original_au_id) AND (address = @Original_address OR @Original_address IS NULL AND address IS NULL) AND (au_fname = @Original_au_fname) AND (au_lname = @Original_au_lname) AND (city = @Original_city OR @Original_city IS NULL AND city IS NULL) AND (contract = @Original_contract) AND (phone = @Original_phone) AND (state = @Original_state OR @Original_state IS NULL AND state IS NULL) AND (zip = @Original_zip OR @Original_zip IS NULL AND zip IS NULL); SELECT au_id, au_lname, au_fname, phone, address, city, state, zip, contract FROM authors WHERE (au_id = @au_id) ORDER BY au_id";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_id", System.Data.SqlDbType.VarChar, 11, "au_id"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_lname", System.Data.SqlDbType.VarChar, 40, "au_lname"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@au_fname", System.Data.SqlDbType.VarChar, 20, "au_fname"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@phone", System.Data.SqlDbType.VarChar, 12, "phone"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@address", System.Data.SqlDbType.VarChar, 40, "address"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@city", System.Data.SqlDbType.VarChar, 20, "city"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@state", System.Data.SqlDbType.VarChar, 2, "state"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@zip", System.Data.SqlDbType.VarChar, 5, "zip"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@contract", System.Data.SqlDbType.Bit, 1, "contract"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_id", System.Data.SqlDbType.VarChar, 11, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_id", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_address", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "address", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_fname", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_fname", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_au_lname", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "au_lname", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_city", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "city", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_contract", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "contract", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_phone", System.Data.SqlDbType.VarChar, 12, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "phone", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_state", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "state", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_zip", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "zip", System.Data.DataRowVersion.Original, null));
			// 
			// dataSet11
			// 
			this.dataSet11.DataSetName = "DataSet1";
			this.dataSet11.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet11.Namespace = "http://www.tempuri.org/DataSet1.xsd";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();

		}
		#endregion

	}
}
