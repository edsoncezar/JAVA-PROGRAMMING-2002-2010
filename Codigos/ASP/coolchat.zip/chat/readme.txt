COOL CHAT LITE beta1

This is a very basic version of the cool chat.It uses an access database and meta refresh to provide a simple chating interface.

REQUIREMENTS :
1.IIS or PWS.
2.Ability to use Accesss database.

INSTRUCTIONS :
1.Copy the folder named "db" to a location where you have write permission.
2.Change the database path in the "inc\db.inc" to reflect the new location of the database. 
 
FUTURE IMPROVEMENTS :
1.Ability to send smilies.
2.Ability to send private messages.
3.Ability to block particular user.

CONTACT :
ganesh gunasegaran
http://www.gg.now.nu
gg@now.nu