Thought of the Day BETA.

Instructions:
1.Set the DSN you want to the database file pod.mdb
2.Open the photooftheday.asp file and make the DSN Changes.
3.Open the table tblPhoto in the MS Access Database and add the thoughts and file names of the photos the you want.
4.Upload the photos in the same folder where you keep the .asp file
5.Open the file photooftheday.asp from your browser and it should work now, if all the steps 
above done correctly.



To be included in the future:
Full administraton for the siteoftheday.

Copyright Stylus Systems Pvt Ltd (http://www.indiawebdevelopers.com) 1999-2001