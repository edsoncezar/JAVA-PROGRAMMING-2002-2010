ABCEventLog 1.0

ABCEventLog is a set of Active Server Page (ASP) Extensions that allow you to put 
messages into the Event Log. It supports multiple event sources and remote event logging.

This version supports Windows NT 4.0 and Windows 2000.



BEFORE INSTALLATION:
To install, double click on the install.bat file.
To uninstall double-click the 'uninstall.bat' file. 
After uninstalling you can delete or move any of the ABCEventLog files.



AFTER INSTALLATION:
Look at the manual.



TO PURCHASE AND FOR SUPPORT:
ABCEventLog is free - see our web site http://www.websupergoo.com



