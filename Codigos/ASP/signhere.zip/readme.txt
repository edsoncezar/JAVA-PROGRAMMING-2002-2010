"Sign Here!" Guest Book

=============================
 Files:
 
DATABASE/gbdb.mdb   - guest book database (Access 2000)
DATABASE/gbdb97.mdb - guest book database (Access 97)
GBI/*.*             - icons, used as smiles. described in database
                      in table 'icons'
D/*.*               - images which is used in sample guestboog
gb_func.asp         - this file consist of functions needed to work
                      with guest book
gb.asp              - sample guest book

=============================
 Installation and use:
 
- copy all content to the root folder of your site
- now you can use gb.asp for the guestbook

- see sample for details

==============================
 Administering:
 
  You can login to the administration page using parameter
action=admin (in the sample - gb.asp?action=admin).
Default password in this package is "1".
  
  To edit or remove messages go to "view guestbook" mode after
login. "Edit" and "del" links will appear under each message.

==============================
 Contacts:

For further updates and more software:
http://www.softua.com

Questions about this guestbook:
signhere@softua.com or ask@softua.com
