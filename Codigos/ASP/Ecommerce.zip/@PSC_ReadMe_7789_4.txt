Title: Ecommerce administrator web-site
Description: This code is Update for "Shopping Cart with orders tracking" created by Andrus Kaurson.
The upgrade not exist, i have changed send objet email from old version in JMail to New version object CDONTS. Sorry, excuseme my language, I'm Italian boy. This application don't use the global.asa file, and fully functctionally in active permission folder!! Raccomanded configuring file co.asp for your server smtp and email for receive order by clients. Good administration web site ecommerce... 
ZeRoHaCk
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7789&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
