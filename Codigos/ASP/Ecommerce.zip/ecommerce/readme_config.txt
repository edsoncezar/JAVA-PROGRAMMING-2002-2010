Application write and realized by Andrus Kaurson
Update version for CDONTS object by ZeRoHaCk

English language:

Hallo,
This application for ecommerce web site, use the CDONTS object for send email to administrator.

For correct use this, setting the file "CO.ASP" in root folder in string 110, 115, 116.
Download all file and directory in Directory activate permission write, and good administration 

Italian Language:

Ciao,
Questo applicativo di ecommerce sul sito, usa l'Oggetto CDONTS per inviare le email all'amministratore.
Per un uso corretto di esso, devi settare il file "CO.ASP" alla riga 110, 115, 116.
Effettua il download di tutti i file e delle directory in una cartella che abbia i permessi di scrittura
e buona amministrazione.

ZeRoHaCk
 