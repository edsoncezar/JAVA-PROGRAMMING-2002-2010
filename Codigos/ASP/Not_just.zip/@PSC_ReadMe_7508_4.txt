Title: Not just another website statistic script...(fixed)
Description: This is a powerfull website statistic script. This can get various client information using a little simple javascript file. It will store this information in a database. It even does a IP lookup (partly adapted from the WhoisWhereis code from Eric Green). It comes with a number of statistics, and if you know a little SQL you could easely add you own. It even displays a bar graph of the visits of the last 30 days. Anyway, you should check it out. For the complete info, just read the readme file.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7508&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
