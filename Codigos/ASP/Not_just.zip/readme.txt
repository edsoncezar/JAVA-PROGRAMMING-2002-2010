Statistics script readme file
=============================

The script will collect various information of the visitor. For best use, link to the counter from every page that is to be considered a part of the site. This way, the information on the time spent on the site will be more acurate. The exact data the script collects can be found in the database. It also includes some statistics, but it isn't hard to come up with your own, all you need is a little knowledge of SQL.
 
You can link to the script using the following code

<script language="JavaScript" src="http://www.yoursite.com/stats/info.js">
</script>
<script language="JavaScript">
<!--
  GetStats('siteid','18');
// -->

The siteid must be replaced by the id you choose. In order to create a new id, you must make a copy of the 'empty' folder and give the folder the same name as your id (if the siteid is cakkie, you must have a folder named cakkie which contains the database)

The second parameter is the size of the images to show (logo.gif, which is placed in the same directory as the asp pages). if you set this to 0, the image will be hidden. Please note that you MUST enclose it in single quotes.

You must change the url used in the code. the path.to.javascipt must be changed to the server/folders where the scripts are stored (eg http://www.yoursite.com/stats/info.js) The same must be done in info.js, where there's a variable called srv, which contains the location of the scripts (eg http://www.yoursite.com/stats/), make sure that you end the name with a /, otherwise it won't work.

A working example can be found in the included info.htm, which links to a script which is placed on our company internal webserver (which is accessible from outside).

For any more info, remarks, suggestions, feedback, whatever, you can always email me at slisse@planetinternet.be