function GetStats(site,iconsize){

    // url where the page is submitted to
    // change this to the address the script resides on
	var srv="http://217.136.232.103/stats/";
	var u=srv+"info.asp?site="+escape(site);
	// where did he come from?	var r=document.referrer;
	// where is he now?	var d=document.location;
	// screen size	var s=screen.width + "x" + screen.height;
	// screen colordepth
	var c=screen.colorDepth	// browser	var n=navigator.appName + " " + navigator.appVersion + "." + navigator.appMinorVersion
	// cpu class, most likely is x86
	var cpu=navigator.cpuClass;	// platform
	var p=navigator.platform;	// random, to prevent the browser from taking a cached image and not do a call to the server	var rnd=Math.random();
	u+="&d="+escape(d)+"&r="+escape(r)+"&s="+escape(s)+"&c="+escape(c)+"&n="+escape(n)+"&cpu="+escape(cpu)+"&p="+escape(p)+"&rnd="+escape(rnd);
	document.write('<a target=_blank href="'+srv+'stats.asp?site='+escape(site)+'"><img src="'+u+'" border=0 width='+iconsize+' height='+iconsize+' alt="Statistics"></a>');

}