Welcome to the templater_asp website.     Put you content files such as main_body.html, into the content subdirectory, having only main window content.   You will need to register the asptear.dll on the server.  (this is for getting content from other websites)

You put content in the template with the content=  variable such as: 
http://servername/templater_asp/default.asp?content=content/main_body.html  (which is also the name of the main page)

Or you can get content from other websites via:
http://servername/templater_asp/default.asp?content=http://servername/someapp/thisapp.asp

The result of the .asp page will be put into the content window.

To change the menu selections edit the menu/menu_var.js file.

In a future version I will again implement the event listings, and headlines. The version on Senner.net is running on .php, which also will soon be available for download.

Check http://www.senner.net for updates. 
