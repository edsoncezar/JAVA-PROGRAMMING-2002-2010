<?
$docroot = $DOCUMENT_ROOT; //On Windows machines, you'll need to hard code the current path.

//Caluclation and configuration
$xval = explode(",", $xvar);
$num_xvalues = sizeof($xval);
if($width < $num_xvalues*60) { $width = $num_xvalues*60; }
if($height < (ImageFontWidth(round($height/200)) * strlen($ylabel))*1.5) { $height = (ImageFontWidth(round($height/200)) * strlen($ylabel))*1.5; }
$padding = .15; //Space around the chart for data, in percentage of width
$font_size = round($height/200);
$chart_width = $width*(1-(2*$padding));
$chart_height = $height*(1-(2*$padding));
$num_yvalues = floor($height/40);
$yval = explode(",", $yvar);
$max = max($yval);
$min = min($yval);
$bar_width = .4; //Percent of x-value area:bar width
$increment = ceil($max/$num_yvalues);
$chart_max = $increment*$num_yvalues;

//Create a blank image canvas
$image = ImageCreate($width, $height);

//Color Configuration
$bg_color = imagecolorallocate($image, 0xFF, 0xFF, 0xFF); //white
$border_color = imagecolorallocate($image, 0x00, 0x00, 0x00); //black
$fill_color = imagecolorallocate($image, 0xE2, 0xE2, 0xE2); //lt. gray
$line_color = imagecolorallocate($image, 0x00, 0x00, 0x00); //gray
$font_color = imagecolorallocate($image, 0x40, 0x40, 0x40); //dk. gray
$bar_color = imagecolorallocate($image, 0x99, 0x99, 0xFF); //lt. blue

//Draw the border and the basic chart outline
ImageRectangle($image, 0, 0, $width-1, $height-1, $border_color);
ImageFilledRectangle($image, $padding*$width, $padding*$height, $width-($width*$padding), $height-($height*$padding), $fill_color);
ImageRectangle($image, $padding*$width, $padding*$height, $width-($width*$padding), $height-($height*$padding), $line_color);

//Display the title at the top
$title_width = ImageFontWidth($fontsize+1) * strlen($title); 
$title_height = ImageFontHeight($fontsize+1);
ImageString($image, $font_size+1, ($width/2)-($title_width/2), ($height*$padding/2)-($title_height/2), $title, $font_color);

//Display the x and y titles
$ylabel_width = ImageFontWidth($fontsize) * strlen($ylabel); 
$font_height = ImageFontHeight($fontsize);
ImageStringUp($image, $font_size, ($width*$padding/4)-($font_height/2), ($height/2)+($ylabel_width/2), $ylabel, $font_color);

$xlabel_width = ImageFontWidth($fontsize) * strlen($xlabel); 
ImageString($image, $font_size, ($width/2)-($xlabel_width/2), ($height*(1-$padding/4))-($font_height/2), $xlabel, $font_color);

//Draw the horizontal lines and then the vertical ticks
for($a = 0; $a <= $chart_height; $a += ($chart_height/$num_yvalues)) {
	imageline($image, $padding*$width-5, $padding*$height+$a, $width-($width*$padding), $padding*$height+$a, $line_color);
}
for($a = 0; $a <= $chart_width; $a += ($chart_width/$num_xvalues)) {
	imageline($image, $padding*$width+$a, $height-($height*$padding), $padding*$width+$a, $height-($height*$padding)+5, $line_color);
}

//Draw the bars and labels
for($a = 0; $a < $num_xvalues; $a++) {
	$label_width = ImageFontWidth($fontsize) * strlen($xval[$a]); 
	$label_offset = ($width*$padding)+(($chart_width/$num_xvalues)*($a))+($chart_width/($num_xvalues*2))-($label_width/2);
	ImageString($image, $font_size, $label_offset, $height-($height*$padding*.95), $xval[$a], $line_color);
	$bar_xstart = ($width*$padding)+(($chart_width/$num_xvalues)*((1-$bar_width)/2))+($a*$chart_width/$num_xvalues);
	$bar_ystart = ($height-($height*$padding))-(($yval[$a]/$chart_max)*$chart_height);
	$bar_xend = $bar_xstart+(($chart_width/$num_xvalues)*$bar_width);
	ImageFilledRectangle($image, $bar_xstart, $bar_ystart, $bar_xend, $height-($height*$padding), $bar_color);
	ImageRectangle($image, $bar_xstart, $bar_ystart, $bar_xend, $height-($height*$padding), $line_color);
	/*
	* //Uncomment this code to display data values on bars
	* $label_width = ImageFontWidth($fontsize) * strlen($yval[$a]); 
	* ImageString($image, $font_size, $bar_xstart+(($bar_xend-$bar_xstart)/2)-($label_width/2), $bar_ystart, $yval[$a], $line_color);
	*/
}
for($a = 0; $a <= $num_yvalues; $a++) {
	$ylabel = $increment*$a;
	$label_width = ImageFontWidth($fontsize) * strlen($ylabel); 
	$label_offset = ($height-($height*$padding))-($chart_height/$num_yvalues)*$a-$font_height;
	ImageString($image, $font_size, $width*$padding-$label_width-8, $label_offset, $ylabel, $line_color);
}

// Flush Image 
header("Content-type: image/png");
ImagePNG($image);
ImageDestroy($image);
?>