Title: Simple Bar Chart Creator
Description: You can use this code to create simple bar charts on the fly. Currently, it only works well with values greater than 1. ZIP file includes code and sample usage. It's not perfect, but it works. Please vote if you find it useful. http://searchforcode.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=786&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
