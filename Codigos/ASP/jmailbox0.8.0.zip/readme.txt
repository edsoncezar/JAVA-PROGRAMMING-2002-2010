//===============================================
//   "JMailbox" Free Web Based Email Client. 
//
//   Copyright (C) 2002  Jan Mulder
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version, and as long as this notice is
//   provided unmodified with the script source code.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License (license.txt) for more details.
//
//   Contact: Jan Mulder feedback@JMailbox.org
//   Homepage: http://JMailbox.org
//  
//================================================

JMailbox is a complete web based email client written in 100% ASP 
using the JMail API.

JMailbox is not a replacement for your usual email client at home. 
It is the ideal companion for when you are travelling and still need full 
access to your email. With JMailbox you can send and receive mail from any 
POP account from any computer with internet access. 

It is very easy to install and use. Just unzip all the files and place them in a 
single folder on your website. To get it to work you just have to change the 
relevant server/password details in CONFIG.ASP file and that's it!

No other files need to be changed.

Configuration and troubleshooting information can be found in the HELP section
of the site.

Please include the small "Powered By JMailbox" image/link at the bottom of the 
program at all times. It is unobtrusive and just links to the JMailbox site.

I hope you enjoy using this program. 

