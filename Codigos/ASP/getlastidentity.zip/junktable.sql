/****** Object:  Table [dbo].[junkTable]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[junkTable]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[junkTable]
GO

/****** Object:  Table [dbo].[junkTable]    Script Date: 6/11/2001 5:42:11 AM ******/
CREATE TABLE [dbo].[junkTable] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[f1] [varchar] (10) NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[junkTable] WITH NOCHECK ADD 
	CONSTRAINT [PK_junkTable] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

