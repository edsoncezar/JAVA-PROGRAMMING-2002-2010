/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Jan 20 17:10:35 2001
 */
/* Compiler settings for C:\TEMP\tonec1sound\download\T1CSound\TONEC1.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ILongBeep = {0x75BD707D,0xEEC9,0x11D4,{0x8D,0xF0,0x00,0x80,0xAD,0x70,0x5C,0x3E}};


const IID LIBID_TONEC1Lib = {0x75BD7071,0xEEC9,0x11D4,{0x8D,0xF0,0x00,0x80,0xAD,0x70,0x5C,0x3E}};


const CLSID CLSID_LongBeep = {0x35F76122,0xE5FB,0x11D4,{0x8D,0xE0,0x00,0x80,0xAD,0x70,0x5C,0x3E}};


#ifdef __cplusplus
}
#endif

