/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Jan 20 17:10:35 2001
 */
/* Compiler settings for C:\TEMP\tonec1sound\download\T1CSound\TONEC1.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __TONEC1_h__
#define __TONEC1_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ILongBeep_FWD_DEFINED__
#define __ILongBeep_FWD_DEFINED__
typedef interface ILongBeep ILongBeep;
#endif 	/* __ILongBeep_FWD_DEFINED__ */


#ifndef __LongBeep_FWD_DEFINED__
#define __LongBeep_FWD_DEFINED__

#ifdef __cplusplus
typedef class LongBeep LongBeep;
#else
typedef struct LongBeep LongBeep;
#endif /* __cplusplus */

#endif 	/* __LongBeep_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ILongBeep_INTERFACE_DEFINED__
#define __ILongBeep_INTERFACE_DEFINED__

/* interface ILongBeep */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ILongBeep;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("75BD707D-EEC9-11D4-8DF0-0080AD705C3E")
    ILongBeep : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE BeepSound( 
            /* [in] */ long Frequency,
            /* [in] */ long Duration) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILongBeepVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILongBeep __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILongBeep __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILongBeep __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ILongBeep __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ILongBeep __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ILongBeep __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ILongBeep __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BeepSound )( 
            ILongBeep __RPC_FAR * This,
            /* [in] */ long Frequency,
            /* [in] */ long Duration);
        
        END_INTERFACE
    } ILongBeepVtbl;

    interface ILongBeep
    {
        CONST_VTBL struct ILongBeepVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILongBeep_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILongBeep_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILongBeep_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILongBeep_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILongBeep_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILongBeep_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILongBeep_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILongBeep_BeepSound(This,Frequency,Duration)	\
    (This)->lpVtbl -> BeepSound(This,Frequency,Duration)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILongBeep_BeepSound_Proxy( 
    ILongBeep __RPC_FAR * This,
    /* [in] */ long Frequency,
    /* [in] */ long Duration);


void __RPC_STUB ILongBeep_BeepSound_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILongBeep_INTERFACE_DEFINED__ */



#ifndef __TONEC1Lib_LIBRARY_DEFINED__
#define __TONEC1Lib_LIBRARY_DEFINED__

/* library TONEC1Lib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_TONEC1Lib;

EXTERN_C const CLSID CLSID_LongBeep;

#ifdef __cplusplus

class DECLSPEC_UUID("35F76122-E5FB-11D4-8DE0-0080AD705C3E")
LongBeep;
#endif
#endif /* __TONEC1Lib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
