// LongBeep.cpp : Implementation of CLongBeep
#include "stdafx.h"
#include "TONEC1.h"
#include "LongBeep.h"

/////////////////////////////////////////////////////////////////////////////
// CLongBeep


STDMETHODIMP CLongBeep::BeepSound(long Frequency, long Duration)
{
	BOOL b1;
	b1= Beep(Frequency, Duration);
	return S_OK;
}
