// LongBeep.h : Declaration of the CLongBeep

#ifndef __LONGBEEP_H_
#define __LONGBEEP_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CLongBeep
class ATL_NO_VTABLE CLongBeep : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CLongBeep, &CLSID_LongBeep>,
	public IDispatchImpl<ILongBeep, &IID_ILongBeep, &LIBID_TONEC1Lib>
{
public:
	CLongBeep()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_LONGBEEP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CLongBeep)
	COM_INTERFACE_ENTRY(ILongBeep)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ILongBeep
public:
	STDMETHOD(BeepSound)(/*[in]*/ long Frequency, /*[in]*/ long Duration);
};

#endif //__LONGBEEP_H_
