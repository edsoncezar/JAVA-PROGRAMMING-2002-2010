vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Feb 2002 05:50:13 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{403BFD4C-21B3-4FC8-9E2F-E5D88274AA36}
vti_author:SR|WEBSTRIKE\\setcomputing
vti_modifiedby:SR|WEBSTRIKE\\setcomputing
vti_nexttolasttimemodified:TR|14 Feb 2002 04:37:01 -0000
vti_timecreated:TR|13 Feb 2002 23:33:57 -0000
vti_parentlineageid:SR|{2A54A63B-7D73-41D1-9758-B674F6B8CDCB}
vti_cacheddtm:TX|14 Feb 2002 05:50:13 -0000
vti_filesize:IR|1911
vti_backlinkinfo:VX|
