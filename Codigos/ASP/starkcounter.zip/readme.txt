******************************
****  STARK Counter v1.0  ****
******************************
By Magnus Stark 
E-mail: scripts@starkwebdesign.com
URL: http://www.starkwebdesign.com/scripts

History ---------------------------------

* 8/3/00 Script created.

Install instructions --------------------

1. Unzip the contents of starkcounter10.zip
   to your hard drive.
2. Open config.asp and make any necessary
   changes.
3. Upload ALL of the files to your server.
4. Add <!-- #include virtual="/counter.asp"-->
   to the ASP files you want to include a
   counter in.

   ***** Use this script at your own risk. I can't be held responsible
         any lost of profit, security breach.... that could be caused
		 by this script ******