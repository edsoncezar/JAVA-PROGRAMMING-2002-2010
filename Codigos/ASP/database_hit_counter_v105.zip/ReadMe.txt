Surf-net database hit counter realease v1.5 beta


The Surf-net database hit counter v1.5 beta is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without permission.             **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!



If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail



The hit counter uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the database hit counter

Unzip all the files to the same directory.

Files must be run through an ASP enabled web sever.

No data needs to be placed in the Access 2000 hit_count database as every page the asp hit counter is placed on an entry will automactically be written to the database.

The hit counter can be used on multiple pages by placing the following line at the top of each asp page requiring a hit counter: -

	<%
	'Dimenstion Variables
	Dim strDatabasePath 	

	'Initialise the path to the access database if inside another folder
	strDatabasePath = ("")

	'Call the sub procedure to increment the hit counters
	Call IncrementHitCount(strDatabasePath)
	%>
	

The following line must also be put in the HTML of the page not between <%  %>: -
	
	<!-- #INCLUDE FILE="hit_count.inc" -->


The hit counters are hidden so to view the hit counters use the admin page supplied.

The admin page shows a total hit counter and another that can be reset for each page the hit counter is on.

Dates the hit counters are from are also displayed on the hit counters admin page.


If the web page that the hit couter is on is not in the same folder then make sure the strDatabasePath variable holds the correct path to the database, but not the database name. 
Also make sure that the path to the hit_count.inc is changed to the correct path (keep the hit_count database and include file in the root directory of your website).



If you recieve the following error: -

Microsoft OLE DB Provider for ODBC Drivers error '80004005' 
[Microsoft][ODBC Microsoft Access Driver] Operation must use an updateable query.

This means that the directory the database is in does not have the right permissions to be able to write to the database. 

If you are running the server yourself then you can change the permissions by right clicking on the folder containing the database and choose sharing, then choose permissions, add IUser_yourcomputername with the permssion set to allow change.

If you are not running the server yourself then you will need to contact the server's adminstrator and ask them to change the permissions otherwise you cannot update a database.




If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ


