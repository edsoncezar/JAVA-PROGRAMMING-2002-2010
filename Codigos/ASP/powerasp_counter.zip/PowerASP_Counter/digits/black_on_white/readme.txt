These digits were created by Chris Williams of www.PowerASP.com from scratch.

Primarily to be used with any counter systems.

If this digit archive is distributed in any
way this text file must remain in tact.

Enjoy..

