package Synchronization;

public final class NotImplementedMethodException extends RuntimeException {
   public NotImplementedMethodException () {super();}
}
