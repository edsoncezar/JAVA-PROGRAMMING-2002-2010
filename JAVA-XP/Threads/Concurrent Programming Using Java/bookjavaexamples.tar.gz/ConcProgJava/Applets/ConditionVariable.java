public class ConditionVariable { // not yet implemented

   public void waitCV(Object monitor) {}

   public void notifyCV(Object monitor) {}

   public boolean emptyCV(Object monitor) {return true;}
}
