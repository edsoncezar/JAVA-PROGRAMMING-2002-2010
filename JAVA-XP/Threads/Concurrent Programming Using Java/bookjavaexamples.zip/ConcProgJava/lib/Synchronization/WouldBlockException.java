package Synchronization;

public class WouldBlockException extends Exception {}
