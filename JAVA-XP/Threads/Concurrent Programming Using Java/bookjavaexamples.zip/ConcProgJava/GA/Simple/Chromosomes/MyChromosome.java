package Chromosomes;

public final class MyChromosome extends

// Put your Chromosome class name here (comment out the others):

   BigBitCountChromosome

   // BitCountChromosome
   // XtoTenthChromosome
   // SinesChromosome
   // ByteCountChromosome

   {public MyChromosome() {super();}
}
