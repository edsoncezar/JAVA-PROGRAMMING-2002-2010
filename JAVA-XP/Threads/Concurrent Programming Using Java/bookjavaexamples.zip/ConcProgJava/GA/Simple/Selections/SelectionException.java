package Selections;

public class SelectionException extends Exception {
   SelectionException() {super("SelectionException");}
   SelectionException(String name) {super(name);}
}
