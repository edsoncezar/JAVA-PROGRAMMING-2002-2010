public class WouldBlockException extends Exception {}
