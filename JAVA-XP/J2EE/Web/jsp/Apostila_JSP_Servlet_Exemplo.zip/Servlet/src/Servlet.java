/**
 * Exemplo de um Servlet que implementa os m�todos init, doGet,
 * doPost, doPut e doDelete e destroy
 */

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Servlet extends HttpServlet {

  private static final String CONTENT_TYPE = "text/html";

  /**
   * M�todo executado pelo container na primeira execu��o do Servlet
   * @throws ServletException
   */
  public void init() throws ServletException {
     //  inicializa��o de vari�veis ou aloca��o de recursos
     System.out.println("M�todo init() do servlet Sevler.java executado");
     System.out.println("getServletInfo() : " + getServletInfo());
     System.out.println("getServletName() : " + getServletName());
  }

  /**
   * M�todo executado a cada solicita��o GET
   * @param request objeto representando o request
   * @param response objeto representando o response
   * @throws ServletException
   * @throws IOException
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet</title></head>");
    out.println("<body>");
    out.println("<p><b>Resposta � solicita��o HTTP Get</b></p>");

    processRequest(request, out);

    out.println("</body></html>");
  }

  /**
   * M�todo executado a cada solicita��o POST
   * @param request objeto representando o request
   * @param response objeto representando o response
   * @throws ServletException
   * @throws IOException
   */
  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet</title></head>");
    out.println("<body>");
    out.println("<p><b>Resposta � solicita��o HTTP Post</b></p>");

    processRequest(request, out);

    out.println("</body></html>");
  }

  /**
   * M�todo executado a cada solicita��o PUT
   * @param request
   * @param response
   * @throws ServletException
   * @throws IOException
   */
  public void doPut(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
  }

  /**
   * M�todo executado a cada solicita��o DELETE
   * @param request objeto representando o request
   * @param response objeto representando o response
   * @throws ServletException
   * @throws IOException
   */
  public void doDelete(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
  }

  /**
   * M�todo executado quando o servlet for destru�do pelo container
   */
  public void destroy() {
    // libera��o de recursos alcados no init
  }

  private void processRequest(HttpServletRequest request, PrintWriter out) {
    out.println("<p><b>Par�metros fornecidos no request.</b></p>");
    /* Obtendo o nome de todos os par�metros da solicita��o */
    Enumeration paramNames = request.getParameterNames();
    /* Para cada parametro obtendo o seu valor */
    while (paramNames.hasMoreElements()) {
      String paramName = (String) paramNames.nextElement();
      String paramValue = request.getParameter(paramName);
      /* Escrevendo cada valor no objeto response */
      out.println(paramName + " = " + paramValue + "<br>");
    }
    /* Obtendo informa��es do request */
    out.println("<p><b>Informa��es obtidas do request.</b></p>");
    out.println("request.getContentType() : " +
                request.getContentType() + "<br>");
    out.println("request.getContextPath() : " +
                request.getContextPath() + "<br>");
    out.println("request.getMethod() : " +
                request.getMethod() + "<br>");
    out.println("request.getQueryString() : " +
                request.getQueryString() + "<br>");
    out.println("request.getRemoteAddr() : " +
                request.getRemoteAddr() + "<br>");
    out.println("request.getRemoteUser() : " +
                request.getRemoteUser() + "<br>");
    out.println("request.getRequestURI() : " +
                request.getRequestURI() + "<br>");
    out.println("request.getServerName() : " +
                request.getServerName() + "<br>");
    out.println("request.getServerPort() : " +
                request.getServerPort() + "<br>");
    out.println("request.getServletPath() : " +
                request.getServletPath() + "<br>");
  }
}