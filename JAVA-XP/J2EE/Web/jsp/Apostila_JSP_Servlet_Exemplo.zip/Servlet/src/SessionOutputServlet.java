import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class SessionOutputServlet extends HttpServlet {

  private static final String CONTENT_TYPE = "text/html";

  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    /* Obtendo a sess�o do usu�rio */
    HttpSession session = request.getSession();
    /* Obtendo os par�metros da sess�o */
    String p1 = (String) session.getAttribute("p1");
    String p2 = (String) session.getAttribute("p2");

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>SessionOutputServlet</title></head>");
    out.println("<body>");
    out.println("<p><b>Par�metos obtidos da sess�o.</b></p>");
    out.println("p1 = " + p1 + "</p>");
    out.println("p2 = " + p2 + "</p>");
    out.println("</body></html>");
  }
}
