import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class CookieReadServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";

  public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    /* Obtendo todos os Cookies */
    Cookie[] cookies = request.getCookies();
    /* Escrevendo todos os Cookies */
    StringBuffer resp = new StringBuffer("");
    if (cookies != null ) {
      for (int i = 0; i < cookies.length; i++ ) {
        Cookie cookie = cookies[i];
        resp.append(cookie.getName() + " = " + cookie.getValue() + "<br>");
      }
    }

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Cookies lidos da m�quina cliente.</title></head>");
    out.println("<body>");
    out.println(resp);
    out.println("</body></html>");
  }
}
