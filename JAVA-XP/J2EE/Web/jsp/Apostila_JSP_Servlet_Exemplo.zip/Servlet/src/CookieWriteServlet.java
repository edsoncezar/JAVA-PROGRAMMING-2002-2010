import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class CookieWriteServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";

  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    /* Obtendo os par�metros com o nome e o valor do cookie */
    String name = request.getParameter("name");
    String value = request.getParameter("value");
    /* Criando o cookie, com o nome e valor fornecidos */
    Cookie cookie = new Cookie(name, value);
    /*
     * Setando o tempo (segundos) de vida do cookie.
     * O padr�o � -1 -> somente enquanto o browser estiver aberto
     */
    cookie.setMaxAge(3600);
    /* Escrevendo o Cookie */
    response.addCookie(cookie);
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>CookieWriteServlet</title></head>");
    out.println("<body>");
    out.println("<p>Cookie :[" + name + "," + value + "] escrito</p>");
    out.println("</body></html>");
  }
}
