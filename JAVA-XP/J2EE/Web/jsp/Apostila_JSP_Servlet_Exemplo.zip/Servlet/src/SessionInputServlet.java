import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class SessionInputServlet extends HttpServlet {

  private static final String CONTENT_TYPE = "text/html";

  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    /* Obtendo a sess�o do usu�rio */
    HttpSession session = request.getSession();
    /* Obtendo os par�metros do request */
    String p1 = (String) request.getParameter("p1");
    String p2 = (String) request.getParameter("p2");
    /* Colocando os par�metros na sess�o */
    session.setAttribute("p1", p1);
    session.setAttribute("p2", p2);

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>SessionInputServlet</title></head>");
    out.println("<body>");
    out.println("<p><b>Par�metros colocados na sess�o.</b></p>");
    out.println("p1 = " + p1 + "</p>");
    out.println("p2 = " + p2 + "</p>");
    out.println("</body></html>");
  }
}
