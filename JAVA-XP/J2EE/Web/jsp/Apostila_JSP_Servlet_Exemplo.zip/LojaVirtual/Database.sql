INTERBASE_DRV =	"interbase.interclient.Driver"
SQLSERVER_DRV =	"com.microsoft.jdbc.sqlserver.SQLServerDriver"
ORACLE_DRV    = "oracle.jdbc.driver.OracleDriver"
INTERBASE_URL = "jdbc:interbase://localhost/D:/.../Arquivo.gdb"
SQLSERVER_URL =	"jdbc:microsoft:sqlserver://localhost:1433"
ORACLE_URL    =	"jdbc:oracle:thin:@localhost:1521:ORCL";

[DRIVER]
  com.microsoft.jdbc.sqlserver.SQLServerDriver
[URL]
  jdbc:microsoft:sqlserver://localhost:1433
[USER]
  LojaVirtual
[PASSWORD]
  LojaVirtual
[SELECT_PRODUTO]
  select *
    from produto
    where codigo = ?
[INSERT_CLIENTE]
  insert into Cliente
   ( email, nome, rua, bairro, numero, complemento, cep, senha )
   values(?,?,?,?,?,?,?,?)
[SELECT_LOGIN]
  select senha
    from Cliente
    where email = ?
[INSERT_PEDIDO]
  insert into Pedido ( data, email )
    values(?,?)
[INSERT_PEDIDO_PRODUTO]
  insert into PedidoProduto
    ( email, dataPedido, codigoProduto, Preco, Quantidade )
    values(?,?,?,?,?)