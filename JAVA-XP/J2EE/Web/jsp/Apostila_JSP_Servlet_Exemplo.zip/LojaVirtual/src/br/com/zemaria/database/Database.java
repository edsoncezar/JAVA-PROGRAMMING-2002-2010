package br.com.zemaria.database;

import java.sql.*;
import java.io.*;
import java.util.*;

/**
 * Classe representando uma estrat�gia simplificada de acesso a banco de dados
 * via JDBC, um aspecto importante nessa classe � utiliza��o de um arquivo
 * contendo as defini��es de : driver, url, usu�rio, senha e comandos sql num
 * arquivo texto. O qual deve seguir a seguinte a seguinte estrutura: <br>
 * [DRIVER]  com.inet.tds.TdsDriver <br>
 * [URL]  jdbc:inetdae:localhost?sql7=true&database=LojaVirtual<br>
 * [USER]  USR_LOJAVIRTUAL<br>
 * [PASSWORD]  USR_LOJAVIRTUAL<br>
 * [NOME_DO_COMANDO_SQL_1]<br>
 *   comando sql<br>
 * [NOME_DO_COMANDO_SQL_1]<br>
 *   comando sq2<br>
 * [NOME_DO_COMANDO_SQL_n]<br>
 *   comando n<br>
 *
 * Obs: O nome do arquivo contendo as defini��es sql deve ser passado no
 * construtor, assim qualquer intera��o com o banco de dados ser� atrav�s
 * das informa��es contidas nesse arquivo.
 */

public class Database {

  /* Conex�o com o banco de dados */
  private Connection connection;
  /* Hashtable para armazenar todas as entradas do arquivo defini��es */
  private Hashtable template;

  /**
   * Contrutor para inicializar o objeto Database com as defini��es contidas
   * no arquivo de configura��o
   * @param sqlFileName Nome do arquivo de configura��o
   */
  public Database (String sqlFileName)
    throws Exception {
    String sqlFile = getTextFile(sqlFileName);
    template = new Hashtable();
    loadTemplate(template, sqlFile);
    String driver = (String) template.get("DRIVER");
    String url      = (String) template.get("URL");
    String user     = (String) template.get("USER");
    String password = (String) template.get("PASSWORD");
    if ( driver == null ) {
      String msg = "Defini��o [DRIVER] ou seu conte�do n�o enconttrado no " +
                   "arquivo de configura��o.";
      throw new Exception (msg);
    }
    if ( url == null ) {
      String msg = "Defini��o [URL] ou seu conte�do n�o enconttrado no " +
                   "arquivo de configura��o.";
      throw new Exception (msg);
    }
    if ( user == null ) {
      String msg = "Defini��o [USER] ou seu conte�do n�o enconttrado no " +
                   "arquivo de configura��o.";
      throw new Exception (msg);
    }
    if ( password == null ) {
      String msg = "Defini��o [PASSWORD] ou seu conte�do n�o enconttrado no " +
                   "arquivo de configura��o.";
      throw new Exception (msg);
    }
    try {
      Class.forName(driver);
      connection = DriverManager.getConnection(url, user, password);
    } catch (ClassNotFoundException e) {
      String msg = "Driver JDBC n�o encontrado : " + driver;
      throw new Exception (msg);
    } catch (SQLException e) {
      String msg = "Erro na conex�o ao banco de dados : \n" +
                   "url     = " + url + "\n" +
                   "usu�rio = " + user + "\n" +
                   "senha   = " + password;
      throw new Exception (msg);
    } catch (Exception e) {
      String msg = "Erro n�o esperado : " + e.getMessage();
      throw new Exception (msg);
    }
  }

  /**
   * M�todo para executar um comando sql de consulta
   * @param sql Consulta sql a ser executada
   * @return retorno da execu��o da consulta solicitada
   */
  public final ResultSet executeQuery (String sql ) throws  Exception {
    Statement statement = connection.createStatement();
    return statement.executeQuery(sql);
  }

  /**
   * M�todo para executar um comando SQL de atualiza��o
   * @param sql comando SQL de atualiza��o a ser executado
   * @return int quantidade de linhas afetadas pela execu��o do comando SQL
   * solicitado
   */
  public final int executeUpdate (String sql ) throws  Exception {
    Statement statement = connection.createStatement();
    return statement.executeUpdate(sql);
  }

  /**
   * M�todo para retornar um PreparedStatement j� carregado com o comando sql
   * contido no arquivo de configura��o sobre a template informada.<br>
   * Exemplo : <br>
   * [TEMPLATE_NAME]<br>
   *   comando sql<br>
   * Assim, basta setar os parametros e em seguida executar o PreparedStatement.
   * @return objeto Statement
   */
  public final PreparedStatement getPreparedStatement (String templateName)
    throws  Exception  {
    String template = this.getTemplate(templateName);
    return connection.prepareStatement(template);
  }

  /**
   * M�todo para finalize, para ser usado pelo Garbage Collector, finalizando a
   * conex�o
   */
  public void finalize () throws Exception {
    connection.close();
  }

  /**
   * M�todo para retornar o conte�do de um template do arquivo de configura��o
   * @param label Nome do template
   * @return conte�do do template
   */
  public final String getTemplate (String label) {
    return (String) template.get(label);
  }

  /**
   * M�todo para carregar o arquivo de template do disco para um Hashtable
   **/
  public final void loadTemplate (Hashtable template, String sqlFile)
    throws Exception {
    int start = 0;
    int end = sqlFile.length();
    while ( start < end ) {
      int startLabel = sqlFile.indexOf("[", start);
      int endLabel = sqlFile.indexOf("]", startLabel);
      String label = sqlFile.substring(startLabel + 1, endLabel);
      int startText = endLabel + 1;
      int endText = sqlFile.indexOf("[", startText);
      if ( endText == -1 ) {
        endText = end;
      }
      String text = sqlFile.substring(startText, endText);
      template.put(label, text.trim());
      start = endText;
    }
  }

  /**
   * M�todo utilit�rio para ler o conte�do de um arquivo texto
   * @param nome do arquivo texto
   * @return conte�do do arquivo texto
   */
  public final static String getTextFile (String fileName)
    throws Exception {
    Reader reader = null;
    try {
      if ( reader == null )
        reader = new FileReader( fileName );
    } catch (FileNotFoundException e) {
      throw new Exception( "Arquivo n�o encontrado" + fileName);
    }
    try {
      StringBuffer content = new StringBuffer();
      BufferedReader is = new BufferedReader(reader);
      String linha = is.readLine();
      while ( linha != null ) {
        content.append( linha ).append( "\r\n");
        linha = is.readLine();
      }
      return content.toString();
    } catch (IOException e) {
      throw new Exception( "Erro de leitura do arquivo : " + fileName);
    } finally {
      try {
        reader.close();
      } catch(IOException e) {
        throw new Exception( "Erro fechando arquivo : " + fileName);
      }
    }
  }
}