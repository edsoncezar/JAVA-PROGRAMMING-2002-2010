CREATE TABLE [dbo].[CategoriaProduto] (
	[codigo] [numeric](3, 0) NOT NULL ,
	[Descricao] [varchar] (50) NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Cliente] (
	[email] [varchar] (50) NOT NULL ,
	[nome] [varchar] (50) NOT NULL ,
	[rua] [varchar] (50) NOT NULL ,
	[bairro] [varchar] (50) NOT NULL ,
	[numero] [varchar] (5) NOT NULL ,
	[complemento] [varchar] (50) NULL ,
	[cep] [char] (8) NULL ,
	[telefone] [varchar] (20) NULL ,
	[senha] [varchar] (10) NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Pedido] (
	[email] [varchar] (50) NOT NULL ,
	[data] [datetime] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[PedidoProduto] (
	[email] [varchar] (50) NOT NULL ,
	[dataPedido] [datetime] NOT NULL ,
	[codigoProduto] [numeric](5, 0) NOT NULL ,
	[preco] [numeric](10, 2) NOT NULL ,
	[quantidade] [numeric](3, 0) NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Produto] (
	[codigo] [numeric](5, 0) NOT NULL ,
	[descricao] [varchar] (50) NOT NULL ,
	[preco] [numeric](5, 2) NOT NULL ,
	[categoria] [numeric](3, 0) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CategoriaProduto] WITH NOCHECK ADD
	CONSTRAINT [PK_CategoriaProduto] PRIMARY KEY  CLUSTERED
	(
		[codigo]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[Cliente] WITH NOCHECK ADD
	CONSTRAINT [PK_Cliente] PRIMARY KEY  CLUSTERED
	(
		[email]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[Pedido] WITH NOCHECK ADD
	CONSTRAINT [PK_Pedido] PRIMARY KEY  CLUSTERED
	(
		[email],
		[data]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[PedidoProduto] WITH NOCHECK ADD
	CONSTRAINT [PK_PedidoProduto] PRIMARY KEY  CLUSTERED
	(
		[email],
		[dataPedido],
		[codigoProduto]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[Produto] WITH NOCHECK ADD
	CONSTRAINT [PK_Produto] PRIMARY KEY  CLUSTERED
	(
		[codigo]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[Pedido] ADD
	CONSTRAINT [FK_Pedido_Cliente] FOREIGN KEY
	(
		[email]
	) REFERENCES [dbo].[Cliente] (
		[email]
	) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[PedidoProduto] ADD
	CONSTRAINT [FK_PedidoProduto_Pedido] FOREIGN KEY
	(
		[email],
		[dataPedido]
	) REFERENCES [dbo].[Pedido] (
		[email],
		[data]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_PedidoProduto_Produto] FOREIGN KEY
	(
		[codigoProduto]
	) REFERENCES [dbo].[Produto] (
		[codigo]
	) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Produto] ADD
	CONSTRAINT [FK_Produto_CategoriaProduto] FOREIGN KEY
	(
		[categoria]
	) REFERENCES [dbo].[CategoriaProduto] (
		[codigo]
	) ON DELETE CASCADE
GO

insert into CategoriaProduto (codigo, descricao) values ('001', 'Categotia 1')
go
insert into CategoriaProduto (codigo, descricao) values ('002', 'Categotia 2')
go
insert into CategoriaProduto (codigo, descricao) values ('003', 'Categotia 3')
go
insert into CategoriaProduto (codigo, descricao) values ('004', 'Categotia 4')
go
insert into CategoriaProduto (codigo, descricao) values ('005', 'Categotia 5')
go
insert into CategoriaProduto (codigo, descricao) values ('006', 'Categotia 6')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (1, 'Produto 1', 11.11, '001')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (2, 'Produto 2', 22.22, '001')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (3, 'Produto 3', 33.33, '001')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (4, 'Produto 4', 44.44, '001')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (5, 'Produto 5', 55.55, '002')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (6, 'Produto 6', 66.66, '002')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (7, 'Produto 7', 77.77, '003')
go
insert into Produto (codigo, descricao, preco, categoria)
  values (8, 'Produto 8', 88.88, '003')
go