/**
 * StockMarket
 */

package SimpleStocks;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class StockMarketImpl 
  extends UnicastRemoteObject implements StockMarket { 

  public StockMarketImpl( String name ) throws RemoteException { 
    try { 
      Naming.rebind( name, this );
    }
    catch( Exception e ) { 
      System.out.println( e );
    }
  }

  public float get_price( String symbol ) { 
    float price = 0;
    for( int i = 0; i < symbol.length(); i++ ) { 
      price += (int) symbol.charAt( i );
    }
    price /= 5;
    return price;
  }

} 