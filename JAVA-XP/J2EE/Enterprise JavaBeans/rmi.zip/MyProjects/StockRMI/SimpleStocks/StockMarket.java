package SimpleStocks;
import java.util.*;
import java.rmi.*;

public interface StockMarket extends java.rmi.Remote {
  float get_price( String symbol ) throws RemoteException;
}