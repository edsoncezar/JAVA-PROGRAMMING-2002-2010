/**
 * StockMarketClient
 */
import java.rmi.*;
import java.rmi.registry.*;
import SimpleStocks.*;

public class StockMarketClient { 
  
  public static void main(String[] args) { 
    try { 
      if(System.getSecurityManager() == null) { 
        System.setSecurityManager( new RMISecurityManager() );
      }
      StockMarket market = (StockMarket)Naming.lookup("rmi://localhost/NASDAQ");
      System.out.println( "The price of MY COMPANY is "
                          + market.get_price("MY_COMPANY") );
    }
    catch( Exception e ) { 
      System.out.println( e );
    }
  }

}
