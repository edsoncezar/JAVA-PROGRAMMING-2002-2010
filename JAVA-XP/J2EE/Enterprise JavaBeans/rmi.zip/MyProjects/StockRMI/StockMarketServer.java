/**
 * Title:        
 * Version:      
 * Copyright:    Copyright (c) 1998
 * Author:       Gopalan Suresh Raj
 * Company:      
 * Description:  
 */

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import SimpleStocks.*;

public class StockMarketServer { 

  public static void main(String[] args) throws Exception { 
    if(System.getSecurityManager() == null) { 
      System.setSecurityManager( new RMISecurityManager() );
    }
    StockMarketImpl myObject = new StockMarketImpl( "NASDAQ" );
    System.out.println( "RMI StockMarketServer ready..." );
  }
}
