/**
 * The following example illustrates an RMI-IIOP Client
 * 
 * author: Gopalan Suresh Raj
 * Copyright (c), 2002. All Rights Reserved.
 * URL: http://gsraj.tripod.com/
 * email: gopalan@gmx.net
 */
package RmiClient;

import java.util.Properties;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import SimpleStocks.StockMarket;

/**
 * This Client looks up the price of a given Stock Symbol
 * 
 * Pre-requisites: You will need to have the COS naming server
 * and the StockMarket Server up and running before you can 
 * invoke them from this client.
 * 
 * @author Gopalan Suresh Raj
 */
public class RmiClient { 
  
  static final String CONTEXT_NAME = "java.naming.factory.initial";
  static final String IIOP_STRING  = "com.sun.jndi.cosnaming.CNCtxFactory";
  
  static final String URL_NAME = "java.naming.provider.url";
  static final String IIOP_URL_STRING  = "iiop://localhost:1000";
  
  /**
   * Entry Point to this Application
   */
  public static void main( String[] args ) { 
    
    try {
      // Create the IIOP Initial Context
      Properties iiopProperties = new Properties();
      iiopProperties.put( RmiClient.CONTEXT_NAME, 
                          RmiClient.IIOP_STRING );
      iiopProperties.put( RmiClient.URL_NAME, 
                          RmiClient.IIOP_URL_STRING );
      InitialContext iiopContext = new InitialContext( iiopProperties );
      
      // Obtain a reference to the Servant Object
      StockMarket server = (StockMarket) PortableRemoteObject.narrow( iiopContext.lookup ( "NASDAQ" ),
                                                                      StockMarket.class );

      // Invoke the Servant
      System.out.println( "The price of MY COMPANY is " +
                          server.getPrice( "MY_COMPANY" ) );       
    }
    catch ( Exception exception ) {
      exception.printStackTrace ();
    }    
    
  }
}
