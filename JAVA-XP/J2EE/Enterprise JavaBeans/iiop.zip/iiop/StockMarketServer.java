/**
 * The following example illustrates an RMI-IIOP Server
 * 
 * author: Gopalan Suresh Raj
 * Copyright (c), 2002. All Rights Reserved.
 * URL: http://gsraj.tripod.com/
 * email: gopalan@gmx.net
 */

import java.util.Properties;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import SimpleStocks.StockMarketImpl; 

/**
 * Creates a Server and binds the RMI Servant with the IIOP Registry
 * 
 * Pre-requisites: You will need to have the COS naming server
 * running for the registration code to work.
 * 
 * @author Gopalan Suresh Raj
 */
public class StockMarketServer { 
  
  static final String CONTEXT_NAME = "java.naming.factory.initial";
  static final String IIOP_STRING  = "com.sun.jndi.cosnaming.CNCtxFactory";
  
  static final String URL_NAME = "java.naming.provider.url";
  static final String IIOP_URL_STRING  = "iiop://localhost:1000";
  
  /**
   * Entry Point to this application
   */
  public static void main(String[] args) { 
    try {
      
      // Create the Object
      StockMarketImpl myObject = new StockMarketImpl(); 
      
      // Create the IIOP Initial Context
      Properties iiopProperties = new Properties();
      iiopProperties.put( StockMarketServer.CONTEXT_NAME, 
                          StockMarketServer.IIOP_STRING );
      iiopProperties.put( StockMarketServer.URL_NAME, 
                          StockMarketServer.IIOP_URL_STRING );
      InitialContext iiopContext = new InitialContext( iiopProperties );

      // Bind the object to the IIOP registry
      iiopContext.rebind( "NASDAQ", myObject );
      
      System.out.println( "StockMarket bound in the IIOP Registry as NASDAQ and is up and ready for eCommerce..." ); 
    }
    catch ( Exception exception ) {
      exception.printStackTrace ();
    }
  } 
} 

