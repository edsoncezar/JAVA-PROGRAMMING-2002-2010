/**
 * The following example illustrates an RMI-IIOP Servant
 * 
 * author: Gopalan Suresh Raj
 * Copyright (c), 2002. All Rights Reserved.
 * URL: http://gsraj.tripod.com/
 * email: gopalan@gmx.net
 */

package SimpleStocks; 

import java.rmi.RemoteException; 
import javax.rmi.PortableRemoteObject;

/**
 * This component looks up the price of a given Stock Symbol
 * 
 * @author Gopalan Suresh Raj
 */
public class StockMarketImpl extends PortableRemoteObject 
                             implements StockMarket { 

  /**
   * Public No argument constructor
   */
  public StockMarketImpl() throws RemoteException { 
    // Invoke the superclass to export this object
    super();
  } 

  /**
   * Remote method that actually contains the business logic.
   * 
   * @param stock symbol String denoting the stock to look up.
   * @return price of the stock as a float
   */
  public float getPrice( String stockSymbol ) throws RemoteException { 
    float price = 0; 
    for( int index = 0; index < stockSymbol.length(); index++ ) { 
      price += (int) stockSymbol.charAt( index ); 
    } 
    price /= 5; 
    System.out.println ("Value of "+stockSymbol+" is US $"+price);
    return price; 
  } 

} 
