/**
 * The following example illustrates an RMI Server
 * 
 * author: Gopalan Suresh Raj
 * Copyright (c), 2002. All Rights Reserved.
 * URL: http://gsraj.tripod.com/
 * email: gopalan@gmx.net
 */

package SimpleStocks; 

import java.rmi.Remote; 
import java.rmi.RemoteException; 

/**
 * This is an interface to a component that looks up 
 * the price of a given Stock Symbol
 * 
 * @author Gopalan Suresh Raj
 */
public interface StockMarket extends Remote { 
  
  /**
   * Remote method that should contain the business logic.
   * 
   * @param stock symbol String denoting the stock to look up.
   * @return price of the stock as a float
   */  
  float getPrice( String stockSymbol ) throws RemoteException; 
}

