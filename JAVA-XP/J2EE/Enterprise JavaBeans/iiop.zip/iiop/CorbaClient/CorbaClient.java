/**
 * The following example illustrates a CORBA Client
 * 
 * author: Gopalan Suresh Raj
 * Copyright (c), 2002. All Rights Reserved.
 * URL: http://gsraj.tripod.com/
 * email: gopalan@gmx.net
 */
package CorbaClient;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;
import org.omg.CosNaming.NameComponent;

import SimpleStocks.StockMarket;
import SimpleStocks.StockMarketHelper;

/**
 * This Client looks up the price of a given Stock Symbol
 * 
 * Pre-requisites: You will need to have the COS naming server
 * and the StockMarket Server up and running before you can 
 * invoke them from this client.
 * 
 * @author Gopalan Suresh Raj
 */
public class CorbaClient { 
  
  /**
   * Entry Point to this Application
   */  
  public static void main( String[] args ) { 
    
    try {
      
      // Create and Initialize the ORB
      ORB orb = ORB.init( args, null );
      org.omg.CORBA.Object object = orb.resolve_initial_references( "NameService" );
      NamingContext context = NamingContextHelper.narrow( object );
      System.out.println ( "The ORB has been created and initialized ..." );
      
      // Resolve the object reference in naming
      NameComponent component = new NameComponent( "NASDAQ", "" );
      NameComponent path [] = { component };
      StockMarket server = StockMarketHelper.narrow( context.resolve( path ) );
      System.out.println ( "The Object Reference has been resolved in Naming ..." );
      
      // Invoke the Servant
      System.out.println( "The price of MY COMPANY is " +
                          server.getPrice( "MY_COMPANY" ) );       
      
    }
    catch ( Exception exception ) {
      exception.printStackTrace();
    }
    
  }
}
