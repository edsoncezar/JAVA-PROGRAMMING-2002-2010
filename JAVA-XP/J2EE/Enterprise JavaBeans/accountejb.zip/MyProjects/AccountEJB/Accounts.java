/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;import java.rmi.*;

import Bank.*;

public class Accounts extends HttpServlet { 
    TellerHome	home = null;
  Teller		teller = null;

  public void init() { 
        try {
      home = (TellerHome)Naming.lookup("Teller");
      if( home == null ) { 
        System.out.println( "null TellerHome returned..." );
      }
      else { 
        teller = home.create();
        System.out.println( "Naming.lookup successful..." );
        System.out.println( "home.create successful..." );
      }
    } catch(Exception e) {System.out.println( e );}
  }
    public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException { 
    
    displayForm(res, "Welcome");   
  }
  public void doPost(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {
        double	initialBalance = 0, transferAmount = 0;;    String	customerName = null;    int		fromAccount = 0, toAccount = 0;
    boolean isCreate = false;    
    if ("application/x-www-form-urlencoded".equals(req.getContentType())) {       Enumeration enum = req.getParameterNames();
      while (enum.hasMoreElements()) {         String name = (String) enum.nextElement();        System.out.println("name = " + name);
        
        String values[] = req.getParameterValues(name);
                if (values != null) {           if( name.equals("initialBalance") ) { 
            initialBalance = (Double.valueOf(values[0])).doubleValue();
          }          
          if( name.equals("customerName") ) { 
            customerName = values[0];
          }          if( name.equals("transferAmount") ) { 
            transferAmount = (Double.valueOf(values[0])).doubleValue();
          }          
          if( name.equals("fromAccount") ) { 
            fromAccount = Integer.parseInt( values[0]);
          }          
          if( name.equals("toAccount") ) { 
            toAccount = Integer.parseInt( values[0]);
          }          if( name.equals("createButton") ) { 
            isCreate = true;
          }          
          if( name.equals("transferButton") ) { 
            isCreate = false;
          }
        }
      }
      System.out.println(" initialBalance = " + initialBalance +
                         " customerName = " + customerName+
                         " transferAmount = " + transferAmount+
                         " fromAccount = " + fromAccount+
                         " toAccount = " + toAccount+
                         " isCreate = " + isCreate);
      /**
      * Talk to the bean here
      */      try{
        if( ( home == null ) || (teller == null) ) { 
          home = (TellerHome)Naming.lookup("Teller");
          teller = home.create();
        }
        if( isCreate == true ) {           teller.createCheckingsAccount(customerName, initialBalance);
        }
        else { 
          teller.TransferMoney( transferAmount, fromAccount, toAccount);
        }
      } catch(Exception e){ System.out.println( e ); }
    }
    displayForm(res, "Welcome");   
  }    private void displayForm(HttpServletResponse response, String message) 
    throws IOException {
    
    if( ( home == null ) || (teller == null)) { 
      try{
        home = (TellerHome)Naming.lookup("Teller");
        teller = home.create();
      } catch(Exception e){ System.out.println( e ); }
    }
    response.setContentType("text/html");
    PrintWriter  out = response.getWriter();    
    out.println("<HTML><BODY>");
    out.println("<H1> List of Checking Accounts... </H1>");
    out.println("<body bgcolor=\"#FFFFFF\">");
    out.println("<table border=\"2\" width=\"100%\">");
    out.println("<tr><td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Teller Number</strong></font></td>");
    out.println("<td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Customer Name </strong></font></td>");
    out.println("<td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Teller Balance </strong></font></td></tr>");
    System.out.println( "Checking List..." );
    int i = 0;
    Vector checkingList = null;
    try{
      checkingList = teller.getCheckingsList();
    }catch(Exception e){ System.out.println(e);}
    if(checkingList != null) { 
      for(i = 0; i < checkingList.size(); i++) { 
        try{
          CheckingsPK key = (CheckingsPK)checkingList.elementAt(i);
          if(key == null)
            break;
          Checkings found = (Checkings)teller.getCheckings(key.account_number);
          if(found == null)
            break;
          System.out.println( " Account No = "+key.account_number+
                              " Name = "+found.getCustomerName()+
                              " Balance = " + found.getBalance() );
          out.println( "<tr><td><font size=\"1\" face=\"Verdana\"><strong>" + key.account_number +"</strong></font></td>" + 
                       "<td><font size=\"1\" face=\"Verdana\"><strong>"+found.getCustomerName() +"</strong></font></td>" + 
                       "<td><p align=\"right\"><font size=\"1\" face=\"Verdana\"><strong>"+ " $ " +found.getBalance() +"</strong></font></td>");

        }catch(Exception e){ System.out.println(e); break;}

      }
    }
    out.println("</tr></table>");
    out.println("<p align=\"center\">");
    out.println("<font size=\"3\" face=\"Verdana\"><strong>Total Number of Checking Accounts = "+ i +"   </strong></font></p>");
    System.out.println( "Listed all the "+ i + " records..." );
    
    out.println("<hr>");
    out.println("<H1> List of Savings Accounts... </H1>");
    out.println("<body bgcolor=\"#FFFFFF\">");
    out.println("<table border=\"2\" width=\"100%\">");
    out.println("<tr><td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Teller Number</strong></font></td>");
    out.println("<td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Customer Name </strong></font></td>");
    out.println("<td align=\"center\" bgcolor=\"#C0C0C0\"><font size=\"3\"");
    out.println("face=\"Verdana\"><strong>Teller Balance </strong></font></td></tr>");
    System.out.println( "Savings List..." );
    int j = 0;
    Vector savingsList = null;
    try {
      savingsList = teller.getSavingsList();
    }catch(Exception e){ System.out.println(e); }
    if(savingsList != null) {
      for(j = 0; j < savingsList.size(); j++) { 
        try {
          SavingsPK key = (SavingsPK)savingsList.elementAt(j);
          if(key == null) {
            break;
          }
          Savings found = (Savings)teller.getSavings(key.account_number);
          if(found == null) {
            break;
          }
          System.out.println( " Account No = "+key.account_number+
                              " Name = "+found.getCustomerName()+
                              " Balance = " + found.getBalance() );
          out.println( "<tr><td><font size=\"1\" face=\"Verdana\"><strong>" + key.account_number +"</strong></font></td>" + 
                       "<td><font size=\"1\" face=\"Verdana\"><strong>"+found.getCustomerName() +"</strong></font></td>" + 
                       "<td><p align=\"right\"><font size=\"1\" face=\"Verdana\"><strong>"+ " $ " +found.getBalance() +"</strong></font></td>");

        } catch(Exception e){ System.out.println(e); break; }

      }
    }
    out.println("</tr></table>");
    out.println("<p align=\"center\">");
    out.println("<font size=\"3\" face=\"Verdana\"><strong>Total Number of Savings Accounts = "+ j +"   </strong></font></p>");
    System.out.println( "Listed all the "+ j + " records..." );
    
    out.println("<hr>");

    out.println("<p align=\"center\"><font size=\"4\" face=\"Verdana\">");
    out.println("Create a New Teller</font></p>" );
    out.println("<form method=\"POST\">");
    out.println("<p align=\"center\"><font size=\"3\" face=\"Verdana\">");
    out.println("<strong>Enter Name <input type=\"text\" size=\"20\" name=\"customerName\">");
    out.println("Enter Initial Deposit </strong></font><font size=\"2\">");
    out.println("<strong><input type=\"text\" size=\"20\" name=\"initialBalance\"></strong></font></p>");
    out.println("<p align=\"center\"><font size=\"2\"><input type=\"submit\"");
    out.println("name=\"createButton\" value=\"Create\"></font></p>");
    out.println("</form><hr>");
    
    if((checkingList == null) || (savingsList == null)) { 
      out.println("</BODY></HTML>");
      return;
    }
    out.println("<p align=\"center\">");
    out.println("<font size=\"4\" face=\"Verdana\">");
    out.println("Transfer Money between Accounts</font></p>");

    out.println("<form method=\"POST\">");
    out.println("<p align=\"center\"><font size=\"3\" face=\"Verdana\">");
    out.println("<strong>Enter amount <input type=\"text\" size=\"20\" name=\"transferAmount\">");
    out.println("From Teller<select name=\"fromAccount\" size=\"1\">");
    System.out.println("Listing checking from");
    for(int k = 0; k < checkingList.size(); k++) { 
      try {
        CheckingsPK found = (CheckingsPK)checkingList.elementAt(k);
        if(found == null)
          break;
        out.println("<option>" + found.account_number+ "</option>");
      } catch(Exception e){ System.out.println(e); break; }
    }
    System.out.println("Listing saving from");
    for(int k = 0; k < savingsList.size(); k++) { 
      try {
        SavingsPK found = (SavingsPK)savingsList.elementAt(k);
        if(found == null)
          break;
        out.println("<option>" + found.account_number+ "</option>");
      } catch(Exception e) { System.out.println(e); break; }
    }
    
    out.println("</select> To Teller<select name=\"toAccount\" size=\"1\">");
    System.out.println("Listing checking to");
    for(int k = 0; k < checkingList.size(); k++) { 
      try {
        CheckingsPK found = (CheckingsPK)checkingList.elementAt(k);
        if(found == null) {
          break;
        }
        out.println("<option>" + found.account_number+ "</option>");
      } catch(Exception e){ System.out.println(e); break; }
    }
    System.out.println("Listing saving to");
    for(int k = 0; k < savingsList.size(); k++) { 
      try {
        SavingsPK found = (SavingsPK)savingsList.elementAt(k);
        if(found == null) {
          break;
        }
        out.println("<option>" + found.account_number+ "</option>");
      } catch(Exception e) { System.out.println(e); break; }
    }
    out.println("</select></strong></font><font size=\"2\">");
    out.println("<strong> </strong></font></p>");
    out.println("<p align=\"center\"><font size=\"2\"><input type=\"submit\"");
    out.println("name=\"transferButton\" value=\"Transfer\"></font></p>");
    out.println("</form>");

    out.println("<hr>");
    
    out.println("</BODY></HTML>"); 
    
  }
}
