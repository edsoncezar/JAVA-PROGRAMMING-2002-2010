// This file was generated on Sat Mar 27 00:26:14 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaTellerHome_Stub extends java.rmi.server.RemoteStub implements java.rmi.Remote, Bank.TellerHome {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("void remove(javax.ejb.Handle _param0)"),
    new java.rmi.server.Operation("void remove(java.lang.Object _param0)"),
    new java.rmi.server.Operation("javax.ejb.EJBMetaData getEJBMetaData()"),
    new java.rmi.server.Operation("Bank.Teller create()"),
  };

  private static final long ifHash=1587121L;

  public IonaTellerHome_Stub() {
    super();
  }

  public IonaTellerHome_Stub(java.rmi.server.RemoteRef rep) {
    super(rep);
  }

  public void remove(javax.ejb.Handle _param0) throws java.rmi.RemoteException,javax.ejb.RemoveException {
    int op=0;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public void remove(java.lang.Object _param0) throws java.rmi.RemoteException,javax.ejb.RemoveException {
    int op=1;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public javax.ejb.EJBMetaData getEJBMetaData() throws java.rmi.RemoteException {
    int op=2;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    javax.ejb.EJBMetaData $res;
    try {
      $res=(javax.ejb.EJBMetaData)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public Bank.Teller create() throws java.rmi.RemoteException,javax.ejb.CreateException {
    int op=3;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    Bank.Teller $res;
    try {
      $res=(Bank.Teller)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

}
