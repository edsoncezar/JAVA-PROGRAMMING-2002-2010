// This file was generated on Sat Mar 27 00:25:22 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
import java.rmi.RemoteException;
import javax.ejb.*;
import org.omg.CosTransactions.*;

public class IonaSavingsHome extends AbstractEntityHome implements Bank.SavingsHome {

  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeHomeFields);
  static javax.sql.XADataSource dataSource=null;
  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeHomeFields);

  public IonaSavingsHome(javax.naming.Name name) throws RemoteException {
    super(IonaSavingsHome.class,IonaRemoteSavings.class,IonaSavingsBean.class,Bank.SavingsPK.class,IonaSavingsContext.class,60,name);
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeHomeConstructor);
    try {
      if (dataSource==null) {
        java.util.Properties p=new java.util.Properties();
        p.put("java.naming.factory.initial",com.ejbhome.Constants.DEFAULT_NAMING_FACTORY);
        javax.naming.InitialContext initial=new javax.naming.InitialContext(p);
        dataSource=(javax.sql.XADataSource)initial.lookup("Checkings");
        com.ejbhome.util.Assert.isNotNull(dataSource);
      }
    } catch (javax.naming.NamingException ex) {
      throw new java.rmi.RemoteException("unable to locate datasource: Checkings");
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeHomeConstructor);
  }

  public void remove(javax.ejb.Handle _param0) throws java.rmi.RemoteException,javax.ejb.RemoveException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    super.remove(_param0);
  }

  public void remove(java.lang.Object _param0) throws java.rmi.RemoteException,javax.ejb.RemoveException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    super.remove(_param0);
  }

  public Bank.Savings create(int _param0, java.lang.String _param1) throws java.rmi.RemoteException,javax.ejb.CreateException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=(IonaSavingsBean)getBean();
    com.ejbhome.util.Assert.isNotNull(bi);
    bi.ejbCreate(_param0, _param1);
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeCreateBean);
    Bank.SavingsPK pk=(Bank.SavingsPK)new Bank.SavingsPK();
    pk.account_number=bi.account_number;
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(dataSource);
    try {
      conn=dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    java.sql.PreparedStatement insertStmt=null;
    try {
      StringBuffer sql=new StringBuffer("INSERT INTO savings (");
      StringBuffer values=new StringBuffer(" VALUES (");
      sql.append("account_number");
      sql.append(",");
      values.append("?,");
      sql.append("balance");
      sql.append(",");
      values.append("?,");
      if (bi.customer_name!=null) {
        sql.append("customer_name");
        sql.append(",");
        values.append("?,");
      }
      sql.setCharAt(sql.length()-1,')');
      values.setCharAt(values.length()-1,')');
      insertStmt=conn.prepareStatement(sql.toString()+values);
      int ix=0;
      insertStmt.setInt(++ix,bi.account_number);
      insertStmt.setDouble(++ix,bi.balance);
      if (bi.customer_name!=null) {
        insertStmt.setString(++ix,bi.customer_name);
      }
      insertStmt.executeUpdate();
      bi.ctx.setPrimaryKey(pk);
      bi.conn=conn;
      bi.__ejbLoad();
    } catch (java.sql.SQLException ex) {
      ex.printStackTrace();;
      throw new java.rmi.RemoteException("Database error",ex);
    } finally {
      if (insertStmt!=null) {
        try {
          insertStmt.close();
        } catch (java.sql.SQLException sex) {
        }
      }
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeCreateBean);
    IonaRemoteSavings remote=new IonaRemoteSavings(this, pk);
    fireNewRemoteObject((com.ejbhome.management.RemoteObject)remote);
    bi.ctx.setPrimaryKey(pk);
    bi.ctx.remote=remote;
    bi.ejbPostCreate(_param0, _param1);
    try {
      if (tx!=null) {
        txProposeObject(tx,pk,remote);
        remote.map(bi,tx);
      } else {
        remote.map(bi);
        cache(remote,pk);
      }
      return remote;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public Bank.Savings create(int _param0, java.lang.String _param1, double _param2) throws java.rmi.RemoteException,javax.ejb.CreateException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=(IonaSavingsBean)getBean();
    com.ejbhome.util.Assert.isNotNull(bi);
    bi.ejbCreate(_param0, _param1, _param2);
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeCreateBean);
    Bank.SavingsPK pk=(Bank.SavingsPK)new Bank.SavingsPK();
    pk.account_number=bi.account_number;
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(dataSource);
    try {
      conn=dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    java.sql.PreparedStatement insertStmt=null;
    try {
      StringBuffer sql=new StringBuffer("INSERT INTO savings (");
      StringBuffer values=new StringBuffer(" VALUES (");
      sql.append("account_number");
      sql.append(",");
      values.append("?,");
      sql.append("balance");
      sql.append(",");
      values.append("?,");
      if (bi.customer_name!=null) {
        sql.append("customer_name");
        sql.append(",");
        values.append("?,");
      }
      sql.setCharAt(sql.length()-1,')');
      values.setCharAt(values.length()-1,')');
      insertStmt=conn.prepareStatement(sql.toString()+values);
      int ix=0;
      insertStmt.setInt(++ix,bi.account_number);
      insertStmt.setDouble(++ix,bi.balance);
      if (bi.customer_name!=null) {
        insertStmt.setString(++ix,bi.customer_name);
      }
      insertStmt.executeUpdate();
      bi.ctx.setPrimaryKey(pk);
      bi.conn=conn;
      bi.__ejbLoad();
    } catch (java.sql.SQLException ex) {
      ex.printStackTrace();;
      throw new java.rmi.RemoteException("Database error",ex);
    } finally {
      if (insertStmt!=null) {
        try {
          insertStmt.close();
        } catch (java.sql.SQLException sex) {
        }
      }
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeCreateBean);
    IonaRemoteSavings remote=new IonaRemoteSavings(this, pk);
    fireNewRemoteObject((com.ejbhome.management.RemoteObject)remote);
    bi.ctx.setPrimaryKey(pk);
    bi.ctx.remote=remote;
    bi.ejbPostCreate(_param0, _param1, _param2);
    try {
      if (tx!=null) {
        txProposeObject(tx,pk,remote);
        remote.map(bi,tx);
      } else {
        remote.map(bi);
        cache(remote,pk);
      }
      return remote;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public Bank.Savings findByPrimaryKey(Bank.SavingsPK _param0) throws java.rmi.RemoteException,javax.ejb.FinderException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=(IonaSavingsBean)getBean();
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(dataSource);
    try {
      conn=dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    try {
      Bank.SavingsPK pk=null;
      // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeFindBeanBPK);
      java.sql.PreparedStatement selectStmt=null;
      try {
        selectStmt=conn.prepareStatement("SELECT account_number,balance,customer_name FROM savings WHERE account_number=?");
        selectStmt.setInt(1,_param0.account_number);
        java.sql.ResultSet rs=selectStmt.executeQuery();;
        if (!rs.next()) {
          throw new javax.ejb.ObjectNotFoundException();
        }
      } catch (java.sql.SQLException ex) {
        ex.printStackTrace();;
        throw new java.rmi.RemoteException("Database error",ex);
      } finally {
        if (selectStmt!=null) {
          try {
            selectStmt.close();
          } catch (java.sql.SQLException sex) {
          }
        }
      }
      pk=_param0;
      // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeFindBeanBPK);
      available.push(bi);
      Bank.Savings o=null;
      if (tx!=null) {
        java.util.Hashtable ht=(java.util.Hashtable)txCreatedObjects.get(tx);
        if (ht!=null) {
          o=(Bank.Savings)ht.get(pk);
        }
      }
      if (o==null) {
        o=(Bank.Savings)objectCache.get(pk);
        if (o==null) {
          o=new IonaRemoteSavings(this,pk);
          fireNewRemoteObject((com.ejbhome.management.RemoteObject)o);
          objectCache.put(pk,o);
        }
      }
      return o;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

}

