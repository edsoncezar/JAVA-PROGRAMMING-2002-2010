// This file was generated on Sat Mar 27 00:25:23 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
public class IonaSavingsContext extends AbstractEntityContext {

  Bank.Savings remote;
  private static java.util.Properties env=new java.util.Properties();
  static {
    env.put("databasePassword","mouse");
    env.put("dataSourceName","Checkings");
    env.put("databaseUser","user");
    env.put("databaseTable","savings");
  }

  public IonaSavingsContext() {
  }

  public java.util.Properties getEnvironment() {
    return env;
  }

}

