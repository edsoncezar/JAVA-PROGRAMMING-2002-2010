// This file was generated on Sat Mar 27 00:24:14 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaRemoteCheckings_Stub extends java.rmi.server.RemoteStub implements java.rmi.Remote, Bank.Checkings {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("javax.ejb.EJBHome getEJBHome()"),
    new java.rmi.server.Operation("java.lang.Object getPrimaryKey()"),
    new java.rmi.server.Operation("void remove()"),
    new java.rmi.server.Operation("javax.ejb.Handle getHandle()"),
    new java.rmi.server.Operation("boolean isIdentical(javax.ejb.EJBObject _param0)"),
    new java.rmi.server.Operation("void credit(double _param0)"),
    new java.rmi.server.Operation("void debit(double _param0)"),
    new java.rmi.server.Operation("double getBalance()"),
    new java.rmi.server.Operation("int getAccountNumber()"),
    new java.rmi.server.Operation("java.lang.String getCustomerName()"),
  };

  private static final long ifHash=1634344L;

  public IonaRemoteCheckings_Stub() {
    super();
  }

  public IonaRemoteCheckings_Stub(java.rmi.server.RemoteRef rep) {
    super(rep);
  }

  public synchronized javax.ejb.EJBHome getEJBHome() throws java.rmi.RemoteException {
    int op=0;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    javax.ejb.EJBHome $res;
    try {
      $res=(javax.ejb.EJBHome)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized java.lang.Object getPrimaryKey() throws java.rmi.RemoteException {
    int op=1;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    java.lang.Object $res;
    try {
      $res=(java.lang.Object)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized void remove() throws javax.ejb.RemoveException,java.rmi.RemoteException {
    int op=2;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public synchronized javax.ejb.Handle getHandle() throws java.rmi.RemoteException {
    int op=3;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    javax.ejb.Handle $res;
    try {
      $res=(javax.ejb.Handle)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized boolean isIdentical(javax.ejb.EJBObject _param0) throws java.rmi.RemoteException {
    int op=4;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    boolean $res;
    try {
      $res=rc.getInputStream().readBoolean();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized void credit(double _param0) throws java.rmi.RemoteException {
    int op=5;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeDouble(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public synchronized void debit(double _param0) throws java.rmi.RemoteException {
    int op=6;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeDouble(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public synchronized double getBalance() throws java.rmi.RemoteException {
    int op=7;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    double $res;
    try {
      $res=rc.getInputStream().readDouble();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized int getAccountNumber() throws java.rmi.RemoteException {
    int op=8;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    int $res;
    try {
      $res=rc.getInputStream().readInt();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized java.lang.String getCustomerName() throws java.rmi.RemoteException {
    int op=9;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    java.lang.String $res;
    try {
      $res=(java.lang.String)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

}
