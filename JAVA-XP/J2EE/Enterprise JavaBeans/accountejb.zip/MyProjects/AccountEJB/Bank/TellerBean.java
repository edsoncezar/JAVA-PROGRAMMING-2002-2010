/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import javax.ejb.*;
import javax.naming.*;
import javax.transaction.UserTransaction;
import java.rmi.*;
import java.util.*;


public class TellerBean implements SessionBean { 
  
  public static final int INVALID_ACCOUNT = -1;

  SessionContext ctx;

  public CheckingsHome	checkingsHome;
  public SavingsHome	  savingsHome;
  
  public Vector			  checkingsList = null;
  public Vector			  savingsList   = null;
  public final int		checkingsBase = 10;
  public final int		savingsBase	  = 10000;
  public int			    lastCheckings = checkingsBase;
  public int			    lastSavings   = savingsBase;

  public Checkings createCheckingsAccount(String name, double amount) 
    throws RemoteException, CreateException { 
    ++lastCheckings;
    return checkingsHome.create(lastCheckings, name, amount);
  }

  public Savings createSavingsAccount(String name, double amount) 
    throws RemoteException, CreateException { 
    ++lastSavings;
    return savingsHome.create(lastSavings, name, amount);
  }
  
  public int getNextCheckings(CheckingsHome home) throws RemoteException { 
    checkingsList = new Vector();
    int i = checkingsBase;
    for(i = i+1; ; i++) { 
      if( i == savingsBase ) {
        return TellerBean.INVALID_ACCOUNT;
      }
      try {
        CheckingsPK key = new CheckingsPK( i );
        Checkings found = home.findByPrimaryKey( key );
        if(found == null) {
          break;
        }
        System.out.println("======================================================");
        System.out.println( "Key: "+ key.account_number +
                            " Account No = "+found.getAccountNumber()+
                            " Name = "+found.getCustomerName()+
                            " Balance = " + found.getBalance() );
        System.out.println("======================================================");
        checkingsList.addElement(key);

      } catch(Exception e) { break; }

    }
    return i;
    
  }

  public int getNextSavings(SavingsHome home) throws RemoteException { 
    savingsList = new Vector();
    int i = savingsBase;
    for(i = i+1; ; i++) { 
      if( i == checkingsBase ) {
        return TellerBean.INVALID_ACCOUNT;
      }
      try{
        SavingsPK key = new SavingsPK( i );
        Savings found = home.findByPrimaryKey( key );
        if(found == null) {
          break;
        }
        System.out.println("======================================================");
        System.out.println( "Key: "+ key.account_number +
                            " Account No = "+found.getAccountNumber()+
                            " Name = "+found.getCustomerName()+
                            " Balance = " + found.getBalance() );
        System.out.println("======================================================");
        savingsList.addElement(key);

      } catch(Exception e) { break; }

    }
    return i;
    
  }

  public Vector getCheckingsList() throws RemoteException { 
    return checkingsList;
  }

  public Vector getSavingsList() throws RemoteException { 
    return savingsList;
  }
  
  public void TransferMoney(double amount, int fromAccount, int toAccount) 
    throws RemoteException { 
    Checkings fromCheckings = null, toCheckings = null;
    Savings fromSavings = null, toSavings = null;
    try{
      if(fromAccount < savingsBase) { 
        fromCheckings = getCheckings(fromAccount);
        fromCheckings.debit(amount);
      }
      else { 
        fromSavings = getSavings(fromAccount);
        fromSavings.debit(amount);
      }
      if(toAccount < savingsBase) { 
        toCheckings = getCheckings(toAccount);
        toCheckings.credit(amount);
      }
      else { 
        toSavings = getSavings(toAccount);
        toSavings.credit(amount);
      }
      
    }catch(Exception e) {System.out.println(e);} 
  }

  public Checkings getCheckings(int acc) 
    throws RemoteException, FinderException { 
    return checkingsHome.findByPrimaryKey(new CheckingsPK(acc));
  }

  public Savings getSavings(int acc) 
    throws RemoteException, FinderException { 
    return savingsHome.findByPrimaryKey(new SavingsPK(acc));
  }
  
  public void ejbCreate()   { }
  public void ejbActivate() { }
  public void ejbPassivate(){ }
  public void ejbRemove()   { }

  public void setSessionContext(SessionContext ctx) 
    throws RemoteException { 
    this.ctx = ctx;
    try {
      checkingsHome = (CheckingsHome)Naming.lookup("Checkings");
      savingsHome  = (SavingsHome)Naming.lookup("Savings");
      lastCheckings = getNextCheckings(checkingsHome);
      lastSavings = getNextSavings(savingsHome);
    } 
    catch (Exception ex) { 
      throw new RemoteException("Could not find Accounts", ex);
    }
  }
}