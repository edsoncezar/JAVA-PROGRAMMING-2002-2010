// This file was generated on Sat Mar 27 00:26:13 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
import java.rmi.RemoteException;
import org.omg.CosTransactions.*;

public class IonaRemoteTeller extends AbstractSessionRemote implements Bank.Teller {

  public IonaTellerBean instance;

  public IonaRemoteTeller() throws RemoteException {
  }

  public synchronized void remove() throws javax.ejb.RemoveException,java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (instance==null) {
      // TODO: read the instance from secondary storage;
      instance.ejbActivate();
      instance.ctx.home=home;
      instance.ctx.tx=null;
      instance.ctx.ejbObject=this;
    }
    if (instance.ctx.tx!=null) throw new javax.ejb.RemoveException("Bean is participating in a transaction");
    instance.ejbRemove();
    instance=null;
    delete("Removed by client");
    home.delete(beanctx);
  }

  public synchronized Bank.Checkings createCheckingsAccount(java.lang.String _param0, double _param1) throws java.rmi.RemoteException,javax.ejb.CreateException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.createCheckingsAccount(_param0, _param1);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized Bank.Savings createSavingsAccount(java.lang.String _param0, double _param1) throws java.rmi.RemoteException,javax.ejb.CreateException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.createSavingsAccount(_param0, _param1);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized int getNextCheckings(Bank.CheckingsHome _param0) throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getNextCheckings(_param0);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized int getNextSavings(Bank.SavingsHome _param0) throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getNextSavings(_param0);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized void TransferMoney(double _param0, int _param1, int _param2) throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      instance.TransferMoney(_param0, _param1, _param2);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized Bank.Checkings getCheckings(int _param0) throws java.rmi.RemoteException,javax.ejb.FinderException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getCheckings(_param0);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized Bank.Savings getSavings(int _param0) throws java.rmi.RemoteException,javax.ejb.FinderException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getSavings(_param0);
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized java.util.Vector getCheckingsList() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getCheckingsList();
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized java.util.Vector getSavingsList() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    if (removed) throw new java.rmi.NoSuchObjectException(reasonForRemoval);
    try {
      if (instance==null) {
        // TODO: read the instance from secondary storage;
        instance.ejbActivate();
        instance.ctx.home=home;
        instance.ctx.tx=null;
        instance.ctx.ejbObject=this;
      }
      if (instance.tx!=null) {
        if (tx==null || !instance.tx.equals(tx)) throw new RemoteException("Attempt to invoke a method in a different or no transaction context");
      } else {
        if (tx!=null) {
          instance.tx=tx;
        }
      }
      home.touch(this);
      return instance.getSavingsList();
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

}

