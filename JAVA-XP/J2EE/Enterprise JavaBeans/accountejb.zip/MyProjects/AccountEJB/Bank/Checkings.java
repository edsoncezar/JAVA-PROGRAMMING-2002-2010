/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import javax.ejb.*;
import java.rmi.*;

public interface Checkings extends EJBObject { 
  
  void credit(double amount) throws RemoteException;
  void debit(double amount) throws RemoteException;
  double getBalance() throws RemoteException;
  public int getAccountNumber() throws RemoteException;
  public String getCustomerName() throws RemoteException;
  
}