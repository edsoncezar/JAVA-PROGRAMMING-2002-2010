// This file was generated on Sat Mar 27 00:25:23 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaSavingsHome_Skel extends java.lang.Object implements java.rmi.server.Skeleton {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("void remove(javax.ejb.Handle _param0)"),
    new java.rmi.server.Operation("void remove(java.lang.Object _param0)"),
    new java.rmi.server.Operation("javax.ejb.EJBMetaData getEJBMetaData()"),
    new java.rmi.server.Operation("Bank.Savings create(int _param0, java.lang.String _param1)"),
    new java.rmi.server.Operation("Bank.Savings create(int _param0, java.lang.String _param1, double _param2)"),
    new java.rmi.server.Operation("Bank.Savings findByPrimaryKey(Bank.SavingsPK _param0)"),
  };

  private static final long ifHash=1586774L;

  public java.rmi.server.Operation[] getOperations() {
    return operations;
  }

  public void dispatch(java.rmi.Remote r,java.rmi.server.RemoteCall rc,int op,long h) throws java.rmi.RemoteException, Exception {
    if (h!=ifHash) throw new java.rmi.server.SkeletonMismatchException("Mismatch between stub and skeleton");
    Bank.SavingsHome server=(Bank.SavingsHome)r;
    try {
      switch (op) {
        case 0: {
          javax.ejb.Handle _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(javax.ejb.Handle)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.remove(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 1: {
          java.lang.Object _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(java.lang.Object)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.remove(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 2: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          javax.ejb.EJBMetaData $res=server.getEJBMetaData();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 3: {
          int _param0;
          java.lang.String _param1;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=in.readInt();
            _param1=(java.lang.String)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          Bank.Savings $res=server.create(_param0, _param1);
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 4: {
          int _param0;
          java.lang.String _param1;
          double _param2;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=in.readInt();
            _param1=(java.lang.String)in.readObject();
            _param2=in.readDouble();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          Bank.Savings $res=server.create(_param0, _param1, _param2);
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 5: {
          Bank.SavingsPK _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(Bank.SavingsPK)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          Bank.Savings $res=server.findByPrimaryKey(_param0);
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

      }
    } catch (Exception tempex) {
      if (tempex instanceof RuntimeException) {
        com.ejbhome.util.Trace.trace("Runtime exception thrown:");
        tempex.printStackTrace();
      }
      throw tempex;
    }
  }

}
