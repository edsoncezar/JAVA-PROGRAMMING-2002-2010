// This file was generated on Sat Mar 27 00:26:13 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
import java.rmi.RemoteException;
import javax.ejb.*;
import org.omg.CosTransactions.*;

public class IonaTellerHome extends AbstractStatefulSessionHome implements Bank.TellerHome {

  public IonaTellerHome(javax.naming.Name name) throws RemoteException {
    super(IonaTellerHome.class,IonaRemoteTeller.class,IonaTellerBean.class,IonaTellerContext.class,40,name,3484);
  }

  public Bank.Teller create() throws java.rmi.RemoteException,javax.ejb.CreateException {
    com.ejbhome.util.Trace.method();
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaRemoteTeller remote=(IonaRemoteTeller)createObject();
    remote.instance=(IonaTellerBean)remote.beanctx.bean;
    try {
      remote.instance.setSessionContext(remote.beanctx);
      remote.instance.ejbCreate();
      return remote;
      // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
    }
    // com.ejbhome.generator.StatefulSessionContainerCodeGenerator.catchExceptions() -- END
  }

}

