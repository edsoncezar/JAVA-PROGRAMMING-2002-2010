/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import javax.ejb.*;
import java.rmi.*;
import java.util.*;

public interface Teller extends EJBObject { 
  
  public Checkings createCheckingsAccount(String name, double amount) 
    throws RemoteException, CreateException;
  public Savings createSavingsAccount(String name, double amount) 
    throws RemoteException, CreateException;
  public int getNextCheckings(CheckingsHome home) 
    throws RemoteException;
  public int getNextSavings(SavingsHome home) 
    throws RemoteException;
  public void TransferMoney(double amount, int fromAcct, int toAcct) 
    throws RemoteException;
  public Checkings getCheckings(int acc) 
    throws RemoteException, FinderException;
  public Savings getSavings(int acc) 
    throws RemoteException, FinderException;
  public Vector getCheckingsList() throws RemoteException;
  public Vector getSavingsList() throws RemoteException;
}