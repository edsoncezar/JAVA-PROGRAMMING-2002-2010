// This file was generated on Sat Mar 27 00:26:14 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
public class IonaTellerContext extends AbstractSessionContext {

  Bank.Teller remote;
  private static java.util.Properties env=new java.util.Properties();
  static {
  }

  public java.util.Properties getEnvironment() {
    return env;
  }

}

