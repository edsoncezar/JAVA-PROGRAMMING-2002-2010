// This file was generated on Sat Mar 27 00:26:14 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaTellerHome_Skel extends java.lang.Object implements java.rmi.server.Skeleton {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("void remove(javax.ejb.Handle _param0)"),
    new java.rmi.server.Operation("void remove(java.lang.Object _param0)"),
    new java.rmi.server.Operation("javax.ejb.EJBMetaData getEJBMetaData()"),
    new java.rmi.server.Operation("Bank.Teller create()"),
  };

  private static final long ifHash=1587121L;

  public java.rmi.server.Operation[] getOperations() {
    return operations;
  }

  public void dispatch(java.rmi.Remote r,java.rmi.server.RemoteCall rc,int op,long h) throws java.rmi.RemoteException, Exception {
    if (h!=ifHash) throw new java.rmi.server.SkeletonMismatchException("Mismatch between stub and skeleton");
    Bank.TellerHome server=(Bank.TellerHome)r;
    try {
      switch (op) {
        case 0: {
          javax.ejb.Handle _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(javax.ejb.Handle)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.remove(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 1: {
          java.lang.Object _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(java.lang.Object)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.remove(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 2: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          javax.ejb.EJBMetaData $res=server.getEJBMetaData();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 3: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          Bank.Teller $res=server.create();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

      }
    } catch (Exception tempex) {
      if (tempex instanceof RuntimeException) {
        com.ejbhome.util.Trace.trace("Runtime exception thrown:");
        tempex.printStackTrace();
      }
      throw tempex;
    }
  }

}
