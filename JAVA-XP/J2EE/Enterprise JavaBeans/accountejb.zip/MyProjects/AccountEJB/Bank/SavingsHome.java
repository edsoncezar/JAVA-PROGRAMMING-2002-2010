/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import javax.ejb.*;
import java.rmi.*;

public interface SavingsHome extends EJBHome { 
  
  Savings create(int accountNo, String customer)
    throws CreateException, RemoteException;
  Savings create(int accountNo, String customer, double startingBalance)
    throws CreateException, RemoteException;
  Savings findByPrimaryKey(SavingsPK accountNo)
    throws FinderException, RemoteException;
}
