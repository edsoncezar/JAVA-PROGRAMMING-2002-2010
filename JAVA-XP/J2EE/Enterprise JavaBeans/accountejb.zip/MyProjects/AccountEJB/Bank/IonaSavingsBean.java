// This file was generated on Sat Mar 27 00:25:23 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
import java.rmi.RemoteException;
import org.omg.CosTransactions.*;

public class IonaSavingsBean extends Bank.SavingsBean {
  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeBeanFields);
  java.sql.Connection conn;

  int _account_number;
  java.lang.String _customer_name;
  double _balance;

  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeBeanFields);
  public IonaSavingsContext ctx=new IonaSavingsContext();

  public IonaSavingsBean() throws RemoteException {
  }

  public void setEntityContext(IonaSavingsContext ctx) throws java.rmi.RemoteException {
    super.setEntityContext(ctx);
    this.ctx=ctx;
  }

  public void unsetEntityContext() throws java.rmi.RemoteException {
    super.unsetEntityContext();
    this.ctx=null;
  }

  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeBeanClassEnd);
  public void __ejbLoad() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    super.ejbLoad();
    Bank.SavingsPK pk=(Bank.SavingsPK)ctx.getPrimaryKey();
    java.sql.PreparedStatement selectStmt=null;
    try {
      selectStmt=conn.prepareStatement("SELECT account_number,balance,customer_name FROM savings WHERE account_number=?");
      selectStmt.setInt(1,pk.account_number);
      java.sql.ResultSet rs=selectStmt.executeQuery();;
      rs.next();
      _balance=balance=rs.getDouble("balance");
      _customer_name=customer_name=(String)rs.getString("customer_name");
    } catch (java.sql.SQLException ex) {
      ex.printStackTrace();;
      throw new java.rmi.RemoteException("Database error",ex);
    } finally {
      if (selectStmt!=null) {
        try {
          selectStmt.close();
        } catch (java.sql.SQLException sex) {
        }
      }
    }
  }

  public void __ejbStore() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    super.ejbStore();
    if (balance==_balance && (customer_name==null && _customer_name==null)||(customer_name!=null && customer_name.equals(_customer_name))) {
      return;
    }
    Bank.SavingsPK pk=(Bank.SavingsPK)ctx.getPrimaryKey();
    java.sql.PreparedStatement updateStmt=null;
    try {
      updateStmt=conn.prepareStatement("UPDATE savings SET balance=?,customer_name=? WHERE account_number=?");
      updateStmt.setDouble(1,balance);
      if (customer_name==null) {
        updateStmt.setNull(2,java.sql.Types.VARCHAR);
      } else {
        updateStmt.setString(2,customer_name);
      }
      updateStmt.setInt(3,pk.account_number);
      updateStmt.executeUpdate();
    } catch (java.sql.SQLException ex) {
      ex.printStackTrace();;
      throw new java.rmi.RemoteException("Database error",ex);
    } finally {
      if (updateStmt!=null) {
        try {
          updateStmt.close();
        } catch (java.sql.SQLException sex) {
        }
      }
    }
  }

  public void __ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
    super.ejbRemove();
  }
  // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeBeanClassEnd);
}

