// This file was generated on Sat Mar 27 00:25:22 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.

package Bank;

import com.ejbhome.container.*;
import java.rmi.RemoteException;
import org.omg.CosTransactions.*;

public class IonaRemoteSavings extends AbstractEntityRemote implements Bank.Savings {

  public IonaRemoteSavings(AbstractEntityHome hm, Bank.SavingsPK pk) throws RemoteException {
    super(hm,pk);
    com.ejbhome.util.Trace.method(hm+","+pk);
  }

  public synchronized void remove() throws javax.ejb.RemoveException,java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    super.remove();
  }

  public synchronized void credit(double _param0) throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=null;
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(((IonaSavingsHome)home).dataSource);
    try {
      conn=((IonaSavingsHome)home).dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    if (clientTx==null) {
      com.ejbhome.util.Trace.trace("no transaction");
      if (readyInstances.isEmpty()) {
        com.ejbhome.util.Trace.trace("no ready instances");
        if (home.available.isEmpty()) {
          com.ejbhome.util.Trace.trace("no available beans");
          try {
            bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
          } catch (InstantiationException instantiation) {
            throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
          } catch (IllegalAccessException access) {
            throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
          }
        } else {
          com.ejbhome.util.Trace.trace("an unpatched bean is available from home");
          bi=(IonaSavingsBean)home.available.pop();
        }
        IonaSavingsContext ctx=new IonaSavingsContext();
        ctx.setEntityBean(bi);
        ctx.setEJBHome(home);
        ctx.setPrimaryKey(getPrimaryKey());
        ctx.remote=this;
        bi.setEntityContext(ctx);
        bi.ejbActivate();
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
        bi.__ejbLoad();
      } else {
        com.ejbhome.util.Trace.trace("ready instances are available");
        bi=(IonaSavingsBean)readyInstances.pop();
      }
    } else {
      com.ejbhome.util.Trace.trace("client tx");
      bi=(IonaSavingsBean)txInstances.get(clientTx);
      if (bi==null) {
        if (readyInstances.isEmpty()) {
          com.ejbhome.util.Trace.trace("no ready instances are available");
          if (home.available.isEmpty()) {
            com.ejbhome.util.Trace.trace("no beans are available in the home");
            try {
              bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
            } catch (InstantiationException instantiation) {
              throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
            } catch (IllegalAccessException access) {
              throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
            }
            IonaSavingsContext ctx=new IonaSavingsContext();
            ctx.setEntityBean(bi);
            ctx.setEJBHome(home);
            ctx.setPrimaryKey(getPrimaryKey());
            ctx.remote=this;
            bi.setEntityContext(ctx);
            bi.ejbActivate();
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
            bi.conn=conn;
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
            bi.__ejbLoad();
          }
        }
        txInstances.put(clientTx,bi);
        com.ejbhome.container.EntitySynchronization sync=new com.ejbhome.container.EntitySynchronization(this,clientTx,bi,home);
        try {
          clientTx.get_coordinator().register_synchronization(sync);
        } catch (org.omg.CosTransactions.Unavailable unavailable) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.Inactive inactive) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.SynchronizationUnavailable synchro) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        }
      } else {
        com.ejbhome.util.Trace.trace("found bean in tx instances");
      }
    }
    try {
      bi.credit(_param0);
      if (clientTx==null) {
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreStore);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreStore);
        bi.__ejbStore();
        readyInstances.push(bi);
      }
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized void debit(double _param0) throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=null;
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(((IonaSavingsHome)home).dataSource);
    try {
      conn=((IonaSavingsHome)home).dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    if (clientTx==null) {
      com.ejbhome.util.Trace.trace("no transaction");
      if (readyInstances.isEmpty()) {
        com.ejbhome.util.Trace.trace("no ready instances");
        if (home.available.isEmpty()) {
          com.ejbhome.util.Trace.trace("no available beans");
          try {
            bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
          } catch (InstantiationException instantiation) {
            throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
          } catch (IllegalAccessException access) {
            throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
          }
        } else {
          com.ejbhome.util.Trace.trace("an unpatched bean is available from home");
          bi=(IonaSavingsBean)home.available.pop();
        }
        IonaSavingsContext ctx=new IonaSavingsContext();
        ctx.setEntityBean(bi);
        ctx.setEJBHome(home);
        ctx.setPrimaryKey(getPrimaryKey());
        ctx.remote=this;
        bi.setEntityContext(ctx);
        bi.ejbActivate();
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
        bi.__ejbLoad();
      } else {
        com.ejbhome.util.Trace.trace("ready instances are available");
        bi=(IonaSavingsBean)readyInstances.pop();
      }
    } else {
      com.ejbhome.util.Trace.trace("client tx");
      bi=(IonaSavingsBean)txInstances.get(clientTx);
      if (bi==null) {
        if (readyInstances.isEmpty()) {
          com.ejbhome.util.Trace.trace("no ready instances are available");
          if (home.available.isEmpty()) {
            com.ejbhome.util.Trace.trace("no beans are available in the home");
            try {
              bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
            } catch (InstantiationException instantiation) {
              throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
            } catch (IllegalAccessException access) {
              throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
            }
            IonaSavingsContext ctx=new IonaSavingsContext();
            ctx.setEntityBean(bi);
            ctx.setEJBHome(home);
            ctx.setPrimaryKey(getPrimaryKey());
            ctx.remote=this;
            bi.setEntityContext(ctx);
            bi.ejbActivate();
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
            bi.conn=conn;
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
            bi.__ejbLoad();
          }
        }
        txInstances.put(clientTx,bi);
        com.ejbhome.container.EntitySynchronization sync=new com.ejbhome.container.EntitySynchronization(this,clientTx,bi,home);
        try {
          clientTx.get_coordinator().register_synchronization(sync);
        } catch (org.omg.CosTransactions.Unavailable unavailable) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.Inactive inactive) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.SynchronizationUnavailable synchro) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        }
      } else {
        com.ejbhome.util.Trace.trace("found bean in tx instances");
      }
    }
    try {
      bi.debit(_param0);
      if (clientTx==null) {
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreStore);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreStore);
        bi.__ejbStore();
        readyInstances.push(bi);
      }
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized double getBalance() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=null;
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(((IonaSavingsHome)home).dataSource);
    try {
      conn=((IonaSavingsHome)home).dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    if (clientTx==null) {
      com.ejbhome.util.Trace.trace("no transaction");
      if (readyInstances.isEmpty()) {
        com.ejbhome.util.Trace.trace("no ready instances");
        if (home.available.isEmpty()) {
          com.ejbhome.util.Trace.trace("no available beans");
          try {
            bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
          } catch (InstantiationException instantiation) {
            throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
          } catch (IllegalAccessException access) {
            throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
          }
        } else {
          com.ejbhome.util.Trace.trace("an unpatched bean is available from home");
          bi=(IonaSavingsBean)home.available.pop();
        }
        IonaSavingsContext ctx=new IonaSavingsContext();
        ctx.setEntityBean(bi);
        ctx.setEJBHome(home);
        ctx.setPrimaryKey(getPrimaryKey());
        ctx.remote=this;
        bi.setEntityContext(ctx);
        bi.ejbActivate();
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
        bi.__ejbLoad();
      } else {
        com.ejbhome.util.Trace.trace("ready instances are available");
        bi=(IonaSavingsBean)readyInstances.pop();
      }
    } else {
      com.ejbhome.util.Trace.trace("client tx");
      bi=(IonaSavingsBean)txInstances.get(clientTx);
      if (bi==null) {
        if (readyInstances.isEmpty()) {
          com.ejbhome.util.Trace.trace("no ready instances are available");
          if (home.available.isEmpty()) {
            com.ejbhome.util.Trace.trace("no beans are available in the home");
            try {
              bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
            } catch (InstantiationException instantiation) {
              throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
            } catch (IllegalAccessException access) {
              throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
            }
            IonaSavingsContext ctx=new IonaSavingsContext();
            ctx.setEntityBean(bi);
            ctx.setEJBHome(home);
            ctx.setPrimaryKey(getPrimaryKey());
            ctx.remote=this;
            bi.setEntityContext(ctx);
            bi.ejbActivate();
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
            bi.conn=conn;
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
            bi.__ejbLoad();
          }
        }
        txInstances.put(clientTx,bi);
        com.ejbhome.container.EntitySynchronization sync=new com.ejbhome.container.EntitySynchronization(this,clientTx,bi,home);
        try {
          clientTx.get_coordinator().register_synchronization(sync);
        } catch (org.omg.CosTransactions.Unavailable unavailable) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.Inactive inactive) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.SynchronizationUnavailable synchro) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        }
      } else {
        com.ejbhome.util.Trace.trace("found bean in tx instances");
      }
    }
    double result;
    try {
      result=bi.getBalance();
      if (clientTx==null) {
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreStore);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreStore);
        bi.__ejbStore();
        readyInstances.push(bi);
      }
      return result;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized int getAccountNumber() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=null;
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(((IonaSavingsHome)home).dataSource);
    try {
      conn=((IonaSavingsHome)home).dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    if (clientTx==null) {
      com.ejbhome.util.Trace.trace("no transaction");
      if (readyInstances.isEmpty()) {
        com.ejbhome.util.Trace.trace("no ready instances");
        if (home.available.isEmpty()) {
          com.ejbhome.util.Trace.trace("no available beans");
          try {
            bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
          } catch (InstantiationException instantiation) {
            throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
          } catch (IllegalAccessException access) {
            throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
          }
        } else {
          com.ejbhome.util.Trace.trace("an unpatched bean is available from home");
          bi=(IonaSavingsBean)home.available.pop();
        }
        IonaSavingsContext ctx=new IonaSavingsContext();
        ctx.setEntityBean(bi);
        ctx.setEJBHome(home);
        ctx.setPrimaryKey(getPrimaryKey());
        ctx.remote=this;
        bi.setEntityContext(ctx);
        bi.ejbActivate();
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
        bi.__ejbLoad();
      } else {
        com.ejbhome.util.Trace.trace("ready instances are available");
        bi=(IonaSavingsBean)readyInstances.pop();
      }
    } else {
      com.ejbhome.util.Trace.trace("client tx");
      bi=(IonaSavingsBean)txInstances.get(clientTx);
      if (bi==null) {
        if (readyInstances.isEmpty()) {
          com.ejbhome.util.Trace.trace("no ready instances are available");
          if (home.available.isEmpty()) {
            com.ejbhome.util.Trace.trace("no beans are available in the home");
            try {
              bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
            } catch (InstantiationException instantiation) {
              throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
            } catch (IllegalAccessException access) {
              throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
            }
            IonaSavingsContext ctx=new IonaSavingsContext();
            ctx.setEntityBean(bi);
            ctx.setEJBHome(home);
            ctx.setPrimaryKey(getPrimaryKey());
            ctx.remote=this;
            bi.setEntityContext(ctx);
            bi.ejbActivate();
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
            bi.conn=conn;
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
            bi.__ejbLoad();
          }
        }
        txInstances.put(clientTx,bi);
        com.ejbhome.container.EntitySynchronization sync=new com.ejbhome.container.EntitySynchronization(this,clientTx,bi,home);
        try {
          clientTx.get_coordinator().register_synchronization(sync);
        } catch (org.omg.CosTransactions.Unavailable unavailable) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.Inactive inactive) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.SynchronizationUnavailable synchro) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        }
      } else {
        com.ejbhome.util.Trace.trace("found bean in tx instances");
      }
    }
    int result;
    try {
      result=bi.getAccountNumber();
      if (clientTx==null) {
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreStore);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreStore);
        bi.__ejbStore();
        readyInstances.push(bi);
      }
      return result;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

  public synchronized java.lang.String getCustomerName() throws java.rmi.RemoteException {
    com.ejbhome.util.Trace.method();
    if (removed) throw new com.ejbhome.container.ObjectRemovedException("Object has been removed");
    // TX_SUPPORTS
    com.ejbhome.jts.Current current=com.ejbhome.jts.Current.getCurrent();
    Control tx=current.get_control();
    Control clientTx=tx;
    com.ejbhome.util.Trace.trace("control: "+clientTx);
    IonaSavingsBean bi=null;
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codeEstablishConnection);
    java.sql.Connection conn=null;
    com.ejbhome.util.Assert.isNotNull(((IonaSavingsHome)home).dataSource);
    try {
      conn=((IonaSavingsHome)home).dataSource.getXAConnection("user","mouse").getConnection();
    } catch (java.sql.SQLException ex) {
      throw new java.rmi.RemoteException("failed to obtain database connection",ex);
    }
    // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codeEstablishConnection);
    if (clientTx==null) {
      com.ejbhome.util.Trace.trace("no transaction");
      if (readyInstances.isEmpty()) {
        com.ejbhome.util.Trace.trace("no ready instances");
        if (home.available.isEmpty()) {
          com.ejbhome.util.Trace.trace("no available beans");
          try {
            bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
          } catch (InstantiationException instantiation) {
            throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
          } catch (IllegalAccessException access) {
            throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
          }
        } else {
          com.ejbhome.util.Trace.trace("an unpatched bean is available from home");
          bi=(IonaSavingsBean)home.available.pop();
        }
        IonaSavingsContext ctx=new IonaSavingsContext();
        ctx.setEntityBean(bi);
        ctx.setEJBHome(home);
        ctx.setPrimaryKey(getPrimaryKey());
        ctx.remote=this;
        bi.setEntityContext(ctx);
        bi.ejbActivate();
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
        bi.__ejbLoad();
      } else {
        com.ejbhome.util.Trace.trace("ready instances are available");
        bi=(IonaSavingsBean)readyInstances.pop();
      }
    } else {
      com.ejbhome.util.Trace.trace("client tx");
      bi=(IonaSavingsBean)txInstances.get(clientTx);
      if (bi==null) {
        if (readyInstances.isEmpty()) {
          com.ejbhome.util.Trace.trace("no ready instances are available");
          if (home.available.isEmpty()) {
            com.ejbhome.util.Trace.trace("no beans are available in the home");
            try {
              bi=(IonaSavingsBean)IonaSavingsBean.class.newInstance();
            } catch (InstantiationException instantiation) {
              throw new java.rmi.RemoteException("cannot instantiate bean",instantiation);
            } catch (IllegalAccessException access) {
              throw new java.rmi.RemoteException("illegal access while instantiating bean",access);
            }
            IonaSavingsContext ctx=new IonaSavingsContext();
            ctx.setEntityBean(bi);
            ctx.setEJBHome(home);
            ctx.setPrimaryKey(getPrimaryKey());
            ctx.remote=this;
            bi.setEntityContext(ctx);
            bi.ejbActivate();
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreLoad);
            bi.conn=conn;
            // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreLoad);
            bi.__ejbLoad();
          }
        }
        txInstances.put(clientTx,bi);
        com.ejbhome.container.EntitySynchronization sync=new com.ejbhome.container.EntitySynchronization(this,clientTx,bi,home);
        try {
          clientTx.get_coordinator().register_synchronization(sync);
        } catch (org.omg.CosTransactions.Unavailable unavailable) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.Inactive inactive) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        } catch (org.omg.CosTransactions.SynchronizationUnavailable synchro) {
          com.ejbhome.util.Trace.trace("failed to register entity synchronization");
        }
      } else {
        com.ejbhome.util.Trace.trace("found bean in tx instances");
      }
    }
    java.lang.String result;
    try {
      result=bi.getCustomerName();
      if (clientTx==null) {
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- START(codePreStore);
        bi.conn=conn;
        // com.ejbhome.generator.helpers.RelationalPersistenceCodeHelper -- END(codePreStore);
        bi.__ejbStore();
        readyInstances.push(bi);
      }
      return result;
      // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- START
    } catch (java.lang.RuntimeException ex) {
      if (clientTx!=null) {
        try {
          clientTx.get_coordinator().rollback_only();
          throw new RemoteException("Transaction marked for rollback due to runtime exception: "+ex);
        } catch (Unavailable sex) {
          throw new RemoteException("Client transactions cannot be rolled back as its coordinator is unavailable",sex);
        } catch (Inactive sex) {
          throw new RemoteException("Client transaction cannot be rolled back as it is no longer active",sex);
        }
      }
      com.ejbhome.util.Trace.trace("An unchecked exception was thrown by the Bean instance, printing stack trace...");
      ex.printStackTrace();
      throw new RemoteException("unchecked exception",ex);
    } finally {
      try {
        conn.close();
      } catch (java.sql.SQLException ex) {
      }
    }
    // com.ejbhome.generator.EntityContainerCodeGenerator.catchExceptions() -- END
  }

}

