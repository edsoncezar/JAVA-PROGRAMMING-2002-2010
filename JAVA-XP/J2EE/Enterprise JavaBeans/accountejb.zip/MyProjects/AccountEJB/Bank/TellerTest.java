/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import java.rmi.*;
import java.util.*;

public class TellerTest { 

  public static void main(String[] args) throws Exception { 

    TellerHome home = (TellerHome)Naming.lookup("Teller");
    System.out.println( "Naming.lookup successful..." );
    if( home == null ) { 
      System.out.println( "null TellerHome returned..." );
    }
    Teller teller = home.create();
    teller.createCheckingsAccount( "Athul", 100.0);
    teller.createSavingsAccount( "Athul", 100.0);
    teller.TransferMoney( 50, 12, 10002);
    Checkings check = teller.getCheckings( 12 );
    System.out.println("No = " + check.getAccountNumber() +
                       " Name = " + check.getCustomerName() +
                       " Balance = " + check.getBalance());
    Savings save = teller.getSavings( 10002);
    System.out.println("No = " + save.getAccountNumber() +
                       " Name = " + save.getCustomerName() +
                       " Balance = " + save.getBalance());
  }
}
