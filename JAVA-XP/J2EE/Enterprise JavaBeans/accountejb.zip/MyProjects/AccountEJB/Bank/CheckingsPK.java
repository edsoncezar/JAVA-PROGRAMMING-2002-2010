/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import java.util.*;
public class CheckingsPK implements java.io.Serializable {
  
  public int account_number;

  public CheckingsPK() { 
    System.out.println("Invoking CheckingsPK::CheckingsPK");
  }

  public CheckingsPK(int accountNo) { 
    System.out.println("Invoking CheckingsPK::CheckingsPK");
    account_number = accountNo;
  }
}