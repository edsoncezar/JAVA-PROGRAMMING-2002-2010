/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public class SavingsBean implements EntityBean { 
  
  protected EntityContext _entityContext;
  
  public    int           account_number; //ACCOUNT_NUMBER
  public    String        customer_name;	//CUSTOMER_NAME
  public    double        balance;		    //BALANCE
  
  public int getAccountNumber() { 
    return this.account_number;
  }
  
  public String getCustomerName() { 
    return this.customer_name;
  }


  public void credit( double amount ) { 
    System.out.println("==============Invoking SavingsBean::credit");
    System.out.println("==============changing SavingsBean::balance from " + balance);
    if( amount > 0 )
      balance += amount;
    System.out.println(" to " + balance);
  }

  public void debit( double amount ) { 
    System.out.println("==============Invoking SavingsBean::debit");
    System.out.println("==============changing SavingsBean::balance from " + balance);
    if( (amount > 0) && (balance >= amount) )
      balance -= amount;
    System.out.println(" to " + balance);
  }

  public double getBalance( ) { 
    System.out.println("==============Invoking SavingsBean::getBalance");
    System.out.println("==============SavingsBean::balance is " + balance);
    return this.balance;
  }

  public SavingsBean() { 
    System.out.println("==============Invoking SavingsBean::SavingsBean");
    try { 
      jbInit();
    }
    catch (Exception e) { 
      e.printStackTrace();
      System.out.println("==============SavingsBean::SavingsBean - jbInit failed");
    }
  }

  // Container managed beans return void
  public void ejbCreate( int accountNo, String customer)
    throws RemoteException, CreateException { 
    System.out.println("==============Invoking 2 parameter SavingsBean::ejbCreate");
    this.account_number = accountNo;
    this.customer_name  = customer;
    this.balance   = 0d;
    
    System.out.println("======================================================");
    System.out.println("SavingsBean::account_number =" + this.account_number);
    System.out.println("SavingsBean::customer_name =" + this.customer_name);
    System.out.println("SavingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbPostCreate( int accountNo, String customer)
    throws RemoteException, CreateException { 
    System.out.println("======================================================");
    System.out.println("Invoking 2 parameter SavingsBean::ejbPostCreate");
    System.out.println("SavingsBean::account_number =" + this.account_number);
    System.out.println("SavingsBean::customer_name =" + this.customer_name);
    System.out.println("SavingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbCreate( int accountNo, String customer, double balance)
    throws RemoteException, CreateException { 
    System.out.println("==============Invoking 3 parameter SavingsBean::ejbCreate");
    this.account_number = accountNo;
    this.customer_name  = customer;
    this.balance   = balance;
    System.out.println("======================================================");
    System.out.println("SavingsBean::account_number =" + this.account_number);
    System.out.println("SavingsBean::customer_name =" + this.customer_name);
    System.out.println("SavingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbPostCreate( int accountNo, String customer, double balance)
    throws RemoteException, CreateException {
    System.out.println("======================================================");
    System.out.println("Invoking 3 parameter SavingsBean::ejbPostCreate");
    System.out.println("SavingsBean::account_number =" + this.account_number);
    System.out.println("SavingsBean::customer_name =" + this.customer_name);
    System.out.println("SavingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbActivate() throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::ejbActivate=======");
  }

  public void ejbLoad() throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::ejbLoad==========");
  }

  public void ejbPassivate() throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::ejbPassivate=====");
  }

  public void ejbRemove() throws RemoteException, RemoveException { 
    System.out.println("==============Invoking SavingsBean::ejbRemove========");
  }

  public void ejbStore() throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::ejbStore=========");
  }

  public void setEntityContext(EntityContext context) throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::setEntityContext=");
    this._entityContext = context;
  }

  public void unsetEntityContext() throws RemoteException { 
    System.out.println("==============Invoking SavingsBean::unsetEntityContext");
    this._entityContext = null;
  }

  private void jbInit() throws Exception { 
    System.out.println("==============Invoking SavingsBean::jbInit============");
  }	
}

 