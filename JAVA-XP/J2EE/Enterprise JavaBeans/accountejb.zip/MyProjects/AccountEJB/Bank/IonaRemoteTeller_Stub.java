// This file was generated on Sat Mar 27 00:26:14 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaRemoteTeller_Stub extends java.rmi.server.RemoteStub implements java.rmi.Remote, Bank.Teller {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("javax.ejb.EJBHome getEJBHome()"),
    new java.rmi.server.Operation("java.lang.Object getPrimaryKey()"),
    new java.rmi.server.Operation("void remove()"),
    new java.rmi.server.Operation("javax.ejb.Handle getHandle()"),
    new java.rmi.server.Operation("boolean isIdentical(javax.ejb.EJBObject _param0)"),
    new java.rmi.server.Operation("Bank.Checkings createCheckingsAccount(java.lang.String _param0, double _param1)"),
    new java.rmi.server.Operation("Bank.Savings createSavingsAccount(java.lang.String _param0, double _param1)"),
    new java.rmi.server.Operation("int getNextCheckings(Bank.CheckingsHome _param0)"),
    new java.rmi.server.Operation("int getNextSavings(Bank.SavingsHome _param0)"),
    new java.rmi.server.Operation("void TransferMoney(double _param0, int _param1, int _param2)"),
    new java.rmi.server.Operation("Bank.Checkings getCheckings(int _param0)"),
    new java.rmi.server.Operation("Bank.Savings getSavings(int _param0)"),
    new java.rmi.server.Operation("java.util.Vector getCheckingsList()"),
    new java.rmi.server.Operation("java.util.Vector getSavingsList()"),
  };

  private static final long ifHash=1587122L;

  public IonaRemoteTeller_Stub() {
    super();
  }

  public IonaRemoteTeller_Stub(java.rmi.server.RemoteRef rep) {
    super(rep);
  }

  public synchronized javax.ejb.EJBHome getEJBHome() throws java.rmi.RemoteException {
    int op=0;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    javax.ejb.EJBHome $res;
    try {
      $res=(javax.ejb.EJBHome)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized java.lang.Object getPrimaryKey() throws java.rmi.RemoteException {
    int op=1;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    java.lang.Object $res;
    try {
      $res=(java.lang.Object)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized void remove() throws javax.ejb.RemoveException,java.rmi.RemoteException {
    int op=2;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public synchronized javax.ejb.Handle getHandle() throws java.rmi.RemoteException {
    int op=3;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    javax.ejb.Handle $res;
    try {
      $res=(javax.ejb.Handle)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized boolean isIdentical(javax.ejb.EJBObject _param0) throws java.rmi.RemoteException {
    int op=4;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    boolean $res;
    try {
      $res=rc.getInputStream().readBoolean();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized Bank.Checkings createCheckingsAccount(java.lang.String _param0, double _param1) throws java.rmi.RemoteException,javax.ejb.CreateException {
    int op=5;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      out.writeDouble(_param1);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (javax.ejb.CreateException ex) {
      throw ex;
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    Bank.Checkings $res;
    try {
      $res=(Bank.Checkings)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized Bank.Savings createSavingsAccount(java.lang.String _param0, double _param1) throws java.rmi.RemoteException,javax.ejb.CreateException {
    int op=6;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      out.writeDouble(_param1);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (javax.ejb.CreateException ex) {
      throw ex;
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    Bank.Savings $res;
    try {
      $res=(Bank.Savings)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized int getNextCheckings(Bank.CheckingsHome _param0) throws java.rmi.RemoteException {
    int op=7;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    int $res;
    try {
      $res=rc.getInputStream().readInt();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized int getNextSavings(Bank.SavingsHome _param0) throws java.rmi.RemoteException {
    int op=8;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeObject(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    int $res;
    try {
      $res=rc.getInputStream().readInt();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized void TransferMoney(double _param0, int _param1, int _param2) throws java.rmi.RemoteException {
    int op=9;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeDouble(_param0);
      out.writeInt(_param1);
      out.writeInt(_param2);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    sub.done(rc);
  }

  public synchronized Bank.Checkings getCheckings(int _param0) throws java.rmi.RemoteException,javax.ejb.FinderException {
    int op=10;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeInt(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (javax.ejb.FinderException ex) {
      throw ex;
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    Bank.Checkings $res;
    try {
      $res=(Bank.Checkings)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized Bank.Savings getSavings(int _param0) throws java.rmi.RemoteException,javax.ejb.FinderException {
    int op=11;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      out.writeInt(_param0);
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (javax.ejb.FinderException ex) {
      throw ex;
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    Bank.Savings $res;
    try {
      $res=(Bank.Savings)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized java.util.Vector getCheckingsList() throws java.rmi.RemoteException {
    int op=12;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    java.util.Vector $res;
    try {
      $res=(java.util.Vector)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

  public synchronized java.util.Vector getSavingsList() throws java.rmi.RemoteException {
    int op=13;
    java.rmi.server.RemoteRef sub=ref;
    java.rmi.server.RemoteCall rc=sub.newCall((java.rmi.server.RemoteObject)this,operations,op,ifHash);;
    try {
      java.io.ObjectOutput out=rc.getOutputStream();
      com.ejbhome.jts.rmi.RemoteControl tx=(com.ejbhome.jts.rmi.RemoteControl)com.ejbhome.jts.Current.remoteControls.get(Thread.currentThread());
      out.writeObject(tx);
    } catch (java.io.IOException ex) {
      throw new java.rmi.MarshalException("Error marshalling arguments", ex);
    }
    try {
      sub.invoke(rc);
    } catch (java.rmi.RemoteException ex) {
      throw ex;
    } catch (java.lang.Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception",ex);
    }
    java.util.Vector $res;
    try {
      $res=(java.util.Vector)rc.getInputStream().readObject();
    } catch (java.io.IOException ex) {
      throw new java.rmi.UnmarshalException("Error unmarshaling return", ex);
    } catch (Exception ex) {
      throw new java.rmi.UnexpectedException("Unexpected exception", ex);
    } finally {
      sub.done(rc);
    }
    return $res;
  }

}
