/**
 * Copyright (C) 1998-1999, Gopalan Suresh Raj.
 * All Rights Reserved.
 * 
 * This source code is part of the Bank example. 
 * It is part of an EJB tutorial being developed by me.
 * See detailed instructions at my web site at
 * http://www.execpc.com/~gopalan
 * 
 */
package Bank;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public class CheckingsBean implements EntityBean { 
  
  protected EntityContext _entityContext;
  
  public    int           account_number; //ACCOUNT_NUMBER
  public    String        customer_name;	//CUSTOMER_NAME
  public    double        balance;		    //BALANCE
  
  public int getAccountNumber() { 
    return this.account_number;
  }
  
  public String getCustomerName() { 
    return this.customer_name;
  }


  public void credit( double amount ) { 
    System.out.println("==============Invoking CheckingsBean::credit");
    System.out.println("==============changing CheckingsBean::balance from " + balance);
    if( amount > 0 ) {
      balance += amount;
    }
    System.out.println(" to " + balance);
  }

  public void debit( double amount ) { 
    System.out.println("==============Invoking CheckingsBean::debit");
    System.out.println("==============changing CheckingsBean::balance from " + balance);
    if( (amount > 0) && (balance >= amount) ) {
      balance -= amount;
    }
    System.out.println(" to " + balance);
  }

  public double getBalance( ) { 
    System.out.println("==============Invoking CheckingsBean::getBalance");
    System.out.println("==============CheckingsBean::balance is " + balance);
    return this.balance;
  }

  public CheckingsBean() { 
    System.out.println("==============Invoking CheckingsBean::CheckingsBean");
    try { 
      jbInit();
    }
    catch (Exception e) { 
      e.printStackTrace();
      System.out.println("==============CheckingsBean::CheckingsBean - jbInit failed");
    }
  }

  // Container managed beans return void
  public void ejbCreate( int accountNo, String customer)
    throws RemoteException, CreateException { 
    
    System.out.println("==============Invoking 2 parameter CheckingsBean::ejbCreate");
    this.account_number = accountNo;
    this.customer_name  = customer;
    this.balance   = 0d;

    System.out.println("======================================================");
    System.out.println("CheckingsBean::account_number =" + this.account_number);
    System.out.println("CheckingsBean::customer_name =" + this.customer_name);
    System.out.println("CheckingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbPostCreate( int accountNo, String customer)
    throws RemoteException, CreateException { 
    
    System.out.println("======================================================");
    System.out.println("Invoking 2 parameter CheckingsBean::ejbPostCreate");
    System.out.println("CheckingsBean::account_number =" + this.account_number);
    System.out.println("CheckingsBean::customer_name =" + this.customer_name);
    System.out.println("CheckingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbCreate( int accountNo, String customer, double balance)
    throws RemoteException, CreateException { 
    
    System.out.println("Invoking 3 parameter CheckingsBean::ejbCreate");
    this.account_number = accountNo;
    this.customer_name  = customer;
    this.balance   = balance;
    System.out.println("======================================================");
    System.out.println("CheckingsBean::account_number =" + this.account_number);
    System.out.println("CheckingsBean::customer_name =" + this.customer_name);
    System.out.println("CheckingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbPostCreate( int accountNo, String customer, double balance)
    throws RemoteException, CreateException { 
    
    System.out.println("======================================================");
    System.out.println("Invoking 3 parameter CheckingsBean::ejbPostCreate");
    System.out.println("CheckingsBean::account_number =" + this.account_number);
    System.out.println("CheckingsBean::customer_name =" + this.customer_name);
    System.out.println("CheckingsBean::balance =" + this.balance);
    System.out.println("======================================================");
  }

  public void ejbActivate() throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::ejbActivate======");
  }

  public void ejbLoad() throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::ejbLoad==========");
  }

  public void ejbPassivate() throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::ejbPassivate=====");
  }

  public void ejbRemove() throws RemoteException, RemoveException { 
    System.out.println("==============Invoking CheckingsBean::ejbRemove========");
  }

  public void ejbStore() throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::ejbStore=========");
  }

  public void setEntityContext(EntityContext context) throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::setEntityContext=");
    this._entityContext = context;
  }

  public void unsetEntityContext() throws RemoteException { 
    System.out.println("==============Invoking CheckingsBean::unsetEntityContext");
    this._entityContext = null;
  }

  private void jbInit() throws Exception { 
    System.out.println("==============Invoking CheckingsBean::jbInit============");
  }	
}

 