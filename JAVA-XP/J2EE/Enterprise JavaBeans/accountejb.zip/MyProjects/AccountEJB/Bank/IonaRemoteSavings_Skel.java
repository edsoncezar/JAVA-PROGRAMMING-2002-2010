// This file was generated on Sat Mar 27 00:25:23 CST 1999
// by HomeBase 0.5.1 (Scunthorpe)
// (c) Copyright IONA Technologies PLC 1999.  All Rights Reserved.


package Bank;

public final class IonaRemoteSavings_Skel extends java.lang.Object implements java.rmi.server.Skeleton {
  private static java.rmi.server.Operation[] operations =  {
    new java.rmi.server.Operation("javax.ejb.EJBHome getEJBHome()"),
    new java.rmi.server.Operation("java.lang.Object getPrimaryKey()"),
    new java.rmi.server.Operation("void remove()"),
    new java.rmi.server.Operation("javax.ejb.Handle getHandle()"),
    new java.rmi.server.Operation("boolean isIdentical(javax.ejb.EJBObject _param0)"),
    new java.rmi.server.Operation("void credit(double _param0)"),
    new java.rmi.server.Operation("void debit(double _param0)"),
    new java.rmi.server.Operation("double getBalance()"),
    new java.rmi.server.Operation("int getAccountNumber()"),
    new java.rmi.server.Operation("java.lang.String getCustomerName()"),
  };

  private static final long ifHash=1586775L;

  public java.rmi.server.Operation[] getOperations() {
    return operations;
  }

  public void dispatch(java.rmi.Remote r,java.rmi.server.RemoteCall rc,int op,long h) throws java.rmi.RemoteException, Exception {
    if (h!=ifHash) throw new java.rmi.server.SkeletonMismatchException("Mismatch between stub and skeleton");
    Bank.Savings server=(Bank.Savings)r;
    try {
      switch (op) {
        case 0: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          javax.ejb.EJBHome $res=server.getEJBHome();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 1: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          java.lang.Object $res=server.getPrimaryKey();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 2: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.remove();
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 3: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          javax.ejb.Handle $res=server.getHandle();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 4: {
          javax.ejb.EJBObject _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=(javax.ejb.EJBObject)in.readObject();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          boolean $res=server.isIdentical(_param0);
          try {
            rc.getResultStream(true).writeBoolean($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 5: {
          double _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=in.readDouble();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.credit(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 6: {
          double _param0;
          try {
            java.io.ObjectInput in=rc.getInputStream();
            _param0=in.readDouble();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          server.debit(_param0);
          try {
            rc.getResultStream(true);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 7: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          double $res=server.getBalance();
          try {
            rc.getResultStream(true).writeDouble($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 8: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          int $res=server.getAccountNumber();
          try {
            rc.getResultStream(true).writeInt($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

        case 9: {
          try {
            java.io.ObjectInput in=rc.getInputStream();
            com.ejbhome.jts.rmi.RemoteControl tx = (com.ejbhome.jts.rmi.RemoteControl)in.readObject();
            if (tx!=null) com.ejbhome.jts.Current.propagate(tx); else com.ejbhome.jts.Current.forget();
          } catch (java.io.IOException ex) {
            throw new java.rmi.UnmarshalException("Error unmarshalling arguments",ex);
          } finally {
            rc.releaseInputStream();
          }
          java.lang.String $res=server.getCustomerName();
          try {
            rc.getResultStream(true).writeObject($res);
          } catch (java.io.IOException ex) {
            throw new java.rmi.MarshalException("Error marshalling return",ex);
          }
          break;
        }

      }
    } catch (Exception tempex) {
      if (tempex instanceof RuntimeException) {
        com.ejbhome.util.Trace.trace("Runtime exception thrown:");
        tempex.printStackTrace();
      }
      throw tempex;
    }
  }

}
