import java.io.*;
import java.util.*;

class ObjetoParaDisco {
    public static void main(String[] args) throws IOException {
        FileOutputStream out = new FileOutputStream("Agora");
        ObjectOutputStream s = new ObjectOutputStream(out);
        s.writeObject("Agora �");
        s.writeObject(new Date());
        s.flush();
    }
}