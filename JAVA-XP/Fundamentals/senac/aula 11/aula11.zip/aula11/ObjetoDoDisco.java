 import java.io.*;
import java.util.*;

class ObjetoDoDisco {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FileInputStream in = new FileInputStream("Agora");
        ObjectInputStream s = new ObjectInputStream(in);
        String today = (String)s.readObject();
        Date date = (Date)s.readObject();
        
        System.out.println(today);
        System.out.println(date);
        
        }
}
