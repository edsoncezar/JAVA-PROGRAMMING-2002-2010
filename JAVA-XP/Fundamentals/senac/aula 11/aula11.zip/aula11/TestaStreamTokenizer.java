import java.io.*;

public class TestaStreamTokenizer
{
    public static void main(String[] args) throws IOException {
        StreamTokenizer tokenizer = new StreamTokenizer(new FileReader("entrada.txt"));
        int token = StreamTokenizer.TT_EOL;
        while (token!=StreamTokenizer.TT_EOF){
            token = tokenizer.nextToken(); 
            switch(token){
                case StreamTokenizer.TT_NUMBER:
                    //System.out.println("N�mero:");                 
                    break;
                case StreamTokenizer.TT_WORD:                
                    //System.out.println("Palavra:");                
                    break;
                case StreamTokenizer.TT_EOL:                
                    //System.out.println("Quebra de linha");
                    break;
             }
             System.out.println(tokenizer.toString());
                
            }
        }
    }


