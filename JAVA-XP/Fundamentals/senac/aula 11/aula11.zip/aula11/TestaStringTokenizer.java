import java.io.*;
import java.util.*;
    
public class TestaStringTokenizer
{
    public static void main(String[] args) throws IOException {
        String str = "Keep walking.Johnnie Walker. Keep.";
        StringTokenizer tokenizer = new StringTokenizer(str, " .ai");
        while(tokenizer.hasMoreTokens()){
            System.out.println(tokenizer.nextToken());
        }
    }
}
