import java.io.*;
import java.util.*;
import java.nio.charset.*;
import java.nio.*;

/**
 *  Converte um arquivo texto de um esquema de codifica��o para outro 
 *  args[0] nome do arquivo de entrada
 *  args[1] nome do esquema de codifica��o do arquivo de entrada
 *  args[2] nome do esquema de codifica��o do arquivo de sa�da
 *  args[3] nome do arquivo de sa�da (se omitido ser� saida.txt)
 */
public class ConverteEncodings
{
    public static void main(String[] args) throws Exception {       
        printEncodings();     //Imprime lista de encodings dispon�veis
        
        /**
         *  Checa se ao menos tr�s argumentos foram digitados 
         */
        if (args.length < 3){
            System.out.println("Uso : java ConverteEncodings arq_entrada encoding_entrada encoding_saida arq_saida");
            System.exit(0);            
        }                        
        
        /**
         *  Se o 3.o argumento n�o for digitado, o arquivo de sa�da vai se chamar "saida.txt"
         */        
        String saida = "saida.txt";
        if (args.length==4){
            saida = args[3];
        }
       
        
        /**
         * Abre(e cria, se preciso) o arquivo de sa�da, e aloca um stream de caracteres sobre ele
         */
        FileOutputStream outfile = new FileOutputStream(saida);
        OutputStreamWriter writer = new OutputStreamWriter(outfile, args[2]);        
        /**
         * Abre o arquivo de entrada
         */        
        InputStreamReader reader = new InputStreamReader(new FileInputStream(args[0]), args[1]);
        
        /**
         * L� do arquivo de entrada em blocos de 8192 caracteres
         */ 
        char[] buffer = new char[8192];        
        int quant;
        while((quant = reader.read(buffer))!=-1){
            writer.write(buffer, 0, quant);
        }
        
        reader.close();
        writer.close();
        outfile.close();
        System.out.println("Output written to "+saida);
        
    }
    
    /**
     *  Imprime os encodings dispon�veis na plataforma em quest�o
     */
    static void printEncodings(){
            System.out.println("Encodings dispon�veis");
            SortedMap map = Charset.availableCharsets();            
            Collection conjunto = map.values();
            Iterator iter = conjunto.iterator();
            while (iter.hasNext()){
                System.out.println(iter.next());
            }        
    }
}