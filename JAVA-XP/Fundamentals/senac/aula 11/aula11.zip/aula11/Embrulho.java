import java.io.*;

class Embrulho {
    public static void main(String[] args){
           File file = new File("entrada.txt"); 
           FileReader fReader = null;
           try {
               fReader = new FileReader(file); 
           } catch (FileNotFoundException fnf){
               System.out.println("O arquivo "+file+" n�o p�de ser encontrado");
           }
           BufferedReader buff = new BufferedReader(fReader);
           String s;

           int linhas = 0; 
           try {               
               s= buff.readLine();
               linhas ++;
               while (s!=null){
                   System.out.println(linhas+":"+s);
                   s = buff.readLine();
                   linhas ++;
              }
          } catch (IOException ioex){
               System.out.println("Problemas na leitura do arquivo");
          }
           
    }
}