import java.beans.*;
import java.io.*;
import java.util.Date;

public class XMLObject
{
    public static void main(String[] args) throws Exception {
        FileOutputStream fout = new FileOutputStream("DateOut.xml");
        XMLEncoder enc = new XMLEncoder(fout);
        Date d = new Date();
        enc.writeObject(d);
        
        Ponto p = new Ponto(5, 6);
        enc.writeObject(p);
        enc.close();
    }
}
