import java.io.*;

public class ConsoleIO {        
   public static void main(String[] args) {
       /* Fazemos o embrulho de System.in em um InputStreamReader para conseguirmos fazer o uso*/ 
       BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
       PrintStream out = System.out;

       String leitura = "";
       while (!leitura.equals("fora")){
            try {
                leitura = inputReader.readLine();
            } catch (IOException error){
                System.out.println("Erro durante a leitura de bytes");
            }
            out.println("O que voc� escreveu foi: "+leitura);
       }
    }
}
