import java.beans.*;
import java.io.*;
import java.util.Date;

public class XMLObjectRead
{
    public static void main(String[] args) throws Exception {
        FileInputStream fin = new FileInputStream("DateOut.xml");
        XMLDecoder dec = new XMLDecoder(fin);
        Date d = (Date) dec.readObject();
        System.out.println(d);
        
        Ponto p = (Ponto) dec.readObject();        
        dec.close();
    }
}
