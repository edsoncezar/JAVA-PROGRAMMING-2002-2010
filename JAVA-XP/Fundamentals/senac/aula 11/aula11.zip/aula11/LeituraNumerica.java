import java.io.*;

public class LeituraNumerica {
    public static void main(String[] args){
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        PrintStream print = System.out;
        
        String linha;
        int idade = 0;
        double peso = 0.0;
        
        try {
            print.println("Por favor, digite a sua idade");
            linha = reader.readLine();
            idade = Integer.parseInt(linha);
            
            print.println("Agora por favor, digite seu peso");
            linha = reader.readLine();
            peso = Double.parseDouble(linha);
            
        } catch (IOException e){
        }

        print.println("Idade: "+idade+" Peso: "+peso);
        print.println(Integer.toBinaryString(idade));
        
        
    }
}
