import java.io.*;

public class AcessoAleatorio {
    public static void main(String[] args) throws IOException {
           RandomAccessFile raf = new RandomAccessFile("xis.txt", "rw");
           long comprimento = raf.length();
           int curr = 1;
           while (curr < comprimento){
               curr = curr + 10;
               raf.seek(curr);
               raf.writeBytes("Oi");
           }
    }
}