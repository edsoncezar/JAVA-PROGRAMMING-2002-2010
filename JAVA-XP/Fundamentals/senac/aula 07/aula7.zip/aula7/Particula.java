class Particula extends Ponto {

    double massa = 1.0;

    public double calculaPeso(){
        // Imprimir o peso ao final        
        return massa * 10.0;
    }
    
    void mover(){
        //
    }

    public void imprime(){
        System.out.println("Part�cula");
        System.out.println("Massa: "+ massa);
        System.out.println("x:" +x+ "y:" +y+ "z:" +z);
    }
    
    void superImprime(){
        System.out.println("Vers�o de Ponto");
        super.imprime();
    }    

}