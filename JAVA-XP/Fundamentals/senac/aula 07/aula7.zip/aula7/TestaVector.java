import java.util.Vector;
class TestaVector {
    Vector v;
    Vector testa(){
        Ponto p = new Ponto();
        Particula par = new Particula();
        String s = "Java";
        
        Vector v = new Vector();
        v.add(s);
        v.add(p);
        v.add(par);                         
        return v;
    }
}