class PrintTest {
    String p = "ABC";

    public static void main(String[] args){
        PrintTest test = new PrintTest();
        System.out.println(test);        
        System.out.println(test.toString());
    }
}

