class Pegadinha {
    public static void main(String[] args){
        Particula par = new Particula();    
        Ponto p = par;
        p.imprime();
    }
}