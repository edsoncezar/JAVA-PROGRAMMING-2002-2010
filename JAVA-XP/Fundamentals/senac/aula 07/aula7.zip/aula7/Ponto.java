class Ponto {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    
    Ponto(){
    }
    
    void mover(double dx, double dy, double dz){
        x += dx;
        y += dy;
        z += dz;
    }
    
    void imprime(){
       System.out.print("Ponto ");
       System.out.print("x "+ x +"y "+ y +"z "+ z);        
    }
    
}