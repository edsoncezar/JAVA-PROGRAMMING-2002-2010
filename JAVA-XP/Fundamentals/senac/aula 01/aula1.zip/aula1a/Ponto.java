class Ponto {
    int x;
    int y;
    Ponto pr�ximo;
    void setaValor(int vx, int vy){
        x = vx;
        y = vy;
    }
    void setaPr�ximo(Ponto prox){
        pr�ximo = prox;
    }
    
    
}