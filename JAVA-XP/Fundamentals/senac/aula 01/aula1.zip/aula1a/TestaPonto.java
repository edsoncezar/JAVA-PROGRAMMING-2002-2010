/**
 *  Esta classe foi escrita para testar a classe Ponto
 * /
class TestaPonto {
}