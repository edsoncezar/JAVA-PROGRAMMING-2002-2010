class Ponto {
    int x;
    int y;
    Ponto pr�ximo;
    
    void setaValor(int vx, int vy){
        x = vx;
        y = vy;
    }
    /* Para criar uma estrutura ligada de pontos*/
    void setaPr�ximo(Ponto prox){
        pr�ximo = prox;
    }        
    void imprime(){
        System.out.println("(" + x + ", " + y + ")");
    }
}