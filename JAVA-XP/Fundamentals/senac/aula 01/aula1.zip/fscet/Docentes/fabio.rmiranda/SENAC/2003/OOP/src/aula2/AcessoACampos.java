/* Monta uma lista ligada sem utilizar o m�todo setaPr�ximo */
class AcessoACampos
{
    void fazDeUmJeito(){
        Ponto p1 = new Ponto();
        Ponto p2 = new Ponto();
        Ponto p3 = new Ponto();
        p1.pr�ximo = p2;
        p2.pr�ximo = p3;
    }
    
    void fazDeOutroJeito(){
        Ponto p1 = new Ponto();
        Ponto p2 = new Ponto();
        Ponto p3 = new Ponto();
        p1.pr�ximo = p2;
        p1.pr�ximo.pr�ximo = p3;
    }
}
