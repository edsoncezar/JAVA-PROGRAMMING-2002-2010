struct ponto {
	int x;
	int y;
}

typedef struct ponto sPonto;

int distancia(sPonto* a, sPonto* b){
	return ((*a).x - (*b).x) + ((*a).y - (*b).y);
}


int main(){
	struct ponto p1;
	struct ponto p2;
	p1.x = 0;
	p1.y = 1;

	p2.x = 1;
	p2.y = 0;

}
