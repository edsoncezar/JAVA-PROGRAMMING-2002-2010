class QuantasReferencias {
    /**
     * O objetivo deste exemplo � identificar quantas refer�ncias e quantos objetos s�o criados
     * */
    void fazTeste(){
        Ponto p1;
        Ponto p2;
        Ponto p3;
        Ponto p4;
        Ponto p5;
        p1 = new Ponto();
        p2 = new Ponto();
        new Ponto();
    }
}