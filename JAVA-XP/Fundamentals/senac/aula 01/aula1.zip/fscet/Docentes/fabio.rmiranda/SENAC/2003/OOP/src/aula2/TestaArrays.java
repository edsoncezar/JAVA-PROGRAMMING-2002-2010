class TestaArrays {
    void fazTeste(){
        boolean[][] meusBits = new boolean[10][];
        for (int i = 0; i < meusBits.length; i++){
            meusBits[i] = new boolean[i + 1];
            imprime(meusBits[i]);
        }
    }
    
    void imprime(boolean[] array){
        for (int i = 0; i <  array.length; i++){
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
}
