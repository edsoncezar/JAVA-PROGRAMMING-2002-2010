//#########################################
//Cristian Alberto Barrueco Valenzuela 3NA
//#########################################
import java.awt.*;
import java.awt.geom.*;

/*
 * # O enunciado pedia para extender a classe Canvas.
 */ 
public class DesenhaNAgono
{

    /**
     * Constructor for objects of class Desenha_N_Agono
     */
    public DesenhaNAgono()
    {
     
    }
    
    public void desenha(){
       int numero;
        SimpleInput a = new SimpleInput();
        numero = a.getInt("Digite o numero de lados do poligono");
        desenhaNagono(numero);
    }
    
    private void desenhaNagono(int n){
        int i; // contador de itera��es
        double alfa; // �ngulo, 2 Pi dividido pelo numero de lados
        double alfaProx; // �ngulo somado a alfa
        double raio = 200.0; // Raio
        int x1 = 300; // x inicial
        int y1 = 300; //y inicial
        int xBase = 500; // x do Primeiro Ponto
        int yBase = 300; // y do Primeiro Ponto
        int xProx; // x do Segundo Ponto
        int yProx; // y do Segundo Ponto
        
        Canvas myCanvas = new Canvas("Pol�gono de n Lados", 600, 600);
        myCanvas.setVisible(true);
        
        alfa = (2*Math.PI)/n;
        alfaProx = 0.0;
        
        myCanvas.drawString("Pol�gono de " + n + " Lados.", 20, 20);
        
        for(i=1;i<=n;i++){
            alfaProx = alfaProx + alfa;

            xProx = x1 + (int) (raio * Math.cos(alfaProx));
            yProx = y1 + (int) (raio * Math.sin(alfaProx));

            myCanvas.drawLine(xBase, yBase, xProx, yProx);
            xBase = xProx;
            yBase = yProx;
        }
    }
}
