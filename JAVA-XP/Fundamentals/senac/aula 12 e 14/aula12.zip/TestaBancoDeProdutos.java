
/**
 * 
 * @author Carlos Santos 
 * @version 12/09/2003
 */
public class TestaBancoDeProdutos
{
	public static void main(String[] args){
	    BancoDeProdutos banco = new BancoDeProdutos("entrada.txt");
	    Produto teste = new Produto("Coca-Cola","12345");
	    banco.adiciona(teste);
	    try{
	        Produto resultado = banco.busca(teste.getNome());
	        if(resultado!=teste) System.out.println("A busca falhou");
	        else System.out.println("A busca funcionou");
	    }catch(ProdutoException pe){
	        pe.printStackTrace();
	    }
	}
}
