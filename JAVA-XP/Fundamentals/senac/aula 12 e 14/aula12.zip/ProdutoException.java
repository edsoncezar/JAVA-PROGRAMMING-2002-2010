
/**
 * Exce��o lan�ada quando ocorrem erros relacionados a produtos.
 * 
 * @author Carlos Santos
 * @version 12/09/2003
 */
public class ProdutoException extends Exception
{
	
	/**
	 * 
	 */
	public ProdutoException(String descritor)
	{
	    super(descritor);
	}


}
