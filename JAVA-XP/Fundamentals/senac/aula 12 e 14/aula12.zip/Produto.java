
/**
 * Classe cujos objetos v�o constituir os dados a armazenar no Banco de Dados
 * 
 * @author F�bio de Miranda
 * @version 0.09a
 */
public class Produto
{

    private String nome;
    private String c�digo;
    
    /**
     *  Construtor padr�o
     */     
    public Produto()
    {
    }
    
    /**
     *  Construtor mais completo
     */     
    public Produto(String nome, String c�digo){
        setNome(nome);
        setC�digo(c�digo);
    }

    /**
     * M�todos de acesso aos atributos privados da classe
     */
    public String getNome(){
        return this.nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getC�digo(){
        return this.c�digo;
    }
        
    public void setC�digo(String c�digo){
        this.c�digo = c�digo;
    }
    
}
