import java.util.Map;
import java.util.HashMap;

/**
 * 
 */
public class BancoDeProdutos
{

   public BancoDeProdutos(String arquivoDeDados){
       
   }
   
   public void adiciona(Produto produto){
       
   }
   
   public Produto busca(String nome) throws ProdutoException{
      return new Produto("Nada","0000");
   }
   
   public void mudaCodigo(String produto, String novoCodigo){
   
   }
   
}
