class Logradouro {
    /* Constantes */
    static final int RUA      =   0;
    static final int AVENIDA  =   1;
    static final int PRA�A    =   2;
    
    String CEP;
    String nome;
    int tipo;
    
    Logradouro(int tipo, String nome, String CEP){
        this.CEP = CEP;
        this.nome = nome;
        this.tipo = tipo;
    }
    
   String paraString(){
        String resultado = "";
        switch(tipo){
            case PRA�A:
                resultado += "Pra�a ";
                break;
             case RUA:
                resultado += "Rua ";
                break;
             case AVENIDA:
                resultado += "Avenida ";
                break;
             default:
                System.out.println("tipo inv�lido");
                break;
        }
        resultado += nome;
        return resultado;
   }
   
   String getCEP(){
        return CEP;
   }
}