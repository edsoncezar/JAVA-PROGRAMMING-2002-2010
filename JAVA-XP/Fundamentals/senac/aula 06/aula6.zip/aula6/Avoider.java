import josx.platform.rcx.*;
import josx.util.TimerListener;
import josx.util.Timer;

/**
 *  Programa utilizado no exemplo do rob�. N�o se incomodem em l�-lo
 * /
public class Avoider {    
    public static void main(String[] args){     
        Sleeper sleeper = new Sleeper();  // Permite "esperar" algo acontecer       
            
        // Cria os sensores
        /* Bot�o do lado esquerdo */
        TouchSensor botaoEsquerdo = new TouchSensor(1); 
        /* Bot�o do lado direito */
        TouchSensor botaoDireito = new TouchSensor(3);  

        // Cria os motores
        CustomMotor motorEsquerdo = new CustomMotor('A');
        CustomMotor motorDireito = new CustomMotor('C');
    
        // Aciona os motores
        motorEsquerdo.forward();
        motorDireito.forward();
    
     /**
       * Loop principal - Faz o rob� seguir obst�culos
       */         
     while (true) {
        Sleeper.sleep(200); // pausa
                
        // Quando a esquerda do rob� bate
        if (botaoEsquerdo.isPressed()){
            // Recua os dois motores
            motorEsquerdo.backward(); 
            motorDireito.backward();
            Sleeper.sleep(300);

            motorDireito.backward();
            motorEsquerdo.forward();
            Sleeper.sleep(300);
            
            //Retoma o movimento anterior

            motorEsquerdo.forward();
            motorDireito.forward();
        }
            
        // Quando a direita do rob� bate
        if (botaoDireito.isPressed()){
            // Recua os dois motores
            motorEsquerdo.backward(); 
            motorDireito.backward();
            Sleeper.sleep(300);

            motorEsquerdo.backward();
            motorDireito.forward();
            Sleeper.sleep(300);
            
            //Retoma o movimento anterior

            motorEsquerdo.forward();
            motorDireito.forward();
        }        
    }
    }
    
}

