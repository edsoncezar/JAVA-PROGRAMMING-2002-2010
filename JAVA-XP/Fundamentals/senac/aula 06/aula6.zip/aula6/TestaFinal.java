class TestaFinal {
    final Ponto p = new Ponto(5,-5);
    final int valor = 42;

    /* N�o vai compilar */
    void setaValor(int i){
        valor = i;
    }
        
    Ponto getPonto(){
        return this.p;
    }
    
}