class Endere�o {
    Logradouro logradouro;
    int n�mero;
    String complemento;
    Cidade cidade;
    Endere�o(Logradouro logradouro, int n�mero, String complemento, Cidade cidade){
        this.logradouro = logradouro;
        this.n�mero = n�mero;
        this.complemento = complemento;
        this.cidade = cidade;
        imprime(); //funciona
    }
    
    void imprime(){
        System.out.println(
            logradouro.paraString()
            +", "
            + n�mero
            + ", "
            + complemento
            + ", "
            + cidade.getNome());
    }
    
    public static void main(String[] args){
        // N�o d� certo
        // imprime();
        
        /* Jeito certo
        Logradouro logradouro = new Logradouro(Logradouro.RUA, "Tito", "05555-555");
        Cidade s�oPaulo = new Cidade("S�o Paulo", "SP");
        Endere�o end3NA = new Endere�o(logradouro, 54, "Sala 12", s�oPaulo);
        end3NA.imprime();
        */
    }
}