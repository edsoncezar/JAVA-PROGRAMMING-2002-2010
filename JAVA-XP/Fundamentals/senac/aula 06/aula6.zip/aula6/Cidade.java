class Cidade {
    String nome;
    String estado;
    Cidade(String nome, String estado){
        this.nome = nome;
        this.estado = estado;        
    }
    String getNome(){
        return nome;
    }
}