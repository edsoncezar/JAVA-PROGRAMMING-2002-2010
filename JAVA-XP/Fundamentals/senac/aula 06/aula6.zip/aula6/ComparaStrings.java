class ComparaStrings
{
    public static void main(String[] args){
        String a = "Java";
        String b = "Java";
        if (a == b){
            print("As Strings a e b s�o iguais");
        }
        
        ContemString contem = new ContemString();
        TambemContemString tambemContem =
            new TambemContemString();
        if (contem.conte�do == tambemContem.conte�do){
            print("Os conte�dos s�o diferentes");  
        }        
    }
    static void print(String s){
        System.out.println(s);
    }
}
