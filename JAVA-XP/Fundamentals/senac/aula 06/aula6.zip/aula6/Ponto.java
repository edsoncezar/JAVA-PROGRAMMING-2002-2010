class Ponto {
    /**
     *  Class Ponto com construtores
     */
    int x;
    int y;    
    Ponto(int vx, int vy){
        x = vx;
        y = vy;
    }
    Ponto(){
    }
    
    void setaValor(int x, int y){
        this.x = x;
        this.y = y;
    }
}