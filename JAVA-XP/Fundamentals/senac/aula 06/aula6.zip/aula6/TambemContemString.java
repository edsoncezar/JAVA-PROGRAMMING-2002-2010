class TambemContemString {
    String conte�do = "Java";
}