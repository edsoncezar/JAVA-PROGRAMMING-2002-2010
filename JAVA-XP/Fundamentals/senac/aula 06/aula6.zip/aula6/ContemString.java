class ContemString{
    String conte�do = "Java";
}