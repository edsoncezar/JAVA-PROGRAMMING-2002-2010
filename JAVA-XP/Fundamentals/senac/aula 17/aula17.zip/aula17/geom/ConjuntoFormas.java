package geom;

import java.awt.Color;
import java.awt.Graphics;

public class ConjuntoFormas {

    Color fundo;

    // Vamos limitar o n�mero de formas a 10, por enquanto
    Forma[] formas = new Forma[15];

    /**
     * Construtor de conjuntoFormas: Onde todas as
     * formas que quisermos ser�o criadas
     */

    public ConjuntoFormas(){
        Retangulo ret = new Retangulo(50, 50, 40, 25);
        ret.setNome("Ret�ngulo");
        Triangulo tri = new Triangulo(10, 10, 30, 10, 20, 20);
        tri.setNome("triangulo");
        formas[0] = ret;
        formas[1] = tri;
    }

     public void desenhaTodos(Graphics g){
        for (int i = 0; i < formas.length; i++) {
            if (formas[i]!=null){
                formas[i].desenhaForma(g);
                formas[i].desenhaCentro(g);
            }
        }
    }



    public void mover(String nome, int deltaX, int deltaY){
        /*
         * Varre o array de formas em busca de todas cujo nome
         * � uma String igual � vari�vel "nome"
         */
        for (int i = 0; i < formas.length; i++) {
            if (formas[i]!=null){
                if(nome.equals(formas[i].toString())){
                    formas[i].mover(deltaX, deltaY);
                }
            }
        }

    }
}