package geom;

import java.awt.Graphics;
import java.awt.Color;

/**
 * Esta classe � uma subclasse de java.awt.Point
 * Podemos fazer subclasses de classes da Java API!
 */
public class PontoBase extends java.awt.Point {

/* Usar o "nome completo" java.awt.Point �
    equivalente a usar um "import java.awt.*; e chamar a classe apenas de "Point"*/

    /* O Ponto ser� sempre desenhado em preto  */
    Color corDoPonto = new Color(0, 0, 0);

    public PontoBase(int x, int y) {
        super(x,y);
    }

    public void desenha(Graphics g){
        g.setColor(corDoPonto);
        // Desenha uma cruzinha, para definir bem o ponto
        if (g == null){
            System.out.println("G nulo!");
            return;
        }
        g.drawLine(x-3, y, x + 3, y);
        g.drawLine(x, y - 3, x, y + 3);
    }

}