package geom;

import java.awt.Graphics;
import java.awt.Color;

public abstract class Forma {

    Color corDeFundo = new Color(255, 0, 0);
    Color corDeLinha = new Color(0, 0, 0);
    String nome;

    PontoBase base = new PontoBase(0, 0);

    public void desenhaCentro(Graphics g){
        g.setColor(corDeLinha);
        base.desenha(g);
        g.drawString(nome, base.x, base.y);
    }

    public abstract void desenhaForma(Graphics g);

    /**
     * "Move" a forma de um lado para outro alterando a posi��o de seu PontoBase
     */
    public void mover(int deltaX, int deltaY){
        base.x += deltaX;
        base.y += deltaY;
    }

    /* Criar uma representa��o deste objeto na forma de uma String*/
    public String toString(){
        // O crit�rio para criar tal representa��o fica a nosso gosto
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

}