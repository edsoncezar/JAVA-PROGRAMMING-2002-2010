package geom;

import java.awt.Point;
import java.awt.Graphics;

public class Triangulo extends Forma {

    /* Pontos para guardar as quinas do tri�ngulo */
    Point p1;
    Point p2;
    Point p3;

    public Triangulo(int x1, int y1, int x2, int y2, int x3, int y3) {
        p1 = new Point(x1, y1);
        p2 = new Point(x2, y2);
        p3 = new Point(x3, y3);

        // Posiciona a base no centro geom�trico do tri�ngulo
        base.x = (p1.x + p2.x + p3.x)/3;
        base.y = (p1.y + p2.y + p3.y)/3;
        // Muda as coordenadas dos pontos para que fiquem relativos
        // � base
        p1.x -= base.x;
        p2.x -= base.x;
        p3.x -= base.x;
        p1.y -= base.y;
        p2.y -= base.y;
        p3.y -= base.y;
    }

    public void desenhaForma(Graphics g){
        int[] xs = {p1.x + base.x, p2.x + base.x, p3.x + base.x};
        int[] ys = {p2.y + base.y, p2.y + base.y, p3.y + base.y};
        g.setColor(this.corDeFundo);
        g.fillPolygon(xs, ys, 3);
        g.setColor(this.corDeLinha);
        g.drawPolygon(xs, ys, 3);
    }

    
   
}