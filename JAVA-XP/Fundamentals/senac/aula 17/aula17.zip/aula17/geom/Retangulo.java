package geom;

import java.awt.Graphics;

public class Retangulo extends Forma{

    int largura;
    int altura;

    public Retangulo(int xCentro, int yCentro, int largura, int altura) {
        /* O ponto base vai representar o centro do objeto */
        base.x = xCentro;
        base.y = yCentro;
        this.largura = largura;
        this.altura  = altura;
    }

    public void desenhaForma(Graphics g){
        // Desenha o fundo
        g.setColor(this.corDeFundo);
        g.fillRect(base.x, base.y, largura, altura);

        // Desenha o contorno
        g.setColor(this.corDeLinha);
        g.drawRect(base.x, base.y, largura, altura);

    }
}