package geom;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class PrimeiroApplet extends Applet {
    boolean isStandalone = false;
    ConjuntoFormas conjuntoFormas;

    //Construct the applet
    public PrimeiroApplet() {
        conjuntoFormas = new ConjuntoFormas();
    }
    //Initialize the applet
    public void init() {
    }

    //Start the applet
    public void start() {
    }
    //Stop the applet
    public void stop() {
    }
    //Destroy the applet
    public void destroy() {
    }

    //Get Applet information
    public String getAppletInfo() {
        return "Applet Information";
    }

    public void paint(Graphics g){
        conjuntoFormas.desenhaTodos(g);
    }

    // m�todo main
    //    Existe para permitir ao applet rodar sem depender de uma p�gina em HTML.
    // N�o � obrigat�rio
    public static void main(String[] args) {
        PrimeiroApplet applet = new PrimeiroApplet();
        applet.isStandalone = true;
        Frame frame;
        frame = new Frame() {
            protected void processWindowEvent(WindowEvent e) {
                super.processWindowEvent(e);
                if (e.getID() == WindowEvent.WINDOW_CLOSING) {
                    System.exit(0);
                }
            }
            public synchronized void setTitle(String title) {
                super.setTitle(title);
                enableEvents(AWTEvent.WINDOW_EVENT_MASK);
            }
        };
        frame.setTitle("Applet Frame");
        frame.add(applet, BorderLayout.CENTER);
        applet.init();
        applet.start();
        frame.setSize(400,320);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        frame.setVisible(true);
    }
}