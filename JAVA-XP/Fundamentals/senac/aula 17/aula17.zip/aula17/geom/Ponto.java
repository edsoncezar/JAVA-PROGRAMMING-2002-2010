package geom;

// Esta classe est� marcada para a morte

public class Ponto {

    public Ponto() {
    }
    public static void main(String[] args) {
        Ponto ponto1 = new Ponto();
    }
}