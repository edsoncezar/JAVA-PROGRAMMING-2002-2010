interface Gritador {
    public void gritar(String s);
}
