import josx.platform.rcx.*;

public class RoboMain
{
    public static void main(String[] args) throws InterruptedException {
        Sensor botao1 = Sensor.S1;
        botao1.setTypeAndMode(SensorConstants.SENSOR_TYPE_TOUCH, SensorConstants.SENSOR_MODE_BOOL);
        ImplementaSensorListener listener = new ImplementaSensorListener();
        botao1.addSensorListener(listener);
        while(true){
            Thread.sleep(20);
        }
    }
}
