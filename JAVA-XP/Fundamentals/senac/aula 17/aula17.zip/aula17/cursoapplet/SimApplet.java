package cursoapplet;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;
import geom.ConjuntoFormas;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SimApplet extends JApplet implements ActionListener {
    int deltaX = 5;
    int deltaY = 5;
    ConjuntoFormas conjuntoFormas = new ConjuntoFormas();
    boolean isStandalone = false;
    String corFundo;
    String corFrente;
    Color bgColor = null;
    Color fgColor = null;
    JPanel jPanel1 = new JPanel();
    BorderLayout borderLayout1 = new BorderLayout();    

    JPanel painelDesenho = new JPanel();
    JPanel painelBaixo = new JPanel();
    FlowLayout flowLayout1 = new FlowLayout();
    JTextField objetoSelTxt = new JTextField();
    JLabel objetoSelLabel = new JLabel();
    JLabel keyHintLabel = new JLabel();

    javax.swing.Timer timer = new javax.swing.Timer(100, this);

    //Get a parameter value
    public String getParameter(String key, String def) {
        return isStandalone ? System.getProperty(key, def) :
            (getParameter(key) != null ? getParameter(key) : def);
    }

    //Construct the applet
    public SimApplet() {

    }
    //Initialize the applet
    public void init() {
        try {
            corFundo = this.getParameter("corFundo", "0xd9fd75");
            bgColor = Color.decode(corFundo);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        try {
            corFrente = this.getParameter("corFrente", "0x0b27b5");
            fgColor = Color.decode(corFrente);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        //conjuntoFormas.desenhaTodos(painelDesenho.getGraphics());

    }
    //Component initialization
    private void jbInit() throws Exception {
        this.setContentPane(jPanel1);
        /*
        this.setBackground(bgColor);
        this.setForeground(fgColor);
        */
        painelDesenho.setBackground(bgColor);
        painelDesenho.setForeground(fgColor);
        painelDesenho.setLayout(flowLayout1);

        this.setSize(new Dimension(400,400));
        this.repaint();
        jPanel1.setBackground(SystemColor.menu);
        jPanel1.setLayout(borderLayout1);
        jPanel1.setFocusable(true);
        //this.getContentPane().add(jPanel1, null);
        painelBaixo.setPreferredSize(new Dimension(200, 80));
        painelBaixo.setLayout(null);
        objetoSelTxt.setText("digite aqui");
        objetoSelTxt.setBounds(new Rectangle(127, 24, 122, 26));
        objetoSelLabel.setText("Objeto a mover");
        objetoSelLabel.setBounds(new Rectangle(19, 24, 104, 17));
        keyHintLabel.setBounds(new Rectangle(345, 17, 41, 49));
        painelBaixo.add(objetoSelLabel, null);
        painelBaixo.add(objetoSelTxt, null);
        painelBaixo.add(keyHintLabel, null);
        jPanel1.add(painelDesenho, BorderLayout.CENTER);
        jPanel1.add(painelBaixo, BorderLayout.SOUTH);

        objetoSelTxt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jPanel1.requestFocus();
            }
        });


        jPanel1.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {

            }
            public void keyPressed(KeyEvent e) {
                keyHintLabel.setText(e.getKeyText(e.getKeyCode()));
                int dx = 0;
                int dy = 0;

                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:
                        dy = -deltaY;
                        break;
                    case KeyEvent.VK_DOWN:
                        dy = deltaY;
                        break;
                    case KeyEvent.VK_RIGHT:
                        dx = deltaX;
                        break;
                    case KeyEvent.VK_LEFT:
                        dx = -deltaX;
                        break;
                }

                conjuntoFormas.mover(objetoSelTxt.getText(), dx, dy);
                System.out.println(bgColor);
                Graphics g = painelDesenho.getGraphics();
                g.setColor(bgColor);
                g.fillRect(0 ,0,painelDesenho.getWidth(), painelDesenho.getHeight());
                //painelDesenho.getGraphics().setColor(fgColor);
                conjuntoFormas.desenhaTodos(g);
                g.setColor(bgColor);
            }

            public void keyReleased(KeyEvent e) {
            }
        });

    }
    //Start the applet
    public void start() {
        timer.start();
    }
    //Stop the applet
    public void stop() {
    }
    //Destroy the applet
    public void destroy() {
    }
    //Get Applet information
    public String getAppletInfo() {
        return "Applet Information";
    }
    //Get parameter info
    public String[][] getParameterInfo() {
        String[][] pinfo =
            {
            {"corFundo", "String", ""},
            {"corFrente", "String", ""},
            };
        return pinfo;
    }
    //Main method
    public static void main(String[] args) {
        SimApplet applet = new SimApplet();
        applet.isStandalone = true;
        JFrame frame = new JFrame();
        //EXIT_ON_CLOSE == 3
        frame.setDefaultCloseOperation(3);
        frame.setTitle("Applet Frame");
        frame.getContentPane().add(applet, BorderLayout.CENTER);
        applet.init();
        applet.start();
        frame.setSize(400,420);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        frame.setVisible(true);
    }
    
    /**
     * Implementa a interface ActionListener, para podermos ser notificados pelo Timer
     */
    public void actionPerformed(ActionEvent e){
                Graphics g = painelDesenho.getGraphics();
                g.setColor(bgColor);
                g.fillRect(0 ,0,painelDesenho.getWidth(), painelDesenho.getHeight());
                //painelDesenho.getGraphics().setColor(fgColor);
                conjuntoFormas.desenhaTodos(g);
                g.setColor(bgColor);
    }
}