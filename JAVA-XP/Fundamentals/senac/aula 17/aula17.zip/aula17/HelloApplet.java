
import java.applet.Applet;
import java.awt.*;

/**
 * Write a description of the applet class HelloApplet here.
 *
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HelloApplet extends Applet
{
    String texto;
    /**
     * Called by the browser or applet viewer to inform this Applet that it
     * has been loaded into the system. It is always called before the first 
     * time that the start method is called.
     */
    public void init()
    {
        texto = "Chamando init()!";
        repaint();
    }

    /**
     * Called by the browser or applet viewer to inform this Applet that it 
     * should start its execution. It is called after the init method and 
     * each time the Applet is revisited in a Web page. 
     */
    public void start()
    {
        texto = "Chamando start()!";
        repaint();
    }


    /**
     * paint � chamado toda vez que o applet se redesenha na tela
     *
     * @param  g   the Graphics object for this applet
     */
    public void paint(Graphics g){
        g.drawRect(0, 0, size().width - 1, size().height - 1);
    	//Desenha uma string dentro do de um ret�ngulo
        g.drawString(texto, 5, 15);
    }    


    /** 
     * Called by the browser or applet viewer to inform this Applet that
     * it should stop its execution. It is called when the Web page that
     * contains this Applet has been replaced by another page, and also
     * just before the Applet is to be destroyed. If you do not have any
     * resources that you need to release (such as threads that you may
     * want to stop) you can remove this method.
     */
    public void stop()
    {
        texto = "Chamando stop()!";
        repaint();
    }


    /**
     * Called by the browser or applet viewer to inform this Applet that it
     * is being reclaimed and that it should destroy any resources that it
     * has allocated. The stop method will always be called before destroy. 
     * If you do not have any resources that you need to release you can 
     * remove this method.
     */
    public void destroy()
    {
        texto = "Chamando destroy()!";
        repaint();
    }


    /**
     * Returns information about this applet. 
     * An applet should override this method to return a String containing 
     * information about the author, version, and copyright of the Applet.
     *
     * @return a String representation of information about this Applet
     */
    public String getAppletInfo()
    {
        return "Applet do curso extra de Java";
    }


    /**
     * Returns information about the parameters that are understood by this 
     * Applet. You should return an array of Strings here to provide details
     * about each of the parameters separately.
     * Each element of the array should be a set of three Strings containing 
     * the name, the type, and a description.
     *
     * @return  a String[][] representation of parameter information about 
     *        this Applet
     */
    public String[][] getParameterInfo()
    {
        // provide parameter information about the applet
        String paramInfo[][] = {
             {"firstParameter", "1-10", "description of first parameter"},
             {"secondParameter", "boolean", "description of second parameter"}
        };
        return paramInfo;
    }
    
}
