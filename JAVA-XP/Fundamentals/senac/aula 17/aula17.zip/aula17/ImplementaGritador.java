
class ImplementaGritador extends java.applet.Applet implements Gritador, java.io.Serializable  {

    public static void main(String[] args) {
        ImplementaGritador impGritador = new ImplementaGritador();
        Gritador g = impGritador;
        impGritador.gritar("oi, gente");
    }
    public void gritar(String s){
        System.out.println(s.toUpperCase());
    }
}