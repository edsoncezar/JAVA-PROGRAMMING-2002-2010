import josx.platform.rcx.*;

public class ImplementaSensorListener implements SensorListener {
    public void stateChanged(Sensor s, int oldValue, int newValue){
        Sound.beep();
        LCD.showNumber(newValue);
    }
}
