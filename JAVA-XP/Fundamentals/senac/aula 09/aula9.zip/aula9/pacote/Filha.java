package pacote;

class Filha extends Base{
    Filha(){
        atributo_publico = 0;
        atributo_protected = 0;
        atributo_default = 0;
        atributo_private = 0;
    }
}