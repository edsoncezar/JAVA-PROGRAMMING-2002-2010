package pacote;

class DoPacote {
    DoPacote(){
        Base b = new Base();
        b.atributo_publico = 0;
        b.atributo_protected = 0;
        b.atributo_default = 0;
        b.atributo_private = 0;        
    }
}