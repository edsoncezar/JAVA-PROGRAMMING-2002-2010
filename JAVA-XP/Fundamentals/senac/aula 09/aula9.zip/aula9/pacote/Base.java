package pacote;

class Base {    
    public int atributo_publico;
    protected int atributo_protected;
    int atributo_default;
    private int atributo_private;

}