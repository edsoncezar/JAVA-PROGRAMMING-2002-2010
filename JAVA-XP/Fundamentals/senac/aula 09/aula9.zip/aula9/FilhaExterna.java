import pacote.Base;

class FilhaExterna extends Base {
    FilhaExterna(){
        atributo_publico = 0;
        atributo_protected = 0;
        atributo_default = 0;
        atributo_private = 0;        
    }
}