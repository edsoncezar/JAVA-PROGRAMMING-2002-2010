class FilhaDaDeCima extends ExemploFinal {
    void faz(){
    }
}
