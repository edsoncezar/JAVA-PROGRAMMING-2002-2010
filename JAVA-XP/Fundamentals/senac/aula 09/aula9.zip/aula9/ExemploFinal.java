class ExemploFinal  {

    final void faz(){
        System.out.println("Fiz");
    }
}
