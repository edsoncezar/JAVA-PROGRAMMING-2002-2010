/**
 *  Esta classe foi escrita para testar a classe Ponto
 */
class TestaPonto {

    void fazTeste(){
        // Cria  uma inst�ncia de Ponto
        Ponto p1 = new Ponto();
        p1.x = 1;
        p1.y = 1;
        // Cria outra inst�ncia
        Ponto p2 = new Ponto();
        p2.setaValor(2, 2);        
        p1.setaPr�ximo(p2);
        
    }
}