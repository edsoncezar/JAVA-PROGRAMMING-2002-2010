class Pessoa {
    Pessoa pai;
    Pessoa m�e;
    String nome;
    
    /**
     *  Construtor para exemplo de coment�rio
     */    
    Pessoa(Pessoa pai, Pessoa m�e){
        this.pai = pai;
        this.m�e = m�e;
    }
    Pessoa(String pnome, Pessoa ppai, Pessoa pm�e){
        this(ppai, pm�e);
        nome = pnome;
    }
    Pessoa(){
    }
}