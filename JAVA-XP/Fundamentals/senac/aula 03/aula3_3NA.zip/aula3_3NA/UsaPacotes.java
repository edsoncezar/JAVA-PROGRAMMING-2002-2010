import java.util.Stack;
import java.util.Vector;
// A linha abaixo importa todas as classes do pacote
// import java.util.*;
            
class UsaPacotes {
    void fazTeste(){
        Stack pilha = new Stack();
        Vector vetor = new Vector();        
    }    
}