class Pessoa {
    Pessoa pai;
    Pessoa m�e;
    String nome;
}