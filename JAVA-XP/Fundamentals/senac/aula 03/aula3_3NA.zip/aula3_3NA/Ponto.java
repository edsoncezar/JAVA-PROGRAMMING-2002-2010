class Ponto {
    /**
     *  Class Ponto com construtores
     */
    int x;
    int y;    
    Ponto(int vx, int vy){
        x = vx;
        y = vy;
    }
    Ponto(){
    }
}