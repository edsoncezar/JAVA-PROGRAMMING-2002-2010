class TestaPessoa {
    void fazTeste(){
        Pessoa ivo = new Pessoa();
        Pessoa bia = new Pessoa();
        Pessoal rui = new Pessoa();
        
        ivo.nome="Ivo";
        bia.nome="Bia";
        rui.nome="Rui";
                
        ivo.pai = rui;
        ivo.m�e = bia;
    }
}