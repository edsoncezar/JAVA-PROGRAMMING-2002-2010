class Produto {
    int serial;
    static int contador;
    String tipo; // N�o fa�am "String tipo" em classes "de verdade"
    
    Produto(String tipo){
        serial = contador ++;
    }
    
    static void dizContador(){
        System.out.println(contador);
    }
    
}