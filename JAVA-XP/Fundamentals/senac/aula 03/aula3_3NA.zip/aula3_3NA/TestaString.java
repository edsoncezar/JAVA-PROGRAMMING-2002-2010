/**
 *  Mostra algumas caracter�sticas das Strings em Java
 */ 
class TestaString {
    void fazTeste(){
        String linha = "Tinha uma pedra no meio do caminho";
        
        //Converte para array de char
        char[] array = linha.toCharArray();
        imprime(array);
        
        // Vers�o em uppercase
        String linhaUppercase = linha.toUpperCase();
        imprime(linhaUppercase);
        
        // Separa ao redor da ocorr�ncia de espa�os
        String[] peda�os = linha.split("\\ ");
        imprime(peda�os);
        
        
        // Substitui "pedra" por "nota de 50"
        String substitu�da = linha.replaceAll("pedra", "nota de 50");
        imprime(substitu�da);
        
        
    }
    
    /*
     * O m�todo "imprime" est� bastante sobrecarregado abaixo
     */    
    void imprime(char[] entrada){
        for (int i=0; i < entrada.length; i++){
            System.out.print(entrada[i] + " ");
        }
        System.out.println();
    }
    
    void imprime(String s){
        System.out.println(s);
    }
    
    void imprime(String[] s){
        for (int i=0; i < s.length; i++){
            System.out.print("("+ s[i] +")");
        }
        System.out.println();
    }
    
    
}