// Filename TheAnswer.java.
// Initial Java object written for the JFL 
// book chapter 1 - see text.
//
// Fintan Culwin, V0.1, August 1997.

public class TheAnswer { 

   public String theAnswerIs(){ 
      return "forty two";   
   } // End theAnswerIs.

} // End TheAnswer.
