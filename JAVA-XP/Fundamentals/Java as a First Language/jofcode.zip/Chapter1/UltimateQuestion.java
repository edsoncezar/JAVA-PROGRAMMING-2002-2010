// Filename UltimateQuestion.java.
// Initial Java program written for 
// the JFL book chapter 1 - see text.
//
// Fintan Culwin, V0.1, August 1997.

public class UltimateQuestion { 

   public static void main( String args[] ){ 
   
   String secondLine =  "life, the Universe and everything?";
   
      System.out.println();
      System.out.println( "What is the answer to," );
      System.out.println( secondLine);
   } // End main.

} // End UltimateQuestion.

