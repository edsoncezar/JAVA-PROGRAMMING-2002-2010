// Filename ClassDemo.java.
// Second trivial Java object written for 
// the JFL book chapter 2 - see text.
//
// Fintan Culwin, V0.1, January 1997.

public class ClassDemo { 


private int              instanceAttribute = 0;
private static int       classAttribute    = 0;
private static final int classConstant     = 42;


   // Constructuor. 
   ClassDemo( int initialValue) { 
      instanceAttribute = initialValue;
   } // End ClassDemo constructor.
   
   // Default constructor. 
   ClassDemo() { 
      // Do nothing!
   } // End default ClassDemo constructor.
      

   public int instanceAttributeIs(){ 
      instanceAttribute++;
      return instanceAttribute;   
   } // End theAnswerIs.


   static public int classAttributeIs() { 
     classAttribute++;
     return classAttribute;   
   } //End classAttributeIs
   
   static public int classConstantIs() { 
     // This is not possible!
     // classConstant++;
     return classConstant;   
   } //End classConstantIs.   

} // End UltimateAnswer.
