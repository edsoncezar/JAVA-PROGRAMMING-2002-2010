// Filename ClassDemoClient.java.
// Second trivial Java object written for 
// the JFL book chapter 2 - see text.
//
// Fintan Culwin, V0.1, January 1997.

import ClassDemo;

public class ClassDemoClient { 

   public static void main( String args[] ) { 
   
   ClassDemo firstInstance  = new ClassDemo( 14);
   ClassDemo secondInstance = new ClassDemo( );   
   
   
      System.out.println( "\n\t\tThis is the Class Demo Client\n");
      
      System.out.print( "Illustrating the instanceAttributeIs() ");
      System.out.println( "action of the firstInstance object.");
      System.out.print( "The first value should be 15 ... ");    
      System.out.print(  firstInstance.instanceAttributeIs());             
      System.out.println( ".");
      System.out.print( "The second value should be 16 ... ");   
      System.out.print(  firstInstance.instanceAttributeIs());             
      System.out.println( ".");      

      System.out.print( "\n\nIllustrating the instanceAttributeIs() ");
      System.out.println( "action of the secondInstance object.");
      System.out.print( "The first value should be 1 ... ");    
      System.out.print(  secondInstance.instanceAttributeIs());             
      System.out.println( ".");
      System.out.print( "The second value should be 2 ... ");   
      System.out.print(  secondInstance.instanceAttributeIs());             
      System.out.println( ".");      
         

      System.out.print( "\n\nIllustrating the classAttributeIs() ");
      System.out.println( "when asked for by the firstInstance object.");
      System.out.print( "The value should be 1 ... ");    
      System.out.print(  firstInstance.classAttributeIs());             
      System.out.println( ".");
      System.out.print( "\n\nIllustrating the classAttributeIs() ");
      System.out.println( "when asked for by the secondInstance object.");
      System.out.print( "The value should be 2 ... ");    
      System.out.print(  secondInstance.classAttributeIs());             
      System.out.println( ".");
      System.out.print( "\n\nIllustrating the classAttributeIs() ");
      System.out.println( "when asked for by the ClassDemo object.");
      System.out.print( "The value should be 3 ... ");    
      System.out.print(  ClassDemo.classAttributeIs());             
      System.out.println( ".");       

      System.out.print( "\n\nIllustrating the classConstantIs() ");
      System.out.println( "when asked for by the ClassDemo object.");
      System.out.print( "The value should be 42 ... ");    
      System.out.print(  firstInstance.classConstantIs());             
      System.out.println( ".");
   } // End main.


} // End ClassDemoClient;
