//

import java.util.Vector;
import Counters.WarningCounter;

public class WarningDemonstration14 { 


public static void main( String argv[]) { 


   Vector aVector = new Vector();
   
   WarningCounter aCounter       = new WarningCounter();
   WarningCounter theSameCounter = aCounter;
   WarningCounter recoveredCounter;
   aCounter.count();
   

   
   System.out.println( "aCounter � " + 
                        aCounter.hashCode()  + 
                        " has counted " + 
                        aCounter.numberCountedIs());
                        
   System.out.println( "theSameCounter � " + 
                        theSameCounter.hashCode() + 
                        " has counted " + 
                        theSameCounter.numberCountedIs());
                        
   aVector.addElement( aCounter);
   theSameCounter.count();
   recoveredCounter = (WarningCounter) aVector.firstElement();
   System.out.println( "recoveredCounter � " + 
                        recoveredCounter.hashCode() + 
                        " has counted " + 
                        recoveredCounter.numberCountedIs());                 

   } // End main

} // End WarningDemonstration14
