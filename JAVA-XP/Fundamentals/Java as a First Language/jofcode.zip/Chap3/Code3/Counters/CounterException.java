 // Filename Counters/StoppingCounter.java.
 // Providing a non-abstract counter class with 
 // stopping behaviour.
 //
 // Written for JFL book Chapter 3 see text.
 // Fintan Culwin, v0.1, January 1997
 
 package Counters;
 
 class CounterException extends RuntimeException { 
 
//    public CounterException(){
//      // Do nothing.
//    } // End default constructor
    
    public CounterException( String reason) { 
       super( reason);
    } // End principal constructor
    
 
 } // End CounterException
 
