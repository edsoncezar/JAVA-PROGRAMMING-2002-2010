 // Filename Counters/StoppingCounter.java.
 // Providing a non-abstract counter class with 
 // stopping behaviour.
 //
 // Written for JFL book Chapter 3 see text.
 // Fintan Culwin, v0.1, January 1997
 
 package Counters;
 
 public class StoppingCounter extends LimitedCounter { 


    public StoppingCounter() {  
        super();
    }  // End default Constructor.
    
    
    public StoppingCounter( int minToCount, int maxToCount) {  
        super( minToCount, maxToCount);
    }  // End principal Constructor.

 
    public void count() { 
       if ( ! this.isAtMaximum()) { 
         super.count();
       }   
    } // End count.
    
    
    public void unCount(){ 
       if ( ! this.isAtMinimum()) { 
         super.unCount();
       }   
    } // End unCount.

 } // End RollOverCounter
 
