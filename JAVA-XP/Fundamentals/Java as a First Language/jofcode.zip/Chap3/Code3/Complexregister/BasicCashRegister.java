// Filename Counters/BasicCashRegister.java.
// Providing an initial CashRegister model dealing
// in integer units of currency.
//
// Written for JFL book Chapter 5 see text.
// Fintan Culwin, v0.1, January 1997
 
package Counters;
 

// abstract class BasicCashRegister extends WarningCounter { 
 
public class BasicCashRegister extends WarningCounter { 

// Largest positive int value, 2147483647 in denary.
private static final int MAXINTEGER = 0x7FFFFFFF;

 private long theFloat;
 private long theTakings; 

    public BasicCashRegister( long initialFloat ) {  
        super( 0, MAXINTEGER);
        theFloat = initialFloat;
    }  // End default Constructor.
    
    
    public void deposit( long amount) { 
        this.count();
        theTakings += amount;
    } // End deposit. 
    
    
    public int numberOfDepositsIs() { 
       return this.numberCountedIs();
    } // End numberOfDepositsIs. 
    
    
    protected long amountTakenIs () { 
        return theTakings;
    } // End takingsIs. 
    
    
    protected long totalAmountInRegisterIs() { 
        return this.amountTakenIs() + theFloat;
    } // End totalInRegisterIs. 
    
    public String toString() { 
       return "Initial float      : " + theFloat            + "\n" +
              "Number of deposits : " + numberOfDepositsIs() + "\n" +
              "Total takings      : " + amountTakenIs()          + "\n" +
              "Total in register  : " + totalAmountInRegisterIs();
    
    } // End toString. 
    

 } // End WarningCounter
 
 

