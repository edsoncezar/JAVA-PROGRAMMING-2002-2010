// Filename Counters/CashRegister.java.
// Providing an  CashRegister model dealing
// in floating point units of currency.
//
// Written for JFL book Chapter 5 see text.
// Fintan Culwin, v0.1, January 1997
 
package Counters;

public class CashRegister extends BasicCashRegister {

public static final int SYMBOLBEFORE = 1;
public static final int SYMBOLAFTER  = 1;

private int     numberOfDecimalPlaces;
private int     theCurrencyPosition; 
private String  theCurrencySymbol;

   public CashRegister( double  initialCash,
                        int    demimalPlaces,
                        String currencySymbol,
                        int    currencyPosition) { 
     
     super( ((long) initialCash));                             
     numberOfDecimalPlaces =  demimalPlaces;
     theCurrencySymbol     =  currencySymbol;
     theCurrencyPosition   =  currencyPosition;                
  } // End constructor                             


  private long doubleToLong( double doubleToConvert){ 

  String theDouble = Double.toString( doubleToConvert);
System.out.println( "doubleToLong got " + theDouble);
  
return 0;
//  double   multiplier  =  Math.pow( 10, numberOfDecimalPlaces);
//       return  (long) ( doubleToConvert * multiplier);
  } // End doubleToInt
  
  
  private double longToFloat( long longToConvert) { 
  
     return 0;
  } // End intToFloat
  

  private String doubleToString( double doubleToFormat){ 
  
     return "";
  } // End doubleToString

  public void deposit( double amount) { 
     super.deposit( doubleToLong( amount ));
  } // End deposit.
  
  
  public double takenIs () { 
     return longToFloat( this.amountTakenIs());
  } // End takingsIs. 
    
    
  public double totalInRegisterIs() { 
     return longToFloat( this.totalAmountInRegisterIs()) ;
  } // End totalInRegisterIs. 

  public String toString () { 
     return super.toString();
  
  } // End toString.


} // End BasicCashRegister 
