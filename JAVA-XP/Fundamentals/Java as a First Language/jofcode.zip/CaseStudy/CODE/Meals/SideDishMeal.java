// Filename : Meals/SideDishMeal.java
// Author   : Ian Marshall (MARSHAIP@SBU.AC.UK)
//            2nd Year BSc(Hons) Computing Studies(Software Engineering) Student
//            South Bank University, London
// Date     : August 1997
// Version  : v1.0
// Comment  : Second extension of the Meals hierarchy.
//            Adds side dish functionality.

package Meals;

import Menus.BasicMenu;

public class SideDishMeal extends PricedMeal { 

   private final static int UNCHOSEN     = 0;
   private final static int FRIES        = 1;
   private final static int BAKED_POTATO = 2;
   private final static int NONE         = 3;

   private int sideDishChosen = UNCHOSEN;

   String sideDishOptions[] =  { "Fries", "Baked potato", "None"};

   private BasicMenu sideDishMenu = new BasicMenu( 
      "SIDE DISH OPTIONS",
      sideDishOptions,
      "PLEASE SELECT A SIDE DISH ==>"); 

   public SideDishMeal() { 
      super();
   } // End SideDishMeal.

   public void orderMeal() { 
      super.orderMeal();

      System.out.println();
      sideDishChosen = sideDishMenu.offerMenuAsInt();
   } // End orderMeal.

   public int sideDishIs() { 
      return sideDishChosen;
   } // End sideDishIs.

   public String toString() {  
      StringBuffer buffer = new StringBuffer( super.toString());   
      
      buffer.append( "\nSide dish ...... ");

      switch (sideDishChosen) { 

      case UNCHOSEN:
         buffer.append( "unknown ");
         break;

      case FRIES:
         buffer.append( "fries ");
         break;

      case BAKED_POTATO:
         buffer.append( "baked potato ");
         break;    

      case NONE:
         buffer.append( "none ");
         break;
      } // End switch.        
      return buffer.toString();
   } // End toString.

} // End SideDishMeal.


