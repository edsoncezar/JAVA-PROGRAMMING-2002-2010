// Filename : Meals/BeveragedMeal.java
// Author   : Ian Marshall (MARSHAIP@SBU.AC.UK)
//            2nd Year BSc(Hons) Computing Studies(Software Engineering) Student
//            South Bank University, London
// Date     : August 1997
// Version  : v1.0
// Comment  : Third extension of the Meals hierarchy.
//            Adds beverage functionality.

package Meals;

import Menus.BasicMenu;

public class BeveragedMeal extends SideDishMeal { 

   private final static int UNCHOSEN = 0;
   private final static int COKE     = 1;
   private final static int LEMONADE = 2;
   private final static int ORANGE   = 3;
   private final static int NONE     = 4;

   private int beverageChosen = UNCHOSEN;

   String beverageOptions[] =  { "Coke", "Lemonade", "Orange", "None"};

   private BasicMenu beverageMenu = new BasicMenu( 
      "DRINK OPTIONS",
      beverageOptions,
      "PLEASE SELECT A DRINK ==>"); 

   public BeveragedMeal() { 
      super();
   } // End BeveragedMeal.

   public void orderMeal() { 
      super.orderMeal();

      System.out.println();
      beverageChosen = beverageMenu.offerMenuAsInt();
   } // End orderMeal.

   public int beverageIs() { 
      return beverageChosen;
   } // End beverageIs.

   public String toString() {  
      StringBuffer buffer = new StringBuffer( super.toString());    
      
      buffer.append( "\nBeverage ....... ");

      switch (beverageChosen) { 

      case UNCHOSEN:
         buffer.append( "unknown ");
         break;

      case COKE:
         buffer.append( "coke ");
         break;

      case LEMONADE:
         buffer.append( "lemonade ");
         break;    

      case ORANGE:
         buffer.append( "orange ");
         break;    

      case NONE:
         buffer.append( "none ");
         break;
      } // End switch.      
      return buffer.toString();
   } // End toString.

} // End BeveragedMeal.


