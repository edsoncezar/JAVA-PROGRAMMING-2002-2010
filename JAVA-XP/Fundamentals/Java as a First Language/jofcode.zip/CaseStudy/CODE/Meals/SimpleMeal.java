// Filename : Meals/SimpleMeal.java
// Author   : Ian Marshall (MARSHAIP@SBU.AC.UK)
//            2nd Year BSc(Hons) Computing Studies(Software Engineering) Student
//            South Bank University, London
// Date     : August 1997
// Version  : v1.0
// Comment  : Root type of the Meals hierarchy.
//            Introduces a basic meal.

package Meals;

import Menus.BasicMenu;

public class SimpleMeal extends Object { 

   private final static int UNCHOSEN        = 0;
   protected final static int MEAT_MEAL       = 1;
   protected final static int FISH_MEAL       = 2;
   protected final static int VEGETARIAN_MEAL = 3;

   private int mealChosen = UNCHOSEN;

   String mealOptions[] =  { "Meat", "Fish", "Vegetarian"};

   private BasicMenu mealMenu = new BasicMenu( 
      "MAIN MEAL OPTIONS",
      mealOptions,
      "PLEASE SELECT A MEAL ==>"); 

   public SimpleMeal() { 
      super();
   } // End SimpleMeal.

   public void orderMeal() { 
      System.out.println();
      mealChosen = mealMenu.offerMenuAsInt();
   } // End orderMeal.

   public int mealIs() { 
      return mealChosen;
   } // End mealIs.

   public String toString() {    
      StringBuffer buffer = new StringBuffer( "");
      buffer.append( "\nMeal type ...... ");

      switch (mealChosen) { 

      case UNCHOSEN:
         buffer.append( "unknown ");
         break;

      case MEAT_MEAL:
         buffer.append( "meat ");
         break;

      case FISH_MEAL:
         buffer.append( "fish ");
         break;    

      case VEGETARIAN_MEAL:
         buffer.append( "vegetarian ");
         break;
      } // End switch.
      return buffer.toString();      
   } // End toString.

} // End SimpleMeal.


