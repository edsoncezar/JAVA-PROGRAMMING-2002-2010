// Filename : Meals/PricedMeal.java
// Author   : Ian Marshall (MARSHAIP@SBU.AC.UK)
//            2nd Year BSc(Hons) Computing Studies(Software Engineering) Student
//            South Bank University, London
// Date     : August 1997
// Version  : v1.0
// Comment  : First extension of the Meals hierarchy.
//            Adds meal price functionality.

package Meals;

import  OutputFormatter;

public class PricedMeal extends SimpleMeal { 

   private final static double PRICE_OF_MEAT_MEAL       = 1.50;
   private final static double PRICE_OF_FISH_MEAL       = 1.60;
   private final static double PRICE_OF_VEGETARIAN_MEAL = 1.40;
   
   private double thePriceOfTheMeal                     = 0.00;

//   private final static int MEAT_MEAL       = 1;
//   private final static int FISH_MEAL       = 2;
//   private final static int VEGETARIAN_MEAL = 3;

   public PricedMeal() { 
      super();
   } // End PricedMeal.

   public void orderMeal() { 
      super.orderMeal();

      switch ( this.mealIs()) { 

      case MEAT_MEAL:
         thePriceOfTheMeal = PRICE_OF_MEAT_MEAL;
         break;

      case FISH_MEAL:
         thePriceOfTheMeal = PRICE_OF_FISH_MEAL;
         break;    

      case VEGETARIAN_MEAL:
         thePriceOfTheMeal = PRICE_OF_VEGETARIAN_MEAL;
         break;

      } // End switch.     
   } // End orderMeal.

   public double priceIs() { 
      return ( thePriceOfTheMeal);
   } // End priceIs.

   public String toString() {   
      StringBuffer buffer = new StringBuffer( super.toString()); 
      
      buffer.append( "\nPrice of meal .. " + 
                      OutputFormatter.formatFloat( (float) priceIs(),
                                      2, 2, false));
        
      return buffer.toString();
   } // End toString.

} // End PricedMeal.


