// Filename : ElephantBurgerBar.java
// Author   : Ian Marshall (MARSHAIP@SBU.AC.UK)
//            2nd Year BSc(Hons) Computing Studies(Software Engineering) Student
//            South Bank University, London
// Date     : August 1997
// Version  : v1.0
// Comment  : THE "ELEPHANT BURGER BAR" DEMONSTRATION CLIENT.
//            This client addresses and implements the program
//            specification produced by Fintan Culwin. 
//            The client makes full use of the Meal class hierarchy. 

import Menus.BasicMenu;
import Meals.TimeStampedMeal;
import Generics.Queue;
import Counters.MoneyRegister;
import OutputFormatter;

class ElephantBurgerBar {

static TimeStampedMeal theMeal   = new TimeStampedMeal();
static Queue theMealQueue        = new Queue( theMeal.getClass());
static MoneyRegister theRegister = new MoneyRegister( 0.0);

private final static int UNCHOSEN       = 0;
private final static int ORDER_MEAL     = 1;
private final static int SERVE_MEAL     = 2;
private final static int SHOW_QUEUE     = 3;
private final static int SHOW_REGISTER  = 4;
private final static int EXIT           = 5;

private static boolean exitChosen = false;
private static int mainMenuChoice = UNCHOSEN;   

static String mainMenuOptions[] =  { "Order a meal.",
                                     "Serve a meal.", 
                                     "Show meal queue.", 
                                     "Show cash register.",
                                     "EXIT."};

static BasicMenu mainMenu = new BasicMenu( 
   "THE ELEPHANT BURGER BAR",
   mainMenuOptions,
   "PLEASE SELECT ==>"); 
  
   public static void main( String argv[]) { 

      while ( ! exitChosen) {  
      
         System.out.println();
         System.out.println( "===========================================");

         displayNoOfMealsInQueue();

         mainMenuChoice = mainMenu.offerMenuAsInt();
      
         switch ( mainMenuChoice) {

            case ORDER_MEAL:
               orderTheMeal();
               break;          
         
            case SERVE_MEAL:
               serveTheMeal(); 
               break;   
         
            case SHOW_QUEUE:
               showTheQueue();
               break;
         
            case SHOW_REGISTER:
               showTheRegister();
               break;         

            case EXIT:
               if (theMealQueue.isEmpty()) {
                  // Legal.  
                  exitChosen = true;
            
                  System.out.println( "Exit command accepted.");
                  System.out.println( "Goodbye.");
                  System.out.println();
               } else {
                  // Error.
                  System.out.println( "===========================================");
                  System.out.println( "EXIT COMMAND IGNORED");
                  System.out.print( "REASON > unserved meals in queue");
               } // End if.
               break;          
                     
         } // End switch.           

      } // End while.

   } // End main.


   public static void displayNoOfMealsInQueue() {
      System.out.println();
      System.out.println( "Meals queued : " + theMealQueue.size());      
      System.out.println();
   } // End displayNoOfMealsInQueue.

   
   public static void orderTheMeal() {  
   TimeStampedMeal theMeal = new TimeStampedMeal();  
               
      theMeal.orderMeal();
      theMealQueue.add( theMeal);      
      theRegister.deposit( theMeal.priceIs());      

      System.out.println( "===========================================");      
      System.out.print( "The price of the meal is " + 
         OutputFormatter.formatFloat( (float)theMeal.priceIs(), 1, 2, false));
   } // End orderTheMeal.
   
   
   public static void serveTheMeal() {
   TimeStampedMeal theMeal;       

      if ( ! theMealQueue.isEmpty()) {  
         // Legal.         
         displayNoOfMealsInQueue();   
      
         System.out.println( "===========================================");
         System.out.println( "SERVING MEAL");
         System.out.print  ( "~~~~~~~~~~~~");
   
         theMeal = (TimeStampedMeal) theMealQueue.retrieve();
         theMeal.serveMeal();
                
         System.out.print( theMeal);           
      } else {
         // Error.   
         System.out.println( "===========================================");
         System.out.println( "SERVE MEAL COMMAND IGNORED");
         System.out.print  ( "REASON > meal queue is empty");
      } // End if.            
   } // End serveTheMeal.   


   public static void showTheQueue() {     
      if (! theMealQueue.isEmpty()) {
         // Legal.           

         System.out.println( "===========================================");
         System.out.println( "SHOWING MEAL QUEUE");
         System.out.print  ( "~~~~~~~~~~~~~~~~~~");

         displayNoOfMealsInQueue();                  

         System.out.println( theMealQueue);         
      } else {
         // Error.
         
         System.out.println( "===========================================");
         System.out.println( "SHOW MEAL QUEUE COMMAND IGNORED");
         System.out.print  ( "REASON > meal queue is empty");
      } // End if.
   } // End showTheQueue.


   public static void showTheRegister() {
      System.out.println();
      System.out.println( "===========================================");
      System.out.println( "CASH REGISTER STATUS");
      System.out.println( "~~~~~~~~~~~~~~~~~~~~");
      
      System.out.print  ( "Total transactions ....... ");
      System.out.println( theRegister.numberOfDepositsIs());
      
      System.out.print( "Total cash in register ... " + 
         OutputFormatter.formatFloat( (float)theRegister.takingsIs(), 1, 2, false));
   } // End showTheRegister.
       
} // End ElephantBurgerBar.
