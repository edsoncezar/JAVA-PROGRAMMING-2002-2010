// Filename NumberedPrintStreamDemonstration.java.
// Read a named text file and output to terminal, with line numbers. 
//
// Written for JFL Book Chapter 12.
// Fintan Culwin, V 0.1, Jan 1997. 


import java.io.*;
import NumberedPrintStream;

class NumberedPrintStreamDemonstration { 
 
    public static void main(String args[]) {
    
    DataInputStream      in;
    NumberedPrintStream  out;
    boolean              dataAvailable = false;
    
       try { 
          in  = new DataInputStream( 
                                 new FileInputStream( "test.txt"));
          out = new NumberedPrintStream( System.out);
                                                       
          
          while ( in.available() > 0 ) { 
             out.println( in.readLine());
             
          } // end while
          
          in.close(); 
       } catch ( java.io.IOException exception)  { 
          if ( exception instanceof FileNotFoundException) { 
             System.out.println( "file not found");
          } // End if.
       } // End try/ catch block.
    } // end main.
    
 } // End class NumberedPrintStreamDemonstration.
 
