 // Filename Counters/StoppingCounter.java.
 // Providing a non-abstract counter class with 
 // stopping behaviour.
 //
 // This version re-written for JFL book Chapter 12
 // adding read() and write() actions, see text.
 // Fintan Culwin, v0.1, January 1997
 
 package Counters;
 
 import Counters.CounterException;
 import java.io.*;
 
 public class WarningCounter extends LimitedCounter { 


    public WarningCounter() {  
        super();
    }  // End default Constructor.
    
    
    public WarningCounter( int minToCount, int maxToCount) {  
        super( minToCount, maxToCount);
    }  // End principal Constructor.

 
    public void count()  { 
       if ( this.isAtMaximum()) { 
           throw new CounterException( "Attempt to count beyond limit.");
       } else { 
         super.count();
       } // End if.  
    } // End count.
    
    
    public void unCount()  { 
       if ( this.isAtMinimum()) { 
         throw new CounterException( "Attempt to count below limit.");
       } else { 
         super.unCount();
       }   
    } // End unCount.

   public String toString(){
      return "Now in room : "    + this.numberCountedIs();
   } // End toString.

   public void write( DataOutputStream writeTo) throws IOException{ 
     writeTo.writeInt( this.numberCountedIs());
   } // End write.
   
   public void read( DataInputStream readFrom) throws IOException{
     this.setCountTo( readFrom.readInt()); 
   } // End read.

 } // End WarningCounter
 
 

