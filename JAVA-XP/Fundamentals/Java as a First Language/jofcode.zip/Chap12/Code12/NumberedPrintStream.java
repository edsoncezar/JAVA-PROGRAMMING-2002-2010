// Filename NumberedPrintStream.java.
// Extension of the system PrintStream class to 
// provide a class which outputs formatted numbers 
// before every line.
//
// Written for JFL Book Chapter 12.
// Fintan Culwin, V 0.1, Jan 1997. 

import java.io.*;
import OutputFormatter;

class NumberedPrintStream extends java.io.PrintStream { 

private long lineNumber    = 1;

    public NumberedPrintStream( OutputStream out) { 
      super( out);
    } // End constructor.   

    public void println( String anyString){                
       super.println( 
             OutputFormatter.formatLong( lineNumber, 4, true, 10)
             + "  " + anyString);
       lineNumber++;
    } // End println.    

} // end class NumberedOutput.
