
import JulianDates.JulianDate;

class JulianDateDemonstration { 

public static void main(String args[]) {


JulianDate anyDate = new JulianDate();

int        index;

System.out.println( "Julian Date Demo Harness ");


System.out.println( "\n31 dec 2000");
anyDate = new JulianDate( 2000, 12, 31);
System.out.println( anyDate);


System.out.println( "\n1 jan 2001");
anyDate = new JulianDate( 2001, 1, 1);
System.out.println( anyDate);

// System.exit( 0);

System.out.println( "\n 1 jan 1900");
anyDate = new JulianDate( 1900, 1, 1);
System.out.println( anyDate);

//System.out.println( "\n 1 dec 1900");
//anyDate = new JulianDateIO( 1900, 12, 1);
//System.out.println( anyDate);

System.out.println( "\n 31 dec 1900");
anyDate = new JulianDate( 1900, 12, 31);
System.out.println( anyDate);

System.out.println( "\n1 jan 1901");
anyDate = new JulianDate( 1901, 1, 1);
System.out.println( anyDate);

//System.out.println( "\n1 jan 1902");
//anyDate = new JulianDateIO( 1902, 1, 1);
//System.out.println( anyDate);

//System.out.println( "\n1 jan 1903");
//anyDate = new JulianDateIO( 1903, 1, 1);
//System.out.println( anyDate);

System.out.println( "\n1 jan 1904");
anyDate = new JulianDate( 1904, 1, 1);
System.out.println( anyDate);

System.out.println( "\n31 jan 1904");
anyDate = new JulianDate( 1904, 1, 31);
System.out.println( anyDate);

System.out.println( "\n1 feb 1904");
anyDate = new JulianDate( 1904, 2, 1);
System.out.println( anyDate);

System.out.println( "\n28 march 1904");
anyDate = new JulianDate( 1904, 3, 28);
System.out.println( anyDate);

System.out.println( "\n29 march 1904");
anyDate = new JulianDate( 1904, 3, 29);
System.out.println( anyDate);

System.out.println( "\n1 april 1904");
anyDate = new JulianDate( 1904, 4, 1);
System.out.println( anyDate);

anyDate = new JulianDate();
System.out.println( "\n today ...");
anyDate.today();
System.out.println( anyDate);

System.out.println( "\n1 feb 2000");
anyDate = new JulianDate( 2000, 2, 1);
System.out.println( anyDate);

System.out.println( "\n28 feb 2000");
anyDate = new JulianDate( 2000, 2, 28);
System.out.println( anyDate);

System.out.println( "\n29 feb 2000");
anyDate = new JulianDate( 2000, 2, 29);
System.out.println( anyDate);

System.out.println( "\n1 mar 2000");
anyDate = new JulianDate( 2000, 3, 1);
System.out.println( anyDate);

System.out.println( "\n1 jan 2001");
anyDate = new JulianDate( 2001, 1, 1);
System.out.println( anyDate);

System.out.println( "\n1 jan 2001");
anyDate = new JulianDate( 2001, 1, 1);
System.out.println( anyDate);

System.out.println( "\n31 dec 2001");
anyDate = new JulianDate( 2001, 12, 31);
System.out.println( anyDate);

System.out.println( "\n1 jan 2002");
anyDate = new JulianDate( 2002, 1, 1);
System.out.println( anyDate);


System.out.println( "\n1 june 2199");
anyDate = new JulianDate( 2199,6, 1);
System.out.println( anyDate);

System.out.println( "\n1 jly 2199");
anyDate = new JulianDate( 2199,7, 1);
System.out.println( anyDate);

System.out.println( "\n1 aug 2199");
anyDate = new JulianDate( 2199,8, 1);
System.out.println( anyDate);

System.out.println( "\n1 sep 2199");
anyDate = new JulianDate( 2199,9, 1);
System.out.println( anyDate);


System.out.println( "\n1 oct 2199");
anyDate = new JulianDate( 2199,10, 1);
System.out.println( anyDate);

System.out.println( "\n1 nov 2199");
anyDate = new JulianDate( 2199, 11, 1);
System.out.println( anyDate);

System.out.println( "\n1 dec 2199");
anyDate = new JulianDate( 2199, 12, 1);
System.out.println( anyDate);

System.out.println( "\n30 dec 2199");
anyDate = new JulianDate( 2199, 12, 30);
System.out.println( anyDate);


System.out.println( "\n31 dec 2199");
anyDate = new JulianDate( 2199, 12, 31);
System.out.println( anyDate);

}
} // End class JulianDateDemonstration.
