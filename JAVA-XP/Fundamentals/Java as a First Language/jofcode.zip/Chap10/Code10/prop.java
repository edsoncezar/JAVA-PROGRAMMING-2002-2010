 // Filename JuklianDateTestHarness.java.
 // Client test harness for the JulianDate hierarchy. 
 //
 // Written for JFL Book Chapter 10.
 // Fintan Culwin, V 0.1, Jan 1997. 
 
 

 
 class Prop { 
 
    public static void main(String args[]) {
 
    int fred =1;
    int jim;
     
       System.out.println( "\t Interactive Julian Date Test Harness \n");
           
       System.out.println( "\n Trial 1 - attempt to construct 31st Dec 2199.");
       try { 
           jim = fred / 0;
       } catch ( java.lang.Exception exception) { 
          System.out.println( exception);
          System.out.println( "\n\n");
          exception.printStackTrace();
       } // End try/ catch.



         
     } // End main.
} // End InteractiveJulianDateTestHarness.

