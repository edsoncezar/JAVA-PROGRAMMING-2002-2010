
import JulianDates.JulianDate;
import JulianDates.JulianDateException;

class JulianDateDemonstrationA { 

   public static void main(String args[]) {


   JulianDate disDate  = new JulianDate();
   JulianDate thatDate = new JulianDate();
   
      System.out.println( "\t Julian Date Arithmetic Demonstration n");
      
      disDate.today();
      
      System.out.print( "\n today ... ");
      System.out.println( disDate);

      System.out.print( "\n tomorrow ... ");
      disDate.tomorrow();
      System.out.println( disDate);

      System.out.print( "\n yesterday ... ");
      disDate.yesterday();
      System.out.println( disDate);
      
      System.out.print( "\n next week ... ");
      disDate.daysHence( 7);
      System.out.println( disDate);
            
      System.out.print( "\n last week ... ");
      disDate.daysPast( 14);
      System.out.println( disDate);  
      
      disDate.today();
      thatDate.today();
      System.out.print( "\n" + disDate  + " equal to " + 
                        thatDate + " is ");
      if ( disDate.equals( thatDate)) { 
         System.out.println( "true.");
      } else { 
         System.out.println( "false.");
      }                                
      
      thatDate.tomorrow();
      System.out.print( "\n" + disDate  + " earlier than " + 
                        thatDate + " is ");
      if ( disDate.isEarlierThan( thatDate)) { 
         System.out.println( "true.");
      } else { 
         System.out.println( "false.");
      }
      
                        
      System.out.print( "\n" + disDate  + " later than " + 
                        thatDate + " is ");
      if ( disDate.isLaterThan( thatDate)) { 
         System.out.println( "true.");
      } else { 
         System.out.println( "false.");
      } 
      
      
      disDate = new JulianDate( 1900, 1, 1);
      System.out.print( "\n" + disDate  + " 109572 days is " );
      disDate.daysHence( 109572);
      System.out.println( disDate + ".");
      
      System.out.println( "\nThe tomorrow of " + disDate +
                          " should raise an exception ... ");
      try {
         disDate.tomorrow();
         System.out.println( " ... no exception!");
      } catch ( JulianDateException exception ) {
         System.out.println( " ... exception raised!");
      }        
                              
   }
} // End class JulianDateDemonstration.
