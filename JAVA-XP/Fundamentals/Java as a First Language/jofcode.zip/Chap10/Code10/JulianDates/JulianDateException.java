 // Filename JulianDateException.java.
 // Providing specific exception for JulianDate hierachy.
 //
 // Written for JFL book Chapter 10 see text.
 // Fintan Culwin, v0.1, January 1997
 
package JulianDates;
 
 public class JulianDateException extends RuntimeException { 
 
 public static final int UNKNOWN_REASON          = 0; 
 public static final int NULL_DATE               = 1;
 public static final int DATE_CONSTRUCTION_ERROR = 2;
 public static final int ARITHMETIC_ERROR        = 3;
 public static final int DATE_INPUT_ERROR        = 4;
  
  
 private int theReason = UNKNOWN_REASON;
 
    public JulianDateException( int reason){
      super();
      theReason = reason;
    } // End default constructor


    public int obtainReason(){ 
       return theReason;
    } // End obtainReason.
    
    public String toString() {
    
    String toReturn;
    
       switch ( theReason) {
       case NULL_DATE: 
          toReturn = new String( "Julian date exception : Null date.");
          break;         
       case DATE_CONSTRUCTION_ERROR: 
          toReturn = new String( "Julian date exception : Invalid date construction.");
          break;
       case ARITHMETIC_ERROR: 
          toReturn = new String( "Julian date exception : Invalid date.");
          break;
       case DATE_INPUT_ERROR: 
          toReturn = new String( "Julian date exception : Invalid input.");
          break;       
       default: 
          toReturn = new String( "Julian date exception : Unknown reason.");
       } // End switch. 
       return toReturn;    
    } // End principal constructor
    
 
 } // End JulianDateException
 
