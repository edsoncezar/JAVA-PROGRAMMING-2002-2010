// Filename ArithmeticJulianDate.java.
// First extension of the JulianDate hierarchy 
// to provide (pseudo)-arithmetic operations.
//
// Written for JFL Book Chapter 10.
// Fintan Culwin, V 0.1, Jan 1997. 

package JulianDates;

import JulianDates.JulianDateException;

public class ArithmeticJulianDate extends BasicJulianDate {

 
   public ArithmeticJulianDate(){ 
      super();
   } // end JulianDate default constructor
   
   public ArithmeticJulianDate( int year, int month, int day) 
                                    throws JulianDateException {
       super( year, month, day);
   } // end JulianDate alternative default constructor

   
   final public void tomorrow() throws JulianDateException { 
      this.add( 1);
   } // End tomorrow. 

   final public void yesterday() throws JulianDateException { 
      this.add( -1);
   } // End yesterday. 

   final public void daysHence( int toElapse) throws JulianDateException { 
      this.add( toElapse);   
   } // End daysHence.
   
   final public void daysPast( int hasPassed) throws JulianDateException { 
      this.add( -hasPassed);   
   } // End daysPast.
   
   final public long daysBetween( ArithmeticJulianDate since) { 
      return this.dayNumberIs() - since.dayNumberIs();
   } // End equals.
   
   final public boolean equals( ArithmeticJulianDate toCompare) { 
      return this.dayNumberIs() == toCompare.dayNumberIs();
   } // End equals.
   
   final public boolean isLaterThan( ArithmeticJulianDate toCompare) { 
      return this.dayNumberIs() > toCompare.dayNumberIs();
   } // End isLaterThan.   

   final public boolean isEarlierThan( ArithmeticJulianDate toCompare) { 
      return this.dayNumberIs() < toCompare.dayNumberIs();
   } // End isEarierThan.
   
   private void add( int toAdd) { 
      if ( (this.dayNumberIs() + toAdd >  MAXIMIUM_JULIAN_DATE) ||
           (this.dayNumberIs() + toAdd <  MINIMIUM_JULIAN_DATE)   ) { 
        throw new JulianDateException( 
                        JulianDateException.ARITHMETIC_ERROR);          
      } // End if.
      this.dayNumber += toAdd; 
   } // end add. 

} // End AritmeticJulianDate.
