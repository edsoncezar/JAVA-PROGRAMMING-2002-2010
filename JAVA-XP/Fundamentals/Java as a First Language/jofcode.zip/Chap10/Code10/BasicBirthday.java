// Filename BasicBirthday.java.
// 
// 
//
// Written for JFL Book Chapter 12.
// Fintan Culwin, V 0.1, Jan 1997.


import BasicPerson;
import JulianDates.JulianDate;
import JulianDates.JulianDateException;

public class BasicBirthday extends BasicPerson { 

private JulianDate thierBirthDay;


   public BasicBirthday() {    
      super();   
   } // End BasicBirthday default constructor.


   public BasicBirthday( String personsName,
                         char   personsGender,
                         JulianDate personsDOB) {
      super( personsName, personsGender);
      thierBirthDay = new JulianDate( personsDOB.yearIs(),
                                      personsDOB.monthIs(),
                                      personsDOB.dayIs(),
                                      JulianDate.EUROPEAN);
   } // End BasicBirthday constructor.


   public void readBirthday() { 
   
   boolean dateOK = false;
   
      super.readPerson();
      
      while ( ! dateOK) { 
          try { 
             System.out.print( "Please enter the date of birth : ");
             System.out.flush();
             thierBirthDay.readDate();
             dateOK = true;             
          } catch ( JulianDateException exception) { 
             System.out.println( 
                        "Sorry there seems to be a problem!\n" +
                        "Could you please try again.");
          }    
       } // End while.          
       
      
   
   } 

} // End class BasicBirthday.
