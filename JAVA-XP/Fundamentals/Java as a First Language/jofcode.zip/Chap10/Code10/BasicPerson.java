// Filename BasicPerson.java.
// 
// 
//
// Written for JFL Book Chapter 12.
// Fintan Culwin, V 0.1, Jan 1997.

import java.io.*;


class BasicPerson {  

private String  name;

private char    gender;
private DataInputStream theKeyboard 
            = new DataInputStream( System.in);
            
private final char MALE   = 'M';
private final char FEMALE = 'F';            

    public BasicPerson() { 
       super();    
    } // End BasicBirthday default constructor.
    
    public BasicPerson( String thierName,
                        char   thierGender) { 
       super();
       name = new String( thierName);
       gender = thierGender;    
    } // End BasicBirthday default constructor.    


    public void readPerson(){ 
    
    boolean nameOK   = false;
    boolean genderOK = false;
    
    String  fromKeyboard;
    

       while ( ! nameOK) { 
          try { 
             System.out.print( "Please enter the name   :");
             System.out.flush();
             name = new String( theKeyboard.readLine());
             if ( name.length() == 0) { 
                throw new IOException();
             } // End if.
             nameOK = true;             
          } catch ( IOException exception) { 
             System.out.println( 
                        "Sorry there seems to be a problem!\n" +
                        "Could you please try again.");
          }    
       } // End while.          
       

       while ( ! genderOK) { 
          try { 
             System.out.print( "Please enter the gender :");
             System.out.flush();
             fromKeyboard = new String( theKeyboard.readLine());
             if ( fromKeyboard.length() == 0) { 
                throw new IOException();
             } else { 
                gender = Character.toUpperCase( 
                              fromKeyboard.charAt( 0));
                if ( ( gender != MALE) && ( gender != FEMALE)) { 
                   throw new IOException();
                } // End if.
             } // End if.
             genderOK = true;
          } catch ( IOException exception) { 
             System.out.println( 
                        "You must enter 'M' for male, " +
                        " or 'F' for female.\n"         +
                        "Could you please try again.");
          }    
       } // End while.    
    } // End readBirthday 
    
    
    public String toString(){ 
    
    String genderString;
    
       if ( this.gender == MALE) { 
          genderString = new String( "male");
       } else { 
          genderString = new String( "female");
       } // End if.       
       return name + " (" + genderString + ").";
    } // End toString.
    

} // End class Birthday.
