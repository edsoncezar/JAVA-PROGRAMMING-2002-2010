// Filename BasicBirthdayDemonstration.java.
// 
// 
//
// Written for JFL Book Chapter 12.
// Fintan Culwin, V 0.1, Jan 1997.


import BasicBirthday;
import JulianDates.JulianDate;


class BasicBirthdayDemonstration { 

    public static void main(String args[]) {
    
    BasicBirthday demoPerson = new BasicBirthday();   
    JulianDate    demoDate = new JulianDate(); 

      System.out.println( "\tBasic Birthday demonstration \n\n");
      
      demoDate.today();
      demoPerson = new BasicBirthday( "Charlie Chaplin", 'M', demoDate);
      System.out.println( 
             "Counstructed Charlie Chaplin (male), " + 
             "with today's date. outputting ..."); 
      System.out.println( demoPerson );    
      
      System.out.println( 
             "\nPlease enter details of another person ...");
      demoPerson.readPerson();     
      System.out.println( 
             "\nThank you, you input");
      System.out.println( demoPerson );                           

   } // End main.
} // End class BasicPersonDemonstration.

