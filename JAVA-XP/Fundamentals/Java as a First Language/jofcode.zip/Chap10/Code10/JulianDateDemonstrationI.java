
import JulianDates.JulianDate;
import JulianDates.JulianDateException;

class JulianDateDemonstrationI { 

   public static void main(String args[]) {


   JulianDate disDate  = new JulianDate( JulianDate.UK_LOCALE);
   JulianDate thatDate = new JulianDate( JulianDate.USA_LOCALE);

      System.out.println( "\t Julian Date I/O Demonstration ");
      
      disDate.today();
      thatDate.today();
      
      System.out.print( "\n default ... ");
      System.out.println( disDate.sparseString());

      System.out.print( "\n usa     ... ");
      System.out.println( thatDate.sparseString());
      
      System.out.print( "\n uk format input : ");
      disDate.readDate();
      System.out.println( "That was " +  disDate);
      
      System.out.print( "\n usa format input : ");
      thatDate.readDate();
      System.out.println( "That was " +  thatDate);      
      

   }
} // End class JulianDateDemonstration.
