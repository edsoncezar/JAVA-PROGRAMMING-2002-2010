// Filename RoomMonitorInterface.java.
// Provides an interactive interface for the RoomMonitor
// class. 
//
// Written for the Java book Chapter 16 - see text.
// Fintan Culwin, v 0.1, September 1996.

import java.awt.*;
import java.applet.*;
import java.awt.event.*;

import OutputFormatter;


public class RoomMonitorInterface extends Applet {
 
private Button enterButton;
private Button resetButton;
private Button leaveButton;
 
private Label  countDisplay = new Label();  
private Label  maxDisplay   = new Label();  
private Label  totalDisplay = new Label();  


   public RoomMonitorInterface( Applet applet) {

   Panel  displayPanel = new Panel();
   Panel  controlPanel = new Panel();
   Label  countLabel   = new Label( "Current ");
   Label  maxLabel     = new Label( "Max ");
   Label  totalLabel   = new Label( "Total ");
    
      applet.setLayout( new BorderLayout( 0, 0));
      displayPanel.setLayout( new GridLayout(3, 2, 0, 1));
 
      displayPanel.add( countLabel);
      displayPanel.add( countDisplay);
      displayPanel.add( maxLabel);
      displayPanel.add( maxDisplay);
      displayPanel.add( totalLabel);
      displayPanel.add( totalDisplay);
      applet.add( "Center", displayPanel);

      enterButton  = new Button( "+");
      enterButton.setActionCommand( "enter");
      enterButton.addActionListener( (ActionListener) applet);
      controlPanel.add( enterButton);
      
      resetButton  = new Button( "0");
      resetButton.setActionCommand( "reset");
      resetButton.addActionListener( (ActionListener) applet);      
      controlPanel.add( resetButton);
      
      leaveButton  = new Button( "-");
      leaveButton.setActionCommand( "leave");
      leaveButton.addActionListener( (ActionListener) applet);            
      controlPanel.add( leaveButton);
      applet.add( "South", controlPanel);       
   } // End init.


   public void updateDisplays( int numberInRoom,
                               int maxInRoom,
                               int totalInRoom) {

      countDisplay.setText( 
                   OutputFormatter.formatLong( numberInRoom,
                   4, true, OutputFormatter.DECIMAL));
      maxDisplay.setText( 
                   OutputFormatter.formatLong( maxInRoom,
                   4, true, OutputFormatter.DECIMAL));
      totalDisplay.setText( 
                   OutputFormatter.formatLong( totalInRoom,
                   4, true, OutputFormatter.DECIMAL));
    } // End updateDisplays.


    public void setResetState(){
       enterButton.setEnabled( true); 
       resetButton.setEnabled( false); 
       leaveButton.setEnabled( false); 
    } // End setResetState.

    public void setCountingState(){
       enterButton.setEnabled( true);
       resetButton.setEnabled( true); 
       leaveButton.setEnabled( true); 
    } // End setCountingState.

    public void setMinimalState(){
       enterButton.setEnabled( true); 
       resetButton.setEnabled( true); 
       leaveButton.setEnabled( false); 
    } // End setMinimalState.

    public void setMaximalState(){
       enterButton.setEnabled( false); 
       resetButton.setEnabled( true); 
       leaveButton.setEnabled( true); 
    } // End setMaximalState.

} // end class RoomMonitorInterface.





