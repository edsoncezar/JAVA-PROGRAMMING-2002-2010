// Filename RoomMonitorGUI.java.
// Provides an interactive interface for the RoomMonitor
// class. 
//
// Written for the Java book Chapter 16 - see text.
// Fintan Culwin, v 0.1, September 1996.


import java.awt.*;
import java.applet.*;
import java.awt.event.*;


import Counters.RoomMonitor;
import RoomMonitorInterface;


public class      RoomMonitorGUI 
       extends    Applet
       implements ActionListener { 

private RoomMonitor          theMonitor;
private RoomMonitorInterface theInterface;

private static final int INITIAL_STATE  = 0;
private static final int RESET_STATE    = 1;
private static final int COUNTING_STATE = 2;
private static final int MINIMAL_STATE  = 3;
private static final int MAXIMAL_STATE  = 4;
private static int       currentState   = INITIAL_STATE;
 
 
   public void init() {
      theMonitor   = new RoomMonitor();
      theInterface = new RoomMonitorInterface( this);
      theInterface.setResetState();
      currentState = RESET_STATE; 
      theInterface.updateDisplays( theMonitor.numberCurrentlyInRoomIs(),
                                   theMonitor.maxEverInRoomIs(),
                                   theMonitor.totalNumberEnteredIs());
   } // End init.


   public void actionPerformed( ActionEvent event) {   
   
   String buttonPressed = event.getActionCommand();
   
      if ( buttonPressed.equals( "enter")) {    
          if ( currentState == RESET_STATE) {
             theInterface.setCountingState();
             currentState = COUNTING_STATE;
          } else if ( this.isPreMaximal()) { 
             theInterface.setMaximalState();
             currentState = MAXIMAL_STATE;
          } else if ( currentState == MINIMAL_STATE) {
             theInterface.setCountingState();
             currentState = COUNTING_STATE;
          } // End if.
          theMonitor.enterRoom();
       
       } else  if ( buttonPressed.equals( "leave")) { 
          if ( currentState == MAXIMAL_STATE) {
             theInterface.setCountingState();
             currentState = COUNTING_STATE;
          } else if ( this.isPreMinimal()) { 
             theInterface.setMinimalState();
             currentState = MINIMAL_STATE;          
          } // End if.
          theMonitor.leaveRoom();      
                 
       } else { 
           theInterface.setResetState();
           currentState = RESET_STATE;                               
           theMonitor.reset();       
       } // End if.
       theInterface.updateDisplays( theMonitor.numberCurrentlyInRoomIs(),
                                    theMonitor.maxEverInRoomIs(),
                                    theMonitor.totalNumberEnteredIs());   
    } // End actionPerformed.


    private boolean isPreMinimal() { 
       return ( theMonitor.numberCurrentlyInRoomIs() - 
                theMonitor.minimumIs()) == 1;

    } // End isPreMinimal.

    private boolean isPreMaximal() { 
       return( theMonitor.maximumIs() - 
               theMonitor.numberCurrentlyInRoomIs()) == 1;
    } // End isPreMaximal.

    public static void main(String args[]) {

    Frame          frame        = new Frame("Room Monitor demo");
    RoomMonitorGUI theInterface = new RoomMonitorGUI();

       theInterface.init();
       frame.add("Center", theInterface);

       frame.show();
       frame.resize( frame.preferredSize());
    } // end fun main

} // end class RoomMonitorGUI.





