//

import Counters.RoomMonitor;

public class RoomMonitorDemonstration { 


public static void main( String argv[]) { 

   RoomMonitor  demoCounter = new RoomMonitor(); 

      System.out.println( "\n\t\t Room Monitor demonstration \n");
    
      System.out.println( "The counter has been created with a default range of ");

    
      System.out.println( "\nDemonstrating numberCountedIs()");
      System.out.print( "The values should be 0 0 0 ... ");
      System.out.print( demoCounter.numberCountedIs());
      System.out.print( demoCounter.maxEverInRoomIs());
      System.out.print( demoCounter.totalNumberEnteredIs());
      System.out.println( "." );
    
      System.out.println( "\nCounting two ocurrences with count()");
      demoCounter.enterRoom();
      demoCounter.enterRoom();
      demoCounter.exitRoom();
      demoCounter.enterRoom();
      demoCounter.enterRoom();
      demoCounter.exitRoom();      
      demoCounter.exitRoom();      
      System.out.print( "Its value should now be 124 ... ");
      System.out.print( demoCounter.numberCountedIs());
      System.out.print( demoCounter.maxEverInRoomIs());
      System.out.print( demoCounter.totalNumberEnteredIs());
      
      System.out.println( "." );    
    


    
   } // End main.

} // End RoomMonitorDemonstration.
