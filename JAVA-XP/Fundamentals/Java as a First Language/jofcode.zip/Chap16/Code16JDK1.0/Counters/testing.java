

import java.awt.*;
import java.applet.*;

import OutputFormatter;
import Counters.RoomMonitor;


 public class testing extends Applet {
 
 private RoomMonitor theMonitor = new RoomMonitor();
 private Button enterButton  = new Button( "+");
 
 private Label  countDisplay = new Label("hello mum"); 
 
    public void init() {
     //theMonitor  = new RoomMonitor();
     this.add( countDisplay);
     this.add( enterButton);
    }  
 
    
 
 } // End testing.
