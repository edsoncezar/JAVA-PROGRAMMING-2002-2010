// Filename RoomMonitorGUI.java.
// Provides an interactive interface for the RoomMonitor
// class. 
//
// Written for the Java book Chapter 16 - see text.
// Fintan Culwin, v 0.1, September 1996.


 import java.awt.*;
 import java.applet.*;

 import Counters.RoomMonitor;


 public class RoomMonitorGUI extends Applet {

 private RoomMonitor theCounter = new RoomMonitor();

 private Button incrementButton  = new Button( "+");
 private Button resetButton      = new Button( "0");
 private Button decrementButton  = new Button( "-");
 
 private Label  valueDisplay     = new Label();

   public void init() {

   Panel  valuePanel   = new Panel();
   Panel  controlPanel = new Panel();

      this.setLayout( new GridLayout(2, 1, 10, 10));

      valuePanel.add( valueDisplay);
      this.add( valuePanel);

      controlPanel.add( incrementButton);
      controlPanel.add( resetButton);
      controlPanel.add( decrementButton);
      this.add( controlPanel);

      this.update();
   } // End init.


   private void update(){

      valueDisplay.setText( 
        theCounter.numberCurrentlyInRoomIs.toString());

      if ( theCounter.isAtMinimum()) {        // Mimimum state
       decrementButton.disable();
        resetButton.disable();
        incrementButton.enable();
      } else if ( theCounter.isAtMaximum()) { // Maximum state
        decrementButton.enable();
        resetButton.enable();
        incrementButton.disable();
      } else {                                // Counting state   
        decrementButton.enable();
        resetButton.enable();
        incrementButton.enable();
      } // End if.
    } // End update.


    public boolean action( Event event, Object object) {

    boolean hasBeenHandled = false;

       if (event.target.equals( incrementButton)) {
          theCounter.count();
          hasBeenHandled = true;
       } else if ( event.target.equals( decrementButton)) {
          theCounter.unCount();
          hasBeenHandled = true;
       } else if ( event.target.equals( resetButton)) {
          theCounter.reset();
          hasBeenHandled = true;
       } // End if.
             
       if ( hasBeenHandled) {
          this.update();
       } // End if.
          
          return hasBeenHandled;
    } // End action.


   public static void main(String args[]) {

   Frame        frame      = new Frame("Click Counter demo");
   ClickCounterInterface theInterface    
                           = new ClickCounterInterface();

         theInterface.init();
         frame.add("Center", theInterface);

         frame.show();
         frame.resize( frame.preferredSize());
   } // end fun main

} // end class RoomMonitorGUI.





