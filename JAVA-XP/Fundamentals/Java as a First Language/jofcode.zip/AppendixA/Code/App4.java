// Scratch file for app 4

import java.lang.Math;


public class App4 {
 
        

   public static void main( String argv[]) {
 
   char characterVariable = 'A';
   int  integerVariable   = 0; 
   long longVariable      = 0;
   

      longVariable  =  characterVariable;
      integerVariable = characterVariable;
      characterVariable =   longVariable ;
      characterVariable   = integerVariable;
   
     }

} // End app3

