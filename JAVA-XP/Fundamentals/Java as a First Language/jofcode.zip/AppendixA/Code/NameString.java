// Filename NameString.java.
// Illustrating the handling of Strings by automatically
// formatting a NameString upon construction.
//
// Produced for JFL book Appendix A5.
// Fintan Culwin, v 0.1, Jan 1997.


public class NameString extends Object {

String theName;
 
     public NameString( String anyName) {   
        super();
        theName = new String( anyName);
        formatName();       
     } // End constructor.
     
     
     private void formatName() { 
     
     StringBuffer thisName        = new StringBuffer( theName.trim());
     boolean      shouldBeCapital = true;
     char         thisCharacter; 
     int          index;

        for ( index = 0; 
              index < thisName.length();
              index++) {

           thisCharacter = thisName.charAt( index);
           if ( shouldBeCapital ){ 
              thisName.setCharAt( index,
                         Character.toUpperCase( thisCharacter)); 
           } else { 
              thisName.setCharAt( index,
                         Character.toLowerCase( thisCharacter));            
           } // End if.       
        
           if ( Character.isLowerCase( thisCharacter) ||
                Character.isUpperCase( thisCharacter) ){ 
              shouldBeCapital = false; 
           } else { 
              shouldBeCapital = true;       
           } // End if.         
         } // End for.   
         theName = new String( thisName);
     } // end formatName.
     
     public String toString() { 
        return theName;
     } // End toString;
} // End NameString

