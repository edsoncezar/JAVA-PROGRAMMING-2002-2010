// Scratch file for app a investigations ...

import java.io.DataInputStream;

public class AppA {
 
private java.io.DataInputStream keyboard = 
                 new java.io.DataInputStream( System.in);  

   public static void main( String argv[]) {
   

   byte btest;
   int  itest;
   int  dis, that, other;
   int  integerVariable =0;
   boolean inputNotOK;
   java.io.DataInputStream keyboard = 
                 new java.io.DataInputStream( System.in);

      byte  byteVariable = 4;
      short shortVariable;
      int   intVariable;
      long  longVariable = 4; 
      
      float floatVariable = (float) 1.2;
      double doubleVariable = 1.2;



  String  intStr =  Integer.toString( 42, 16);

      String integerString = new String( new Integer( 42), 16);
        
        btest = 127;
        System.out.println( "btest is " + btest); 
        btest++;
        System.out.println( "btest is now " + btest);
        
        itest = 2147483647;
        System.out.println( "\nbtest is " + itest); 
        itest++;
        System.out.println( "btest is now " + itest);        
   
        dis = 8; that = 2; other = 0;
        other = dis | that; 
        System.out.println( "\n dis | that " + other);  
        
        dis = 8; that = 2; other = 0;
        other = dis & that; 
        System.out.println( "\n dis & that " + other);    
        
        dis = 8; that = 2; other = 0;
        other = dis ^ that; 
        System.out.println( "\n dis ^ that " + other);                
                    
        dis = 8; that = 2; other = 0;
        other = ~ dis; 
        System.out.println( "\n other = ~ dis " + other);                

        dis = 8; that = 2; other = 0;
        other = dis >> that; 
        System.out.println( "\n dis >> that " + other);         

        dis = 8; that = 2; other = 0;
        other = dis << that; 
        System.out.println( "\n dis << that " + other);      
        
        
        inputNotOK = true; 
        while ( inputNotOK ) { 
           System.out.print( "Please type in an integer ");
           System.out.flush();
           try {  
               integerVariable=  Integer.valueOf(
                                    keyboard.readLine().trim()
                                                 ).intValue(); 
              inputNotOK = false;
           } catch ( java.lang.Exception exception) {
              System.out.println( "Too bad - try again!");              
           } // End try/ catch;
        } // End while;
        System.out.println( "Thank you you input .. " + 
                            integerVariable + ".");
      
      



      shortVariable = byteVariable;
      intVariable   = shortVariable;
      longVariable  = intVariable;

       
      shortVariable  = 300;
      
           byteVariable = (byte) shortVariable;
           System.out.println( " 300 becomes ... " +  byteVariable);
      
      longVariable  = 9223372036854775807L;
       System.out.println( " 9223372036854775807 becomes ... " +  longVariable);
      longVariable  = 0x7FFFFFFFFFFFFFFFL;
       System.out.println( " 0x7FFFFFFFFFFFFFFFL becomes ... " +  longVariable);   
                                  
   } // End main. 


} // End appA

