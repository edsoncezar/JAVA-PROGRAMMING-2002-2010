// Scratch file for app 3

import java.lang.Math;


public class App3 {
 
        

   public static void main( String argv[]) {
 
   boolean dis;
   boolean that; 
   
      if ( dis ^ that ) { 
      
      } 
   

     }  // End main
} // End app3

