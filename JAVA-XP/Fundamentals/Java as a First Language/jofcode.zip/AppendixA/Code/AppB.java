// Scratch file for app a investigations ...

import java.io.DataInputStream;
import java.lang.Long;

public class AppB {
 
private java.io.DataInputStream keyboard = 
                 new java.io.DataInputStream( System.in);  

   public static void main( String argv[]) {
   

   long   longVariable, anotherLongVariable;
   double doubleVariable;
   float  floatVariable;
   
      doubleVariable = 345.678D;
      floatVariable  = 345.678F;
      longVariable   = (long) doubleVariable;
      
      System.out.println( " long of 1.0E20  is " + longVariable);
         
     }  // End main
} // End appA

