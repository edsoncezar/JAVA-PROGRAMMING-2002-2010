// Filename NameStringDemonstration.java.
// Providing a demonstration of the NameString class. 
//
// Produced for JFL book Appendix A5.
// Fintan Culwin, v0.1, Jan 97.

public class NameStringDemonstration extends Object { 

   public static void main( String argv[]) {
   
   String     testString     = new String( "  mr. connor cRUISE o\u0027brien ");
   NameString testNameString = new NameString( testString);
   
      System.out.println( "\t Name String Demonstration \n\n");
      System.out.println( "Simple string is " + testString);
      System.out.println( "Name string is " + testNameString);
   } // End main.
} // end NameStringDemonstration.
