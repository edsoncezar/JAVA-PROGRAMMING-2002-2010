// Filename SubtleFloatingPointError.java.
// Illustrates a subtle fault which can occur when 
// using floating point values.
//
// Written for JFL book Appendix B.
// Fintan Culwin, v0.1, January 1997.

public class SubtleFloatingPointError {
 
private static final int    ONE_HUDRED_THOUSAND   = 100000;
private static final double ONE                   = 1.0;
private static final double ONE_HUDRED_THOUSANDTH = ONE /
                                                ((double) ONE_HUDRED_THOUSAND);

   public static void main( String argv[]) {
   
   int    index;
   double theResult = 0.0;
   
         System.out.println( "\t Illustrating a subtle floating point bug.\n");
         System.out.println( "Adding one hundred thousandth to itself ");
         System.out.println( "one hundred thousand times and seeing if the ");
         System.out.println( " result is equal to one... \n\n");
         
         for ( index  = 0;
               index <= ONE_HUDRED_THOUSAND;
               index++ ){ 
            theResult += ONE_HUDRED_THOUSANDTH; 
         } // End for.      
         
         if ( theResult == ONE) { 
            System.out.println( "This should be no surprise one " +
                                               "is equal to one!");
         } else { 
            System.out.println( "This might surprise you one is equal to " +
                                theResult + ".");
         } // End if.
     }  // End main
} // End SubtleFloatingPointError

