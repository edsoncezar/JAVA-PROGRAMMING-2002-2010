// Filename SafeDemo.java.
// Providing a demonstration of the possibility of 
// an invalid update happening to a dangerous object.
//
// Written for JFL book Chapter 8 see text.
// Fintan Culwin, v0.1, January 1997.


public class SafeDemo { 

   public static void main( String argv[]) { 

   Safe       safe    = new Safe();
   SafeWriter aWriter = new SafeWriter( safe);
   SafeReader aReader = new SafeReader( safe);

      aWriter.start();
      aReader.start();
   } // End main.   
} // End  SafeDemo.
