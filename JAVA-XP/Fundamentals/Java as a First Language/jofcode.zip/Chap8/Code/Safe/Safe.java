// Filename Safe.java.
// Contains an updatable object with synchronization,
// preventing the possibility of an invalid update.
//
// Written for JFL book Chapter 8 see text.
// Fintan Culwin, v0.1, January 1997.

public class Safe extends Object { 

private int anAttribute;
private int anotherAttribute;

   public synchronized void update( int updateTo) { 
      anAttribute      = updateTo;
      anotherAttribute = updateTo;
   } // End update.
   
   
   public int getAnAttribute( ) { 
      return anAttribute;
   } // End getAnAttribute.
   
   
   public int getAnotherAttribute( ) { 
      return anotherAttribute;
   } // End getAnotherAttribute.
   
} // End Safe.

