// Filename Dangerous.java.
// Contains an updatable object without synchronisation,
// leading to the possibility of an invalid update.
//
// Written for JFL book Chapter 8 see text.
// Fintan Culwin, v0.1, January 1997.

public class Dangerous extends Object { 

private int anAttribute;
private int anotherAttribute;

   public void update( int updateTo) { 
      anAttribute      = updateTo;
      anotherAttribute = updateTo;
   } // End update.
   
   
   public int getAnAttribute( ) { 
      return anAttribute;
   } // End getAnAttribute.
   
   
   public int getAnotherAttribute( ) { 
      return anotherAttribute;
   } // End getAnotherAttribute.
   
} // End Dangerous.

