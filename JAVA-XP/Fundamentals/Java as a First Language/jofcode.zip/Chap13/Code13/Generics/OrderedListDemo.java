// Filename OrderedListDemo.java.
//
//
// Written for JFL book, chapter 14.
// Fintan Culwin, v0.1, Jan 1997.


import Generics.OrderedList;
import Generics.GenericException;
import Persons.*;

class OrderedListDemo {

  public static void main(String args[]) {

  EmailAddress demoAddress;  
  NamedPerson  demoNamedPerson = new NamedPerson(); 
  PhonePerson  demoPhonePerson;
  String       demoString;
  
  OrderedList demoList = new OrderedList( demoNamedPerson.getClass());
  
  
     System.out.println( "\tOrdered List Demonstration Program\n\n");
     
     System.out.println( "Adding three instances to the list ...");
     
     demoNamedPerson = new NamedPerson( "sad@boring.com",
                                        "Suzie Sad");
     demoList.add( demoNamedPerson); 

     demoPhonePerson = new PhonePerson( "geek@boring.com",
                                        "Gary Geek",
                                        "111-2222");
     demoList.add( demoPhonePerson); 
                               
     demoNamedPerson = new NamedPerson( "anorak@boring.com",
                                        "Andy Anorak");
     demoList.add( demoNamedPerson);                                    
     

    System.out.println( "\nShowing the list ...\n");
    System.out.println( demoList);

    System.out.println( "\nAttempting to add an existing element ...\n");
    System.out.println( "Attemptng to add " + 
                         demoNamedPerson.keyValueIs());
    try { 
       demoList.add( demoNamedPerson); 
       System.out.println( "added ... demonstration failed.");
    } catch ( Exception exception) { 
       System.out.println( "Exception thrown ... demonstration passed!");
    } // End try/ catch




    System.out.println( "\nObtaining an element ...\n");
    demoAddress = new EmailAddress( "sad@boring.com");
    System.out.println( "Attemptng to obtain " + demoAddress);
    try { 
       demoNamedPerson = (NamedPerson) demoList.obtain( demoAddress); 
       System.out.println( "Obtained ... " + demoNamedPerson);
    } catch ( Exception exception) { 
       System.out.println( "Exception thrown ... demonstration failed!");
    } // End try/ catch

    System.out.println( "\nAttempting to obtain an element ...\n");
    demoAddress = new EmailAddress( "noone@nowhere.com");
    System.out.println( "Attemptng to obtain " + demoAddress);
    try { 
       demoNamedPerson = (NamedPerson) demoList.obtain( demoAddress); 
       System.out.println( "Obtained ... " + demoNamedPerson + 
                           "\nNo exception thrown ... demonstration failed");
    } catch ( Exception exception) { 
       System.out.println( "Exception thrown as expected " + 
                           " ... demonstration suceeded!");
    } // End try/ catch

    System.out.println( "\nRemoving an element ...\n");
    demoAddress = new EmailAddress( "anorak@boring.com");
    System.out.println( "Attemptng to remove " + demoAddress);
    try { 
       demoNamedPerson = (NamedPerson) demoList.remove( demoAddress); 
       System.out.println( "Removed ... " + demoNamedPerson);
       System.out.println( "\nThe list now contains ...");
       System.out.println( demoList);
    } catch ( Exception exception) { 
       System.out.println( "Exception thrown ... demonstration failed!");
    } // End try/ catch
  } // End main.
} // End OrderedListDemo.  

