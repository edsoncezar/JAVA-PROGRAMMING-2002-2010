//

import Persons.*;

class PersonDemo { 

    public static void main(String args[]) {

    NamedPerson aPerson;
    PhonePerson anotherPerson = new PhonePerson();
    PhonePerson copiedPerson;
    
       System.out.println( "\tPersons hierarchy demonstration\n");
       
       System.out.println( "Constructing a NamedPerson instance ...");
       aPerson = new NamedPerson( "jim@test.com", "Jimmy Bean");
       System.out.println( "instance constructed, demonstrating output ...");
       System.out.println( aPerson);
       
       System.out.println( "\nPlease enter details of a person");
       anotherPerson.read();
       System.out.println( "\nThank you, your input ...");       
       System.out.println( anotherPerson);

       System.out.println( "\nDemonstrating the Ordering actions ...\n");
       System.out.println( aPerson);       
       if ( (aPerson.keyValueIs()).keyIsEqualTo( 
                     anotherPerson.keyValueIs() ) ){ 
          System.out.println( " ... is equal to ... ");
       } else if ( (aPerson.keyValueIs()).keyIsGreaterThan( 
                        anotherPerson.keyValueIs() )) {    
          System.out.println( " ... is greater than ... "); 
       } else if ( (aPerson.keyValueIs()).keyIsLessThan( 
                        anotherPerson.keyValueIs() )) {
          System.out.println( " ... is less than ... ");   
       } else { 
          System.out.println( "ORDERING DEMONSTRATION FAILED!!");
       } // End if.   



       System.out.println( "\nCopying the Phone Person instance ...");

       System.out.println( "\nHash code and contents to be copied ...");       
       System.out.println( anotherPerson.hashCode());
       System.out.println( anotherPerson);
       
       copiedPerson = anotherPerson.copy();
       
       System.out.println( "\nHash code and contents copied ...");       
       System.out.println( "The copy contains ... ");
       System.out.println( copiedPerson.hashCode());
       System.out.println( copiedPerson);

    } // End main.

} // End PersonDemo.
