// Filename ContactListDemonstration.java.
// Introduces the Hashtable class by storing 
// a list of people's details.
//
// Written for JFL book Chapter 13.
// Fintan Culwin, v 0.1, Jan 1997.

import Persons.*;
import Menus.BasicMenu;
import ValidatedInput;

import java.util.Hashtable;
import java.util.Enumeration;
import java.io.*;

class ContactList { 

private static final char ADD_OPTION    = 'A';
private static final char REMOVE_OPTION = 'B';
private static final char SHOW_OPTION   = 'C';
private static final char EXIT_OPTION   = 'D';

private static final char PART_OPTION   = 'A';
private static final char FULL_OPTION   = 'B';

private static DataInputStream theKeyboard 
                   = new DataInputStream( System.in);    

   public static void main(String args[]) {
   
   

   String mainOptions[] =  { "Add to contact list.",
                             "Remove from contact list",
                             "Show contact list.",
                             "Exit"};
                             
   String subOptions[] =   { "Add name and e-mail",
                             "Add name, e-mail and phone number"};
                             
   BasicMenu mainMenu = new BasicMenu( "Contact list main menu",
                                       mainOptions,
                                       "");
                                       
   BasicMenu subMenu  = new BasicMenu( "Add contact sub menu",
                                       subOptions,
                                       "");                                       
   Hashtable theList   = new Hashtable();
   char mainMenuChoice = ' ';    
   
      while ( mainMenuChoice != EXIT_OPTION ) { 
         System.out.println( "\n\n");
         mainMenuChoice = mainMenu.offerMenuAsChar();
         System.out.println( "\n");
      
         switch ( mainMenuChoice) { 
            
            case  ADD_OPTION:   
               addOption( theList, subMenu);
               break;
            // End case ADD_OPTION.
         
            case  REMOVE_OPTION:
               removeOption( theList);
               break;
            // End case REMOVE_OPTION.
           
            case  SHOW_OPTION:
               showOption( theList);
               break;
            // End case SHOW_OPTION.         
         
            case  EXIT_OPTION:
               System.out.println( "Have a nice day");
               break;
            // End case SHOW_OPTION.                          
         } // End switch.      
      } // End while.
   } // End main.
   

   static private void addOption( Hashtable aList,
                                  BasicMenu theMenu) { 
   
   char        subMenuChoice;
   
   EmailPerson aPerson;   
      subMenuChoice = theMenu.offerMenuAsChar();
      if ( subMenuChoice == PART_OPTION) {            
         aPerson = new NamedPerson();
      } else {              
         aPerson = new PhonePerson();
      } // End if. 
      aPerson.read();
      
      if ( aList.containsKey( aPerson.eMailIs())) { 
         System.out.println( aList.get( aPerson.eMailIs()) + 
                             " ... has been removed.");
      } // End if.
      
      aList.put( aPerson.eMailIs(), aPerson); 
      System.out.println( aPerson + " ... has been added");          
   } // end addOption.


   static private void removeOption( Hashtable aList) {

   String  toRemove = "";
   boolean emailOK  = false;    
    
       while ( ! emailOK) { 
          try { 
             System.out.print( 
                "Please enter the email address of the person to remove \n" +
                " (Or <ENTER> to cancel) : ");
             System.out.flush();
             toRemove = new String( theKeyboard.readLine()).trim();
             emailOK = true;             
          } catch ( IOException exception) { 
             System.out.println( 
                        "Sorry there seems to be a problem!\n" +
                        "Could you please try again.");
          } // End try/ catch.   
       } // End while.           
       
       if ( toRemove.length() != 0) { 
          if ( aList.containsKey( toRemove)) { 
             System.out.print( aList.get( toRemove));
             aList.remove( toRemove); 
             System.out.println( " ... has been removed");         
          } else { 
             System.out.println( "That email address is not in the list");
          } // End if.
       } // End if.      
    } // End removeOption.            
            
              
//   static private void showOption( Hashtable aList) {                        
//      System.out.println( aList);   
//   } // End showOption.
  
   
//   static private void showOption( Hashtable aList) {  
//   
//   int         thisElement = 0;
//   NamedPerson fromList;
//   Enumeration contacts    = aList.elements();
//   
//      while( contacts.hasMoreElements() ) { 
//         fromList = (NamedPerson) contacts.nextElement();      
//         thisElement++;
//         System.out.println( thisElement + "  " + fromList);       
//      } // End while;   
//   } // End showOption.    


   static private void showOption( Hashtable aList) {  
   
   int         thisElement = 0;
   NamedPerson fromList;
   String      eMailKey;
   Enumeration contacts    = aList.keys(); 
      while( contacts.hasMoreElements() ) { 
         eMailKey = (String) contacts.nextElement();   
         fromList = (NamedPerson) aList.get( eMailKey);  
         thisElement++;
         System.out.println( thisElement + "  " + fromList);       
      } // End while;   
   } // End showOption.    
      
} // End class ContactList.
