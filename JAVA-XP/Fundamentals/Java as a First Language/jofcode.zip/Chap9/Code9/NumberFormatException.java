 // Filename NumberFormatException.java.
 // Providing specific exception for number formatting.
 //
 // Written for JFL book Chapter 9 see text.
 // Fintan Culwin, v0.1, January 1997
 
 
 
 class NumberFormatException extends RuntimeException { 
 
 public static final int NO_PROBLEM   = 0; 
 public static final int INVALID_BASE = 1;
 
 
    public NumberFormatException(){
      // Do nothing.
    } // End default constructor
    
    public NumberFormatException( int reason) {
    
       switch ( reason) {  
       case INVALID_BASE: 
          super( "Invalid base specified");
          break;
       default: 
          super( "Unknown reason");
       } // End switch.      
    } // End principal constructor
    
 
 } // End CounterException
 
