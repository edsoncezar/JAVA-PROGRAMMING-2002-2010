// Way6B.java
//
// A simple class containing several attributes, 
// a constructor, a setter rule and I/O methods. 
//
// A collection of these will be written to and 
// then read from a file. 
//
// Assumes BasicMenu & other terminal i/o classes 
// are available. 
//
// Fintan Culwin, V0.1, May 2000

package way6b;

import java.io.*;

public class Way6B extends Object { 


private int    anInt    = 0; 
private double aDouble  = 0.0;
private String aString  = "";

   public Way6B() { 
      super(); 
   } // End Way6B default constructor. 

   public Way6B( String conStr, int conInt) { 
      super();
      aString = conStr;
      anInt   = conInt;
      aDouble = (double) conInt;
   } // End Way6B


   public void writeDetails( DataOutputStream theStream) 
                               throws java.io.IOException {
      theStream.writeUTF( this.aString);
      theStream.writeInt( this.anInt);
   } // End writeDetails.   

   public void readDetails( DataInputStream theStream)
                               throws java.io.IOException {
      this.aString = theStream.readUTF();
      this.anInt   = theStream.readInt();
   } // End readDetails.

   public String toString() { 
      return aString + " " + anInt + " " + aDouble; 
   } // End toString.

} // End Class Way6A.
