// Filename FuelTransaction\FuelTransaction.java.
// Contains details of a single fuel sale with 
// methods to read and write to/from a stream.
//
// Written for waypoint 5.
// Fintan Culwin, v0.1, march 1997

package FuelTransaction;

import  java.io.*;
import  OutputFormatter;

public class FuelTransaction {

private String typeOfFuel;
private double amountOfFuel;
private double costOfFuel;

  public FuelTransaction() { 
     this( "invalid", 0.0, 0.0);
  } // End FuelTransaction default constructor;

  public FuelTransaction( String type,
                          double amount,
                          double cost ) {
     super();
     typeOfFuel   = new String( type);
     amountOfFuel = amount;
     costOfFuel   = cost;
  } // End FuelTransaction constructor.


  public String typeOfFuelIs() {
     return new String( typeOfFuel);
  } // End typeOfFuelIs.

  public double amountOfFuelIs() {
     return amountOfFuel;
  } // End amountOfFuelIs.

  public double costOfFuelIs() {
     return costOfFuel;
  } // End costOfFuelIs.


  public void writeTransaction( DataOutputStream theStream)
                                    throws java.io.IOException {
     theStream.writeUTF(    this.typeOfFuelIs());
     theStream.writeDouble( this.amountOfFuelIs());
     theStream.writeDouble( this.costOfFuelIs());
  } // End writeTransaction.

  public void readTransaction( DataInputStream theStream)
                                   throws java.io.IOException {
     this.typeOfFuel   = theStream.readUTF();
     this.amountOfFuel = theStream.readDouble();
     this.costOfFuel   = theStream.readDouble();
  } // End readTransaction.


  public String toString(){
     return OutputFormatter.formatFloat( (float) this.amountOfFuelIs(),
                                          4, 2, false)         +
            " of " + this.typeOfFuelIs() + " sold for "        +
            OutputFormatter.formatFloat( (float) this.costOfFuelIs(),
                                          4, 2, false)         +
            ".";
  } // End toString.

} // End class FuelTransaction.
