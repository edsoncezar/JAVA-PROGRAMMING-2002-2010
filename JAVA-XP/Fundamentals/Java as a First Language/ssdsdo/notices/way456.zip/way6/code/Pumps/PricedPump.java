// Filename Pumps/PricedPump.java.
// Supplies and supports the priceperUnit 
// attribute of the PricedPump.javaPump hierarchy.
//
// Written for SSD waypoint 1. 
// Fintan Culwin, v0.1, Sept 1997.

package Pumps;


public class PricedPump extends MeteredPump {

private double pricePerUnit = 0.0;

   public PricedPump( String units,
                      double price) { 
      super( units);
      pricePerUnit = price;
   } // End PricedPump constructor.


   public double pricePerUnitIs() { 
      return pricePerUnit;
   } // End amountDispensedIs.


   public String toString() { 
      return super.toString() +
             "\nAt a cost of " + 
              this.pricePerUnitIs() + ".";
   } // End toString.

} // End PricedPump.
