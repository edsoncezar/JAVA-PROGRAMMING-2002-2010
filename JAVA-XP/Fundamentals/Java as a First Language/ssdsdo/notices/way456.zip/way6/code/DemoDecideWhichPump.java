// Filename DemoDecideWhichPump.java.
// Change the price of a Fuel Pump in an array.
//
// Written for waypoint 4 assessment F.
// Fintan Culwin, v0.1, March 1998.



import Pumps.FuelPump;

import ValidatedInput;


public class DemoDecideWhichPump { 




   public static void main( String argv[]) { 


   FuelPump thePumps[] = { new FuelPump( "litres", 0.60, FuelPump.UNLEADED),
                           new FuelPump( "litres", 0.65, FuelPump.LEADED) 
                           new FuelPump( "litres", 0.62, FuelPump.DIESEL) };

   int theChosenPump;

      System.out.println("Decide Which Pump Demo");


      
      theChosenPump = decideWhichPump( thePumps);

 
      System.out.println( "\nPump " + theChosenPump " was chosen.");
   } // End main.


    private static int decideWhichPump( FuelPump  allPumps[] {  

   int      chosenPump;      

        for ( int index =0; index < pumpsToChange.length; index++) {
           System.out.println( "Pump " + ??????+ " is dispensing " + 
                            ??????????? + " at " + 
                            ??????????? + 
                            " per litre");
        } // End for.
        pumpToChange = ???? ValidatedInput.?????( ??????);

        return ?????

   } // End decideWhichPump.



} // End class DemoDecideWhichPump.
