// Filename Pumps/FuelPump.java.
// Supplies and supports the fuel 
// attribute of the PricedPump.javaPump hierarchy.
//
// Written for SSD waypoint 1. 
// Fintan Culwin, v0.1, Sept 1997.

package Pumps;

import Pumps.PumpException;

public class FuelPump extends PricedPump {

public static final int UNKNOWN  = 0;
public static final int UNLEADED = 1;
public static final int LEADED   = 2;
public static final int DIESEL   = 3;

private int theFuel = UNKNOWN;

   public FuelPump( String units,
                    double price,
                    int    fuel) { 
      super( units, price);
      theFuel = fuel;
   } // End FuelPump constructor.


   public double dispenseFuel( double amount) { 
      
      if ( this.isSwitchedOn()) { 
         super.dispense( amount);
         return amount * this.pricePerUnitIs();
      } else { 
         throw new PumpException( "Pump Switched off");
      } // End if.
   } // End dispenseFuel.

   public int fuelIs() { 
      return theFuel;
   } // End fuelIs.

   public String fuelNameIs() { 

   String fuelName;

      if ( this.fuelIs() == UNLEADED) { 
         fuelName = new String( "unleaded");
      } else if ( this.fuelIs() == LEADED) { 
         fuelName = new String( "leaded");
      } else if ( this.fuelIs() == DIESEL) { 
         fuelName = new String( "diesel");
      } else { 
         fuelName = new String( "unknown");
      } // End if.
      return fuelName;
   } // End fuelNameIs.


   public String toString() { 
      return super.toString() +
             "\nIt is dispensing " + 
              this.fuelNameIs() + ".";
   } // End toString.

} // End FuelPump.
