// Filename TransactionLogUtility.java.
// Allows transaction log from fifth
// garage simulation to be read.
//
// Written for JFL book Chapter 7 see text.
// Fintan Culwin, v0.1, January 1997

import java.io.*;
import java.util.Vector;

import Menus.BasicMenu;
import Pumps.FuelPump;
import OutputFormatter;
import FuelTransaction.FuelTransaction;



public class TransactionLogUtility {

   public static void main( String argv[]) { 

   Vector transactions = new Vector();

   final String menuOptions[]  =  { "List transactions",
                                    "Save transactions",    
                                    "Sort by Price",               
                                    "Exit"};

   final char LIST_TRANSACTIONS  = 'A';
   final char SAVE_TRANSACTIONS  = 'B';
   final char SORT_BY_PRICE      = 'C';
   final char EXIT_CHOICE        = 'D';

   BasicMenu mainMenu = new BasicMenu( "\nFuel sales Transaction Log Utility",
                                       menuOptions,
                                       "");
   char menuChoice = ' '; 
   

      System.out.println("\n\nFuel sales Transaction Log Utility");
      System.out.println("\nLoading from file ... please wait ...");
      readTransactionsFromFile( transactions);

      while ( menuChoice != EXIT_CHOICE) {
         menuChoice = mainMenu.offerMenuAsChar();
         switch ( menuChoice) {

         case LIST_TRANSACTIONS : listTransactions( transactions);

         case SAVE_TRANSACTIONS : saveTransactions( transactions);

         case SORT_BY_PRICE     : sortTransactionsByPrice( transactions);

         } // End switch.
      } // End while.
      System.out.println( "\n\nFuel sales Transaction Log Utility");

   } // End main.






   private static void listTransactions( Vector toList) { 

      System.out.println( "\nListing " + toList.size() + " transactions\n");

      for ( int index =0; index < toList.size(); index++ ) { 
          System.out.print( (index+1) + "   ");
          System.out.println( toList.elementAt( index));
      } // End for.
   } // End listTransactions.


   private static void saveTransactions( Vector toSave) { 

   PrintWriter saveHere;

      System.out.println( "\nSaving " + toSave.size() + " transactions" + 
                          " to 'transactions.lis'");

      try { 
         saveHere = new PrintWriter( 
                        new FileOutputStream( 
                            "transactions.lis"));
         for ( int index =0; index < toSave.size(); index++ ) { 
             saveHere.print( (index+1) + "   ");
             saveHere.println( toSave.elementAt( index));
         } // End for.
         saveHere.close();
      } catch ( IOException exception) { 
         System.err.println( "Exception when saving transactions ... "+
                             " continuing ...");
      } // End try/catch
   } // End saveTransactions.


   private static void sortTransactionsByPrice( Vector toSort) { 

   int     outerIndex;
   boolean isSorted = false;

      while ( ! isSorted) { 
         isSorted = true;
         for( int index = 0; index < (toSort.size()-1); index++) { 
         FuelTransaction thisOne;
         FuelTransaction nextOne;
         
            thisOne = (FuelTransaction) toSort.elementAt( index); 
            nextOne = (FuelTransaction) toSort.elementAt( index+1); 
            
            if ( thisOne.costOfFuelIs() > nextOne.costOfFuelIs() ) { 
               toSort.setElementAt( thisOne, index+1); 
               toSort.setElementAt( nextOne, index); 
               isSorted = false;
            } // End if.
         } // End for.
      } // End while.
   } // End sortTransactionsByPrice.



   private static void readTransactionsFromFile( Vector storeHere) { 

   DataInputStream readFromHere = null;
   FuelTransaction fromFile;
   boolean         fileNotFinished = true;

      try {          
         readFromHere = new DataInputStream(
                            new FileInputStream( "transactions.dat"));
         System.out.println("\nFile open ... reading ...");  
         
         while ( fileNotFinished) { 
            try { 
               fromFile = new FuelTransaction();
               fromFile.readTransaction( readFromHere);
               storeHere.addElement( fromFile);
               System.out.print( "."); 
            } catch ( EOFException exception) { 
               System.out.println( "\n" + storeHere.size() + 
                                 " transactions read from file."); 
               fileNotFinished = false;
            } // End try/catch 
         } // End while.    

         readFromHere.close();
                                      
      } catch ( IOException exception) { 
          System.err.println("Transactions file could not be read sucesfully" + 
                             " ...\nThis program is finishing .... ");
          System.exit( -1);
      } // End try/catch 

   } // End readTransactionsFromFile.

} // End TransactionLogUtility.
