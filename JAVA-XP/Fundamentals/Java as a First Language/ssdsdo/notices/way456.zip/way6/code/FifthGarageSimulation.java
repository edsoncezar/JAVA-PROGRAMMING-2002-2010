// Filename FifthGarageSimulation.java.
// Adds a MoneyRegister to the simulation.
//
// Written for JFL book Chapter 7 see text.
// Fintan Culwin, v0.1, January 1997

import java.io.*;

import Menus.BasicMenu;
import Pumps.FuelPump;
import OutputFormatter;
import ValidatedInput;
import Counters.MoneyRegister;
import FuelTransaction.FuelTransaction;

public class FifthGarageSimulation {


public static void main( String argv[]) { 

   final String menuOptions[] =  { 
                                 "Show the state of the pumps", 
                                 "Switch all pumps on",   
                                 "Switch a pump off",
                                 "Dispense fuel",      
                                 "Show the Money Register",                   
                                 "Exit"
                                 };


   final char SHOW_THE_PUMPS      = 'A';
   final char SWITCH_ALL_PUMPS_ON = 'B';
   final char SWITCH_A_PUMP_OFF   = 'C';
   final char DISPENSE_FUEL       = 'D';
   final char SHOW_REGISTER       = 'E';
   final char EXIT_CHOICE         = 'F';

   BasicMenu garageMenu = new BasicMenu( "\nGarage Simulation Menu",
                                         menuOptions,
                                         "");

   char   menuChoice = ' ';


   final String fuelOptions[] =  { "unleaded", 
                                   "leaded"};

   BasicMenu fuelMenu  = new BasicMenu( "\nFuel menu",
                                         fuelOptions,
                                         "");

   FuelPump thePumps[] = { 
                         new FuelPump( "litres", 0.60, FuelPump.UNLEADED),
                         new FuelPump( "litres", 0.65, FuelPump.LEADED) 
                         };
                             


   double        theCost     = 0.0;
   MoneyRegister theRegister = new MoneyRegister( 100.0);


   DataOutputStream storeHere = null;
   try { 
       storeHere = new DataOutputStream(
                       new FileOutputStream( "transactions.dat"));
   } catch (IOException exception) { 
      System.err.println("Transactions file could not be opened ...\n" + 
                         "... continuing ... ");
   } // End try/catch 

      System.out.println( "\n\t\t Fifth Garage Simulation ");

      while ( menuChoice != EXIT_CHOICE) {
         menuChoice = garageMenu.offerMenuAsChar();

         switch ( menuChoice) {

         case SHOW_THE_PUMPS : 
                   showThePumps( thePumps);
                   break;

         case SWITCH_ALL_PUMPS_ON : 
                   switchAllPumpsOn( thePumps);
                   break;

         case SWITCH_A_PUMP_OFF : 
                   switchAPumpOff( thePumps, fuelMenu);
                   break;

         case DISPENSE_FUEL : 
                   theCost = dispenseFuel( thePumps,fuelMenu,
                                           storeHere);
                   if ( theCost > 0.0) {
                      System.out.print( "That will cost");
                      System.out.println(
                             OutputFormatter.formatFloat(
                                   (float) theCost,
                                   4, 2, false));
                      theRegister.deposit( theCost);
                  } else {
                      System.out.println(
                            "That pump is switched off");
                  } // End if.
                  break;

        case SHOW_REGISTER : 
                  showTheRegister( theRegister);
                  break;

         } // End switch.
      } // End while.

      try { 
         storeHere.close();
      } catch IOException exception) { 
         System.err.println("Transactions file could not be closed " + 
                            " ...\n... continuing ... ");        
      } // End try catch.

      System.out.println( "\n\nEnd of Fifth Garage Simulation ");
   } // End main
   


   private static void showTheRegister( MoneyRegister registerToShow) { 
      System.out.println( registerToShow);
   } // End showTheRegister.

   private static void showThePumps( FuelPump pumpsToShow[]) { 

      for ( int index = 0; index < pumpsToShow.length; index++) { 
         System.out.println( "\n");
         System.out.println( pumpsToShow[ index]);         
      } // End for.
   } // End showThePumps.


   private static void switchAllPumpsOn( FuelPump pumpsToSwitchOn[]) { 

      for ( int index = 0; index < pumpsToSwitchOn.length; index++) { 
         pumpsToSwitchOn[ index].switchOn();        
      } // End for.
   } // End switchAllPumpsOn.




   private static void switchAPumpOff( FuelPump  pumpsToSwitchOff[],
                                       BasicMenu fuelOffmenu) { 
   int fuelChoice = ' ';

        fuelChoice = fuelOffmenu.offerMenuAsInt() -1;
        pumpsToSwitchOff[ fuelChoice].switchOff();
   } // End switchAPumpOff.



   private static double dispenseFuel( FuelPump  pumpsToDispenseFrom[],
                                       BasicMenu fuelDispenseMenu,
                                       DataOutputStream recordHere    ){
   int    fuelChoice   = ' ';
   float  amountOfFuel;
   double costOfFuel   = 0.0;

        fuelChoice   = fuelDispenseMenu.offerMenuAsInt() -1;
        if ( pumpsToDispenseFrom[ fuelChoice].isSwitchedOn() ) {
           amountOfFuel = (float) ValidatedInput.readDouble(
                                     "How much fuel : ", 0.0F, 250.0F);
           costOfFuel   = pumpsToDispenseFrom[ fuelChoice].
                                    dispenseFuel( amountOfFuel);
           try {
           FuelTransaction details = new FuelTransaction(
                pumpsToDispenseFrom[ fuelChoice].fuelNameIs(),
                amountOfFuel, costOfFuel);

                details.writeTransaction( recordHere);
           } catch ( java.io.IOException exception) {
                System.err.println( "Exception thrown when writing " +
                               "transaction details ... continuing!");

           } // End try/catch.

        } // End if.
        return costOfFuel;
   } // End dispenseFuel.

} // End  FifthGarageSimulation.


