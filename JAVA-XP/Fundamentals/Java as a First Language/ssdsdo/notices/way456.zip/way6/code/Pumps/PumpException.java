// Filename Pumps/PumpException.java.
// Providing a specialised execption class for 
// use with the Pumps hierrachy.
//
// Written for SSD waypoint 1. 
// Fintan Culwin, v0.1, Sept 1997.

package Pumps;
 
public class PumpException extends RuntimeException { 
    
    public PumpException( String reason) { 
       super( reason);
    } // End principal constructor
     
} // End PumpException.
 
