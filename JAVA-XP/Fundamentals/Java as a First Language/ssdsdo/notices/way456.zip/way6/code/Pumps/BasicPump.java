// Filename Pumps/BasicPump.java.
// Supplies and supports the state attribute of the 
// Pump hierarchy.
//
// Written for SSD waypoint 1. 
// Fintan Culwin, v0.1, Sept 1997.

package Pumps;


public class BasicPump extends Object {

private boolean state = false;


   public BasicPump() { 
      super();
      state = false;
   } // End BasicPump constructor.


   public void switchOn() { 
      state = true;
   } // End switchOn.

   public void switchOff() { 
      state = false;
   } // End switchOff.

   public boolean isSwitchedOn() { 
      return state;
   } // End switchOn.


   public String toString() { 
      if ( this.isSwitchedOn()) { 
         return "The pump is switched on.";
      } else { 
         return "The pump is switched off.";
      } // End if.
   } // End toString.

} // End BasicPump.
