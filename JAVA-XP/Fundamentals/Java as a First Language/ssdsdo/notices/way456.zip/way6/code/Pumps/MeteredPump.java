// Filename Pumps/MeteredPump.java.
// Supplies and supports the totalAmount and
// dispensingIn attributes of the 
// Pump hierarchy.
//
// Written for SSD waypoint 1. 
// Fintan Culwin, v0.1, Sept 1997.

package Pumps;


public class MeteredPump extends BasicPump {

private double totalAmount  = 0.0;
private String dispensingIn = null;


   public MeteredPump( String units) { 
      super();
      totalAmount  = 0.0;
      dispensingIn = new String( units);
   } // End MeteredPump constructor.


   public void switchOn() { 
      totalAmount = 0.0;
      super.switchOn();
   } // End switchOn.


   public void dispense( double amount) { 
      totalAmount += amount;
   } // End switchOn.


   public double amountDispensedIs() { 
      return totalAmount;
   } // End amountDispensedIs.


   public String toString() { 
      return super.toString() +
             "\nIt has dispensed " + 
              this.amountDispensedIs() + 
             " " + dispensingIn + ".";
   } // End toString.

} // End MeteredPump.
