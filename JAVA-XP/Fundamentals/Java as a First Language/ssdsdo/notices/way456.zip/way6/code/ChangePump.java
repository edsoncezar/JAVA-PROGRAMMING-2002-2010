// Filename ChangePrice.java.
// Change the price of a Fuel Pump in an array.
//
// Written for waypoint 4 assessment C.
// Fintan Culwin, v0.1, March 1998.


import Menus.BasicMenu;
import Pumps.FuelPump;
import OutputFormatter;
import ValidatedInput;


public class ChangePump { 




   public static void main( String argv[]) { 

   final String fuelOptions[] =  { "unleaded", 
                                   "leaded"};

   FuelPump thePumps[] = { new FuelPump( "litres", 0.60, FuelPump.UNLEADED),
                           new FuelPump( "litres", 0.65, FuelPump.LEADED) };

   BasicMenu fuelMenu  = new BasicMenu( "\nFuel menu",
                                         fuelOptions,
                                         "");

      System.out.println("Change the Price Demo");

      thePumps[ 0].switchOn();
      thePumps[ 1].switchOn();

      System.out.println( "\nShowing the Pumps ... ");
      System.out.println( thePumps[ 0]);
      System.out.println( "\n\n");
      System.out.println( thePumps[ 1]);
      System.out.println( "\n\n");

      System.out.println( "Changing a pump ...\n");
      changeAPump( thePumps, fuelMenu);

      System.out.println( "Showing the Changed Pumps");
      System.out.println( thePumps[ 0]);
      System.out.println( "\n\n");
      System.out.println( thePumps[ 1]);
      System.out.println( "\n\n");     

   } // End main.


    private static int decideWhichPump( FuelPump  allPumps[] {  

   int      chosenPump;      

        for ( int index =0; index < pumpsToChange.length; index++) {
           System.out.println( "Pump " + ??????+ " is dispensing " + 
                            ??????????? + " at " + 
                            ??????????? + 
                            " per litre");
        } // End for.
        pumpToChange = ???? ValidatedInput.?????( ??????);

        return ?????

   } // End decideWhichPump.



} // End class DemoDecideWhichPump.
