
import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class TimerEventSourceInterface  { 


private Label theTime;

   public TimerEventSourceInterface( Applet screenWindow) { 
      theTime = new Label( "******");
      screenWindow.add( theTime);
   } // End init. 

   public void setTime( String timeNow) { 
      theTime.setText( timeNow);
   } // End setTime;


} // End class TimerEventSourceInterface.
