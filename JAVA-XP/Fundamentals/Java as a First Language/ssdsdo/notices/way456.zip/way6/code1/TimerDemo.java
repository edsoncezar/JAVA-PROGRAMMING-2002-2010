//

public class TimerDemo extends Object { 


public static void main( String argv[]) { 

Timer aTimer = new Timer();

   System.out.println( "Timer demo .. starting the timer.");
   aTimer.start();
   for ( int tick =0; tick < 15; tick++) {
      for ( int index = 0; index < 500000; index++) { 
         // do nothing.
      } 
   System.out.print( aTimer.getTime() + "  ");
   System.out.flush();
   } 
   System.out.println( "\n");

   System.out.println( "Timer demo .. suspending the timer.");
   aTimer.suspend();
   for ( int tick =0; tick < 15; tick++) {
      for ( int index = 0; index < 500000; index++) { 
         // do nothing.
      } 
   System.out.print( aTimer.getTime() + "  ");
   System.out.flush();
   } 
   System.out.println( "\n");

   System.out.println( "Timer demo .. resuming the timer.");
   aTimer.resume();
   for ( int tick =0; tick < 15; tick++) {
      for ( int index = 0; index < 500000; index++) { 
         // do nothing.
      } 
   System.out.print( aTimer.getTime() + "  ");
   System.out.flush();
   } 
   System.out.println( "\n");


   System.out.println( "Timer demo .. resetting the timer.");
   aTimer.resetTime();
   for ( int tick =0; tick < 15; tick++) {
      for ( int index = 0; index < 500000; index++) { 
         // do nothing.
      } 
   System.out.print( aTimer.getTime() + "  ");
   System.out.flush();
   } 
   System.out.println( "\n");

   aTimer.stop();
} 



} // End TimerDemo.
