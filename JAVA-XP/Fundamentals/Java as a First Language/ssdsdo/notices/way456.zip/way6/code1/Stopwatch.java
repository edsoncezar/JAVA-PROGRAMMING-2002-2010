// Stopwatch.java
// Timer class which demonstrates recieving 
// ActionEvents from a unicaster and showing
// them in a graphical window.
// Bridge between threading and GUIs.
// Written for waypoint 5.
//
// Fintan Culwin, v0.1, March 1998.


import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class Stopwatch extends Applet
                    implements ActionListener { 

private static final int INITIAL = 0;
private static final int RESET   = 1;
private static final int RUNNING = 2;
private static final int STOPPED = 3;
private int theState = INITIAL;

private TimerEventSource aTimer      = null;
private StopwatchUI      anInterface = null;

   public void init() { 

      aTimer      = new TimerEventSource();
      anInterface = new StopwatchUI( this, this);
      try { 
         aTimer.addActionListener( this);
      } catch ( java.util.TooManyListenersException exception) { 
         // do nothing
      } // End try/catch      
      anInterface.setResetState();
      theState = RESET;
      aTimer.start();
   } // End init.


   public synchronized void actionPerformed( ActionEvent event) {

   String theCommand = event.getActionCommand();

      if ( theCommand.equals( "start")) { 
         aTimer.resetTime();
         anInterface.setRunningState();
         theState = RUNNING;

      } else if ( theCommand.equals( "stop")) { 
         anInterface.setStoppedState();
         theState = STOPPED;

      } else if ( theCommand.equals( "reset")) { 
         anInterface.setResetState(); 
         theState = RESET;        

      } else if ( theState == RUNNING) { 
         anInterface.setTime( theCommand);
      } // End if.
   } // End actionPerformed.


   public static void main( String argv[]) { 

   Frame     frame    = new Frame("Stopwatch");
   Stopwatch theDemo  = new Stopwatch();
  
      theDemo.init();  
      frame.add( theDemo, "Center");
  
      frame.show();
      frame.setSize( frame.getPreferredSize());     
   } // End main.

} // End class Stopwatch.
