// Way6CDemo.java
//
// ONLY THE saveTheList() METHOD IS INCOMPLETE - ALL 
// OTHER PARTS OF THE FILE SHOULD NOT BE CHANGED!!
//
// Fintan Culwin, V0.1, May 2000

package way6c;

import java.util.*;
import java.io.*; 

public class Way6CDemo { 
 
    public static void main( String argv[]) { 

    Vector demoVect = new Vector(); 

        System.out.println( "Demonstration harness for the " + 
                            "Waypoint 6 version C Assessment"); 

        System.out.println( "\n\nFruging the list . . . ");
        frugTheList( demoVect);
        System.out.println( "\n. . . list frugged showing . . . \n");  
        showTheList( demoVect);    
        System.out.println( "\n. . . saving the list in way6c.dat . . . \n");        
        saveTheList( demoVect);   
        System.out.println( "\n. . . saved\n. . . reloading . . . \n");
        demoVect = loadTheList();
        System.out.println( "\n. . . showing the reloaded list  . . . \n");       
        showTheList( demoVect);     
             
        System.out.println( "\nend of demonstration program \n");
    } // End main.

    private static final void frugTheList( Vector frugVect) { 
       for ( int index = 0; index < 10; index++) { 
          frugVect.addElement( new Way6C( index));
       } // End for. 
    } // End frugTheList

    private static final void showTheList( Vector showVect) { 
       for ( int index = 0; index < showVect.size(); index++) { 
           System.out.println( (Way6C) showVect.elementAt( index));
       } // End showTheList
    } // End showTheList


    private static final void saveTheList( Vector saveVect) { 
  
    DataOutputStream writeTo    = null;
    Way6C            currentOne = null;

    try { 
       writeTo = new DataOutputStream( 
                    new FileOutputStream( "way6.dat"));

       // CODE TO WRITE THE CONTENTS OF THE ARRAY TO THE 
       // FILE NEEDED HERE !!!!!
    } catch (IOException exception) { 
       System.err.println( "\n\n!!! ERROR WRITING FILE !!!!");
       System.exit( -1);
    } // End try/catch
    } // End saveTheList


    private static final Vector loadTheList() { 
  
    DataInputStream readFrom     = null;
    Way6C           fromFile     = null;
    Vector          tempVect     = null;
    boolean         fileFinished = false; 

       try { 
          readFrom = new DataInputStream( 
                       new FileInputStream( "way6c.dat"));
          tempVect = new Vector();
          while ( !fileFinished) { 
             try { 
                fromFile = new Way6C();
                fromFile.readDetails( readFrom);
                tempVect.addElement( fromFile);
             } catch (EOFException exception) { 
                fileFinished = true; 
             } // End try/catch.
           } // End while. 
           readFrom.close();
       } catch (IOException exception) { 
          System.err.println( "\n\n!!! ERROR READING FILE !!!!");
          System.exit( -1);
       } // End try/catch
       return tempVect;
    } // End loadTheList

} // End Way6CDemo.
