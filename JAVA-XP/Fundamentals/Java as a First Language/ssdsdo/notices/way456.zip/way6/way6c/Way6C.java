// Way6B.java
//
// A simple class containing several attributes, 
// a constructor, a setter rule and I/O methods. 
//
// A collection of these will be written to and 
// then read from a file. 
//
// Assumes BasicMenu & other terminal i/o classes 
// are available. 
//
// Fintan Culwin, V0.1, May 2000

package way6c;

import java.io.*;

public class Way6C extends Object { 


private int     anInt    = 0; 
private boolean isOdd    = false;
private String  aString  = "";

   public Way6C() { 
      this( 0); 
   } // End Way6C default constructor. 

   public Way6C( int conInt) { 
      super();
      anInt   = conInt;     
      isOdd   = (anInt % 2) == 1;

      if ( isOdd) { 
         aString = "The number " + 
                   new Integer( anInt).toString() + 
                   " is odd";
      } else { 
         aString = "The Way6C constructor is faulty!!";
      } // End if. 
   } // End Way6C


   public void writeDetails( DataOutputStream theStream) 
                               throws java.io.IOException {
      theStream.writeInt( this.anInt);
      theStream.writeBoolean( this.isOdd);
   } // End writeDetails.   

   public void readDetails( DataInputStream theStream)
                               throws java.io.IOException {
      this.anInt   = theStream.readInt();
      this.isOdd   = theStream.readBoolean();
   } // End readDetails.

   public String toString() { 
      return  anInt + " " + isOdd + "\n" + aString + "\n"; 
   } // End toString.

} // End Class Way6C.
