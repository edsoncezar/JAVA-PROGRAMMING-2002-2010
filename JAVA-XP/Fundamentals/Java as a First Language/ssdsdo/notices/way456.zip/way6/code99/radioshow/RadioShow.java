// THIRD ITERATION!!!
//
// Filename RadioShow.java.
// Providing a demonstration of the initial Interactive Menu.
//
// Written for SDO 1999/2000 waypoint 4
// Fintan Culwin, v 0.1, jan 2000

package radioshow; 

import menus.BasicMenu;
import radioslot.*;
import playtime.*;
import ValidatedInput;
import java.util.Vector;
import java.io.*;

public class RadioShow extends Object  { 

   public static void main( String args[]) { 

   final char LIST_SLOTS   = 'A';
   final char ADD_END      = 'B';
   final char RESEQUENCE   = 'C';
   final char REMOVE       = 'D';
   final char CLEAR        = 'E';
   final char SAVE         = 'F';
   final char LOAD         = 'G';
   final char EXIT_CHOICE  = 'H';

   final String menuOptions[] =  { 
                          "List Radio Slot Items",  
                          "Add Radio Slot at End",   
                          "Resequence the Slots",
                          "Remove a Slot", 
                          "Clear all slots", 
                          "Save the show", 
                          "Load the show",                       
                          "Exit"
                           };

   final BasicMenu mainMenu = new BasicMenu( 
                                      "\n\tRadio Show Main Menu",
                                       menuOptions,
                                       "");
   char menuChoice = ' ';


   Vector theList = new Vector();
                             
frugTheList( theList);

      System.out.println( "\n\t\t Radio Show (Fifth Iteration)");
      
      while ( menuChoice != EXIT_CHOICE) { 
         menuChoice = mainMenu.offerMenuAsChar();
         switch ( menuChoice) { 

         case LIST_SLOTS : 
               listTheSlots( theList);
               break;

         case ADD_END : 
               addAtEnd( theList);
               break;

         case RESEQUENCE: 
               resequenceSlots( theList);
               break;

         case REMOVE: 
               removeSlot( theList);
               break;

         case CLEAR: 
               clearAllSlots( theList);
               break;

         case SAVE: 
               saveShow( theList);
               break;

         case LOAD: 
               loadShow( theList);
               break;


         } // End switch.
      } // End while.

      System.out.println( "\n\nEnd of Radio Show (Fifth Iteration)");    
   } // End main
   

   private static void listTheSlots( Vector listToShow) { 
      if ( listToShow.isEmpty()) { 
         System.out.println( "\n\tThe list is empty!");
      } else { 
         for( int index = 0; index < listToShow.size(); index++) { 
            System.out.println( "Radio Slot No. " + (index +1));
            System.out.println( listToShow.elementAt( index) + "\n");
         } // End for.
      } // End showThePumps.
   } // End listTheSlots.


   private static void addAtEnd( Vector listToAddTo) {
   RadioSlot toBeAdded = null;
      toBeAdded = RadioSlotTerminalInput.readRadioSlot( "");
      listToAddTo.add( toBeAdded);
   } // End addAtEnd.


   private static void resequenceSlots( Vector listToResequence) {
   RadioSlot currentSlot      = null;
   PlayTime  currentStartTime = new PlayTime( 0);

      if ( listToResequence.isEmpty()) { 
         System.out.println( "\n\tThe list is empty!");
      } else { 
         for ( int index = 0; index < listToResequence.size(); index++) { 
            currentSlot = (RadioSlot) listToResequence.elementAt( index); 
            currentSlot.setSlotStartTime( currentStartTime); 
            currentStartTime = currentStartTime.addTime( 
                                       currentSlot.getSlotDuration());
         } // End for.
      } // End if.
   } // End resequenceSlots.


   private static void removeSlot( Vector listToRemoveFrom) {

   int slotToRemove = -1; 

      if ( listToRemoveFrom.isEmpty()) { 
         System.out.println( "\n\tThe list is empty!");
      } else { 
         slotToRemove = (int) ValidatedInput.readLong( 
                               "Please enter the slot number to delete",
                               1, listToRemoveFrom.size());
         listToRemoveFrom.remove( --slotToRemove);
      } // End if. 
   } // End removeSlot


   private static void clearAllSlots( Vector listToClear) { 
      listToClear.clear();
   } // End clearAllSlots


   private static void saveShow( Vector toSave) { 

   DataOutputStream saveToHere = null;
   RadioSlot       currentSlot  = null;

      try {          
          saveToHere = new DataOutputStream(
                          new FileOutputStream( "show.dat"));
          for ( int index = 0; index < toSave.size(); index++) { 
            currentSlot = (RadioSlot) toSave.elementAt( index); 
            currentSlot.writeSlot( saveToHere);
          } // End for.
          saveToHere.close();
      } catch ( IOException exception) { 
         System.out.println( "\nERROR writing the file - abending!"); 
         System.exit( -1);
      } // End try/catch
   }  // End saveShow


   private static void loadShow( Vector toLoad) { 

   Vector          loadInto        = null;
   DataInputStream loadFromHere    = null;
   RadioSlot       currentSlot     = null;
   boolean         fileNotFinished = false; 

      try { 
         loadFromHere = new DataInputStream(
                            new FileInputStream( "show.dat"));
         loadInto = new Vector();
         fileNotFinished = true;

         while ( fileNotFinished) {
            try { 
               currentSlot = new RadioSlot();
               currentSlot.readSlot( loadFromHere);
               loadInto.addElement( currentSlot);
            } catch ( EOFException exception) { 
               System.out.println( "\n" + loadInto.size() + 
                                   " transactions read from file."); 
               fileNotFinished = false;
            } // End try/catch 
         } // End while. 

         clearAllSlots( toLoad); 
         for ( int index = 0; index < loadInto.size(); index++) { 
            toLoad.addElement( loadInto.elementAt( index));
          } // End for.

      } catch ( IOException exception) { 
         System.out.println( "\nERROR writing the file - abending!"); 
         System.exit( -1);
      } // End try/catch
   } // End  loadShow




private static void frugTheList( Vector toFrug) { 

PlayTime  frugTime = new PlayTime( 900);
RadioSlot frug = null;

          frugTime = new PlayTime( 900);
          frug = new RadioSlot( RadioSlot.ADVERT, "one", frugTime);
          toFrug.add( frug);
          
          frugTime = new PlayTime( 1200);
          frug = new RadioSlot( RadioSlot.MUSIC, "two", frugTime);
          toFrug.add( frug);

          frugTime = new PlayTime( 1500);
          frug = new RadioSlot( RadioSlot.NEWS, "three", frugTime);
          toFrug.add( frug);

          frugTime = new PlayTime( 500);
          frug = new RadioSlot( RadioSlot.ADVERT, "four", frugTime);
          toFrug.add( frug);

          frugTime = new PlayTime( 1800);
          frug = new RadioSlot( RadioSlot.WEATHER, "five", frugTime);
          toFrug.add( frug);

          frugTime = new PlayTime( 2100);
          frug = new RadioSlot( RadioSlot.MUSIC, "six", frugTime);
          toFrug.add( frug);

          frugTime = new PlayTime( 2400);
          frug = new RadioSlot( RadioSlot.MUSIC, "seven", frugTime);
          toFrug.add( frug);
} // End frugTheList

} // End RadioShow.

