// Filename FuelPumpInputDemonstration.java.
// Interacts with the user to obtain details of a FuelPump
// which is then constructed and output. 
//
// Written for Waypoint 4 1997/8
// Fintan Culwin, v0.1, Jan 1998.

import Pumps.FuelPump;
import ValidatedInput;
import ManifestInput;

public class FuelPumpInputDemonstration { 


private static final String dispensing[] = { "litres", "gallons"};

private static final String fuels[] = { "unknown", "unleaded", "leaded", "diesel" };


   public static void main( String argv[]) {

   ManifestInput unitInput = new ManifestInput( dispensing);
   ManifestInput fuelInput = new ManifestInput( fuels);

   int    dispensingIn;
   int    dispensingFuel;
   double dispensingPrice;

   FuelPump demoPump;

      System.out.println( "\t Fuel Pump Input Demonstration \n\n");

      dispensingFuel  = fuelInput.readManifest( "Please input the type of fuel ");
      dispensingIn    = unitInput.readManifest( "Please input the units to dispense in ");
      dispensingPrice = ValidatedInput.readDouble( "Please input the price of one " + 
                                                   dispensing[ dispensingIn] + " of " + 
                                                   fuels[ dispensingFuel] + " ", 
                                                   0.0, 100.0);
      
      demoPump = new FuelPump( dispensing[ dispensingIn], 
                               dispensingPrice,
                               dispensingFuel);

      System.out.println( "\nThe details of the pump are \n" + 
                          demoPump);

      System.out.println( "\n\nEnd of Fuel Pump Input Demonstration");

   } // End main.
} // End class FuelPumpInputDemonstration.
