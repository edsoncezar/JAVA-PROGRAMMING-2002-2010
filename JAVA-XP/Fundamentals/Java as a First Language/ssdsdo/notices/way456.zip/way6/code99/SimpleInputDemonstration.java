// Filename SimpleInputDemonstration.java.
// Demonstration harness for the SimpleInput class.
//
// Produced for JFL book Chapter 9.
// Fintan Culwin, v0.1, January 1997.
// This version January 1999.

import SimpleInput;

public class SimpleInputDemonstration { 


   public static void main( String argv[]) {

   SimpleInput  theKeyboard = new SimpleInput();
   long         demoLong;
   int          demoInt;
   double       demoDouble;
   
      System.out.println( "\t Simple Input Demonstration \n");
      
      System.out.println( "Demonstrating getLong ...");
      System.out.print( "Please enter an integer value ");
      try { 
         demoLong = theKeyboard.readLong();
         System.out.println( "You input " + demoLong + ".");
      } catch ( java.lang.Exception exception){ 
         System.out.println( exception);
      } // End try/ catch.


      System.out.println( "Demonstrating getInt ...");
      System.out.println( "Please enter an integer value between " +
                          Integer.MIN_VALUE + " and "              + 
                          Integer.MAX_VALUE + ".");
      System.out.print( "Please enter your value ");                    
      try { 
         demoInt = theKeyboard.readInt();
         System.out.println( "You input " + demoInt + ".");
      } catch ( java.lang.Exception exception){ 
         String errorString = exception.getMessage();
         if ( errorString.indexOf( "too large") != -1) { 
            System.out.println( "That value is too large.");         
         } else if ( errorString.indexOf( "too small") != -1) {
            System.out.println( "That value is too small.");         
         } else { 
            System.out.println( "Unknown error (" + exception + ").");         
         } // End if.
      } // End try/ catch.




      
      System.out.println( "\n\nDemonstrating getDouble ...");
      System.out.print( "Please enter an floating point value ");
      try { 
         demoDouble = theKeyboard.readDouble();
         System.out.println( "You input " + demoDouble + ".");
      } catch ( java.lang.Exception exception){ 
         System.out.println( exception);
      } // End try/ catch.      


   } // End main.


} // End SimpleInputDemonstration.
