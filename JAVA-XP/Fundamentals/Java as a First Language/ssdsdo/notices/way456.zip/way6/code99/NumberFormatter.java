// Filename OutputFormatter.java.
// Provides faciltiies for the foamtting of numbers.
//
// Produced for JFL book Chapter 9.
// Fintan Culwin, v0.1, January 1997.

import OutputFormatException;

public class  OutputFormatter { 

private static final char SPACE = ' ';
private static final char ZERO  = '0';

   public String formatLong( long    aNumber,
                             int     toWidth,
                             boolean withZeros,
                             int     inBase) { 
   
   StringBuffer formatString = new StringBuffer( String.valueOf( aNumber ));
   char         padding;
   
      if ( withZeros) { 
         padding = ZERO;
      } else { 
         padding = SPACE;
      } // End if.                                
       
      formatString = new StringBuffer( Long.toString( aNumber, inBase));
    
      return formatString.toString();                          
   } // End formatString.                             



} // End NumberFormatter.
