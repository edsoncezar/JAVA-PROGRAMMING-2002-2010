// Way6D.java
//
// A simple class containing several attributes, 
// a constructor, a setter rule and I/O methods. 
//
// A collection of these will be written to and 
// then read from a file. 
//
// Assumes BasicMenu & other terminal i/o classes 
// are available. 
//
// Fintan Culwin, V0.1, May 2000

package way6d;

import java.io.*;

public class Way6D extends Object { 


private int     anInt    = 0; 
private String  aName    = ""; 
private String  aString  = "??????????????";

   public Way6D() { 
      super(); 
   } // End Way6C default constructor. 

   public Way6D( String conName, int conInt) { 
      super();
      anInt   = conInt; 
      aName   = conName;    

      { // Start of inner constructor block
      StringBuffer temp = new StringBuffer( aName);
      while ( temp.length() < 8) { 
          temp.append( " ");
      } // End while.

      for ( int index=0; index <= anInt; index++) { 
         temp.append( index + " ");
      } // End if. 
      aString = temp.toString();
      } // End of inner constructor block. 
   } // End Way6D


   public void writeDetails( DataOutputStream theStream) 
                               throws java.io.IOException {
      theStream.writeInt( this.anInt);
      theStream.writeUTF( this.aName);
   } // End writeDetails.   

   public void readDetails( DataInputStream theStream)
                               throws java.io.IOException {
      this.anInt   = theStream.readInt();
      this.aName   = theStream.readUTF();
   } // End readDetails.

   public String toString() { 
      return  aString; 
   } // End toString.

} // End Class Way6D.
