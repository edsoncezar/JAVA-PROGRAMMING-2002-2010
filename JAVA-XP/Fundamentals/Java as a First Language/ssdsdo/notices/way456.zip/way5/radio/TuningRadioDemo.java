// Filename radio/TuningRadioDemo.java.
//
// Demonstration of the TuningRadio class. 
//
// Produced for ssd way 3 sem 2 99/00
//
// Version 0.1 Fintan Feb 2000
// Revised for way 7 July 2000


package radio;

public class TuningRadioDemo extends Object { 

   public static void main( String[] args) { 

   TuningRadio aRadio = null;

      System.out.println( "\nTuning Radio Demonstration");

      System.out.println( "\nConstructing a Radio & switching on .... ");
      aRadio = new TuningRadio();
      aRadio.switchOn();      

      System.out.println( "\nShowing its state ... ");
      System.out.println( aRadio);

      System.out.println( "\nSetting Volume & showing again ... ");
      aRadio.louder(); aRadio.louder();
      System.out.println( aRadio);


      System.out.println( "\nTuning down & showing again ... ");
      aRadio.tuneDown(); aRadio.tuneDown();
      System.out.println( aRadio);

      System.out.println( "\nDeliberately throwing an execption  ... ");
      while( true) { 
         aRadio.tuneDown(); 
      } // End while. 

      //System.out.println( "\n\nEnd of Tuning Radio Demonstration");
 
   } // End main. 

} // End TuningRadioDemo
