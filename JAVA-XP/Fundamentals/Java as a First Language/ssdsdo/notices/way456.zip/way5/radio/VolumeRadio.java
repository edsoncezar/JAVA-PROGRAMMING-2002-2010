// Filename radio/VolumeRadio.java.
//
// Adds volume attribute to a SimpleRadio.
//
// Produced for ssd way 3 sem 2 99/00
//
// Version 0.1 Fintan Feb 2000
// Revised for way 7 July 2000

package radio;

public class VolumeRadio extends SimpleRadio { 

private final static int MINIMUM_VOLUME = 0;
private final static int MAXIMUM_VOLUME = 10;

private int volume = MINIMUM_VOLUME;

   public VolumeRadio() { 
      super();
      volume = MINIMUM_VOLUME;
   } // End VolumeRadio default constructor.

   public int getVolume() { 
      return volume;
   } // End getVolume

   public void louder() { 
      this.setVolume( this.getVolume() + 1);
   } // End louder

   public void quieter() { 
      this.setVolume( this.getVolume() - 1);
   } // End quieter

   public void mute() { 
      this.setVolume( MINIMUM_VOLUME);
   } // End mute

   public boolean isSilent() { 
      return this.getVolume() == MINIMUM_VOLUME;
   } // End isSilent

   private void setVolume( int newVolume) { 
      if ( (newVolume >= MINIMUM_VOLUME) &&
           (newVolume <= MAXIMUM_VOLUME) ){ 
         volume = newVolume;
      } else { 
         if ( newVolume < MINIMUM_VOLUME) { 
            throw new RadioException( RadioException.VOLUME_LOW);
         } else { 
            throw new RadioException( RadioException.VOLUME_HIGH);
         } // End if. 
      } // End if. 
   } // End setVolume

   public String toString() { 
      if ( this.isSwitchedOn()) { 
         if ( this.isSilent()) { 
            return super.toString() + 
                   "\nThe speaker is muted";
         } else { 
            return super.toString() + 
                   "\nThe volume is " + this.getVolume();
         } // End if. 
      } else { 
         return super.toString();
      } // End if. 
   } // End toString   

} // End VolumeRadio
