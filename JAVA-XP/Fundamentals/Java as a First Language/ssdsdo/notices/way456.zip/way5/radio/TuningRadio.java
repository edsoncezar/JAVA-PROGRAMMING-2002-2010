// Filename radio/TuningRadio.java.
//
// Adds Tuning attribute to a VolumeRadio.
//
// Produced for ssd way 3 sem 2 99/00
//
// Version 0.1 Fintan Feb 2000
// Revised for way 7 July 2000


package radio;

public class TuningRadio extends VolumeRadio { 

private final static double MINIMUM_FREQUENCY = 88.0;
private final static double MAXIMUM_FREQUENCY = 109.0;

private final static double DEFAULT_FREQUENCY = 93.5;

private double frequency = MINIMUM_FREQUENCY;

   public TuningRadio() { 
      super();
      frequency = DEFAULT_FREQUENCY;
   } // End TuningRadio default constructor.

   public double getFrequency() { 
      return frequency;
   } // End getFrequency

   public void tuneUp() { 
      this.setFrequency( this.getFrequency() + 0.1);
   } // End tuneUp

   public void tuneDown() { 
      this.setFrequency( this.getFrequency() - 0.1);
   } // End tuneDown

   private void setFrequency( double newFrequency) { 
      if ( (newFrequency >= MINIMUM_FREQUENCY) &&
           (newFrequency <= MAXIMUM_FREQUENCY) ){ 
         frequency = newFrequency;
         frequency = ((double) Math.round( frequency * 10) /10.0);
      } else { 
         if (newFrequency < MINIMUM_FREQUENCY) { 
            throw new RadioException( RadioException.FREQUENCY_LOW); 
         } else { 
            throw new RadioException( RadioException.FREQUENCY_HIGH); 
         } // End if. 
      } // End if. 
   } // End setFrequency

   public String toString() { 
      if ( this.isSwitchedOn()) { 
         if ( this.isSilent()) { 
            return super.toString();
         } else { 
            return super.toString() + 
                   "\tThe Frequency is " + this.getFrequency();
         } // End if. 
      } else { 
         return super.toString();
      } // End if. 
   } // End toString   

} // End TuningRadio
