// Filename centralheating/TimedBoilerDemo.java.
//
// Demonstration of the TimedBoiler class. 
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class TimedBoilerDemo extends Object { 

   public static void main( String[] args) { 

   TimedBoiler aBoiler = null;

      System.out.println( "\nTimed Boiler Demonstration");

      System.out.println( "\nConstructing a boiler .... ");
      aBoiler = new TimedBoiler();     

      System.out.println( "\nConstructed toString should report it as switched off .... ");
      System.out.println( aBoiler);
/*
      System.out.println( "\nWarming twice, the temperature should be 22");
      aBoiler.warmer(); 
      aBoiler.warmer(); 
      System.out.println( "The temperature is " + aBoiler.getTemperature());      

      System.out.println( "\nSetting the temperature to 12");
      aBoiler.setTemperature( 12); 

      System.out.println( "\nDemonstrating toString() " + 
                          "it should show it is switched on \n" + 
                          "with a temperature of 12 ...\n");
      System.out.println( aBoiler);

      System.out.println( "\nEnd of Timed Boiler Demonstration");
*/ 
   } // End main. 

} // End TimedBoilerDemo
