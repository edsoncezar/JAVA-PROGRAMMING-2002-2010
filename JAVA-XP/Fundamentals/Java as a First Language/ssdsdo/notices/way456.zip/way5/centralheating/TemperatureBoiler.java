// Filename centralheating/TemperatureBoiler.java.
//
// A GasBoiler with an onn/offf control.
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class TemperatureBoiler extends GasBoiler { 

// Required central heating temperature in centigrade.
private int temperature = 20;


   public TemperatureBoiler() { 
      super();
      temperature = 20;
   } // End TemperatureBoiler

   
   public void setTemperature( int newTemperature) { 
      temperature = newTemperature;
   } // End setTemperature

   public int getTemperature() { 
      return temperature;
   } // End setTemperature

   public void warmer() { 
      temperature++;
   } // End warmer.

   public void cooler() { 
      temperature--;
   } // End cooler. 

      public String toString() { 
      if ( this.isSwitchedOn()) { 
         return super.toString() + 
                "\nThe temperature is " + 
                this.getTemperature() + ".";
      } else { 
         return super.toString();
      } // End if. 
   } // End toString

} // End class TemperatureBoiler
