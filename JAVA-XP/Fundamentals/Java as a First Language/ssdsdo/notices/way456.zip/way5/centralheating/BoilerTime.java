// Filename centralheating/BoilerTime.java.
//
// Provides the time object for a TimedBoiler.
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class BoilerTime extends Object { 

private final static int MINS_PER_HOUR = 60;

private int minsSinceMidnight = 0;

   public BoilerTime() { 
      this( 0, 0);
   } // End BoilerTime default constructor.

   public BoilerTime( int hoursToSet, 
                      int minsToSet) { 
      super();
      minsSinceMidnight = hoursToSet * MINS_PER_HOUR + 
                          minsToSet;
   } // End BoilerTime constructor.

   public int getHours() { 
      return minsSinceMidnight / MINS_PER_HOUR;
   } // End getHours

   public int getMins() { 
      return minsSinceMidnight % MINS_PER_HOUR;
   } // End getMins

   public boolean isLaterThan( BoilerTime anotherTime) { 
      return this.minsSinceMidnight >= anotherTime.minsSinceMidnight;
   } // End isLaterThan  

   public boolean isEarlierThan( BoilerTime anotherTime) { 
      return this.minsSinceMidnight <= anotherTime.minsSinceMidnight;
   } // End isEarlierThan  

   public String toString() { 
      return this.getHours() + ":" + this.getMins();
   } // End toString

} // End BoilerTime
