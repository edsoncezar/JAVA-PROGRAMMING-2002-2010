// Filename centralheating/GasBoiler.java.
//
// A GasBoiler with an onn/offf control.
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class GasBoiler extends Object { 

private boolean onOrOff = false; 

   public GasBoiler() { 
      super(); 
      onOrOff = false; // Switched off by default. 
   } // End GasBoiler

   
   public void switchOn() { 
      onOrOff = true;
   } // End switchOn

   public void switchOff() { 
      onOrOff = true;
   } // End switchOff

   public boolean isSwitchedOn() { 
      return onOrOff;
   } // End isSwitchedOn

   public boolean isSwitchedOff() { 
      return ! onOrOff;
   } // End isSwitchedOff

   public String toString() { 
      if ( this.isSwitchedOn()) { 
         return "The boiler is switched on.";
      } else { 
         return "The boiler is switched off.";
      } // End if. 
   } // End toString

} // End class GasBoiler
