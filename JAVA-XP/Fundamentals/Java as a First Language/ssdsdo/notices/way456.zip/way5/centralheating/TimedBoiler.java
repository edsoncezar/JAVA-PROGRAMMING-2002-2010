// Filename centralheating/TimedBoiler.java.
//
// A Boiler with timing control.
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class TimedBoiler extends TemperatureBoiler { 

// Required central heating temperature in centigrade.
private BoilerTime startTime = null;
private BoilerTime endTime   = null;


   public TimedBoiler() { 
      super();
      this.set24HourOperation();
   } // End TimedBoiler


   public boolean is24HourOperation() { 
      return (startTime.getHours() == 0) &&
             (startTime.getMins()  == 0) &&
             (endTime.getHours()   == 24) &&
             (endTime.getMins()    == 0);
   } // End is24HourOperation.

   public void set24HourOperation() { 
      startTime = new BoilerTime( 0, 0);
      endTime   = new BoilerTime( 24, 0);
   } // End set24HourOperation.


   public BoilerTime getStartTime() { 
      return startTime; 
   } // End getStartTime.

   public BoilerTime getEndTime() { 
      return endTime; 
   } // End getEndTime.
   

   public void setStartTime( BoilerTime newStart) { 
      if ( newStart.isLaterThan( this.getEndTime())) { 
         throw new RuntimeException( 
                    "Start time later than or equal to End Time!");
      } else { 
         startTime = newStart; 
      } // End if. 
   } // End setStartTime.


   public void setEndTime( BoilerTime newEnd) { 
      if ( newEnd.isEarlierThan( this.getStartTime())) { 
         throw new RuntimeException( 
                    "End time earlier than or equal to Start Time!");
      } else { 
         endTime = newEnd; 
      } // End if. 
   } // End setEndTime.


   public String toString() { 
      if ( this.isSwitchedOff()) { 
         return super.toString();
      } else { 
         if ( this.is24HourOperation()) { 
            return super.toString() + 
                   "\nSet to 24 hour operation.";
         } else { 
            return super.toString() + 
                   "\nStart " + this.getStartTime().toString() + 
                   " End "    +  this.getEndTime().toString()  + ".";           
         } // End if. 
      } // End if. 
   } // End toString


} // End class TimedBoiler
