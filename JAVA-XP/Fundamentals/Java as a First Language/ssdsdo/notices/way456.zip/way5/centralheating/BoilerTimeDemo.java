// Filename centralheating/BoilerTimeDemo.java.
//
// Demonstration of the BoilerTime class. 
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class BoilerTimeDemo extends Object { 

   public static void main( String[] args) { 

   BoilerTime aTime          = new BoilerTime( 13, 42);
   BoilerTime anEarlierTime  = new BoilerTime( 13, 41);
   BoilerTime aLaterTime     = new BoilerTime( 13, 43);

      System.out.println( "\nBoiler Time Demonstration");

      System.out.println( "\nThree instances Constructed, showing ... \n");
      System.out.println( "aTime         is " + aTime);
      System.out.println( "anEarlierTime is " + anEarlierTime);
      System.out.println( "aLaterTime    is " + aLaterTime);

      System.out.println( "\nanEarlierTime should be earlier than aTime ... ");
      if ( anEarlierTime.isEarlierThan( aTime)) { 
         System.out.println( "CORRECT it is!!");
      } else { 
         System.out.println( "ERROR it isn't!!");
      } // End if. 

      System.out.println( "\naLaterTime should be later than aTime ... ");
      if ( aLaterTime.isLaterThan( aTime)) { 
         System.out.println( "CORRECT it is!!");
      } else { 
         System.out.println( "ERROR it isn't!!");
      } // End if. 

      System.out.println( "\nEnd of Boiler Time Demonstration"); 
   } // End main. 
} // End BoilerTimeDemo
