// Filename centralheating/GasBoilerDemo.java.
//
// Demonstration of the GasBoiler class. 
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class GasBoilerDemo extends Object { 

   public static void main( String[] args) { 

   GasBoiler aBoiler = null;

      System.out.println( "\nGas Boiler Demonstration");

      System.out.println( "\nConstructing a boiler .... ");
      aBoiler = new GasBoiler();

      System.out.println( "\nConstructed it should be off .... ");
      if ( aBoiler.isSwitchedOff()) { 
         System.out.println( "Yes it is!");
      } else { 
         System.out.println( "ERROR - no it isn't!!");
      } // End if. 

      System.out.println( "\nSwitching on  .... ");
      aBoiler.switchOn();

      System.out.println( "\nDemonstrating toString() " + 
                          "it should show it is switched on ...\n");
      System.out.println( aBoiler);

      System.out.println( "\nEnd of Gas Boiler Demonstration");
 
   } // End main. 

} // End GasBoilerDemo
