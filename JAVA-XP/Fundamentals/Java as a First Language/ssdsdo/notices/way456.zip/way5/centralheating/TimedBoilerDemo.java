// Filename centralheating/TimedBoilerDemo.java.
//
// Demonstration of the TimedBoiler class. 
//
// Produced for ssd way 3 sem 1 99/00
//
// Version 0.1 Fintan Nov 1999


package centralheating;

public class TimedBoilerDemo extends Object { 

   public static void main( String[] args) { 

   TimedBoiler aBoiler = null;
   BoilerTime  tenThirty     = new BoilerTime( 10, 30);
   BoilerTime  elevenThirty  = new BoilerTime( 11, 30);

      System.out.println( "\nTimed Boiler Demonstration");

      System.out.println( "\nConstructing a boiler .... ");
      aBoiler = new TimedBoiler();     

      System.out.println( "\nConstructed toString should report it as switched off .... ");
      System.out.println( aBoiler);

      System.out.println( "\nSwitching on and showing again .... ");
      aBoiler.switchOn();
      System.out.println( aBoiler);

      System.out.println( "\nSetting Start & End time and showing again .... ");      
      aBoiler.setStartTime( tenThirty);
      aBoiler.setEndTime(   elevenThirty);
      System.out.println( aBoiler);

      System.out.println( "\nSetting an invalid start time\n" + 
                          "Which should throw an execption!");    
      try { 
         aBoiler.setStartTime( elevenThirty);
         System.out.println( "\nERROR! This message should never appear!");
      } catch ( RuntimeException exception) { 
         System.out.println( "\nCORRECT! The exception was thrown!");
      } // End try/catch.

      System.out.println( "\nSetting 24 hour and showing again .... ");      
      aBoiler.set24HourOperation();
      System.out.println( aBoiler);

      System.out.println( "\nwarming and showing again .... ");       
      aBoiler.warmer(); aBoiler.warmer(); aBoiler.warmer();
      System.out.println( aBoiler);

      System.out.println( "\nEnd of Timed Boiler Demonstration");

   } // End main. 

} // End TimedBoilerDemo
