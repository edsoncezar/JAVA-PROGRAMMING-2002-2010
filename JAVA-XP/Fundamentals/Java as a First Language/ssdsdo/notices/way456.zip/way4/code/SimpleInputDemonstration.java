// Filename SimpleInputDemonstration.java.
// Demonstration harness for the SimpleInput class.
//
// Produced for JFL book Chapter 9.
// Fintan Culwin, v0.1, January 1997.
// This version January 1999.
//
// This can only be used if the SimpleInput class 
// is changed to be non-abstract!!!!!!!!

import SimpleInput;

public class SimpleInputDemonstration { 


   public static void main( String argv[]) {

   SimpleInput  theKeyboard = new SimpleInput();
   long         demoLong;
   int          demoInt;
   double       demoDouble;
   
      System.out.println( "\t Simple Input Demonstration \n");
      
      System.out.println( "Demonstrating getLong ...");
      System.out.print( "Please enter an integer value ");
      try { 
         demoLong = theKeyboard.getLong();
         System.out.println( "You input " + demoLong + ".");
      } catch ( java.lang.Exception exception){ 
         System.out.println( exception);
      } // End try/ catch.

      
      System.out.println( "\n\nDemonstrating getDouble ...");
      System.out.print( "Please enter an floating point value ");
      try { 
         demoDouble = theKeyboard.getDouble();
         System.out.println( "You input " + demoDouble + ".");
      } catch ( java.lang.Exception exception){ 
         System.out.println( exception);
      } // End try/ catch.      


   } // End main.


} // End SimpleInputDemonstration.
