// Filename playtime\BasicTimeDemonstration.java
//
// Initial demo of the basicTime class 
//
// Produced for waypoint 2 99/00.
//
// Fintan Culwin, v0.1, sept 99.

package playtime;

public class PlayTimeDemonstration extends Object { 

   public static void main( String[] args) { 

   PlayTime startTime = null;
   PlayTime endTime   = null;
   PlayTime timeTaken = null;
  

      System.out.println( "\n\nPlay Time Demonstration\n\n");

      System.out.println( "This demonstration will construct a start time" + 
                          "\nrepresenting 2 min 15.9 seconds"); 
      System.out.println( "And an end time of 3 min 16.0 seconds"); 

      System.out.println( "\nConstructing ... \n");
      startTime = new PlayTime( 1359);
      endTime   = new PlayTime( 1960);      
      

      System.out.println( "... constructed showing ..."); 
      System.out.println( "Start time is " + startTime);
      System.out.println( "End   time is " + endTime);
      
      System.out.println( "\nThe time between start and end should be 1 min 00.1 seconds");        
      timeTaken = endTime.timeBetween( startTime);
      System.out.println( "The time between is ... " + timeTaken); 

      System.out.println( "\n??Are any more demonstrations needed???");

   } // End main. 

} // End class PlayTimeDemonstration.


