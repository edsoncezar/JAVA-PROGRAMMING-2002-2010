// Filename DangerousWriter.java.
// Providing class to read the dangerous attributes. 
//
// Written for JFL book Chapter 8 see text.
// Fintan Culwin, v0.1, January 1997.
// This version for sdo lecture March 2000

public class DangerousWriter extends Thread { 
 
Dangerous writeThis = null;
 
    public DangerousWriter( Dangerous toWrite) { 
        writeThis = toWrite; 
    } // End DangerousWriter Constructor.
  
    public void run() {
    int index = 0;
       while ( true) { 
          writeThis.update( index++);
       } // End while.   
    } // End run.
 
} // End DangerousWriter. 
