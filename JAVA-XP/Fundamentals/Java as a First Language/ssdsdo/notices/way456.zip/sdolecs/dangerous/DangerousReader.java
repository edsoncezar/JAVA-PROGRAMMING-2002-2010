// Filename DangerousReader.java.
// Providing class to read the dangerous attributes. 
//
// Written for JFL book Chapter 8 see text.
// Fintan Culwin, v0.1, January 1997.
// This version for sdo lecture March 2000

public class DangerousReader extends Thread { 
 
Dangerous readThis = null;
 
    public DangerousReader( Dangerous toRead) { 
       readThis = toRead; 
    } // End DangerousReader Constructor;
 
 
    public void run() {
    
    int firstAttribute;
    int secondAttribute;
    
        while ( true) { 
           firstAttribute  = readThis.getAnAttribute(); 
           secondAttribute = readThis.getAnotherAttribute();
           if ( firstAttribute != secondAttribute) { 
               System.out.println( "Danger proved ... "      + 
                                   firstAttribute  + " and " + 
                                   secondAttribute + ".");
           } // End if
        } // End while.   
    } // End run.
 
} // End DangerousReader.
