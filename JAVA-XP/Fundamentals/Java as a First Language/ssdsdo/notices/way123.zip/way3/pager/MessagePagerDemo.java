// Filename pager/MessagePagerDemo.java.
//
// Demonstration of the MessagePager class. 
//
// Produced for ssd way 3 sem 1 00/01
//
// Version 0.1 Fintan Sept 2000


package pager;

public class MessagePagerDemo extends Object { 

   public static void main( String[] args) { 

   MessagePager aPager = null;

      System.out.println( "\nMessage Pager Demonstration");

      System.out.println( "\nConstructing a default pager .... ");
      aPager = new MessagePager();

      System.out.println( "\nConstructed it should be off .... ");
      if ( aPager.isSwitchedOff()) { 
         System.out.println( "Yes it is!");
      } else { 
         System.out.println( "ERROR - no it isn't!!");
      } // End if. 

      

      System.out.println( "\nSwitching on  .... ");
      aPager.switchOn();

      System.out.println( "\nSetting a message ");
      aPager.setMessage( "This is just a test!");    

      System.out.println( "\nGetting and showing message . . . ");
      System.out.println( "The message is \n\n" + 
                          aPager.getMessage() + "\n\n");

      System.out.println( "\nClearing message . . . ");
      System.out.println( "\nhasMessage() should now be false . . .  ");
      if ( aPager.hasMessage()) { 
         System.out.println( "ERROR - it says that it still has a message!");
      } else { 
         System.out.println( "OK - it says that it has not!!");
      } // End if. 

      System.out.println( "\nDemonstrating toString() " );
      System.out.println( aPager);

      System.out.println( "\nEnd of Message Pager Demonstration");
 
   } // End main. 

} // End MessagePagerDemo
