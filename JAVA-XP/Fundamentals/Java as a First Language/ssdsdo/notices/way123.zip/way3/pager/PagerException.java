// Filename pager/PagerException.java.
//
// Specific exception class for pager hierarchy
//
// Produced for ssd way 3 sem 1 00/01
//
// Version 0.1 Fintan Sept 2000


package pager;

public class PagerException extends RuntimeException { 

public final static int UNKNOWN        = 0;
public final static int SWITCHED_OFF   = 1;
public final static int WRONG_STATUS   = 2;

private int reason = UNKNOWN;

   public PagerException() { 
      this( UNKNOWN);
   } // End RadioException.


   public PagerException( int theReason) { 
      super();
      reason = theReason;
   } // End RadioException.
   

   public String toString() { 

   String toReturn = null;

      switch( reason) { 

      case SWITCHED_OFF:
         toReturn = "The Pager is switched off";
         break;

      case WRONG_STATUS:
         toReturn = "Status must be Normal, Urgent or Vital.";
         break;

      default: 
         toReturn = "Unknown reason.";
         break;         
      } // End switch.
      return "Pager Exception - " + toReturn;
   } // End toString.

} // End PagerException
