// Filename pager/SimplePager.java.
//
// A pager with an on/off control.
//
// Produced for ssd way 3 sem 1 00/01
//
// Version 0.1 Fintan sept 2000


package pager;

public class SimplePager extends Object { 

private boolean onOrOff = false; 

   public SimplePager() { 
      super(); 
      onOrOff = false; // Switched off by default. 
   } // End SimplePager
   
   public void switchOn() { 
      onOrOff = true;
   } // End switchOn

   public void switchOff() { 
      onOrOff = false;
   } // End switchOff

   public boolean isSwitchedOn() { 
      return onOrOff;
   } // End isSwitchedOn

   public boolean isSwitchedOff() { 
      return ! onOrOff;
   } // End isSwitchedOff

   public String toString() { 
      if ( this.isSwitchedOn()) { 
         return "The pager is switched on.";
      } else { 
         return "The pager is switched off.";
      } // End if. 
   } // End toString

} // End class SimplePager
