// Filename pager/MessagePager.java.
//
// A pager with a message to show.
//
// Produced for ssd way 3 sem 1 00/01
//
// Version 0.1 Fintan sept 2000


package pager;

public class MessagePager extends SimplePager { 

private static final String DEFAULT_MESSAGE = 
                            "There is no message.";

private String message = null; 

   public MessagePager() { 
      super(); 
      message = new String("");
   } // End SimplePager
   
   public void setMessage( String newMessage) { 
      message = new String( newMessage);
   } // End setMessage

   public String getMessage() { 
      if ( this.isSwitchedOff()) { 
        return new String( "Switched off!"); 
      } else { 
        return new String( message);
      } // End getMessage
   } // End getMessage

   public void clearMessage() { 
      this.setMessage( "Deafult Message");
   } // End setMessage

   public boolean hasMessage() { 
      return ! message.equals( DEFAULT_MESSAGE);
   } // End isSwitchedOn


   public String toString() { 
      return super.toString() + 
             "\nA message pager!";
   } // End toString

} // End class MessagePager
