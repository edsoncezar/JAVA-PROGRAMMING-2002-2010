// Filename TemperatureConvertorDemonstration.java.
// Provides a main action to demonstrate TemperatureConvertor.
//
// Written for waypoint 1 section 7.
// Fintan Culwin, v 0.1, Sept 1997.

import TemperatureConvertor;

public class TemperatureConvertorDemonstration extends Object { 

   public static void main( String argv[]) { 

   TemperatureConvertor aTemperature;

      System.out.println( "\n\tTemperature Convertor Demonstration");
      System.out.println( "\nConstructing an instance with the value ");
      System.out.println( "273.0 Kelvin and showing it as Centigrade ");
      System.out.println( "(0.0) and as Farenheit (32.0)");
      
      aTemperature = new TemperatureConvertor( 273.0,
                                    TemperatureConvertor.KELVIN);

      System.out.println( "\nConstucted ...  showing values \n");

      System.out.print( "Kelvin     ...  "); 
      System.out.println( aTemperature.getValueInKelvin());
      System.out.print( "Centigrade ...  ");
      System.out.println( aTemperature.getValueInCentigrade());
      System.out.print( "Farenheit  ...  ");
      System.out.println( aTemperature.getValueInFarenheit());
      
      // More demonstrations required here ,,,,

      System.out.println( "\n\nEnd of Temperature Convertor Demonstration.");      

   } // end main.




} // End TemperatureConvertorDemonstration.
