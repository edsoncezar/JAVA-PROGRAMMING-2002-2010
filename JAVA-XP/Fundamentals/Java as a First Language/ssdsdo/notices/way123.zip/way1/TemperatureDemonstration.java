// Filename TemperatureDemonstration.java.
// Provides a main action to demonstrate the Temperature class.
//
// Written for waypoint 1 section 7.
// Fintan Culwin, v 0.1, Sept 1997.

import Temperature;

public class TemperatureDemonstration extends Object { 

   public static void main( String argv[]) { 

   Temperature aTemp;

      System.out.println( "\n\tTemperature Demonstration");
      System.out.println( "\nConstructing an instance with the value ");
      System.out.println( "273.0 Kelvin and showing it as Centigrade ");
      System.out.println( "(0.0) and as Fahrenheit (32.0)");
      
      aTemp = new Temperature( 98.4, Temperature.FAHRENHEIT);

      System.out.println( "\nConstructed ...  showing values \n");

      System.out.print( "Kelvin      ...  "); 
      System.out.println( aTemp.getValueInKelvin());
      System.out.print( "Centigrade  ...  ");
      System.out.println( aTemp.getValueInCentigrade());
      System.out.print( "Fahrenheit  ...  ");
      System.out.println( aTemp.getValueInFahrenheit());
      
      // More demonstrations required here ,,,,

      System.out.println( "\n\nEnd of Temperature Demonstration.");      
   } // end main.
} // End TemperatureDemonstration.
