// Filename Temperature.java.
// Provides a class whose instances contain a 
// temperature which can be requested in 
// Kelvin, Centigrade or Farenheit; supported by
// suitable manifest values.
//
// Written for waypoint 1 section 7.
// Fintan Culwin, v 0.1, Sept 1997.

public class Temperature extends Object { 

public final static int CENTIGRADE = 0;
public final static int FARENHEIT  = 1;
public final static int KELVIN     = 2;

private static final double CENTIGRADE_TO_KELVIN    = 273.0;
private static final double CENTIGRADE_TO_FARENHEIT = 1.80;
private static final double FARENHEIT_ZERO          = 32.0;

private double theValueInKelvin = 0.0;

   public Temperature( double theValue,
                       int    itsScale) { 
      if ( itsScale == CENTIGRADE) { 
         theValueInKelvin = theValue - CENTIGRADE_TO_KELVIN;
      } else if ( itsScale == FARENHEIT) { 
         theValueInKelvin = ((theValue - FARENHEIT_ZERO) / 
                                CENTIGRADE_TO_FARENHEIT) - 
                                   CENTIGRADE_TO_KELVIN;
      } else if ( itsScale == KELVIN) { 
          theValueInKelvin = theValue;
      } else { 
          throw new RuntimeException( "Attempt to construct a " +
                            "Temperature with an unknown scale.");
      } // End if.
   } // End TemperatureConvertor constructor.   


   public double getValueInCentigrade() { 
      return theValueInKelvin - CENTIGRADE_TO_KELVIN;
   } // End getValueInCentigrade.

   public double getValueInFarenheit() { 
      return (getValueInCentigrade() * CENTIGRADE_TO_FARENHEIT) + 
                                                FARENHEIT_ZERO;
   } // End getValueInFarenheit.   

   public double getValueInKelvin() { 
      return theValueInKelvin;
   } // End getValueInKelvin. 

} // End Temperature.
