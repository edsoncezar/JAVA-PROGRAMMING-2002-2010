// Filename MoreComplexCommandsClient.java
// Client program to output a list of the simple
// unix commands and thier names.
//
// Written for SSD waypoint 1 schedule.
// Fintan Culwin, v0.1, Sept 1997.
 
import MoreComplexCommands;
 
public class MoreComplexCommandsClient {
 
   public static void main( String[] args) {
 
      System.out.println( "\n\tMore Complex Unix Commands\n");
 
      System.out.println( MoreComplexCommands.getRmdirDetails());
      System.out.println( MoreComplexCommands.getMvDetails());
 
      System.out.println( "\nEnd of More Complex Unix Commands\n");
   } // End main.
} // End MoreComplexCommandsClient.