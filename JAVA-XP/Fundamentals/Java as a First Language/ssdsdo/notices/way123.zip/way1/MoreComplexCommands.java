// Filename MoreComplexCommands.java
// Class to supply a list of the simple unix
// commands and thier names.
//
// Written for SSD waypoint 1 schedule.
// Fintan Culwin, v0.1, Sept 1997.
 
public class MoreComplexCommands {
 
   public static String getRmdirDetails(){
      return "rmdir      -      " +
             "remove (an empty) directory.";
   } // End getRmdirDeatails;
 
   public static String getMvDetails(){
      return "mv         -      " +
             "move (rename) a file or directory.";
   } // End getmvDeatails;
} // End MoreComplexCommands