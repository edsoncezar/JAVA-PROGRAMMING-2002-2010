// Filename playtime\BasicTimeDemonstration.java
//
// Initial demo of the basicTime class 
//
// Produced for waypoint 2 99/00.
//
// Fintan Culwin, v0.1, sept 99.

package playtime;

public class PlayTimeDemonstration extends Object { 

   public static void main( String[] args) { 

   PlayTime startTime = null;
   PlayTime endTime   = null;
   PlayTime timeTaken = null;
  

      System.out.println( "\n\nPlay Time Demonstration\n\n");

      System.out.println( "This demonstration will construct a start time" + 
                          "\nrepresenting 2 min 15.9 seconds"); 

      System.out.println( "\nConstructing ... \n");
      startTime = new PlayTime( 1359);

      System.out.println( "\n... constructed showing ... " + 
                           startTime);
 
      System.out.println( "\n??Are any more demonstrations needed???");

   } // End main. 

} // End class PlayTimeDemonstration.


