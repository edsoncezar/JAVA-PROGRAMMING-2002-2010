// Filename Counters\ClassWideCounterDemo.java.
// Demonstration harness for the (temporarily
// amended LimitedCounter class.
//
// Written for JFL book Chapter 3.
// Fintan Culwin, v0.1, January 1997.

package Counters;

public class ClassWideCounterDemo extends Object { 

   public static void main( String argv[]) { 

   RollOverCounter  aRollOverCounter = null;
   StoppingCounter  aStoppingCounter = null;
   WarningCounter   aWarningCounter  = null;


      System.out.println( "\n\n\t Class Wide Counter Demonstration");

      System.out.print( "\n\nConstructing three instances & counting \n\n");

      aRollOverCounter = new RollOverCounter( 10, 12);
      aStoppingCounter = new StoppingCounter( 2);
      aWarningCounter  = new WarningCounter();
      
      aRollOverCounter.count();
      aRollOverCounter.count();
      aStoppingCounter.count();

      System.out.println( "\nRollOver Counter ... \n" + 
                          aRollOverCounter);     
      System.out.println( "\nStopping Counter ... \n" + 
                          aStoppingCounter);     
      System.out.println( "\nWarning Counter ... \n" + 
                          aWarningCounter);       

      System.out.print( "\n\nDestroying two instances & showing\n\n");    

      aRollOverCounter = null;
      aStoppingCounter = null;

      System.gc();

      System.out.println( "\nWarning Counter ... \n" + 
                          aWarningCounter);             
   } // end fun main()
} // end class ClassWideCounterDemo.    



