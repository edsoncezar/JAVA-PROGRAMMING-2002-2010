// Filename ExitDialogResources_sp.java.
// Contains the Spanish language resources 
// for the ExitDialog class.
//
// Written for Java Interface book chapter 5.
// Fintan Culwin, v0.1, August 1997.


import java.util.ListResourceBundle;

public class ExitDialogResources_sp extends ListResourceBundle { 

   static final Object[][] contents = {    
      { "exitDialogTitle",    "�Salida?" },     
      { "exitDialogQuestion", "�Esta seguro que \nquiere abandonar?" },        
      { "exitDialogYes",      "Si"},      
      { "exitDialogNo",       "No"}        
   }; // End contents.

   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class ExitDialogResources_sp.
