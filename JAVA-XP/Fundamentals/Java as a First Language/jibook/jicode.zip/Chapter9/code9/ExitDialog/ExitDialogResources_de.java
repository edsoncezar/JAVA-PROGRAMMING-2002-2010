// Filename ExitDialogResources_de.java.
// Contains the German language resources 
// for the ExitDialog class.
//
// Written for Java Interface book chapter 5.
// Fintan Culwin, v0.1, August 1997.


import java.util.ListResourceBundle;

public class ExitDialogResources_de extends ListResourceBundle { 

   static final Object[][] contents = {    
      { "exitDialogTitle",    "Best�tigen" },      
      { "exitDialogQuestion", "Wollen Sie diese \nAnwendung verlassen?" },        
      { "exitDialogYes",      "Ja"},      
      { "exitDialogNo",       "Nein"}        
   }; // End contents.

   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class ExitDialogResources_de.
