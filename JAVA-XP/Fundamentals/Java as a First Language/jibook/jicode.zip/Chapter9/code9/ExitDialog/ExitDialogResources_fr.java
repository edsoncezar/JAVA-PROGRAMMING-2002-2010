// Filename ExitDialogResources_fr.java.
// Contains the French language resources 
// for the ExitDialog class.
//
// Written for Java Interface book chapter 5.
// Fintan Culwin, v0.1, August 1997.

import java.util.ListResourceBundle;

public class ExitDialogResources_fr extends ListResourceBundle { 

   public Object[][] getContents() { 
      return contents;   
   } // End getContents.

   static final Object[][] contents = {    
      { "exitDialogTitle",    "Quitter" },      
      { "exitDialogQuestion", "Voulez vous \nvraiement quitter?" },        
      { "exitDialogYes",      "Oui"},      
      { "exitDialogNo",       "Non"}        
   }; // End contents.
} // End class ExitDialogResources_fr.
