// Filename ExitDialogDemo.java.
// Program to illustrate customisation of exit dialog.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v0.2, August 1997.

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import ExitDialog;

public class ExitDialogDemo extends    Applet
                            implements ActionListener, 
                                       WindowListener { 


Frame     itsFrame;
Label     aLabel;

MenuBar   mainMenuBar;
Menu      fileMenu;   
MenuItem  exitButton;

ExitDialog exitDialog;
   
   public void init() { 
   
      itsFrame = new Frame();
      itsFrame.addWindowListener( this);
      itsFrame.setTitle( "Exit Demo Demonstration");
      itsFrame.setBackground( Color.white);
      itsFrame.setFont( new Font( "TimesRoman", Font.PLAIN, 20));   
   
      mainMenuBar = new MenuBar();               
         fileMenu    = new Menu( "File"); 
            exitButton  = new MenuItem( "Exit ...");  
            exitButton.setActionCommand( "exit show");
            exitButton.addActionListener( this);     
         fileMenu.add( exitButton);         
      mainMenuBar.add( fileMenu);   
      itsFrame.setMenuBar( mainMenuBar);      

      exitDialog = new ExitDialog( itsFrame, this);
      
      aLabel = new Label( "hello World!");
      itsFrame.add( aLabel, "Center");
      itsFrame.setSize( itsFrame.getPreferredSize());      
      itsFrame.setVisible( true);                
   } // End init.
   

   public  void actionPerformed( ActionEvent event) {  
      if ( event.getActionCommand().equals( "exit show")) { 
         exitDialog.show();     
      } else if ( event.getActionCommand().equals( "exit please")) {  
         this.setVisible( false);
         System.exit( 0);      
      } // End if.  
   } // End actionPerformed.

   public void windowClosing( WindowEvent event) {  
      exitDialog.show();     
   } // End windowClosing .
   
   public void windowOpened( WindowEvent event)      {} // End windowOpened.    
   public void windowClosed( WindowEvent event)      {} // End windowClosed
   public void windowIconified( WindowEvent event)   {} // End windowIconified
   public void windowDeiconified(WindowEvent event)  {} // End windowDeiconified   
   public void windowActivated( WindowEvent event)   {} // End windowActivated
   public void windowDeactivated( WindowEvent event) {} // End windowDeactivated   
   

   
} // End ExitDialogDemo.       
