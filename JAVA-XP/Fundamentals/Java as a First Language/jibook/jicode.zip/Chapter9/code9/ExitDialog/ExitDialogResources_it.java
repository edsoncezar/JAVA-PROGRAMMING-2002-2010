// Filename ExitDialogResources_it.java.
// Contains the Italian language resources 
// for the ExitDialog class.
//
// Written for Java Interface book chapter 5.
// Fintan Culwin, v0.1, August 1997.


import java.util.ListResourceBundle;

public class ExitDialogResources_it extends ListResourceBundle { 

   static final Object[][] contents = {    
      { "exitDialogTitle",    "Esci" },      
      { "exitDialogQuestion", "Sei sicuro che \nvuoi uscire?" },        
      { "exitDialogYes",      "Si"},      
      { "exitDialogNo",       "No"}        
   }; // End contents.

   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class ExitDialogResources_it.
