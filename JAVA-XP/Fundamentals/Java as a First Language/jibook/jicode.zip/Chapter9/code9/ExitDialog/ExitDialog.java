// Filename ExitDialog.java.
// Supplies a Dialog containing an exit/ yes/ no  
// question and sends ActionEvent if yes replied.
//
// Written for Java Interface book chapter 5.
// Fintan Culwin, v0.1, August 1997.

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import MessageCanvas;


class ExitDialog extends    Dialog 
                 implements ActionListener { 


private Window          itsParentWindow;
private ActionListener  itsListener;

private Panel            buttonPanel;
private MessageCanvas    message;                      
private Button           yesButton;
private Button           noButton; 

private ResourceBundle   resources;
private String           dialogTitle;
private String           exitQuestion;
private String           yesLabel;
private String           noLabel;


   protected ExitDialog( Frame          parentFrame,
                         ActionListener listener) { 
                                     
      super( parentFrame, true);
      
      itsParentWindow = (Window) parentFrame;
      itsListener     = listener;
      
      this.setFont(       itsParentWindow.getFont());
      this.setForeground( itsParentWindow.getForeground());
      this.setBackground( itsParentWindow.getBackground());
      
      resources    = ResourceBundle.getBundle( "ExitDialogResources");
      dialogTitle  = (String) resources.getObject( "exitDialogTitle"); 
      exitQuestion = (String) resources.getObject( "exitDialogQuestion");
      yesLabel     = (String) resources.getObject( "exitDialogYes");
      noLabel      = (String) resources.getObject( "exitDialogNo");
      
      super.setTitle( dialogTitle);
      
      message = new MessageCanvas( exitQuestion);
      message.setBackground( Color.white);
      this.add( message, "Center");

      buttonPanel     = new Panel();
      buttonPanel.setBackground( Color.white);
      
      yesButton = new Button( yesLabel);      
      yesButton.setActionCommand( "yes"); 
      yesButton.addActionListener( this); 
      buttonPanel.add( yesButton);

      noButton = new Button( noLabel); 
      noButton.setActionCommand( "no"); 
      noButton.addActionListener( this);            
      buttonPanel.add( noButton);
      
      this.add( buttonPanel, "South");
      this.pack();
   } // End ExitDialog constructor.
    
    
   public void show() { 
   
   Point         itsParentsLocation;
   Dimension     itsParentsSize;
   Point         itsLocation;
   Dimension     itsSize;

      itsParentsLocation = itsParentWindow.getLocationOnScreen();
      itsParentsSize     = itsParentWindow.getSize();
      itsSize            = this.getSize();
      itsLocation        = new Point();
      
      itsLocation.x = itsParentsLocation.x + 
                      itsParentsSize.width/2 - 
                      itsSize.width/2;
      itsLocation.y = itsParentsLocation.y + 
                      itsParentsSize.height/2 - 
                      itsSize.height/2;                          
      this.setLocation( itsLocation);             
      super.show();            
   } // End show

   public  void actionPerformed( ActionEvent event) {  
      this.setVisible( false);
      if ( event.getActionCommand().equals( "yes")) {   
         itsListener.actionPerformed( new ActionEvent( this, 
                                      ActionEvent.ACTION_PERFORMED,
                                      "exit please"));        
      } // End if.   
   } // End actionPerformed.       
} // End exitPanel.


