

import java.util.ListResourceBundle;

public class TransactionResources extends ListResourceBundle { 

static final String wereOptions[]  = {"There were","There was","There were"};

static final String transOptions[]  = {"transactions","transaction","transactions"};                                
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.


   static final Object[][] contents = {    
      { "transOptions",   transOptions },      
      { "wereOptions", wereOptions },            
   }; // End contents.
} // End class TransactionResources.
