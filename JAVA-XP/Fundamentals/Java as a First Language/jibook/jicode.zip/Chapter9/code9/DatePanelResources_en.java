

import java.util.ListResourceBundle;

public class DatePanelResources_en extends ListResourceBundle { 

static final String dayNames[]   = { "Sun", "Mon", "Tue", "Wed", 
                                     "Thu", "Fri", "Sat", };

static final String monthNames[] = { "Jan", "Feb", "Mar", "Apr", 
                                     "May", "Jun", "Jly", "Aug",
                                     "Sep", "Oct", "Nov", "Dec" };                                  
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.


   static final Object[][] contents = { 
   
      { "dayNames",   dayNames },   
   
      { "monthNames", monthNames },   
   
   
   
   }; // End contents.



} // End class DatePanelResources
