// Filename PropertyDemo.java.
// Program to load and display the system properties.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v0.2, August 1997.


import java.applet.*;
import java.awt.*;
import java.util.*;

public class PropertyDemo  extends Applet { 

   public void init() {    

   Properties    preset   = System.getProperties();
   String        userName = new String( preset.getProperty( "user.name"));
   AppletContext itsContext;
   
      System.out.println( "hello " + userName);
      
     try { 
        itsContext = this.getAppletContext();
        System.out.println( "applet");
     } catch ( NullPointerException  exception) {    
        System.out.println( "stand alone");
     } // End try/ catch.
//      preset.list( System.out);      
   } // End init.
   
   
   public static void main( String args[]) { 

   Frame        frame        = new Frame("PostIt");
   PropertyDemo theDemo = new PropertyDemo();

      theDemo.init();
      frame.add(theDemo, "Center");
      frame.show();
      frame.setSize( frame.getPreferredSize());
   } // end main.
   
} // End PropertyDemo

