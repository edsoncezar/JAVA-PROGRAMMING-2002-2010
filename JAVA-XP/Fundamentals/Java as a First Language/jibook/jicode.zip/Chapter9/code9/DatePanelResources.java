

import java.util.ListResourceBundle;

public class DatePanelResources extends ListResourceBundle { 

static final String dayNames[]   = { "mon", "tue", "wed", "thu",
                                     "fri", "sat", "sun"};

static final String monthNames[] = { "jan", "feb", "mar", "apr", 
                                     "may", "jun", "jly", "aug",
                                     "sep", "oct", "nov", "dec" };                                  
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.


   static final Object[][] contents = { 
   
      { "dayNames",   dayNames },   
   
      { "monthNames", monthNames },   
   
   
   
   }; // End contents.



} // End class DatePanelResources.
