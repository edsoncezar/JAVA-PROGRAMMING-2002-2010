// Filename DatePanelResources_fr.java.
// Contains the French language resources 
// for the DatePanel class.
//
// Written for Java Interface book chapter 9.
// Fintan Culwin, v0.2, August 1997.

import java.util.ListResourceBundle;

public class DatePanelResources_fr extends ListResourceBundle { 

static final String dayNames[]   = { "Dim", "Lun", "Mar", "Mer", 
                                     "Jeu", "Ven", "Sam", };

static final String monthNames[] = { "Jan", "F�v", "Mar", "Avr", 
                                     "Mai", "Jun", "Jul", "Ao�",
                                     "Sep", "Oct", "Nov", "D�c"};
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.


   static final Object[][] contents = {    
      { "dayNames",   dayNames },      
      { "monthNames", monthNames },            
   }; // End contents.
} // End class DatePanelResources_fr.
