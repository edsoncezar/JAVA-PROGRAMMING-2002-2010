// Filename MessageDemoResources.java.
// English (UK) resources for the MessageFormatDemo program.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.util.ListResourceBundle;
import java.text.*;

public class MessageDemoResources extends ListResourceBundle { 

static final double[]     limits = {0,1,2};

static final String       initialPhrases[]  = {"There were ",
                                               "There was ",
                                               "There were "};
static final ChoiceFormat initialFormatter  = 
                                 new ChoiceFormat( limits, initialPhrases);  

static final String       finalPhrases[]  = {" transactions",
                                             " transaction",
                                             " transactions"};
static final ChoiceFormat finalFormatter  = 
                                  new ChoiceFormat( limits, finalPhrases);    

static final Format formatters[] = { initialFormatter, 
                                     NumberFormat.getInstance(),
                                     finalFormatter, 
                                     NumberFormat.getCurrencyInstance(),
                                     DateFormat.getTimeInstance( 
                                                     DateFormat.MEDIUM), 
                                     DateFormat.getDateInstance( 
                                                        DateFormat.FULL)
                                   };

static final MessageFormat generator = new MessageFormat(
                             "{1} {1} {1} totalling {2}\nat {0} on {0}.");       

   static final Object[][] contents = {    
      { "formatters", formatters },         
      { "generator",  generator }             
   }; // End contents.
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class MessageDemoResources.
