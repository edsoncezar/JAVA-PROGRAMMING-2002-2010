// Filename MessageDemoResources.java.
// German language resources for the MessageFormatDemo program.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.util.ListResourceBundle;
import java.text.*;

public class MessageDemoResources_de extends ListResourceBundle { 

static final double[]     limits = {0,1,2};


static final String       finalPhrases[]  = {" �berweiungen",
                                             " �berweiung",
                                             " �berweiungen"};
static final ChoiceFormat finalFormatter  = 
                                  new ChoiceFormat( limits, finalPhrases);
  
static final Format formatters[] = { DateFormat.getTimeInstance( 
                                                        DateFormat.MEDIUM), 
                                        DateFormat.getDateInstance( 
                                                          DateFormat.FULL),                              
                                        NumberFormat.getInstance(),
                                        finalFormatter, 
                                        NumberFormat.getCurrencyInstance() 
                                   };

static final MessageFormat generator = new MessageFormat(
                          "Am {0} on {0} \ngab es {1} {1} totalling {2}.");       

   static final Object[][] contents = {    
      { "formatters", formatters },         
      { "generator",  generator }             
   }; // End contents.
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class MessageDemoResources_de.
