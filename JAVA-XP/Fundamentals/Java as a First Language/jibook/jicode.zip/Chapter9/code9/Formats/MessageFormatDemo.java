// Filename MessageFormatDemo.java.
// Program to illustrate different formatting of messages.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.text.*;
import java.util.*;

public class MessageFormatDemo extends Object { 

   public static void main(String args[]) {

   Integer       numberOfTransactions = new Integer( 1234);
   Date          theDate              = new GregorianCalendar( 
                                            2000, 0, 1, 9, 15).getTime();
   Double        amountTaken          = new Double( 1234.56);
   Object arguments[] = { theDate, 
                          numberOfTransactions,
                          amountTaken
                         };
   
   ResourceBundle resources     = ResourceBundle.getBundle( 
                                                 "MessageDemoResources");
   MessageFormat  generator     = ((MessageFormat) resources.
                                                getObject( "generator")); 
   Format         formatters[]  = ((Format[]) resources.
                                               getObject( "formatters"));

     generator.setFormats( formatters);
     System.out.println( generator.format( arguments));
   } // End main.
} // End MessageFormatDemo.

