// Filename NumberFormatDemo.java.
// Program to illustrate formatting of numeric values.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.text.NumberFormat;

public class NumberFormatDemo { 

   public static void main( String args[]) { 

   Double aGeneralNumber  = new Double( 1234.56);
   Double aPositiveAmount = new Double( 12.34);
   Double aNegativeAmount = new Double( -12.34);

      System.out.println( "\n\tNumber Format Demo\n");

      System.out.print( "Default formatting of a general  number ... ");
      System.out.println( NumberFormat.getNumberInstance().
                                     format( aGeneralNumber) + ".");

      System.out.print( "Default formatting of a positive amount ... ");
      System.out.println( NumberFormat.getCurrencyInstance().
                                     format( aPositiveAmount) + ".");

      System.out.print( "Default formatting of a negative amount ... ");
      System.out.println( NumberFormat.getCurrencyInstance().
                                     format( aNegativeAmount) + ".");
   } // end main.   
} // End NumberFormatDemo.

