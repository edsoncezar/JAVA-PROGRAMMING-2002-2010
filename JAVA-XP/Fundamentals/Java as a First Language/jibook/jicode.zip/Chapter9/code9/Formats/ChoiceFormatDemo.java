// Filename ChoiceFormatDemo.java.
// Program to illustrate different formatting of messages.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.text.ChoiceFormat;
import java.util.ResourceBundle;

public class ChoiceFormatDemo extends Object { 

   public static void main(String args[]) {

   int         numberOfTransactions;
   ResourceBundle  resources;
   ChoiceFormat    initialPhrase;
   ChoiceFormat    finalPhrase; 

      System.out.println( "\n\t Choice Format Demo\n");

      resources     = ResourceBundle.getBundle( "ChoiceFormatResources");
      initialPhrase = ((ChoiceFormat) resources.getObject( "initialFormatter"));
      finalPhrase   = ((ChoiceFormat) resources.getObject( "finalFormatter")); 

      
      numberOfTransactions =0;
      System.out.println( initialPhrase.format( numberOfTransactions) + 
                          numberOfTransactions                        + 
                          finalPhrase.format( numberOfTransactions) + ".");

       numberOfTransactions =  1;
      System.out.println( initialPhrase.format( numberOfTransactions) + 
                          numberOfTransactions                        + 
                          finalPhrase.format( numberOfTransactions) + ".");

      numberOfTransactions = 1000;
      System.out.println( initialPhrase.format( numberOfTransactions) + 
                          numberOfTransactions                        + 
                          finalPhrase.format( numberOfTransactions) + ".");
   } // End main.
} // End ChoiceFormatDemo.

