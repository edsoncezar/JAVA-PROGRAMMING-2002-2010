// Filename TimeFormatDemo.java.
// Program to illustrate formatting of times and dates.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.

import java.util.Date;
import java.util.GregorianCalendar;
import java.text.DateFormat;

public class TimeFormatDemo { 

   public static void main( String args[]) { 

   Date theNightBefore  = new GregorianCalendar( 
                                    1999, 11, 31, 20, 20).getTime();
   Date theMorningAfter = new GregorianCalendar( 
                                    2000, 0, 1, 07, 07).getTime();

      System.out.println( "\n\t Date and Time Format Demo\n");

      System.out.println( "Default formatting of dates and times ... ");
      System.out.print(   "Before ");
      System.out.print(   DateFormat.getInstance().format( theNightBefore));
      System.out.print(   " after ");
      System.out.print(   DateFormat.getInstance().format( theMorningAfter));
      System.out.println( ".\n");

      System.out.println( "Formatting of dates ... ");
      System.out.print(   "Before ");
      System.out.print(   DateFormat.getDateInstance( DateFormat.FULL).
                                                      format( theNightBefore));
      System.out.print(   " after "); 
      System.out.print(   DateFormat.getDateInstance( DateFormat.MEDIUM).
                                                      format( theMorningAfter));
      System.out.println( ".\n");

      System.out.println( "Formatting of times ... ");
      System.out.print(   "Before ");
      System.out.print(   DateFormat.getTimeInstance( DateFormat.SHORT).
                                                      format( theNightBefore));
      System.out.print(   " after ");
      System.out.print(   DateFormat.getTimeInstance( DateFormat.LONG).
                                                      format( theMorningAfter));
      System.out.println( ".");
   } // end main.   
} // End TimeFormatDemo.

