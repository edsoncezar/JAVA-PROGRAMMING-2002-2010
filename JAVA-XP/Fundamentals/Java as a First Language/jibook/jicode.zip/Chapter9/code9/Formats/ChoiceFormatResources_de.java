// Filename ChoiceFormatResources_de.java.
// German resources for the ChoiceFormatDemo program.
//
// Written for JI book, Chapter 9 see text.
// Fintan Culwin, v 0.2, August 1997.


import java.util.ListResourceBundle;
import java.text.*;

public class ChoiceFormatResources_de extends ListResourceBundle { 

static final double[]     limits = {0,1,2};

static final String       initialPhrases[]  = {"Gab es ",
                                               "Gab es ",
                                               "Gab es "};
static final ChoiceFormat initialFormatter  = 
                                 new ChoiceFormat( limits, initialPhrases);  

static final String       finalPhrases[]  = {" �berweiungen",
                                             " �berweiung",
                                             " �berweiungen"};
static final ChoiceFormat finalFormatter  = 
                                  new ChoiceFormat( limits, finalPhrases);  

   static final Object[][] contents = {    
      { "initialFormatter", initialFormatter },  
      { "finalFormatter",   finalFormatter   }        
   }; // End contents.
                                     
   public Object[][] getContents() { 
      return contents;   
   } // End getContents.
} // End class ChoiceFormatResources_de.

