// Filename LoggingCommandLineTuttle.java.
// Supplies a command line interface for  
// the Tuttle class.
//
// Written for Java Interface book chapter 8.
// Fintan Culwin, v0.2, August 1997.

package CommandLineTuttle;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

import java.util.StringTokenizer;

import Tuttles.LoggingTuttle;
import CommandLineTuttle.CommandLineTuttleInterface;

public class LoggingCommandLineTuttle extends    Applet 
                                      implements ActionListener,
                                                 MouseListener {   

private LoggingTuttle              theTuttle; 
private CommandLineTuttleInterface theInterface;

private Panel                      feedbackPanel;
private Label                      feedbackLabel;

   public void init() { 
   
   Panel tuttlePanel   = new Panel();
              
      this.setLayout( new BorderLayout());
      this.setFont( new Font( "TimesRoman", Font.BOLD, 14));
      this.setBackground( Color.white);

      theTuttle = new LoggingTuttle( this, this, 400, 400);      
      tuttlePanel.add( theTuttle);
      
      theInterface = new CommandLineTuttleInterface( this);        
                 
      feedbackPanel = new Panel();     
      feedbackPanel.setBackground( Color.white);
      feedbackLabel = new Label();
      feedbackPanel.add( feedbackLabel);
      
      this.add( feedbackPanel, "North");
      this.add( tuttlePanel,   "Center");
      this.add( theInterface,  "South");
            
      this.feedback();
   } // end init.   


   public void actionPerformed( ActionEvent event) { 

   String          theCommand = event.getActionCommand();
   StringTokenizer tokenizer  = new StringTokenizer( theCommand);
   String          firstTerm  = tokenizer.nextToken().toLowerCase();
   String          theResponse;

       if ( firstTerm.equals( "help")) { 
         theTuttle.logCommand( theCommand);       
         theResponse = obtainHelp( tokenizer);
       } else if ( firstTerm.equals( "exit")) {  
         theTuttle.logCommand( theCommand);       
         theResponse = checkExit( tokenizer);
       } else {        
         theResponse = theTuttle.doCommand( theCommand); 
       } // End if           
       theInterface.appendFeedback( "\n> " + theCommand);
       if ( theResponse.length() > 0 ) { 
          theInterface.appendFeedback("\n" + theResponse);    
       } // End if.   
       theInterface.clearCommandArea();
       this.feedback();
   } // end actionPerformed.


   public void mouseClicked( MouseEvent event) {  
  
      if ( event.isControlDown() && event.isShiftDown()) { 
         if ( theTuttle.isLoggingActive()) { 
            theTuttle.stopLogging();
         } else { 
            theTuttle.startLogging();
            this.feedback();       
         } // End if. 
      } // End if.  
   } // End keyTyped.
   
   public void mousePressed(  MouseEvent event ) {}  // End mousePressed.
   public void mouseReleased( MouseEvent event ) {}  // End mouseReleased.
   public void mouseEntered(  MouseEvent event ) {}  // End mouseEntered.
   public void mouseExited(   MouseEvent event ) {}  // End mouseExited.
   

   protected String obtainHelp( StringTokenizer tokenizer) { 
   
   StringBuffer theHelp = new StringBuffer( "");
   String       secondTerm;
   int          helpFor;   

      if ( !tokenizer.hasMoreTokens()) { 
         theHelp.append( "help is available for fd, bd, tr, tl " + 
                         "fg bg pu pd cl rs cr exit undo load and save.");
      } else {    
          secondTerm = tokenizer.nextToken().toLowerCase();
          helpFor = theTuttle.identifyCommand( secondTerm);
          
          switch ( helpFor) { 
          case theTuttle.UNDO:
             theHelp.append( "Undo will undo the last command, if any \n" + 
                             "unless the last command cleared the screen.\n"); 
             if ( theTuttle.isUndoAvailable()) { 
                theHelp.append( "Undo will currently undo " + 
                                theTuttle.whatUndoIsAvailable());
             } else { 
                theHelp.append( "Undo is not available at this time.");
             } // End if.          
             break;
                                  
          case theTuttle.FORWARD:
             theHelp.append("fd is ForwarD, it must be followed by a number, " + 
                            "\nthe tuttle will move that many steps in its " + 
                            "current direction.");
             break;
             
          case theTuttle.UNKNOWN:
             theHelp.append("Sorry! The command '" + secondTerm + 
                            "' is not known \n Try 'help' by itself for " +
                            "a list of commands which are known.");
             break;                                 
          
          } // End switch.
      } // End if.    
      return theHelp.toString();
   } // End obtainHelp.
   

   private String checkExit( StringTokenizer tokenizer) {    
      if ( (tokenizer.countTokens() == 1)  &&
           (tokenizer.nextToken().toLowerCase().equals( "please")) ){ 
         if ( theTuttle.isLoggingActive()) { 
            theTuttle.stopLogging();         
         } // End if.  
         System.exit( 0);
         return "";  
      } else {               
         return new String( "To exit from this application you have to " +
                            "type 'exit', followed by 'please'!");         
      }   
   } // End checkExit.
   
   private void feedback(){    
      feedbackLabel.setText(  theTuttle.getDetails());
      feedbackPanel.layout();
   } // End feedback.
} // End class BufferedCommandLineTuttle.



