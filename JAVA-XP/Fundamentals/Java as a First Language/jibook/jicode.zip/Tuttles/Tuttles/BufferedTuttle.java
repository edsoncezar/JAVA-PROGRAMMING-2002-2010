// Filename BufferedTuttle.java.
// Extends the Tuttle class by providing a buffer to 
// store the commands and a text processing interface.
// Provides undo, save and load capability.
//
// Written for the Java Interface Book Chapter 8.
// Fintan Culwin, v 0.2, August 1997.

package Tuttles;

import java.awt.*;
import java.applet.*;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;

import Tuttles.TextTuttle;


public class BufferedTuttle extends TextTuttle {

public static final int UNDO          = 12;
public static final int LOAD          = 13;
public static final int SAVE          = 14;
public static int       MAX_COMMANDS  = 15;

private   int     startX;
private   int     startY;
private   int     startDirection;
private   Color   startForeground;
private   Color   startBackground;
private   boolean startPenStatus;

protected Vector  commandBuffer;


   public BufferedTuttle( Applet applet, int width, int height) { 
      super( applet, width, height);
      commandBuffer = new Vector(); 
      this.storeTuttleStatus();     
   } // End Tuttle constructor.


   public String doCommand( String theCommand) { 
   
   StringTokenizer tokenizer = new StringTokenizer( theCommand);
   String          firstTerm = null;
   String          theReply  = null; 
   int             thisCommand; 
        
      if ( tokenizer.hasMoreTokens()) { 
         firstTerm = tokenizer.nextToken().toLowerCase();
         thisCommand = identifyCommand( firstTerm);
         
         if ( thisCommand == UNDO) { 
            theReply = this.undo();       
         } else if ( thisCommand == LOAD) { 
            theReply = this.loadDrawing( tokenizer);           
         } else if ( thisCommand == SAVE) { 
            theReply = this.saveDrawing( tokenizer);           
         } else {    
            theReply = super.doCommand( theCommand);     
         } // End if. 
         
         if ( theReply.length() == 0) { 
            if ( thisCommand == CLEAR_AND_RESET ||
                 thisCommand == CLEAR           ){ 
               this.storeTuttleStatus();                  
            } else if ( thisCommand != CLEAR    &&
                        thisCommand != SAVE     && 
                        thisCommand != LOAD     ){ 
               commandBuffer.addElement( theCommand); 
            } // End if.                                    
         } // End if.          
      } // End if.      
      return theReply;
   } // End doCommand.


   public int identifyCommand( String toIdentify) { 
   
   int identified  = UNKNOWN;
   
     if ( toIdentify.equals( "undo")) { 
       identified = UNDO;
     } else if ( toIdentify.equals( "load")) { 
       identified = LOAD;
     } else if ( toIdentify.equals( "save")) {
       identified = SAVE;
     } else {  
       identified = super.identifyCommand( toIdentify); 
     } // End if.
     return identified;
   } // End identifyCommand.
   
   
   private String undo() { 
   
   int           thisCommand;
   StringBuffer  theReply = new StringBuffer("");

      if ( commandBuffer.size() > 0) {
         theReply.append( "undo " + 
                          commandBuffer.elementAt( commandBuffer.size()-1));          
         commandBuffer.removeElementAt( commandBuffer.size()-1);  
         this.hideTuttle();  
         this.restoreTuttleStatus();
         for ( thisCommand = 0; 
               thisCommand < commandBuffer.size(); 
               thisCommand++) {                  
            super.doCommand( (String) commandBuffer.elementAt( thisCommand)); 
         } // End for.           
         this.showTuttle();         
      } else { 
         theReply.append( "Nothing to undo!");   
      } // End if.
      return theReply.toString();
   } // End undo.


   public boolean isUndoAvailable() { 
      return !commandBuffer.isEmpty();   
   } // End isUndoAvailable.
   

   public String whatUndoIsAvailable() { 
   
   StringBuffer isAvailable = new StringBuffer( "");
   
      if ( this.isUndoAvailable()) {   
         isAvailable.append(  commandBuffer.elementAt( commandBuffer.size()-1));
      } // End if. 
      return isAvailable.toString();
   } // End whatUndoIsAvailable. 

   
   protected void storeTuttleStatus() { 
   
   Point localPoint = super.tuttleLocationIs();
   
      startX          = localPoint.x; 
      startY          = localPoint.y; 
      startDirection  = this.tuttleDirectionIs();
      startForeground = this.tuttleForegroundIs();
      startBackground = this.tuttleBackgroundIs();
      startPenStatus  = this.penStatusIs(); 
      commandBuffer.removeAllElements();  
   } // End getTuttleStatus.
   

   protected void restoreTuttleStatus(){ 
      this.setForeground( startForeground);      
      this.clearAndReset( startBackground);
      this.setPenUp();
      this.turnRight( 90);
      this.forward( startX);
      this.turnLeft( 90);
      this.forward( startY);
      this.turnRight( startDirection);
      if ( startPenStatus) { 
         this.setPenDown();
      } else { 
         this.setPenUp();
      } // End if.  
   } // End restoreTuttle.   
   
   
   private String saveDrawing( StringTokenizer tokenizer) { 
     
     int         thisCommand;
     String      theReply   = "";
     String      theFileName;
     PrintWriter saveHere;
  
        if ( tokenizer.countTokens() != 1) { 
           theReply = new String( "Save must be followed only by the name " + 
                                  "of the file to save the drawing to.");
        } else { 
           theFileName = (String) tokenizer.nextToken(); 
           try { 
              saveHere = new PrintWriter( new FileOutputStream( theFileName));
              saveHere.println( this.identifyColourAsString( startBackground));
              saveHere.println( "fg " + 
                                this.identifyColourAsString( startForeground));
              saveHere.println( "pu");
              saveHere.println( "tr 90");
              saveHere.println( "fd " + startX);
              saveHere.println( "tl 90");
              saveHere.println( "fd " + startY);   
              saveHere.println(  "tr " + startDirection);
              if ( startPenStatus) { 
                 saveHere.println( "pd");
              } else { 
                 saveHere.println( "pu");
              } // End if.
        
              for ( thisCommand = 0; 
                    thisCommand < commandBuffer.size(); 
                    thisCommand++) {
                 saveHere.println( (String) 
                                       commandBuffer.elementAt( thisCommand));
              } // End for.            
              saveHere.close();   
           } catch ( IOException exception) { 
              theReply = new String( "The drawing could not be save to " + 
                                    theFileName + ".");
           } // End try/catch.
        } // End if.
        return theReply;                                               
     } // End saveDrawing.
 


     public String loadDrawing( StringTokenizer tokenizer) { 
     
     int            loadCount = 0;
     int            thisCommand;
     boolean        allDone    = false;
     String         theReply   = "";
     String         theFileName;
     String         theCommand;
     BufferedReader loadFromHere = null;
  
        if ( tokenizer.countTokens() != 1) { 
           theReply = new String( "Load must be followed only by the name " + 
                                  "of the file to save the drawing to.");     
        } else { 
           theFileName = (String) tokenizer.nextToken(); 
           try { 
              loadFromHere = new BufferedReader( 
                                     new FileReader( theFileName));
              this.hideTuttle();            
              theCommand = loadFromHere.readLine();
              if ( super.identifyColor( theCommand ) != null) { 
                 this.clearAndReset( super.identifyColor( theCommand ));
              } else { 
                 throw new IOException();
              } // End if.
              while ( !allDone) { 
                 theCommand = loadFromHere.readLine();         
                 if ( theCommand == null ) {                      
                    allDone = true;
                 } else {                   
                    this.doCommand( theCommand); 
                    if ( ++loadCount == 8) { 
                       this.storeTuttleStatus();
                    } // End if.  
                } // End if.                     
              } // End while. 
              loadFromHere.close();                                       
           } catch ( IOException exception) { 
              theReply = new String( "The drawing could not be loaded from " + 
                                     theFileName + ".");
           } // End try/ catch.   
           this.showTuttle();
        } // End if.
        return theReply;        
     } // End loadDrawing.


   private static String identifyColourAsString( Color toIdentify) { 
   
   String theString = null;
   
      if ( toIdentify.equals( Color.black)) { 
         theString = new String( "black") ;
      } else if ( toIdentify.equals( Color.white)) { 
         theString = new String( "white");   
      } else if ( toIdentify.equals( Color.yellow)) { 
         theString = new String( "yellow");
      } else if ( toIdentify.equals( Color.green)) { 
         theString = new String( "green");
      } else if ( toIdentify.equals( Color.red)) { 
         theString = new String( "red");
      } else if ( toIdentify.equals( Color.blue)) { 
         theString = new String( "blue");     
      } // End if.        
      return theString;      
   } // End identifyColourAsString.
      
} // End BufferedTuttle

