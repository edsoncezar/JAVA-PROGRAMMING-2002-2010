// Filename LoggingTuttle.java.
// Extends the Tuttle class by providing the facility
// for tuttle commands to be logged to a file.
// Written for the Java Interface Book Chapter 7.
// Fintan Culwin, v 0.1, August 1997.

package Tuttles;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;

import java.io.*;

import TimeStamp;
import Tuttles.BufferedTuttle;

public class LoggingTuttle extends BufferedTuttle {

private boolean       loggingActive   = false;
private PrintWriter   logFile;

   public LoggingTuttle( Applet applet, MouseListener itsListener,
                         int width, int height) { 
      super( applet, width, height);
      this.addMouseListener( itsListener);
   } // End LoggingTuttle  constructor.

   public String doCommand( String theCommand) { 
      logCommand( theCommand);
      return super.doCommand( theCommand);
   } // End doCommand.

   public void logCommand( String theCommand ) { 
      if ( loggingActive) { 
         logFile.println( new TimeStamp( true) + " " + theCommand);      
      } // End if.      
   } // End logCommand;


   public void startLogging() { 

   String theTime  = new String( new TimeStamp( true).toString());  
   String fileName = new String( "tlog" + theTime.substring( 0, 2)
                                        + theTime.substring( 3, 5)
                                        + theTime.substring( 6)
                                        + ".log");                                               
      try { 
         //logFile = new PrintWriter( new FileOutputStream( fileName));
         throw new IOException();
      } catch ( IOException exception) { 
         System.err.println( "Log file could not be openend," +
                             "logging to terminal.");
         logFile = new PrintWriter( System.out, true);                              
      } // End try/ catch.     
      loggingActive = true;
      logCommand( "logging started");  
   } // End startLogging.

   public void stopLogging() { 
      logCommand( "logging stopped");      
      logFile.close();      
      loggingActive = false;  
   } // End startLogging.  
   

   public boolean isLoggingActive() { 
      return loggingActive;   
   } // End isLoggingActive. 
   
   
   public String getDetails() { 

   StringBuffer buffer = new StringBuffer( super.getDetails());
       
       if ( loggingActive) { 
          buffer.setCharAt( buffer.toString().indexOf('x'), 'X');
          buffer.setCharAt( buffer.toString().indexOf('y'), 'Y');
          buffer.setCharAt( buffer.toString().indexOf('d'), 'D');
       } // End if.   
       return buffer.toString();
   } // End showDetails.
} // End LoggingTuttle.
