// Filename TuttleSaveDialog.java.
// Supplies a Dialog containing an exit/ yes/ no  
// question and sends ActionEvent if yes replied.
//
// Written for Java Interface book chapter 8.
// Fintan Culwin, v 0.2, August 1997.

package MenuBarTuttle;

import java.awt.*;
import java.awt.event.*;

class TuttleSaveDialog extends FileDialog { 

private String          saveFilename = null;
private String          saveDirname  = null;
private Frame           itsParentFrame;
private ActionListener  itsListener;    

    protected TuttleSaveDialog( Frame          parentFrame,
                                ActionListener listener) { 
       super( parentFrame, "Tuttle Save", FileDialog.SAVE);        
       itsParentFrame = parentFrame;
       itsListener = listener;
    } // End TuttleSaveDialog constructor.
    

    public void setVisible( boolean showIt) { 
    
    String    tempDirname;
    String    tempFilename; 
    Point     itsParentsLocation;
    Dimension itsParentsSize;
    Point     itsLocation;
    Dimension itsSize;

       if ( showIt) { 
          itsParentsLocation = itsParentFrame.getLocationOnScreen();
          itsParentsSize     = itsParentFrame.getSize();
          itsSize            = this.getSize();
          itsLocation        = new Point();
      
          itsLocation.x = itsParentsLocation.x + 
                          itsParentsSize.width/2 - 
                          itsSize.width/2;
          itsLocation.y = itsParentsLocation.y + 
                          itsParentsSize.height/2 - 
                          itsSize.height/2;                          
          this.setLocation( itsLocation);             
          this.setDirectory( "");
          this.setFile( "*.tutt");                                     
       
          saveFilename = null;
          saveDirname  = null;
       
          super.setVisible( true);             

          tempFilename = this.getFile();
          tempDirname  = this.getDirectory();
          if ( ( tempDirname != null)) {                      
             saveDirname  = new String( tempDirname);                                                        
          } // End if.
          if ( ( tempFilename != null)) {  
             saveFilename = new String( tempFilename);
             itsListener.actionPerformed( new ActionEvent( this, 
                                          ActionEvent.ACTION_PERFORMED,
                                          "saveit"));
          } // End if.                                     
       } else { 
         super.setVisible( false);
       } 
    } // End postLoadDialog.


    protected void setFullFilename( String filename,
                                    String dirname) { 
       saveFilename = new String( filename);
       saveDirname  = new String(  dirname); 
       itsParentFrame.setTitle( "Menu Bar Tuttle [" +
                                 saveDirname + saveFilename + "]");               
    } // End setFullFilename.     
    
    protected void clearFullFilename() { 
       saveFilename = null;
       saveDirname  = null;    
       itsParentFrame.setTitle( "Menu Bar Tuttle ");       
    } // End clearFullFilename.                                    
        
    protected boolean isFilenameAvailable() { 
       return ( saveFilename != null);
    } // End isFilenameAvailable.
    
    protected String filenameIs(){ 
       return new String( saveFilename);  
    } // End filenameIs. 

    protected String fullFilenameIs() { 
       return new String( saveDirname + saveFilename);            
    } // End fullFilenameIs.
    
    protected String dirnameIs() { 
       return new String( saveDirname);         
    } // End dirnameIs.         
} // End TuttleSaveDialog.

