// Filename TuttleOpenDialog.java.
// Supplies a Dialog containing an exit/ yes/ no  
// question and sends ActionEvent if yes replied.
//
// Written for Java Interface book chapter 8.
// Fintan Culwin, v0.2, August 1997.

package MenuBarTuttle;

import java.awt.*;
import java.awt.event.*;

class TuttleOpenDialog extends FileDialog { 

private String          openFilename = null;
private String          openDirname  = null;
private Window          itsParentWindow;
private ActionListener  itsListener;    

    protected TuttleOpenDialog( Frame          itsParentFrame,
                                ActionListener listener) { 
       super( itsParentFrame, "Tuttle Open", FileDialog.LOAD);        
       itsParentWindow = (Window) itsParentFrame;
       itsListener = listener;
    } // End OpenDialog constructor.
    

    public void setVisible( boolean showIt) { 
    
    String    tempDirname;
    String    tempFilename; 
    Point     itsParentsLocation;
    Dimension itsParentsSize;
    Point     itsLocation;
    Dimension itsSize;

       if ( showIt) { 
          itsParentsLocation = itsParentWindow.getLocationOnScreen();
          itsParentsSize     = itsParentWindow.getSize();
          itsSize            = this.getSize();
          itsLocation        = new Point();
      
          itsLocation.x = itsParentsLocation.x + 
                          itsParentsSize.width/2 - 
                          itsSize.width/2;
          itsLocation.y = itsParentsLocation.y + 
                          itsParentsSize.height/2 - 
                          itsSize.height/2;                          
          this.setLocation( itsLocation);             
          this.setDirectory( "");
          this.setFile( "*.tutt");                                     
       
          openFilename = null;
          openDirname  = null;
       
          super.setVisible( true);             

          tempFilename = this.getFile();
          tempDirname  = this.getDirectory();
          if ( ( tempDirname != null)) {                      
             openDirname  = new String( tempDirname);                                                        
          } // End if.
          if ( ( tempFilename != null)) {  
             openFilename = new String( tempFilename);
             itsListener.actionPerformed( new ActionEvent( this, 
                                          ActionEvent.ACTION_PERFORMED,
                                          "loadit"));         
          } // End if.   
       } else { 
         super.setVisible( false);
       } 
    } // End setVisible.

        
    protected boolean isFilenameAvailable() { 
       return ( openFilename != null);
    } // End isFilenameAvailable.
    
    protected String filenameIs(){ 
       return new String( openFilename);  
    } // End getFilename. 

    protected String fullFilenameIs() { 
       return new String( openDirname + openFilename);            
    } // End getFullFilename.
    
    protected String dirnameIs() { 
       return new String( openDirname);         
    } // End getDirname.         
} // End OpenDialog.

