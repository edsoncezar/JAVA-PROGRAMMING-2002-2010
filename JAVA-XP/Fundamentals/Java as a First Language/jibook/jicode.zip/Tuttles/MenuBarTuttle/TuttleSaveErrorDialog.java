// Filename TuttleSaveErrorDialog.java.
// Supplies a Dialog containing an exit/ yes/ no  
// question and sends ActionEvent if yes replied.
//
// Written for Java Interface book chapter 8.
// Fintan Culwin, v0.1, August 1997.


package MenuBarTuttle;


import java.awt.*;
import java.awt.event.*;

import MessageCanvas;

class TuttleSaveErrorDialog extends    Dialog 
                            implements ActionListener { 


private Window         itsParentWindow;
private ActionListener itsListener;

private Button         okButton;
private Panel          buttonPanel;
private MessageCanvas  message;

   protected TuttleSaveErrorDialog( Frame          itsParentFrame,
                                    ActionListener listener) { 
             
      super( itsParentFrame, "Tuttle Save Error!", true);
      this.setFont( itsParentFrame.getFont());
      this.setBackground( itsParentFrame.getBackground());
      itsParentWindow = (Window) itsParentFrame;
      itsListener     = listener; 
      
      okButton = new Button( "OK");
      okButton.addActionListener( this);
      buttonPanel = new Panel();
      buttonPanel.setBackground( Color.white); 
      buttonPanel.add( okButton);

      this.add( buttonPanel, "South");      
   } // End TuttleSaveErrorDialog constructor.
    

   protected void setReason( String theReason) { 
      message = new MessageCanvas( theReason);
      message.setBackground( Color.white); 
      this.add( message, "Center");     
      this.pack();
   } // End setReason.

    
   public void setVisible( boolean showIt) {  

   Point         itsParentsLocation;
   Dimension     itsParentsSize;
   Point         itsLocation;
   Dimension     itsSize;


      if ( showIt) {        
         itsParentsLocation = itsParentWindow.getLocationOnScreen();
         itsParentsSize     = itsParentWindow.getSize();
         itsSize            = this.getSize();
         itsLocation        = new Point();
      
         itsLocation.x = itsParentsLocation.x + 
                         itsParentsSize.width/2 - 
                         itsSize.width/2;
         itsLocation.y = itsParentsLocation.y + 
                         itsParentsSize.height/2 - 
                         itsSize.height/2;                          
         this.setLocation( itsLocation); 
      } // End if.                 
      super.setVisible( showIt);                
   } // End setVisible.

   public  void actionPerformed( ActionEvent event) {
      this.setVisible( false);
      itsListener.actionPerformed( new ActionEvent( this, 
                                   ActionEvent.ACTION_PERFORMED,
                                  "saveas"));     
   } // End actionPerformed. 

} // End TuttleSaveErrorDialog.
