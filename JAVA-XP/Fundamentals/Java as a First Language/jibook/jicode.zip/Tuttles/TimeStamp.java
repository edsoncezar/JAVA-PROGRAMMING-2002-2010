// Filename TimeStamp.java.
// Providing a very minimal TimeStamp class.
//
// Written for JI Book Chapter 8.
// Fintan Culwin, V 0.2, Aug 1997. 


import java.util.GregorianCalendar;

public class TimeStamp extends Object { 

private static final int SECONDS_PER_MIN  = 60;
private static final int SECONDS_PER_HOUR = SECONDS_PER_MIN * 60;
private static final int INVALID_TIME     = -1;
private int              theStamp = INVALID_TIME;

   public TimeStamp() { 
       super();
       this.stamp();
   } // End TimeStamp.
   
   public TimeStamp( boolean toStampNow) { 
       super();   
       if ( toStampNow) { 
          this.stamp();
       } // End if.
   } // End TimeStamp alternative constructor.


   public void stamp(){   
   
   GregorianCalendar now = new GregorianCalendar();

      theStamp = ( now.get( GregorianCalendar.HOUROFDAY) * SECONDS_PER_HOUR) +    
                 ( now.get( GregorianCalendar.MINUTE)    * SECONDS_PER_MIN)  + 
                 now.get( GregorianCalendar.SECOND);               
   } // End stamp.


   public int elapsed( TimeStamp anotherStamp) { 
      if ( (anotherStamp.theStamp == INVALID_TIME ) ||
           (this.theStamp         == INVALID_TIME )  ){
         return INVALID_TIME;  
      } else {            
         return anotherStamp.theStamp - this.theStamp;   
      } // End if.   
   } // End elapsed.


   public String toString() { 

   StringBuffer theTime = new StringBuffer( "");

      if ( theStamp != INVALID_TIME) { 

      int hours;
      int mins;
      int secs;
      StringBuffer theHours = new StringBuffer( "");
      StringBuffer theMins  = new StringBuffer( "");
      StringBuffer theSecs  = new StringBuffer( "");
          hours =  theStamp / SECONDS_PER_HOUR;
          theHours.append( hours);
          if ( theHours.length() == 1) { 
             theHours = new  StringBuffer( "0" + theHours);
          } // End if.
          secs  = theStamp % SECONDS_PER_MIN;
          theSecs.append( secs); 
          if ( theSecs.length() == 1) { 
             theSecs = new  StringBuffer( "0" + theSecs);
          } // End if. 
          mins  = (theStamp - ( hours * SECONDS_PER_HOUR)) / SECONDS_PER_MIN; 
          theMins.append( mins); 
          if ( theMins.length() == 1) { 
             theMins = new  StringBuffer( "0" + theMins);
          } // End if. 
          theTime.append( theHours + ":" + theMins + ":" + theSecs);       
      } else { 
          theTime.append( "**:**:**");
      } // End if. 
      return theTime.toString();    
   } // End toString;
} // End TimeStamp.
