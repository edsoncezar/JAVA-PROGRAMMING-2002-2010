// Filename DatePanelTest.java.
// Demonstration harness for the interactive date panel.
//
// Fintan Culwin, v 0.1, April 1996


import java.awt.*;
import java.applet.*;
import DatePanel;

public class DatePanelTest extends Applet {

DatePanel  aDatePanel;
  public void init() {

  Font       theFont    = new Font( "TimesRoman", Font.PLAIN, 16);
  
     aDatePanel = new DatePanel();
     this.setFont( theFont);
     this.setBackground( Color.white);
     this.add( aDatePanel);          
  } // end init()


   public boolean action(Event event,
                         Object what) { 
       this.showDate(); 
       return true;                    
   } // End action.                        


   private void showDate() { 
   
       System.out.println( aDatePanel.yearIs()  + "/" +
                           aDatePanel.monthIs() + "/" +
                           aDatePanel.dayIs());
   } // End showDate.

   public static void main(String args[]) {

   Frame        frame      = new Frame("Date Panel Test");
   DatePanelTest theTest   = new DatePanelTest();
   
   
   try { 

      theTest.init();
      frame.add("Center", theTest);

      frame.show();
      frame.resize( frame.preferredSize());
   } catch ( Exception exception) { 
      exception.printStackTrace();
   }    

   } // end fun main

} // end class DatePanelTest










