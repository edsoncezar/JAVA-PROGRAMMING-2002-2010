// Filename MultipleListExample.java.
// Provides an example of the AWT List class, illustrating 
// scrollbar and multiple selction possibilities.  
// Written for the Java interface book Chapter 2 - see text.
// This version with a scroll bar.
//
// Fintan Culwin, v 0.2, August 1997.


import java.awt.*;
import java.awt.event.*;
import java.applet.*;


public class MultipleListExample extends    Applet 
                                 implements ItemListener { 
                                 
                                 
   public void init() {

   List   cityList    = new List( 4, true);
   Label  promptLabel = new Label( "Which cities have you visited?");

      this.setFont( new Font( "TimesRoman", Font.PLAIN, 20));     
      this.setLayout( new BorderLayout());
     
      cityList.addItem( "London");
      cityList.addItem( "Paris");
      cityList.addItem( "Barcelona");
      cityList.addItem( "Athens");
      cityList.addItem( "Rome");
      cityList.addItem( "Istanbul");
      cityList.addItem( "Berlin");

      cityList.addItemListener( this); 
     
      this.add( promptLabel, "North");     
      this.add( cityList,    "Center");
   } // End init.


  public  void itemStateChanged(ItemEvent event) {  
  
  List   originator = (List) event.getItemSelectable();
  String visited[]  = originator.getSelectedItems();
 
      if ( visited.length == 0) { 
         System.out.println( "No items are now selected!");
      } else {      
         for ( int index = 0; index < visited.length; index++ ) {     
            System.out.print( visited[ index] + " ");
         } // End for.
         System.out.println();          
      } // End if.
  } // End itemStateChanged.
  


   public static void main(String args[]) {

   Frame        frame     = new Frame("Mutiple List Example demo");
   MultipleListExample theExample = new MultipleListExample();

      theExample.init();
      frame.add("Center", theExample);

      frame.show();
      frame.setSize( frame.getPreferredSize());

   } // End main.

} // end class MultipleListExample.










