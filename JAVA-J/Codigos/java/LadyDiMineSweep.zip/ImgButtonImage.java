import java.awt.*;
import java.awt.Image;
import java.awt.Graphics;
import java.applet.Applet;

class ImgButtonImage {
  private int xSize,ySize,border;
  private String gifName;
  public  Image   up,down;
  static private final Color   upEdgeColor= Color.lightGray;  
  static private final Color   downEdgeColor = Color.darkGray;
  static private final Color   lineColor = Color.black;
  private final float   shiftPercentage = 5.0f;

  private void fillImage(Graphics g,Image gif, 
			 int shift, boolean isUp, Applet app) {
    Color upColor,downColor;

    if ( isUp ) {
      upColor = upEdgeColor;
      downColor  = downEdgeColor;
    }
    else {
      upColor = downEdgeColor;
      downColor  = upEdgeColor;
    }

    /* left edge */
    int xpt1[] = { 0 , border+shift, border+shift, 0 , 0 };
    int ypt1[] = { 0 , border+shift, ySize-border+shift, ySize , 0 };
    Polygon p1 = new Polygon(xpt1,ypt1,5);
    g.setColor(upColor);
    g.fillPolygon(p1);

    /* top edge */
    int xpt2[] = { 0 , border+shift, xSize-border+shift, xSize , 0 };
    int ypt2[] = { 0 , border+shift, border+shift, 0 , 0 };
    Polygon p2 = new Polygon(xpt2,ypt2,5);
    g.setColor(upColor);
    g.fillPolygon(p2);

    /* right edge */
    int xpt3[] = { xSize , xSize-border+shift, xSize-border+shift, xSize , xSize };
    int ypt3[] = { 0 , border+shift, ySize-border+shift, ySize , 0 };
    Polygon p3 = new Polygon(xpt3,ypt3,5);
    g.setColor(downColor);
    g.fillPolygon(p3);

    /* bottom edge */
    int xpt4[] = { 0 , border+shift, xSize-border+shift, xSize , 0 };
    int ypt4[] = { ySize , ySize-border+shift, ySize-border+shift, ySize , ySize };
    Polygon p4 = new Polygon(xpt4,ypt4,5);
    g.setColor(downColor);
    g.fillPolygon(p4);

    /* place image on graphic */

    /* Draw lines around 3D edges */
    g.setColor(lineColor);
    g.drawPolygon(p1);
    g.drawPolygon(p2);
    g.drawPolygon(p3);
    g.drawPolygon(p4);

    MediaTracker mt = new MediaTracker(app);
    int id;
    id = 1;
    mt.addImage(gif,id);
    try { mt.waitForID(id); } 
    catch ( InterruptedException e ) { }

    g.drawImage(gif,border+shift,border+shift,xSize-2*border,ySize-2*border,app);
  }

  public ImgButtonImage(String inGifName,int inXSize,int inYSize, int inBorder, Applet app ) {
    Graphics gUp,gDown;
    Image    gif;
    int    shift;
    boolean  isUp;


    gifName  = new String(inGifName);
    xSize    = inXSize;
    ySize    = inYSize;
    border   = inBorder;

    up   = app.createImage(xSize,ySize);
    down = app.createImage(xSize,ySize);


    gUp   =  up.getGraphics();
    gDown =  down.getGraphics();

    System.out.println("getting image "+app.getCodeBase()+gifName);

    gif = app.getImage(app.getCodeBase(),gifName);
    
    shift = (int)(border * shiftPercentage / 100);
    isUp  = true;
    this.fillImage(gUp,gif,shift,isUp,app);

    shift = (int)( -1.*border * shiftPercentage / 100);
    isUp  = false;
    this.fillImage(gDown,gif,shift,isUp,app);
  }

  public Image getUp() {
    return up;
  }

  public int getXsize() {
    return xSize;
  }
  public int getYsize() {
    return ySize;
  }
  public int getBorder() {
    return border;
  }

  public Image getDown() {
    return down;
  }

  boolean IsEqual(String inGifName,int inXSize, 
			     int inYSize, int inBorder) {
    boolean result = true;
    result = result && ( gifName.compareTo(inGifName) == 0 );
    result = result && ( xSize == inXSize);
    result = result && ( ySize == inYSize);
    result = result && ( border == inBorder);
    return result; 
  }
  
}

