import java.net.URL;
import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.util.*;
import java.lang.StringBuffer;
import netscape.applet.Control;

public class Mine extends Applet implements Runnable {
  String JavaVendor = null ;
  boolean onNetscape = false ;
  boolean won=false;
  boolean easy=false;
  boolean medium=false;
  boolean hard=false; 
  boolean custom=true;
  boolean unique=true;
  boolean notunique=true;
  boolean playing=true;
  boolean somethingtosay=false;
  long seed=0;
  long mylong=0;
  int myint=0;
  String para;
  String playerName;
  String message1;
  String message2;
  String message3;
  String level="custom";
  int clockstate=0;
  int tries=0;
  int maxx=50;
  int maxy=50;
  int numberofmines=128;
  int remainingmines=128;
  int timetobeat=1000;
  int[] minearray;
  int[][] myarray;
  ImageButton myinitbutton;
  ImageButton square[][] = new ImageButton[maxx][maxy];
  ImageButton restartButton;
  ImageButton submitButton;
  TextField tfPlayerName = new TextField(15);
  TextField tfRemainingMines = new TextField(4);
  TextField tfSecond = new TextField(4);
  Thread thrSecond = new Thread(this);
  int second=0;
  Image img;
  public static Image hiddenimage;
  public static Image a0image;
  public static Image a1image;
  public static Image a2image;
  public static Image a3image;
  public static Image a4image;
  public static Image a5image;
  public static Image a6image;
  public static Image a7image;
  public static Image a8image;
  public static Image flagimage;
  public static Image mineimage;
  public static Image expmineimage;
  Random myrand = new Random(seed);
  URL scoreURL;

  public void run() {
    System.out.println("now in run");
    Thread current = Thread.currentThread();
    int sleep=0;
    while (true) {
      if (current.equals(thrSecond)) {
        second++;
        tfSecond.setText(""+second);
        if (second%60==0) {repaint();}
      }
      //repaint();
      try {current.sleep(1000);}
      catch (InterruptedException e) {};
    }
  }
  public void start() {
    myrand.setSeed(seed);
    int i=0;
    int j=0;
    int testnumber=0;
    int mynumber=0;
    int myi=0;
    int myj=0;
    int k=0;
    int l=0;
    int m=0;
    int n=0;
    System.out.println("start");
    minearray = new int[numberofmines];
    myarray = new int[maxx][maxy];
    for(i=0;i<numberofmines;i++)
      {             
        minearray[i]=0;
      }    
    for(i=0;i<maxx;i++)
      {
        j=0;
        for(j=0;j<maxy;j++)
          { myarray[i][j] = 0;
          }
      }
    for(k=0;k<numberofmines;k++)
    {
      unique=true;
      while(unique==true)
      {
        mynumber = ((Math.abs(myrand.nextInt()))%(((maxx)*(maxy)-1)))+1;
        myi = mynumber/maxy;
        myj = mynumber%maxy;
        if(myarray[myi][myj]<10)
        {
          unique=false;
        }
      }
      plantmine(myi,myj);
    }
    thrSuspend();
  }
  public void restart() {
    int i=0;
    int j=0;
    int testnumber=0;
    int mynumber=0;
    int myi=0;
    int myj=0;
    int k=0;
    int l=0;
    int m=0;
    int n=0;
    System.out.println("restart");
    playing=true;
    won=false;
    somethingtosay=false;
    remainingmines=numberofmines;
    for(i=0;i<numberofmines;i++)
      {
        minearray[i]=0;
      }
    for(i=0;i<maxx;i++)
      {
        j=0;
        for(j=0;j<maxy;j++)
          { myarray[i][j] = 0;
            square[i][j].setNewImage(9);
          }
      }
    for(k=0;k<numberofmines;k++)
    {
      unique=true;
      while(unique==true)
      {
        mynumber = ((Math.abs(myrand.nextInt()))%(((maxx)*(maxy)-1)))+1;
        myi = mynumber/maxy;
        myj = mynumber%maxy;
        if(myarray[myi][myj]<10)
        {
          unique=false;
        }
      }
      plantmine(myi,myj);
    }
    if(clockstate==1)
      {
        thrSuspend();
        clockstate = 0;
      }
    if(second>0) {second = 0;}
    repaint();
  }

  public void plantmine(int myi, int myj){
    int k=0;
    int l=0;
    System.out.println("plantmine "+myi+" "+myj);
    for(k=-1;k<2;k++)
      {
        for(l=-1;l<2;l++)
          {
            if(((myi+k)>-1)&&((myi+k)<maxx)&&((myj+l)>-1)&&((myj+l)<maxy))
            {
              if(myarray[myi+k][myj+l]<10)
              {
                myarray[myi+k][myj+l]++;
              }
            }
          }
      }
    myarray[myi][myj]=10;
  }
  public void thrStart() {
    System.out.println("thrStart");
    thrSecond.start();
    clockstate = 1;
  }
  public void thrSuspend() {
    System.out.println("thrSuspend");
    thrSecond.suspend();
    clockstate = 0;
  }
  public void thrResume() {
    System.out.println("thrResume");
    System.out.println("resuming thread");
    thrSecond.resume();
    clockstate = 1;
  }
  public void thrStop() {
    System.out.println("thrStop");
    thrSecond.stop();
  }
public void stop () 
{
  removeAll();
}
  public void init() {
  hiddenimage=getImage(getCodeBase(),"hidden.gif");
  a0image=getImage(getCodeBase(),"0.gif");
  a1image=getImage(getCodeBase(),"1.gif");
  a2image=getImage(getCodeBase(),"2.gif");
  a3image=getImage(getCodeBase(),"3.gif");
  a4image=getImage(getCodeBase(),"4.gif");
  a5image=getImage(getCodeBase(),"5.gif");
  a6image=getImage(getCodeBase(),"6.gif");
  a7image=getImage(getCodeBase(),"7.gif");  
  a8image=getImage(getCodeBase(),"8.gif");
  flagimage=getImage(getCodeBase(),"flag.gif");
  mineimage=getImage(getCodeBase(),"mine.gif");
  expmineimage=getImage(getCodeBase(),"expmine.gif");
  JavaVendor = System.getProperty("java.vendor") ;
  String upJavaVendor = JavaVendor.toUpperCase();
  if (upJavaVendor.indexOf("NETSCAPE")>=0) onNetscape = true ;
  if (onNetscape) Control.setAppletPruningThreshold(0);
  System.gc();
    para = getParameter("maxx");
    if (para != null) { maxy = Integer.parseInt(para,10);}
    para = getParameter("maxy");
    if (para != null) { maxx = Integer.parseInt(para,10);}
    para = getParameter("numberofmines");
    if (para != null) { numberofmines = Integer.parseInt(para,10);}
    para = getParameter("playerName");
    if (para != null) { playerName = para;}
    para = getParameter("seed");
    if (para != null) { seed = Long.parseLong(para,10);}
    para = getParameter("timetobeat");
    if (para != null) { timetobeat = Integer.parseInt(para,10);}
    if(numberofmines>(maxx*maxy-1)){numberofmines=maxx*maxy-1;}
    if((maxx==8)&&(maxy==8)&&(numberofmines==10)) { easy=true; custom=false; level="easy"; }
    if((maxx==16)&&(maxy==16)&&(numberofmines==40)) { medium=true; custom=false; level="medium"; }
    if((maxx==16)&&(maxy==30)&&(numberofmines==99)) { hard=true; custom=false; level="hard"; }
    remainingmines = numberofmines;
    second = 0;
    int i=0;
    int j=0;
    setBackground(Color.white);
    Panel controls = new Panel();
    controls.setLayout(new GridLayout(maxx,maxy));
    myinitbutton = new ImageButton(hiddenimage);
    for(i=0;i<maxx;i++)
      {
        for(j=0;j<maxy;j++)
          { 
//            square[i][j] = myinitbutton;//new ImageButton(hiddenimage);
            square[i][j] = new ImageButton();
            controls.add(square[i][j]);
          }
      }
    Panel displays = new Panel();
    restartButton = new ImageButton(getCodeBase(), "dihead.jpg");
    submitButton = new ImageButton(getCodeBase(), "englishflag.gif");
    displays.add(restartButton);
    if(custom==false)
    { displays.add(submitButton); }
    displays.add(tfSecond);
    displays.add(tfRemainingMines);
    displays.add(tfPlayerName);
    add(displays);
    add(controls);
    tfPlayerName.setText(""+playerName);
  }
  public void paint(Graphics g) {
 
    System.out.println("In Mine paint.");
    tfSecond.setText(""+second);
    tfRemainingMines.setText(""+remainingmines);
    if(somethingtosay==true) 
    {
      g.drawString(message1,10,30);
      g.drawString(message2,10,60);
      g.drawString(message3,10,200);
    }
  }
  public void repaint() {
    System.out.println("In Mine repaint.");
                super.repaint();        
  }
  public void youLose() {
    if(clockstate==1){ thrSuspend(); clockstate=0; }
    tries++;
    playing=false;
    somethingtosay=true;
    message1="You stepped on a mine " + playerName + ".";
    message2="The princess is displeased.";
    revealall();
    repaint();
  }
  public boolean checkWin() {
  int k=0;
  int l=0;
  int hidden=0;
  //Win checking
  for(k=0;k<maxx;k++)
  {
    for(l=0;l<maxy;l++)
    {
      if((myarray[k][l]<100)||(myarray[k][l]>199))
        { hidden++;}
    }
  }
  if(hidden==numberofmines) { return true; }
  else { return false; }
  } 
  public void youWin() {
    if(clockstate==1){ thrSuspend(); clockstate=0; }
    revealall();
    tries++;
    remainingmines=0;
    won=true;
    playing=false;
    somethingtosay=true;
    message1="Congratulations, " + playerName + " you win!";
    if((second>timetobeat)&&(easy==true)) {
      message2=second + " centiseconds is a great time.";
      message3="Click on the flag to submit your score.";
    }
    else if(second<=timetobeat) {
      message2="Your time of " + second + "centiseconds sucks.";
    }
    repaint();
  }
  public void revealall() {
    int k=0;
    int l=0;
    for(k=0;k<maxx;k++){
      for(l=0;l<maxy;l++){
        if((myarray[k][l]==10)||(myarray[k][l]==666)) {
          setmineimage(k, l);
        }
      }
    }
  }
  public void setmineimage(int x, int y) {
    if((myarray[x][y]%100)==10) {
      square[x][y].setNewImage(11);
    }
    else if(myarray[x][y]==666) {
      square[x][y].setNewImage(12);
    }
    else if((myarray[x][y]%100)==0) {
      square[x][y].setNewImage(0);
    }
    else if((myarray[x][y]%100)==1) {
      square[x][y].setNewImage(1);
    }
    else if((myarray[x][y]%100)==2) {
      square[x][y].setNewImage(2);
    }
    else if((myarray[x][y]%100)==3) {
      square[x][y].setNewImage(3);
    }
    else if((myarray[x][y]%100)==4) {
      square[x][y].setNewImage(4);
    }
    else if((myarray[x][y]%100)==5) {
      square[x][y].setNewImage(5);
    }
    else if((myarray[x][y]%100)==6) {
      square[x][y].setNewImage(6);
    }
    else if((myarray[x][y]%100)==7) {
      square[x][y].setNewImage(7);
    }
    else if((myarray[x][y]%100)==8) {
      square[x][y].setNewImage(8);
    }
    //    repaint();
  }
  public void revealzero(int x, int y) {
  int i=0;
  int j=0;
  for(i=-1;i<2;i++)
  {
    for(j=-1;j<2;j++)
    {
      if(((i!=0)||(j!=0))&&((x+i)>=0)&&((y+j)>=0)&&((x+i)<maxx)&&((y+j)<maxy))
      {
        if((myarray[x+i][y+j]<100))
        {
          myarray[x+i][y+j]=myarray[x+i][y+j]+100;
          setmineimage(x+i, y+j);
          if((myarray[x+i][y+j]%100)==0)
          {
            revealzero(x+i,y+j);
          }
        }
      }
    }
  }
  }
  public void revealAdjacent(int x, int y) {
  int i=0;
  int j=0;
  for(i=-1;i<2;i++)
  {
    for(j=-1;j<2;j++)
    {
      if(((i!=0)||(j!=0))&&((x+i)>=0)&&((y+j)>=0)&&((x+i)<maxx)&&((y+j)<maxy))
      {
      if(myarray[x+i][y+j]<100) {
        setmineimage(x+i, y+j);
        myarray[x+i][y+j]=myarray[x+i][y+j]+100;
        if(myarray[x+i][y+j]%100==0){
          revealzero(x+i,y+j);
        }
      }
      }
    }
  }
  if(checkWin()==true) {
    youWin();
  }
  }
  public boolean action(Event e, Object o) { 
  int mods = e.modifiers;
  int i=0;
  int j=0;
  int k=0;
  int l=0;
  int m=0;
  int n=0;
  int namelength=0;
  int c=0;
  int myinitialvalue=0;
  int spotted = 0;
  int notrevealed = 0;
  int myi = 0;
  int myj = 0;
  int cryptscore = 0;
  boolean leftButtonFlag = false;
  boolean wrong = false;
  ImageButton PB = (ImageButton) e.target;         
  String tempPlayerName = tfPlayerName.getText();
  String testst;
  playerName = tfPlayerName.getText();
  namelength = playerName.length();
  if(custom==false) {
  if(PB.equals(submitButton)){ 
    if((easy==true)&&(won==true)) {
    {  try
      { 
        testst = playerName.replace(' ','_');
        testst = playerName.replace('(','<');
        testst = playerName.replace(')','>');
        playerName = testst;
        //hidden;
        AppletContext context = getAppletContext();
      URL scoreURL = new URL("http://porter.desy.de/ms/cgi-bin/uncgi.cgi/Mina.cgi/query?level="+level+"&score="+cryptscore+"&playerName="+playerName);
      context.showDocument(scoreURL);
      }
    catch(Exception exc)
      {  showStatus("Error " + exc);
      }
    }
    }//end if easy==true
    if((medium==true)&&(won==true)) {
    {  try
      {
        testst = playerName.replace(' ','_');
        testst = playerName.replace('(','<');
        testst = playerName.replace(')','>');
        playerName = testst;
        //hidden;
        AppletContext context = getAppletContext();
      URL scoreURL = new URL("http://porter.desy.de/ms/cgi-bin/uncgi.cgi/Mina.cgi/query?level="+level+"&score="+cryptscore+"&playerName="+playerName);
      context.showDocument(scoreURL);
      }
    catch(Exception exc)
      {  showStatus("Error " + exc);
      }
    }
    }//end if medium==true
    if((hard==true)&&(won==true)) {
    {  try
      {
        testst = playerName.replace(' ','_');
        testst = playerName.replace('(','<');
        testst = playerName.replace(')','>');
        playerName = testst;
        //hidden;
        AppletContext context = getAppletContext();
      URL scoreURL = new URL("http://porter.desy.de/ms/cgi-bin/uncgi.cgi/Mina.cgi/query?level="+level+"&score="+cryptscore+"&playerName="+playerName);
      context.showDocument(scoreURL);
      }
    catch(Exception exc)
      {  showStatus("Error " + exc);
      }
    }
    }//end if hard==true
  }
  }//end if custom==false

  {
    if(PB.equals(restartButton)){
      restart();
    }
  }
  if(playing==true)
  {
  for(i=0;i<maxx;i++)
  {
    for(j=0;j<maxy;j++)
    { 
      if(PB.equals(square[i][j]))
      {
        m=i;n=j;
        myinitialvalue=myarray[i][j];
        System.out.println("button pressed");
//        System.out.println(PB.toString());
        if ((mods & MouseEvent.META_MASK) != 0) {
          System.out.println ("Right Button Pressed");
        } else if ((mods & MouseEvent.ALT_MASK) != 0) {
          System.out.println ("Middle Button Pressed");
        } else if ((mods & MouseEvent.SHIFT_MASK) != 0) {
          System.out.println ("SHIFT Pressed");
        } else if ((mods & MouseEvent.CTRL_MASK) != 0) {
          System.out.println ("CONTROL Pressed");
        } else if ((mods & MouseEvent.BUTTON1_MASK) != 0) {
          leftButtonFlag=true;
          System.out.println ("Button One Pressed");
        } else if ((mods & MouseEvent.BUTTON2_MASK) != 0) {
          System.out.println ("Button Two Pressed");
        } else if ((mods & MouseEvent.BUTTON3_MASK) != 0) {
          System.out.println ("Button Three Pressed");
        } else {
          leftButtonFlag=true;
          System.out.println ("Left Button Pressed");
        }
        if(leftButtonFlag==true)
        {
          if(myinitialvalue>199)
          { return true; }
          //Lose checking
          if(((myinitialvalue>9)&&(myinitialvalue<100))){
            myarray[i][j]=666;
            youLose();
//            repaint();
            return true;
          }
          //End lose checking
          myarray[i][j]=myarray[i][j]%100+100;
          if((clockstate==0)&&(myarray[i][j]%100<10)){
            if(tries==0){thrStart();}
            if(tries>0) {thrResume();}
            message1 = "";
            message2 = "";
            message3 = "";
          }
          setmineimage(i,j);
          if(myarray[i][j]%100==0) {
            revealzero(i,j);
          }
          repaint();
          if(checkWin()==true) {
            youWin();
            return true;
          }
        }
        if(leftButtonFlag==false) 
        {
          if(myinitialvalue<100) { 
            myarray[i][j]=myarray[i][j]+200;
            remainingmines--;
            square[i][j].setNewImage(10);
          }
          if(myinitialvalue>=200) {
            myarray[i][j]=myarray[i][j]-200;
            remainingmines++;
            square[i][j].setNewImage(9);
          }
          if((myinitialvalue<200)&&(myinitialvalue>=100)) {
            for(k=-1;k<2;k++)
            {
              for(l=-1;l<2;l++)
              {
                if(((k!=0)||(l!=0))&&((i+k)>=0)&&((j+l)>=0)&&((i+k)<maxx)&&((j+l)<maxy))
                {
                  if(myarray[i+k][j+l]==10) {myi=i+k;myj=j+l;}
                  if(myarray[i+k][j+l]>200) {spotted++;
                  if(myarray[i+k][j+l]<209) {
                                              wrong=true;
                                            }}
                  if((myarray[i+k][j+l]<100)||(myarray[i+k][j+l]>200))
                    {notrevealed++;
                    }
                }
              }
            }
            if(notrevealed==(myinitialvalue%100)) {
            for(k=-1;k<2;k++)
            {
              for(l=-1;l<2;l++)
              {
                if(((k!=0)||(l!=0))&&((i+k)>=0)&&((j+l)>=0)&&((i+k)<maxx)&&((j+l)<maxy)&&(myarray[i+k][j+l]<100))
                  {
                    myarray[i+k][j+l]=myarray[i+k][j+l]+200;
                    remainingmines--;
                    square[i+k][j+l].setNewImage(10);
                  }
              }
            }
            }
            if(spotted==(myinitialvalue%100)) {
              if(wrong==false){revealAdjacent(i,j); repaint();}
              if(wrong==true){myarray[myi][myj]=666;youLose();}
            }
        }
      }
        }
      }
    }
  }
    //repaint();
    return true;
  }
}
