import java.net.URL;
import java.awt.*;
import java.lang.String;
import java.lang.Math;
import java.lang.System;
import java.awt.Graphics;
import java.applet.*;
import java.util.Random;
import ImgButton;
import ImgButtonImage;

public class easy extends java.applet.Applet implements Runnable {

  TextField Xsize,Ysize,Mines;
  Label nleft,Time,myMinesHeader,myTimeHeader,myMessage,mySecondMessage,myPlayerNameLabel;
  Choice c;
  int nxButtons,nyButtons,nMines,nl;
  ImgButton[][] it;
  ImgButton restartButton;
  ImgButton firstflagButton;
  ImgButton secondflagButton;
  ImgButtonImage[] Buttons = new ImgButtonImage[16];
  TextField tfPlayerName = new TextField(7);
  int itouch,jtouch, ibutton;
  int[] imines,jmines;
  int[][] matrix;
  int[][] untouched;
  int bd = 4;
  int sz = 16+bd*2,lastsz=0;
  int ntouch;
  long starttime;
  long nowtime;
  boolean firstPaint = true;
  int xmin = 20, ymin = 62+bd*2;
  int maxWidth = 50 , maxHeight=50;
  long tdiff;
  URL scoreURL;
  public final static int mine=9, flag=11 , hidden=13, question=10, expmine=12;
  Thread timer;
  boolean inPlay = true;
  boolean won = false;
  String level="easy";
  long seednum=0;
  String para;
  String playerName;

/*  public String makeGoodString()
  {
    String myTempString = "";
    String kluge = " ?()_";
    int myLength = 0;
    char myTempChar;
    char spacechar;
    char questionmark;
    char leftparen;
    char rightparen;
    char underscore;

    spacechar = kluge.charAt(0);
    questionmark = kluge.charAt(1);
    leftparen = kluge.charAt(2);
    rightparen = kluge.charAt(3);
    underscore = kluge.charAt(4);

    playerName = tfPlayerName.getText();
    playerName = playerName.trim();
    myLength = playerName.length();

    int i=0;
    while(i<myLength)
    { 
      myTempChar = playerName.charAt(i);
      if(myTempChar==spacechar) {
        myTempString = myTempString + "_s";
      }
      else if(myTempChar==questionmark) {
        myTempString = myTempString + "_q";
      }
      else if(myTempChar==leftparen) {
        myTempString = myTempString + "_l";
      }
      else if(myTempChar==rightparen) {
        myTempString = myTempString + "_r";
      }
      else if(myTempChar==underscore) {
        myTempString = myTempString + "_u";
      }
      else {
        myTempString = myTempString + playerName.charAt(i);
      }
      i++;
    }
      
    try
    {System.in.read();}
    catch(Exception le)
    {}
    return myTempString;
  }

  public void startTimer() {
    if ( timer == null ) {
      starttime = System.currentTimeMillis();
      timer = new Thread(this);
      timer.start();
    }
  }*/

  public void start() {
    ;
  }
	
  public void stop() {
    if ( timer != null) {
      timer.stop();
      nowtime = System.currentTimeMillis();
      Time.setText(""+tdiff);
      repaint();
      timer = null;
    }
  }

  public void run() {
    while (true) {
      nowtime = System.currentTimeMillis();
      tdiff = nowtime - starttime;
      Time.setText(""+tdiff);
      try { Thread.sleep(10); }
      catch ( InterruptedException e ) {}
    }
  }

/*  private void doload() {
    if ( lastsz != sz ) {
      lastsz = sz;
      Buttons[0] = new ImgButtonImage("images/0.gif",sz,sz,bd,this);
      Buttons[1] = new ImgButtonImage("images/1.gif",sz,sz,bd,this);
      Buttons[2] = new ImgButtonImage("images/2.gif",sz,sz,bd,this);
      Buttons[3] = new ImgButtonImage("images/3.gif",sz,sz,bd,this);
      Buttons[4] = new ImgButtonImage("images/4.gif",sz,sz,bd,this);
      Buttons[5] = new ImgButtonImage("images/5.gif",sz,sz,bd,this);
      Buttons[6] = new ImgButtonImage("images/6.gif",sz,sz,bd,this);
      Buttons[7] = new ImgButtonImage("images/7.gif",sz,sz,bd,this);
      Buttons[8] = new ImgButtonImage("images/8.gif",sz,sz,bd,this);
      Buttons[9] = new ImgButtonImage("images/mine.gif",sz,sz,bd,this);
      Buttons[10] = new ImgButtonImage("images/question.gif",sz,sz,bd,this);
      Buttons[11] = new ImgButtonImage("images/flag.gif",sz,sz,bd,this);
      Buttons[12] = new ImgButtonImage("images/expmine.gif",sz,sz,bd,this);
      Buttons[13] = new ImgButtonImage("images/hidden.gif",sz,sz,bd,this);
      Buttons[14] = new ImgButtonImage("images/greathead.jpg",50+bd*2,62+bd*2,bd,this);
      Buttons[15] = new ImgButtonImage("images/ukmedium.gif",50+bd*2,25+bd*2,bd,this);
    }
  }


 public int countNeighbors(int i, int j) {
    int ct=0;
    if ( matrix[i][j] == mine ) {
      ct = mine;
    } else {
      for (int k=i-1;k<=i+1;k++) {
	for (int l=j-1;l<=j+1;l++) {
	  if ( k>-1 && k<nxButtons && l>-1 && l<nyButtons && matrix[k][l]== mine) {
	    ct++;
	  }
	}
      }
    }
    return(ct);
  }

  private void layMines() {
    Random r = new Random();
    for (int k=0;k<nMines;k++) {
      boolean newmine = false;
      while ( ! newmine ) {
	int i = Math.abs(r.nextInt()) % nxButtons;
	int j = Math.abs(r.nextInt()) % nyButtons;
	if ( matrix[i][j] == 0 && ((i!=0)&&(j!=0)) ) {
	  // ((i==0)&&(j==0)) top left square is always empty.
	  matrix[i][j] = mine;
	  imines[k] = i;
	  jmines[k] = j;
	  newmine = true;
	}
      }
    }
    for (int i=0;i<nxButtons;i++) {
      for (int j=0;j<nyButtons;j++) {
	matrix[i][j] = countNeighbors(i,j);
      }
    }
  }

  public void donleft() {
    nleft.setText(" "+nl);
  }*/

  public void dosetup() {
/*    doload();*/
    firstPaint = true;
    inPlay = true;

nxButtons = 8;
nyButtons = 8;
nMines = 10;

/*
    itouch = -1;
    jtouch = -1;
    ntouch = 0;
    ibutton= 0;
    nl = nMines;
    it     = new ImgButton[nxButtons][nyButtons];
    restartButton = new ImgButton(Buttons[14],xmin+nxButtons*sz/2-(50+bd*2)/2,ymin-(62+bd*2),true,this);
    firstflagButton = new ImgButton(Buttons[15],xmin,ymin+nyButtons*sz,true,this);
    //    secondflagButton = new ImgButton(Buttons[15],xmin+nxButtons*sz-(50+bd*2),ymin+nyButtons*sz,true,this);
    matrix = new int[nxButtons][nyButtons];
    untouched = new int[nxButtons][nyButtons];
    imines  = new int[nMines];
    jmines  = new int[nMines];
    for (int i=0;i<nxButtons;i++) {
      for (int j=0;j<nyButtons;j++) {
	int x = xmin;
	int y = ymin;
	it[i][j] = new ImgButton(Buttons[hidden],x+j*sz,y+i*sz,true,this);
	matrix[i][j] = 0;
	untouched[i][j] = 0;
      }
    }
    layMines();
    donleft();
    stop();*/
  }

/*  void buildConstraints( GridBagConstraints gbc, int gx, int gy, 
			 int gw, int gh,
			 int wx, int wy) {
    gbc.gridx = gx;
    gbc.gridy = gy;
    gbc.gridwidth = gw;
    gbc.gridheight = gh;
    gbc.weightx = wx;
    gbc.weighty = wy;
  }*/

  public void init() {
/*
    para = getParameter("playerName");
    if (para != null) { playerName = para;}
    para = getParameter("seed");
    if (para != null) { seednum = Long.parseLong(para,10);}

    setBackground(Color.white);

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints con = new GridBagConstraints();
    setLayout(gridbag);

    buildConstraints(con,0,0,1,1,10,0);
    myMinesHeader =  new Label("Mines",Label.CENTER);
    gridbag.setConstraints(myMinesHeader,con);
    add(myMinesHeader);
    buildConstraints(con,1,0,1,1,80,0);
    Canvas can1  =  new Canvas();
    gridbag.setConstraints(can1,con);
    add(can1);
    buildConstraints(con,2,0,1,1,10,0);
    myTimeHeader =  new Label("Time",Label.CENTER);
    gridbag.setConstraints(myTimeHeader,con);
    add(myTimeHeader);

    buildConstraints(con,0,1,1,1,10,0);
    nleft =  new Label("10",Label.LEFT);
    gridbag.setConstraints(nleft,con);
    add(nleft);

    buildConstraints(con,1,1,1,1,80,0);
    Canvas can2  =  new Canvas();
    gridbag.setConstraints(can2,con);
    add(can2);

    buildConstraints(con,2,1,1,1,10,0);
    Time  =  new Label("   0   ",Label.CENTER);
    gridbag.setConstraints(Time,con);
    add(Time);

    buildConstraints(con,0,2,1,1,35,87);
    Canvas can3  =  new Canvas();
    gridbag.setConstraints(can3,con);
    add(can3);
    buildConstraints(con,1,2,1,1,30,87);
    Canvas can4  =  new Canvas();
    gridbag.setConstraints(can4,con);
    add(can4);
    buildConstraints(con,2,2,1,1,35,87);
    Canvas can5  =  new Canvas();
    gridbag.setConstraints(can5,con);
    add(can5);

    buildConstraints(con,0,3,1,1,25,13);
    Canvas can6  =  new Canvas();
    gridbag.setConstraints(can6,con);
    add(can6);
    buildConstraints(con,1,3,1,1,30,13);
    myPlayerNameLabel =  new Label("Name",Label.CENTER);
    gridbag.setConstraints(myPlayerNameLabel,con);
    add(myPlayerNameLabel);
    buildConstraints(con,2,3,1,1,45,13);
    tfPlayerName.setText(""+playerName);
    gridbag.setConstraints(tfPlayerName,con);
    add(tfPlayerName);

    buildConstraints(con,0,4,3,1,100,0);
    myMessage =  new Label("          Click in the top          ",Label.CENTER);
    gridbag.setConstraints(myMessage,con);
    add(myMessage);
    buildConstraints(con,1,4,1,1,0,0);
    Canvas can7  =  new Canvas();
    gridbag.setConstraints(can7,con);
    add(can7);
    buildConstraints(con,2,4,1,1,0,0);
    Canvas can8  =  new Canvas();
    gridbag.setConstraints(can8,con);
    add(can8);

    buildConstraints(con,0,5,3,1,100,0);
    mySecondMessage =  new Label("          left corner to begin.          ",Label.CENTER);
    gridbag.setConstraints(mySecondMessage,con);
    add(mySecondMessage);
    buildConstraints(con,1,5,1,1,0,0);
    Canvas can9  =  new Canvas();
    gridbag.setConstraints(can9,con);
    add(can9);
    buildConstraints(con,2,5,1,1,0,0);
    Canvas can10  =  new Canvas();
    gridbag.setConstraints(can10,con);
    add(can10);

    dosetup()*/;
  }  


  public void recurCheck(int i,int j) {
    if ( i>-1 && i<nxButtons && j>-1 && j<nyButtons && untouched[i][j] == 0) {
      untouched[i][j] = 1;
      ntouch++;
      it[i][j].ChangeImage(Buttons[matrix[i][j]],this);
      if ( matrix[i][j] == 0 ) {
	for (int k=i-1;k<=i+1;k++) {
	  for (int l=j-1;l<=j+1;l++) {
	    if ( k>-1 && k<nxButtons && l>-1 && l<nyButtons && untouched[k][l] == 0 ) {
	      recurCheck(k,l);
	    }
	  }
	}
      }
    }
  }

  public boolean youClicked(int i,int j){
    if ( matrix[i][j] == mine ) {
      untouched[i][j] = 1;
      it[i][j].ChangeImage(Buttons[expmine],this);
      for (int k=0;k<nMines;k++) {
	if ( untouched[imines[k]][jmines[k]] == 0 ) {
	  it[imines[k]][jmines[k]].ChangeImage(Buttons[mine],this);
	}
      }
      return(true);
    } else {
      recurCheck(i,j);
    }
    return(false);
  }

  public boolean doMouseDown(Event evt, int x, int y) {
    if((x>xmin+nyButtons*sz/2-(50+bd*2)/2)&&(x<xmin+nyButtons*sz/2+(50+bd*2)/2)&&(y<ymin)&&(y>ymin-62+bd*2))    {
      return(restartButton.mouseDown(evt,x,y,this));
    }
    if((x>xmin)&&(x<xmin+(50+bd*2))&&(y>ymin+nyButtons*sz)&&(y<ymin+nyButtons*sz+(25+bd*2)))
    {
      return(firstflagButton.mouseDown(evt,x,y,this));
    }
    if ( inPlay ) {
      int j = (x - it[0][0].getX()) / it[0][0].getXsize();
      int i = (y - it[0][0].getY()) / it[0][0].getYsize();
      if((y - it[0][0].getY())<0){i=-1;}
      if((x - it[0][0].getX())<0){j=-1;}
      ibutton = 0;
      if ( i>=0 && i <= nxButtons && j>=0 && j <= nyButtons ) {
	startTimer();
	itouch = i;
	jtouch = j;
	ibutton = 1;
	if ( evt.metaDown() ) {
	  ibutton = 2;
	}
	return(it[i][j].mouseDown(evt,x,y,this));      
      }
    }
    return(false);
  }

  public void YouWin() {
    tdiff = nowtime - starttime;
    myMessage.setText("You won in "+tdiff+" ms.");
    mySecondMessage.setText(" ");
    stop();
    inPlay = false;
    won = true;
  }

  public void YouLose() {
    myMessage.setText("You lose");
    mySecondMessage.setText(" ");
    stop();
    inPlay = false;
  }

  public void SubmitScore()
  {
  long cryptscore = 0;
  String playerName;
  try
    {
      playerName = makeGoodString(); 
      cryptscore=tdiff;   
      AppletContext context = getAppletContext();
      URL scoreURL = new URL("http://porter.desy.de/ms/cgi-bin/uncgi.cgi/Mina.cgi/query?level="+level+"&score="+cryptscore+"&playerName="+playerName);
      context.showDocument(scoreURL);
    }
  catch(Exception exc)
    {  showStatus("Error " + exc);
    }
  }


  public boolean doMouseUp(Event evt, int x, int y) {
    boolean didit = false;
    boolean youlost = false;
    boolean wrong = false;
    int spotted = 0;
    int notrevealed = 0;
    int k = 0;
    int l = 0;
    int myi = 0;
    int myj = 0;
    if((x>xmin+nyButtons*sz/2-(50+bd*2)/2)&&(x<xmin+nyButtons*sz/2+(50+bd*2)/2)&&(y<ymin)&&(y>ymin-62+bd*2))
    {
      won=false;
      dosetup();
      repaint();
      Time.setText("0");
      myMessage.setText("          Click in the top          ");
      mySecondMessage.setText("          left corner to begin.          ");
      return(true);
    }//end if in restartButton
    if((x>xmin)&&(x<xmin+(50+bd*2))&&(y>ymin+nyButtons*sz)&&(y<ymin+nyButtons*sz+(25+bd*2)))
    {
      if(won){SubmitScore();}
      didit = firstflagButton.mouseUp(evt,x,y,this);
      return(didit);
    }//end if in firstflagButton
    if ( inPlay) {
      int j = (x - it[0][0].getX()) / it[0][0].getXsize();
      int i = (y - it[0][0].getY()) / it[0][0].getYsize();
      if((y - it[0][0].getY())<0){i=-1;}
      if((x - it[0][0].getX())<0){j=-1;}
      if ( i>=0 && i <= nxButtons && j>=0 && j <= nyButtons ) {
	if ( itouch == i && jtouch == j ) {
	  if ( ibutton == 1 && untouched[i][j] == 0 ) {
	    youlost = youClicked(i,j);
	  } else if ( ibutton == 2 ) {
	    switch (untouched[i][j] ) {
	    case 0:
	      it[i][j].ChangeImage(Buttons[flag],this);
	      untouched[i][j] = 2;
	      ntouch++;
	      nl--;
	      break;
            case 1:
              for(k=-1;k<2;k++)
		{
		  for(l=-1;l<2;l++)
		    {
		      if(((k!=0)||(l!=0))&&((i+k)>=0)&&((j+l)>=0)&&((i+k)<nxButtons)&&((j+l)<nyButtons))
			{
			  if((untouched[i+k][j+l]==0)&&(matrix[i+k][j+l]==mine))
			    {myi=i+k;myj=j+l;
                            wrong=true;
			    }
			  if(untouched[i+k][j+l]>1) 
			    {spotted++;
			    }
                          if(untouched[i+k][j+l]!=1)
                            {notrevealed++;
                            }
			}
                     }
                 }
                      if(notrevealed==(matrix[i][j]))
                      {
                        for(k=-1;k<2;k++)
                          {
                            for(l=-1;l<2;l++)
                              {
                                if(((k!=0)||(l!=0))&&((i+k)>=0)&&((j+l)>=0)&&((i+k)<nxButtons)&&((j+l)<nyButtons)&&(untouched[i+k][j+l]==0))
                                {

                                  it[i+k][j+l].ChangeImage(Buttons[flag],this);
                                  untouched[i+k][j+l] = 2;
                                  ntouch++;
                                  nl--;
                                }
                              }
                          }

                      }
		      if(spotted==(matrix[i][j])) 
			{ 
       			  if(wrong==false){
			    for(k=-1;k<2;k++)
			      {
				for(l=-1;l<2;l++)
				  {
				    if(((k!=0)||(l!=0))&&((i+k)>=0)&&((j+l)>=0)&&((i+k)<nxButtons)&&((j+l)<nyButtons)&&(matrix[i+k][j+l]<mine)&&(untouched[i+k][j+l]==0)) 
				      {youlost = youClicked(i+k,j+l);}
				  }
			      }
			  }
			  if(wrong==true){matrix[myi][myj]=666;youlost = true;
untouched[myi][myj] = 1;
          it[myi][myj].ChangeImage(Buttons[expmine],this);
      for (int kp=0;kp<nMines;kp++) {
        if ( untouched[imines[kp]][jmines[kp]] == 0 ) {
          it[imines[kp]][jmines[kp]].ChangeImage(Buttons[mine],this);
        }
      }
}
			}
	      untouched[i][j] = 1;
              break;
	    case 2:
	      it[i][j].ChangeImage(Buttons[hidden],this);
	      untouched[i][j] = 0;
	      ntouch--;
	      nl++;
	      break;
	    case 3:
	      it[i][j].ChangeImage(Buttons[hidden],this);
	      untouched[i][j] = 0;
	      ntouch--;
	      nl++;
	      break;
	    default:
	      break;
	    }
	  }
	} 
      }
      if ( itouch>=0 && itouch <= nxButtons && jtouch>=0 && jtouch <= nyButtons ) {
	didit = it[itouch][jtouch].mouseUp(evt,x,y,this);
      }
      donleft();
      if ( ntouch == nxButtons*nyButtons ) {
      if ( nl == 0 ) {
       	YouWin();
      }
      }
      if ( youlost ) {
	YouLose();
      }
      return(didit);
    }
    return(false);
  }

  public boolean handleEvent(Event evt) {
    switch (evt.id) {
    case Event.MOUSE_DOWN:
      return doMouseDown(evt,evt.x,evt.y);
    case Event.MOUSE_UP:
      return doMouseUp(evt,evt.x,evt.y);
    default:
      return(false);
    }
  }

  public void update(Graphics g) {
    //    g.setColor(getBackground());
    //    g.fillRect(0,0,width,height);
    //    g.setColor(getForeground());
    paint(g);
  }

  public void paint(Graphics g) {
    if ( firstPaint ) {
      // this clears old buttons when I make the grid smaller
      g.setColor(getBackground());
      g.fillRect(xmin,ymin,maxWidth*sz,maxHeight*sz);
      g.setColor(getForeground());
      firstPaint = false;
    }
    for (int i=0;i<nxButtons;i++) {
      for (int j=0;j<nyButtons;j++) {
	it[i][j].paint(g);
      }
    }
    restartButton.paint(g);
    firstflagButton.paint(g);
    //    secondflagButton.paint(g);
  }
}
