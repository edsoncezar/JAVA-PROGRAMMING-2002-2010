import java.awt.*;
import java.util.Hashtable;
import ImgButtonImage;
import java.io.*;
import java.applet.Applet;


class ImgButton extends java.applet.Applet {

  public  Image   up,down;
  private boolean isUp;
  private int x,y;
  private boolean clickable;
  private boolean changed;
  private int xSize,ySize,border;
  
  static public Hashtable images = new Hashtable();

  public void init () {
    images.clear();
  }

  public boolean mouseDown(Event evt, int x, int y, Applet app) {
    if ( this.clickable ) {
      isUp = false;
      changed = true;
      app.repaint();
      return true;
    }
    return false;
  }

  public boolean mouseUp(Event evt, int x, int y, Applet app) {
    if ( ! isUp ) {
      isUp = true;
      changed = true;
      app.repaint();
      return true;
    }
    return false;
  }

  public void paint(Graphics g) {
    if ( isUp ) {
      g.drawImage(up,x,y,this);
    } else {
      g.drawImage(down,x,y,this);
    }
    changed = false;
  }

  ImgButton(String inGifName, int inXSize, 
			     int inYSize, int inBorder,
			int inX, int inY,boolean inClickable, Applet app) {
    ImgButtonImage img;
    Integer jj = new Integer(-1);

    for ( int i=0;i<ImgButton.images.size();i++) {
      Integer ii = new Integer(i);
      ImgButtonImage localimg = (ImgButtonImage) ImgButton.images.get(ii);
      if ( localimg.IsEqual(inGifName,inXSize,inYSize,inBorder) ) {
	jj = ii;
      }
    }

    if ( jj.intValue() == -1 ) {
      img = new ImgButtonImage(inGifName,inXSize,inYSize,inBorder,app);
      int i;
      i = ImgButton.images.size();
      Integer ii = new Integer(i);
      ImgButton.images.put(ii,img);
    } else {
      img = (ImgButtonImage) ImgButton.images.get(jj);
    }
    
    up = img.getUp();
    down = img.getDown();

    
    changed = true;
    clickable = inClickable;
    x = inX;
    y = inY;
    xSize = inXSize;
    ySize = inYSize;
    border = inBorder;
    isUp   = true;
  }


  ImgButton(ImgButtonImage im,
	    int inX, int inY,boolean inClickable, Applet app) {
    ImgButtonImage img = im;
    
    up = img.getUp();
    down = img.getDown();
    
    changed = true;
    clickable = inClickable;
    x = inX;
    y = inY;
    xSize = im.getXsize();
    ySize = im.getYsize();
    border = im.getBorder();
    isUp   = true;
  }


  public boolean  getIsUp() {
    return isUp;
  }
  public boolean  getChanged() {
    return changed;
  }
  public void setChanged() {
    changed = false;
  }

  public boolean getClickable() {
    return clickable;
  }
  public void setClickable(boolean val) {
    clickable = val;
  }

  public int  getXsize(){
    return xSize;
  }
  public int getYsize(){
    return ySize;
  }
  public int getBorder(){
    return border;
  }
  public int  getX(){
    return x;
  }
  public int getY(){
    return y;
  }

  public void setX(int inX){
    x = inX;
  }
  public void setY(int inY){
    y = inY;
  }


  public Image getUp() {
    return up;
  }
  public Image getDown() {
    return down;
  }

  public void ChangeImage(String inGifName,Applet app) {
    boolean found = false;
    ImgButtonImage img;
    Integer jj = new Integer(-1);

    for ( int i=0;i<ImgButton.images.size();i++) {
      Integer ii = new Integer(i);
      ImgButtonImage localimg = (ImgButtonImage) ImgButton.images.get(ii);
      if ( localimg.IsEqual(inGifName,xSize,ySize,border) ) {
	jj = ii;
      }
    }

    if ( jj.intValue() == -1 ) {
      img = new ImgButtonImage(inGifName,xSize,ySize,border,app);
      int i;
      i = ImgButton.images.size();
      Integer ii = new Integer(i);
      ImgButton.images.put(ii,img);
    } else {
      img = (ImgButtonImage) ImgButton.images.get(jj);
    }
    up = img.getUp();
    down = img.getDown();
  }




  public void ChangeImage(ImgButtonImage im,
	    Applet app) {
    ImgButtonImage img = im;
    
    up = img.getUp();
    down = img.getDown();
  }

}
