/*
ANButton.java
Version 1.0.0
"Written" by Florian Hars, 14-FEB-1996.

ANButton.class loads up to 10 images. Images 3 to 9 are dispayed in a
sequence when the pointer in located over the button, image0 (if
present) is the normal apperance, image1 is the Background and image2
is the depressed button. The parameters image1, image2 and image3 are
required.
 
"Writing" it means adding a thread taken from the Animator.java-example to:
BFButton.java
Version 1.0.0
Written by Elijah Dean Meeker 1/4/96
BFButton.class(stands for Background/Foreground)is an preloading interactive
button that loads two or three images (based on whether or not image0 is a
parameter) and a background image. Clicking it navigates to the given URL. It
uses off-screen buffering to avoid flicker. Here are two valid applet tags:

Two states:
<APPLET 
codebase="classes" 
CODE="ANButton.class" WIDTH=130 HEIGHT=98>		    SIZE of button images
<PARAM NAME="image1" VALUE="images/tvbg.jpg">		    BACKGROUND image
<PARAM NAME="image2" VALUE="images/tvdn.jpg">		    DOWN image
<PARAM NAME="image3" VALUE="images/tvup1.jpg">		    UP image(s)
...
<PARAM NAME="image9" VALUE="images/tvup9.jpg">
<PARAM NAME="pause" VALUE="200">                            Pause between images in ms (optinal, defaults to 200)
<PARAM NAME="x" VALUE="19">				    LEFT pos. to draw sub-images
<PARAM NAME="y" VALUE="19">				    TOP pos. to draw sub-images
<PARAM NAME="dest" VALUE="http://www.math.uni-hamburg.de/~fm5a014/">URL to navigate to 
</APPLET>

Three states:
<APPLET 
codebase="classes" 
CODE="ANButton.class" WIDTH=130 HEIGHT=98>		    SIZE of button images
<PARAM NAME="image0" VALUE="images/tvrg.jpg">		    NORMAL image
<PARAM NAME="image1" VALUE="images/tvbg.jpg">		    BACKGROUND image
<PARAM NAME="image2" VALUE="images/tvdn.jpg">		    DOWN image
<PARAM NAME="image3" VALUE="images/tvup.jpg">		    UP image(s)
...
<PARAM NAME="image9" VALUE="images/tvup9.jpg">
<PARAM NAME="pause" VALUE="200">                            Pause between images in ms (optinal, defaults to 200)
<PARAM NAME="x" VALUE="19">				    LEFT pos. to draw sub-images
<PARAM NAME="y" VALUE="19">				    TOP pos. to draw sub-images
<PARAM NAME="dest" VALUE="http://www.math.uni-hamburg.de/~fm5a014/">URL to navigate to 
</APPLET>


Please feel free to use and improve this code. It would not be here but for the
freely given help of others. I would love to see your improvements.
Elijah.

elijah@bga.com
http://www.realtime.net/~elijah/ 

The same things are valid for me.
Florian.

hars@math.uni-hamburg.de
http://www.math.uni-hamburg.de/~fm5a014 */

import java.awt.* ;
//import java.awt.Graphics;
//import java.awt.Event;
//import java.awt.Image;
import java.awt.MediaTracker;
import java.net.URL;
import java.net.MalformedURLException;
import java.lang.InterruptedException;
import java.applet.Applet;



public class ANButton extends java.applet.Applet implements Runnable{
    
    private	MediaTracker tracker;
    private	Image buf;
    private	Image bg;
    private	Image img[] = new Image[10];
    private	int X,Y;
    private	Graphics offscreen;
    private	Dimension d;
    private	boolean onButt = false;
    private	boolean pressedButt = false;
    private	boolean three_state = true;
    private     boolean userPause = true;
    private	int onIs = 0;
    private int animImg = 3;
    private int maxImg = 3;
    private int pause = 200;
    private	URL clickDest;
    private	String dest;
    private String destDefault = "http://www.math.uni-hamburg.de/math/ign/";

    /**
     * The thread animating the images.
     */
    private Thread engine = null;



/****************************STATE CHANGES*************************************/
    public void init() {
	String istr;
	d = size();
	buf= createImage(d.width,d.height);
	offscreen = buf.getGraphics();
	int i = 0;
	boolean finished = false;
	
	tracker = new MediaTracker(this);
	
	while (!finished && i<10) {
	    istr = getParameter("image"+i);
	    if (istr == null){
		if(i>0){
		    finished = true;
		}else{
		    three_state = false;
		    onIs = 3;
		}
	    }else{
		if (i==0) {
		    three_state = true;
		}
		showStatus("Loading image "+istr+".");
		img[i] =  getImage(getCodeBase(),istr);
		tracker.addImage(img[i], 0);
		try {
		    tracker.waitForAll();
		} catch (InterruptedException e) {
		    System.out.println("Error waiting for image"+i+" to load");
		}//end catch
	    }//end if
	    i++;
	}//end while
	maxImg = i-2;
	if (maxImg < 3) {
	    System.out.println("Need at least images 1 to 3: Check Applet Tag.");
	    for (i = maxImg + 1; i < 4 ; i++) {
		img[i]=img[1];
	    }
	    maxImg = 3;
	}
	istr = getParameter("x");
	X = (istr != null) ? Integer.parseInt(istr) : 0;
	istr = getParameter("y");
	Y = (istr != null) ? Integer.parseInt(istr) : 0;
	istr = getParameter("pause");
	pause = (istr != null) ? Integer.parseInt(istr) : 200;
	istr = getParameter("dest");
	dest = (istr != null) ? istr : destDefault;
	try{
	    clickDest = new URL(dest);
	}catch(MalformedURLException mal){
	    System.out.println("Malformed URL: Check Applet Tag.");
	}
	
    }//end init


    public void start(){
	if (engine == null && !userPause) {
	    engine = new Thread(this);
	    engine.start();
	}
    }//end start
    
  public void stop(){
      if (engine != null && engine.isAlive()) {
	  engine.stop();
     }
      engine = null;
  }//end stop
    
    public void destroy(){
    }//end destroy
/****************************END STATE CHANGES********************************/
/*******************************EVENTS****************************************/
    
    public boolean mouseDown(Event e, int x, int y){
	if (engine != null && engine.isAlive()) {
	    userPause = true;
	    engine.suspend();
	    stopPlaying();
	}
	pressedButt = true;
	repaint();
	
	return(true);
    }//end mouseDown
    
    public boolean mouseUp(Event e, int x, int y){
	
	if(pressedButt && onButt){
	    pressedButt = false;
	    repaint();
	    getAppletContext().showDocument(clickDest);
	}else{
	    pressedButt = false;
	    repaint();
	}
	return(true);
    }//end mouseUp
    
    public boolean mouseEnter(Event e, int x, int y){
	onButt = true;
	userPause = false;
	if (engine != null && engine.isAlive()) {
	    engine.resume();
	    startPlaying();
	} else {
	    engine = new Thread(this);
	    engine.start();
	    startPlaying();
	}

	repaint();
	showStatus(dest);
	return(true);
    }//end mouseEnter
    
    public boolean mouseExit(Event e, int x, int y){
	onButt = false;
	userPause= true;
	if (engine != null && engine.isAlive()) {
	    engine.suspend();
	    stopPlaying();
	}

    	repaint();
	showStatus("");
	
	return(true);
    }//end mouseExit
    
/*******************************END EVENTS*************************************/
/*******************************METHODS****************************************/
    void startPlaying() {
    }
    
    void stopPlaying() {
    }
    
    public void run() {
	Thread me = Thread.currentThread();
	
	me.setPriority(Thread.MIN_PRIORITY);
	
	while (engine == me) {
	    try {	 
		Thread.sleep(pause);
	    } catch (InterruptedException e) {
		// Should we do anything?
	    }
	    animImg += 1;
	    if (animImg > maxImg) {
		animImg=3;
	    }
	    repaint();
	}
    }
    
    public  void update(Graphics g){
	if(!onButt) {
	    if(three_state) {
		onIs = 0;
	    } else {
		onIs = 3;
	    }
	}
	else if (onButt && !pressedButt) {
			onIs = 3;
	}
	else {
	    onIs = 2;
	}

	paint(g);

    }//end update

    public void paint(Graphics g){
	if (offscreen != null) {
	    paintApplet(offscreen);
	    g.drawImage(buf, 0, 0, this);
	} else {
	    paintApplet(g);
	}
	
    }//end paint
    
    public void paintApplet(Graphics g) {
	int pic;
	
	pic = onIs;
	if (onIs == 3) {
	    pic = animImg;
	}
	g.drawImage(img[1],0,0,null);
	g.drawImage(img[pic],X,Y,null);
    }

/*****************************END METHODS**************************************/

}//end class ANButton




