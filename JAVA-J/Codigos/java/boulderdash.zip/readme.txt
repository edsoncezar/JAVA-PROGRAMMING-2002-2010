Use these two lines to compile and run:

javac Boulderdash.java

appletviewer play.html
