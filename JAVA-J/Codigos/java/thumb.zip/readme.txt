Free JAVA applet by Stig Christensen, Copenhagen Marts 2000
Homepage: www.stigc.dk
E-mail: stig@stigc.dk

-------------------------------------------------------------

This applet is free and for use anywhere. 
The HTML-tags is like this (an example with 3 links):

<applet code="thumb.class" width=250 height=450>
<param name = "text1" value ="Page 1">
<param name = "text2" value ="Page 2">
<param name = "text3" value ="Page 3">
<param name = "link1" value ="page1.htm">
<param name = "link2" value ="page2.htm">
<param name = "link3" value ="page3.htm">
<param name = "background_color" value ="000,000,000">
<param name = "text_color" value ="000,255,000">
<param name = "text_antialising_color" value ="000,100,000">
<param name = "fontsize" value ="22">
<param name = "fontface" value ="Century Gothic">
<param name = "target" value ="aktion">
<param name = "loading_message" value ="loading...">
</applet>

-------------------------------------------------------
Decription og some of the parameters:

text1 .... textX    :   defines the text for each button
link1 .... linkX    :	defines the links for each button	
	
target		    :	difines how to open the links.
			could be "_self", "_blank" or a name
			of a frame on your site.

---------------------------------------------------------

You can not change the space between the buttons.......

