

import java.applet.*;
import java.awt.*;

/*
@Author: Ajit Kumar (ajit@omnikron.com)
@Date: Jan 96
@Version: 0.1
@Description : A simple animation applet to demonstrate use of threads.
*/


/* SpinTop class */
public class SpinTop extends Applet implements Runnable {
	Thread spinThread = null;
	Image img[] = new Image[18];
	int counter =  0;
	int clockwise = 1;
	
	/* class initialization */
	public void init() {
		int i;
		for (i=0;i<18;i++) {
			img[i]=getImage(getCodeBase(),"tops"+i+".gif");
		}
	}

	/* Next Spin image */
	public void nextSpin(){
			if (clockwise==1) {
				counter = counter + 1;
				if (counter == 18) {
					counter = 0;
				}
			}
			else {
				counter = counter -1;
				if (counter < 0) {
					counter = 17;
				}
			}
	}
	
	/* draw the Spin image */
	public void update(Graphics g) {
		g.drawImage(img[counter],0,0,this);
	}

	/* start the thread */
	public void start() {
		if (spinThread == null) {
			spinThread = new Thread(this);
			spinThread.start();
		}
	}

	/* stop the thread */
	public void stop() {
		if (spinThread!=null) {
			spinThread.stop();
			spinThread = null;
		}
	}

	/* applet's run() method */		
	public void run() {
		while (spinThread != null) {
			repaint();
			try {
			   spinThread.sleep(75);
			}
			catch(InterruptedException e) {
			}
			nextSpin();
		}
	}

	/* handle MOUSE_DOWN event */
	public boolean handleEvent(Event e){
		if (e.id == Event.MOUSE_DOWN) {
			clockwise = 1 - clockwise;
		}
	return true;
	}
}