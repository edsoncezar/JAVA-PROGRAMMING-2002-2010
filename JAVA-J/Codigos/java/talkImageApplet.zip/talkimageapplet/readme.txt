TalkImageApplet Readme

The TalkImageApplet is a simple Java 1.0 applet that 
allows you to present an image, and animate cartoon-style
word bubbles with a selection of phrases.  This is suitable
for use as humor, political satire, religious instruction,
etc.  The applet uses a fairly large set of parameters to
configure the phrases, their locations, timing, and more.

To use TalkImageApplet, you need to follow these steps:

   1. Select the image that you would like to 'talk'
   2. Decide on one or more spots where you'd like
      the word bubbles to originate from, and the
      corresponding spots where you'd like the 
      word bubbles to appear.
   3. Put the applet tag into your HTML file, as
      follows:
         <applet code="TalkImageApplet" width=400 height=500>

   4. Write the parameter tags for the phrases you
      want to appear in the word bubbles.  You'll have
      several kinds of parameter tags:

      - imageURL	 the image to be displayed
      - cycles		 number of repetitions, 0 for infinite
      - cycleTimeMin	 minimum time a word bubble will stay up
				 (in milliseconds)
      - cycleTimeMax	 maximum time a word bubble will stay up
      - spaceTimeMin	 minimum time between word bubbles
				 (in seconds)
      - spaceTimeMax	 maximum time between word bubbles
      - fontName	 Font to use for words (usually "Courier")
      - defFontSize	 Default font size (usually 11)
      - wordbackground	 Color for word bubbles (hex, usually FFFFFF)
      - background	 Margin color around the image (CCFFFFF)
      - endpoint0	 First wordbubble end point (e.g. "180,57")
      - endpoint1	 Second wordbubble end point
      - endpoint2,3,4..	 subsequent end points
      - centerpoint0	 First top left wordbubble location ("241,0")
      - centerpoint1	 Second top left wordbubble location
      - centerpoint2,3.. subsequent wordbubble locations
      - message0	 First wordbubble message
      - message1	 Second wordbubble message
      - message2,3,4..	 subsequent wordbubble messages


The messages can be a single line, or they can be designated
as multiple lines with vertical bar characters, like 
this "Line1|Line2".

Simply check out the example packed with this distribution for more
imformation about setting up the parameters.
