/*
 *  TestaPooledConnectionFactory.java - Short Description
 *  Copyright (C) 15 de Fevereiro de 2003 author
 *  email
 *  webaddress
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import javax.swing.*;
import java.io.*;
import java.sql.*;
import java.util.*;
/**
 *  Um teste para a classe ConnectionFactory
 *
 *@author     Cl�udio Marcelo Silva - AOPEC
 *@created    3 de Fevereiro de 2003
 */
public class TestaPooledConnectionFactory {
	/**
	 *  M�todo main da classe de teste. Este m�todo poderia estar na pr�pria
	 *  ConnectionFactory, tornando-a execut�vel, mas isso tornaria sua
	 *  documenta��o deselegante e confusa.
	 *
	 *@param  args  parametros de linha de comando n�o s�o usados.
	 */
	public static void main(String args[]) {
		try {
			//Criando um di�logo de arquivos swing!
			JFileChooser jfile = new JFileChooser();
			/*
			 *  Criando um objeto de filtro de arquivos para o
			 *  objeto JFileChooser. Um filtro limita os arquivos
			 *  que podem ser exibidos no di�logo.
			 *  O filtro � criado implementando a classe abstrata
			 *  javax.swing.filechooser.Filter.
			 */
			jfile.setFileFilter(
				new javax.swing.filechooser.FileFilter() {
					/*
					 *  M�todo que informa se um arquivo
					 *  pode ou n�o ser exibido.
					 */
					public boolean accept(File f) {
						/*
						 *  Se o "arquivo" for um diret�rio
						 *  pode ser mostrado.
						 */
						if (f.isDirectory()) {
							return true;
						}
						/*
						 *  Dando parse no nome do arquivo para
						 *  extrair sua extens�o.
						 */
						StringTokenizer stk = new StringTokenizer(f.getName(), ".");
						String extension = null;
						//avan�a ao �ltimo token e o extrai.
						if (stk.countTokens() > 0) {
							for (int i = 0; i < stk.countTokens() - 1; i++) {
								stk.nextToken();
							}
							extension = stk.nextToken();
						}
						//Se .properties, ok.
						if (extension != null) {
							if (extension.equals("properties")) {
								return true;
							} else {
								return false;
							}
						}
						return false;
					}


					//M�todo que descreve o filtro.
					public String getDescription() {
						return "arquivos de propriedade (*.properties)";
					}

				});
			//Loop at� que se escolha um arquivo.
			while (true) {
				if (jfile.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					//Extrai o caminho completo do arquivo
					File f = jfile.getSelectedFile();
					//Cria a f�brica e uma conex�o.
					PooledConnectionFactory factory = new PooledConnectionFactory(f);
					Connection c = factory.getConnection();
					if (c != null) {
						JOptionPane.showMessageDialog(null, "Conex�o bem sucedida!");
						//fechando uma conex�o.:
						c.close();
						//Pedindo mais de 10 conex�es:
						//(Tamanho do pool em bd.properties)
						Connection[] overCon = new Connection[11];
						for (int i = 0; i < 11; i++) {
							overCon[i] = factory.getConnection();
						}
						//Devolvendo as conex�es feitas:
						for (int i = 0; i < 11; i++) {
							overCon[i].close();
						}
						//Vc. tem que fechar a factory, com o pool.
						factory.closePool();
						System.exit(0);

					}
					break;
				} else {
					JOptionPane.showMessageDialog(null, "Vc. deve escolher um arquivo de configura��o para continuar.");
				}
			}

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "" + e.getMessage(), e.getClass().getName(), JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}

