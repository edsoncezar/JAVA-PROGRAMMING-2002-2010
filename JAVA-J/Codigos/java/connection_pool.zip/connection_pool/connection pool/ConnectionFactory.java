/*
 *  ConnectionFactory.java - Short Description
 *  Copyright (C) 15 de Fevereiro de 2003 author
 *  email
 *  webaddress
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import java.util.*;
import java.io.*;
import java.sql.*;

/**
 *  F�brica simples de conex�es, configurada mediante um arquivo de propriedades
 *
 *@author     Cl�udio Marcelo Silva, AOPEC
 *@created    1 de Fevereiro de 2003
 */
public class ConnectionFactory {
	/**
	 *  Armazena as configura��es para a cria��o de conex�es
	 */
	protected Properties conProp;


	/**
	 *  Construtor da f�brica de conex�es.<br>
	 *  Espera um arquivo de propriedades com o seguinte conte�do:<br>
	 *
	 *  <UL>
	 *    <LI> driver = [nome completo da classe do driver JDBC</LI>
	 *    <LI> url = [URL completa de conex�o].</LI>
	 *    <LI> user = [Usu�rio para acesso ao esquema desejado.]</LI>
	 *    <LI> password = [senha do usu�rio]</LI>
	 *  </UL>
	 *
	 *
	 *@param  config           Objeto java.io.File que cont�m refer�ncia para o
	 *      arquivo de propriedades
	 *@exception  IOException  Description of the Exception
	 */
	public ConnectionFactory(File config) throws IOException {
		//Abre um InputStream para o arquivo de propriedades
		FileInputStream input = new FileInputStream(config);
		//A cole��o Properties (uma esp�cie de mapa)..
		conProp = new Properties();
		//... pode carregar seus dados diretamente de um arquivo.
		conProp.load(input);
		//Fechar o stream de leitura do arquivo.
		input.close();
	}


	/**
	 *  Retorna uma conex�o pr�-configurada.
	 *
	 *@return                             conex�o.
	 *@exception  SQLException            Se qualquer falha na cria��o da conex�o
	 *      ocorre.
	 *@exception  ClassNotFoundException  Se o driver configurado n�o existe no
	 *      classpath.
	 *@exception  InstantiationException  Description of the Exception
	 *@exception  IllegalAccessException  Description of the Exception
	 */
	public Connection getConnection() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		//Carrega da classe do driver na mem�ria, executando seu construtor.
		Class.forName(conProp.getProperty("driver")).newInstance();
		//Cria a conex�o a partir das informa��es existentes no objeto de propriedades
		Connection c = DriverManager.getConnection(
				conProp.getProperty("url"),
				conProp.getProperty("user"),
				conProp.getProperty("password")
				);
		return c;
	}
}

