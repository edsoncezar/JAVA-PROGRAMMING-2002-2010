// Abstract space
// Copyright (C) 2002 Charles Foster
// Please visit www.cfoster.net

import java.awt.*;
import java.applet.*;

public class AbstractSpace extends Applet implements Runnable
{
	double[][] stars;
	double centerx, centery;

	Thread myThread = null;
	Image myImage = null;
	Graphics g2;

	boolean clicked = false;
	boolean credits = true;

	double speedx = 0.02, speedy = 0.02, angrot = 0.05;
	double oldx = 0, oldy = 0;
	int stramt, j;

	public void init()
	{
		centerx = (int)size().width/2;
		centery = (int)size().height/2;
		getParameters();
		for(int i=0;i<stars.length;i++)
		{
			buildStar(i);
		}
		myImage = createImage(size().width,size().height);
		g2 = myImage.getGraphics();
	}
	public void getParameters()
	{
		speedx = (double)(Integer.parseInt(getParameter("speedx")))/100;
		speedy = (double)(Integer.parseInt(getParameter("speedy")))/100;
		angrot = (double)(Integer.parseInt(getParameter("angrot")))/100;
		stramt = Integer.parseInt(getParameter("stramt"));
		stars = new double[stramt][6];
	}
	public void buildStar(int s)
	{
		stars[s][0] = 0;
		stars[s][1] = 0;

		stars[s][2] = 0;
		stars[s][3] = 0;

		stars[s][4] = Math.random()*360; // angle to start
		stars[s][5] = Math.random()*size().width*2; // life expectancy
	}
	public void start()
	{
		if(myThread == null)
		{
			myThread = new Thread(this);
			myThread.start();
		}
	}
	public void stop()
	{
		if(myThread != null)
		{
			myThread.stop();
			myThread = null;
		}
	}
	public void run()
	{
		while(true)
		{
			g2.setColor(Color.black);
			g2.fillRect(0,0,size().width,size().height);
			if(credits)
			{
				g2.setColor(Color.green);
				g2.drawString("Abstract Space, Copyright (C) Charles Foster 2002",20,20);
				g2.drawString("www.cfoster.net",20,35);
				if(++j > 400) { credits = false; }
			}
			g2.setColor(Color.white);
			for(int i=0;i<stars.length;i++)
			{
				if(!clicked)
				{
					if(stars[i][0] > stars[i][5]) { buildStar(i); }
					stars[i][0] = Math.cos(oldx+stars[i][4])*stars[i][2]*180/Math.PI+centerx;
					stars[i][1] = Math.sin(oldy+stars[i][4])*stars[i][3]*180/Math.PI+centery;
					stars[i][2] += speedx;
					stars[i][3] += speedy;
					stars[i][4] += angrot;
				}
				else
				{
					stars[i][0] = Math.cos(oldx+stars[i][4])*stars[i][2]*180/Math.PI+centerx;
					stars[i][1] = Math.sin(oldy+stars[i][4])*stars[i][3]*180/Math.PI+centery;
				}
				g2.fillRect((int)stars[i][0],(int)stars[i][1],2,2);
			}
			repaint();
			try { myThread.sleep(25); } catch(InterruptedException e) {}
		}
	}
	public boolean mouseDrag(Event evt,int x,int y)
	{
		clicked = true;
		oldy = (double)(y-oldy)/180*Math.PI;
		oldx = (double)(oldx-x)/180*Math.PI;
		return true;
	}
	public boolean mouseUp(Event e, int x, int y)
	{
		clicked = false;
		return true;
	}
	public void paint(Graphics g){}
	public void update(Graphics g)
	{
		paint(g2);
		g.drawImage(myImage, 0, 0, this);
	}
}