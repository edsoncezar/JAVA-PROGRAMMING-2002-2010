/*
 * Blackboard.java
 *
 * Copyright (c) 1999 by R�diger Appel, All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * See also: http://www.3quarks.com
 *
 */


import java.applet.*;
import java.awt.*;
import java.util.*;


public class Blackboard extends Applet implements Runnable
  {
  private Thread  loader      = null;
  private boolean allLoaded   = false;
  private Image   buffer      = null;
  private Image   background  = null;
  private Image   textImage[] = null;
  private int     textCount   = 14;
  private int     textLine1[] = { 0, 2, 8, 5,  9, 12 };
  private int     textLine2[] = { 1, 3, 8, 6, 10, 12 };
  private int     textLine3[] = { 1, 4, 8, 7, 11, 13 };
  private int     language    = 0;
  

  public Blackboard ()
    {
    // write applet info
    System.out.println (getAppletInfo ());
    }
  
  
  public String getAppletInfo ()
    {
    // return my copyright notice
    return "Blackboard, Version 1.0"
         + System.getProperty ("line.separator")
         + "Copyright (c) 1999 by R�diger Appel, All Rights Reserved" 
         + System.getProperty ("line.separator")
         + "See also: http://www.3quarks.com";
    }


  public void init ()
    {
    // get and set background parameters
    Color backgroundColor = getColorParameter ("BackgroundColor");
    if (backgroundColor != null)
      setBackground (backgroundColor);
    
    // get language
    try
      {
      if (getParameter ("Language").trim ().equalsIgnoreCase ("Deutsch"))
        language = 1;
      }
    catch (Exception exception) {}
    
    // initialize german text lines
    if (language == 1)
      {
      textLine1[2] = 5;
      textLine2[2] = 6;
      textLine3[2] = 7;
      textLine1[3] = 8;
      textLine2[3] = 8;
      textLine3[3] = 8;
      }
    }


  private Color getColorParameter (String name)
    {
    // return a color parameter 
    try 
      {
      StringTokenizer tokenizer = new StringTokenizer (getParameter (name), ",");

      switch (tokenizer.countTokens ())
        {
        case 1:
          {
          String value = tokenizer.nextToken ().trim ();
          if ((value.length () == 7) && (value.charAt (0) == '#'))
            return new Color (Integer.parseInt (value.substring (1, 3), 16),
                              Integer.parseInt (value.substring (3, 5), 16),
                              Integer.parseInt (value.substring (5, 7), 16));
          }
        case 3:
          return new Color (Integer.parseInt (tokenizer.nextToken ().trim ()),
                            Integer.parseInt (tokenizer.nextToken ().trim ()), 
                            Integer.parseInt (tokenizer.nextToken ().trim ()));
        }
      }
    catch (Exception exception) {}
      
    return null;
    }


  public void update (Graphics graphics)
    {
    paint (graphics);
    }


  public void paint (Graphics graphics)
    {
    // get applet size
    int width  = size ().width;
    int height = size ().height;

    // create buffer if not exist
    if (buffer == null)
      buffer = createImage (width, height);

    // get buffer graphics
    Graphics bufferGraphics = buffer.getGraphics ();
    bufferGraphics.clipRect (0, 0, width, height);

    // fill background
    bufferGraphics.setColor (getBackground ());
    bufferGraphics.fillRect (0, 0, width, height);

    // draw background
    if (background != null)
      {
      int backgroundWidth  = background.getWidth  (this);
      int backgroundHeight = background.getHeight (this);
      for (int x = 0; x < width; x += backgroundWidth)
        for (int y = 0; y < height; y += backgroundHeight)
          bufferGraphics.drawImage (background, x, y, this);
      }
    
    // draw text lines
    if (textImage != null)
      {
      paintTextLine (bufferGraphics, 17, 16, textLine1);
      paintTextLine (bufferGraphics, 17, 45, textLine2);
      paintTextLine (bufferGraphics, 17, 74, textLine3);
      }

    // paint buffer
    graphics.drawImage (buffer, 0, 0, this);
    }

    
  public void paintTextLine (Graphics graphics, int x, int y, int textLine[])    
    {
    // check text line
    if (textLine == null)
      return;
    
    // draw text
    for (int index = 0; index < textLine.length; index++)
      {
      // get image index
      int imageIndex = textLine[index];
      
      // check image index
      if ((imageIndex >= 0) && (imageIndex < textImage.length))
        {
        // check image
        if (textImage[imageIndex] != null)
          {
          // paint image
          graphics.drawImage (textImage[imageIndex], x, y, this);
          
          // update x position
          x += textImage[imageIndex].getWidth (this);
          }
        }
      }
    }

 
  public boolean action (Event event, Object what)
    {
    String source = (String) what;
    
    // set color
    if (source.equalsIgnoreCase ("RedButton"))
      {
      textLine1[1] = 2;
      textLine2[1] = 3;
      textLine3[1] = 4;
      }
    else if (source.equalsIgnoreCase ("YellowButton"))
      {
      textLine1[1] = 3;
      textLine2[1] = 4;
      textLine3[1] = 2;
      }
    else if (source.equalsIgnoreCase ("GreenButton"))
      {
      textLine1[1] = 4;
      textLine2[1] = 2;
      textLine3[1] = 3;
      }
    else
      return super.action (event, what);
    
    if (Math.random () > 0.5)
      {
      int temp = textLine2[1];
      textLine2[1] = textLine3[1];
      textLine3[1] = temp;
      }
      
    // set random condition
    randomize ((language == 1) ? 2 : 3, 5, 6, 7);
      
    // set random action
    randomize (4, 9, 10, 11);
    
    // repaint canvas
    repaint ();
    
    return super.action (event, what);
    }


  public void randomize (int index, int value1, int value2, int value3)
    {
    switch (new Double (Math.random () * 3.0).intValue ())
      {
      case 0:  textLine1[index] = value1;
               textLine2[index] = value2;
               textLine3[index] = value3;
               break;
      case 1:  textLine1[index] = value2;
               textLine2[index] = value3;
               textLine3[index] = value1;
               break;
      default: textLine1[index] = value3;
               textLine2[index] = value1;
               textLine3[index] = value2;
      }
    
    if (Math.random () > 0.5)
      {
      int temp = textLine2[index];
      textLine2[index] = textLine3[index];
      textLine3[index] = temp;
      }
    }
    
  
  public void start ()
    {
    // initialize textlines
    textLine1[1] = 2;
    textLine2[1] = 3;
    textLine3[1] = 4;
    textLine1[4] = 9;
    textLine2[4] = 10;
    textLine3[4] = 11;

    if (language == 1)
      {
      textLine1[2] = 5;
      textLine2[2] = 6;
      textLine3[2] = 7;
      }
    else
      {
      textLine1[3] = 5;
      textLine2[3] = 6;
      textLine3[3] = 7;
      }
      
    // start loader
    if (!allLoaded)
      {
      loader = new Thread (this);
      loader.start ();
      }
    }


  public void stop ()
    {
    // stop loader
    if (loader != null)
      {
      loader.stop ();
      loader = null;
      }
    }


  public void run ()
    {
    if (Thread.currentThread () == loader)
      {
      // load all images
      MediaTracker tracker = new MediaTracker (this);

      background = loadImage (tracker, getParameter ("BackgroundImage"), 1);
      if (background != null)
        repaint ();
      
      String imagePrefix = getParameter ("ImagePrefix");
      if (imagePrefix != null)
        {
        textImage = new Image[textCount];
        for (int index = 1; index <= textCount; index++)
          {
          String imageName = imagePrefix + ((index < 10) ? "0" : "") + index + ".gif";
          textImage[index - 1] = loadImage (tracker, imageName, 1 + index);
          }
          
        repaint ();  
        }
      
      allLoaded = true;
      }
    }

  
  private Image loadImage (MediaTracker tracker, String name, int identifier)
    {
    // load an image
    if (name != null)
      {
      Image image = getImage (getCodeBase (), name);
      tracker.addImage (image, identifier);
      try 
        {
        tracker.waitForID (identifier);
        if (!tracker.isErrorID (identifier))
          return image;
        }
      catch (InterruptedException exception) {}
      }

    return null;
    }


  }