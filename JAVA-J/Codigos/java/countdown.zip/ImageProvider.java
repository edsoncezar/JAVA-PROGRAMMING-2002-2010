import java.applet.*;
import java.awt.*;

class ImageProviderException extends Exception
{
	public ImageProviderException(String string)
	{
		super(string);
	}
}

public class ImageProvider
{
	private Applet applet;
	private MediaTracker mediaTracker;

	public ImageProvider(Applet applet)
	{
		this.applet=applet;
		mediaTracker=new MediaTracker(applet);
	}

	public Image get(String filename) throws InterruptedException,ImageProviderException
	{
		Image image=applet.getImage(applet.getCodeBase(),filename);

		mediaTracker.addImage(image,0);
		mediaTracker.waitForAll();

		if(mediaTracker.isErrorAny())
			throw new ImageProviderException(filename);

		return image;
	}

	public Image[] get(String filename[]) throws InterruptedException,ImageProviderException
	{
		Image[] image=new Image[filename.length];

		for(int n=0;n<image.length;n++)
			mediaTracker.addImage(image[n]=applet.getImage(applet.getCodeBase(),filename[n]),0);

		mediaTracker.waitForAll();

		if(mediaTracker.isErrorAny())
		{
			String filenameString="";

			for(int n=0;n<image.length;n++)
				filenameString+=filename[n]+" ";

			throw new ImageProviderException(filenameString);
		}

		return image;
	}
}

