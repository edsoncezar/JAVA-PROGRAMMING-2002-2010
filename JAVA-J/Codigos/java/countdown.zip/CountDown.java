/*
	CountDown

	Written by Michael Kraus
	Version 1.0
	JDK 1.0

	<applet code="CountDown.class" width=80 height=40>
	<param name="date" value="1 Jan 2000">
	<param name="bgcolor" value="000000">
	<!--param name="background" value="background.gif"-->
	<param name="space" value="1">
	</applet>
*/

import java.applet.*;
import java.awt.*;
import java.util.*;

public class CountDown extends Applet
{
	private static String[][] parameterInfo=
	{
		{"date","String","target date, e.g. \"1 Jan 2000\""},
		{"bgcolor","int","background color"},
		{"background","file","background image"},
		{"space","int","space pixels between digits"}
	};

	private static final String[] digitImageFile=
	{
		"zero.gif",
		"one.gif",
		"two.gif",
		"three.gif",
		"four.gif",
		"five.gif",
		"six.gif",
		"seven.gif",
		"eight.gif",
		"nine.gif"
	};

	private Image backgroundImage;
	private Image[] digitImage;

	private String outputString;

	private int space;

	private int x;
	private int y;

	public void init()
	{
		String parameter;
		ImageProvider imageProvider=new ImageProvider(this);

		if((parameter=getParameter("date"))!=null)
			outputString=String.valueOf(Math.max(0,(new Date(parameter).getTime()-new Date().getTime())/(1000*60*60*24)+1));
		else
			outputString="666";

		if((parameter=getParameter("bgcolor"))!=null)
			setBackground(new Color(Integer.parseInt(parameter,16)));

		try
		{
			digitImage=imageProvider.get(digitImageFile);

			if((parameter=getParameter("background"))!=null)
				backgroundImage=imageProvider.get(parameter);
		}
		catch(Exception exception)
		{
			System.err.println(exception);
		}

		if((parameter=getParameter("space"))!=null)
			space=Integer.parseInt(parameter,10);
		else
			space=1;

		Dimension dimension=size();

		y=(dimension.height-26)/2;
		x=-space;

		for(int n=0;n<outputString.length();n++)
			x+=digitImage[outputString.charAt(n)-'0'].getWidth(null)+space;

		x=(dimension.width-x)/2;
	}

	public void paint(Graphics graphics)
	{
		int cursor=x;

		if(backgroundImage!=null)
			graphics.drawImage(backgroundImage,0,0,null);

		for(int n=0;n<outputString.length();n++)
		{
			graphics.drawImage(digitImage[outputString.charAt(n)-'0'],cursor,y,null);
			cursor+=digitImage[outputString.charAt(n)-'0'].getWidth(null)+space;
		}
	}

	public String getAppletInfo()
	{
		return "CountDown\n\nWritten by Michael Kraus\nVersion 1.0\nJDK 1.0";
	}

	public String[][] getParameterInfo()
	{
		return parameterInfo;
	}
}

