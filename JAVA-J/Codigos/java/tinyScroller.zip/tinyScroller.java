import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class tinyScroller extends Applet
    implements Runnable {                // Threaded application

    int maxLines=100,                    // Added by a user
    direction=0,                         // 0=up, 1=down
    delay=100,                           // delay, controls scroll speed
    spacing=12,                          // spacing, between lines
    XPos=5,                              // XPos, indent 
    maxLine=0,                           // maxLine, # of Lines being sent 
    current,                             // current, initial position 
    height;                              // height, of the applet

    String[] Line = new String[maxLines];// Lines, to be displayed, 12 max

    Image offImage, bg;                  // Double buffering to eliminate
    Graphics offGrfx;                    // frame flicker

    Font outFont;                        // Output font (if passed)
    boolean customFont = false;          // Flag, is there a custom outFont?
                                    
    Color background, fontColor;

    Thread runner;

    public void init() {

        /****  Get attributes, if available  ****/
        String bgRed$      = getParameter("BGRED");
        String bgGreen$    = getParameter("BGGREEN");
        String bgBlue$     = getParameter("BGBLUE");
        String fgRed$      = getParameter("FGRED");
        String fgGreen$    = getParameter("FGGREEN");
        String fgBlue$     = getParameter("FGBLUE");
        String spacing$    = getParameter("SPACING");
        String delay$      = getParameter("DELAY");
        String XPos$       = getParameter("XPOS");
        String maxLine$    = getParameter("MAXLINE");
        String background$ = getParameter("BACKGROUND");
        String fontName$   = getParameter("FONTNAME");
        String fontSize$   = getParameter("FONTSIZE");
        String direction$  = getParameter("DIRECTION");

        /****           Data lines           ****/
        for (int x=0; x<maxLines; x++) {
            Line[x] = getParameter("LINE" + Integer.toString(x+1));
        }

        /****          Setting Font          ****/
        if ((fontSize$ != null) && (fontName$ != null)) {
            int size = Integer.parseInt(fontSize$);
            outFont = new Font(fontName$, Font.PLAIN, size);
            customFont = true;
        }

        /****          Find maxline         ****/
        for (int x=0; x<maxLines; x++) {
            if (Line[x] == null) break;
            maxLine++;
        }
        
        /****      Convert color values     ****/
        int Red=255;
        if (bgRed$ != null)
	  Red = Integer.parseInt(bgRed$);

        int Green=255; 
        if (bgGreen$ != null)
	  Green = Integer.parseInt(bgGreen$);

        int Blue=255;
        if (bgBlue$ != null)
	  Blue = Integer.parseInt(bgBlue$);

        int fRed=0;
        if (fgRed$ != null)
          fRed = Integer.parseInt(fgRed$);

        int fGreen=0; 
        if (fgGreen$ != null)
          fGreen = Integer.parseInt(fgGreen$);

        int fBlue=0;
        if (fgBlue$ != null)
          fBlue = Integer.parseInt(fgBlue$);

        /****   Convert attribute values   ****/
        if (spacing$ != null)
	  spacing = Integer.parseInt(spacing$);
        
        if (delay$ != null)
	  delay = Integer.parseInt(delay$);
       
        if (XPos$ != null)
	  XPos = Integer.parseInt(XPos$);
       
        height = size().height;                                              

        if (direction$ != null)
          direction = Integer.parseInt(direction$);

        if (background$ !=null)
          bg = getImage(getDocumentBase(), background$);

        /****        Set init index       ****/
        if (direction == 0) { 
          current = height;
        }
        else {
          current = -(maxLine * spacing);
        }

        /****     Set foreground color    ****/
        fontColor = new Color(fRed, fGreen, fBlue);

        /****     Set background color    ****/
        background = new Color(Red, Green, Blue);
        setBackground(background);


        /****         Init buffer         ****/
        offImage = createImage(size().width, size().height);
        offGrfx = offImage.getGraphics();

    }

    public void paint(Graphics screen) {

        /****     Clear prev image        ****/
          offGrfx.setColor(background);
          offGrfx.fillRect(0,0,size().width, size().height);

        /****      Draw background        ****/
          if (bg != null)
            offGrfx.drawImage(bg, 0, current - height, null);

        /****      Set custom font        ****/
          offGrfx.setColor(fontColor);
          try { offGrfx.setFont(outFont); }
          catch (NullPointerException e) {}

        /****        Draw lines           ****/
          if (direction == 0) {
              for (int i=0; i<maxLine; i++) 
                  offGrfx.drawString(Line[i],  XPos, current + (i * spacing));
          }
          else {
              for (int i=0; i<maxLine; i++)
                  offGrfx.drawString(Line[i],  XPos, current + ( (maxLine-i) * spacing));
          }

        /****   Flip buffer to screen     ****/
          screen.drawImage(offImage, 0, 0, this);
    }

    public void update(Graphics screen) {

        /****      Override update        ****/
          paint(screen);
    }

    public void start() {
        if (runner == null) {
            runner = new Thread(this);
            runner.start();
        }
    }

    public void run() {
        while (true) {
            repaint();
            if (direction == 0) {
                current--;
                if ((current + (maxLine * spacing)) < 0)
                current = height + spacing;
            }
            else {
                current++;
                if (current > height)
                current = -(maxLine * spacing);
            }
            try { Thread.sleep(delay); }
            catch (InterruptedException e) { }
        }
    }

    public void stop() {
        if (runner != null) {
            runner.stop();
            runner = null;
        }
    }
}
