import          java.net.URL;
import          java.util.*;
import          java.awt.*;
import          java.applet.*;
import java.io.*;

public class ZeBanner extends java.applet.Applet implements Runnable
{
    // This function	gets a parameter from applet and return	a default
    // value	if not found
    protected String getParam(String name, String defaultValue) {
        String          s = getParameter(name);
                        return (s == null) ? defaultValue : s;
    }

    private String RegString;
    private String          TmpString[] = new String[50];
    private int             nb_TmpString;
    private String          c;
    private Thread runner;

    // Maximal 200 images	+ 1	of basis
    private int curx;
    private int             ccurx;
    private int             ccurw;
    private int             cfirstimg;
    private int             lastx;
    private int             lasty;
    private int             curw;
    private int             firstimg;
    private int             lastprint;
    private int             step;
    private int             delay;
    private int             nbCut;

    private int             firstx[] = new int[200];
    private int             dec[] = new int[200];
    private Image           img[] = new Image[200];
    private Image           himg[] = new Image[200];
    private String          target[] = new String[200];
    private String          tip[] = new String[200];
    private String          msg[] = new String[200];
    private URL             boxURL[] = new URL[200];
    private int col2use[] = new int[200];
    private int fnt2use[] = new int[200];

    private Cutline         cl[] = new Cutline[200];
    private Cutline         hcl[] = new Cutline[200];

    private int             totalwidth;
    private String          boxText;

    private int nbcol;
    private int shadx[] = new int[200];
    private int shady[] = new int[200];
    private Color           scol[] = new Color[200];
    private Color           hscol[] = new Color[200];

    private Color           tcol[] = new Color[200];
    private Color           htcol[] = new Color[200];
    private Color           backcolor[] = new Color[200];
    private Color           hbackcolor[] = new Color[200];

    private int nbfont;
    private String          font[] = new String[200];
    private String          fontStyle[] = new String[200];
    private int             fontSize[] = new int[200];

    private boolean loaded = false;

    private Image           offscreen;
    private Graphics        offG,
                    tmpG;

    private String filename;

    private void MakeIt() {
        int             remindwidth;
        int             teststat;
        int             maxwidth;

        for             (int x = 0; x < nbCut; x++) {
            hcl[x] = new Cutline(msg[x], font[fnt2use[x]], fontSize[fnt2use[x]], fontStyle[fnt2use[x]], hbackcolor[col2use[x]], htcol[col2use[x]], shadx[col2use[x]],shady[col2use[x]],  hscol[col2use[x]],size().height, dec[x], offG);
            cl[x] = new Cutline(msg[x], font[fnt2use[x]], fontSize[fnt2use[x]], fontStyle[fnt2use[x]], backcolor[col2use[x]], tcol[col2use[x]], shadx[col2use[x]],shady[col2use[x]], scol[col2use[x]],size().height, dec[x], offG);
        }

        maxwidth = 0;
        while           (totalwidth < size().width) {
            totalwidth = 0;
            firstx[0] = 0;
            for (int x = 0; x < nbCut; x++) {
                totalwidth += cl[x].maxwidth + 30;
                if (x > 0) {
                    firstx[x] = firstx[x - 1] + cl[x - 1].maxwidth + 30;
                }
            }

            if  (totalwidth < size().width) {
                for (int x = 0; x < nbCut; x++) {
                    cl[x].setWidth((totalwidth - size().width) / nbCut);
                    hcl[x].setWidth((totalwidth - size().width) / nbCut);
                }
            }
        }

        for (int x = 0; x < nbCut; x++) {
            img[x] = createImage(cl[x].maxwidth + 30, size().height);
            tmpG = img[x].getGraphics();
            cl[x].BuildImage(tmpG, size().height);

            himg[x] = createImage(hcl[x].maxwidth + 30, size().height);
            tmpG = himg[x].getGraphics();
            hcl[x].BuildImage(tmpG, size().height);
        }
        loaded = true;
    }

    public void ScrollIt() {

            curx += step;

            if (curx > totalwidth)
                curx = 0;

            // Get current first image ;
            int firstimg = 0;
            int curw = 0;

            while (curx > firstx[firstimg + 1] && firstimg != nbCut - 1) {
                firstimg++;
            }

            curw = firstx[firstimg] - curx;

            int teststat = 0;
            while (curw < totalwidth) {
                if (lastprint != -2) {
                    // lastprint = -1;
                    if (teststat == 0 && curw + cl[firstimg].maxwidth + 30 > lastx) {
                        if (lastprint != firstimg) {
                            lastprint = firstimg;
                            showStatus(" " + tip[firstimg]);
                        }
                        teststat = 1;
                    }
                }

                if (lastprint == firstimg)
                    offG.drawImage(himg[firstimg], curw, 0, this);
                else
                    offG.drawImage(img[firstimg], curw, 0, this);

                curw += cl[firstimg].maxwidth + 30;
                firstimg++;
                if (firstimg == nbCut)
                    firstimg = 0;
            }

    }

    public void     run() {

      long            thisTick, waitTick;

      if (!loaded) {
        repaint();
        filename = getParameter("file");
        readParameter();
        MakeIt();
      }


        curx = 0 - step;

        thisTick = System.currentTimeMillis();
        waitTick = thisTick + delay;

        offG.clipRect(0, 0, size().width, size().height);
        runner.setPriority(Thread.MIN_PRIORITY);
        while (true) {
            ScrollIt();
            thisTick = System.currentTimeMillis();
            if (thisTick < waitTick) {
               try {
                 Thread.currentThread().sleep((int) (waitTick - thisTick));
                } catch(InterruptedException e) {}
            }
            waitTick = System.currentTimeMillis() + delay;
            repaint();

        }
    }

    public void     start() {
        if (runner == null) {
            runner = new Thread(this);
            runner.start();
        }
    }

    public void     stop() {
        if (runner != null) {
            runner.stop();
            runner = null;
        }
    }

    public void     init() {
        int             nbcoord,
                        p1,
                        p2;
        int             node;

        filename = getParameter("file");
        cfirstimg = 0;
        lastx = 0;
        lasty = 0;
        firstimg = 0;
        lastprint = -2;
        step = 5;
        delay = 100;
        nbCut = 0;


        offscreen = createImage(size().width, size().height);
        offG = offscreen.getGraphics();

        try {
            step = Integer.parseInt(getParameter("step"));
        }
                        catch(Exception E) {
        }

        try {
            delay = Integer.parseInt(getParameter("delay"));
        }
        catch(Exception E) {
        }

        // load text array
        nbcol = 0;
        String          nodeText = getParam("color" + (nbcol + 1), "none");
        while (nodeText != "none" && nbcol < 30) {
            SplitTxt(nodeText, ",");
            // Get Text	color
            try {
                tcol[nbcol] = new Color(Integer.parseInt(TmpString[0], 16));
            }
            catch(Exception E) {
            }

            // Get Text	color
            try {
                htcol[nbcol] = new Color(Integer.parseInt(TmpString[1], 16));
            }
            catch(Exception E) {
            }

            try {
               backcolor[nbcol] = new Color(Integer.parseInt(TmpString[2], 16));
            }
            catch(Exception E) {
            }

            try {
               hbackcolor[nbcol] = new Color(Integer.parseInt(TmpString[3], 16));
            }
            catch(Exception E) {
            }

            nodeText = getParam("shadow" + (nbcol + 1), "none");
            if (nodeText=="none") {
               shadx[nbcol] = 0;
               shady[nbcol] = 0;
            } else {
              SplitTxt(nodeText, ",");
              shadx[nbcol] = Integer.parseInt(TmpString[0]);
              shady[nbcol] = Integer.parseInt(TmpString[1]);
              scol[nbcol] = new Color(Integer.parseInt(TmpString[2], 16));
              hscol[nbcol] = new Color(Integer.parseInt(TmpString[3], 16));
            }

            nbcol++;
            nodeText = getParam("color" + (nbcol + 1), "none");
        }


                // load text array
        nbfont = 0;
        nodeText = getParam("font" + (nbfont + 1), "none");
        while (nodeText != "none" && nbfont < 30) {

            SplitTxt(nodeText, ",");

            // Get font	parameters
            font[nbfont] = TmpString[0];
            fontSize[nbfont] = Integer.parseInt(TmpString[1]);
            fontStyle[nbfont] = TmpString[2];

            nbfont++;
            nodeText = getParam("font" + (nbfont + 1), "none");
        }
	}

    public void     update(Graphics g) {
      if (!loaded) {
           g.setColor(Color.white);
           g.fillRect(0, 0, size().width, size().height);
           Font font = new Font("Helvetica", 0, 8);
           FontMetrics fm = g.getFontMetrics(font);
           g.setColor(Color.black);
           g.drawString("Applet is loading...",5,15);
      } else {
          g.drawImage(offscreen, 0, 0, this);
      }
    }

    public void     paint(Graphics g) {
      update(g);
    }

    public          boolean mouseMove(Event evt, int x, int y) {
        if (lastprint < -1) lastprint = -1;
        lastx = x;
        lasty = y;
        return true;
    }

    public boolean mouseUp(Event evt, int x, int y) {
        URL Url;
        Url = null;

        if (lastprint != -1 && boxURL[lastprint] != null) {
            getAppletContext().showDocument(boxURL[lastprint], target[lastprint]);
        }
        return true;

    }

    private void readParameter()
    {
        DataInputStream data_in;
        String        i2,  inputline;
        int waitforbegin = 1;

        URL             fileUrl;
        int curx;
        int nbtext=0;
        String ttext="", ttarget="", turl="", ttip="";
        String chkdate="";
        String schkdate="";
        int tcolor=1, tfont=1;
        int tdec=0;
        nbCut = 0;

        try {
            fileUrl = new URL(getDocumentBase(), filename);
            data_in = new DataInputStream(fileUrl.openStream());
            do {
                i2 = data_in.readLine();
                inputline = i2.trim();
                if (inputline != null) {
                    if (inputline.startsWith("BEGIN")) {
                        waitforbegin = 0;
                        ttext=""; ttarget=""; turl=""; ttip="";
                        tcolor=1; tfont=1;
                        tdec=0; nbtext = 0;
                        chkdate ="";
                        schkdate="01/01/1900";
                       continue;
                    }
                    if (waitforbegin == 0) {
                        if (inputline.startsWith("END")) {
                          waitforbegin = 1;
                          if (CheckDate(chkdate) && !CheckDate(schkdate)) {
                              dec[nbCut] = tdec;
                              target[nbCut] = ttarget;
                              tip[nbCut] = ttip;
                              msg[nbCut] = ttext;
                              col2use[nbCut] = tcolor-1;
                              fnt2use[nbCut] = tfont-1;
                                // get URL
                                try {
                                    boxURL[nbCut] = null;
                                    if (turl.length() > 0) {
                                        boxURL[nbCut] = new URL(getDocumentBase(), turl);
                                    }
                                } catch(Exception e) {
                                    System.out.println(e);
                                }
                              nbCut ++;
                          }
                        } else {
                           SplitTxt(inputline, "=");
                        }
                        if (TmpString[0].startsWith("TIP"))
                            ttip = TmpString[1];
                        if (TmpString[0].startsWith("DEC"))
                            tdec = Integer.parseInt(TmpString[1]);
                        if (TmpString[0].startsWith("COLOR"))
                            tcolor = Integer.parseInt(TmpString[1]);
                        if (TmpString[0].startsWith("FONT"))
                            tfont = Integer.parseInt(TmpString[1]);
                        if (TmpString[0].startsWith("TEXT")) {
                            if (nbtext > 0) {
                               ttext = ttext + "|" + TmpString[1];
                            } else {
                                ttext = ttext + TmpString[1];
                            }
                            for (int x=2; x < nb_TmpString; x++) {
                                ttext += "=" + TmpString[x];
                            }
                            nbtext++;
                        }
                        if (TmpString[0].startsWith("TARGET"))
                            ttarget = TmpString[1];
                        if (TmpString[0].startsWith("DATE"))
                            chkdate = TmpString[1];
                        if (TmpString[0].startsWith("SDATE"))
                            schkdate = TmpString[1];
                        if (TmpString[0].startsWith("URL"))
                                turl = TmpString[1];
                        }
                }

            } while (data_in.available() > 0);
            data_in.close();
        } catch(IOException e) {
            System.out.println(e);
        }
     }

    public boolean mouseExit(Event evt, int x, int y) {
        lastprint = -2;
        showStatus("");
        return true;
    }

    protected void  SplitTxt(String txt, String del)
    {
        int             clen,
                        cdeb,
                        cend;
                        nb_TmpString = 0;

                        clen = txt.length();
                        cdeb = 0;

                        cdeb = 0;

        while (cdeb < clen) {
            cend = txt.indexOf(del, cdeb);
            if (cend < 0)
                cend = clen;
            TmpString[nb_TmpString] = txt.substring(cdeb, cend);
            cdeb = cend + 1;
            nb_TmpString++;
        }
    }

    public boolean CheckDate(String chkdate) {
        if (chkdate == "") return true;

        Date today = new Date();

        int ty =  today.getYear();
        int tm = today.getMonth()+1;
        int td = today.getDate();

        SplitTxt(chkdate,"/");

        int chky = Integer.parseInt(TmpString[2])-1900;
        int chkm = (Integer.parseInt(TmpString[1]));
        int chkd = (Integer.parseInt(TmpString[0]));

        long dd = ty*10000 + tm * 100 + td;
        long ee = chky*10000 + chkm * 100 + chkd;
        if (dd > ee) return false;
        return true;

    }

}