import          java.net.URL;
import          java.util.*;
import          java.awt.*;
import          java.awt.Font;


public class Cutline {
    private String[] lines = new String[20];
    private FontMetrics     fm;

    private String          text;
    private int             numLines;
    private int             decy = 0;
    private Font            font;
    private Color           backcolor = Color.black;
    private Color           tcolor = Color.white;
    private Color           scolor = Color.gray;
    int             maxwidth = 0;
    
    private int shx, shy; 
  

    public          Cutline(String txt, String fn, int fs, String style, Color bcol, Color tcol, int sx, int sy, Color s, int height, int decyy, Graphics g) {
        int             fontStyle = 0;
        if  (style.indexOf("BOLD") >= 0) {
            fontStyle += Font.BOLD;
        }
        if (style.indexOf("ITALIC") >= 0)
           fontStyle += Font.ITALIC;

        font = new Font(fn, fontStyle, fs);
      
        fm = g.getFontMetrics(font);

        shx =  sx; shy = sy;
        backcolor = bcol;
        tcolor = tcol;
        scolor = s;        
        buildBox(txt);

        decy = decyy;
    }

    private void    buildBox(String text) {
        // set up text
        this.text = text.trim();
        String          c = "";
                        numLines = 0;
                        lines[0] = "";

        // build lines of text for box
        for             (int i = 0; i < text.length(); i++) {
            try {
                c = text.substring(i, i + 1);
            }
                            catch(StringIndexOutOfBoundsException e) {
            }
            if (c.charAt(0) == '|') {
                if (maxwidth < fm.stringWidth(lines[numLines])) {
                    maxwidth = fm.stringWidth(lines[numLines]);
                }
                numLines++;
                lines[numLines] = "";
            } else {
                lines[numLines] += c;
            }
        }

        if (maxwidth < fm.stringWidth(lines[numLines])) {
            maxwidth = fm.stringWidth(lines[numLines]);
        }
        numLines++;
    }

    public void     setWidth(int x) {
        maxwidth += maxwidth;
    }


    public void     BuildImage(Graphics g, int height) {

        int             posy = decy;

                        g.setColor(backcolor);
                        g.fillRect(0, 0, maxwidth + 30, height);

                        g.setFont(font);
                        g.setColor(tcolor);

        for             (int i = 0; i < numLines; i++) {
            if (shx != 0 && shy != 0) {
               g.setColor(scolor);                
               g.drawString(lines[i], shx + 15 + (maxwidth - fm.stringWidth(lines[i])) / 2, shy+ posy + (i + 1) * fm.getHeight());               
               g.setColor(tcolor);
            }    
            g.drawString(lines[i], 15 + (maxwidth - fm.stringWidth(lines[i])) / 2, posy + (i + 1) * fm.getHeight());

        }
    }
}