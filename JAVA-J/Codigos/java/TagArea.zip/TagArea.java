/*
 * TagArea.java  2/19/1996
 *
 * Copyright (c) 1996 Pulse Incorporated, All Rights Reserved
 *
 * Class for use with the ImageMap (c) Sun Microsystems by Jim Graham
 *
 * Pulse makes no warranties express or implied regarding the use of this 
 * software. You may copy, modify, distribute and use this software for 
 * NON-COMMERCIAL or COMMERCIAL purposes without any type of fee what so 
 * ever.
 *
 */

import java.awt.Graphics;
import java.util.StringTokenizer;
import java.awt.Image;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * This Class was written to pop up a descriptive tag when the mouse is
 * over it a specified area.
 *
 * Author:   Robert Klein (robk@pulse-sys.com)
 * Date:     2/19/1996
 * Version:  1.0
 *
 *  Parameters are X,Y,Width,Height,TagGifFile,TagX,TagY
 *
 *  Where:
 *
 *    X,Y,Width,Height describe the dimension of the clickable area
 * 
 *    TagGifFile is the name of the Gif file to display when the mouse
 *        enters the clickable area
 *
 *    TagX,TagY are the Coordinates of the upper left and corner where
 *        you want TagGifFile displayed
 *
 *    NOTE: For now the TagGifFile is hardcoded to be exaclty 100x25.
 */
class TagArea extends ImageMapArea {

    Image sourceImage;
    int  tagx;
    int  tagy;

    public void handleArg(String s) {
	StringTokenizer st = new StringTokenizer(s, ", ");
	int	i;
        String imgName;

	imgName = st.nextToken();
	try {
	sourceImage = parent.getImage(
			new URL(parent.getDocumentBase(), imgName));
	} catch (MalformedURLException e) {}

        tagx = Integer.parseInt(st.nextToken());
        tagy = Integer.parseInt(st.nextToken());
    }

    public void makeImages() {
        setHighlight(sourceImage);
    }

    public void highlight(Graphics g) {
	if (entered) {
            g.drawImage(hlImage, tagx, tagy, this);
	}
    }


    public void repaint() {
        parent.repaint(0, tagx, tagy, 100, 25);
    }

    public boolean enter() {
	repaint();
	return true;
    }

    public void exit() {
	repaint();
    }
}