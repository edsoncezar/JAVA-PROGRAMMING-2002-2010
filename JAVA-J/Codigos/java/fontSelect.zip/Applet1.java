/*
	A basic extension of the java.applet.Applet class
 */

import java.awt.*;
import java.applet.*;

public class Applet1 extends Applet implements java.awt.event.ActionListener
{
	public void init()
	{
		//{{INIT_CONTROLS
		setLayout(null);
		setSize(470,266);
		setBackground(java.awt.Color.lightGray);
		button1 = new java.awt.Button();
		button1.setLabel("Select font");
		button1.setBounds(180,228,85,36);
		button1.setBackground(java.awt.Color.lightGray);
		add(button1);
		label1 = new java.awt.Label("Press button to select font",Label.CENTER);
		label1.setBounds(12,24,444,192);
		label1.setFont(new Font("Dialog", Font.PLAIN, 30));
		add(label1);
		//}}
	
		//{{REGISTER_LISTENERS
		button1.addActionListener(this);
		//}}
	}
	
	//{{DECLARE_CONTROLS
	java.awt.Button button1;
	java.awt.Label label1;
	//}}

	public void actionPerformed(java.awt.event.ActionEvent event)
	{
		Object object = event.getSource();
		if (object == button1) {
            Frame fr;
            fr = new Frame();
	    	fontSelect fntSel;
		    fntSel = new fontSelect(fr, true);
    		fntSel.show();
    		if (fntSel.isSelected) {
       			label1.setFont(fntSel.selectedFont);
        		label1.setBackground(fntSel.selectedBackground);
        		label1.setForeground(fntSel.selectedForeground);
        		label1.setText("Font has been selected");
       		}
	    }
	}
}
