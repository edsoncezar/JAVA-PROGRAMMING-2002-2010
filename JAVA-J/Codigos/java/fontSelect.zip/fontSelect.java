import java.awt.*;
import java.awt.event.*;
public class fontSelect extends java.awt.Dialog implements AdjustmentListener, ItemListener, TextListener, ActionListener {
    public Font selectedFont;       //to get result
    public boolean isSelected = false;
    public Color selectedBackground, selectedForeground;
	public fontSelect(Frame parent, boolean modal) {
		super(parent, modal);
    	String fntName[] = getToolkit().getFontList();
		//{{INIT_CONTROLS
		setLayout(null);
		setVisible(false);
		setSize(insets().left + insets().right + 591,insets().top + insets().bottom + 505);
		setBackground(java.awt.Color.lightGray);
		fontList = new java.awt.List(0,false);
		add(fontList);
		fontList.setBounds(insets().left + 12,insets().top + 60,337,144);
		label1 = new java.awt.Label("Example string");
		label1.setBounds(insets().left + 372,insets().top + 36,84,24);
		add(label1);
		exampleText = new java.awt.TextField();
		exampleText.setText("Simple");
		exampleText.setBounds(insets().left + 372,insets().top + 60,202,21);
		add(exampleText);
		label2 = new java.awt.Label("Select font");
		label2.setBounds(insets().left + 12,insets().top + 36,60,19);
		add(label2);
		isBold = new java.awt.Checkbox("Bold");
		isBold.setBounds(insets().left + 372,insets().top + 96,60,18);
		isBold.setFont(new Font("Dialog", Font.BOLD, 12));
		add(isBold);
		isItalic = new java.awt.Checkbox("Italic");
		isItalic.setBounds(insets().left + 372,insets().top + 132,48,17);
		isItalic.setFont(new Font("Dialog", Font.ITALIC, 12));
		add(isItalic);
		showFont = new java.awt.Label("Simple",Label.CENTER);
		showFont.setBounds(insets().left + 12,insets().top + 324,566,173);
		showFont.setBackground(java.awt.Color.white);
		add(showFont);
		fontSize = new java.awt.Choice();
		add(fontSize);
		fontSize.setBounds(insets().left + 372,insets().top + 156,60,23);
		fontSize.setBackground(java.awt.Color.white);
		btnSelect = new java.awt.Button();
		btnSelect.setLabel("Select");
		btnSelect.setBounds(insets().left + 492,insets().top + 108,87,24);
		add(btnSelect);
		btnCancel = new java.awt.Button();
		btnCancel.setLabel("Cancel");
		btnCancel.setBounds(insets().left + 492,insets().top + 156,91,24);
		add(btnCancel);
		label3 = new java.awt.Label("Background");
		label3.setBounds(insets().left + 24,insets().top + 216,94,18);
		add(label3);
		rBackground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,255,0,0,255);
		rBackground.setBounds(insets().left + 24,insets().top + 240,197,21);
		add(rBackground);
		gBackground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,255,0,0,255);
		gBackground.setBounds(insets().left + 24,insets().top + 264,197,21);
		add(gBackground);
		bBackground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,255,0,0,255);
		bBackground.setBounds(insets().left + 24,insets().top + 288,197,21);
		add(bBackground);
		label4 = new java.awt.Label("R");
		label4.setBounds(insets().left + 12,insets().top + 240,12,18);
		label4.setFont(new Font("Dialog", Font.BOLD, 12));
		label4.setForeground(java.awt.Color.red);
		add(label4);
		label5 = new java.awt.Label("G");
		label5.setBounds(insets().left + 12,insets().top + 264,12,18);
		label5.setFont(new Font("Dialog", Font.BOLD, 12));
		label5.setForeground(new Color(-16744448));
		add(label5);
		label6 = new java.awt.Label("B");
		label6.setBounds(insets().left + 12,insets().top + 288,12,18);
		label6.setFont(new Font("Dialog", Font.BOLD, 12));
		label6.setForeground(java.awt.Color.blue);
		add(label6);
		rBackValue = new java.awt.Label("255");
		rBackValue.setBounds(insets().left + 228,insets().top + 240,24,12);
		rBackValue.setFont(new Font("Dialog", Font.BOLD, 12));
		rBackValue.setForeground(java.awt.Color.red);
		add(rBackValue);
		gBackValue = new java.awt.Label("255");
		gBackValue.setBounds(insets().left + 228,insets().top + 264,24,12);
		gBackValue.setFont(new Font("Dialog", Font.BOLD, 12));
		gBackValue.setForeground(new Color(-16744384));
		add(gBackValue);
		bBackValue = new java.awt.Label("255");
		bBackValue.setBounds(insets().left + 228,insets().top + 288,24,12);
		bBackValue.setFont(new Font("Dialog", Font.BOLD, 12));
		bBackValue.setForeground(java.awt.Color.blue);
		add(bBackValue);
		label7 = new java.awt.Label("Foreground");
		label7.setBounds(insets().left + 336,insets().top + 216,94,18);
		add(label7);
		rForeground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255);
		rForeground.setBounds(insets().left + 336,insets().top + 240,197,21);
		add(rForeground);
		gForeground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255);
		gForeground.setBounds(insets().left + 336,insets().top + 264,197,21);
		add(gForeground);
		bForeground = new java.awt.Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255);
		bForeground.setBounds(insets().left + 336,insets().top + 288,197,21);
		add(bForeground);
		label8 = new java.awt.Label("R");
		label8.setBounds(insets().left + 324,insets().top + 240,12,18);
		label8.setFont(new Font("Dialog", Font.BOLD, 12));
		label8.setForeground(java.awt.Color.red);
		add(label8);
		label9 = new java.awt.Label("G");
		label9.setBounds(insets().left + 324,insets().top + 264,12,18);
		label9.setFont(new Font("Dialog", Font.BOLD, 12));
		label9.setForeground(new Color(-16744448));
		add(label9);
		label10 = new java.awt.Label("B");
		label10.setBounds(insets().left + 324,insets().top + 288,12,18);
		label10.setFont(new Font("Dialog", Font.BOLD, 12));
		label10.setForeground(java.awt.Color.blue);
		add(label10);
		rForeValue = new java.awt.Label("255");
		rForeValue.setBounds(insets().left + 540,insets().top + 240,24,12);
		rForeValue.setFont(new Font("Dialog", Font.BOLD, 12));
		rForeValue.setForeground(java.awt.Color.red);
		add(rForeValue);
		gForeValue = new java.awt.Label("255");
		gForeValue.setBounds(insets().left + 540,insets().top + 264,24,12);
		gForeValue.setFont(new Font("Dialog", Font.BOLD, 12));
		gForeValue.setForeground(new Color(-16744384));
		add(gForeValue);
		bForeValue = new java.awt.Label("255");
		bForeValue.setBounds(insets().left + 540,insets().top + 288,24,12);
		bForeValue.setFont(new Font("Dialog", Font.BOLD, 12));
		bForeValue.setForeground(java.awt.Color.blue);
		add(bForeValue);
		setTitle("Choosing font");
		//}}

		//{{REGISTER_LISTENERS
		exampleText.addTextListener(this);
		btnSelect.addActionListener(this);
		btnCancel.addActionListener(this);
		isBold.addItemListener(this);
		fontList.addItemListener(this);
		isItalic.addItemListener(this);
		fontSize.addItemListener(this);
		rBackground.addAdjustmentListener(this);
		gBackground.addAdjustmentListener(this);
		bBackground.addAdjustmentListener(this);
		rForeground.addAdjustmentListener(this);
		gForeground.addAdjustmentListener(this);
		bForeground.addAdjustmentListener(this);
		//}}
        for (int i = 0; i < (int)fntName.length; i++) 
            fontList.addItem(fntName[i]); 
		showFont.setFont(new Font(fntName[0], Font.PLAIN, 12));
		selectedBackground = showFont.getBackground();
		selectedForeground = showFont.getForeground();
		int i = 8;
		do {
			fontSize.addItem(""+i);
			if (i<=30) i+=2;
			    else if (i<=70) i+=4;
			    else i+=8;
		} while (i<150);
		try {
			fontSize.select(2);
		} catch (IllegalArgumentException e) { }
	}

	//{{DECLARE_CONTROLS
	java.awt.List fontList;
	java.awt.Label label1;
	java.awt.TextField exampleText;
	java.awt.Label label2;
	java.awt.Checkbox isBold;
	java.awt.Checkbox isItalic;
	java.awt.Label showFont;
	java.awt.Choice fontSize;
	java.awt.Button btnSelect;
	java.awt.Button btnCancel;
	java.awt.Label label3;
	java.awt.Scrollbar rBackground;
	java.awt.Scrollbar gBackground;
	java.awt.Scrollbar bBackground;
	java.awt.Label label4;
	java.awt.Label label5;
	java.awt.Label label6;
	java.awt.Label rBackValue;
	java.awt.Label gBackValue;
	java.awt.Label bBackValue;
	java.awt.Label label7;
	java.awt.Scrollbar rForeground;
	java.awt.Scrollbar gForeground;
	java.awt.Scrollbar bForeground;
	java.awt.Label label8;
	java.awt.Label label9;
	java.awt.Label label10;
	java.awt.Label rForeValue;
	java.awt.Label gForeValue;
	java.awt.Label bForeValue;
	//}}
    private Font constructFont() {
        int l;
        try {
            l = Integer.parseInt(fontSize.getSelectedItem());
        } catch (NumberFormatException e) {l = 12;}
        selectedFont = new Font(fontList.getItem(fontList.getSelectedIndex()>=0?fontList.getSelectedIndex():0 ), (isBold.getState()?Font.BOLD:0)+(isItalic.getState()?Font.ITALIC:0), l);
        selectedBackground = new Color(rBackground.getValue(), gBackground.getValue(), bBackground.getValue());
        selectedForeground = new Color(rForeground.getValue(), gForeground.getValue(), bForeground.getValue());
        return (selectedFont);
    }
	public void textValueChanged(java.awt.event.TextEvent event) {
		Object object = event.getSource();
		if (object == exampleText) showFont.setText(exampleText.getText());
	}
	public void actionPerformed(java.awt.event.ActionEvent event) {
		Object object = event.getSource();
		if (object == btnSelect) {
            isSelected = true;
            selectedFont = constructFont();
        	dispose();
        } else if (object == btnCancel) {
	        selectedFont = null;
            selectedBackground = null;
            selectedForeground = null;
            dispose();
        }
    }
	public void itemStateChanged(java.awt.event.ItemEvent event) {
		Object object = event.getSource();
		if (object == isBold) showFont.setFont(constructFont());
		else if (object == fontList) showFont.setFont(constructFont());
		else if (object == isItalic) showFont.setFont(constructFont());
		else if (object == fontSize) showFont.setFont(constructFont());
	}
	public void adjustmentValueChanged(java.awt.event.AdjustmentEvent event)
	{
		Object object = event.getSource();
        constructFont();
        showFont.setBackground(new Color(rBackground.getValue(), gBackground.getValue(), bBackground.getValue()));
        showFont.setForeground(new Color(rForeground.getValue(), gForeground.getValue(), bForeground.getValue()));
        if (object == rBackground) rBackValue.setText(""+rBackground.getValue());
		else if (object == gBackground) gBackValue.setText(""+gBackground.getValue());
		else if (object == bBackground) bBackValue.setText(""+bBackground.getValue());
		else if (object == rForeground) rForeValue.setText(""+rForeground.getValue());
		else if (object == gForeground) gForeValue.setText(""+gForeground.getValue());
		else if (object == bForeground) bForeValue.setText(""+bForeground.getValue());
	}
}