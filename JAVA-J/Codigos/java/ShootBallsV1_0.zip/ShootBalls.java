/*
ShootIt Version 1.0 (Java 2 1.4.1.01)
Copyright(c) 2002 By Charles L. Wilson All Rights Reserved.
ufotogo@hotmail.com

This program is FREE to all that agree to the user agreement below.

You will agree not to hold clarles l. wilson the programmer or 
anyone else liable for any dammages what so ever this program may
cause. You agree this program is purely for enjoyment and may or
my not live up to your expections. If you modify or improve this program.
You agree to send Charles L. Wilson a copy with changes pointed out. 
If used, the code becomes the sole property of charles l. wilson and you 
forfit all rights to the code or changes you make. The code becomes 
the sole property of Charles L. Wilsom.

As you can see. I am currently developing this program. Below is a 
list of known bugs.

None at current time

I hope you enjoy playing this game and you are encouraged to modify 
the code for improvements. Credit will be given for any changes you make. 
*/




import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;

public class ShootBalls extends Applet implements MouseListener, Runnable 
{
// VARS
//**********************
private Image dbImage;			//Var for image buffering
private Graphics dbg;			//Var for image buffering
Thread th;							//Thread
GameTimer mytimer;				//Timer object
private Ball ball;				//ball object
private Color ballcolor;		//Ball color object
Cursor c;							//cursor object
Random rnd = new Random ();	//Random generator object
private Color [] color_array;	//Array of colors for balls
private Ball [] ball_array; 	//Array to store balls in
int level=1;						//Game level being played
int maxballs;	 					//Max number of balls
int maxspeed;						//must be at least 2.. 
private int x,y =0;				//x & y position of ball
public int ball_width=20;		// inital ball width
public int ball_height = 20;	// inital ball	height			
public int appletsize_x = 295;// x size of applet drawing area for balls 
public int appletsize_y = 270;// y size of applet drawing area	for balls 
int x_speed,y_speed =0;			//x & y speed of the balls
private int count = 0;			// used for counting loops
private int test =0;				// used in test for no more balls
int numcolors = 6;				//used to initilize the colors array
public int timeleft;				//Time till end of game
int colorIndex=0;					//used in filling color array
private int score,hits,miss =0;

public boolean movetonextlevel= false;			
private boolean gotHit =false;
public boolean end_of_game = false;
private boolean alive = true;	

public AudioClip hitnoise;		//Sound objects
public AudioClip gunnoise;
public AudioClip startnoise;
public AudioClip gameovernoise;

Font small = new Font("TimesRoman", Font.PLAIN, 12);
Font large = new Font("TimesRoman", Font.PLAIN, 25);
Font realsmall = new Font("TimesRoman", Font.PLAIN, 10);

//INITILIZE APPLET
//**************************
public void init()
	{	

	//set inital game level
	//***************************
				
	//Init Game 
	//***********
	end_of_game = false;
	setGameLevel(level);	
	int timeleft=60;				//Set length of game
	//Start game timer
	mytimer = new GameTimer(timeleft);
	c = new Cursor (Cursor.CROSSHAIR_CURSOR);	//Change cursor to cross hair
	this.setCursor (c);
	setBackground (Color.black);					//Set background color
	color_array = new  Color[] {					//Initlize ball color array
		Color.blue, Color.yellow, Color.orange,
		Color.white, Color.green,Color.red
		};
	
	ball_array = new Ball[maxballs];				//Init ball_array to maxballs 
	gunnoise = getAudioClip (getCodeBase() , "gun.au");
	hitnoise = getAudioClip (getCodeBase() , "score.au");
	startnoise = getAudioClip (getCodeBase() , "spacemusic.au");
	gameovernoise = getAudioClip (getCodeBase() , "gameover.au");
	startnoise.play();				//Play Game intro music
	
	//Initilize Balls Array
	//**********************************
	for (count = 0; count < maxballs; count++){
	    if(count < maxballs){
	    // Make Ball
	    //*********
	    x=(int)(Math.random()*appletsize_x);
	       if(x < 20){x = 25;}
	    y=(int)(Math.random()*appletsize_y);
	    if(y < 20){y = 25;}
	    x_speed =(int)(Math.random()*maxspeed);
	    if(x_speed < 1){x_speed=1;}
	    y_speed = (int)(Math.random()*maxspeed);		
	    if(y_speed < 1){y_speed=1;}	
	    // rnd get color form color array
	    colorIndex=(int)(Math.random()*numcolors);
	    if(colorIndex < 0){colorIndex=0;}	
		ballcolor= color_array[colorIndex];
		ball =  new Ball(x,y,ball_width,ball_height,ballcolor,x_speed,y_speed,
		maxspeed,alive,appletsize_x,appletsize_y);
		ball_array[count] = ball;
		}
	}
}//end init



public void start ()
	{
		Thread th = new Thread (this);			//Create thread for game
		th.start ();
		}

public void stop()
	{
	  
	}

public void destroy()
	{
	removeMouseListener(this);
	}

public void run ()
	{
	addMouseListener(this);	
	
	while (end_of_game == false)	
		{
	// Check time remaining
	timeleft = mytimer.getTime();
	if(timeleft == 0){end_of_game = true;}
	
		// Test for end of game
		//test for all balls shot	
		//******************************************
		test=0; 
		for(count =0; count < maxballs ; count++){
		   if(ball_array[count].alive == false){
			test++;
			// test for all balls hit 
			if(test == maxballs){
				if(level<5){
					level++;
					movetonextlevel= true;
					repaint();
					delay(6000);
					movetonextlevel = false;	// reset level flag
					setGameLevel(level);
		  			init();	 
				  }else end_of_game = true;
				}
		   }
	  	}
						 					
		// Move balls
		for (count = 0; count < maxballs ; count++){
			if(ball_array[count].alive == true){
			  ball_array[count].move();
			}
		}
		repaint();	
		delay(20);
	}
//End of game
//***********************
	delay(2000);
	gameovernoise.play();
	repaint();
	destroy();
	
}//end run

public void delay(int time){
	try
		{
		// Stop Threads time ms
			th.sleep (time);
		}
		catch (InterruptedException ex)
		{
			// do nothing
		}

}

// Mouse implementintation
//*************************
 public void mousePressed(MouseEvent e) {
	
        double x = e.getX();
        double y = e.getY();
	
		gunnoise.play();
	for(count=0; count< maxballs ; count++){
	  	  if(ball_array[count].userHit(x,y)){
	 	  ball_array[count].killBall();
		  gotHit = true;

			//CHECK BALLS COLOR
			//red=100, white=50 yellow=10, orange =5 cyan=1000 green = 200
			//************************************************************
			if(ball_array[count].color == Color.red){ 
				score +=5;
			}else if(ball_array[count].color == Color.white){
				score +=10;
			}else if(ball_array[count].color == Color.yellow){
				score +=50;
			} else if(ball_array[count].color == Color.orange){
				score +=100;
			} else if(ball_array[count].color == Color.blue){
				score +=200;
			} else if(ball_array[count].color == Color.green){
				score +=1000;
				}
		  hitnoise.play();
		  } else {gotHit=false;}
	}//end for
	
	// loose 10 point for miss
	//*******************************
	if(gotHit == false){score+= -10;}
	if(score < 0){score=0;}
	
}//end mouse pressed
public void mouseClicked(MouseEvent e) {}
public void mouseReleased(MouseEvent e) {}
public void mouseEntered(MouseEvent e) {
       repaint();
    }
public void mouseExited(MouseEvent e) {
       repaint();
    }

//Set Level of play
//*****************************
public void setGameLevel(int level){
	if(level == 1){
		maxballs = 10;
		maxspeed = 3;
		ball_height=40;
		ball_width=40;
	}
	if(level == 2){
		maxballs = 20;
		maxspeed = 4;
		ball_height=30;
		ball_width=30;
	 }
	if(level == 3){
		maxballs = 30;
		maxspeed = 5;
		ball_height=20;
		ball_width=20;
	}
	if(level == 4){
		maxballs = 40;
		maxspeed = 5;
		ball_height=15;
		ball_width=15;
	}
	if(level == 5){
		maxballs = 50;
		maxspeed = 5;
		ball_height=10;
		ball_width=10;
	}
 }

/** Update - double buffering */
//******************************
public void update (Graphics g)
	{
		// Init DoubleBuffers
		if (dbImage == null)
		{
			dbImage = createImage (this.getSize().width, this.getSize().height);
			dbg = dbImage.getGraphics ();
		}
	
		// Bildsceen
		dbg.setColor (getBackground ());
		dbg.fillRect (0, 0, this.getSize().width, this.getSize().height);
	
		// set foreground
		dbg.setColor (getForeground());
		paint (dbg);

		// build offscreen image
		g.drawImage (dbImage, 0, 0, this);
	}//end update


//PAINT SCREEN
//*******************************
public void paint (Graphics g)
	{
	
		if( movetonextlevel == true){
			g.setColor(Color.black);
			g.fillRect(0,0,appletsize_x,appletsize_y);
			g.setColor(Color.yellow);
			g.setFont(large);
			g.drawString("Moving to Level: "+level,60,150);
			}
		g.setColor(Color.yellow);
		g.setFont(realsmall);	
		g.drawString("Ver 1.0, Copyright(c) 2002 By Charles L. Wilson",40,295);
		String s = Integer.toString(score);
		String l = Integer.toString(level);
		String t = Integer.toString(timeleft);
		g.setColor(Color.white);
		g.setFont(small);
		g.drawString("SCORE= "+s,10,280);
		g.drawString("SKILL LEVEL= "+l,200,280);
		g.drawString("Time:"+t,120,280);
	  for (count = 0; count < maxballs ; count++){
		
			if(ball_array[count].alive == true){
				ball_array[count].drawBall(g);
			}
		 }
		 	if(end_of_game == true){
			g.setColor(Color.blue);
			g.fillRect(60,117,190,50);
			g.setFont(large);
			g.setColor(Color.yellow);
			g.drawString("END OF GAME",70,150);
			}

	}//end paint
	
}//end class
