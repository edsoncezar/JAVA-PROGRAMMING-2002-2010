/* Time Class 
	When given a number it will count down to zero in 
	one second intervals. Method getTime() when called 
	will return the current count. 
	Copyright(c) 2002 By Charles Wilson. All Rights Reserved
	webmaster@getimage.com
*/	


public class GameTimer extends Thread implements Runnable {

private int count;
private Thread timer;

//Constructor
public GameTimer(int gamelength){
	count=gamelength;
	start();
		}	
public void start(){
		timer = new Thread(this);
		timer.start();
		}

				
public void run(){

	while(count != 0){
	try
		{
		// Stop Threads 1 second
			timer.sleep (1000);
		}
		catch (InterruptedException ex)
		{
			// do nothing
		}
	 count--;
	 }
}

// Used to return time left for game
public int getTime(){
 		return(count);
  }
}