

import java.awt.*;
import java.util.*;

public class Ball{

//Vars here
public boolean alive = true;
public Color color;

private int ballwidth,ballheight;			
private int x_pos,y_pos;
private int x_speed;
private int y_speed;
private int aim_adjust;
private int appletsize_x; 
private int appletsize_y;	 
private int maxspeed, first_x,first_y;
private Random rnd = new Random ();				//Initilize random generator

//CONTROCTER THE BALL
//**********************************
public Ball(
		int x,
		int y,
		int x_size,
		int y_size,
		Color color,
		int xsp,int ysp,
		int max,
		boolean state,
		int appsize_x,
		int appsize_y)	{

					x_pos = x;
					y_pos = y;
					first_x=x;
					first_y=y;
					ballwidth = x_size;
					ballheight = y_size;
					this.color = color;
					x_speed = xsp;
					y_speed = ysp;
					maxspeed = max;
					alive = state;
					appletsize_x = appsize_x;
					appletsize_y = appsize_y;
					}


//LETS MOVE SOMETHING
//********************
public void move(){
	y_pos += y_speed;
	x_pos += x_speed;
	isOut();
	
}

//DID WE HIT THE BALL?
//******************
public boolean userHit(double maus_x, double maus_y){
    if (alive == true){
	  aim_adjust =(ballwidth/2);					// Adjust for bad aim.. 
	  double x = maus_x - x_pos - aim_adjust;
	  double y = maus_y - y_pos-aim_adjust;
 	  double distance = Math.sqrt ((x*x) + (y*y));
	  if (distance < aim_adjust)
		{
		 	return true;
		}else return false;

	}	
	 	  return false;
}

//IS THE BALL GOING OUT OF RANGE
//IF SO CHANGE SPEED AND REVERSE DIRECTION
//*******************************
private boolean isOut(){

	if(x_pos < 5 ){
		if(x_speed <1){
		  x_speed = (int)(Math.random()*maxspeed);
		  
	  	}
	  return(true);
	}

	else if(y_pos < 5 ){
	     	if(y_speed <1){
	        y_speed = (int)(Math.random()*maxspeed);
		}
	  return(true);
	 }

	else if(y_pos > appletsize_y ){
	       if(y_speed > -1){
	          y_speed = (int)(Math.random()*maxspeed);
	          y_speed= y_speed -(y_speed *2);
		 }
	  return(true);
	 }

	else if(x_pos > appletsize_x ){
	       if(x_speed > -1){
	          x_speed = (int)(Math.random()*maxspeed);
	          x_speed= x_speed -(x_speed *2);
		}
	  return(true);
	}
	
	
	return(true);

}

//IF BALL WAS HIT MAKE BALL DIE
//*****************************
public void killBall(){
	alive=false;
	}

//DRAW THE CURRENT BALL
//*******************************
public void drawBall(Graphics g){
      g.setColor(color);
      g.fillOval(x_pos,y_pos,ballwidth,ballheight);
	
 }

}//end of class
