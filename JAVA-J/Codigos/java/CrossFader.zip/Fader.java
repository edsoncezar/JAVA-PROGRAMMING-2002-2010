//
// Text fader
//
// (C)1999
// Brian Postma
// b.postma@hetnet.nl
//

import java.awt.*;
import java.applet.Applet;

public class Fader extends Applet implements Runnable
{
  Dimension	d;
  Image         ii;
  Graphics      goff;
  Thread	thethread;
  Font 		font = new Font("Helvetica", Font.BOLD, 36);
  FontMetrics	fm;  
  String	s1;
  String	s2;
  int		color1, color2;
  int		dcolor1, dcolor2;

  public String getAppletInfo()
  {
    return("Text fader - by Brian Postma");
  }

  public void init()
  {
    Graphics    g;
    int		i;
    d = size();
    g=getGraphics();
    g.setFont(font);
    fm = g.getFontMetrics();
    setBackground(Color.black);
    s1=getParameter("Text1");
    s2=getParameter("Text2");
    color1=10;
    color2=245;
    dcolor2=-2;
    dcolor1=2;
  }

  public void paint(Graphics g)
  {
    if (goff==null && d.width>0 && d.height>0)
    {
      ii = createImage(d.width, d.height);
      goff = ii.getGraphics();
    }
    if (goff==null || ii==null)
      return;

    g.setFont(font);
    goff.setFont(font);

    if (color1<color2)
    {
      goff.setColor(new Color(color1/4, color1/2, color1));
      goff.drawString(s1,(d.width-fm.stringWidth(s1)) / 2, d.height/2 );
      goff.setColor(new Color(color2/4, color2/2, color2));
      goff.drawString(s2,(d.width-fm.stringWidth(s2)) / 2, d.height/2 );
    }
    else
    {
      goff.setColor(new Color(color2/4, color2/2, color2));
      goff.drawString(s2,(d.width-fm.stringWidth(s2)) / 2, d.height/2 );
      goff.setColor(new Color(color1/4, color1/2, color1));
      goff.drawString(s1,(d.width-fm.stringWidth(s1)) / 2, d.height/2 );
    }
    g.drawImage(ii, 0, 0, this);

    color1+=dcolor1;
    color2+=dcolor2;
    if (color1<=3 || color1>=250)
      dcolor1=-dcolor1;
    if (color2<=3 || color2>=250)
      dcolor2=-dcolor2;
  }

  public void run()
  {
    long  starttime;
    Graphics g;
 
    Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
    g=getGraphics();
    while(true)
    {
      starttime=System.currentTimeMillis();
      try
      {
        paint(g);
        starttime += 20;
        Thread.sleep(Math.max(0, starttime-System.currentTimeMillis()));
      }
      catch (InterruptedException e)
      {
        break;
      }
    }
  }

  public void start()
  {
    if (thethread == null) {
      thethread = new Thread(this);
      thethread.start();
    }
  }

  public void stop()
  {
    if (thethread != null) {
      thethread.stop();
      thethread = null;
    }
  }
}
