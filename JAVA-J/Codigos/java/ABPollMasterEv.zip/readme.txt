
FIRST READ AND ACCEPT THE LICENSE BEFORE USING THIS SOFTWARE.

--------------------------------

VISIT http://www.wyka-warzecha.com for the latest
information about other products, such as the

Wyka-Warzecha BannerMan!    - Add Amazing Special Image FX to your website!
Wyka-Warzecha NewsMan!      - Have a scrolling news ticker with FX to your website!
Wyka-Warzecha MiniSpeak!    - Add Streaming Audio & Speech Enable your website!
Wyka-Warzecha AScratchNWin! - Add amazing scratch and win capabilities to your website!
Wyka-Warzecha ABCMenuMan!   - Add amazing menu effects to your website!

Quick Docs:
-------------------

To 'Install' this, simply unzip all the contents to a directory on your website,
and then you can load in the documents from the 'index' page. Be sure to
replace the license key.

Quick Docs for Wyka-Warzecha ABPollMaster!:
-------------------

1. Start-up (Sample & Adding it to your webpages)

------------------
1. Start-up (Sample & Adding it to your webpages)
------------------

For a quick start, simply extract all the files to a directory on your website,
and then load in the example.html page. Be sure to replace the license key
so that it will operate!
