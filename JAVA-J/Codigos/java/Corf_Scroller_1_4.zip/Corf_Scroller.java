/*
 * Corf_Scroller.java  1.4 May 28, 2000
 *
 * Copyright (c) 1998, 1999, 2000 by Robert Corfman.  All rights reserved.
 *
 * I reserve all rights to this software.  You may use it and
 * distribute it freely, provided you do not remove this header
 * and attribute partial credit to the author, Robert Corfman (robert@corfman.com).
 */
//******************************************************************************
// Corf_Scroller.java:  Applet
//
//******************************************************************************
import java.applet.*;
import java.awt.*;
import java.net.URL;
import java.net.MalformedURLException;
//==============================================================================
// Main Class for applet Corf_Scroller
//
//==============================================================================
public class Corf_Scroller extends Applet implements Runnable
{
	// THREAD SUPPORT:
	// m_Corf_Scroller is the Thread object for the applet
	//--------------------------------------------------------------------------
	private Thread   m_Corf_Scroller = null;

	// PARAMETER SUPPORT:
	// Parameters allow an HTML author to pass information to the applet;
	// the HTML author specifies them using the <PARAM> tag within the <APPLET>
	// tag.  The following variables are used to store the values of the parameters.
	//--------------------------------------------------------------------------

	// Members for applet parameters
	// <type>       <MemberVar>       = <Default Value>
	//--------------------------------------------------------------------------
	private final String Scroller_Address = "http://www.corfman.com/robert/Java/Corf_Scroller";
	private String m_Corf_Link;
	private String m_Corf_Target;
	private String m_Corf_Text        = "Robert Corfman's Scrolling Applet. Email: Robert@Corfman.com for more info ";
	private int m_Corf_Timer          = 50;
	private Color m_Corf_BackGround   = Color.white;
	private Color m_Corf_ForeGround   = Color.black;
	private int m_Corf_Thickness      = 1;
	private Color m_Corf_Border       = Color.gray;
	private boolean m_Corf_Status     = true;
	private boolean m_Corf_Jump       = true;
	private boolean m_Corf_Alt_Status = false;
	private String m_Corf_Status_Msg;
	private String m_Corf_Font;

	// Global Variables for use within the class.
	//--------------------------------------------------------------------------
	private int i_Corf_Pos = 1;
	private int i_Corf_Len = 0;
	private int i_Corf_y = 0;
	private int i_Corf_Width = 0;
	private int i_Corf_Height = 0;
	private Font f_Corf_New;
	private Image im_Corf_Buf = null;
	private Graphics g_Corf_Buf;
	private Image im_Corf_Text = null;
	private Graphics g_Corf_Text;

	// APPLET INFO SUPPORT:
	// The getAppletInfo() method returns a string describing the applet's
	// author, copyright date, or miscellaneous information.
	//--------------------------------------------------------------------------
	public String getAppletInfo()
	{
		return "Name: Corf_Scroller\r\nAuthor: Robert Corfman\r\nVersion: 1.4\r\nCreated: May 28,2000\r\nE-Mail: Robert@corfman.com";
	}

	// PARAMETER SUPPORT
	// The getParameterInfo() method returns an array of strings describing
	// the parameters understood by this applet.
	//
	// CORF_SCROLLER Parameter Information:
	//  { "Name", "Type", "Description" },
	//--------------------------------------------------------------------------
	public String[][] getParameterInfo()
	{
		String[][] info =
		{ 
			{ "Corf_Link", "URL", "Targe Link when applet is clicked" },
			{ "Corf_Target", "String", "Target window when jumping to Link" },
			{ "Corf_Text", "String", "Text to Scroll in the Applet Area" },
			{ "Corf_Timer", "int", "Time in Milliseconds between scrolling pixel" },
			{ "Corf_Background", "Color", "Background Color in HEX format of RRGGBB.  white-FFFFFF, black-000000" },
			{ "Corf_Foreground", "Color", "Foreground Color in HEX format(See BackGround)" },
			{ "Corf_Thickness", "String", "Applet Border Thickness" },
			{ "Corf_Border", "String", "Applet Border Color" },
			{ "Corf_Status", "boolean", "<>0 Changes status line on mouse over, 0 does nothing" },
			{ "Corf_Jump", "boolean", "<>0 Jumps to Link on click, 0 does nothing" },
			{ "Corf_Alt_Status", "boolean", "<>0 Displays Als Msg Below, 0 displays Link param" },
			{ "Corf_Status_Msg", "String", "Alt Msg to display in status line on mouse over" },
			{ "Corf_Font", "String", "Name of the Font to use(Can be unpredictable to override font name)" },
		};
		return info;            
	}

	// The init() method is called by the AWT when an applet is first loaded or
	// reloaded.  Override this method to perform whatever initialization your
	// applet needs, such as initializing data structures, loading images or
	// fonts, creating frame windows, setting the layout manager, or adding UI
	// components.
	//--------------------------------------------------------------------------
	public void init()
	{
		// store the applet width, height and font for later use.
		i_Corf_Width = size().width;
		i_Corf_Height = size().height;
		f_Corf_New = getFont();

		// PARAMETER SUPPORT
		// The following code retrieves the value of each parameter
		// specified with the <PARAM> tag and stores it in a member
		// variable.
		//----------------------------------------------------------------------
		String param;

		// Corf_Link: Link to go to when the applet is clicked
		if ((m_Corf_Link = getParameter("Corf_Link")) == null)
			m_Corf_Link = Scroller_Address;

		// Corf_Target: Target window to open when the applet is clicked
		//----------------------------------------------------------------------
		if ((m_Corf_Target = getParameter("Corf_Target")) == null)
			m_Corf_Target = "_self";

		// Corf_Text: Text to Scroll within the Applet Area
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Text")) != null)
			m_Corf_Text = param.concat(" ");

		// Corf_Timer: Time in Milliseconds to pause between scrolling the text in the window
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Timer")) != null)
			if ((m_Corf_Timer = Integer.parseInt(param)) < 10)
				m_Corf_Timer = 10;

		// Corf_BackGround: The Background Color to Be Used in HEX format of RRGGBB.  FFFFFF is white 000000 is black
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Background")) != null)
			m_Corf_BackGround = new Color(Integer.parseInt(param,16));

		// Corf_ForeGround: The Foreground Color to Be Used in HEX format of RRGGBB.  FFFFFF is white 000000 is black
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Foreground")) != null)
			m_Corf_ForeGround = new Color(Integer.parseInt(param,16));

		// Corf_Thickness: Thickness of the border around the applet's text
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Thickness")) != null)
			if ((m_Corf_Thickness = Integer.parseInt(param)) < 0)
				m_Corf_Thickness = 0;

		// Corf_Border: The Border Color to Be Used in HEX format of RRGGBB.  FFFFFF is white 000000 is black
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Border")) != null)
			m_Corf_Border = new Color(Integer.parseInt(param,16));

		// Corf_Status: 1 to change status line when mouse is over applet, 0 to leave default
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Status")) != null)
			m_Corf_Status = (Integer.parseInt(param) != 0);

		// Corf_Jump: 1 to jump to Link when applet is clicked, 0 to do nothing
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Jump")) != null)
			m_Corf_Jump = (Integer.parseInt(param) != 0);

		// Corf_Alt_Status: 1 to display alternate supplied status message, 0 to display Link parameter
		//----------------------------------------------------------------------
		if ((param = getParameter("Corf_Alt_Status")) !=null)
			m_Corf_Alt_Status = (Integer.parseInt(param) != 0);

		// Corf_Status_Msg: Alternate message to display in the status line when the mouse is over the applet
		//----------------------------------------------------------------------
		if ((m_Corf_Status_Msg = getParameter("Corf_Status_Msg")) == null)
			m_Corf_Status_Msg = Scroller_Address;

		// Corf_Font: Name of the Font to use in the scrolling window (it can be unpredictable to override the font name)
		//----------------------------------------------------------------------
		m_Corf_Font = (param = getParameter("Corf_Font")) != null?param:f_Corf_New.getName();

		FontMetrics fm_temp = null;
		// set the default font size
		int i_Size_Temp = f_Corf_New.getSize();
		// find the correct font size, first, enlarge till it is too big
		do
			f_Corf_New = new Font(m_Corf_Font,Font.PLAIN,++i_Size_Temp);
		while( fit_font() );
		// now, shrink till it fits the correct height
		while( !fit_font() && (i_Size_Temp > 2) )
			f_Corf_New = new Font(m_Corf_Font,Font.PLAIN,--i_Size_Temp);
		fm_temp = getFontMetrics(f_Corf_New);
		i_Corf_Len = fm_temp.stringWidth(m_Corf_Text);
		int i_Ascent_temp = fm_temp.getAscent();
		i_Corf_y = (i_Corf_Height>>1)-((i_Ascent_temp+fm_temp.getDescent())>>1)+i_Ascent_temp;

		// Create the new text image and graphics context
		im_Corf_Text = createImage(i_Corf_Len, i_Corf_Height);
		g_Corf_Text = im_Corf_Text.getGraphics();
		g_Corf_Text.setColor(m_Corf_BackGround);
		g_Corf_Text.fillRect(0,0,i_Corf_Len,i_Corf_Height);
		g_Corf_Text.setColor(m_Corf_ForeGround);
		g_Corf_Text.setFont(f_Corf_New);
		g_Corf_Text.drawString(m_Corf_Text,0,i_Corf_y);

		// Create the offscreen image and graphics context
		if (im_Corf_Buf == null)
			im_Corf_Buf = createImage(i_Corf_Width, i_Corf_Height);
		g_Corf_Buf = im_Corf_Buf.getGraphics();
	}

	// routine used to identify the correct font size for the applet height
	//-------------------------------------------------------------------------
	public boolean fit_font()
	{
		FontMetrics fm_temp = getFontMetrics(f_Corf_New);
		return ( i_Corf_Height-(m_Corf_Thickness<<1) > fm_temp.getMaxAscent() + fm_temp.getMaxDescent() );
	}

	// the update event should just call paint directly.
	//-------------------------------------------------------------------------
	public void update(Graphics g) {paint(g);}

	// CORF_SCROLLER Paint Handler
	//--------------------------------------------------------------------------
	public void paint(Graphics g)
	{
		int i_left;
		if ( ++i_Corf_Pos > i_Corf_Len ) i_Corf_Pos = 1;
		i_left = i_Corf_Pos *-1;
		do
		{
			g_Corf_Buf.drawImage(im_Corf_Text,i_left,0,this);
			i_left += i_Corf_Len;
		} while (i_left < i_Corf_Width);
		g_Corf_Buf.setColor(m_Corf_Border);
		for( i_left=0; i_left < m_Corf_Thickness; i_left++)
			g_Corf_Buf.draw3DRect(i_left,i_left,i_Corf_Width-(i_left<<1)-1,i_Corf_Height-(i_left<<1)-1,false);

		g.drawImage(im_Corf_Buf,0,0,this);
	}

	// The start() method is called when the page containing the applet
	// first appears on the screen. The AppletWizard's initial implementation
	// of this method starts execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void start()
	{
		if (m_Corf_Scroller == null)
		{
			m_Corf_Scroller = new Thread(this);
			m_Corf_Scroller.start();
		}
	}

	// The stop() method is called when the page containing the applet is
	// no longer on the screen. The AppletWizard's initial implementation of
	// this method stops execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void stop()
	{
		if (m_Corf_Scroller != null)
		{
			m_Corf_Scroller.stop();
			m_Corf_Scroller = null;
		}
	}

	// THREAD SUPPORT
	// The run() method is called when the applet's thread is started. If
	// your applet performs any ongoing activities without waiting for user
	// input, the code for implementing that behavior typically goes here. For
	// example, for an applet that performs animation, the run() method controls
	// the display of images.
	//--------------------------------------------------------------------------
	public void run()
	{
		while (true)
		{
			try
			{
				repaint();
				Thread.sleep(m_Corf_Timer);
			}
			catch (InterruptedException e)
			{
				stop();
			}
		}
	}

	// MOUSE SUPPORT:
	// The mouseDown() method is called if the mouse button is pressed
	// while the mouse cursor is over the applet's portion of the screen.
	//--------------------------------------------------------------------------
	public boolean mouseDown(Event evt, int x, int y)
	{
		if( m_Corf_Jump)
		{
			try
			{
				getAppletContext().showDocument(new URL(m_Corf_Link), m_Corf_Target);
			}
			catch (MalformedURLException e)
			{
				m_Corf_Text = "Error|MalformedURLException|Target URL invalid|";
			}
		}
		return true;
	}

	// MOUSE SUPPORT:
	// The mouseEnter() method is called if the mouse cursor is moved 
	// over the applet's portion of the screen.
	//--------------------------------------------------------------------------
	public boolean mouseEnter(Event evt, int x, int y)
	{
		if( m_Corf_Status )
 			getAppletContext().showStatus(m_Corf_Alt_Status?m_Corf_Status_Msg:m_Corf_Link);       
		return true;
	}

	// MOUSE SUPPORT:
	// The mouseExit() method is called if the mouse cursor is moved 
	// out of the applet's portion of the screen.
	//--------------------------------------------------------------------------
	public boolean mouseExit(Event evt, int x, int y)
	{
		if( m_Corf_Status )
			getAppletContext().showStatus(" ");     
		return true;
	}
}