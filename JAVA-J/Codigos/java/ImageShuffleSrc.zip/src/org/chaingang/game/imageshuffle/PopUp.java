package org.chaingang.game.imageshuffle;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PopUp extends JPopupMenu
{
   private JMenuItem mPlay;
   private JMenuItem mPeek;
   private JMenuItem mUnpeek;
   private JMenuItem mRestart;
   private JMenuItem mStatus;
   private JMenuItem mAbout;
   private JMenuItem firstMenuItem;
   private int mouseMove;
   private boolean isWin = false;



   public PopUp(ActionListener parentListener) {
      super();

      JMenuItem menuItem;

      menuItem = new JMenuItem("Peek");
      menuItem.setActionCommand(Globals.CMD_PEEK);
      menuItem.addActionListener(parentListener);
      add(menuItem);
      mPeek= menuItem;

      menuItem = new JMenuItem("Play");
      menuItem.setActionCommand(Globals.CMD_PLAY);
      menuItem.addActionListener(parentListener);
      add(menuItem);
      mPlay = menuItem;

      menuItem = new JMenuItem("Restart");
      menuItem.setActionCommand(Globals.CMD_PLAY);
      menuItem.addActionListener(parentListener);
      add(menuItem);
      mRestart= menuItem;


      menuItem = new JMenuItem("Resume");
      menuItem.setActionCommand(Globals.CMD_UNPEEK);
      menuItem.addActionListener(parentListener);
      add(menuItem);
      mUnpeek= menuItem;

      menuItem = new JMenuItem("About");
      menuItem.setActionCommand(Globals.CMD_ABOUT);
      menuItem.addActionListener(parentListener);
      add(menuItem);
      mAbout= menuItem;


      addSeparator();

      menuItem = new JMenuItem("-");
      menuItem.setEnabled(false);
      add(menuItem);
      mStatus = menuItem;

      setPlay();
   }


   private void setPlay() {
      mPlay.setVisible(true);
      mPeek.setVisible(false);
      mUnpeek.setVisible(false);
      mRestart.setVisible(false);
      firstMenuItem = mPlay;
      mStatus.setText("-");
   }


   private void setPlaying() {
      mPlay.setVisible(false);
      mPeek.setVisible(true);
      mUnpeek.setVisible(false);
      mRestart.setVisible(true);
      firstMenuItem = mPeek;
   }


   private void setPeek() {
      mPlay.setVisible(false);
      mPeek.setVisible(false);
      mUnpeek.setVisible(true);
      mRestart.setVisible(false);
      firstMenuItem = mUnpeek;
   }


   public void setStatus(String s) {
      if (s.equals(Globals.CMD_PLAY)) {
         setPlaying();
      } else if (s.equals(Globals.CMD_PEEK)) {
         setPeek();
      } else if (s.equals(Globals.CMD_UNPEEK)) {
         setPlaying();
      } else if (s.equals(Globals.CMD_WIN)) {
         setPlay();
      }
      pack();
   }

   public void show(MouseEvent e) {
      show(e.getComponent(), e.getX(), e.getY());
   }


   public void fireFirst() {
      firstMenuItem.doClick();
   }


   private void updateStatusText() {
      if (isWin) {
         mStatus.setText("won in " + String.valueOf(mouseMove) + " moves");
      } else {
         mStatus.setText("played " + String.valueOf(mouseMove) + " move" + (mouseMove==1 ? "" : "s"));
      }

   }


   public void setMoves(int mouseMove) {
      this.mouseMove=mouseMove;
      updateStatusText();
   }

   public void setWin(boolean isWin) {
      this.isWin=isWin;
      updateStatusText();
   }


}

