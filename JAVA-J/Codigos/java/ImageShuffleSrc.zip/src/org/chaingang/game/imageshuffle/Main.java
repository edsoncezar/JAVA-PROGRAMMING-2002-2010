package org.chaingang.game.imageshuffle;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.util.*;
import java.io.*;
import org.chaingang.common.AppProperties;
import org.chaingang.common.AboutBox;

public class Main extends JApplet
   implements ActionListener
{
   private MediaTracker mt;
   Puzzle canvas;
   PopUp popup;
   AppProperties ap;
   public boolean isAppletContext = true;
   public String puzzleStatus = Globals.CMD_WIN;
   AboutBox aboutbox;


   public void init(){
      aboutbox = new AboutBox(
         "Image Puzzle",
         "Copyleft (c) 2002 brett@chaingang.org",
         "http://www.chaingang.org/code/game/",
         (isAppletContext ? this : null )
      );
      ap = new AppProperties();
      mt = new MediaTracker(this);
      loadParms();
      Image imageLoad = getImageUrl();

      canvas = new Puzzle(this, imageLoad,
         ((Integer)ap.get("cols")).intValue(),
         ((Integer)ap.get("rows")).intValue(),
         (Color) ap.get("color.empty"),
         (Color) ap.get("color.puzzle")
      );

      Container content = getContentPane();

      content.setLayout(new BorderLayout());
      JPanel pan = new JPanel();
      pan.setBackground((Color) ap.get("color.background"));
      pan.setLayout(new BoxLayout(pan, BoxLayout.X_AXIS));
      pan.add(Box.createHorizontalGlue());
      pan.add(canvas);
      pan.add(Box.createHorizontalGlue());
      content.add(pan, BorderLayout.CENTER );

      popup = new PopUp(this);

      canvas.addMouseListener(
         new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
               if (e.getClickCount()==2) {
                  popup.fireFirst();
               }
            }
            public void mousePressed(MouseEvent e) {
               if (e.isPopupTrigger()) {
                  popup.setMoves( canvas.getMoveCount() );
                  popup.show(e);
               }
            }
            public void mouseReleased(MouseEvent e) {
               if (e.isPopupTrigger()) {
                  popup.setMoves( canvas.getMoveCount() );
                  popup.show(e);
               }
            }
         }
     );

      validate();
   }


   private Image getImageUrl() {
      Image img = null;

      URL url = (URL) ap.get("image.url");
      if ( ap.isDefUrl(url) ) {
         img = Toolkit.getDefaultToolkit().getImage(
            getClass().getResource((String) ap.get("image.resource"))
         );
      } else {
         img = getImage(url);
      }

      mt.addImage(img, 0);
      try {
         mt.waitForID(0);
      } catch (InterruptedException ie)  {
         System.err.println(ie);
         System.exit(1);
      }
      return img;

   }


   public void actionPerformed(ActionEvent e) {
      boolean statusChange = true;
      String cmd = e.getActionCommand();

      if (cmd.equals(Globals.CMD_PLAY)) {
         popup.setWin(false);
         canvas.cmdShuffle();
      } else if (cmd.equals(Globals.CMD_PEEK)) {
         canvas.setPlayState(false);
      } else if (cmd.equals(Globals.CMD_UNPEEK)) {
         canvas.setPlayState(true);
      } else if (cmd.equals(Globals.CMD_WIN)) {
         canvas.setPlayState(false);
         popup.setWin(true);
      } else if (cmd.equals(Globals.CMD_ABOUT)) {
         aboutbox.show();
      } else {
         statusChange = false;
      }

      if (statusChange) {
         puzzleStatus = cmd;
         popup.setStatus(puzzleStatus);
      }
   }


   public String getAppletInfo() { return "Image Shuffle Game"; }


   public String[][] getParameterInfo() {
      return ap.getParameterInfo();
   }


   private void loadParms() {
      ap.add("cols", (Object) new Integer(4), "columns in puzzle");
      ap.add("rows", (Object) new Integer(4), "rows in puzzle");
      ap.add("image.url", (Object) ap.getDefUrl(), "url to image for puzzle");
      ap.add("image.resource", (Object) new String("default.jpg"), "class resource name for image for puzzle");
      ap.add("color.empty", (Object) Color.black, "color for empty piece");
      ap.add("color.puzzle", (Object) Color.white, "color for puzzle background");
      ap.add("color.background", (Object) Color.white, "color for app background");
      try {
        ap.loadProperties(getClass().getResourceAsStream("ImageShuffleDefault.properties"));
      } catch (java.io.IOException  e) { }

      if (isAppletContext) {
         ap.loadParameters(this);
      } else {
         try {
            ap.loadProperties(getClass().getResourceAsStream("ImageShuffle.properties"));
         } catch (java.io.IOException  e) { }
      }

   }




    public static void main(String s[]) throws Exception {
        JFrame f = new JFrame("ImageShuffle");
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {System.exit(0);}
        });

        Main app = new Main();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        app.isAppletContext = false;

        f.getContentPane().add("Center", app );
        app.init();
        f.pack();
        Dimension frameSize = new Dimension ( app.getSize().width+20, app.getSize().height+50 );
        f.setSize(frameSize.width, frameSize.height );
        f.setLocation(
           screenSize.width/2 - (frameSize.width/2),
           screenSize.height/2 - (frameSize.height/2)
        );

        ImageIcon icon = new ImageIcon( app.getClass().getResource( "icon.gif"));
        f.setIconImage( icon.getImage());

        f.show();
    }

}
