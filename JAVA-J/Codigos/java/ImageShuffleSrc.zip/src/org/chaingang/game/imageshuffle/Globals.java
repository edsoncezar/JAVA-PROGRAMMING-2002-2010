package org.chaingang.game.imageshuffle;

public class Globals {
   public final static String CMD_PLAY = "c_play";
   public final static String CMD_PEEK = "c_peek";
   public final static String CMD_UNPEEK = "c_unpeek";
   public final static String CMD_RESHUFFLE = "c_reshuffle";
   public final static String CMD_STATUS_UPDATE = "c_status_update";
   public final static String CMD_WIN = "c_win";
   public final static String CMD_ABOUT = "c_about";
}


