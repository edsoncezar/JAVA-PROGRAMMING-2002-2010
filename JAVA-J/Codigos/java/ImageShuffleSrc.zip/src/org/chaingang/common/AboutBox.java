package org.chaingang.common;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;

public class AboutBox extends JDialog
   implements ActionListener
{
   private final String ACTION_OK = "a_ok";
   private final String ACTION_LINK = "a_link";
   Applet applet = null;
   String url = null;

   public AboutBox(String title, String copy, String link) {
      this(title, copy, link, null);
   }


   public AboutBox(String title, String copy, String link, Applet applet) {
      super();
      this.applet = applet;
      setTitle("About");

      JButton but;
      JLabel lab;

      setResizable(false);
      setModal(true);

      Container content = getContentPane();
      getRootPane().setBorder(
         BorderFactory.createLineBorder(content.getBackground(), 5)
      );

      content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

      lab=new JLabel(title);
      lab.setAlignmentX(Component.CENTER_ALIGNMENT);
      content.add(lab);

      lab=new JLabel(copy);
      lab.setAlignmentX(Component.CENTER_ALIGNMENT);
      content.add(lab);

      if (applet != null) {
         this.url = link;
         but = new JButton(link);
         but.setBorder( BorderFactory.createEmptyBorder() );
         but.setAlignmentX(Component.CENTER_ALIGNMENT);
         but.setActionCommand(ACTION_LINK);
         but.addActionListener(this);
         content.add(but);
      } else {
         lab=new JLabel(link);
         lab.setAlignmentX(Component.CENTER_ALIGNMENT);
         content.add(lab);
      }


      content.add(Box.createVerticalStrut(10) );

      but = new JButton("OK");
      but.setAlignmentX(Component.CENTER_ALIGNMENT);
      but.setActionCommand(ACTION_OK);
      but.addActionListener(this);
      content.add(but);

      this.pack();
      centerScreen();
    }


    public void centerScreen() {
       Dimension frameSize = new Dimension ( getSize() );
       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
       setLocation(
          screenSize.width/2 - (frameSize.width/2),
          screenSize.height/2 - (frameSize.height/2)
       );
    }


    public void actionPerformed(ActionEvent e) {
       String cmd = e.getActionCommand();

       if (cmd.equals(ACTION_OK)) {
          setVisible(false);
       } else if (cmd.equals(ACTION_LINK)) {
          URL linkUrl =  null;

          try {
             linkUrl = new URL(url);
          } catch (java.net.MalformedURLException ex) {
          }

          if (linkUrl!=null) {
             try {
                applet.getAppletContext().showDocument(linkUrl,"_blank");
             } catch (Exception ex2) {
             }
          }
       }
   }

}
