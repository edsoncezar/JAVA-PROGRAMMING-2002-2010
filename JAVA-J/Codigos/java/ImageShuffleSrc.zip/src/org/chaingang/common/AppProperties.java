package org.chaingang.common;

import java.awt.Color;
import java.net.*;
import java.util.*;
import java.io.*;

public class AppProperties {
   private Hashtable hashProps = new Hashtable();
   private Hashtable hashDesc = new Hashtable();
   protected final String URL_DEF = "http://www.chaingang.org";

   public AppProperties() {
   }

   public void add(String propertyName, Object propertyDefaultObject) {
      hashProps.put(propertyName, propertyDefaultObject);
   }

   public void add(String propertyName, Object propertyDefaultObject, String description) {
      add(propertyName, propertyDefaultObject);
      hashDesc.put(propertyName, description);
   }


   public URL getDefUrl() {
      URL url=null;
      try {
         url = new URL(URL_DEF);
      } catch (MalformedURLException  e) { }
      return url;
   }

   public boolean isDefUrl(URL url) {
      URL urlDef=getDefUrl();
      return urlDef.equals(url);
   }


   public Object get(String propName) {
      return hashProps.get(propName);
   }


   public void loadParameters(java.applet.Applet applet) {
      String propName;
      Map.Entry entry;

      Iterator iterator = hashProps.entrySet().iterator();
      for (int i=0; i<hashProps.size(); i++) {
         entry = (Map.Entry) iterator.next();
         propName = (String) entry.getKey();
         setProperty(propName, applet.getParameter(propName));
      }
   }


   public void loadProperties(Properties props) {
      String propName;
      Map.Entry entry;

      Iterator iterator = hashProps.entrySet().iterator();
      for (int i=0; i<hashProps.size(); i++) {
         entry = (Map.Entry) iterator.next();
         propName = (String) entry.getKey();
         setProperty(propName, props.getProperty(propName));
      }
   }


   public void loadProperties(InputStream in) throws java.io.IOException {
      Properties props = new Properties();
      props.load(in);
      loadProperties(props);
   }


   public void setProperty(String propName, String propVal) {
      if (propVal==null) return;
      Object oVal = hashProps.get(propName);
      if (oVal==null) return;

      String className = oVal.getClass().getName();

      if ( className.equals("java.net.URL") ) {
         try {
            URL url = new URL(propVal);
            hashProps.put(propName, url);
         } catch (MalformedURLException  e) { }
      } else if ( className.equals("java.awt.Color") ) {
         try {
            Color c = Color.decode( propVal );
            hashProps.put(propName, c);
         } catch (NumberFormatException  e) { }
      } else if ( className.equals("java.lang.Integer") ) {
         try {
            int i = Integer.parseInt( propVal );
            hashProps.put(propName, new Integer( i ));
         } catch (NumberFormatException  e) { }
      } else {
         hashProps.put(propName, propVal);
      }

   }

   public String[][] getParameterInfo() {
      String [][] pi = new String [hashProps.size()][3];
      Map.Entry entry;

      Iterator iterator = hashProps.entrySet().iterator();
      for (int i=0; i<hashProps.size(); i++) {
         entry = (Map.Entry) iterator.next();
         pi[i][0] = (String) entry.getKey();
         pi[i][1] = entry.getValue().getClass().getName();
         pi[i][2] = (String) hashDesc.get( pi[i][0] );
      }

      return pi;
   }


}

