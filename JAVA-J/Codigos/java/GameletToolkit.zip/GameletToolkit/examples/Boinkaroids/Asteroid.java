/**

*
 * Asteroid.java
 * @author	Mark G. Tacchi (mtacchi@next.com) 
 * @version	0.8
 * Mar 11/1996

*
 * A generic Asteroid class which handles varying sizes of asteroids.  Images
 * should have filenames with corresponding S, M, L, and G appended to them
 * (example asteroidM.gif).
 * This Actor collides with Bullets and Ships.  It is responsible for creating
 * an explosion object.
 *
*/

import java.applet.Applet;
import java.lang.Math;

import com.next.gt.*;

public class Asteroid extends Actor {

  //
  // Size of the Asteroid.
  //
  public static final 	int	SMALL_SIZE= 0,
  					MEDIUM_SIZE= 1,
					LARGE_SIZE= 2;
  int				size;
  
  //
  // The filename prefix.
  //
  String			name;
  		
Asteroid(Gamelet theOwner, Asteroid explodee, String theName, int theSize) {
  super();
 
  String[]					theImageName= {"S", "M", "L", "G"};

 java.awt.Image			theImage;

  owner= theOwner;
  size= theSize;
  name= theName;
  
  if (theSize==LARGE_SIZE) {
    x= (Math.random()*512);
    y= (Math.random()*512);
    velocity_x= (double)((int)Gamelet.randBetween(0.5,1.5)*2 - 1) * Gamelet.randBetween(8.,32.);
    velocity_y= (double)((int)Gamelet.randBetween(0.5,1.5)*2 - 1) * Gamelet.randBetween(8.,32.);
  }
  else {
    x= explodee.x;
    y= explodee.y;
	velocity_x= explodee.velocity_x * Gamelet.randBetween(0.6,1.4);
	velocity_y= explodee.velocity_y * Gamelet.randBetween(0.6,1.4);
	
  }
  theImage = owner.getImage(owner.getCodeBase(), "images/" +theName + theImageName[theSize] + ".gif");
  setImage (theImage, 4, 32);

  currentFrame= (int)Gamelet.randBetween(0, numFrames);
  
} /*Asteroid()*/



/**
 * Explode asteroid.
 */
public void explode()
{
  Explosion anExplosion;
  
  //
  // create explosion if smallest asteroid
  //
  if (size==SMALL_SIZE) {
    anExplosion= new Explosion(owner, this);
    owner.actorManager.addActor(anExplosion);
  }
  else { 
    owner.play(owner.getCodeBase(), "sounds/explode1.au");
  }
  

  //
  // split off into smaller bits
  //
  if (size==LARGE_SIZE) {
    for (int i=0; i<2; i++) {
      owner.actorManager.addActor(new Asteroid(owner, this, name, MEDIUM_SIZE));
      ((Boinkaroids)owner).badGuyCount++;
	} /*next_i*/

  }
  else if (size==MEDIUM_SIZE) {
    for (int i=0; i<2; i++) {
      owner.actorManager.addActor(new Asteroid(owner, this, name, SMALL_SIZE));
      ((Boinkaroids)owner).badGuyCount++;
	} /*next_i*/
  }
  
  
  //
  // give credit for hitting me, increase score
  //
  owner.scoreManager.addToScore((2-size) * 200 + 100);
  
  //
  // i'm dead, i should schedule to be removed
  //
  owner.actorManager.removeActor(this);
  
  //
  // tell the gamelet that there is one less bad guy
  //
  ((Boinkaroids)owner).badGuyCount--;
  
} /*explode*/



/**
 * Handle collision with an actor.
 */
protected void collideWithActor (Actor theActor)
{
  String theActorClassName= theActor.getClass().getName();
  
  if (theActorClassName.equals("Bullet") ||
      theActorClassName.equals("Ship") ) {
    explode();
  } /*endif*/
  
} /*collideWithActor*/

} /*Asteroid*/
