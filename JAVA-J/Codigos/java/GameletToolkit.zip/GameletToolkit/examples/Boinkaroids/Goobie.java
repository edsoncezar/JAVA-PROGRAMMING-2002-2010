/**

*
 * Goobie.java
 * @author	Mark G. Tacchi (mtacchi@next.com) 
 * @version	0.8
 * Mar 18/1996

*

* A goobie is just a little green thing that lives within a transparent
 * shell until that shell pops.
 *
 * Goobies harm ships and bullets harm Goobies.
 *
*/

import java.applet.Applet;
import java.lang.Math;

import com.next.gt.*;

public class Goobie extends Actor {

  //
  // Gravity strength toward the ship.
  //
  private static double	GRAVITATIONAL_PULL= 0.5;
  
Goobie(Gamelet theOwner, Bigoobie explodee) {
  super();

 java.awt.Image			theImage;
  java.awt.MediaTracker		tracker;

  owner= theOwner;
  
  theImage = owner.getImage(owner.getCodeBase(), "images/goobie.gif");
  tracker = new java.awt.MediaTracker(theOwner);

  tracker.addImage(theImage, 0);
  try
{
		tracker.waitForID(0);
  } 
  catch (InterruptedException e) {}
  
  x= (int)(explodee.x - (width - explodee.width)/2.0);
  y= (int)(explodee.y - (height - explodee.height)/2.0);
  velocity_x= explodee.velocity_x * Gamelet.randBetween(0.2,1.4);
  velocity_y= explodee.velocity_y * Gamelet.randBetween(0.2,1.4);
  
  setImage (theImage);

} /*Goobie()*/


/**
 * Gravitate torwards player.
 */
public void calculateNewPosition() {
  super.calculateNewPosition();
  
  //
  // Is the player alive?
  //
  if (((Boinkaroids)owner).player==null) return;
  
  //
  // gravitate towards player
  //
  if (x> ((Boinkaroids)owner).player.x) velocity_x-= GRAVITATIONAL_PULL;
  else velocity_x+= GRAVITATIONAL_PULL;
  if (y> ((Boinkaroids)owner).player.y) velocity_y-= GRAVITATIONAL_PULL;
  else velocity_y+= GRAVITATIONAL_PULL;
    

} /*calculateNewPosition*/



/**
 * Explode goobie.
 */
public void explode()
{
  //
  // play explode sound
  //
  owner.play(owner.getCodeBase(), "sounds/smack.au");
  
  //
  // give credit for hitting me, increase score
  //
  owner.scoreManager.addToScore(1000);
  
  //
  // i'm dead, i should schedule to be removed
  //
  owner.actorManager.removeActor(this);
  
  //
  // tell the gamelet that there is one less bad guy
  //
  ((Boinkaroids)owner).badGuyCount--;
    
} /*explode*/




/**
 * Handle collision with an actor.
 */
protected void collideWithActor (Actor theActor)
{
  String theActorClassName= theActor.getClass().getName();
  
  if (theActorClassName.equals("Bullet") ||
      theActorClassName.equals("Ship") ) {
         explode();
  } /*endif*/
  
} /*collideWithActor*/

} /*Goobie*/
