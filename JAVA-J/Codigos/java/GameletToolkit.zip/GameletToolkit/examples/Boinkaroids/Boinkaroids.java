
/**
 *
 * Boinkaroids.java
 * @author	Mark G. Tacchi (mtacchi@next.com) 
 * @version	0.8
 * Mar 27/1996
 *
 * Boinkaroids is an Asteroids type game developed for the purpose of showing
 * off the Gamelet Toolkit.  It makes use of all of the features within the
 * Gamelet Toolkit.
 *
 */
 
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

import com.next.gt.*;

public class Boinkaroids extends Gamelet implements BonusHandler, EventHandler{

  //
  // Boinkaroids variables
  //
  public Ship		player;
  public int		numShips;
  public int		badGuyCount;
  public int		level;
  
  //
  // Should a player be created?
  //
  private boolean	createNewPlayer;
  
  //
  // Score label.
  //
  private Label		myLabel;
  
  //
  // This area that has to be clear for a ship to enter level.
  //
  private int		SAFETY_ZONE_WIDTH= 128;
  private int		SAFETY_ZONE_HEIGHT= 128;
  
  
/**
 * Initialize.
 */
public void init() {
  //
  // cache images
  //
  new ImageManager(this);  
  
  //
  // initialize the score manager
  //
  scoreManager= new ScoreManager();
  scoreManager.registerForBonusNotification(this, 20000);
  
  
  myLabel= new Label("Score: 00000000" + "   Ships: " + numShips
                      + "   Level: "+ level);
  add("South",myLabel);
  
  this.newGame();


 //
  // register for events
  //
  eventManager.
    registerForSingleEventNotification(this,Event.KEY_ACTION_RELEASE);
  
  //
  // paint background image
  //
  displayManager.setBackgroundTile (getImage(getCodeBase(), "images/background.gif"));

} /*init*/



/**
 * Set up the new game.
 */
public void newGame() {
  scoreManager.setScore (0);
  numShips= 3;
  badGuyCount= 0;
  level= 0;
  player= null;
  actorManager.removeAllActors();
  this.createActors();
} /*newGame*/



/**
 * Advance levels.
 */
public void newLevel() {
  level++;
  this.createActors();
} /*newLevel*/


/**
 * Create the actors for this scene.
 */
public void createActors() {
  for (int i= 0; i< 2*level; i++) {
     actorManager.addActor (new Asteroid(this, null, "gumball", Asteroid.LARGE_SIZE));
	 badGuyCount++; 
  } /*nexti*/ 
  for (int i= 0; i< 0.5*level; i++) {
    actorManager.addActor (new Bigoobie(this));
    badGuyCount++; 
  } /*next_i*/
  this.createPlayer();
} /*createActors*/



/**
 * Create the player object.
 */
public void createPlayer() {
  if (player!=null) {
    actorManager.removeActor(player);
  } /*endif*/
  player= new Ship(this);
  actorManager.addActor (player);
} /*createPlayer*/



/**
 * Override tick to test for specific game events.
 */
public void tick() {

super.tick();

 if (badGuyCount <= 0) {
   this.newLevel();
 } /*endif*/
 if (createNewPlayer) {
   Rectangle myRectangle= new Rectangle((int)this.size().width/2 - SAFETY_ZONE_WIDTH/2,
                                        (int)this.size().height/2 - SAFETY_ZONE_HEIGHT/2,
										SAFETY_ZONE_WIDTH,
										SAFETY_ZONE_HEIGHT);
   if (!actorManager.isActorIn(myRectangle)) {
     createNewPlayer= false;
	 this.createPlayer();
   } /*endif*/
 } /*endif*/
} /*tick*/



/**
 * Handle keyboard events to restart game.
 */
public boolean handleRequestedEvent (Event theEvent) {
  switch(theEvent.id) {
  case Event.KEY_ACTION_RELEASE:
    switch(theEvent.key) {
	  case Event.F1:
       this.newGame();
	    return true;
	} /*endSwitch*/
  } /*endSwitch*/
  return false;
} /*handleRequestedEvent8/



/**
 * Override paint to display score bar.
 */
public void paint(Graphics g) {
  super.paint(g);
  myLabel.setText("Score: " + scoreManager.score + "   Ships: " + numShips
                      + "   Level: "+ level );
} /*paint*/



/**
 * Give bonus ship for getting a certain score.
 */
public void didAchieveBonus() {
  numShips++;
} /*didAchieveBonus*/



/**
 * Player must have died, decrement ship count.
 */
public void decrementShipCount() {
  if (numShips-- > 0) {
    createNewPlayer= true;
	player= null;
  } /*endif*/
} /*decrementShipCount*/
} /*Boinkaroids*/
