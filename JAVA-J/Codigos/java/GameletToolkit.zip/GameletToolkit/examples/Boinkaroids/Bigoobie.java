/**

*
 * Bigoobie.java
 * @author	Mark G. Tacchi (mtacchi@next.com) 
 * @version	0.8
 * Mar 18/1996

*

* A Bigoobie transparent shell containing two orbiting goobies.  They take
 * a number of hits and then pop.
 *
 * Bigoobies harm ships and bullets harm Bigoobies.
 *
*/

import java.applet.Applet;
import java.lang.Math;

import com.next.gt.*;

public class Bigoobie extends Actor {
  //
  // This actor has to be hit this many times before dying.
  //
  public int	attackResistance= 3;
  
Bigoobie(Boinkaroids theOwner) {
  super();
  

 java.awt.Image			theImage;
  java.awt.MediaTracker		tracker;

  owner= theOwner;
  
  theImage = owner.getImage(owner.getCodeBase(), "images/bigoobie.gif");
  tracker = new java.awt.MediaTracker(theOwner);

  tracker.addImage(theImage, 0);
  try
{
		tracker.waitForID(0);
  } 
  catch (InterruptedException e) {}
  x= (Math.random()*512);
  y= (Math.random()*512);
  velocity_x= (double)((int)Gamelet.randBetween(0.5,1.5)*2 - 1) * Gamelet.randBetween(16.,48.);
  velocity_y= (double)((int)Gamelet.randBetween(0.5,1.5)*2 - 1) * Gamelet.randBetween(16.,48.);
  setImage (theImage, 4, 12);

  currentFrame= (int)Gamelet.randBetween(0, numFrames);

} /*Bigoobie()*/



/**
 * Explode goobie.
 */
public void explode()
{
  //
  //  free the 2 goobies
  //
  for (int i= 0; i<2; i++) {
    owner.actorManager.addActor(new Goobie(owner, this));
   ((Boinkaroids)owner).badGuyCount++;
  } /*next_i*/

  //
  // play explode sound
  //
  owner.play(owner.getCodeBase(), "sounds/pop.au");
  
  //
  // give credit for hitting me, increase score
  //
  owner.scoreManager.addToScore(500);
  
  //
  // i'm dead, i should schedule to be removed
  //
  owner.actorManager.removeActor(this);
  
  //
  // tell the gamelet that there is one less bad guy
  //
  ((Boinkaroids)owner).badGuyCount--;
      
} /*explode*/




/**
 * Handle collision with an actor.
 */
protected void collideWithActor (Actor theActor)
{
  String theActorClassName= theActor.getClass().getName();
  
  if (theActorClassName.equals("Bullet") ||
      theActorClassName.equals("Ship") ) {
	  if (--attackResistance<0) {
         explode();
	  }
	  else {
	      owner.play(owner.getCodeBase(), "sounds/futility.au");
      }
  } /*endif*/
  
} /*collideWithActor*/

} /*Bigoobie*/
