/**
 *
 * Boink.java
 * @author	Mark G. Tacchi (mtacchi@next.com) 
 * @version	1.0
 * Feb 23/1996
 *
 * Create a bunch of bouncy balls.  Cool as ice, and easy as pie!
 *
 */

import java.awt.Color;
import com.next.gt.*;

public class Boink extends Gamelet {
public void init() {
  super.init();
  //
  // cache images
  //
  new ImageManager(this);  

  //
  // Create balls
  //
  for (int i= 0; i< 5; i++) {
     actorManager.addActor (new Ball(this));
  } /*nexti*/ 

  //
  // paint background image
  //
  displayManager.setBackgroundTile (getImage(getCodeBase(), "images/background.gif"));
} /*init*/


} /*Boink*/
