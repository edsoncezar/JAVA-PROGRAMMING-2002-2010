/*
 Difus.java     Diciembre 1.999   Copyright()  N. Betancort
 Applet que muestra la difusi�n  browniania de part�culas
*/

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;

 //clase  principal  -- Main class

 public class Difus extends Applet implements Runnable{

   static final Color CFONDO = new Color(200,100,120); //color fondo

   private int x = 400;                       //width
   private int y = 400;                       //height

   boolean btrace = true;                     // huella de trayectoria
   int tiempo_pausa = 200;                    //tiempo m�ximo pausa thread
   Thread tgrafi = null;                      //Thread para dibujar gr�fica
   Panel marco;
   Digraf grafi;                              //Pizarra gr�fica
   ProceDifu calcular;                        //Proceso de calculo
   Pancontrol pantrol;                        //Panel de control
   Panbotones panbot;                         //Panel de botones
   Dif_info finfo;                            //Frame informativo

   private Panel ptitu = new Panel();          //Panel para titulo
   private Label ltitu= new Label("Particles Diffusion");  //Titulo

   public Dimension getPreferredSize() { return new Dimension(x,y);}


   public void  init(){
      setLayout(null);
      setSize(getPreferredSize());
      setBackground(CFONDO);

      //Captura de par�metros--getting parameters
      try{
        String sx = getParameter("an");           //dimensiones
        String sy = getParameter("al");
        if (sx != null & sy != null){
           x = (Integer.valueOf(sx)).intValue();
           y = (Integer.valueOf(sy)).intValue();
        }
      }
      catch(Exception e) {   }

      marco = new Tapiz(x,y, CFONDO);
      marco.setBounds(0,0, x, y);
      add(marco);
      ptitu.setBounds(20,10,x-40,y/10);
      ptitu.setBackground(CFONDO);
      ltitu.setForeground(new Color(10,10,240));
      ltitu.setFont(new Font("Serif",Font.BOLD, 16));
      ptitu.add("Center",ltitu);
      marco.add(ptitu);

      grafi = new Digraf(this);
      marco.add(grafi);
      grafi.setBounds(16,y/10+10,x-32,7*y/10); //dimensiones funci�n de x e y
      grafi.iniciar();

      calcular = new ProceDifu(50);
      calcular.setorigen(grafi.getBounds().width, grafi.getBounds().height);
      calcular.setrandom();

      pantrol = new Pancontrol(this, CFONDO, x-40,20);
      pantrol.setBounds(20, 8*y/10+20, x-40, 20);
      marco.add(pantrol);
      panbot = new Panbotones(this, CFONDO);
      panbot.setBounds( 20, 7*y/8+20, x-40, y/16);
      marco.add(panbot);

      finfo = new Dif_info();

   }

 //..................................................
     public void start(){
        grafi.iniciar();                   //posicion al origen
        calcular.setorigen(grafi.getBounds().width, grafi.getBounds().height);

         if (tgrafi==null){
             tgrafi = new Thread(this);
             tgrafi.start();
         }
         else { repaint(); }
     }
 //..........................................
     public void stop(){
         if (tgrafi!=null){
             tgrafi.stop();
             tgrafi = null;
         }
     }
 //..................................................
     public void continuar(){
         if (tgrafi==null){
             tgrafi = new Thread(this);
             tgrafi.start();
         }
     }
 //..........................................

     public void run(){

         while (tgrafi != null){
         calcular.getnewpos();

             try{
                  for(int r = 0; r < 5; r++){
                        grafi.dibusalto(r, btrace);
                        tgrafi.sleep(tiempo_pausa);
                  }
              }
              catch(InterruptedException e){  tgrafi.stop();  }
          }
      }
 //..........................................
    public void cambionumpart(int nsel){
          stop();
          this.calcular = new ProceDifu(nsel);
      calcular.setorigen(grafi.getBounds().width, grafi.getBounds().height);
          start();
    }
 //..........................................
     public static void main(String args[]) {      //iniciar como aplicaci�n
         Difus Nidifu = new Difus();
         Nidifu.init();
         Nidifu.start();
     }
  //.............................................

 }  //Fin de clase Difus

 //--------------------------------------------------------------------
 //--------------------------------------------------------------------

 class Digraf extends Canvas implements MouseListener{

    Difus padre;
    Image clonima;
    Graphics clongraf;
    Rectangle rgraf = new Rectangle(0,0,0,0);
    boolean bcurva = false;
    int intervalx = 10;         //anchura de barras
    int acumulador = 0;         //contador de retardo para grafico de barras
    int bars1[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int bars2[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String destip = " ";

    public Digraf(Difus padre){        //Constructor
        super();
        this.padre = padre;
        this.addMouseListener(this);
        setBackground(Color.black);             //color negro
    }

  //.....................................................

    public void paint(Graphics g){
          g.drawImage(clonima, 0,0, this);
    }
  
    public void update(Graphics g){
           paint(g);
    }
  
   //............................................................

    public void fixpaint(Graphics g){

        g.setColor(Color.red);        //ejes coordenados
        g.drawLine(rgraf.width/2 , 2, rgraf.width/2, rgraf.height-2);
        g.drawLine(4, rgraf.height/2 , rgraf.width, rgraf.height/2);
        g.setColor(Color.yellow);       //leyenda
        g.drawString( "Mean free path= 16 pixels", 10,10);

        g.clearRect(2, rgraf.height -30, 60, 30);
        g.setColor(Color.yellow);       //Numero de iteraciones
        g.drawString("N = "+
           String.valueOf(padre.calcular.contador), 10,rgraf.height -10);
       
        g.clearRect(rgraf.width - 80, rgraf.height -30, 80, 30);
        g.setColor(Color.yellow);       //desviaci�n t�pica
        destip = destip.valueOf(padre.calcular.desv_tip);
        try{
             destip = destip.substring(0,5);
             g.drawString("st. dev.= "+ destip,
                           rgraf.width - 80,rgraf.height -10);
        }
        catch(StringIndexOutOfBoundsException e){  }

        if((bcurva == true) & (padre.btrace == false)){
             cal_bar();
             curvapaint(g, bars2);
        }
        
    }

   //............................................................

    private void cal_bar(){

           acumulador ++;
           //calculo
           for (int j = 0; j < 12; j++){
               int altura[] = padre.calcular.recuento(j*intervalx,
                         (j+1)*intervalx);
               bars1[2*j] =   bars1[2*j] + altura[0]/4;
               bars1[2*j+1] =  bars1[2*j+1] + altura[1]/4;
           }
           if (acumulador == 3) {
                acumulador = 0;
                for (int h = 0; h < 24; h++) {
                    bars2[h] = bars1[h];       // repone bars2  para pintar
                    bars1[h] = 0;
                }
           }
    }
   //............................................................

    public void curvapaint(Graphics g, int bar[]){

        g.setColor(Color.blue);

        for(int j = 0; j < 12; j++){
            g.drawRect( rgraf.width/2 + j*intervalx ,
            rgraf.height - bar[2*j], intervalx, bar[2*j]);

            g.drawRect( rgraf.width/2 - (j+1)*intervalx ,
            rgraf.height - bar[2*j+1], intervalx, bar[2*j+1]);
        }
    }

   //............................................................

   public void iniciar(){

        rgraf = this.getBounds();  //obtener las propias dimensiones
        intervalx = rgraf.width/24;
        clonima = createImage(rgraf.width,  rgraf.height);
        clongraf = clonima.getGraphics();
        repaint();           //borrar pantalla
    }

   //..............................................................

    public void dibusalto(int r, boolean huella){

        if( huella == false )  {
                clongraf.clearRect(0, 0, rgraf.width, rgraf.height);
        }
        fixpaint(clongraf);
        clongraf.setColor(Color.white);     

        for(int i = 0; i<padre.calcular.num_partic; i++) {
          if(padre.calcular.fuera_lim[i] == false){
            clongraf.drawLine(
            padre.calcular.icx[r][i],
            padre.calcular.icy[r][i],
            padre.calcular.icx[r][i],
            padre.calcular.icy[r][i]);
          }
        }
        repaint();

    }

   //................................................................

    public void mouseClicked(MouseEvent ev) {
            if (bcurva == false){bcurva = true;}
            else{bcurva = false;}
    }
    public void mousePressed(MouseEvent ev) {  }
    public void mouseReleased(MouseEvent ev) { }
    public void mouseEntered(MouseEvent ev) { }
    public void mouseExited(MouseEvent ev) {  }

  }

//------------------------------------------------------------------------
  //Fin clase  Digraf

//-------------------------------------------------------------------------

  class Pancontrol extends Panel implements ItemListener, AdjustmentListener{

      Difus padre;
      Label L1;
      Scrollbar sbar;
      Checkbox cbonof;
      Choice lista;
      int np[] = {50,100,200,400};
      String listem[]={"50 particles","100 particles",
                        "200 particles","400 particles"};
      int codesb1, codesb2, codesb3;        //hashCode for controls

      public Pancontrol( Difus padre, Color FONDO, int ancho, int alto){

          super();
          this.padre = padre;
          L1 = new Label("Speed");
          sbar = new Scrollbar(Scrollbar.HORIZONTAL,1,1,1,5);
          cbonof = new Checkbox("Trace ", true);
          cbonof.addItemListener(this);
          lista = new Choice();
          codesb1 = sbar.hashCode();
          codesb2 = cbonof.hashCode();
          codesb3 = lista.hashCode();

          for(int h=0; h<4; h++){lista.addItem(listem[h]);}
          setLayout(null);
          setBackground(FONDO);

          sbar.addAdjustmentListener(this);
          lista.addItemListener(this);
          cbonof.setBounds(ancho/16, 0, 8*ancho/32, alto);
          lista.setBounds(13*ancho/32,0, 7*ancho/32, alto);
          L1.setBounds(21*ancho/32, 0, 2*ancho/16, alto);
          sbar.setBounds(25*ancho/32,0, 7*ancho/32, alto);
          add(cbonof);

          add(lista);
          add(L1);
          add(sbar);

      }
 //.......................................................

      public void itemStateChanged(ItemEvent ev) {

          if(ev.getSource().hashCode() == codesb2) {
                 padre.btrace = ( cbonof.getState());
          }
          else if(ev.getSource().hashCode() == codesb3) {
              padre.cambionumpart(np[lista.getSelectedIndex()]);
          }
      }

 //.......................................................

      public void adjustmentValueChanged(AdjustmentEvent ev) {
         if(ev.getSource().hashCode() == codesb1) {
               padre.tiempo_pausa = 200/ev.getValue();
         }
      }
 //..........................................................

   }     //Fin Clase Pancontrol

//-------------------------------------------------------------------------

  class Panbotones extends Panel implements ActionListener{

      Difus padre;
      int id = 0;
      Button pause, conti, start, info;
      final static String sb[] = {"Start", "Pause", "Continue",
                                  "Show Info", "Hide Info" };

      public Panbotones( Difus padre, Color FONDO){

          super();
          this.padre = padre;
          start = new Button(sb[0]);
          pause = new Button(sb[1]);
          conti = new Button(sb[2]);
          info = new Button(sb[3]);

          setLayout(new GridLayout(1,4,8,4));
          setBackground(FONDO);

          start.addActionListener(this);
          pause.addActionListener(this);
          conti.addActionListener(this);
          info.addActionListener(this);
          add(start);                      
          add(pause);
          add(conti);
          add(info);
      }

 //.......................................................

      public void actionPerformed(ActionEvent ev) {

          String accion = ev.getActionCommand();

          if(accion.equals(sb[0])){ padre.start();}
          else if( accion.equals(sb[1]) ){ padre.stop(); }
          else if( accion.equals(sb[2]) ){ padre.continuar();}
          else if( accion.equals(sb[3]) ){
                padre.finfo.show();
                info.setLabel(sb[4]); 
          }
          else if( accion.equals(sb[4]) ){
                padre.finfo.setVisible(false);
                info.setLabel(sb[3]); 
          }
      }

   }     //Fin Clase Panbotones

  //-------------------------------------------------------------------------


 //------------------------------------------------------------------------
                          //Fin c�digo applet
 //.........................*************************.............................

