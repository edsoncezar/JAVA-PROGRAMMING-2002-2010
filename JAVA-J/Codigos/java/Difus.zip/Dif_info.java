
  /*
  Frame con informaci�n para el Applet Difusi�n.  N.Betancort  22-12-99
 */

 import java.awt.*;


 class Dif_info extends Frame{

  String texto =  "           "
                 +" N = number of collisions; \n"
                 +" s = standard deviation of the distance from origin\n"
                +"Statistically, the average distance traveled by a \n"
                +"particle after N collisions, is the square root of N\n"
                +"multiplyed by the mean free path.\n"
                +"This simulation model is applicable to the diffusion\n"
                +"of Brownian particles and also to a group of molecules\n"
                +"which are different in some way from the molecules of\n"
                +"the fluid.\n"                                               
                +"If in the mode -Trace OFF- click with the mouse into\n"
                +"the drawing-area, you will see a bars-graphic showing\n"
                +"the evolution of the particles density along de x axis.\n"
                +"The next version will include  Diffusion's coefficient.\n"
                +"   "
                +"Author N.Betancort   Dec-1999";

  
     public Dif_info (){

         super("Information about Diffusion Applet");
         setSize(360,300);
         setResizable(false);
         TextArea ta = new TextArea();
         add(ta);
         ta.setEditable(false);
         ta.setText(texto);
     }

  }    //Fin de clase

