
   import java.awt.*;

   class Tapiz extends Panel {      //panel de fondo para el applet

      int an = 260; int al =200;
      static Color cuno = new Color(210,210,210);   //borde uno
      static Color cdos = new Color(100,100,100);   //borde dos
      static Color ctre = new Color(220,100,10);    //fondo tapiz

      public Tapiz(int ancho, int alto, Color fondo) {   //Constructor

          super();
          this.an = ancho ;
          this.al = alto ;
          this.ctre = fondo;
          setLayout(null);
          setBackground(cuno);   //cuadro grande
          repaint();
      }

      public void paint(Graphics g){
       
          g.setColor(ctre);
          g.fillRect(3,3, an-5, al-5);
          g.setColor(cdos);
          for(int i=0; i<3; i++){     //rebordes de 5 pixels de ancho
             g.drawLine(an-i, i, an-i, al-i);       //vert. dch.
             g.drawLine(i, al-i, an-i, al-i);       //hor. baja
          }
      }  

   }    //fin de clase

