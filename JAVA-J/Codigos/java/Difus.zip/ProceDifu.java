
/*
 ProceDifu.java     Diciembre 1.999   Copyright()  N. Betancort
 Clase para proceso y calculo necesarios para el Applet Difusion
 Contiene los m�todos siguientes:

 ProceDifu(int N)
 setrandom()
 setorigen( int ancho, int alto)
 getnewpos()
 cal_desvtip()      --Calcula la desviaci�n t�pica
 recuento(int mini, int maxi)

*/

 import java.awt.*;
 import java.util.*;

 class ProceDifu {

    //cx[0][n] = posini, cx[1][n] = posfin, n = num. part�cula

    double cx[][] = new double [2][400];
    double cy[][] = new double [2][400];
    int icx[][] = new int [6][400];       //coordenadas enteras para gr�ficos
    int icy[][] = new int [6][400];
    boolean fuera_lim[] = new boolean[400];    //marca fuera de l�mites
    double dist[] = new double[400];           //distancia al origen
    double desv_tip = 0;                       //desviaci�n t�pica

    static final int MAX_NUM_PART = 400;
    int num_partic = 50;              //numero inicial de part�culas
    int contador = 0;                 //contador de tiempo
    int anchoalto[] ={0,0};           //dimensiones del panel gr�fico
    int origen[] = {0,0};            //coordenadas del origen
    double dOx = 0 ;
    double dOy = 0;

    Random rangen = new Random();    //generador n�meros aleatorios
    Rectangle rgraf = new Rectangle(0,0,0,0);

    double dang ;    // �ngulo aleatorio
    double dimp ;    // recorrido gaussiano    media=16  s=4
    double dincx;    // incremento de x  
    double dincy;    // incremento de y

    boolean bcurva = false;

    public ProceDifu(int N){        //Constructor
        super();
        if (N <= MAX_NUM_PART) { this.num_partic = N;}
    }

   //..............................................................

    public void setrandom(){
        Date fecha = new Date();
        rangen.setSeed(fecha.getTime());
    }
   //..............................................................

    public void setorigen(int ancho, int alto ){

         this.anchoalto[0] = ancho;
         this.anchoalto[1] = alto;
         this.origen[0] = ancho/2;
         this.origen[1] = alto/2;
         dOx = new Integer(origen[0]).longValue() ;
         dOy = new Integer(origen[1]).longValue();

        for(int i = 0; i < num_partic; i++){    //coordenadas al origen
           fuera_lim[i] = false;
           for(int k = 0; k < 2; k++){
             cx[k][i] = origen[0];
             cy[k][i] = origen[1];
           }
        }
          
        for(int k=0; k < num_partic; k++){ dist[k] = 0; }  //Iniciar distancias a 0
        desv_tip = 0;
        contador = 0;

    }

   //.....................................................................

    public void getnewpos(){

      contador = contador+1;             //incrementa contador

      for(int i = 0; i< num_partic; i++){

          dang = rangen.nextDouble()* 6.283185;    //�ngulo aleatorio
          dimp = rangen.nextGaussian()*4 + 16 ;    //recorrido gaussiano
          dincx = dimp*Math.cos(dang);             // media=16  s=4
          dincy = dimp*Math.sin(dang);

          // incrementar coordenadas 

          cx[1][i] =  cx[0][i] + dincx ;
          cy[1][i] =  cy[0][i] + dincy ;

          //almacenar  coordenas para gr�ficos

          icx[0][i] =  new Double(cx[0][i]).intValue();
          icy[0][i] =  new Double(cy[0][i]).intValue();

          for(int k = 1; k< 6; k++){
              icx[k][i] =  icx[0][i] +new Double(k*dincx/5).intValue(); 
              icy[k][i] =  icy[0][i] +new Double(k*dincy/5).intValue(); 
          }

          //Correccion desbordamientos horizontal y vertical sup. e inf.

          if (cx[1][i] < 0 | cx[1][i] > anchoalto[0] ){
                 fuera_lim[i] = true;
                 //partout = partout +1;
          }
          else{  fuera_lim[i] = false;  }

          if (cy[1][i] < 0 | cy[1][i] > anchoalto[1] ){
                 fuera_lim[i] = true;
                 //partout = partout +1;
          }
          else{  fuera_lim[i] = false;  }

          //nueva posici�n de inicio
          cx[0][i] =  cx[1][i]  ;
          cy[0][i] =  cy[1][i]  ;

          cal_desvtip();                //calculo desviaci�n t�pica

      }
    }

   //..............................................................

    private void cal_desvtip(){

         double suma =  0;
         double dist2 = 0;
         for (int i = 0; i< num_partic; i++){
    dist2 = ((cx[0][i]-dOx)*(cx[0][i]-dOx)+(cy[0][i]-dOy)*(cy[0][i]-dOy));
           suma = suma + dist2;
           dist[i] = Math.sqrt(dist2);
         }
         desv_tip = Math.sqrt(suma/num_partic);
    }

   //..............................................................

    public int[] recuento(int mini, int maxi){

           int cuenta[] ={0,0};

           for(int i = 0; i< num_partic; i++){
                //dispersi�n seg�n x
                int idist = new Double(cx[0][i] - dOx).intValue();
                if(idist >= mini & idist < maxi) { cuenta[0] ++;}
                if(idist <= -mini & idist > -maxi) { cuenta[1] ++;}
           }
           cuenta[0] = cuenta[0] *800/num_partic;   //dimensionar altura
           cuenta[1] = cuenta[1] *800/num_partic;

           return cuenta;
    }
  //....................................................................

  } //fin de clase
  //-------------------------------------------------------------------
