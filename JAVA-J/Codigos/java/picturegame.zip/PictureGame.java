import java.applet.Applet;
import java.awt.*;

public class PictureGame extends Applet 
{
	private boolean laidOut = false, WordUpdate = true;
	private int TotalLetters, TotalPictures, CurrentPicture, PreviousPicture, counter;
	private int offsettop, offsetleft;
	private Button cmdDone, cmdReset, cmdHelp, cmdLetter[];
	private Label lblWordTyped;
	private String ThingsName[], msgWon = "You Won!", msgLost = "Try again.";
	private Image Things[];

	public void init() 
	{
		PictureGame window = new PictureGame();
		Insets insets = window.insets();
		TotalPictures = 35;
		CurrentPicture = Random();

		Things = new Image[TotalPictures];
		for(counter = 1; counter <= TotalPictures; counter++)
		{
			showStatus("Loading images/T"+counter+".gif");
			Things[counter - 1] = getImage(getCodeBase(), "images/T"+counter+".gif");
		}

		ThingsName = new String[TotalPictures];
		ThingsName[0] = "PICTURE";
		ThingsName[1] ="BOOK";
		ThingsName[2] = "BOX";
		ThingsName[3] = "LOCK";
		ThingsName[4] = "SUN";
		ThingsName[5] = "CAMERA";
		ThingsName[6] = "DOG";
		ThingsName[7] = "DOOR";
		ThingsName[8] = "EARTH";
		ThingsName[9] = "EIGHT";
		ThingsName[10] = "EYE";
		ThingsName[11] ="FIRE";
		ThingsName[12] = "FIVE";
		ThingsName[13] = "FOUR";
		ThingsName[14] = "HAND";
		ThingsName[15] = "HOUSE";
		ThingsName[16] = "KEY";
		ThingsName[17] = "TV";
		ThingsName[18] = "TREE";
		ThingsName[19] = "LIGHTBULB";
		ThingsName[20] = "MAILBOX";
		ThingsName[21] ="NINE";
		ThingsName[22] = "ONE";
		ThingsName[23] = "PAINT";
		ThingsName[24] = "PHONE";
		ThingsName[25] = "SEVEN";
		ThingsName[26] = "SIX";
		ThingsName[27] = "SPIDER";
		ThingsName[28] = "STAR";
		ThingsName[29] = "COMPUTER";
		ThingsName[30] = "THREE";
		ThingsName[31] ="CASTLE";
		ThingsName[32] = "TWO";
		ThingsName[33] = "MONEY";
		ThingsName[34] = "NEWSPAPER";

		//How do we know insets is valid here?
		window.resize(400 + insets.left + insets.right, 300 + insets.top + insets.bottom);
		offsettop = insets.top;
		offsetleft = insets.left;
		window.show();

	}

	public PictureGame() 
	{
		super();
		setLayout(null);
		TotalLetters = 26;
		cmdLetter = new Button[TotalLetters];

		cmdDone = new Button("Done");
		cmdDone.setFont(new Font("Helvetica", Font.BOLD, 30));
		add(cmdDone);

		cmdReset = new Button("Reset");
		cmdReset.setFont(new Font("Helvetica", Font.BOLD, 30));
		add(cmdReset);

		cmdHelp = new Button("Help");
		cmdHelp.setFont(new Font("Helvetica", Font.BOLD, 30));
		cmdHelp.disable();
		add(cmdHelp);
	
		lblWordTyped = new Label();
		lblWordTyped.setFont(new Font("Helvetica", Font.PLAIN, 20));
		add(lblWordTyped);

		setFont(new Font("Helvetica", Font.PLAIN, 20));
		cmdLetter[0] = new Button("A");
		cmdLetter[1] = new Button("B");
		cmdLetter[2] = new Button("C");
		cmdLetter[3] = new Button("D");
		cmdLetter[4] = new Button("E");
		cmdLetter[5] = new Button("F");
		cmdLetter[6] = new Button("G");
		cmdLetter[7] = new Button("H");
		cmdLetter[8] = new Button("I");
		cmdLetter[9] = new Button("J");
		cmdLetter[10] = new Button("K");
		cmdLetter[11] = new Button("L");
		cmdLetter[12] = new Button("M");
		cmdLetter[13] = new Button("N");
		cmdLetter[14] = new Button("O");
		cmdLetter[15] = new Button("P");
		cmdLetter[16] = new Button("Q");
		cmdLetter[17] = new Button("R");
		cmdLetter[18] = new Button("S");
		cmdLetter[19] = new Button("T");
		cmdLetter[20] = new Button("U");
		cmdLetter[21] = new Button("V");
		cmdLetter[22] = new Button("W");
		cmdLetter[23] = new Button("X");
		cmdLetter[24] = new Button("Y");
		cmdLetter[25] = new Button("Z");

		for(counter = 0; counter < TotalLetters; ++counter)
			add(cmdLetter[counter]);
	}

	public void paint(Graphics g) 
	{
		g.setColor(Color.magenta);
		g.fill3DRect(offsetleft,offsettop, 600, 350, true);
		g.drawImage(Things[CurrentPicture], 275 + offsetleft, 210 + offsettop, this);
		if (!laidOut) 
		{
			Insets insets = insets();
			insets = insets(); 
			cmdReset.reshape(130 + offsetleft, 300 + offsettop, 100, 30);
			cmdDone.reshape(375 + offsetleft, 300 + offsettop, 100, 30);
			cmdHelp.reshape(250 + offsetleft, 300 + offsettop, 100, 30);
			for(counter = 0; counter < 8; ++counter)
						       //      Left, Top, Right, Bottom
				cmdLetter[counter].reshape(  160 + (counter * 35), 20, 35, 30);
			for(;counter < 18; ++counter)
				cmdLetter[counter].reshape(  130 + ((counter - 8) * 35), 80, 35, 30);
			for(;counter < TotalLetters; ++counter)
				cmdLetter[counter].reshape(  160 + ((counter - 18) * 35), 140, 35, 30);

			laidOut = true;
		}

		if(!WordUpdate)
		{
			g.setColor(Color.black);
			g.drawString(lblWordTyped.getText(), 250 + offsetleft, 200+ offsettop);
			g.setColor(Color.magenta);
		}
	}

	public boolean action(Event evt, Object obj)
	{
		if(lblWordTyped.getText() == msgWon || lblWordTyped.getText() == msgLost)
			Reset();
		if("A".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "A");
		if("B".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "B");
		if("C".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "C");
		if("D".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "D");
		if("E".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "E");
		if("F".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "F");
		if("G".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "G");
		if("H".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "H");
		if("I".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "I");
		if("J".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "J");
		if("K".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "K");
		if("L".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "L");
		if("M".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "M");
		if("N".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "N");
		if("O".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "O");
		if("P".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "P");
		if("Q".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "Q");
		if("R".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "R");
		if("S".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "S");
		if("T".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "T");
		if("U".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "U");
		if("V".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "V");
		if("W".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "W");
		if("X".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "X");
		if("Y".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "Y");
		if("Z".equals(obj))
			lblWordTyped.setText(lblWordTyped.getText() + "Z");
		if("Reset".equals(obj))
			Reset();
		if("Help".equals(obj))
			lblWordTyped.setText(ThingsName[CurrentPicture]);
		if("Done".equals(obj))
		{
			if(CheckWord() == false)
				TooBad();
			else
			{
				Celebrate();
				showStatus("Finding Next Picture.");
				CurrentPicture = Random();
				showStatus("Picture Found, Good Luck!");
			}
		}
		WordUpdate = false; repaint();return true;
	}
	
	boolean CheckWord()
	{
		 if((int)ThingsName[CurrentPicture].compareTo(lblWordTyped.getText()) != 0)
			return false;
		else
			return true;
	}

	void Celebrate()
	{
		lblWordTyped.setText(msgWon);
	}

	void TooBad()
	{
		cmdHelp.enable();
		lblWordTyped.setText(msgLost);
	}	

	void Reset()
	{
		lblWordTyped.setText("");
	}
	
	int Random()
	{
		int ranint = -1;

		while(ranint < 0 || ranint >= TotalPictures || ranint == PreviousPicture)
		{
			ranint = (int)(java.lang.Math.random()*TotalPictures);
			showStatus("Looking for random number");
		}
		PreviousPicture = ranint;
		cmdHelp.disable();
		return ranint;
	}	        
}