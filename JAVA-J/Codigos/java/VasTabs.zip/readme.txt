/**************************************************************\
* Copyright (C) 1998 Vasile CALMATUI (vasile@club-internet.fr) *
*                                                              *
* Permission is granted to use this software for evaluation    *
* purposes for a period of 20 days. Following this period, if  *
* you wish to continue to use this software, you must register *
* See http://www.chez.com/vasile/vasregus.html or VasRegUs.txt *
* file for more details.                                       *
****************************************************************
* As registered user, you :                                    *
* - gain access to the SOURCE CODE of the registered programs  *
* - access support and assistance, via e-mail worldwide        *
* - encourage the author to further improve the programs       *
* - may use the programs in commercial and other environments  *
****************************************************************
* Feel free to contact me for information, bugs, comments, job *
* offers. The author is not liable for damages resulting from  *
* the use of this software or its derivates.                   *
****************************************************************
* Vasile CALMATUI                                              *
* appt. A338, Resid. Jean Zay                                  *
* 92160 ANTONY (FRANCE)                                        *
* e-mail: vasile@club-internet.fr                              *
* web : http://www.chez.com/vasile/                            *
\**************************************************************/
