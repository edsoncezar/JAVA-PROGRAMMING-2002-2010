/**************************************************************\
* Copyright (C) 1998 Vasile CALMATUI (vasile@club-internet.fr) *
*                                                              *
* Permission is granted to use this software for evaluation    *
* purposes for a period of 30 days. Following this period, if  *
* you wish to continue to use this software, you must register *
* See http://www.chez.com/vasile/vasregus.html or VasRegUs.txt *
* file for more details.                                       *
****************************************************************
* As registered user, you :                                    *
* - gain access to the SOURCE CODE of the registered programs  *
* - access support and assistance, via e-mail worldwide        *
* - encourage the author to further improve the programs       *
* - may use the programs in commercial and other environments  *
****************************************************************
* Feel free to contact me for information, bugs, comments, job *
* offers. The author is not liable for damages resulting from  *
* the use of this software or its derivates.                   *
****************************************************************
* Vasile CALMATUI                                              *
* appt. A338, Resid. Jean Zay                                  *
* 92160 ANTONY (FRANCE)                                        *
* e-mail: vasile@club-internet.fr                              *
* web : http://www.chez.com/vasile/                            *
\**************************************************************/

//Sample Applet of VasTabs

import VasTabs;
import java.applet.Applet;
import java.awt.*;

public class VasTabsApplet extends Applet {
  VasTabs tabs;
  Panel mPan0,mPan1,mPan2,mPan3,mPan4,mPan5;
  Label lLogin,lPasswd,llState,lState,llReplay,lReplay;
  TextField eLogin,ePasswd;
  Button bSend;

  //constructor
  public VasTabsApplet() {
    this.setLayout(null);
    this.resize(400,400);    
    setBackground(Color.lightGray);
    
    //where is the left upper corner of tabs=(25,25)
    //the dimension of tabs=(350,350)
    tabs = new VasTabs(25,25,350,350);

    //Creating the Panel of the first tab
    mPan0=new Panel();
    mPan0.setLayout(null);    

    lLogin = new Label("Login :");
    mPan0.add(lLogin);
    lLogin.reshape(10,30,100,21);
    eLogin = new TextField("vasile");
    mPan0.add(eLogin);
    eLogin.reshape(110,30,130,21);
    
    lPasswd = new Label("Password :");
    mPan0.add(lPasswd);
    lPasswd.reshape(10,60,100,21);
    ePasswd = new TextField("password_here");
    mPan0.add(ePasswd);
    ePasswd.reshape(110,60,130,21);
    ePasswd.setEchoCharacter('*');

    //Creating the Panel of the second tab
    mPan1=new Panel();
    mPan1.setLayout(null);    
    
    llState = new Label("State :");
    mPan1.add(llState);
    llState.reshape(10,160,100,21);
    lState = new Label("Just a test");
    mPan1.add(lState);
    lState.reshape(110,160,390,21);
    
    llReplay = new Label("Replay :");
    mPan1.add(llReplay);
    llReplay.reshape(10,200,100,21);
    lReplay = new Label("Register Now !");
    mPan1.add(lReplay);
    lReplay.reshape(110,200,390,21);
    
    bSend = new Button("Action !");
    mPan1.add(bSend);
    bSend.reshape(110,90,80,30);

    mPan2=new Panel();
    mPan3=new Panel();
    mPan4=new Panel();
    mPan5=new Panel();
    
    //adding the tabs
    tabs.addTab("Login", mPan0);
    tabs.addTab("Action!", mPan1);
    tabs.addTab("T2", mPan2);
    tabs.addTab("Third", mPan3);
    tabs.addTab("4", mPan4);
    tabs.addTab("the 5th avenue", mPan5);
    add(tabs);
  }//end constructor
}//end class VasTabsApplet