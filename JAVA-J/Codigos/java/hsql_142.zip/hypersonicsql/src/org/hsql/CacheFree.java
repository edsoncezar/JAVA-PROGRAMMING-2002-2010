/*
 * CacheFree.java
 */

package org.hsql;

class CacheFree {
  int iPos;
  int iLength;
  CacheFree fNext;
}
