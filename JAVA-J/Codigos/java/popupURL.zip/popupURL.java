<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.5b2 [en] (Win95; I) [Netscape]">
   <TITLE>PopupURL Applet</TITLE>
</HEAD>
<BODY>

<PRE>import java.applet.*;
import java.awt.*;
import java.net.*;
import java.awt.event.*;


public class popupURL extends Applet {&nbsp;
&nbsp;&nbsp; PopupMenu&nbsp;&nbsp;&nbsp; popup;
&nbsp;&nbsp; MenuItem&nbsp;&nbsp;&nbsp;&nbsp; menu;
&nbsp;&nbsp; Image&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; image;
&nbsp;&nbsp; String&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; webpage,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; pageURL;
&nbsp;&nbsp; String[] holdPage;
&nbsp;&nbsp; String[] holdURL;
&nbsp;&nbsp; int&nbsp;&nbsp;&nbsp; pagenumber = 20,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; count = 0,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; index = 0;
&nbsp;&nbsp; int i,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; in,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; x;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

&nbsp; public void init()
&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp; image = getImage(getDocumentBase(),"image.gif");
&nbsp;&nbsp;&nbsp;&nbsp; enableEvents(AWTEvent.MOUSE_EVENT_MASK|AWTEvent.MOUSE_MOTION_EVENT_MASK|
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AWTEvent.ACTION_EVENT_MASK);

&nbsp;&nbsp;&nbsp;&nbsp; holdPage = new String[pagenumber];&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp; holdURL = new&nbsp; String[pagenumber];
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; popup = new PopupMenu();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; for(in = 0; in &lt; pagenumber; in++)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; webpage=getParameter("page" + in);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; pageURL=getParameter("url" + in);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if((webpage == null) || (pageURL == null)) break;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; count++;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; index++;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; holdPage[in] = webpage;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; holdURL[in] = pageURL;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; for(i = 0; i &lt; count; i++)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; menu = new MenuItem(holdPage[i]);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; menu.setActionCommand(holdPage[i]);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; popup.add(menu);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if(i != (count - 1)) popup.addSeparator();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; else break;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }&nbsp;&nbsp;&nbsp;&nbsp; // End for-loop&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp; add(popup);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; popup.addActionListener(new ActionListener() {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; public void actionPerformed(ActionEvent e)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; String command = e.getActionCommand();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; System.out.println(command);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; String address;

&nbsp;&nbsp;&nbsp; for(x = 0; x &lt; index; x++)&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if (command.equals(holdPage[x]))
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; address = holdURL[x];
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; popupURL.this.newPage(address);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; break;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }/* End if statement*/&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp; }/* End for-loop */
&nbsp; }});&nbsp;&nbsp;
&nbsp;&nbsp;
&nbsp;&nbsp; this.addMouseListener(new MouseAdapter()&nbsp;
&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; public void mouseClicked(MouseEvent e)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if (e.getID() == MouseEvent.MOUSE_CLICKED)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; popup.show(e.getComponent(),e.getX(),e.getY());&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }});&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp; }&nbsp;&nbsp;

&nbsp; public void newPage(String s)&nbsp;&nbsp; {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; try</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; URL u = new URL(s);</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; getAppletContext().showDocument(u);</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; catch(MalformedURLException ex)</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; System.err.println(ex);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</PRE>

<PRE>&nbsp;&nbsp;&nbsp;&nbsp; }&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

&nbsp;&nbsp; public void paint(Graphics g)
&nbsp;&nbsp; {&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp; g.drawImage(image,10,10,this);&nbsp;&nbsp; }
&nbsp;}

</PRE>

</BODY>
</HTML>
