/* timeThread.java
 * Copyright (C) 1996 by William Giel
 *
 * E-mail: rvdi@usa.nai.net
 * WWW: http://www.nai.net/~rvdi/home.htm
 *
 ***************************************************************************
 * Abstract
 * --------
 * This unit provides a Thread class for running the time displays in
 * the program window.
 *
 ***************************************************************************
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation without fee for NON-COMMERCIAL purposes is hereby granted.
 * 
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE
 * FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 ***************************************************************************/
 

import java.awt.*;
import java.lang.*;
import java.util.*;

// Bring in Julian.class
import Julian;

///////////////////////////////////////////
// This class is used to 'run' the clocks
// by updating the display areas. This is
// typically performed in the run() method
// of an applet, but this is an applicaton,
// so we'll do it with a thread.
///////////////////////////////////////////
public class timeThread extends Thread
{
	TextField text;
	Date date;
	long timezoneOffset;
	long correction;
	boolean local;
	
	public String getTimezoneString()
	{
		long tz;
		String retString;

		tz=timezoneOffset;
		boolean isPositive = (tz<0)? false: true;

		tz=Math.abs(tz);
		String hours=Long.toString(tz/60L);
		String minutes= Long.toString(tz-Long.valueOf(hours).longValue()*60L);

		if(1 == hours.length())hours=("0" + hours);
		if(1 == minutes.length())minutes=("0"+minutes);

		if(isPositive==true)retString="+";
		else retString="-";

		retString=retString + hours + ":" + minutes;

		return retString;
	}

	/////////////////////////////////////////////////////////
	// Initiallizer to display uncorrected system time. The
	// localTime flag determines whether or not the timezone
	// offset should be applied when displaying. To display
	// GMT it should be false.
	/////////////////////////////////////////////////////////
	public timeThread(TextField textfield, boolean localTime)
	{
		super();
		text=textfield;
		date=new Date();
		timezoneOffset=(long)date.getTimezoneOffset();
		correction=0L;
		local=localTime;
	}
	
	/////////////////////////////////////////////////////////
	// Initiallizer to display CORRECTED system time. The
	// localTime flag determines whether or not the timezone
	// offset should be applied when displaying. To display
	// GMT it should be false. The "corr" parameter is in
	// seconds.
	/////////////////////////////////////////////////////////
	public timeThread(TextField textfield, long corr, boolean localTime)
	{
		super();
		text=textfield;
		date=new Date();
		timezoneOffset=(long)date.getTimezoneOffset();
		correction= corr * 1000L;
		local=localTime;
	}
		
		
	public void run()
	{
        this.setPriority(Thread.MIN_PRIORITY);
        
        for(;;){
            date=new Date();
            if(!local)
                /////////////////////////////////////////
                // For GMT, apply TZ offset + correction.
                /////////////////////////////////////////
                date.setTime(date.getTime() + timezoneOffset * 60L * 1000L + correction);
			else
                /////////////////////////////////////////
                // Otherwise, only apply correction.
                /////////////////////////////////////////
                date.setTime(date.getTime() + correction);
                
			text.setText(Julian.date2ietf(date));
            try{
                Thread.sleep(1000);
            } catch (InterruptedException e) {}			
        }
	}
}

