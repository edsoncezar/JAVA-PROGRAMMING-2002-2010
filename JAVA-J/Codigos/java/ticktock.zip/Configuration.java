/* Configuration.java
 * Copyright (C) 1996 by William Giel
 *
 * E-mail: rvdi@usa.nai.net
 * WWW: http://www.nai.net/~rvdi/home.htm
 *
 ***************************************************************************
 * Abstract
 * --------
 * This unit handles reading and writing the user's defaults.
 *
 * At this time, the only default information  saved consists of the
 * platform-specific DATE and TIME setting command statements.
 *
 * Future plans include adding last main window origin coordinates
 * but there is a bug in Java 1.0 that prevents doing this. (Topmost
 * parent location() always returns 0,0)
 **************************************************************************
 * Permission to use, copy, modify, and distribute this software and its
 * documentation without fee for NON-COMMERCIAL purposes is hereby granted.
 * 
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE
 * FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 **************************************************************************/

import java.awt.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import java.util.Properties;

public class Configuration
{

	String command1=null;
	String command2=null;
	
	String filename=null;

	public Configuration(String fname)
	{
		filename=fname;
	}

    ///////////////////////////////////////
	// Retrieve configuration defaults
	///////////////////////////////////////
	public boolean getConfig()
	{
		File f=new File(filename);
		if(!f.exists())return false;
		try{
			RandomAccessFile file= new RandomAccessFile(f,"r");

			///////////////////////////////////////
			// Read defaults and remove extraneous
			// white space, i.e. \r\n
			///////////////////////////////////////
			command1=file.readLine().trim();

			///////////////////////////////////////
			// For UNIX system, only one command is
			// needed. Gerry Gleason suggests the
			// following.
			///////////////////////////////////////
			try{
           		command2=file.readLine().trim();
          	}catch(Exception e){command2=null;}
			file.close();
		}catch(Exception e){return false;}
		return true;
	}

	public String getCommand1(){return command1;}
	
	public String getCommand2(){return command2;}

    ///////////////////////////////////////
	// Save configuration defaults
	///////////////////////////////////////
	public boolean setConfig(String cmd1, String cmd2)
	{
        File fd = new File(filename);

        //////////////////////////////
        // Start fresh...
        //////////////////////////////
        if(fd.exists())fd.delete();
	    
		/////////////////////////////////
		// Get line separator from system
		/////////////////////////////////
		String separator=System.getProperty("line.separator");
		
		try{
			RandomAccessFile file= new RandomAccessFile(fd,"rw");

			////////////////////////////////////
			// Write and append line separators
			////////////////////////////////////
			file.writeBytes(cmd1 + separator);

            //////////////////////////////////////////////////
			// If the second command template is null, we're
			// on a Unix or similar type of system that uses
			// a single command to set both time and date, so
			// nothing should be written.
			/////////////////////////////////////////////////
			if(null != cmd2)file.writeBytes(cmd2 + separator);
			
			file.close();
			
		}catch(Exception e){return false;}
		return true;
	}
}

