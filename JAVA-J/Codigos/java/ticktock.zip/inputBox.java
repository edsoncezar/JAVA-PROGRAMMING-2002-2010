/* inputBox.java
 * Copyright (C) 1996 by William Giel
 *
 * E-mail: rvdi@usa.nai.net
 * WWW: http://www.nai.net/~rvdi/home.htm
 *
 ***************************************************************************
 * Abstract
 * --------
 * A generic OK/Cancel Dialog Box presently set up to permit data entry in
 * two textfields. If only one textfield is used, send null as the argument
 * 'dflt2' for the second textfield.
 *
 * As an abstract class, inputBox cannot be instantiated. Classes derived
 * from inputBox must define an action method. Two methods are provided for
 * initiallizing, one for a 350x150 dialog, and the other permitting a user
 * defined dialog size.
 *
 ***************************************************************************
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation without fee for NON-COMMERCIAL purposes is hereby granted.
 * 
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE
 * FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 ***************************************************************************/



import java.awt.*;
import java.lang.*;
import java.util.*;

abstract public class inputBox extends Dialog
{
    int width=350;
    int height=150;
	public static final String OK     = "OK";
	public static final String CANCEL = "Cancel";
    TextField textfield1,textfield2;

    /////////////////////////////////////////////
    // This initiallizer creates a 350 x 150 box
    /////////////////////////////////////////////
    public inputBox(    Frame parent,
                        String title,
                        String prompt,
                        String dflt,
                        String dflt2)
    {

        super(parent,true);

        Panel p1 = new Panel();

        p1.add(new Label(prompt));

        textfield1=new TextField(dflt,50);
        p1.add(textfield1);

        if(null != dflt2){
            textfield2=new TextField(dflt2,50);
            p1.add(textfield2);
        }
       

        Panel p2 = new Panel();
        p2.add(new Button(OK));
        p2.add(new Button(CANCEL));

        resize(width,height);

        /////////////////////////////////////////////////
        // Position dialog just below caption bar
        // and centered in parent. The vertical position
        // is a fudge, based on current font height.
        // Anybody know how to get system metrics???
        /////////////////////////////////////////////////
        move(   parent.location().x + (parent.size().width-width)/2,
                parent.location().y + getFontMetrics(getFont()).getHeight() * 8 / 3);
                                
                
        add("Center",p1);
        add("South",p2);
        
        setTitle(title);
        
    }

    //////////////////////////////////////////////////////////
    // This initiallizer creates a box with the specified
    // dimensions.
    //////////////////////////////////////////////////////////
    public inputBox(    Frame parent,
                        String title,
                        String prompt,
                        String dflt,
                        String dflt2,
                        int w,
                        int h)
    {

        super(parent,true);

        width=w;
        height=h;
       
        Panel p1 = new Panel();
 
        p1.add(new Label(prompt));

        textfield1=new TextField(dflt,50);
        p1.add(textfield1);

        if(null != dflt2){
            textfield2=new TextField(dflt2,50);
            p1.add(textfield2);
        }
       

        Panel p2 = new Panel();
        p2.add(new Button(OK));
        p2.add(new Button(CANCEL));


        resize(width,height);
        move(   parent.location().x + (parent.size().width-width)/2,
                parent.location().y + getFontMetrics(getFont()).getHeight() * 8 / 3);
                
        add("Center",p1);
        add("South",p2);
        setTitle(title);
    }
    
    ///////////////////////////////////////////////////////
    // You tell me what to do!
    ///////////////////////////////////////////////////////
    abstract public boolean action(Event evt, Object arg);

    ////////////////////////////////////////////////
    // Handle built-in events
    ////////////////////////////////////////////////
    public synchronized boolean handleEvent(Event e)
    {
        if (e.id == Event.WINDOW_ICONIFY ||e.id == Event.WINDOW_DESTROY) {
            dispose(); 
            return true;
        }
        return super.handleEvent(e);
    }
}

