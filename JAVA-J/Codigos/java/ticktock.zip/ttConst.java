/* ttConst.java
 * Copyright (C) 1996 by William Giel
 *
 * E-mail: rvdi@usa.nai.net
 * WWW: http://www.nai.net/~rvdi/home.htm
 *
 ***************************************************************************
 * Abstract
 * --------
 * A public interface containing our "stringtable" of literal strings
 * for labels and messages, and any other suitable 'const' data.
 *
 * Supports ticktock.java
 ***************************************************************************/

import java.lang.*;

public interface ttConst
{
	static final boolean DEBUG=false;
	
    ///////////////////////////////////////////////////////////
    // These are the time servers that support the implemented
    // time signal format.
    ///////////////////////////////////////////////////////////
    static final String[] SERVERLIST=  {"tick.usno.navy.mil",
    				                    "tock.usno.navy.mil",
    				                    null};

    //////////////////////////////////////////
    // Version text, typeface, and font height
    //////////////////////////////////////////    				                    
    static final String VERSION     =   "TickTock v1.04b Copyright 1996 by Bill Giel";
    static final String FONTSTRING  =   "Helvetica";
    static final int FONTHEIGHT     =   12;

    ///////////////////////////////////
    //How many ticks we'll try to grab.
    ///////////////////////////////////
    static final int SAMPLES        =   8;

    /////////////////////////////////////
    // Maximum std. deviation to trigger
    // data snooping.
    /////////////////////////////////////
    static final double MAX_SIGMA   =   0.5;

    
    ///////////////////////////
    // Button text
    ///////////////////////////
    static final String CONNECT     =   "Connect";
    static final String SET         =   "Set Time";
    static final String RESET       =   "Reset";
    static final String QUIT        =   "Quit";

    ///////////////////////////
    // Label text
    ///////////////////////////    
    static final String SYSTEM      =   "System Time/Date: ";
    static final String SERVER      =   "Server Time/Date: ";
    static final String OFFSET      =   "Time Zone (HH:MM): ";
    static final String CORRECTION  =   "Correction(secs): ";
    static final String SERVERNAME  =   "Time Server:";

    ///////////////////////////
    // Status messages
    ///////////////////////////    
    static final String USER_RESET  =   "User Reset!";
    static final String NO_CONNECT  =   "No Connection!";
    static final String WAITING     =   "Waiting for connection...";
    static final String CONTACTING  =   "Contacting: ";
    static final String CONNECTED   =   "Connected!";
    static final String ERRORMSG    =   "Error getting time/date.";
    static final String INVALID_TIME_FORMAT =
                                        "Time command must include 'hh', 'mm' and 'ss'.";
    static final String INVALID_DATE_FORMAT =
                                        "Date command must include 'MM', 'DD' and 'YY'.";    
    static final String FINISHED    =   "Finished - Number of Samples: ";
    static final String STD_DEVIATION =
                                        "Standard Deviation = � ";
    static final String REJECTS     =   "Number of Rejects: ";
    static final String NO_REJECTS  =   "No data was rejected.";
    static final String EVALUATING  =   "Evaluating data...";
    static final String NO_DATA     =   "WARNING - UNRELIABLE DATA!";
    static final String MEAN        =   "Mean Correction (seconds) = ";

    ////////////////////////////////////////////////
    // Caption, label, and default command templates
    // for the sysCommandDialog
    ////////////////////////////////////////////////
    static final String CONFIRM     =   "Confirm/Edit System Commands";
    static final String PROMPT      =   "Time/Date will be adjusted using the following system command(s):";
    static final String DFLT_TIME   =   "C:\\COMMAND.COM /C TIME hh:mm:ss";
    static final String DFLT_DATE   =   "C:\\COMMAND.COM /C DATE MM-DD-YY";

    ///////////////////////////////////////
    // Test for 'one tic' warning
    // Do not modify this string!
    ///////////////////////////////////////
    static final String USNO_WARNING=   "Only";

    ///////////////////////////////////////////
    // The file for default configuration data
    ///////////////////////////////////////////
    static final String DEFAULTS    =   "ticktock.cfg";
}
    								
