{
       int XMAX = 112;

       float[] m_Height = new float[XMAX] ;    //current height
       float[] m_G = new float[XMAX] ;         //move value before
       float b = 1.01f ;       //load factor
       float fWeight = 3 ;     //wave speed

       public void paint(Graphics g)
       {
           int i ;
           float a, w3, w3_2 ;
           float fWk ;

           g.setColor( Color.blue ) ;

           w3 = 3 * fWeight ;
           w3_2 = w3 - 2 ;
           m_Height[0] = m_Height[1] ;
           m_Height[(XMAX-1)] = m_Height[(XMAX-2)] ;
           a = m_Height[0] ;
           for ( i = 1 ; i < (XMAX-1) ; i++ ) {
               fWk = ((a + w3_2 * m_Height[i] + m_Height[i+1]) / w3 + m_G[i]) / b ;
               a = m_Height[i] ;
               m_G[i] = fWk - a ;
               m_Height[i] = fWk ;
               g.clearRect( (i-1)*4, (int)fWk-30, 4, 60 ) ;
               g.fillRect( (i-1)*4, (int)fWk+30, 4, 60 ) ;
           }
       }

       public void update(Graphics g)
       {
           paint(g);
       }
   }