

import java.awt.*;
import java.applet.*;

// Not much exciting here...  Class is just being used as a struct.  Not
// a pretty sight.

public class fPointTree {
	double        x,y;
	double	      vX, vY;
	fPointTree    left,right;


public fPointTree() {
  x = 0;
  y = 0;
  vX = 0;
  vY = 0;
  left = null;
  right = null;
}

public fPointTree(double a, double b, double vA, double vB, fPointTree l, fPointTree r) {
	x = a;
	y = b;
	vX = vA;
	vY = vB;
	left = l;
	right = r;
}

}





