/**
*		@author Kaushik Raj
*		@see	http://www.cis.syr.edu/~kraj/java/
*	@email	kraj@syr.edu
*	
*		(c) copyright-98 Kaushik Raj
*		All Rights Reserved.
*
*       This source code is free for all non-commercial purposes, as long as the name
*       and the url address given above is written with the modified program. The author does not gives
*       the permission to publish the source code in any book or any other publishing media.
*
*
*       The author doesnot takes any responsibility for the software/hardware damages
*       that may occur due to this program.
*/



/**
*	File : HungryRat.java
*	Last update : 10 July,1998
*/


import java.applet.*;
import java.awt.*;

/**
*	HungryRat class manages the control of the rat over the board.
*/
public class HungryRat implements Runnable{
	/** present position of the rat */
	private int ratX,ratY;

	/** previous position of the rat */
	private int oldx,oldy;

	/** thread to have rat independent */
	private Thread ratThread=null;

	/** counter to keep check if any click has been done otherwise random movement */
	private int click=0;

	/** conuter keeping track of rat's energy */
	private int foodclick=100;

	/** how long rat before reacting randomely */
	private final int RatReactionTime=3;

	/** how many blocks the mouse can smell */
	private final int noOfSmellBlocks;

	/** number of blocks the rat can move random */
	private final int noOfBlocks=1;

	private MazeCanvas mc;
	private Maze mz;
	private MazeGame mg;

	private int foodAt[][];

	/** boolean to know whether the game is still going on */
	private boolean gameOver=false;

	/**
	*	constructor
	*/
	public HungryRat(int ratX,int ratY,MazeCanvas mc,Maze mz,int noOfSmellBlocks,MazeGame mg){
		this.ratX=ratX;
		this.ratY=ratY;
		oldx=ratX;
		oldy=ratY;
		this.mc=mc;
		this.mz=mz;
		this.mg=mg;
		this.noOfSmellBlocks=noOfSmellBlocks;
		foodclick=100;
		foodAt=new int[mz.getCols()][mz.getRows()];
		for(int i=0;i<mz.getCols();i++)
			for (int j=0;j<mz.getRows();j++) foodAt[i][j]=0;
	}

	/**
	*	moves the rat given by the position x,y
	*/
	synchronized public void moveRatAt(int x,int y){
		if ((x>=mz.getCols())||(y>=mz.getRows())) return;
		oldx=ratX;
		oldy=ratY;
		ratX=x;
		ratY=y;
		removeFoodFrom(new Point(x,y));
		click=0;
	}

	/**
	*	returns the Point of the rat at that movement
	*/
	public Point getRatPosition(){
		return (new Point(ratX,ratY));
	}

	/** returnsd the older position of the rat */
	public Point getOldPosition(){
		return (new Point(oldx,oldy));
	}

	/**
	*	returns if the point given by x,y is reachable by the rat or not
	*/
	public boolean isReachable(int x,int y){
		return mz.isReachable(new Point(ratX,ratY),new Point(x,y),noOfBlocks);
	}

	/**
	*	runs 
	*/
	public void run(){
		while(!gameOver){
			click++;
			sleep(1000);

			if(anyFoodNearBy(getRatPosition(),noOfSmellBlocks).x!=-1){
				Point p=new Point(anyFoodNearBy(getRatPosition(),noOfSmellBlocks).x,anyFoodNearBy(getRatPosition(),noOfSmellBlocks).y);
				moveRatAt(p.x,p.y);
				increaseEnergy();
				mg.updateGraphics();
				click=0;
			}

			/* wait for three seconds before moving randomly */
			if (click>=RatReactionTime){
				click=0;
				decreaseEnergy();

				while(true){
						int i=(int) (Math.random()*10%2);
						int j=(int) (Math.random()*10%2);

						if (randomBoolean()) i*=-1;
						if (randomBoolean()) j*=-1;

						if (((i!=0)||(j!=0))&&(isReachable(getRatPosition().x+i,getRatPosition().y+j))){
							moveRatAt(getRatPosition().x+i,getRatPosition().y+j);
							mg.updateGraphics();
							break;
						}

				}//:~while
			}

			/** if no more food left game lost */
			if (foodclick<=0) {
					mg.gameLost();
					gameOver=true;
					break;

			}


		}//:while
	}//:~run()

	/**
	*	associates a thread to the rat
	*/
	public void init(){
		gameOver=false;
		if (ratThread==null){
			ratThread=new Thread(this);
			ratThread.start();
			System.out.println("ratThread started");
		}

	}

	/**
	*	stops the thread associated with the rat
	*/
	public void stop(){
		gameOver=true;
		if (ratThread!=null){
			ratThread.stop();
			ratThread=null;
			System.out.println("ratThread stop");
		}
	}//:~stop()

	/**
	*	tries to sleep the thread
	*/
	public void sleep(int ms){
		try{
			ratThread.sleep(ms);
		}catch(Exception e){
		}
	}//:~sleep

	/**
	*	returns a random boolean
	*/
	public boolean randomBoolean(){
		int i=(int) (Math.random()*10%2);

		if (i==1) return true;
		else return false;
	}


	/**
	*	checks whether the mouse position has been changed or not
	*/
	public boolean hasChanged(){
		boolean flag=false;
		if (oldx!=ratX) flag=true;
		if (oldy!=ratY) flag=true;

		return flag;
	}


	/**
	*
	*	keeps the food at the point 
	*/
	public void putFoodAt(Point p){
		foodAt[p.x][p.y]=1;
	}

	/**
	* returns false if there was no food at that point
	*
	*/
	public boolean removeFoodFrom(Point p){
		if (foodAt[p.x][p.y]==0) return false;
		foodAt[p.x][p.y]=0;
		return true;
	}
    
	/**
	*	returns the nearest point that comes otherwise returns (-1,-1) if there is no
	*	food available at the place.
	*/
	public Point anyFoodNearBy(Point p,int noOfBlocks){
		int minBlocksTaken=9999;
		Point newp=new Point(-1,-1);

		if (foodAt[p.x][p.y]==1){
			return p;
		}

		//check in all the vicinity area if there is a food or not
		//return the nearest point.
		for (int i=-noOfBlocks;i<noOfBlocks+1;i++){
			for (int j=-noOfBlocks;j<noOfBlocks+1;j++){
				//first check this area is within the range
				if ((p.x+i>=0)&&(p.y+j>=0)&&(p.x+i<mz.getCols())&&(p.y+j<mz.getRows())){ 
					//check if this place is reachable
					if (foodAt[p.x+i][p.y+j]==1)
					if (mz.isReachable(p,new Point(p.x+i,p.y+j),noOfBlocks)){
						//check now that this point is the smallest path
						int blocksTaken=mz.getPath(p,new Point(p.x+i,p.y+j));
						if (blocksTaken<minBlocksTaken) {
							minBlocksTaken=blocksTaken;
							newp=new Point(p.x+i,p.y+j);
						}
					}
				}
			}
		}

		return (newp);
	}

	/** method to stop the game and rat thread */
	public void gameOver(){
		gameOver=true;
		stop();
	}

	/** increases the rat energy */
	public void increaseEnergy(){
		foodclick+=10;
		if (foodclick>100) foodclick=100;
	}

	/** decreasses the rat energu */
	public void decreaseEnergy(){
		foodclick-=10;
	}

	/** returns the strenght of the rat */
	public int getEnergy(){
		return foodclick;
	}

	/** returnsd the time left before rat is going to die */
	public int getTimeLeft(){
		return (int)((RatReactionTime-click)*100/RatReactionTime);
	}

	/** returns the food matrix */
	public int[][] getFoodPosition(){
		return foodAt;
	}

}//:~HungryRat