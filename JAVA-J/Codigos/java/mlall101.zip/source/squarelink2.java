/**
    squarelink2.java
    Copyright 1998-1999 by Maier Media.
    All rights reserved. 
*/
/**
    For information, bug reports, or to suggest code changes, 
    please email mightylinks@maiermedia.com
   
    Lastest information on MightyLinks and other Maier Media
    products can be found at:
      
      http://www.maiermedia.com 

    This software is released under the terms of the General
    Public License (GPL) Version 2 as published by the Free
    Software Foundation (http://www.fsf.org). The complete
    text of the GPL can be obtained from the Free Software
    Foundation or found on the World Wide Web at
    http://www.fsf.org/copyleft/gpl.html
    
    This software is distributed in the hope it will be 
    useful but WITHOUT ANY WARRANTY; without even the 
    implied warranty of MERCHANTABILITY or FITNESS FOR A 
    PARTICULAR PURPOSE.
*/
/**
    Version History for squarelink2.java 
   
    -- Please note any code changes here!! --

    5/17/1999  1.0  Original release
    5/22/1999  1.0.1  Use of GNU GPL, source code cleanup and release
*/
    
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.awt.image.ImageObserver;
import java.lang.Thread;
import squarehelper2;
import squarelisten2;

/** 
    squarelink2 -- an easily-configured Java link button
    that looks and acts like an application button. 
    Designed for Java 1.1. 
*/

public class squarelink2 extends java.applet.Applet 
  implements ImageObserver
{
  public static final String mszAppletInfo = "MightyLink/squarelink for Java 1.1.x\nVersion 1.0.1\nCopyright 1998-1999 by Maier Media\nhttp://www.maiermedia.com\n";

  public static final int FIRE_LINK = 0;
  public static final int CAPTION_CHANGE = 1;
  
  public squarehelper2 mLinkButton = new squarehelper2(this);
  
  public Rectangle mButtonRect;
  
  public int mnButtonX;
  public int mnButtonY;
  public int mnButtonWidth;
  public int mnButtonHeight;
  
  public URL murlImage;
  public Image miImage;
  public boolean mbImageReady = true;

  public Color mBackgroundColor = Color.white;
  public Color mBorderColor= Color.white;

  // Shadow the button on the applet area
  public Color mButtonShadow = null;

  public int mnBorderWidth = 0;
  
  // Browser AppletContext parameters
  public String msLink;
  public String msTargetFrame = "_self";  // Default to same frame
  
  public String msCaption;
  public String msMouseCaption;
  public String msClickCaption;
  
  public boolean mbMouseOver = false;
  public boolean mbMouseDown = false;

  // Special cases to prevent a bunch of 
  // unnecessary redraws
  public boolean mbMouseJustPressed = false;
  public boolean mbMouseDragOut = false;

/**
*/
  
  public String getAppletInfo()
  {
    return mszAppletInfo;
  } // getAppletInfo()

/**
*/

  public void init()
  {
    setDefaults();
    getParameters();   
    add(mLinkButton);
    loadImages();
    
    addMouseListener(new squarelisten2(this));
  } // init()
  
/**
*/

  public void paint(Graphics g)
  {
    Rectangle r = getBounds();
    
    // Get the current X position of the button
    int nLastX = mLinkButton.getBounds().x; 
    
    // Fill the applet background
    g.setColor(mBackgroundColor);
    g.fillRect(0, 0, r.width, r.height);

    if ((miImage != null) &&
        (mbImageReady == true)) {
      g.drawImage(miImage, 0, 0, 
                  r.width, r.height, mBackgroundColor, this);
    } 
    
    // After drawing the button, draw a shadow
    // for the button
    if (mButtonShadow != null) {

      g.setColor(mButtonShadow);
      
      // The shadow consists of a vertical and
      // horizontal rectangle two pixels wide. It
      // is drawn to the right and bottom of the
      // button
      g.fillRect((mnButtonX + mnButtonWidth),
                 (mnButtonY + 2), 
                 2, mnButtonHeight);
      g.fillRect((mnButtonX + 2), 
                 (mnButtonY + mnButtonHeight),
                 mnButtonWidth, 2); 
    } 

    // Has a pressed mouse left the button area?
    if (mbMouseDragOut) {
      mLinkButton.setBounds(mnButtonX, mnButtonY,
                            mnButtonWidth, mnButtonHeight);
      mbMouseDragOut = false;
    }

    // Reposition the button
    if ((mbMouseOver == true) &&
        (mbMouseDown == true)) {
      mLinkButton.setBounds((mnButtonX + 1), (mnButtonY + 1),
                            mnButtonWidth, mnButtonHeight);
    }
    else {
      mLinkButton.setBounds(mnButtonX, mnButtonY, 
                            mnButtonWidth, mnButtonHeight);
    }
  } // paint()
  
/**
*/

  public boolean imageUpdate(Image img, int flags,
                             int x, int y, int w, int h)
  {
    // Force a repaint if ALLBITS
    if ((flags & ALLBITS) != 0) {

      if (img == mLinkButton.miImage) mLinkButton.mbImageReady = true;
      if (img == miImage) mbImageReady = true;
      if (img == mLinkButton.miMouseImage) mLinkButton.mbMouseImageReady = true;
      if (img == mLinkButton.miClickImage) mLinkButton.mbClickImageReady = true;

      repaint();
      mLinkButton.repaint();
      return true; // Leave this out if you want to invoke super
    }

    return super.imageUpdate(img, flags, x, y, w, h);

  } // imageUpdate()

/**
*/

  public void fireLink()
  {
    try {
      getAppletContext().showDocument(new URL(msLink), msTargetFrame);
    }
    catch (Exception ex) {
      System.out.println("Unable to Link -- " + msLink + ex.toString());
    }
  } // fireLink()
  
/**
*/
  
  public void setDefaults()
  {
    Rectangle r = getBounds();

    // Default values are neutral
    mnButtonX = 0;
    mnButtonY = 0;
   
    mnButtonWidth = (r.width - 1);
    mnButtonHeight = (r.height - 1);

    mnBorderWidth = 0;
    
    try {
      murlImage = new URL(getCodeBase().toString());
    }
    catch (Exception ex) {
      // Do nothing
    }
  } // setDefaults()

/**
*/
    
  public void handleMouseEntered()
  { 
    showStatus(msCaption);
  } // handleMouseEntered()

/**
*/

  public void handleMouseExited()
  {
    getAppletContext().showStatus("");    
  } // handleMouseExited()

/**
*/

  public void showStatus(String sCaption)
  {
    // The button class can't change the
    // browser caption because it can't call
    // getAppletContext(). This provides an
    // exposed method for the button to use
    // to do showStatus().
    getAppletContext().showStatus(sCaption);
  } // showStatus()
  
/**
*/
  
  public void loadImages()
  {
    // This routine makes sure that the images
    // are loaded one at a time in a predefined
    // order. This reduces the number of threads
    // running simultaneously when several applets
    // are on the same page or when the image 
    // files are large.
    if (mLinkButton.miMouseImage != null) {
      
      mLinkButton.mbImageReady = 
        prepareImage(mLinkButton.miImage, this);

      while (mLinkButton.mbImageReady == false) {
        try {
          Thread.sleep(100);
        }
        catch(Exception ex) {}
      }
    }

    if (miImage != null) {

      mbImageReady = prepareImage(miImage, this);
      while (mbImageReady == false) {
        try {
          Thread.sleep(100);
        }
        catch(Exception ex) {}
      }
    }

    if ((mLinkButton.miMouseImage != null) &&
        (mLinkButton.miMouseImage != mLinkButton.miImage)) {
      
      mLinkButton.mbMouseImageReady = 
        prepareImage(mLinkButton.miMouseImage, this);
      
      while (mLinkButton.mbMouseImageReady == false) {
        try {
          Thread.sleep(100);
        }
        catch(Exception ex) {}
      }
    }

    if ((mLinkButton.miClickImage != null) &&
        (mLinkButton.miClickImage != mLinkButton.miMouseImage)) {
      
      mLinkButton.mbClickImageReady = 
       prepareImage(mLinkButton.miClickImage, this);

      while (mLinkButton.mbClickImageReady == false) {
        try {
          Thread.sleep(100);
        }
        catch(Exception ex) {}
      }
    }
  } // loadImages()

/**
*/

  public void getParameters()
  {
    String sTemp = "";
    
    // Set up the button
    
    // Check for preset before doing anything else
    // PRESET
    sTemp = "";
    sTemp = getSafeParm("PRESET");
    if (sTemp.length() > 0) mLinkButton.doPreset(sTemp);
    
    // APPLETCOLOR 
    sTemp = "";
    sTemp = getSafeParm("BGCOLOR");
    if (sTemp.length() > 0) mBackgroundColor = getHTMLColor(sTemp);
     
    // APPLETBORDERCOLOR
    sTemp = "";
    sTemp = getSafeParm("APPLETBORDERCOLOR");
    if (sTemp.length() > 0) mBorderColor = getHTMLColor(sTemp);
    
    // BGIMAGE
    sTemp = "";
    sTemp = getSafeParm("BGIMAGE");
    if (sTemp.length() > 0) {
      try { 
        miImage = getImage(murlImage, sTemp); 
      }
      catch (Exception ex) { miImage = null; }
    }

    // BUTTONX
    sTemp = "";
    sTemp = getSafeParm("BUTTONX");
    if (sTemp.length() > 0) {
      try {
        mnButtonX = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
        
    // BUTTONY
    sTemp = "";
    sTemp = getSafeParm("BUTTONY");
    if (sTemp.length() > 0) {
      try {
        mnButtonY = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
        
    // BUTTONSHADOW
    sTemp = "";
    sTemp = getSafeParm("BUTTONSHADOW");
    if (sTemp.length() > 0) {
      
      mButtonShadow = getHTMLColor(sTemp);
      
      // BUTTONSHADOW requires a little
      // extra space for the button.
      // Of course, using the BUTTONWIDTH
      // and BUTTONHEIGHT parameters could
      // override this.
      if (mButtonShadow != null) {
        mnButtonWidth-= 2;
        mnButtonHeight-= 2;
      }
    }
        
    // BUTTONWIDTH
    sTemp = "";
    sTemp = getSafeParm("BUTTONWIDTH");
    if (sTemp.length() > 0) {
      try {
        mnButtonWidth = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
    
    // BUTTONHEIGHT
    sTemp = "";
    sTemp = getSafeParm("BUTTONHEIGHT");
    if (sTemp.length() > 0) {
      try {
        mnButtonHeight = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
     
    // COLOR
    sTemp = "";
    sTemp = getSafeParm("COLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mBackgroundColor = getHTMLColor(sTemp);
    }
 
    // BORDERCOLOR
    sTemp = "";
    sTemp = getSafeParm("BORDERCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mBorderColor = getHTMLColor(sTemp);
    }
     
    // TEXTCOLOR
    sTemp = "";
    sTemp = getSafeParm("TEXTCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mTextColor = getHTMLColor(sTemp);
    }
    
    // MOUSECOLOR
    sTemp = "";
    sTemp = getSafeParm("MOUSECOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mMouseBackgroundColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mMouseBackgroundColor = mLinkButton.mBackgroundColor;
    } 

    // MOUSEBORDERCOLOR
    sTemp = "";
    sTemp = getSafeParm("MOUSEBORDERCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mMouseBorderColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mMouseBorderColor = mLinkButton.mBorderColor;
    }
    
    // MOUSETEXTCOLOR
    sTemp = "";
    sTemp = getSafeParm("MOUSETEXTCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mMouseTextColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mMouseTextColor = mLinkButton.mTextColor;
    }
     
    // CLICKCOLOR
    sTemp = "";
    sTemp = getSafeParm("CLICKCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mClickBackgroundColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mClickBackgroundColor = mLinkButton.mMouseBackgroundColor;
    }
    
    // CLICKBORDERCOLOR
    sTemp = "";
    sTemp = getSafeParm("CLICKBORDERCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mClickBorderColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mClickBorderColor = mLinkButton.mMouseBorderColor;
    }
     
    // CLICKTEXTCOLOR
    sTemp = "";
    sTemp = getSafeParm("CLICKTEXTCOLOR");
    if (sTemp.length() > 0) {
      mLinkButton.mClickTextColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mClickTextColor = mLinkButton.mMouseTextColor;
    }

    // IMAGE
    sTemp = "";
    sTemp = getSafeParm("IMAGE");
    if (sTemp.length() > 0) {
      try { 
        mLinkButton.miImage = getImage(murlImage, sTemp); 
      }
      catch (Exception ex) { mLinkButton.miImage = null; }
    }
    
    // MOUSEIMAGE
    sTemp = "";
    sTemp = getSafeParm("MOUSEIMAGE");
    if (sTemp.length() > 0) {
      try { 
        mLinkButton.miMouseImage = getImage(murlImage, sTemp);
      }
      catch (Exception ex) { mLinkButton.miMouseImage = null; }
    }
    else {
      mLinkButton.miMouseImage = mLinkButton.miImage;
    }
    
    // CLICKIMAGE
    sTemp = "";
    sTemp = getSafeParm("CLICKIMAGE");
    if (sTemp.length() > 0) {
      try { 
        mLinkButton.miClickImage = getImage(murlImage, sTemp); 
      }
      catch (Exception ex) { mLinkButton.miClickImage = null; }
    }
    else {
      mLinkButton.miClickImage = mLinkButton.miMouseImage;
    }

    // BORDERWIDTH
    sTemp = "";
    sTemp = getSafeParm("BORDERWIDTH");
    if (sTemp.length() > 0) {
      try {
        mLinkButton.mnBorderWidth = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
    
    // TEXT
    sTemp = "";
    sTemp = getSafeParm("TEXT");
    if (sTemp.length() > 0) mLinkButton.msText = sTemp;
    
    // MOUSETEXT
    sTemp = "";
    sTemp = getSafeParm("MOUSETEXT");
    if (sTemp.length() > 0) {
      mLinkButton.msMouseText = sTemp;
    }
    else {
      mLinkButton.msMouseText = mLinkButton.msText;
    }
    
    // CLICKTEXT
    sTemp = "";
    sTemp = getSafeParm("CLICKTEXT");
    if (sTemp.length() > 0) {
      mLinkButton.msClickText = sTemp;
    }
    else {
      mLinkButton.msClickText = mLinkButton.msMouseText;
    }
    
    // TEXTVALIGN
    sTemp = "";
    sTemp = getSafeParm("TEXTVALIGN");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().charAt(0) == 'C') 
        mLinkButton.mnTextVAlign = mLinkButton.VALIGN_CENTER;
      if (sTemp.toUpperCase().charAt(0) == 'T') 
        mLinkButton.mnTextVAlign = mLinkButton.VALIGN_TOP;
      if (sTemp.toUpperCase().charAt(0) == 'B') 
        mLinkButton.mnTextVAlign = mLinkButton.VALIGN_BOTTOM;
    }
     
    // MOUSETEXTVALIGN
    sTemp = "";
    sTemp = getSafeParm("MOUSETEXTVALIGN");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().charAt(0) == 'C') 
        mLinkButton.mnMouseTextVAlign = mLinkButton.VALIGN_CENTER;
      if (sTemp.toUpperCase().charAt(0) == 'T')
        mLinkButton.mnMouseTextVAlign = mLinkButton.VALIGN_TOP;
      if (sTemp.toUpperCase().charAt(0) == 'B') 
        mLinkButton.mnMouseTextVAlign = mLinkButton.VALIGN_BOTTOM;
    }
    else {
      mLinkButton.mnMouseTextVAlign = mLinkButton.mnTextVAlign;
    }

    // CLICKTEXTVALIGN
    sTemp = "";
    sTemp = getSafeParm("CLICKTEXTVALIGN");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().charAt(0) == 'C') 
        mLinkButton.mnClickTextVAlign = mLinkButton.VALIGN_CENTER;
      if (sTemp.toUpperCase().charAt(0) == 'T') 
        mLinkButton.mnClickTextVAlign = mLinkButton.VALIGN_TOP;
      if (sTemp.toUpperCase().charAt(0) == 'B') 
        mLinkButton.mnClickTextVAlign = mLinkButton.VALIGN_BOTTOM;
    }
    else {
      mLinkButton.mnClickTextVAlign = mLinkButton.mnMouseTextVAlign;
    }
    
    // FONT
    sTemp = "";
    sTemp = getSafeParm("FONT");
    if (sTemp.length() > 0) {
      mLinkButton.msFont = sTemp;
    }
    
    // MOUSEFONT
    sTemp = "";
    sTemp = getSafeParm("MOUSEFONT");
    if (sTemp.length() > 0) {
      mLinkButton.msMouseFont = sTemp;
    }
    else {
      mLinkButton.msMouseFont = mLinkButton.msFont;
    }
    
    // CLICKFONT
    sTemp = "";
    sTemp = getSafeParm("CLICKFONT");
    if (sTemp.length() > 0) {
      mLinkButton.msClickFont = sTemp;
    }
    else {
      mLinkButton.msClickFont = mLinkButton.msMouseFont;
    }
    
    // FONTSIZE
    sTemp = "";
    sTemp = getSafeParm("FONTSIZE");
    if (sTemp.length() > 0) {
      try {
        mLinkButton.mnFontSize = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
    
    // MOUSEFONTSIZE
    sTemp = "";
    sTemp = getSafeParm("MOUSEFONTSIZE");
    if (sTemp.length() > 0) {
      try {
        mLinkButton.mnMouseFontSize = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
    else {
      mLinkButton.mnMouseFontSize = mLinkButton.mnFontSize;
    }
    
    // CLICKFONTSIZE
    sTemp = "";
    sTemp = getSafeParm("CLICKFONTSIZE");
    if (sTemp.length() > 0) {
      try {
        mLinkButton.mnClickFontSize = (new Integer(sTemp).intValue());
      }
      catch (Exception ex) {}
    }
    else {
      mLinkButton.mnClickFontSize = mLinkButton.mnMouseFontSize;
    }
    
    // OR new fontstyle with existing fontstyle
    // This should allow combined styles (i.e. BOLD ITALIC).
    // FONTSTYLE
    sTemp = "";
    sTemp = getSafeParm("FONTSTYLE");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().indexOf("P") > -1) 
        mLinkButton.mnFontStyle = (mLinkButton.mnFontStyle | Font.PLAIN);
      if (sTemp.toUpperCase().indexOf("B") > -1) 
        mLinkButton.mnFontStyle = (mLinkButton.mnFontStyle | Font.BOLD);
      if (sTemp.toUpperCase().indexOf("I") > -1) 
        mLinkButton.mnFontStyle = (mLinkButton.mnFontStyle | Font.ITALIC);
      if (sTemp.toUpperCase().indexOf("U") > -1)
        mLinkButton.mbUnderline = true;
    }

    // MOUSEFONTSTYLE
    sTemp = "";
    sTemp = getSafeParm("MOUSEFONTSTYLE");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().indexOf("P") > -1) 
        mLinkButton.mnMouseFontStyle = 
          (mLinkButton.mnMouseFontStyle | Font.PLAIN);
      if (sTemp.toUpperCase().indexOf("B") > -1) 
        mLinkButton.mnMouseFontStyle = 
          (mLinkButton.mnMouseFontStyle | Font.BOLD);
      if (sTemp.toUpperCase().indexOf("I") > -1) 
        mLinkButton.mnMouseFontStyle = 
          (mLinkButton.mnMouseFontStyle | Font.ITALIC);
      if (sTemp.toUpperCase().indexOf("U") > -1)
        mLinkButton.mbMouseUnderline = true;
    }
    else {
      mLinkButton.mnMouseFontStyle = mLinkButton.mnFontStyle;
      mLinkButton.mbMouseUnderline = mLinkButton.mbUnderline;
    }

    // CLICKFONTSTYLE
    sTemp = "";
    sTemp = getSafeParm("CLICKFONTSTYLE");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().indexOf("P") > -1)
        mLinkButton.mnClickFontStyle = (mLinkButton.mnClickFontStyle | Font.PLAIN);
      if (sTemp.toUpperCase().indexOf("B") > -1) 
        mLinkButton.mnClickFontStyle = (mLinkButton.mnClickFontStyle | Font.BOLD);
      if (sTemp.toUpperCase().indexOf("I") > -1) 
        mLinkButton.mnClickFontStyle = (mLinkButton.mnClickFontStyle | Font.ITALIC);
      if (sTemp.toUpperCase().indexOf("U") > -1)
        mLinkButton.mbClickUnderline = true;
    }
    else {
      mLinkButton.mnClickFontStyle = mLinkButton.mnMouseFontStyle;
      mLinkButton.mbClickUnderline = mLinkButton.mbMouseUnderline;
    }
    
    // LINK
    sTemp = "";
    sTemp = getSafeParm("LINK");
    if (sTemp.length() > 0) {
      msLink = getSafeHREF(sTemp);
    }
    else {
      msLink = "";
    }

    // HREF (Same as LINK)
    sTemp = "";
    sTemp = getSafeParm("HREF");
    if (sTemp.length() > 0) {
      msLink = getSafeHREF(sTemp);
    }
    else {
      msLink = "";
    }

    // CAPTION (browser caption)
    sTemp = "";
    sTemp = getSafeParm("CAPTION");
    if (sTemp.length() > 0) {
      msCaption = sTemp;
    }
    else {
      msCaption = "";
    }
    
    // MOUSECAPTION 
    sTemp = "";
    sTemp = getSafeParm("MOUSECAPTION");
    if (sTemp.length() > 0) {
      msMouseCaption = sTemp;
    }
    else {
      // If there is no MOUSECAPTION and no
      // CAPTION, then use whatever text is
      // in the button as a caption
      if (msCaption.length() > 0) {
        msMouseCaption = msCaption;
      }
      else {
        msMouseCaption = mLinkButton.msText;
      }
    }

    // CLICKCAPTION
    sTemp = "";
    sTemp = getSafeParm("CLICKCAPTION");
    if (sTemp.length() > 0) {
      msClickCaption = sTemp;
    }
    else {
      msClickCaption = msMouseCaption;
    }
    
    sTemp = "";
    sTemp = getSafeParm("BUTTONSTYLE");
    if (sTemp.length() > 0) {
      if (sTemp.toUpperCase().charAt(0) == 'N') 
        mLinkButton.mnStyle = mLinkButton.NORMAL;
      if (sTemp.toUpperCase().charAt(0) == 'R') 
        mLinkButton.mnStyle = mLinkButton.RAISED;
      if (sTemp.toUpperCase().charAt(0) == 'M') 
        mLinkButton.mnStyle = mLinkButton.MODERN;
    }

    // TEXTSHADOW
    sTemp = "";
    sTemp = getSafeParm("TEXTSHADOW");
    if (sTemp.length() > 0) {
      mLinkButton.mTextShadowColor = getHTMLColor(sTemp);
    }

    // MOUSETEXTSHADOW
    sTemp = "";
    sTemp = getSafeParm("MOUSETEXTSHADOW");
    if (sTemp.length() > 0) {
      mLinkButton.mMouseTextShadowColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mMouseTextShadowColor = mLinkButton.mTextShadowColor;
    }
    
    // CLICKTEXTSHADOW
    sTemp = "";
    sTemp = getSafeParm("CLICKTEXTSHADOW");
    if (sTemp.length() > 0) {
      mLinkButton.mClickTextShadowColor = getHTMLColor(sTemp);
    }
    else {
      mLinkButton.mClickTextShadowColor = mLinkButton.mMouseTextShadowColor;
    }       

    // TARGET
    sTemp = "";
    sTemp = getSafeParm("TARGET");
    if (sTemp.length() > 0) {
      msTargetFrame = sTemp;
    }
  } // getParameters()
  
/**
*/
  
  public String getSafeParm(String sParm)
  {
    String sRet = "";
    String sTemp = "";
    boolean bGotParm = true;
    
    try { sTemp = getParameter(sParm); }
    catch (Exception ex) { bGotParm = false; }
    
    try { if (sTemp.length() > 0) bGotParm = true; }
    catch (Exception ex) { bGotParm = false; }
    
    if (bGotParm == true) sRet = sTemp;
    
    return sRet;
  } // getSafeParm()  
  
/**
*/

  public String getSafeHREF(String sParm)
  {
    // A safe way to get an absolute or 
    // relative HREF param value
    String sTemp = sParm.trim();
    sParm = sParm.trim();
    
    if (sTemp.toLowerCase().indexOf("http://") == 0) {
      return sParm;
    }
    else {
      // Is there a leading slash to trim?
      if (sParm.indexOf("/") == 0) {
        sParm = sParm.substring(1);
      }
      
      sParm = getCodeBase().toString() + sParm;
    }
    
    return sParm;
  } // getSafeHREF

/**
*/

  public Color getHTMLColor(String sColor)
  {
    // Convert incoming color string into
    // something we can use. Also 
    // understands HTML-style RGB values
    String sRGB;
    int nRGB;
    Integer niRGB;
    
    sColor = sColor.toUpperCase().trim();

    // Preset color constants
    if (sColor.compareTo("WHITE") == 0) return Color.white;
    if (sColor.compareTo("BLACK") == 0) return Color.black;
    if (sColor.compareTo("GRAY") == 0) return Color.gray;
    if (sColor.compareTo("LIGHTGRAY") == 0) return Color.lightGray;
    if (sColor.compareTo("DARKGRAY") == 0) return Color.darkGray;
    if (sColor.compareTo("RED") == 0) return Color.red;
    if (sColor.compareTo("GREEN") == 0) return Color.green;
    if (sColor.compareTo("BLUE") == 0) return Color.blue;
    if (sColor.compareTo("PINK") == 0) return Color.pink;
    if (sColor.compareTo("ORANGE") == 0) return Color.orange;
    if (sColor.compareTo("YELLOW") == 0) return Color.yellow;
    if (sColor.compareTo("MAGENTA") == 0) return Color.magenta;
    if (sColor.compareTo("CYAN") == 0) return Color.cyan;

    if (sColor.charAt(0) == '#') {

      sRGB = "" + sColor.substring(sColor.indexOf("#") + 1);
      nRGB = hexToInt(sRGB);
      return new Color(nRGB);
    }
    
    return Color.white;
  } // getHTMLColor()
  
/**
*/
 
  public int hexToInt(String sVal)
  {
    String sChar;
    int nNum = 0;
    int nMult = 16;   // Multiplier
    int nMultRes = 1;
    int nRet = 0;

    // Convert incoming hex string to an integer
        
    sVal = sVal.toUpperCase();
    
    for (int cnt = (sVal.length() - 1); cnt > -1; cnt--) {
      sChar = sVal.substring(cnt, (cnt + 1));
      
      try {
        nNum = new Integer(sChar).intValue();
      }
      catch(Exception ex) {

        if (sChar.charAt(0) == 'A') nNum = 10;
        if (sChar.charAt(0) == 'B') nNum = 11;
        if (sChar.charAt(0) == 'C') nNum = 12;
        if (sChar.charAt(0) == 'D') nNum = 13;
        if (sChar.charAt(0) == 'E') nNum = 14;
        if (sChar.charAt(0) == 'F') nNum = 15;
      }   
   
      nRet = nRet + (nNum * nMultRes);
      
      nMultRes = nMultRes * nMult;
      
    }
    
    return nRet;
  } // hexToInt()
}
