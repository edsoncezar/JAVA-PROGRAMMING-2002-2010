/* 
    squarelisten2.java 
    Copyright 1998-1999 by Maier Media.
    All rights reserved. 
*/
/**    
    http://www.maiermedia.com

    This code is released under the terms of the
    General Public License Version 2 as published
    by the Free Software Foundation. For more
    information, please visit http://www.fsf.org
*/
/** 
    Version History for squarelisten2.java
    
    -- Please log any changes here!! --
    
    5/17/1999 1.0 Original release
    5/22/1999 1.0.1 Use of GNU GPL, source code cleanup and release
*/

import java.awt.*;
import java.awt.event.*;
import squarelink2;
import squarehelper2;

/** 
    A listener class which allows use of the
    Java 1.1 event model.
*/

public class squarelisten2 extends MouseAdapter
{
  squarelink2 mApplet;
  squarehelper2 mButton;
  
  boolean bEntering;
  boolean bExiting;

/**
*/

  squarelisten2 (squarelink2 applet)
  {
    this.mApplet = applet;
  }

/**
*/
  
  squarelisten2 (squarehelper2 button)
  {
    this.mButton = button;
  }

/**
*/
       
  public void mouseEntered(MouseEvent evt)
  {
    if (evt.getSource() == mApplet)
      mApplet.handleMouseEntered();
    if (evt.getSource() == mButton)
      mButton.handleMouseEntered();
  } // mouseEntered()
    
/**
*/
    
  public void mouseExited(MouseEvent evt)
  {
    if (evt.getSource() == mApplet)
      mApplet.handleMouseExited();
    if (evt.getSource() == mButton)
      mButton.handleMouseExited();
  } // mouseExited()

/**
*/

  public void mousePressed(MouseEvent evt)
  {
    if (evt.getSource() == mButton) mButton.handleMousePressed();
  } // mousePressed()
  
/**
*/
    
  public void mouseReleased(MouseEvent evt)
  {
    if (evt.getSource() == mButton) mButton.handleMouseReleased();
  } // mouseReleased()
}
