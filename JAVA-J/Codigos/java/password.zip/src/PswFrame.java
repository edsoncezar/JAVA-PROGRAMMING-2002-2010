import java.net.URL;
import java.net.MalformedURLException;
import java.util.Hashtable;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.applet.Applet;

/** Login Window, written by Dan Kiser, 1999
 *  <p>
 *  This class is used display a window that allows
 *  a user to enter their user name and password.
 *  If a valid user name and password is entered,
 *  the valid flag is set to true.  This flag is
 *  queried by the calling applet.  
 *
 */
public class PswFrame extends Frame implements ActionListener, KeyListener, WindowListener {

  // Constants
  private final int MAX_ATTEMPTS = 3;  // Max number of attempts

  // Variables
  private TextField name;              // Name field
  private TextField psw;               // Password field
  private Button login;                // Login button
  private Hashtable hash = null;       // Hash table of users
  private int attempt = 0;             // Count login attempts
  private boolean valid = false;       // Login success flag
  private password app;                // Parent applet
  private URL pswfile;                 // Password file URL


  public PswFrame(password parent, URL pswURL)
  {

    super("Login");

    app     = parent;
    pswfile = pswURL;

    // Set background color
    setBackground(new Color(Color.white.getRGB()));

    // Set font
    setFont(new Font("SansSerif", Font.PLAIN, 14));

    // Set layout
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    setLayout(gridbag);    

    // Name label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 0, 1, 1, 10, 40);
    Label label1 = new Label("Username:", Label.LEFT);
    gridbag.setConstraints(label1, constraints);
    add(label1);

    // Name text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 0, 1, 1, 90, 0);
    name = new TextField();
    gridbag.setConstraints(name, constraints);
    name.addKeyListener(this);
    add(name);

    // Password label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 1, 1, 1, 0, 40);
    Label label2 = new Label("Password:", Label.LEFT);
    gridbag.setConstraints(label2, constraints);
    add(label2);

    // Password text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 1, 1, 1, 0, 0);
    psw = new TextField();
    psw.setEchoChar('*');
    gridbag.setConstraints(psw, constraints);
    psw.addKeyListener(this);
    add(psw);

    // Button Panel
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.CENTER;
    buildConstraints(constraints, 0, 2, 2, 1, 0, 20);
    Panel panel = new Panel();

    // Set panel layout
    panel.setLayout(new GridLayout(1, 2, 20, 2));
    gridbag.setConstraints(panel, constraints);
    add(panel);

    // Login button
    login = new Button("Login");
    login.addActionListener(this);
    login.addKeyListener(this);
    login.setEnabled(false);
    panel.add(login);

    // Cancel button
    Button cancel = new Button("Cancel");
    cancel.addActionListener(this);
    cancel.addKeyListener(this);
    panel.add(cancel);

    // Add WindowListener
    addWindowListener(this);

    setSize(225,175);
    setResizable(false);

    // Position window on screen
    Dimension d = getToolkit().getScreenSize();

    int x = Math.round( (d.width - 225) / 2 );
    int y = Math.round( (d.height - 175) / 2 );

    setLocation( new Point(x,y) );

    setVisible(true);

  } // PswFrame


  void buildConstraints(GridBagConstraints gbc, int gx, int gy, int gw, int gh, int wx, int wy)
  {
    gbc.gridx = gx;
    gbc.gridy = gy;
    gbc.gridwidth = gw;
    gbc.gridheight = gh;
    gbc.weightx = wx;
    gbc.weighty = wy;
    gbc.ipadx = 0;
    gbc.ipady = 0;

  } // buildConstraints


  public Insets getInsets() {
    return new Insets(20, 20, 20, 20);
  }


  //*******************************************************
  // The following methods implement a KeyListener for
  // this class.  The KeyListener is used to listen for key 
  // press events in the text fields and buttons.  For
  // text field, only letters and digits are allowed to
  // be entered. 
  // 
  public void keyTyped(KeyEvent e) {
    return;  
  }

  public void keyPressed(KeyEvent e) {
    return;
  }

  public void keyReleased(KeyEvent e) {

    if (e.getSource() instanceof Button) {

      Button theSource = (Button) e.getSource();

//      System.out.println("Command="+theSource.getActionCommand());

      // Dispatch a new action event so that the ENTER key
      // behaves like a mouse click.
      if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        ActionEvent ae = new ActionEvent(e.getSource(),ActionEvent.ACTION_PERFORMED,theSource.getActionCommand());
        theSource.dispatchEvent(ae);
      }

    }
    else {

      TextField theSource = (TextField) e.getSource();

//      System.out.println("Key Press="+e.getKeyCode());

      if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        theSource.transferFocus();
      }
    }

  }


  //*******************************************************
  // The following methods implement a WindowListener for
  // this class.  
  // 
  public void windowOpened(WindowEvent e) {
    // Load user db
    if (hasUsers()) {
      login.setEnabled(true);
      name.requestFocus();
    }
    else {
      MsgDialog msg = new MsgDialog(this, "Error", "Unable to locate user database.");
      setVisible(false);
    }
  }

  public void windowActivated(WindowEvent e) {
    return;
  }

  public void windowDeactivated(WindowEvent e) {
    return;
  }

  public void windowIconified(WindowEvent e) {
    setVisible(false);
  }

  public void windowDeiconified(WindowEvent e) {
    return;
  }

  public void windowClosing(WindowEvent e) {
    setVisible(false);
  }

  public void windowClosed(WindowEvent e) {
    return;
  }


  //*******************************************************
  // The following method implements an ActionListener for
  // this class.  It is used to listen for events occurring
  // on the buttons in this layout.  
  // 
  public void actionPerformed(ActionEvent e) {

    Button theSource = (Button) e.getSource();

    if (theSource.getLabel().equals("Login")) {
      // handle login

      if (hash.containsKey(name.getText())) {

        String password = (String) hash.get(name.getText());
        String salt = name.getText().substring(0,2);
        
        if (password.equals(jcrypt.crypt(salt,psw.getText()))) {
          // Login successful
          valid = true;
          setVisible(false);
        }
        else {
          MsgDialog msg = new MsgDialog(this, "Error", "You entered an invalid password. Please try again.");
          if (++attempt < MAX_ATTEMPTS) {
            psw.requestFocus();
          }
          else {
            setVisible(false);
          }
        }
  
      }
      else {
        MsgDialog msg = new MsgDialog(this, "Error", "You entered an invalid username. Please try again.");
        if (++attempt < MAX_ATTEMPTS) {
          name.requestFocus();
        }
        else {
          setVisible(false);
        }
      }

    } else if (theSource.getLabel().equals("Cancel")) {
      // handle cancel
      setVisible(false);
    }
  }


  //*******************************************************
  // This method is used to load the list of user names
  // and passwords for verifying a valid login.
  // 
  public boolean hasUsers() {

    try {
//      System.out.println("Password file: "+ pswfile);
      BufferedReader in = new BufferedReader(new InputStreamReader(pswfile.openStream()));

      hash = new Hashtable(13);

      String inputLine;

      while ((inputLine = in.readLine()) != null) {
        int i = inputLine.indexOf(' ');
        String username = inputLine.substring(0,i);
        i = inputLine.lastIndexOf(' ');
        String password = inputLine.substring(i+1);

        hash.put(username,password);
//        System.out.println("username="+username+"\tpassword="+password);
      }

      in.close();
    }
    catch (Exception e) { 
      System.out.println(e); 
      return false; 
    }

    return true;

  } // hasUsers


  //*******************************************************
  // This method is called by the applet to determine if
  // the login was valid.
  // 
  public boolean isValid() {

    return valid;

  } // isValid

 
} // PswFrame
