import java.applet.Applet;
import java.net.URL;
import java.net.MalformedURLException;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.util.Vector;
import java.util.Hashtable;
//import java.util.Date;
//import java.text.SimpleDateFormat;


/** Password applet, written by Dan Kiser, 1999
 *  <p>
 *  This applet is used to provide a way to password
 *  protect web pages.  This entire application resides
 *  on the client machine.
 *
 *  After a user enters a valid username and password,
 *  the appet manages the retrieval of all protected
 *  web pages.  It also provides buttons for navigation.
 * 
 *  A page is never cached and cannot be book marked.
 *  If the use_base parameter is set to false, a base
 *  tag will not be inserted into the document.  By
 *  default, JavaScript will still insert a base tag, which
 *  is the base URL of the page containing this applet.
 *  If no base tag is specified, all relative URLs become
 *  relative to this default base tag.
 *  <p>
 *  The applet accepts the following parameter values: 
 *  <ul>
 *  <li>param name=start_url value="url"     <br>
 *      where url is the encoded starting url
 *  <li>param name=bgcolor value="RGB"       <br>
 *      where RGB is a hex value of 000000 thru ffffff.
 *  <li>param name=home_url value="url"      <br>
 *      where url is the home page url
 *  <li>param name=error_url value="url"     <br>
 *      where url is the error page url
 *  <li>param name=psw_url value="url"       <br>
 *      where url is the password file url
 *  <li>param name=use_base value="flag"     <br>
 *      where flag is either true or false
 *  </ul>
 *
 */
public class password extends Applet implements Runnable {

  // Constants

  protected final int FWD = 1;   // Move forward in history list
  protected final int BWD = 2;   // Move backwrd in history list
  protected final int GET = 3;   // Get current URL in history list
  protected final int ADD = 4;   // Add URL to history list
  protected final int MAX = 50;  // Max size of history list

  // Variables

  private String startURL=null;  // Encoded starting URL

  private String name;           // Username string

  private String password;       // Password string

  private boolean cancel;        // Cancel flag

  private NavPanel navpan;       // Navigation panel

  private URL homeURL=null;      // Home page URL

  private URL errorURL=null;     // Error page URL

  private URL pswURL=null;       // Password file URL

  private boolean useBase=true;  // Use base tag flag

  private Vector keys;           // List of link keys

  private cipher c3 = new cipher3();      // Cipher3 object
 
  private PswFrame pswWin;       // Password entry window

  private Thread pswMon;         // Thread to monitor password entry window

  private Vector list = new Vector(10);   // History list

  private int curr=-1;           // Current page index

  private boolean load=false;    // Load page flag


  //*******************************************************
  // This method initializes the applet.  It creates the
  // navigation buttons and a Listener class for them.
  //
  public void init() {

//    System.out.println("Init applet...");

    String attr;

    // Get starting URL
    if (startURL == null) {
      attr = getParameter("start_url");
      startURL = (attr == null) ? new String() : attr;
    }

    // Set background color
    attr = getParameter("bgcolor");
    int bgcolor;
    try {
      bgcolor = (attr == null) ? Color.white.getRGB() : (Integer.parseInt(attr,16));
    }
    catch (Exception e) { bgcolor = Color.white.getRGB(); }
    setBackground(new Color(bgcolor));

    // Get home page URL
    attr = getParameter("home_url");
    if (attr != null) {
      try {
        // Relative URLs don't have colons.
        if (attr.indexOf(":") == -1) {
          homeURL = new URL(this.getDocumentBase(), attr);
        }
        else {
          homeURL = new URL(attr);
        }
      }
      catch (Exception e) { System.err.println(e); }
    }

    if (homeURL == null) {
      try {
        // Default to index page in doucment base directory
        homeURL = new URL(this.getDocumentBase(),"./"); 
      }
      catch (Exception e) { System.err.println(e); }
    }      

    // Get error page URL
    attr = getParameter("error_url");
    if (attr != null) {
      try {
        // Relative URLs don't have colons.
        if (attr.indexOf(":") == -1) {
          errorURL = new URL(this.getDocumentBase(), attr);
        }
        else {
          errorURL = new URL(attr);
        }
      }
      catch (Exception e) { System.err.println(e); }
    }

    if (errorURL == null) {
      try {
        // Default to error.htm in document base directory
        errorURL = new URL(this.getDocumentBase(),"./error.htm"); 
      }
      catch (Exception e) { System.err.println(e); }
    }      

    // Get password file URL
    if (pswURL == null) {
      attr = getParameter("psw_url");
      if (attr != null) {
        try {
          // Relative URLs don't have colons.
          if (attr.indexOf(":") == -1) {
            pswURL = new URL(this.getDocumentBase(), attr);
          }
          else {
            pswURL = new URL(attr);
          }
        }
        catch (Exception e) { System.err.println(e); }
      }
    }

    if (pswURL == null) {
      try {
        // Default to users.txt in document base directory
        pswURL = new URL(this.getDocumentBase(),"./users.txt"); 
      }
      catch (Exception e) { System.err.println(e); }
    }      

    // Get base tag flag
    attr = getParameter("use_base");
    if (attr != null) {
      useBase = (attr.equalsIgnoreCase("false")) ? false : true;
    }

    // Set font
    setFont(new Font("SansSerif", Font.PLAIN, 14));

    // Create NavPanel
    navpan = new NavPanel(this);
    navpan.setVisible(false);
    add(navpan);

  } // init


  public void start() {

//    System.out.println("Starting applet...");

    if (pswMon == null) {

      pswWin = new PswFrame(this, pswURL);
      pswMon = new Thread(this);
      pswMon.start();
    }

  } // start


  public void run() {

//    System.out.println("Starting monitor thread...");

    int i = 0;

    // Timeout after one minute if not logged in.
    while (pswWin.isShowing() && i < 120) {
      try {
        pswMon.sleep(500);
        i++;
      }
      catch (Exception e) { 
        System.out.println(e); 
      }
    }

    if (pswWin.isValid()) {
      pswWin.dispose();
      navpan.setVisible(true);
      goStart();
    }
    else {
      pswWin.dispose();
      redirect(errorURL, "_top");
    }

  } // run


  public void stop() {
    pswMon = null;
  } // stop


  //*******************************************************
  // This method can be called by a wrapper program to
  // set the starting URL so that the encoded value is
  // not revealed in the HTML source file.
  //
  public void setStartURL(String start_url) {

    if (start_url != "") startURL = start_url;

  } // setStartURL


  //*******************************************************
  // This method can be called by a wrapper program to
  // set the password file URL so that its name and 
  // location are not revealed in the HTML source file.
  //
  public void setPswURL(String psw_url) {

    if (psw_url != "") {

      try {
        // Relative URLs don't have colons.
        if (psw_url.indexOf(":") == -1) {
          pswURL = new URL(this.getDocumentBase(), psw_url);
        }
        else {
          pswURL = new URL(psw_url);
        }
      }
      catch (Exception e) { System.err.println(e); }

    }

  } // setPwsURL


  //*******************************************************
  // This method is used by JavaScript to retrieve the
  // content of an URL when the user clicks on a navigation
  // button.
  //
  public synchronized String getURL() {

    String content = new String();

    if (load) {
      URL theURL = (URL)list.elementAt(curr);
//      System.out.println("Get URL=" + theURL);
      content = getContent(theURL);
    }

    load = false;

    return content;

  } // getURL


  //*******************************************************
  // This method is used to manage an URL history list.  
  // The list pointer is adjusted and the list navigation 
  // buttons are either enabled or disabled. 
  // 
  public synchronized void setList(int action, URL theURL) {

//    System.out.println("Action="+action);

    // Load prev page
    if (action == BWD) {

      if (curr > 0) {
        curr--;
        load = true;
      }

    }

    // Load next page
    else if (action == FWD) {

      if (curr < list.size()-1) {
        curr++;
        load = true;
      }

    } 

    // Reload current page
    else if (action == GET) {
      load = true;
    }

    // Add page to list
    else if (action == ADD) {

      if (curr == list.size()-1) {

        if (list.size() < MAX) {
          list.addElement(theURL);
          curr++;
        }
        else {
          list.removeElementAt(0);
          list.addElement(theURL);
        }

      } 
      else {
        list.insertElementAt(theURL,curr+1);
        curr++;

        for(int i=list.size()-1; i > curr; i--) {
          list.removeElementAt(i);
        }

      }

    }

    // Set prev and next buttons
    if (curr > 0) {
      navpan.setEnabled("Back",true);
    }
    else {
      navpan.setEnabled("Back",false);
    }

    if (curr < list.size()-1) {
      navpan.setEnabled("Next",true);
    }
    else {
      navpan.setEnabled("Next",false);
    }

  } // setList


  //*******************************************************
  // This method is used to load the start page.  
  // 
  private void goStart() {

    URL theURL;

    System.out.println("Loading start page...");

    int len = startURL.charAt(0) - 100;

    String keyStr = startURL.substring(1,len+1);

    String urlStr = startURL.substring(len+1);

//    System.out.println("URL: "+urlStr);
//    System.out.println("Key: "+keyStr+" Len="+len);

    // Decode string with key
    urlStr = c3.decode(urlStr, keyStr);

    try {
      // Relative URLs don't have colons.
      if (urlStr.indexOf(":") == -1) {
        theURL = new URL(this.getDocumentBase(), urlStr);
      }
      else {
        theURL = new URL(urlStr);
      }

      setList(ADD, theURL);  // Save URL on history list
      setList(GET, null);    // Force reload of start page

    }
    catch (Exception e) { 
      System.err.println(e);
      redirect(errorURL, "_top");
    }


  } // goStart


  //*******************************************************
  // This method is called when a hyperlink to a secret
  // page is clicked.  The key for the link must be
  // retrieved before the page can be loaded.
  //
  public String fetchURL(String theURL) {

    int index = Integer.valueOf(theURL.substring(0,2)).intValue();

    String key = (String)keys.elementAt(index);

    // Remove index value from URL
    String newURL = theURL.substring(2);

    return ( loadPage(newURL, key) );

  } // fetchURL


  //*******************************************************
  // This method is used to load a given URL.  Input
  // includes an encoded URL and a decode key.  The URL
  // can be relative to the directory that contains the
  // page displaying this applet, or it can be absolute.
  // 
  private String loadPage(String theURL, String key) {

    String content = new String();

    URL newURL;

    // Decode string with key
    theURL = c3.decode(theURL, key);

    try {
      // Relative URLs don't have colons.
      if (theURL.indexOf(":") == -1) {
        newURL = new URL(this.getDocumentBase(), theURL);
      }
      else {
        newURL = new URL(theURL);
      }

//      System.out.println("URL=" + newURL);
      setList(ADD, newURL);  // Save URL on history list
      content = getContent(newURL);
    }
    catch (Exception e) { 
      System.err.println(e); 
      content = content + "<hr><h3>Invalid URL</h3>";
    }

    return content;

  } // loadPage


  //*******************************************************
  // This method is used to load an URL by allowing
  // JavaScript to pass in the requested URL.
  // 
  private String getContent(URL theURL) {

    StringBuffer content = new StringBuffer();

    char thisChar;
    String theTag;

    navpan.setEnabled("Reload",false);

    try {
      DataInputStream theHTML = new DataInputStream(theURL.openStream());

      if (useBase) {
        int i = theURL.toString().lastIndexOf('/');

        String base = theURL.toString().substring(0,i+1);
//        System.out.println("Base=" + base);

        content.append("<BASE HREF=\"" + base + "\">\n");
      }

      // Create a new vector of keys
      keys = new Vector(10);

      while (true) {
        thisChar = (char) theHTML.readByte();
        if (thisChar == '<') {
          theTag = readTag(theHTML);
          theTag = checkTag(theTag);
          content.append(theTag);
        }
        else {
          content.append(thisChar);
        }

      } // while 

    }
    catch (EOFException e) {  
      // This page is done
      System.out.println("Done loading page "+curr+": "+content.length()+" bytes");

      // Add HTTP Headers

//*** Superfluous.  Example only.
//      SimpleDateFormat formatter
//          = new SimpleDateFormat ("EEE, dd MMM yyyy hh:mm:ss z");
//      String dateString = formatter.format(new Date());
//      System.out.println("Date: "+dateString);
//
//      content.insert(0,"HTTP/1.1 200 OK\n" +
//                       "Server: Netscape-Enterprise/3.5.1G\n" +
//                       "Date: " + dateString + "\n" +
//                       "Content-type: text/html\n" +
//                       "Last-modified: " + dateString + "\n" +
//                       "Content-length: " + content.length() + "\n" +
//                       "Accept-ranges: bytes\n" +
//                       "Connection: close\n\n");
//***
    }   
    catch (Exception e) {
      System.err.println(e); 
      content.append("<hr><h3>Error Opening Input Stream</h3>");
    }

    navpan.setEnabled("Reload",true);

    return content.toString();

  } // getContent
  

  //*******************************************************
  // The readTag method is called when a < is encountered
  // in the input stream.  This method is responsible
  // for reading the remainder of the tag.
  // Note that when this method has been called the <
  // has been read from the input stream but has not yet 
  // been sent to the output stream. 
  //
  // This method has trouble (as do most web browsers) 
  // if it encounters a raw < sign in the Stream. Technically
  // raw < signs should be encoded as &lt; in the original HTML.
  //
  private static String readTag(DataInputStream is) {
  
    StringBuffer theTag = new StringBuffer("<");
    char theChar = '<';
  
    try {
       while (theChar != '>') {
         theChar = (char) is.readByte();
         theTag.append(theChar);
       } 
     }
     catch (EOFException e) {
       // Done with the Stream
     }
     catch (Exception e) {
        System.err.println(e);
     }     

     return theTag.toString();
  
  } // readTag


  //*******************************************************
  // The checkTag method takes a complete tag as a string
  // and, if it's a link for a secret page, converts the
  // link to cipher text.  The converted tag is returned.
  //
  private String checkTag(String tag) {
  
    // temporary position variables
    int p1, p2, p3;

    // Remove newlines from tag.
    StringBuffer sb = new StringBuffer(tag);
  
    for (int i=0; i < sb.length(); i++) {
        if (sb.charAt(i) == '\r' || sb.charAt(i) == '\n') {
            sb.setCharAt(i,' ');
        }
    }
    String tag2 = sb.toString(); 

    try {
      // HTML tags are cases insensitive so converting
      // it to upper case makes the problem slightly easier
      String s1 = tag2.toUpperCase();

      // Anchor tag?
      if (s1.startsWith("<A HREF")) {
//        System.out.println("Link="+s1);
        p1 = s1.indexOf("PARENT.NAVPANE.FETCH(");
      }
      // Title tag?
      else if (s1.startsWith("<TITLE>")) {
        tag = "<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\">\n" + tag2; 
        return tag;
      }
      else { // this is not a link based tag
        return tag;      
      }

      // Return if link does not contain 
      if (p1 == -1) return tag;

      p2 = p1 + 21;

      while (Character.isWhitespace(s1.charAt(p2))) {
        p2++;
      } 

      if (s1.charAt(p2) == '\'') p2++;

      // p2 now points to the beginning of the URL
      // The URL is read until a closing ' or ) or whitespace is seen
      p3 = p2+1;
      while (!Character.isWhitespace(s1.charAt(p3)) && 
        s1.charAt(p3) != '\'' && s1.charAt(p3) != ')') {
        p3++;
      }

      // The URL is the text between p2 and p3
      String link = tag.substring(p2, p3);

      // Get key and save
      String key = c3.getKey(link);
      keys.addElement(key);
//      System.out.println("Decoded key="+key);

      // Encode link with key
      link = c3.encode(link, key);
      String index = Integer.toString(keys.size()-1);
      link = (index.length() < 2) ? "0" + index + link : index + link;

      // Insert converted URL into tag
      tag = tag2.substring(0,p2) + link + tag2.substring(p3,tag2.length());

    }  // end try
    catch (StringIndexOutOfBoundsException e) {
      // Most of the time a StringIndexOutOfBoundsException 
      // here means the tag was not standard conforming so 
      // the algorithm for finding the URL crapped out.
      // If that's the case, the original tag is returned.
    }
    catch (Exception e) {
      System.err.println(e);
    }
    
    return tag;
  
  } // checkTag


  //*******************************************************
  // This method is used to redirect the browser to the
  // Home page.
  //
  public void home() {

    redirect(homeURL, "_top");

  } // home


  //*******************************************************
  // This method is used to redirect the browser to the
  // specified URL and display it in the destination
  // window.
  //
  private void redirect(URL theURL, String dest) {

    try {
      InputStream in = theURL.openStream();
      int input = in.read();
      in.close();
//      System.out.println("Redirect URL=" + theURL);
      getAppletContext().showDocument(theURL, dest);
    }
    catch (Exception e) { System.out.println(e); }

  } // redirect

} // password 
