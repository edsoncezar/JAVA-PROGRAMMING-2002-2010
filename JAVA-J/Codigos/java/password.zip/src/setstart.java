import java.net.URL;
import java.net.MalformedURLException;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.applet.Applet;


/** Set start URL applet, written by Dan Kiser, 1999
 *  <p>
 *  This applet is used to encode the starting URL
 *  to be loaded by the loader applet.  The starting
 *  URL is the entry point to the protected documents.
 *
 */
public class setstart extends Applet implements ActionListener, KeyListener {

  protected TextField intext;
  protected TextField outtext;
  protected Button encode;

  private cipher c3 = new cipher3();     // Cipher3 object

  public void init()
  {
    String attr;

    // Set background color
    setBackground(new Color(Color.white.getRGB()));

    // Set font
    setFont(new Font("SansSerif", Font.PLAIN, 14));

    // Set layout
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    setLayout(gridbag);    

    // Input label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 0, 1, 1, 5, 40);
    Label label1 = new Label("INPUT:", Label.LEFT);
    gridbag.setConstraints(label1, constraints);
    add(label1);

    // Input text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 0, 1, 1, 95, 0);
    intext = new TextField();
    gridbag.setConstraints(intext, constraints);
    intext.addKeyListener(this);
    add(intext);

    // Password label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 1, 1, 1, 0, 40);
    Label label2 = new Label("OUTPUT:", Label.LEFT);
    gridbag.setConstraints(label2, constraints);
    add(label2);

    // Output text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 1, 1, 1, 0, 0);
    outtext = new TextField();
    gridbag.setConstraints(outtext, constraints);
    outtext.addKeyListener(this);
    add(outtext);

    // Button Panel
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.CENTER;
    buildConstraints(constraints, 0, 2, 2, 1, 0, 20);
    Panel panel = new Panel();

    // Set panel layout
    panel.setLayout(new GridLayout(1, 2, 20, 2));
    gridbag.setConstraints(panel, constraints);
    add(panel);

    // Encode button
    encode = new Button("Encode");
    encode.addActionListener(this);
    encode.addKeyListener(this);
    panel.add(encode);

    // Clear button
    Button clear = new Button("Clear");
    clear.addActionListener(this);
    clear.addKeyListener(this);
    panel.add(clear);

    setSize(550,125);

  } // init


  public void start() {

    System.out.println("Starting setstart applet...");

    intext.setText("");
    intext.requestFocus();
    outtext.setText("");

  } // start


  void buildConstraints(GridBagConstraints gbc, int gx, int gy, int gw, int gh, int wx, int wy)
  {
    gbc.gridx = gx;
    gbc.gridy = gy;
    gbc.gridwidth = gw;
    gbc.gridheight = gh;
    gbc.weightx = wx;
    gbc.weighty = wy;
    gbc.ipadx = 0;
    gbc.ipady = 0;

  } // buildConstraints


  public Insets getInsets() {
    return new Insets(5, 5, 5, 5);
  }


  //*******************************************************
  // The following are used to listen for key press events
  // in the text fields.  
  // 
  public void keyTyped(KeyEvent e) {
    return;  
  }

  public void keyPressed(KeyEvent e) {
    return;
  }

  public void keyReleased(KeyEvent e) {

    if (e.getSource() instanceof Button) {

      Button theSource = (Button) e.getSource();

//      System.out.println("Command="+theSource.getActionCommand());

      // Dispatch a new action event so that the ENTER key
      // behaves like a mouse click.
      if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        ActionEvent ae = new ActionEvent(e.getSource(),ActionEvent.ACTION_PERFORMED,theSource.getActionCommand());
        theSource.dispatchEvent(ae);
      }
    }
    else {

      TextField theSource = (TextField) e.getSource();

//      System.out.println("Key Press="+e.getKeyCode());

      if (e.getKeyCode() == KeyEvent.VK_ENTER)
        theSource.transferFocus();
    }
  }


  //*******************************************************
  // The following method is used to listen for events 
  // occurring on the buttons in this layout.  
  // 
  public void actionPerformed(ActionEvent e) {

    Button theSource = (Button) e.getSource();
    Frame theFrame = MsgDialog.getFrame(this);

    if (theSource.getLabel().equals("Encode")) {
      // handle encode

      if (intext.getText().length() > 4) {

        // Get random length key
        String key = c3.getKey(intext.getText());

        // Encode link with key
        String link = c3.encode(intext.getText(), key);
        Character len = new Character((char)(key.length()+100));
        link = len + key + link;
        outtext.setText(link);
        outtext.requestFocus();
      }
      else {
        MsgDialog msg = new MsgDialog(theFrame, "Error", "Input URL must contain at least 5 characters. Please try again.");
        intext.requestFocus();
      }

    } else if (theSource.getLabel().equals("Clear")) {
      // handle clear
      intext.setText("");
      intext.requestFocus();
      outtext.setText("");
    }
  }

} // setstart
