/** Cipher interface, written by Dan Kiser, 1999
 *  <p>
 *  This interface is used to aid a developer in
 *  implementing a cipher routine to encode and
 *  decode secret URLs.
 *
 */
public interface cipher {

  // Method to get a key to encode/decode a string
  public String getKey(String inText);

  // Method to encode a string
  public String encode(String inText, String key);

  // Method to decode a string
  public String decode(String inText, String key);

}
