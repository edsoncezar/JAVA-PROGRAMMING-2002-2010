import java.awt.*;
import java.awt.event.*;
import java.lang.*;

/** Navigation panel, written by Dan Kiser, 1999
 *  <p>
 *  This class is used to define a navigation panel.
 *  The panel contains buttons used to navigate
 *  through the protected files that have been 
 *  previously loaded.  The following buttons are
 *  displayed by the panel:
 *    Home
 *    Back
 *    Next
 *    Reload
 *
 */
public class NavPanel extends Panel implements ActionListener {

  // Constants

  protected final int FWD = 1;   // Move forward in history list
  protected final int BWD = 2;   // Move backwrd in history list
  protected final int GET = 3;   // Get current URL in history list
  protected final int ADD = 4;   // Add URL to history list

  // Variables

  private Button bhome;          // Home page button
  private Button bnext;          // Next page button
  private Button bprev;          // Prev page button
  private Button bload;          // Reload page button

  private password app;          // Applet reference

  public NavPanel(password parent) {

    app = parent;

    // Set layout
    setLayout(new FlowLayout(FlowLayout.CENTER,20,10));

    // Home page
    bhome = new Button("Home");
    bhome.addActionListener(this);
    add(bhome);

    // Previous page
    bprev = new Button("Back");
    bprev.addActionListener(this);
    bprev.setEnabled(false);
    add(bprev);

    // Next page
    bnext = new Button("Next");
    bnext.addActionListener(this);
    bnext.setEnabled(false);
    add(bnext);

    // Reload page
    bload = new Button("Reload");
    bload.addActionListener(this);
    bload.setEnabled(false);
    add(bload);

    // Set size of panel
    setSize(300,40);

  } // NavPanel


  public void setEnabled(String name, boolean flag) {

    if (name.equals("Home")) {
      bprev.setEnabled(flag);
    } else if (name.equals("Back")) {
      bprev.setEnabled(flag);
    } else if (name.equals("Next")) {
      bnext.setEnabled(flag);
    } else if (name.equals("Reload")) {
      bload.setEnabled(flag);
    }

  } // setEnabled


  public void actionPerformed(ActionEvent e) {
    Button theSource = (Button) e.getSource();

    if (theSource.getLabel().equals("Home")) {
      // Handle home page
      app.home();

    } else if (theSource.getLabel().equals("Back")) {
      // Handle previous page
      app.setList(BWD, null);

    } else if (theSource.getLabel().equals("Next")) {
      // Handle next page
      app.setList(FWD, null);

    } else if (theSource.getLabel().equals("Reload")) {
      // Handle reload page
      app.setList(GET, null);
    }
      
  } // actionPerformed

} // NavPanel
