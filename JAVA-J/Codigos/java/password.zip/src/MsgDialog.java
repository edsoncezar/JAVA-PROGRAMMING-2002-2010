import java.awt.*;
import java.awt.event.*;

/** MsgDialog class, written by Dan Kiser, 1999
 *  <p>
 *  This class is used to display a pop-up dialog message
 *  window.  The constructor takes as its arguments a
 *  frame, a title, and a message string.
 *
 */
public class MsgDialog extends Dialog implements ActionListener, WindowListener {

    public MsgDialog(Frame parent, String title, String message) {

        super(parent,title,true);
        setLayout(new BorderLayout(10,10));
        setBackground(Color.white);
        setFont(new Font("Helvetica", Font.PLAIN, 14));

        TextArea msg = new TextArea(message,3,30,TextArea.SCROLLBARS_VERTICAL_ONLY);
        add("Center", msg);

        Button ok = new Button("OK");
        ok.addActionListener(this);
        add("South", ok);

        addWindowListener(this);

        setSize(300,150);

        // Position window on screen
        Dimension d = getToolkit().getScreenSize();

        int x = Math.round( (d.width - 300) / 2 );
        int y = Math.round( (d.height - 150) / 2 );

        setLocation( new Point(x,y) );

        setVisible(true);

    } // MsgDialog

    public void actionPerformed(ActionEvent e) {
      if (e.getSource() instanceof Button) {
        String label = ((Button)e.getSource()).getLabel();
        if (label == "OK") {
           setVisible(false);
           dispose();
        }
      }
    }

    public void windowOpened(WindowEvent e) {
      return;
    }

    public void windowActivated(WindowEvent e) {
      return;
    }

    public void windowDeactivated(WindowEvent e) {
      return;
    }

    public void windowIconified(WindowEvent e) {
      return;
    }

    public void windowDeiconified(WindowEvent e) {
      return;
    }

    public void windowClosing(WindowEvent e) {
      setVisible(false);
      dispose();
    }

    public void windowClosed(WindowEvent e) {
      return;
    }

    public static Frame getFrame(Component com) {

        // Get the frame object for this component.
        Object anchorpoint = com.getParent();
        while (!(anchorpoint instanceof Frame))
          anchorpoint = ((Component)anchorpoint).getParent();

        return (Frame)anchorpoint;

    } // getFrame
  
} // MsgDialog
