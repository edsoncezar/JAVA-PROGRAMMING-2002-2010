import java.net.URL;
import java.net.MalformedURLException;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.applet.Applet;


/** Set Password applet, written by Dan Kiser, 1999
 *  <p>
 *  This applet is used to generate encrypted
 *  password vaules.
 *
 *  <p>
 *  The applet accepts the following parameter values: 
 *  (all parameters are optional)
 *  <ul>
 *  <li>param name=load_db value="flag"     <br>
 *      where flag is either "true" or "false".
 *  </ul>
 *
 */
public class setpass extends Applet implements ActionListener, KeyListener {

  protected TextField name;
  protected TextField psw;
  protected Button list;
  protected Hashtable hash = null;
  protected URL pswURL=null;


  public void init()
  {
    String attr;

    // Get password file URL
    attr = getParameter("psw_url");
    if (attr != null) {
      try {
        // Relative URLs don't have colons.
        if (attr.indexOf(":") == -1) {
          pswURL = new URL(this.getDocumentBase(), attr);
        }
        else {
          pswURL = new URL(attr);
        }
      }
      catch (Exception e) { System.err.println(e); }
    }

    // Set background color
    setBackground(new Color(Color.white.getRGB()));

    // Set font
    setFont(new Font("SansSerif", Font.PLAIN, 14));

    // Set layout
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();
    setLayout(gridbag);    

    // Name label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 0, 1, 1, 10, 40);
    Label label1 = new Label("Username:", Label.LEFT);
    gridbag.setConstraints(label1, constraints);
    add(label1);

    // Name text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 0, 1, 1, 90, 0);
    name = new TextField();
    gridbag.setConstraints(name, constraints);
    name.addKeyListener(this);
    add(name);

    // Password label
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.EAST;
    buildConstraints(constraints, 0, 1, 1, 1, 0, 40);
    Label label2 = new Label("Password:", Label.LEFT);
    gridbag.setConstraints(label2, constraints);
    add(label2);

    // Password text field
    constraints.fill = GridBagConstraints.HORIZONTAL;
    buildConstraints(constraints, 1, 1, 1, 1, 0, 0);
    psw = new TextField();
    psw.setEchoChar('*');
    gridbag.setConstraints(psw, constraints);
    psw.addKeyListener(this);
    add(psw);

    // Button Panel
    constraints.fill = GridBagConstraints.NONE;
    constraints.anchor = GridBagConstraints.CENTER;
    buildConstraints(constraints, 0, 2, 2, 1, 0, 20);
    Panel panel = new Panel();

    // Set panel layout
    panel.setLayout(new GridLayout(1, 3, 20, 2));
    gridbag.setConstraints(panel, constraints);
    add(panel);

    // Login button
    Button login = new Button("Add");
    login.addActionListener(this);
    login.addKeyListener(this);
    panel.add(login);

    // List button
    list = new Button("List");
    list.addActionListener(this);
    list.addKeyListener(this);
    panel.add(list);

    // Clear button
    Button clear = new Button("Clear");
    clear.addActionListener(this);
    clear.addKeyListener(this);
    panel.add(clear);

    setSize(225,125);

  } // init


  public void start() {

    name.setText("");
    name.requestFocus();
    psw.setText("");

    hash = new Hashtable(13);

    if (pswURL != null) getUsers();

    if (!hash.isEmpty()) {
      list.setEnabled(true);
    }
    else {
      list.setEnabled(false);
    }

  } // start


  void buildConstraints(GridBagConstraints gbc, int gx, int gy, int gw, int gh, int wx, int wy)
  {
    gbc.gridx = gx;
    gbc.gridy = gy;
    gbc.gridwidth = gw;
    gbc.gridheight = gh;
    gbc.weightx = wx;
    gbc.weighty = wy;
    gbc.ipadx = 0;
    gbc.ipady = 0;

  } // buildConstraints


  public Insets getInsets() {
    return new Insets(5, 5, 5, 5);
  }


  //*******************************************************
  // The following methods are used to listen for key press 
  // events in the text fields.  It will allow ony letters
  // and digits to be entered.
  // 
  public void keyTyped(KeyEvent e) {
    return;  
  }

  public void keyPressed(KeyEvent e) {

//    System.out.println("Key Press="+e.getKeyCode());

    if (!Character.isLetterOrDigit(e.getKeyChar()) && 
        e.getKeyCode() != KeyEvent.VK_ENTER  &&
        e.getKeyCode() != KeyEvent.VK_SHIFT  &&
        e.getKeyCode() != KeyEvent.VK_LEFT   &&
        e.getKeyCode() != KeyEvent.VK_RIGHT  &&
        e.getKeyCode() != KeyEvent.VK_DELETE &&
        e.getKeyCode() != KeyEvent.VK_TAB    &&
        e.getKeyCode() != KeyEvent.VK_BACK_SPACE) {
        e.consume();
    }
  }

  public void keyReleased(KeyEvent e) {

    if (e.getSource() instanceof Button) {

      Button theSource = (Button) e.getSource();

//      System.out.println("Command="+theSource.getActionCommand());

      // Dispatch a new action event so that the ENTER key
      // behaves like a mouse click.
      if (e.getKeyCode() == KeyEvent.VK_ENTER) {
        ActionEvent ae = new ActionEvent(e.getSource(),ActionEvent.ACTION_PERFORMED,theSource.getActionCommand());
        theSource.dispatchEvent(ae);
      }

    }
    else {

      TextField theSource = (TextField) e.getSource();

//      System.out.println("Key Press="+e.getKeyCode());

      if (e.getKeyCode() == KeyEvent.VK_ENTER)
        theSource.transferFocus();
    }

  }


  //*******************************************************
  // The following methods are used to listen for events 
  // occurring on the buttons in this layout.  
  // 

  // Validate a username or a password.
  boolean isValid(String text, int minLen, int minDigits) {

    StringBuffer sb = new StringBuffer(text);

    int digits=0;
    int i=0;

    // Count letters and digits
    for(; i < sb.length(); i++) {
      if (Character.isDigit(sb.charAt(i))) {
        digits++;
      }
    }

    return ( (i >= minLen && digits >= minDigits) ? true : false );

  } // isValid


  public void actionPerformed(java.awt.event.ActionEvent e) {

    Button theSource = (Button) e.getSource();

    Frame theFrame = MsgDialog.getFrame(this);

//    System.out.println("Command="+e.getActionCommand());

    if (theSource.getLabel().equals("Add")) {
      // handle add user

      if (isValid(name.getText(),3,0)) {

        if (!hash.containsKey(name.getText())) {

          if (isValid(psw.getText(),6,1)) {

            String username = name.getText();

            String salt = name.getText().substring(0,2);

            String password = jcrypt.crypt(salt,psw.getText());

            hash.put(username,password);
        
            name.setText("");
            name.requestFocus();
            psw.setText("");
            list.setEnabled(true);
          }
          else {
            MsgDialog msg = new MsgDialog(theFrame, "Error", "Passwords must contain at least 5 letters plus 1 digit. Please try again.");
            psw.requestFocus();
          }
        }
        else {
          MsgDialog msg = new MsgDialog(theFrame, "Error", "Duplicate user name is already in the database. Please try again.");
          name.requestFocus();
        }
      }
      else {
        MsgDialog msg = new MsgDialog(theFrame, "Error", "User names must contain at least 3 letters/digits. Please try again.");
        name.requestFocus();
      }

    } else if (theSource.getLabel().equals("List")) {
      // handle list

      String list = new String();

      for (Enumeration keys = hash.keys(); keys.hasMoreElements() ;) {
        String username = (String)keys.nextElement();
        String password = (String)hash.get(username);
        list = list + username + "  " + password + "\n";
      }

      MsgDialog msg = new MsgDialog(theFrame, "List", list);

    } else if (theSource.getLabel().equals("Clear")) {
      // handle clear
      name.setText("");
      name.requestFocus();
      psw.setText("");
    }
  }


  //*******************************************************
  // This method is used to load the list of valid user
  // names and passwords into a hash table.
  // 
  void getUsers() {

    try {

//      System.out.println(users);
      BufferedReader in = new BufferedReader(new InputStreamReader(pswURL.openStream()));

      String inputLine;

      while ((inputLine = in.readLine()) != null) {
        int i = inputLine.indexOf(' ');
        String username = inputLine.substring(0,i);
        i = inputLine.lastIndexOf(' ');
        String password = inputLine.substring(i+1);

        hash.put(username,password);
//        System.out.println("username="+username+"\tpassword="+password);
      }

      in.close();
    }
    catch (Exception e) { System.out.println(e); }

  } // getUsers

 
} // setpass