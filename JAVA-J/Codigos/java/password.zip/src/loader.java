/** Wrapper class, written by Dan Kiser, 1999
 *  <p>
 *  This class is used to wrap the password class.
 *
 *  Use this wrapper if you don't want to have
 *  the encoded starting URL or the password file
 *  URL revealed to anyone who views the HTML source.
 *
 *  Place your encoded starting URL between
 *  the double quotes of the setStartURL method.
 *  For example:
 *    setStartURL("rdbxbvctuvt1uepbKxzvv");
 *
 *  Place your password file URL between
 *  the double quotes of the setPswURL method.
 *  For example:
 *    setStartURL("../users.txt");
 *
 *  After making changes to this file, recompile
 *  the class file using the following command:
 *    javac loader.java
 *
 */
public class loader extends password {


  public loader() {

    super();

    setStartURL("");

    setPswURL("");

  }


} // loader