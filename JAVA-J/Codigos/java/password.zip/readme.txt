############################################################################
# PASSWORD APPLET  v1.0 - written by Dan Kiser
# LAST UPDATED 9/7/1999
# 
# This applet is free for use "as is" by anyone in need of applying a
# password protection scheme on the Web.  
#
# The most secure password protection schemes involve configuring the Web 
# server to restrict access to a given directory and/or document.  Even if 
# a user happens to know the URL of the document (e.g. by bookmarking), 
# they cannot gain access to it unless they can enter a valid user name 
# and password.
#
# Trying to apply a password protection scheme that does not rely on a
# Web server is a little more challenging.  First, you must try to conceal
# the names of your documents so that users cannot bookmark them.  Second,
# you must be able to encrypt the passwords so that they cannot be
# determined by someone who gains access to the password file.  This applet
# solution handles both these conditions.  If you code your links correctly,
# you should be able to use this applet to password protect documents from
# all but the most sophisticated Internet hackers.
#
# The source code for all classes except the cipher3 class is inlcuded in 
# the ZIP file.  You are encouraged to devise your own cipher scheme to
# protect your URLs.  I've included a standard interface class that can be
# implemented by your cipher scheme.  You will want to make sure that your 
# scheme can encode a string that is HTML/JavaScript safe since the encoded 
# strings need to be inserted into the HTML.
# 
############################################################################

Setup Instructions:

1. Unzip the file "password.zip".

Unzip the contents of the password.zip file into a new directory.  
You should find the following files:

index.htm        - Frame document (start page)
login.htm        - Contains login message
loader.htm       - Contains password applet
error.htm        - Contains login error message
setstart.htm     - Used to encode starting page URL
setpass.htm      - Used to create password file
readme.txt       - This file
users.txt        - Default password file (demo only)
loader.js        - JavaScript for LiveConnect

loader.java      - Wrapper class for password applet
cipher.java      - Cipher scheme interface class
jcrypt.java      - Password encryption class
password.java    - Main applet class
PswFrame.java    - Password dialog window class
MsgDialog.java   - Message dialog window class
NavPanel.java    - Navigation panel
setstart.java    - Set starting URL applet
setpass.java     - Set password applet

loader.class      
cipher.class     
cipher3.class     
jcrypt.class     
password.class
PswFrame.class
MsgDialog.class
NavPanel.class
setstart.class
setpass.class
build            - Script to compile source files


*Note that when you unzip the files be sure the capital letters remain in
the file names.  Java will complain that it can't find the class if the 
name of it happens to change.


*Note that you may need to rename "index.htm" if the default start page 
on your Web server is different.  The start page is the page the server
loads by default if an explicit page name is not given.


2. Configuring the unzipped files and your secret files.

a. The simplest configuration used to protect a single directory is to 
place the unzipped files into the same Web directory that contains the 
documents to be protected.

This directory structure would look like the following:

public_html
    |
    +- private_dir
        |
        +- unzipped files
        +- secret files

b. A second, more complex, configuration involves placing the unzipped
files in one directory and the protected files in another.  
Note that image files should be placed in another directory outside the
private directory.

public_html
    |
    +- private_dir
        |
        +- secret files
    |
    +- password_dir
        |
        +- unzipped files
    |
    +- images_dir
        |
        +- images used in secret files

With this configuration, you are capable of concealing the directory
containing the secret files.  But to do this you'll need to set the
applet parameter "use_base" to a value of "false".

Edit the file "loader.htm" to set this parameter.  The default value is
"true", if not explicitly set.  This flag has the following effect:

1) If set to "true" (default), a base tag is created at the beginning of
the secret file reflecting the document's current directory.  This means
that all relative URLs inside the secret document will be relative to this
base URL.

For example, say your secret document has an URL of
http://www.xyz.com/private/doc.htm
then the base tag would be
<BASE HREF="http://www.xyz.com/private/">

2) If set to "false", a base tag is created at the beginning of the secret
document reflecting the base directory of the file "loader.htm".

For example, say that loader.htm has an URL of
http://www.xyz.com/password/loader.htm
then the base tag would be
<BASE HREF="http://www.xyz.com/password/">

Assuming all relative URLs in the secret document are relative to this 
base, this would mean that the name of the directory containing the secret 
files is not revealed.  In addition, all absolute URLs in the secret 
document should point to somewhere outside of the secret directory.

For example, say that the URL to the secret file is
http://www.xyz.com/private/doc.htm
and assume that this page contains a link to another secret file named
doc2.htm that is also in the secret directory. Also assume that the 
base tag in doc.htm is
<BASE HREF="http://www.xyz.com/password/">
In this case, if you use a relative link to doc2.htm, it must be set to 
<A HREF="../private/doc2.htm">...</A>
for it to correctly work with this base tag.

Of course, a base tag is used only to resolve relative links.  If you
use absolute links you do not have to be concerned about how the relative
links will be resolved.

I'd recommend using this configuration with preferably absolute links.
Remember to only place the files you want protected in your secret
directory.  This way, someone viewing the document source will not be
able to easily determine the name of this directory.


3. Creating links to your secret documents.

All links in your secret document that point to some other secret document
should be encoded as follows:

<A HREF=#n onClick="parent.navpane.fetch('url string');">link text</A>

Note the following about this link:

a) Use the # for the HREF link value.  This results in the base tag of the
document appearing in the status window.  Remember to set the "use_base"
parameter to "false" if you don't want to reveal the base URL of the
secret document.

b) The onclick JavaScript event is used to call the fetch function which
sends the link to the password applet for loading.  

c) The url string is the absolute or relative URL of the secret document.
This string must be enclosed in single quotes.  When the password
applet loads a secret document, it will automatically encode the url string
so that the name of the document cannot be discovered by someone viewing
the document's source.  When the link is clicked, the password applet 
decodes the url string before retrieving the document.

d) Important: The pages that you want to protect must come from the same
server as the password applet itself.  Java security will not allow access
to documents outside of this domain.


4. Encoding your starting URL.

The URL of the initial secret document that gets loaded after a user logs in 
must be encoded.  The encoded URL will prevent someone who views the 
document source for discovering the name and location of the initial secret
document.  After encoding this URL, you must edit the file "loader.htm" and 
modify the applet parameter "start_url" so that it contains your encoded 
starting url.

To encode your starting URL, load the file "setstart.htm" into your Web
browser and follow the instructions given on this page.  


5. URLs pointing to unprotected documents.

If you include a link inside a secret document that points to an unprotected
document somewhere outside of the secret directory, make sure to set the value 
of the target attribute to "_top" so that the document loads into the main 
browser window.

For example:
<A HREF="http://www.xyz.com/" target="_top">Home Page</A>


6. Create the password file.

A file containing a list of user names and passwords must be created.  To
complete this step, load the file "setpass.htm" into your Web browser and
follow the instructions given on this page.  By default, the applet will
attempt to read the file "users.txt" from the same directory that contains
the file "loader.htm".  The default file name and location of the password
file may be changed by setting the applet parameter "psw_url". 


7. Configure the password applet.

The password applet accepts the following parameter values which may be
modified by editing the file "loader.htm".

PARAMETER NAME    DESCRIPTION           DEFAULT VALUE    VALUES
bgcolor           background color      ffffff           000000-ffffff (hex)
home_url          used by home button   ./
psw_url           password file         ./users.txt
error_url         error page            ./error.htm
start_url         starting page
use_base          base tag flag         true             true or false


8. Edit the wrapper class "loader.java" to hide the starting URL.

This step is optional.  You can edit the file "loader.java" to set the
starting URL and the password file URL as opposed to setting these
values via applet parameters.  Doing so prevents these values from being 
revealed to anyone viewing the source.

Follow the instructions in the file "loader.java".  You must download
and install JDK 1.1 from JavaSoft to compile the Java source file.

The JDK 1.1 is available at: http://www.javasoft.com:80/products/jdk/1.1/