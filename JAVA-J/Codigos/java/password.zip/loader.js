<!--

// Fetch the document
function fetch(theURL) {

  if (document.loader != null) {

    var content = document.loader.fetchURL(theURL);

    parent.docpane.document.open();
    parent.docpane.document.writeln(content);
    parent.docpane.document.writeln("\n");
    parent.docpane.document.close();
    parent.docpane.document.close();
  }

}  // fetch


// Check to see if PREV, NEXT, or RELOAD button was pressed.
function checkLoad() {

  if (document.loader != null) {

    var content = document.loader.getURL();

    if (content != "") {
      parent.docpane.document.open();
      parent.docpane.document.writeln(content);
      parent.docpane.document.writeln("\n");
      parent.docpane.document.close();
      parent.docpane.document.close();
    }

  }
  setTimeout("checkLoad()",1000);

} // checkLoad

//-->
