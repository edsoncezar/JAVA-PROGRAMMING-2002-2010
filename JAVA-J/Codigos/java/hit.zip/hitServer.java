
/*
Guestbook by XdebugX
xdebugx@hotmail.com
http://xdebugx.deltaarc.net
*/

import java.net.*; import java.io.*; import java.util.*;

public class hitServer {
	private ServerSocket serverSocket;

	public static void main(String[] args) throws IOException {
    	new hitServer();
    }

	public hitServer() {

		try {
		    serverSocket = new ServerSocket(6592);
            System.out.println("Server Is Running ...");

            } catch (IOException e) {
			            System.out.println("Could not listen on port: .");
			            System.exit(-1);
			        }
			while (true) {
			try {
    	    	Socket socket = serverSocket.accept();
    	    	System.out.println("Connection from : " + socket);
        		new MyServerThread(socket).start();


		    }catch (IOException e) {}

		}


	    	}



}///gurest server