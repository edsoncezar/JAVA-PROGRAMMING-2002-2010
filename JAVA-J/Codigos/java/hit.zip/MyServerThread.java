/*
eGraffiti by XdebugX
xdebugx@hotmail.com
http://xdebugx.deltaarc.net
*/

import java.net.*;
import java.io.*;
import java.util.*;

public class MyServerThread extends Thread {
    private Socket socket;


    public MyServerThread(Socket socket) {
		this.socket = socket;


	}

    public void run() {
		try {
			DataInputStream in = new DataInputStream(socket.getInputStream());

		    String inputLine;
			while (true) {

	    		inputLine = in.readUTF();
	    		System.out.println (inputLine);


	    			int g,p,c,numChars,wCount;
					String addLine="";
					String temp;

					c=0;
					p=0;
					numChars=0;
					wCount=0;
					inputLine="";
					try {
					FileReader fr = new FileReader ("hits.dat");
					c=fr.read();
					while (c != -1) {
					inputLine = inputLine + (char) (c);

					numChars++;
					if (numChars>=1000) c=-1;
					c=fr.read();
					}
					fr.close();
					} catch (IOException ioe) {System.out.println ("io error for read images webpage");}


					temp = inputLine.substring (0,inputLine.indexOf("X"));
					p=Integer.parseInt (temp);
					p+=1;
					temp = "" + p;
					inputLine=temp+"X";


					try {
						FileWriter fw = new FileWriter ("hits.dat");

						for (p=0;p<inputLine.length();p++) {
							fw.write (inputLine.charAt(p));
						}

						fw.close ();
						System.out.println ("closed");

						} catch (IOException ioe) {System.out.println ("io error for write images webpage");}





			}
		} catch (IOException ie) {
	    	ie.printStackTrace();
	    }

}

}