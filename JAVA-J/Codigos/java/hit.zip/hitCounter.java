
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class hitCounter extends Applet implements Runnable  {

  Thread t;  //main thread

  Graphics grBuffer;  //main graphics object
  Image imgBuffer;

  int height,width;  //height and width of applet

  int paintDelay=0;

  int numHits=0;
  int ones=0,tens=0,hund=0,thou=0,tenthou=0,hunthou=0,mil=0;
  int rot=0,rot2,rot3,rot4,rot5,rot6,rot7;

  boolean flipped=false;

static int randomNumber (int low, int high) {
   		// returns a random number between low and high, inclusive
   		return (int)(java.lang.Math.random() * (high - low + 1) + low);
	} // randomNumber


public void init () {
height = 30;      //get height and width
width = 125;

imgBuffer = createImage (width, height); //make buffer image
grBuffer = imgBuffer.getGraphics ();    //associate buffer with buffer image
grBuffer.setFont (new Font ("Courier", Font.BOLD , 25));
sendData ();
newView ();
} //inint





public void paint (Graphics g) {
int p,t,a;

grBuffer.setColor(Color.black);
grBuffer.fillRect (0,0,width,height);
grBuffer.setColor (Color.white);
grBuffer.drawRect (0,0,width,height);
//( | | | | | | )
for (p=0;p<6;p++) grBuffer.drawLine (p*(width/6),0,p*(width/6),30);
if ((mil*1000000) + (hunthou*100000) + (tenthou*10000) + (thou*1000) + (hund*100) + (tens*10) + ones < numHits) {
grBuffer.drawString (""+ones,105,45-rot);
a=rot-30;
if (a<0) a=0;
grBuffer.drawString (""+(ones+1),105,45-a);
rot+=2;
if (rot>=40) {
flipped=true;
rot=10;
}
a=rot2-20;
if (a<0) a=0;
grBuffer.drawString (""+tens,83,30-rot2);
grBuffer.drawString (""+(tens+1),83,45-a);
rot2=ones*4;

a=rot3-20;
if (a<0) a=0;
grBuffer.drawString (""+hund,63,30-rot3);
grBuffer.drawString (""+(hund+1),63,45-a);
rot3=tens*4;

a=rot4-20;
if (a<0) a=0;
grBuffer.drawString (""+thou,43,30-rot4);
grBuffer.drawString (""+(thou+1),43,45-a);
rot4=hund*4;

a=rot5-20;
if (a<0) a=0;
grBuffer.drawString (""+tenthou,23,30-rot5);
grBuffer.drawString (""+(tenthou+1),23,45-a);
rot5=thou*4;

a=rot6-20;
if (a<0) a=0;
grBuffer.drawString (""+hunthou,3,30-rot6);
grBuffer.drawString (""+(hunthou+1),3,45-a);
rot6=tenthou*4;
}
else {
grBuffer.drawString (""+ones,105,25);
grBuffer.drawString (""+tens,83,25);
grBuffer.drawString (""+hund,63,25);
grBuffer.drawString (""+thou,43,25);
grBuffer.drawString (""+tenthou,23,25);
grBuffer.drawString (""+hunthou,3,25);


}



g.drawImage (imgBuffer, 0, 0, this);
paintDelay=0;

}

private void sendData () {
	System.out.println ("sending...");
	String IPAdd="";
	int port=0;
	Socket clientsocket;
	DataOutputStream out;
	IPAdd = getParameter("IPAdd");
	port=Integer.parseInt (getParameter("PortNumber"));

	try {
	            clientsocket = new Socket(IPAdd, port);                    //IPAdd  "localHost"
	           	out = new DataOutputStream(clientsocket.getOutputStream());

	           	String msg="new hit";

				out.writeUTF(msg);
				out.close();

} catch (Exception e) {
	System.out.println ("Couldnt connect to server");
} //exception





}//senddata

private void newView () {
String fileName;
fileName = getParameter("fileName");
int tempInt1=0;
char charRead='a';
String tempString="";
int p,t,a;
a=0;
try {
			URL url = new URL(getCodeBase(), fileName);

			try {
				BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
               do {
                    tempInt1=in.read();
                    charRead= (char) (tempInt1);
                    if (charRead=='X') numHits=Integer.parseInt (tempString);

                    tempString=tempString + charRead;

					} while (tempInt1 != -1);
					in.close ();
			} catch (IOException e) { }
		} catch (MalformedURLException e) { }

}//newview

 public void run() {
while (true) {


if ((mil*1000000) + (hunthou*100000) + (tenthou*10000) + (thou*1000) + (hund*100) + (tens*10) + ones < numHits) {

if (flipped==true) {
flipped=false;

ones+=2;
if (numHits>1000) tens++;
if (numHits>10000) hund++;
if (numHits>100000) thou++;
if (ones>9) {
tens++;
ones=0;
}

if (tens>9) {
hund++;
tens=0;
}

if (hund>9) {
thou++;
hund=0;
}

if (thou>9) {
tenthou++;
thou=0;
}

if (tenthou>9) {
hunthou++;
tenthou=0;
}

if (hunthou>9) {
mil++;
hunthou=0;
}

}
repaint ();


} else {
ones=numHits-((int) (numHits/10)*10);
tens=(numHits-((int) (numHits/100)*100))/10;
hund=(numHits-((int) (numHits/1000)*1000))/100;
thou=(numHits-((int) (numHits/10000)*10000))/1000;
tenthou=(numHits-((int) (numHits/100000)*100000))/10000;
hunthou=((int) (numHits/100000));

paintDelay++;
if (paintDelay>=4) {
repaint ();
paintDelay=0;
}

}

try {
	t.sleep(1);
	} catch (InterruptedException e) {  }



} //while

} //run

public void start() {


        if (t==null) {
           t = new Thread(this);
        }

           t.start();
}

public void stop() {
           t = null;

}
public void update (Graphics g) {

        paint (g);
    }



} //class spacefly