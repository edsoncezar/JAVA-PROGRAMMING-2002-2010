hitcounter by XdebugX
XdebugX@hotmail.com
http://xdebugx.deltaarc.net

This is a hit counter, server application and client applet.  The applet is for viewing hits to your site.  The number of hits are kept in the file hits.dat as text.  The applet reads the number of hits from this file.  The applet connects to the application on the server to have it write a new hit.

The server must be running on the same machine that the client applet is hosted on.  To run the server you need the Java Runtime Environment installed.  If you dont have the jre go to http://java.sun.com where you can get it.  Run the file hitServer.class on your webserver with the jre.  Such as: 
java hitServer 
:from the command line.  

To put the applet on a web page you must imbed an applet tag in the html.  Use one similar to this, with your specifications.

<applet code="hitCounter.class" width="125" height="30">
<param name=fileName value=hits.dat>
<param name=IPAdd value=localhost>
<param name=PortNumber value=6592>
</applet>

code="hitCounter.class" <-- this tells the webpage what java file to run, it should not be changed.

width="125" height="30" <-- this tells the webpage how big the applet is, it should not be changed.

<param name=fileName value=hits.dat> <-- this tells the applet what file to load for the number of hits.  As of this version it should not be changed because the server uses this file name.

<param name=IPAdd value=localhost>  <-- this tells the applet the ip address of the server that the application is running on.  This should be changed to the ip address of your webserver.

<param name=PortNumber value=6592>  <-- this tells the applet the port number to use.  As of this version it should not be changed because it is hardcoded in the application.


If you have any questions email me at xdebugx@hotmail.com



