/*
	Ian the man Charnas' Quoter 1.0.
	Yes, he strikes again.  This applet takes quotes from a text file 
	and displays one at random with all sorts of graphic goodies.
	background, fonts, border, etc.  See readme.txt for all info.
	If you wish to use this applet, you must first recognize me as the
	god of all that occurs between the hours of 11:00 PM and 5:00 AM.
	You must also eat 17 meatballs all covered with cheese, pee in a 
	drinking fountain, and make a woman entirely out of jello.
	Remember, This is not a flying toy. Results may vary with use.
	Void where prohibited, no purchase neccessary.  10% sales tax in Ohio.
	Phi Kappa Psi is cool. Zeta Beta Tau is not. -> note the difference.
	And, last but not least, SCSI_BUCKET RULES!!! (it's my computer, silly).
*/

import java.awt.*;
import java.applet.Applet;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.util.Random;
import java.util.Vector;
import java.util.StringTokenizer;
import java.lang.*;

public class quoter extends Applet

{
	Graphics offscreen;			// Double buffering use, I think.
	Image buf;					// Double buffering strikes again.
	MediaTracker tracker;		// Used to keep track of image.
	Dimension AppletSize;		// Used to find applet dimensions.
	Color fontColor;			// Color of the text.
	Color bgColor;				// Color of the background.
	Color borderColor;			// Color of the border.
	Color tempColor;
	String rgbDelimiter = ":,.";	// string delimiter
	StringTokenizer st;			// Breaks apart strings separated by rgbDelimiter.
	Image bgImage;				// Background Image object.
	Integer intTemp = null;		// We use this only temporarily.
	int intImageWidth;			// Width of the image.
	int intImageHeight;			// Height of the image.
	Boolean boolResizeImage;	// Should we resize the image to fit the applet window?
	String strImageName = null;	// File Name of background image.
	int intAppletWidth;			// Width of Applet.
	int intAppletHeight;		// Height of Applet.
	int intRightIndent;			// How far to indent text from right of applet.
	int intLeftIndent;			// How far to indent text from left of applet.
	int intIndent;				// Will be left indent + right indent.  for asthetic code purposes.
	int intTopIndent;			// How far to indent text from top of applet.
	int intSpace;				// Space in pixels between lines of text.
	FontMetrics fm;				// Used to find pixel info on fonts.
	Font fontOurFont;			// This font object saves all our font info.
	Font FontTemp;				// We use this only temporarily.
	int intFontSize;			// i.e. 10 - size of the font.
	String strFileName = null;	// Name of file to open.
	Vector vecQuotes = new Vector();	// Contains all Quotes.

	// Initialize the freaking variables.
	public void init() 

	{

	AppletSize      = size();	// Used in the next statement ONLY!
	intAppletWidth  = AppletSize.width;	//	The width of the java applet.  Used when wrapping quote.
	intAppletHeight = AppletSize.height;	// The height of the java applet.
	
	intSpace 		= PickInt("space", 3);				// Space in pixels between each line of text.
	intRightIndent  = PickInt("rightindent", 5);		// Indent from the right.
	intLeftIndent   = PickInt("leftindent", 20);		// Indent from the left.
	intTopIndent    = PickInt("topindent",0);		// Indent from top.
	intIndent		= intLeftIndent + intRightIndent;	// This variable is created so I don't
														// Have to keep typing intLeftIndent + intRightIndent.
														
	intFontSize      = PickInt("fontsize",18);		// Size of the font used.
	// The Folowing statement will set up our font object with font name,style, and size.
	fontOurFont	  = PickFont("fontname", "TimesRoman", "fontstyle", Font.PLAIN, intFontSize);
	fontColor	  = PickColor("fontcolor", Color.black);	// Set the font color.
	borderColor   = PickColor("bordercolor", Color.black);	// Set the border color.
	bgColor       = PickColor("bgcolor", Color.white);			// Set the background color.

	strImageName = PickString("imagename", "");	// Name of background image file to open.
	buf = createImage(intAppletWidth, intAppletHeight); // Load buffer image.
	offscreen = buf.getGraphics();						// Display buffer image.
	tracker = new MediaTracker(this);	// Start up the media tracker. Super-spy!

	boolResizeImage = PickBoolean("resizeimage", Boolean.TRUE);
	if (boolResizeImage == Boolean.TRUE)
		{
		intImageWidth = intAppletWidth;	// Default Image width is applet width.
		intImageHeight = intAppletHeight; // Default Image height is applet height.
		bgImage = getImage(getDocumentBase(), strImageName);  // Load the image.
//		bgImage = bgImage.getScaledInstance(intImageWidth-2, intImageHeight-2, 0); // Resize to fit inside border
		}
	else
		{
		intImageWidth = PickInt("imagewidth",10);	// Get image with from parameter.
		intImageHeight = PickInt("imageheight", 10);// Get image height from parameter.
		bgImage = getImage(getDocumentBase(), strImageName);	// Load the image.
		if (intImageWidth > intAppletWidth-2) // If the image is too wide to fit inside applet...
			{
			intImageWidth = intAppletWidth;	// Set the image width = the applet width...
//			bgImage = bgImage.getScaledInstance(intImageWidth-2, intImageHeight, 0); // And resize image.
			}
		if (intImageHeight > intAppletHeight-2)	// If the image is too tall to fit inside applet...
			{
			intImageHeight = intAppletHeight;	// Set the image height = the applet height...
//			bgImage = bgImage.getScaledInstance(intImageWidth, intImageHeight-2, 0); // And resize image.
			}
		}

	tracker.addImage(bgImage, 0);
	try
		{
		tracker.waitForAll();
		}
	catch (InterruptedException e)
		{
		System.out.println("Error waiting for background image to load.");
		}
//	bgImage      = getImage(getDocumentBase(), strImageName);  // Load the image.
//	bgImage      = bgImage.getScaledInstance(intImageWidth-2, intImageHeight-2, 0);  // Scale the Image.
	
	strFileName = PickString("quotefile", "");	// Name of quotes file to open.



	// Get the quotes from a text file and store it into the vector vecQuotes.
	GetQuotes();
	
	}
	// End init.
	
	// Begin PickString
	// This gets a parameter, and returns the string value, using default
	// as necessary.
	public String PickString(String strStringParameter, String strDefaultString)
	{
	String strStringTemp = getParameter(strStringParameter);
	if (strStringTemp == null)
		return strDefaultString;
	else return strStringTemp;
	}
	// End PickString
	
	// Begin PickBoolean
	// This gets a parameter, and returns the boolean value, using default
	// as necessary.
	public Boolean PickBoolean(String strBooleanParameter, Boolean defaultBoolean)
	
	{
	
	String strBooleanTemp = getParameter(strBooleanParameter);
	if (strBooleanTemp == null)
		return defaultBoolean;
	else if (strBooleanTemp.equalsIgnoreCase("true"))
		return Boolean.TRUE;
	else if (strBooleanTemp.equalsIgnoreCase("false"))
		return Boolean.FALSE;
	else
		return defaultBoolean;
	
	}
	// End PickBoolean

	// Begin PickFont
	// This gets the FontName and FontStyle from parameters, using defaults if
	// Neccessary.  It also takes the FontSize we already have, and when it's all
	// Done, returns a font object filled with our font info.
	public Font PickFont(String strFontNameParameter, String strDefaultFontName, String strFontStyleParameter, int intDefaultFontStyle, int intFontSize)

	{
	
	String strFontNameTemp = null, strFontStyleTemp = null;
	int intFontStyle;
	strFontNameTemp = getParameter(strFontNameParameter);
	if (strFontNameTemp == null)
		strFontNameTemp = strDefaultFontName;
	else if (strFontNameTemp.equalsIgnoreCase("TimesRoman"))
		strFontNameTemp = "TimesRoman";
	else if (strFontNameTemp.equalsIgnoreCase("Helvetica"))
		strFontNameTemp = "Helvetica";
	else if (strFontNameTemp.equalsIgnoreCase("Courier"))
		strFontNameTemp = "Courier";
	else if (strFontNameTemp.equalsIgnoreCase("Dialog"))
		strFontNameTemp = "Dialog";
	else if (strFontNameTemp.equalsIgnoreCase("DialogInput"))
		strFontNameTemp = "DialogInput";
	else
		strFontNameTemp = "TimesRoman";
	
	strFontStyleTemp = getParameter(strFontStyleParameter);
	if (strFontStyleTemp == null)
		intFontStyle = intDefaultFontStyle;
	else if (strFontStyleTemp.equalsIgnoreCase("PLAIN"))
		intFontStyle = Font.PLAIN;
	else if (strFontStyleTemp.equalsIgnoreCase("BOLD"))
		intFontStyle = Font.BOLD;
	else if (strFontStyleTemp.equalsIgnoreCase("ITALIC"))
		intFontStyle = Font.ITALIC;
	else
		intFontStyle = intDefaultFontStyle;
	
	FontTemp = new Font(strFontNameTemp, intFontStyle, intFontSize);
	return FontTemp;
	
	}
	// End PickFont.

	// Begin PickInt.
	// This function gets a parameter and returns the int value.
	// If the parameter isn't in the HTML, or is invalid, it returns the default int value.
	public int PickInt(String strParameter, int intDefault)

	{

	int tempInt;
	try
		{
		intTemp = new Integer(getParameter(strParameter));
		return intTemp.intValue();
		}
	catch (Exception e)
		{
		return intDefault;
		}

	}
	// End PickInt.

	// Begin PickColor.
	// Get the color value from a parameter and store it in a color object.
	// If the color isn't there, return the default Color value.
	public Color PickColor(String strParameter, Color defaultColor) 
	
	{
	
	String strColor = null;
	strColor = getParameter(strParameter);
	if (strColor != null)
		st = new StringTokenizer(strColor, rgbDelimiter);
	if (strColor == null)
		return defaultColor;
	else if (strColor.equalsIgnoreCase("black"))
		return Color.black;
	else if (strColor.equalsIgnoreCase("blue"))
		return Color.blue;
	else if (strColor.equalsIgnoreCase("cyan"))
		return Color.cyan;
	else if (strColor.equalsIgnoreCase("darkGray"))
		return Color.darkGray;
	else if (strColor.equalsIgnoreCase("gray"))
		return Color.gray;
	else if (strColor.equalsIgnoreCase("green"))
		return Color.green;
	else if (strColor.equalsIgnoreCase("lightGray"))
		return Color.lightGray;
	else if (strColor.equalsIgnoreCase("magenta"))
		return Color.magenta;
	else if (strColor.equalsIgnoreCase("orange"))
		return Color.orange;
	else if (strColor.equalsIgnoreCase("pink"))
		return Color.pink;
	else if (strColor.equalsIgnoreCase("red"))
		return Color.red;
	else if (strColor.equalsIgnoreCase("white"))
		return Color.white;
	else if (strColor.equalsIgnoreCase("yellow"))
		return Color.yellow;
	else if (st.countTokens() == 3)
		{
		Integer r = new Integer(st.nextToken());
		Integer g = new Integer(st.nextToken());
		Integer b = new Integer(st.nextToken());
		tempColor = new Color(r.intValue(), g.intValue(), b.intValue());
		return tempColor;
		}
	
	return defaultColor;

	}
	// End PickColor.
		
	// Begin GetQuotes.  This will...
	// Read the quotes file and store values into the vector vecQutoes.
    synchronized void GetQuotes() 
    
    {
    
        InputStream         conn;
        DataInputStream     inStream = null;
        URL     			theURL = null;

		// We require a file name.
        if (strFileName==null) return;
        try 
        	{
			// If it is a absolute URL...
            if (strFileName.indexOf("http://") >= 0 ) 
            	{
                theURL = new URL(strFileName);
            	}
            // If it is a relative URL...
            else 
            	{
            	// Turn it into an absolute URL.
                theURL = new URL(getDocumentBase(),strFileName);
				}
            try 
            	{
                String  strLine;
                conn = theURL.openStream();
				// inStream is our DataInputStream from the quote file.
                inStream = new DataInputStream(new BufferedInputStream(conn));
				// While we haven't reached the end of the file...
                while( (strLine=inStream.readLine()) != null) 
                	{
					// # is a comment in the quotes text file.
					// Blank lines should be skipped.
                    if (strLine.startsWith("#") || strLine.length()==0) continue;
					// Add the line from the file to the quote vector.
                    vecQuotes.addElement(strLine);
                    continue;
                   	}
            	}
            catch (IOException e) {}
        	}
        catch (MalformedURLException e) {}
   	
   	}
	// End of GetQuotes

	// Paint the silly thing.
	public void paint( Graphics g ) 

	{
	if (offscreen != null)
		{
		paintApplet(offscreen);
		g.drawImage(buf,0,0,this);
		}
	else
		{
		paintApplet(g);
		}
	

	}
	
	public void paintApplet( Graphics g )
	
	{
	
		Random randNumber = new Random();
		// Get a random float variable.
		float fltRandomNumber = randNumber.nextFloat() * (vecQuotes.size()-1);
		// Get a random int variable.
		int intRandomNumber = Math.abs(Math.round(fltRandomNumber));
		
		//Get pixel information on our font.
		fm = g.getFontMetrics(fontOurFont);
		
		int intFontAscent = fm.getAscent();  // Ascent is the height of the font, pretty much.

		g.setColor(bgColor);	// Set color for background.
		g.fillRect(0,0,intAppletWidth, intAppletHeight);	// And Draw background.		

		if (strImageName != "")
			{
			if (boolResizeImage == Boolean.TRUE)
				g.drawImage(bgImage, 1, 1, null);  // Draw the Image.
			else
				{
				int intImageX, intImageY;
				intImageX = Math.round( ((intAppletWidth-2) - intImageWidth) / 2 );	// Center Width.
				intImageY = Math.round( ((intAppletHeight-2) - intImageHeight) / 2);// Center Height.
				g.drawImage(bgImage, intImageX, intImageY, null); // Draw Image
				}
			}
		
		g.setColor(borderColor);	// Set color for border
		g.drawRect(0,0,intAppletWidth-1,intAppletHeight-1); // Draw Border

		g.setColor(fontColor);	// Set color for text.
		g.setFont(fontOurFont);	// Set font for text.

		// Get a random quote from the vector we just made in GetQuotes().
		String strQuote = vecQuotes.elementAt(intRandomNumber).toString();
		
		int intStringWidth = 0, intEnd = 0, intY = intTopIndent+intFontAscent;
		
		// If there's no quote, complain!
		if (strQuote.length() <= 0)
			g.drawString("Error: Empty Quote", intRightIndent, intY);
			
			
		// All the stuff in this for loop and if statements draws, wraps, and indents the text.
		for (;;)
			{
			if (strQuote.length() > 0)
				{
				if ( (fm.stringWidth(strQuote) + intIndent) < intAppletWidth)
					{
					g.drawString(strQuote.trim(),intLeftIndent,intY);
					strQuote = "";
					}
				else
					{
					if ( (intStringWidth + intIndent) < intAppletWidth)
						{
						intStringWidth += fm.charWidth(strQuote.charAt(intEnd));
						intEnd++;
						}
					else
						{
						intEnd = strQuote.lastIndexOf(' ',(intEnd-1));
						g.drawString(strQuote.substring(0,intEnd).trim(), intLeftIndent, intY);
						intY += intFontAscent + intSpace;
						strQuote = strQuote.substring(intEnd);
						intEnd = 0;
						intStringWidth = 0;
						}
					}
				}
			else
				break;
			}

	}
	// End Paint.	
}
// End Applet.