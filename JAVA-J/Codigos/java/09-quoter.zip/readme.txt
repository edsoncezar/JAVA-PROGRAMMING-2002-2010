Quoter 1.0  by Ian Charnas
----------------------------------
In case you've been blindfolded, analy raped by asian gorillas and forced to download
this without any knowlege of what it is...it's a java applet that displays a random
quote from a text file.
Here's what you need to do to use it.

1.  Get a web server to put it on.  Geez, that's no-brainer.

2.  Make sure you've eaten 17 meatballs, peed in a drinking fountain,
    and made a woman entirely out of jello before continuing.

3.  Save the quoter.jar file to some kinda directory on your web server.
    Probably the same directory that holds the HTML file you want to put
    the Java Applet inside.
    If you don't know how to do that... skip to direction #8.

4.  Edit the web page that you want to embed the java applet into.

5.  Wherever you want the applet, put something resembling the following HTML...

<applet code="quoter.class" width="500" height="100" align="middle">
  <param name="bgcolor" value="white">
  <param name="bordercolor" value="black">
  <param name="fontcolor" value="black">
  <param name="fontname" value="TimesRoman">
  <param name="fontsize" value="18">
  <param name="fontstyle" value="ITALIC">
  <param name="imagename">
  <param name="imageheight" value="50">
  <param name="imagewidth" value="100">
  <param name="leftindent" value="20">
  <param name="quotefile" value="quotes.txt">
  <param name="rightindent" value="5">
  <param name="space" value="5">
  <param name="topindent" value="0">
</applet>

6.  These don't have to be the parameters you choose.  But, to choose them, take
    a gander at the nice section below clearly marked "Parameters:"!  Chances are,
    you'll find your answers in there.  Save the html, and you're all done.

7.  Skip to Direction #9.

8.  Jump off a cliff.

9.  Smile, because you're using a Scsi_bucket affiliated product!


---------------------------------------------------------------------------------------
Parameters:
NAME		DESCRIPTION
---------------------------------------------------------------------------------------
space		Space in pixels between each line of text. Default is 3
rightindent	Space to indent text from right side of applet. Default is 5.
leftindent	Space to indent text from left side of applet. Default is 20.
topindent	Space to indent text from top of applet. Default is 0.
fontsize	Size of font to use. Default is 18.
fontname	Name of Font.  Pick from list below. Default is Times Roman.
fontstyle	Style of font. either BOLD, ITALIC, or PLAIN. Default is PLAIN.
fontcolor	Font color. Pick a color from the color list below, or type in RGB values separated in colons, i.e. 255:0:35
bordercolor     Border color. Pick a color from the color list below, or type in RGB values separated in colons, i.e. 255:0:35
bgcolor		Background color. Pick a color from the color list below, or type in RGB values separated in colons, i.e. 255:0:35
imagename	relative url of image, relative to the path of the java applet. Default is no image.
imagewidth	If you specify an image, you have to specify a width of the image.
imageheight	If you specify an image, you have to specify a height of the image.
quotefile	relative url of quote file, relative to the path of the java applet. Will give error if not supplied.

-----------------------------------------------------------------------
COLOR LIST:
black, blue, cyan, darkGray, gray, green, lightGreen, magenta, orange,
pink, red, white, yellow
-----------------------------------------------------------------------
FONT LIST:
TimesRoman, Helvetica, Courier, Dialog, DialogInput
-----------------------------------------------------------------------