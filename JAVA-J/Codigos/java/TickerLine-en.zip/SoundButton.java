/*
 * SoundButton.java
 *
 * Copyright (c) 1999 by R�diger Appel, All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * See also: http://www.3quarks.com
 *
 */


import java.applet.*;
import java.awt.*;
import java.net.*;
import java.util.*;


public class SoundButton extends Applet implements Runnable
  {
  private Thread    loader          = null;
  private boolean   allLoaded       = false;
  
  private Applet    receiver        = null; 
  private String    onMessage       = null;
  private String    offMessage      = null;
  private Image     buttonImage     = null;

  private boolean   isMouseOver     = false;
  private boolean   isSoundEnabled  = false;

  
  public SoundButton ()
    {
    // write applet info
    System.out.println (getAppletInfo ());
    }
  
  
  public String getAppletInfo ()
    {
    // return my copyright notice
    return "SoundButton, Version 1.0"
         + System.getProperty ("line.separator")
         + "Copyright (c) 1999 by R�diger Appel, All Rights Reserved" 
         + System.getProperty ("line.separator")
         + "See also: http://www.3quarks.com";
    }

  
  public void init ()
    {
    // get message parameter
    onMessage  = getParameter ("onMessage");
    offMessage = getParameter ("offMessage");

    // set background color
    try 
      {
      StringTokenizer tokenizer = new StringTokenizer (getParameter ("BackgroundColor"), ",");
      if (tokenizer.countTokens () == 1)
        {
        String value = tokenizer.nextToken ().trim ();
        setBackground (new Color (Integer.parseInt (value.substring (1, 3), 16),
                                  Integer.parseInt (value.substring (3, 5), 16),
                                  Integer.parseInt (value.substring (5, 7), 16)));
        }
      else
        setBackground (new Color (Integer.parseInt (tokenizer.nextToken ().trim ()),
                                  Integer.parseInt (tokenizer.nextToken ().trim ()), 
                                  Integer.parseInt (tokenizer.nextToken ().trim ())));
      }
    catch (Exception exception) {}
    }


  public void update (Graphics graphics)
    {
    paint (graphics);
    }


  public void paint (Graphics graphics)
    {
    // paint button image
    if (buttonImage != null)
      {
      // compute source position
      int xPos = ((isSoundEnabled) ? 2 * size ().width : 0)
               + ((isMouseOver) ? 0 : size ().width);
      
      // paint button rect
      graphics.drawImage (buttonImage, -xPos, 0, this);
      }
    }


  private void updateStatus ()
    {
    String message = null;
    
    // get message
    if (isMouseOver)
      {
      if (isSoundEnabled)
        message = offMessage;
      else
        message = onMessage;
      }
    else
      message = " ";
    
    // update browser status line
    if (message != null)
      showStatus (message);
    }
  
  
  public boolean mouseEnter (Event event, int x, int y)
    {
    // update button
    isMouseOver = true;
    repaint ();
    updateStatus ();
    
    return true;
    }

  
  public boolean mouseExit (Event event, int x, int y)
    {
    // update button
    isMouseOver = false;
    repaint ();
    updateStatus ();
    
    return true;
    }


  public boolean mouseDown (Event event, int x, int y)
    {
    // check for button hit
    if ((x >= 0) && (x < size ().width) &&
        (y >= 0) && (y < size ().height))
      {
      isSoundEnabled = !isSoundEnabled;
      
      // send message to receiver and verify sound flag
      try
        {
        ((TickerLine) receiver).enableSound (isSoundEnabled);
        isSoundEnabled = ((TickerLine) receiver).isSoundEnabled ();
        }
      catch (Exception exception) {}
      
      repaint ();
      updateStatus ();
      }

    return true;
    }


  public void start ()
    {
    // start loader
    if (!allLoaded)
      {
      loader = new Thread (this);
      loader.start ();
      }
    }


  public void stop ()
    {
    // stop loader
    if (loader != null)
      {
      loader.stop ();
      loader = null;
      }
    }


  public void run ()
    {
    // load button image
    try 
      {
      MediaTracker tracker = new MediaTracker (this);
      Image image = getImage (getCodeBase (), getParameter ("ButtonImage"));
      tracker.addImage (image, 1);
      tracker.waitForID (1);
      if (!tracker.isErrorID (1))
        buttonImage = image;
      }
    catch (Exception exception) {}
    
    // get receiver
    try 
      {
      receiver = getAppletContext ().getApplet (getParameter ("Receiver"));
      }
    catch (Exception exception) {}
    
    // repaint applet
    allLoaded = true;
    repaint ();
    }

  
  }