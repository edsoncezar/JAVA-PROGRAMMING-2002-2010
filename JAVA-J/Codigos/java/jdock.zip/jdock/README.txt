This is a non registered JDock 1.1 version. A popup will appear every 10 mn. 

Get the full registered version at http://www.swingall.com

Please, 
Send bugs, 
Improvement needs, 
Comments at : product@japisoft.com

Thank you for trying a JAPISOFT product.

Best regards,

JAPISoft
http://www.japisoft.com


