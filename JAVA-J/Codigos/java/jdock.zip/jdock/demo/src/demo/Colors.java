package demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.UIManager;

import com.japisoft.framework.dockable.JDock;

/**
 * This is a demo customizing the JDock panel with various colors
 * @author (c) 2004 JAPISoft
 */
public class Colors {
	
	public static void main( String[] args ) {

		// Reset the starting color of the header for each non selected inner window
		UIManager.put( "jdock.innerwindow.gradient.startColor", Color.DARK_GRAY );
		// Reset the final color of the header for each non selected inner window
		UIManager.put( "jdock.innerwindow.gradient.stopColor", Color.white );
		// Reset the starting color of the header for each selected inner window
		UIManager.put( "jdock.innerwindow.gradient.selectedStartColor", Color.red.darker() );
		// Reset the final color of the header for each selected inner window		
		UIManager.put( "jdock.innerwindow.gradient.selectedStopColor", Color.white );		
		
		// Main panel without shadow for the inner window
		JDock pane = new JDock( false );

		// Action for removing the default shadow
		// pane.setShadowMode( false );

		// The default JDock layout is a BorderLayout

		pane.addInnerWindow( "T1", "Tree", new JScrollPane( new JTree() ), BorderLayout.WEST );
		pane.addInnerWindow( "TA", "Text Area", new JTextArea(), BorderLayout.CENTER );
		pane.addInnerWindow( "TEXT1", "Text1", new JTextField( "SOUTH" ), BorderLayout.SOUTH );
		
		JTextField tf;
		
		pane.addInnerWindow( "TEXTE", "Text2", tf = new JTextField( "NORTH" ), BorderLayout.NORTH );
		
		tf.setPreferredSize( new Dimension( 100, 50 ) );
		
		pane.addInnerWindow( "T2", "Tree 2", new JTree(), BorderLayout.EAST );
		
		// Background color for the inner panel
		pane.setBackground( Color.black );
		// Color of the found window while dragging an inner window
		pane.setDraggingActiveWindow( Color.blue );
		// Color of the shadow while dragging an inner window
		pane.setDraggingShadowColor( Color.green );
		// Color of the shadow while resizing an inner window
		pane.setResizingShadowColor( Color.green );

		pane.setInnerWindowBackgroundForId( "T1", Color.green.darker() );
		
		JFrame frame = new JFrame();
		frame.getContentPane().add( pane.getView() );
		frame.setSize( 600, 500 );
		frame.setVisible( true );

	}
	
}
