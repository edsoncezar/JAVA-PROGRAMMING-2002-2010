
import java.awt.*;
import java.io.*;
import java.lang.*;
import java.net.URL;
import java.util.*;
import java.applet.*;

public class NF4 extends Applet {
    NFControls controls;
    NFCanvas canvas;
    PlainData data[];
    int num = 1;
    int c;
    Font dataFont;
    int columns;
    int values[][];
    String name[];

    public void init() {


	String rs;



	dataFont = new java.awt.Font("Courier",Font.BOLD, 16);

        rs = getParameter("columns");
        if (rs == null){
           columns = 5;
        }else {
           columns = Integer.parseInt(rs);
        }


	Vector pdTemp = new Vector();
	
	while(true){
	      String str_tmp;
	      PlainData data_tmp = new PlainData();
	      
	      str_tmp = getParameter("a"+num);
	      if(str_tmp == null)break;

	      data_tmp.init(str_tmp);
	      pdTemp.addElement(data_tmp);

	      num++;
	}

	data = new PlainData[pdTemp.size()];
	pdTemp.copyInto(data);
	num--;
	
	values = new int[num][columns];
	for(int j=0;j < num;j++){
	   for(int i=0;i < columns;i++){
	      values[j][i] = data[j].item[i];
	      }
	   }
	name = new String[num];
	for(int j=0;j < num;j++){
	name[j] = data[j].name;
	}

        setLayout(new BorderLayout());
        NFCanvas c = new NFCanvas();
        add("Center", c);
        add("North", controls = new NFControls(c));
	c.add(this,values,columns,num,name);

    }


    public void start() {


	controls.start();
    }

    public void stop() {
        controls.stop();
    }


    public static void main(String args[]) {
        Frame f = new Frame("NF4");
        NF4 nf4 = new NF4();
	

        nf4.init();
	nf4.start();

        f.add("Center", nf4);
        f.resize(550,600 );
        f.show();
    }




}
class NFCanvas extends Canvas {
    NF4 nf4;
    NFControls controls;
    int         a = 10;
    int         b = 40;
    int	        xy = 0;
    int         angle[];
    int         total;
    int 	values[][],columns,num,X,Y;
    String      name[];
    boolean     submit = false;
    int		kind = 0;
    int 	witch = 0;
    Font        font;
    double         max = 0;
    double         min = 10000000000;
    double      decode = 1;

    public void add(NF4 nf4,int values[][],int columns,int num,String name[] ){
	this.columns = nf4.columns;
	this.num = nf4.num;
	this.values = new int[num][columns];
	this.name   = new String[num];

	for(int j = 0;j < num;j++){
	   this.name[j] = nf4.name[j];
	   for(int i = 0;i < columns;i++){
	      this.values[j][i] = nf4.values[j][i];
	      }
	   }

	for(int j = 0;j < num;j++){
	   for(int i = 0;i < columns;i++){
		if (values[j][i] > max)max = values[j][i];
		else if (values[j][i] < min)min = values[j][i];
	      }
	   }
	
	decode = 260 / (max - min);

	}    


    public void paint(Graphics g) {
	this.white(g);
	}

    public void update(Graphics g){

	if (!submit)this.white(g);
	else{
 	 if (kind == 0){
    	          this.line(g,xy,witch);
	     }

	 else if (kind == 1) {
	         this.rect(g,xy,witch);
	 }

	 else{
	    this.circle(g,xy,witch);
           }
     }
    }
    public void white(Graphics g){
	
	g.setColor(Color.white);
        g.fillRect(10,10,500,280);
        g.setColor(Color.black);
        g.drawRect(10,10,500,280);
    
	g.drawRect(10,300,90 + 40*columns, 30*num);
   	for(int j=0;j < num;j++){
           a = 10;
             switch (j){
                case 0:g.setColor(Color.red);break;
                case 1:g.setColor(Color.blue);break;
                case 2:g.setColor(Color.green);break;
                case 3:g.setColor(Color.orange);break;
                default:g.setColor(Color.yellow);break;
                }

           g.drawString(name[j],10,300 + (j+1)*30);
	   g.setColor(Color.black);
           a = a + 80;
	   g.drawLine(10,300 + (j + 1)*30,90 + 40*columns,300 + (j + 1)*30);
           for(int i=0;i < columns;i++){
               g.drawString("" + values[j][i],a,300+(j+1)*30);
	       g.drawLine(a-3,270+(j+1)*30,a-3,300+(j + 1)*30);
               a = a + 40;
	      }
	   }	
	}

    public void line(Graphics g,int xy,int witch){
	   
	if (witch > (num+1))g.drawString("Please Input Number under "+(num+1),100,100);
	else{
	     a = 10;
             switch (witch){
		case 0:g.setColor(Color.red);break;
                case 1:g.setColor(Color.blue);break;
                case 2:g.setColor(Color.green);break;
                case 3:g.setColor(Color.orange);break;
                default:g.setColor(Color.yellow);break;
		}

             for (int i=0;i < columns ;i++){
             if (i == (columns - 1)){
                 g.drawString("" + values[witch][i],a
				,290- (int)(values[witch][i]*decode));
                 break;
                 }

            g.drawLine(a,290 - (int)(values[witch][i]*decode) ,a+(500/(columns-1)), 
						290- (int)(values[witch][i+1]*decode));
            g.drawString("" + values[witch][i],a,290- (int)(values[witch][i]*decode));
            a = a + (500/columns);
                 }
	}
    }

    public void rect(Graphics g,int xy,int witch){
	a = 10;
	if (witch > (num+1))g.drawString("Please Input Number under "+ (num+1),100,100);
	else{
        for(int i=0;i < columns;i++){
       	switch (witch){
		case 0:g.setColor(Color.red);break;
       		case 1:g.setColor(Color.blue);break;
        	case 2:g.setColor(Color.green);break;
        	case 3:g.setColor(Color.orange);break;
        	default:g.setColor(Color.yellow);break;
	}

       g.fillRoundRect(a,290 - (int)(values[witch][i]*decode),15,(int)(values[witch][i]*decode),5,5);
       g.setColor(Color.black);
       g.drawString("" + values[witch][i],a + 5,290 - (int)(values[witch][i]*decode));
       a = a + 20;
      }
	}
    }

   public void circle(Graphics g,int xy,int witch){
         a = 10;
	if (witch > columns)g.drawString("Please Input number under"+ (columns+1),100,100);
	else{
         total = values[0][witch]; 
         for(int j = 1;j < num;j++ ){
            total = total + values[j][witch];
            }
         angle = new int[num];

         for(int j = 0;j < num;j++){
         angle[j] = 360 * values[j][witch] / total; 
           }

        g.setFont(font);           
        a = 0;
	b = 0;
        for(int j=0; j < num;j++){
           if(j == 0)g.setColor(Color.red);
           else if(j == 1)g.setColor(Color.blue);
	   else if(j == 2)g.setColor(Color.green);
	   else if(j == 3)g.setColor(Color.orange);
           else g.setColor(Color.yellow);

           g.drawString("" + name[j],40,b);
           g.fillArc(150,60,200,200,a,angle[j]);
           a = a + angle[j];
           b = b + 20;
           }
	}
    }
    public void getdata(int kind) {

	this.kind = kind;
    }

    public void redraw(boolean submit,int witch) {

        this.submit = submit;
	this.witch = witch - 1;
	repaint();
    }

}

class NFControls extends Panel{
    int k,xy;
    NFCanvas canvas;
    TextField s;

    public  NFControls(NFCanvas canvas) {
        this.canvas = canvas;

	Choice k = new Choice();
        k.addItem("Line");
        k.addItem("Rect");
        k.addItem("Circle");
	add(k);
	
	add(s = new TextField("1", 5));
	add(new Button("submit"));
	add(new Button("clear"));
    }

   
public boolean action(Event e, Object arg) {
	if (e.target instanceof Choice){
         String label = (String)arg;
         if (label.equals("Line"))k=0;
         else if (label.equals("Rect"))k = 1;
         else  k = 2;

         canvas.getdata(k);
         return true;
	}
	else if(e.target instanceof Button){
	 String label = (String)arg;
	 canvas.redraw(label.equals("submit"),
			Integer.parseInt(s.getText().trim()));
	return true;
	}
	
	 return false;	
  }

  public void start(){
	this.enable();
   }

  public void stop(){
	this.disable();
  }

}
        

class PlainData {
 int item[];
 int n;
 String name;
 

  public void init(String str){


	StringTokenizer st = new StringTokenizer(str,",");
	String str_tmp;

	n = st.countTokens();

	n = n - 1;
	name = st.nextToken();
	item = new int[n];
	for(int i=0;i < n;i++){
	    item[i] = Integer.parseInt(st.nextToken());
	    }
  }
}     




















