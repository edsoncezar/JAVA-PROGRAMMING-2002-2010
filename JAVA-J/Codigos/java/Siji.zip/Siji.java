/*********************************************************
   Applet  : Siji.java - My 4th Java Applet Game
   Version : 1.30
   Author  : Riza Purwo Nugroho <rizapn@ratelindo.co.id>
   Date    : August 9, 2000
   Update  : August 9, 2000
**********************************************************/

import java.applet.*;
import java.awt.*;
import java.awt.image.*;
import java.net.*;
import java.util.*;

public class Siji extends Applet implements Runnable
{
  static int MAX_X=12, MAX_Y=10, MAX_LVL=100, MAX_IMG=5;
  static int xRect = 24, yRect = 24;
  static int X_0 = 5, Y_0 = 5, BALL_CODE = 4;
  static int maxHist = 200;

  Thread game0 = null;

  private Image[] xImg = new Image[MAX_IMG+1];
  private int gLevel, mvPos, maxMove, dlyBall, num, xPos, yPos;
  private byte[][] currCanvas = new byte[MAX_Y+1][MAX_X+1];
  private byte firstTime;
  private int[] hst = new int[maxHist+1];

  private Button btn1  = new Button("X");
  private Button btnN2 = new Button(">>");
  private Button btnN  = new Button(">");
  private Button btnP  = new Button("<");
  private Button btnP2 = new Button("<<");
  private Button btnU  = new Button("U");

  private static String stGameEnd = " [GAME END]";
  private static String stYouLose = " [YOU LOSE]";

  private static String mCode = " =#.xo,123456789ABCDEFGHIJKLMN";
  private static int xCoord[][] =
    {{      0,     0,xRect,yRect},
     {  xRect,     0,xRect,yRect},
     {2*xRect,     0,xRect,yRect},
     {      0, yRect,xRect,yRect},
     {  xRect, yRect,xRect,yRect},
     {2*xRect, yRect,xRect,yRect},
    };

  private static String biDat[] = {
    ", 3#4, 2#1.x.#, 2#.x.1#, 2#x#x.#, 2#x.x.#, 2#.1#2, 2#.#1, 2#2,,",
    ",, 2#3, 2#.1#2, 2#.x1.#, 2#x3#1, 1#1.1x.1#, 1#.2#3, 1#1.#1, 2#2,,",
    ", 1#2, 1#.#5, 1#.#.x#.#, 1#.x.x.1#, 1#.x3.#, 1#1.1x1.#, 2#4.#, 6#2,,",
    ", 2#5, 2#x1.1#1, 1#1x1.2#, 1#.x1.2#, 1#1x2.#1, 2#1.x.1#, 3#.1#2, 3#3,,",
    ",, 4#4, 3#1.2#, 2#1.3#, 1#1x1.2#, 1#x3.#1, 1#1.x#2, 2#3,",
    ",, 1#4, 1#.2#1, 1#.x1.#, 1#1.2#2, 2#1.x.1#, 3#1x2#, 4#4,",
    ", 3#3, 3#.1#1, 2#1x1.#1, 2#.x.x1#, 2#.1x.1#, 2#1x1#2, 1#1.x.#, 1#.2#1, 1#4,",
    ",, 3#4, 2#1.x.#, 2#.2x#, 2#1.x1#1, 2#x1.1x#, 2#.3#1, 2#5,",
    ", 1#8, 1#x.x1.x.#, 1#1x#2x1#, 1#1.# #x1#, 1#.x#3.#, 1#.#2.2#, 1#.#2.#.#, 1#3.1#2, 4#3,,",
    ", 2#5, 2#.1x.#, 2#.x1#1, 2#.x1#1, 2#x.x.#1, 2#.1x1.#, 2#.#.1#1, 2#.#3, 2#2,,",
    ",,, 1#4, 1#.2#2, 1#.1x1.#, 1#.1x1#3, 1#.2x.x1#, 1#8,,",
    ", 2#3, 1#1.1#3, 1#.2x1.#, 1#1.x.x#1, 2#1x1#1, 3#.x#1, 3#.2#, 3#4,,",
    ", 5#2, 4#1x#1, 3#1x1.#, 3#.x2#1, 3#.2x1#, 3#.#.2#, 3#.3#1, 3#5,,",
    ", 7#3, 2#5x.#, 2#.x.#1x.#,#3x3.x.#,#.2#.#5,#.1x1.#,#.1#3,#3,,",
    ", 2#6, 1#1.1#x.#, 1#x1.3#, 1#.1#x1.#, 1#3x1#1, 4#1.1#, 5#3,,",
    ", 6#2, 3#3.#, 2#1.x.1#, 2#.1x.1#, 2#.x2#1, 2#x.x1#, 2#2.1#, 4#1.#, 5#2,,",
    ",, 6#2, 1#5.#, #1.1x1.1#, #.2x1.1#1, #2.x1.x1#, 2#1x1.1#1, 3#1.#2, 4#2,,",
    ", 4#2, 2#2.#3, 1#1x.4#, #1.x#5, #.x.#1, #x2.#, #2.#1, 2#2,,",
    ",, 6#2, 2#4.#, 2#.1x1.#, 2#x.x1.#, 2#x.x1.#, 2#.4#, 2#6,,",
    ",, 2#4, 1#1.2#3, 1#x1.1#1.#, 1#.x2#1.#, 1#1x.x1.1#, 2#1x.1#.#, 3#6,,,",
    ",, 1#6, 1#.1x.1#, 1#.x2.#, 1#2.x.#1, 3#x#.1#, 3#.#3, 3#2,,",
    ",, 1#3, #1.x#2, #.x1.x#2, #2.x1.1#, 2#x#1.#2, 2#1.4#, 3#6,,",
    ",, 2#7, 1#1.1#.x.#, 1#.3x1.#, 1#.x1.x.x#, 1#1.#.x1#1, 2#6,,",
    ",, 2#4, 2#.2#1, 2#.1x1#2, 2#.1x1.1#, 2#x1.1#2, 2#5,,",
    ",, 2#7, 2#.x#.2#, 2#x1.1x1#, 2#.x.2#1, 2#.x#3, 2#.#1, 2#2,,",
    ",, 1#4, 1#x2#1, 1#x1.x#, 1#2.1#2, 1#1.x2.#2, 1#.2x.3#, 1#.1#2.#2, 1#3 #2,,",
    ",,, 2#6, 2#.#x.1#1, 2#.1x#.1#, 2#.x1.x.#, 2#4x.#, 6#3,,",
    ",, 2#7, 2#.1x1.1#, 2#1x1.#.#, 3#2.x1#, 5#.1#1, 5#.1#, 5#3,,",
    ", 5#2, 1#4.#, 1#.4#, 1#.1x.1#1, 1#2.x2#, 3#1x2#, 4#1.#1, 5#2,,",
    ",, 2#3, 2#.x# #2, 2#.x#2.#, 2#x.#.2#, 1#1x3.#1, 1#x.1#1.1#, 1#6.#, 7#2,,",
    ", 3#4, 3#.2#, 1#2.x.#2, 1#.2x.2#, 1#.x4.#, 1#.2x.2#, 1#2.x.#2, 3#.2#, 3#4,,",
    ", 3#4, 3#x2#, 1#2x2#2, 1#.1x2.1#, 1#.1x.x.1#, 1#.6#, 1#2.2#2, 3#.2#, 3#4,,",
    ", 3#4, 3#.2#, 1#2.x.#2, 1#.1x2.1#, 1#.x4.#, 1#x6#, 1#2.2#2, 3#.2#, 3#4,,",
    ", 3#4, 3#.x.#, 1#2x2#2, 1#.x4.#, 1#.2x.2#, 1#.2x.2#, 1#2x2#2, 3#x2#, 3#4,,",
    ", 3#4, 3#.x.#, 1#2x2#2, 1#.x4.#, 1#.1x2.1#, 1#.x4.#, 1#2x2#2, 3#.x.#, 3#4,,",
    ", 3#4, 3#.x.#, 1#2x2#2, 1#.x4.#, 1#x2.x2#, 1#.x4.#, 1#2x2#2, 3#.x.#, 3#4,,",
    ", 3#4, 3#x2#, 1#2x2#2, 1#x6#, 1#x2.x2#, 1#x6#, 1#2x2#2, 3#x2#, 3#4,,",
    " 3#4, 3#x2#, 3#x2#, #3x2#3, #x8#, #x3.x3#, #x8#, #3x2#3, 3#x2#, 3#x2#, 3#4,,",
    " 2#9, 2#.1#.x1.1#, 2#.x#x2.1#,#3.x.x.1x.#,#.#1x2.x2.#,#.4x2.1x#,#.1#.#x5#,#.1#.1#x.x1.#,#4.x2.x1#, 3#2.3#1, 5#5,,",
    " 1#8, 1#.#.2#.#1, 1#.x.#.#.1#, 1#1x.5#, 1#.3x1.1#, 1#.1x2.x1#, 1#.x2.3#, #2x2#.x1#,#1x3.x3#,#x1.x1.x.#2,#9,,",
    "#3 #6,#.x#2.4#,#.x.x1.4#,#x2#x1.3#,#.x4.3#,#1.x3.#.1#,#x5.#3,#.x1#.2#,#.#6,#2,,",
    " 2#2, #2x#2,#1x.x2#2,#.x5.#,#.x1.x1.1#3,#x1.x1.2#1.#,#.x.1x2.3#,#.x5.3#,#.x3.5#,#.1x1.6#,#C,,",
    " 5#2, 5#.#,#6.#3,#.1#1.x1.2#1,#.4x.x3#,#.4x3.x#,#.2x4.x1#,#.3x6#,#.5x2.x#,#C,,",
    "#8,#.#1.x1.#2,#.1#x4.#,#x1.x4.#,#.#1.x4#1,#.x1.x2.2#,#.2x.x#.1#1,#1.2x.#3, #.2x.#, #.#.2#, #6,,",
    ", #B,#1.x#.1x1.2#,#.2x2.x.x1#,#2x2.1x1.1#, 1#x3.#.2#, 1#x3#.2#1, 1#x.x.x1.2#, 1#1.1#1.1#2, 2#7,,",
    " 5#2, 5#.#3,#6x.2#,#.6x1#1,#.x.x4.1#,#1x4.2#1,#x4.#.2#,#x1.x1.x1.#1,#.x2#.4#,#1.x1.2#3, #7,,",
  };

  private static int aMove[] = {
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,
    };

  private Image mainImg;
  private Graphics g;
  private TextField txt1;

  public void init()
  {
    String param;
    int i;

    if (g==null) g = getGraphics();

    URL url = getCodeBase();

    String str = "";
    int b = 0;

    MediaTracker tracker = new MediaTracker(this);
    mainImg = getImage(url, "Images.gif");
    tracker.addImage(mainImg,0);

    for (i=0; i<=MAX_IMG; i++)
      {
        xImg[i] = extractImage(xCoord[i]);
        tracker.addImage(xImg[i], i+1);
      }

    try { tracker.waitForAll(); }
    catch (InterruptedException e) {}

    setLayout(new BorderLayout());

    txt1 = new TextField(17);
    txt1.setForeground(new Color(255,255,204));
    txt1.setBackground(new Color(102,51,51));
    txt1.setEditable(false);

    Panel p = new Panel();

    p.add(txt1);
    p.add(btnP2);
    p.add(btnP);
    p.add(btnN);
    p.add(btnN2);
    p.add(btnU);
    p.add(btn1);

    add("South", p);

    gLevel = 0;
    dat2Canvas(0);
    firstTime = 1;
    dlyBall = 30;
  }

  public void start()
  {
    if (game0==null) 
     {
       game0 = new Thread(this);
       game0.start();
     }
  }

  public void stop()
  {
    if (game0 != null)
     {
       game0.stop();
       game0 = null;
     }
  }

  public void run()
  {
  }

  public boolean dat2Canvas(int dlvl)
  {
    int i,x,y,tmp0;
    byte z = 0, oz = 0;
    String param;

    try
     {
       gLevel += dlvl;
       if (gLevel<0) gLevel = 0;

       try { i = Integer.parseInt(getParameter("maxmove"+gLevel)); }
       catch (NumberFormatException e) { i = 0; }

       param = getParameter("data"+gLevel);
       if (i>0) maxMove = i;

       if (param==null || i<=0)
        { 
          param = biDat[gLevel];
          maxMove = aMove[gLevel];
        }
     }
    catch (ArrayIndexOutOfBoundsException exc)
     { 
       gLevel -= dlvl; 
       param = biDat[gLevel];
       maxMove = aMove[gLevel];
     }

    for (y=0; y<=MAX_Y; y++)
      { for (x=0; x<=MAX_X; x++)
          { currCanvas[y][x] = 0; }
      }

    x = y = 0;
    for (i=0; i<param.length(); i++)
      {
        z = (byte)(mCode.indexOf(param.charAt(i)));
        if (z>MAX_IMG)
         {
           if ((tmp0 = (z-MAX_IMG-1))>0)
            {
              for (int j=0; j<tmp0; j++)
                {
                  try { currCanvas[y][x++] = oz; }
                  catch (ArrayIndexOutOfBoundsException exc) { j = tmp0; }
                }
            }
           else
            {
              x = 0; y++;
              if (y>MAX_Y) break;
            }
         }
        else if (x<=MAX_X)
         {
           if (z<0) z = 0;
           currCanvas[y][x++] = z;
           oz = z;
         }
      }
    xPos = yPos = -1;
    mvPos = 0;

    for (x=0; x<=maxHist; x++) hst[x] = 0;

    if (maxMove>0) { txt1.setText(" Level "+gLevel+" ("+maxMove+" step max.)"); }
       else { txt1.setText(" Level "+gLevel); }
    if (firstTime==1) firstTime = 0;

    return true;
  }

  public int checkStep(int x, int y)
  {
    int  h = 0;
    byte z0 = (byte)(BALL_CODE-1);
    byte z1 = (byte)BALL_CODE;

    if (currCanvas[y][x]==z1)
     {
       if ((currCanvas[y-1][x]==z1 && currCanvas[y-2][x]==z0) ||
           (currCanvas[y+1][x]==z1 && currCanvas[y+2][x]==z0) ||
           (currCanvas[y][x-1]==z1 && currCanvas[y][x-2]==z0) ||
           (currCanvas[y][x+1]==z1 && currCanvas[y][x+2]==z0)) h = 1;
     }
    else h = -1;

    return h;
  }

  public int gameEnd()
  {
    byte z0 = (byte)(BALL_CODE-1);
    byte z1 = (byte)(BALL_CODE);
    byte z2 = (byte)(BALL_CODE+1);
    int h = 0, ch = 0;
    int x,y,i;

    y = 2;
    while (y<MAX_Y-1 && h==0)
    {
      x = 2;
      while (x<MAX_X-1 && h==0)
      {
        i = checkStep(x,y);
        if (i>=0) { ch++; if (i>0) h = 1; }
        x++;
      }
      y++;
    }

    if (ch>1 && h==0) h = -1;
    
    return h;
  }

  public boolean mouseDown(Event e, int x, int y)
  {
    int  dx,dy;
    byte z0;
    int  h = 0;
    byte old = 0;
    int  x2,y2,x1,y1;

    x2 = (x-X_0)/xRect;
    y2 = (y-Y_0)/yRect;
    if (x2<0 || x2>MAX_X || y2<0 || y2>MAX_Y) return true;

    if (xPos>=0 && yPos>=0 && xPos<=MAX_X && yPos<=MAX_Y) old = currCanvas[yPos][xPos];

    z0 = currCanvas[y2][x2];
    h = checkStep(x2,y2);
    if (z0==BALL_CODE+1) { z0 -= 1; h = 1; }
    else if (h>0) { z0 += 1; h = 1; }
    else
     {
       dx = (x2-xPos)/2; x1 = x2-dx;
       dy = (y2-yPos)/2; y1 = y2-dy;
       if (old==BALL_CODE+1 &&
           (((dx==1 || dx==-1) && dy==0) || ((dy==1 || dy==-1) && dx==0)) &&
           currCanvas[y1][x1]==BALL_CODE
          )
        {
          changeCanvas(xPos,yPos,BALL_CODE-1);
          changeCanvas(x1,y1,BALL_CODE-1);
          z0 = (byte)BALL_CODE;

          hst[mvPos % maxHist] = 16*y2 + x2 + 256*((1+dx)+4*(1+dy));

          old = 0; mvPos++;
          h = 2;
        }
     }

    if (h>0)
     {
       if (old>=BALL_CODE)
        {
          changeCanvas(xPos,yPos,BALL_CODE);
        }
       xPos = x2;
       yPos = y2;
       changeCanvas(x2,y2,z0);
       if (h==2)
        {
          h = gameEnd();
          if (h==0) { txt1.setText(stGameEnd); h = -99; }
          else if (h==-1) { txt1.setText(stYouLose); h = -100; }
          else { txt1.setText("Level "+gLevel+" step "+mvPos); }
        }
     }

    if (h<=-99)
     {
       try { game0.sleep(400); }
       catch (InterruptedException exp) {}
       if (dat2Canvas(h+100)) paint(null);
     }

    return true;
  }

  public void changeCanvas(int x, int y, int z0)
  {
    currCanvas[y][x] = (byte)z0;
    g.drawImage(xImg[z0],X_0+xRect*x,Y_0+yRect*y,this);
  }

  public boolean action(Event e, Object arg)
  {
    int h = 0;

    if      (e.target==btnP)  h = 106;
    else if (e.target==btnN)  h = 107;
    else if (e.target==btn1)  h = 27;
    else if (e.target==btnP2) h = 104;
    else if (e.target==btnN2) h = 108;

    if (h>0) keyDown(e, h);

    return true;
  }

  public boolean keyDown(Event e, int c)
  {
    int h = 0;

    switch (c)
    {
      case  8:  if (mvPos>0) doUndo(); break;
      case 27:  if (mvPos==0 && firstTime==0) { firstTime = 1; paint(null); return true; }
                h = 100; break;
      case 104: h =  89; break;
      case 106: h =  99; break;
      case 107: h = 101; break;
      case 108: h = 111; break;
      default: txt1.setText("Key "+c+" is not defined"); return true;
    }

    if (h>0) { if (dat2Canvas(h-100)) paint(null); }

    return true;
  }

  private void doUndo()
  {
    int ch,h,x,y,dx,dy;

    mvPos--;
    h = hst[mvPos % maxHist];
    hst[mvPos] = 0;

    ch = h/256;
    dx = (ch % 4) - 1;
    dy = ((ch / 4) % 4) - 1;

    x  = h % 16;
    y  = (h / 16) % 16;

    txt1.setText("Back to step "+mvPos);

    ch = BALL_CODE-1;
    for (h=0; h<3; h++)
      {
        changeCanvas(x,y,ch);
        ch = BALL_CODE;
        x -= dx; y -= dy;
      }

  }

  private Image extractImage(int[] xyCoord)
  {
    Image newImage;
    ImageFilter filter;
    ImageProducer producer;

    filter = new CropImageFilter(xyCoord[0],xyCoord[1],xyCoord[2],xyCoord[3]);
    producer = new FilteredImageSource(mainImg.getSource(), filter);
    newImage = createImage(producer);
    return newImage;
   }

  public void paint(Graphics g)
  {
    byte z;
    int  x2,y2,xe,x,y;

    if (g==null) g = getGraphics();
    y2 = Y_0;
    xe = X_0+xRect*(MAX_X+1);
    for (y=0; y<=MAX_Y; y++)
      {
        //g.drawImage(xImg[1],X_0-20,y2,this);
        //g.drawImage(xImg[1],xe,y2,this);
        x2 = X_0;
        for (x=0; x<=MAX_X; x++)
          {
            z = currCanvas[y][x];
            if (firstTime==1 || z>MAX_IMG) z = 0;
            g.drawImage(xImg[z],x2,y2,this);
            x2 += xRect;
          }
        y2 += yRect;
      }
    if (firstTime==1) doFirstTime();
  }

  public void doFirstTime()
  {
    int y,x;
    int c;

    y = 20;
    x = X_0 + 15;
    g.setColor(new Color(255,255,204));
    String str = "* Siji v0.9 *";
    g.drawString(str,x,y);
    txt1.setText(str);
    y += 20; g.drawString("(Java Applet version) 2000 by Riza PN",x,y);
    y += 20; g.drawString("Siji is a word of 'One' in Javanesse language.",x,y);
    y += 20; g.drawString("The goal is to take all object until the last one by jump over",x,y);
    y += 15; g.drawString("another object. Click one object, jump over another object,",x,y);
    y += 15; g.drawString("move it to the blank place, and it will clear the middle object.",x,y);
    y += 15; g.drawString("Repeat it until there is only one object in the screen.",x,y);
    y += 15; g.drawString("Press U button or use Backspace to undo the last move (it",x,y);
    y += 15; g.drawString("can do until 200 last steps). Press X button or Esc key to",x,y);
    y += 15; g.drawString("restart the game. Use h,j,k,l to change the level.",x,y);
    y += 15; g.drawString("Almost all level is based on its similar game from internet.",x,y);
    y += 20; g.drawString("Hope you enjoy it...",x,y);
    y += 20; g.drawString("Salam",x,y);
    y += 15; g.drawString("Riza Purwo Nugroho, Jakarta-Indonesia",x,y);
  }

}
