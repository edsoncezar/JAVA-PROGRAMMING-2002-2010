/*Applet by Gurpreet singh ahluwalia
E-mail at gurpreet_gh761230@rediffmail.com

This applet creates moving lines with animated effects just like any screensaver with very simple code.
The programme is complied in jdk1.2.1 version.
*/


import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class linesdemo extends Applet implements Runnable,ActionListener

{

Button b1;

Thread t,t1,t2,t3,color;

//t1 for leftx to travel to left direction
//t2 for rightx to travel to left direction
//t3 for sparkles effect
//color for changing line color




int linecolor=5; //for lines color
int sparkles=0; //for sparkles


//create object to avoid flickering;
Image flick;
Graphics gflick;

int leftx=200; //x'axes which will travel to left direction
int rightx=200; //x'axes which will travel to right direction

int y1=200; //starting y'axes




public void init()
{

flick=createImage(size().width,size().height);
gflick=flick.getGraphics();


b1=new Button("animate");
b1.addActionListener(this);
add(b1);

t1=new Thread(this);
t2=new Thread(this);
t3=new Thread(this);
color=new Thread(this);

t1.start();
t2.start();
t3.start();
color.start();


}

public void run()
{
t=Thread.currentThread();

if(t==t1)
{
while(true)
{
for(leftx=200;leftx>0;leftx--)
{
try{
t1.sleep(20);
}
catch(Exception e){}
repaint();

}

}
}
if(t==t2)
{
while(true)
{
for(rightx=200;rightx<=400;rightx++)
{
try
{
t2.sleep(20);
}

catch(Exception e){}
repaint();
}
}
}

if(t==color)
{
while(true)
{

for(linecolor=5;linecolor<=255;linecolor++)
{

if(linecolor==255)
{
for(linecolor=255;linecolor>=5;linecolor--)
{

try{
color.sleep(50);
}
catch(Exception e){}

repaint();
}
}
try{
color.sleep(50);
}
catch(Exception e){}

repaint();

}
}
}

if(t==t3)
{

while(true)
{

sparkles=(int)(Math.round(Math.random())*255);

try{

t3.sleep(500);
}

catch(Exception w) { }
repaint();

}
}


}



public void paint(Graphics g)
{

gflick.setColor(Color.black);

gflick.fillRect(0,0,size().width,size().height);



//create color object to change color of lines
Color c=new Color(150,50,linecolor);

gflick.setColor(c);



for(int i=0;i<size().width;i=i+30)
{

gflick.drawLine(200,y1,rightx,0+i); //draws ending y'axes for rightxline

gflick.drawLine(200,y1,leftx,0+i); //draws ending y'axes for leftxline

}

//create color object to create effects of sparkles

Color c1=new Color(sparkles,sparkles,sparkles);

gflick.setColor(c1);

      for(int i1=0;i1<10;i1++)
        {
       int x=(int)(getSize().width*Math.random());//draws random sparkles in width of applet
      int y=(int)(getSize().height*Math.random());//draws random sparkles in width of applet

        gflick.fillRect(x,y,(int)1.5,(int)1.5);
       }





g.drawImage(flick,0,0,this);
}
public void update(Graphics g)
{
paint(g);
}                          

public void actionPerformed(ActionEvent ae)
{
if(ae.getSource()==b1)
{

// to change the postion of lines on click

leftx=(int)(Math.round(Math.random())*400);

rightx=(int)(Math.round(Math.random())*400);

y1=(int)(Math.random()*300);




}


 }

}

 
