

import java.applet.*;
import java.awt.*;
import java.net.*;

class Animate extends Thread
{
  animateButton b;

  public Animate(animateButton who)
  {
    b = who;
  }

  public void run()
  {
    while(b.running)
    {
	b.advanceFrame();
  	b.repaint();
	try
	{
	  sleep(b.sleeptime);
	}
	catch(Exception e){}
    }
  }
}

public class animateButton extends Applet
{
  int nframe;
  Image image[];
  AudioClip audio;
  URL url;
  String target;
  int sleeptime;
  MediaTracker tracker;
  Animate animate;
  int frame;
  boolean running;

  private Image offScreenImage;
  private Dimension offScreenSize;
  private Graphics offScreenGraphics;

  public void advanceFrame()
  {
	frame = (frame + 1) % nframe;
  }

  public void init()
  {
	String parameter;

	// init number of frames
	parameter = getParameter("nframe");
	if (parameter == null)
	  System.out.println("Error: invalid parameter: nframe");
	else
	  nframe = Integer.parseInt(parameter);

	// init images
	image = new Image[nframe];
	tracker = new MediaTracker(this);
	for (int i = 0; i < nframe; i++)
	{
	  parameter = getParameter("image"+i);
	  if (parameter == null)
	    System.out.println("Error: invalid parameter: image"+i);
	  else
	  {
	    image[i] = getImage(getDocumentBase(), parameter);
	    tracker.addImage(image[i], i);
	  }
	}
	try
	{
	  tracker.waitForAll();
	}
	catch (InterruptedException e)
	{
	  System.out.println("Error waiting for image to load.");
	}

	// init audio
	parameter = getParameter("audio");
	if (parameter != null)
	  audio = getAudioClip(getDocumentBase(), parameter);

	// init url
	parameter = getParameter("url");
	if (parameter != null)
	{
	  try
	  {
	    url= new URL(parameter);
	  }
	  catch(MalformedURLException mal)
	  {
	    System.out.println("Error locating URL address.");
	  }
	}

	// init target window
	target = getParameter("target");

	// init sleep time
	parameter = getParameter("sleeptime");
	if (parameter == null)
	  sleeptime = 1000;
	else
	  sleeptime = Integer.parseInt(parameter);	  
  }

  public void paint (Graphics g)
  {
    g.drawImage(image[frame], 0, 0, null);    
  }

  public final synchronized void update (Graphics g)
  {
    Dimension d = size();
    if((offScreenImage == null) || (d.width != offScreenSize.width) ||  (d.height != offScreenSize.height))
    {
      offScreenImage = createImage(d.width, d.height);
      offScreenSize = d;
      offScreenGraphics = offScreenImage.getGraphics();
    }
    offScreenGraphics.setColor(getBackground());
    offScreenGraphics.fillRect(0, 0, d.width, d.height);
    paint(offScreenGraphics);
    g.drawImage(offScreenImage, 0, 0, null);
  }

  public void stop()
  {
	running = false;
	destroy();
  }

  public boolean mouseDown(Event evt, int x, int y)
  {
	if (audio != null)
          audio.play();
	return true;
  }
  public boolean mouseUp(Event evt, int x, int y)
  {
	if (url != null)
	{
	  if (target != null)
	    getAppletContext().showDocument(url, target);
	  else
	  getAppletContext().showDocument(url);
	}
	return true;
  }

  public boolean mouseEnter(Event evt, int x, int y)
  {
	running = true;
        animate = new Animate(this);
        animate.start();
	return true;
  }

  public boolean mouseExit(Event evt, int x, int y)
  {
	running = false;
	return true;
  }
}
