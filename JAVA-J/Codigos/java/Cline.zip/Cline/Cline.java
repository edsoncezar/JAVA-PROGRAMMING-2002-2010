/**********************************************************************
// Cline is copyrighted by Linda Carpenter
//
// Portions of this source code may be used in your projects
//   as you wish...
// Use the Applet Cline.class wherever you want...
// This copyright notice must remain on all copies of this unmodified source
//
***********************************************************************/
   
import java.applet.*;
import java.awt.*;
import java.net.URL;
import java.net.MalformedURLException;

public class Cline extends Applet implements Runnable
{
	Thread	 m_Cline = null;

	static int numLines = 10;

	private int m_Width = 0;
	private int m_Height = 0;
	private int f_Width = 0;
	private int f_Height = 0;

	private int m_Speed = 0;
	private String m_URL = "";

	URL goURL;

	Dimension offDimension;
	Image offImage;
	Graphics offGraphics;

	boolean buttonPressed = false;
	boolean overButton = false;

	private final String PARAM_Speed = "Speed";
	private final String PARAM_URL = "URL";

	int[] end0x = new int[numLines];
	int[] end0y = new int[numLines];
	int[] end1x = new int[numLines];
	int[] end1y = new int[numLines];
	int[] dir0x = new int[numLines];
	int[] dir0y = new int[numLines];
	int[] dir1x = new int[numLines];
	int[] dir1y = new int[numLines];

	public Cline()
	{
	}

	public String getAppletInfo()
	{
		return "Name: Cline\r\n" +
		       "Author: Linda Carpenter\r\n" +
		       "(c) Copyright 1998 by author";
	}

	public String[][] getParameterInfo()
	{
		String[][] info =
		{
			{ PARAM_Speed, "int", "Parameter description" },
			{ PARAM_URL, "String", "Parameter description" },
		};
		return info;		
	}

	public void init()
	{
		String param;
		int i,j,k;
		Graphics g;
		Dimension d;

		g = getGraphics();
		d = size();

		f_Width = d.width;
		f_Height = d.height;
		m_Width = f_Width - 8;
		m_Height = f_Height - 8;

		param = getParameter(PARAM_Speed);
		if (param != null)
			m_Speed = Integer.parseInt(param);

		param = getParameter(PARAM_URL);
		if (param != null)
			m_URL = param;

		try
		{
			goURL = new URL(m_URL);
		}
		catch(MalformedURLException mal)
		{
			System.out.println("Something is wrong with your URL, Check applet parameter.");
		}

		j = m_Width/2;
		k = m_Height/2;
		for(i=0;i<numLines;i++)
		{
			end0x[i] = j;
			end0y[i] = k;
			end1x[i] = j;
			end1y[i] = k;
			while(dir0x[i]==0)
				dir0x[i] = (int)(5.0-Math.random()*10.0);
			while(dir0y[i]==0)
				dir0y[i] = (int)(6.0-Math.random()*10.0);
			while(dir1x[i]==0)
				dir1x[i] = (int)(4.0-Math.random()*10.0);
			while(dir1y[i]==0)
				dir1y[i] = (int)(5.0-Math.random()*10.0);
		}	
	}

	public void destroy()
	{
	}

	public void update(Graphics g)
	{
		paint(g);
	}

	public void paint(Graphics g)
	{
		int i,j;
 		Dimension d = size();

		if (offGraphics == null || d.width != offDimension.width || d.height != offDimension.height) {
			offDimension = d;
			offImage = createImage(d.width, d.height);
			offGraphics = offImage.getGraphics();
		}

		offGraphics.setColor(Color.lightGray);
		offGraphics.fill3DRect(0,0,f_Width,f_Height,true);
		offGraphics.setColor(Color.black);
		offGraphics.fillRect(4,4,m_Width,m_Height);
		for(i=0; i< numLines; i++) 
		{
			j = i % 4;
			switch(j) 
			{
				case 0:
					offGraphics.setColor(Color.yellow);
					break;
				case 1:
					offGraphics.setColor(Color.blue);
					break;
				case 2:
					offGraphics.setColor(Color.pink);
					break;
				case 3:
					offGraphics.setColor(Color.white);
					break;
			};
			offGraphics.drawLine(end0x[i],end0y[i],end1x[i],end1y[i]);
		}
		g.drawImage(offImage, 0, 0, this);
	}

	public void start()
	{
		if (m_Cline == null)
		{
			m_Cline = new Thread(this);
			m_Cline.start();
		}
	}
	
	public void stop()
	{
		if (m_Cline != null)
		{
			m_Cline.stop();
			m_Cline = null;
		}
	}

	public void updateLine(int i)
	{
		end0x[i] += dir0x[i];
		end0y[i] += dir0y[i];
		end1x[i] += dir1x[i];
		end1y[i] += dir1y[i];

		if(end0x[i]<2)
		{
			end0x[i] = 2;
			dir0x[i] = -1*dir0x[i];
		}
		if(end0x[i]>=m_Width)
		{
			end0x[i] = m_Width-1;
			dir0x[i] = -1*dir0x[i];
		}
		if(end0y[i]<2)
		{
			end0y[i] = 2;
			dir0y[i] = -1*dir0y[i];
		}
		if(end0y[i]>=m_Height)
		{
			end0y[i] = m_Height-1;
			dir0y[i] = -1*dir0y[i];
		}
		if(end1x[i]<2)
		{
			end1x[i] = 2;
			dir1x[i] = -1*dir1x[i];
		}
		if(end1x[i]>=m_Width)
		{
			end1x[i] = m_Width-1;
			dir1x[i] = -1*dir1x[i];
		}
		if(end1y[i]<2)
		{
			end1y[i] = 2;
			dir1y[i] = -1*dir1y[i];
		}
		if(end1y[i]>=m_Height)
		{
			end1y[i] = m_Height-1;
			dir1y[i] = -1*dir1y[i];
		}
	}

	public void run()
	{
		int i;

		while (true)
		{
			try
			{
				for(i=0;i<numLines;i++)
					updateLine(i);
				repaint();
				Thread.sleep(m_Speed);
			}
			catch (InterruptedException e)
			{
				System.out.println("Barf");
				stop();
			}
		}
	}

	public boolean mouseDown(Event evt, int x, int y)
	{
		buttonPressed = true;
		return true;
	}

	public boolean mouseUp(Event evt, int x, int y)
	{
		buttonPressed = false;
		getAppletContext().showDocument(goURL);
		return true;
	}

	public boolean mouseEnter(Event evt, int x, int y)
	{
		overButton = true;
		showStatus(m_URL);
		return true;
	}

	public boolean mouseExit(Event evt, int x, int y)
	{
		overButton = false;
		showStatus("");
		return true;
	}

}
