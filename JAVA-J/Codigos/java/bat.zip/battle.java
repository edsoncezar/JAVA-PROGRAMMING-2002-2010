//This program was completely written by Peter Wetsel.
//If there are any questions about this code you
//can email me at phwetsel@eos.ncsu.edu
//To get it to compile using jdk type "javac -nowarn battle.java".
//
//
//




import java.util.*;
import java.lang.*;
import java.awt.*;
import java.applet.*;
import java.net.*;
import java.lang.*;

public class battle extends java.applet.Applet implements Runnable {
	Color col;
	String message= new String("");//holds the message placed in the upper left
	String Status = new String("");
	String message2[]= new String[5];//holds the destroyed messages in order for repainting.
	int hits=0;//the total number of hits by the player
	int numDestroyed=0;//the number of ships destroyed by the player
	int battlepos[]=new int[4];//the 4 positions of the battleship
    int carrierpos[]=new int[5];//the 5 positions of the carrier
	int subpos[]=new int[3];//the 3 positions of the submarine
	int patrolpos[]=new int[2];//the 2 positions of the patrol boat
	int destroyerpos[]=new int[3]; //the 3 positions of the destroyer
	int guesses=0;// the number of guesses by the player
	int player[][]=new int[10][10]; //to hold the positions of the player.(not until version 2)
	int guessed[][]=new int[10][10]; //hold the places that have been guessed by the player
	int computer[][]=new int[10][10]; //holds where the computers ships are
	int battleshipHitCt, destroyerHitCt, subHitCt, patrolHitCt, carrierHitCt;//keeps the hit count for each of the ships
	boolean init=false;//false until play is pushed.
	boolean ok=false;//boolean that is true if current boat position chosen by random is ok(getcarrier(), etc.)
	boolean battleOK=true;//false when the type of ship is destroyed
	boolean patrolOK=true;//...
	boolean subOK=true;//...
	boolean destroyerOK=true;//...
	boolean carrierOK=true;//...
	boolean won=false;//true when the player has won
	int o;
	
	public void getCarrier(){
		int x, y, dir;  //will hold a random x & y coordinate(0-9), and a random direction(0-1)(N,E,S,W)
		x=(int)(10*Math.random());
		y=(int)(10*Math.random());
		dir=(int)(100*Math.random()/25);    
		if(dir==0)
		{
			while(y<4){
				y=(int)(10*Math.random());
			}
			for (int i=0; i<5; i++){
				computer[x][y-i]=1;
				carrierpos[i]=x*10+y-i;
			}
		}
		if (dir==1)
		{
			while(x>5){
				x=(int)(10*Math.random());
			}
			for (int i=0; i<5; i++){
				computer[x+i][y]=1;
				carrierpos[i]=(x+i)*10+y;
			}
		}
		if (dir==2)
		{
			while(y>5){
				y=(int)(10*Math.random());
			}
			for (int i=0; i<5; i++){
				computer[x][y+i]=1;
				carrierpos[i]=x*10+y+i;
			}
		}
		if (dir==3)
		{
			while(x<4){
				x=(int)(10*Math.random());
			}
			for (int i=0; i<5; i++){
				computer[x-i][y]=1;
				carrierpos[i]=(x-i)*10+y;
			}
		}
	}
	
	public void getBattle(){
		int x, y, dir;
		x=(int)(10*Math.random());
		y=(int)(10*Math.random());
		dir=(int)(100*Math.random()/25);    
		while(!ok){
			ok=true;
			x=(int)(10*Math.random());
			y=(int)(10*Math.random());
			dir=(int)(100*Math.random()/25);    
			if(dir==0)
			{
				while(y<3){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<4; i++){
					o=computer[x][y-i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==1)
			{
				while(x>6){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<4; i++){
					o=computer[x+i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==2)
			{
				while(y>6){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<4; i++){
					o=computer[x][y+i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==3)
			{
				while(x<3){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<4; i++){
					o=computer[x-i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
		}
		
		if(dir==0)
		{
			for (int i=0; i<4; i++){
				computer[x][y-i]=1;
				battlepos[i]=x*10+y-i;
			}
		}
		if (dir==1)
		{
			for (int i=0; i<4; i++){
				computer[x+i][y]=1;
				battlepos[i]=(x+i)*10+y;
			}
		}
		if (dir==2)
		{
			for (int i=0; i<4; i++){
				computer[x][y+i]=1;
				battlepos[i]=x*10+y+i;
			}
		}
		if (dir==3)
		{
			for (int i=0; i<4; i++){
				computer[x-i][y]=1;
				battlepos[i]=(x-i)*10+y;
			}
		}
		
	}
	
	public void getSub(){
		int x, y, dir;
		x=(int)(10*Math.random());
		y=(int)(10*Math.random());
		dir=(int)(100*Math.random()/25);    
		while(!ok){
			ok=true;
			x=(int)(10*Math.random());
			y=(int)(10*Math.random());
			dir=(int)(100*Math.random()/25);    
			if(dir==0)
			{
				while(y<2){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x][y-i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==1)
			{
				while(x>7){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x+i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==2)
			{
				while(y>7){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x][y+i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==3)
			{
				while(x<2){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x-i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
		}
		
		if(dir==0)
		{
			for (int i=0; i<3; i++){
				computer[x][y-i]=1;
				subpos[i]=x*10+y-i;
			}
		}
		if (dir==1)
		{
			for (int i=0; i<3; i++){
				computer[x+i][y]=1;
				subpos[i]=(x+i)*10+y;
			}
		}
		if (dir==2)
		{
			for (int i=0; i<3; i++){
				computer[x][y+i]=1;
				subpos[i]=x*10+y+i;
			}
		}
		if (dir==3)
		{
			for (int i=0; i<3; i++){
				computer[x-i][y]=1;
				subpos[i]=(x-i)*10+y;
			}
		}
		
	}
	
	public void getDestroyer(){
		int x, y, dir;
		x=(int)(10*Math.random());
		y=(int)(10*Math.random());
		dir=(int)(100*Math.random()/25);    
		while(!ok){
			ok=true;
			x=(int)(10*Math.random());
			y=(int)(10*Math.random());
			dir=(int)(100*Math.random()/25);    
			if(dir==0)
			{
				while(y<2){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x][y-i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==1)
			{
				while(x>7){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x+i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==2)
			{
				while(y>7){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x][y+i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==3)
			{
				while(x<2){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<3; i++){
					o=computer[x-i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
		}
		
		if(dir==0)
		{
			for (int i=0; i<3; i++){
				computer[x][y-i]=1;
				destroyerpos[i]=x*10+y-i;
			}
		}
		if (dir==1)
		{
			for (int i=0; i<3; i++){
				computer[x+i][y]=1;
				destroyerpos[i]=(x+i)*10+y;
			}
		}
		if (dir==2)
		{
			for (int i=0; i<3; i++){
				computer[x][y+i]=1;
				destroyerpos[i]=x*10+y+i;
			}
		}
		if (dir==3)
		{
			for (int i=0; i<3; i++){
				computer[x-i][y]=1;
				destroyerpos[i]=(x-i)*10+y;
			}
		}
		
	}
	
	public void getPatrol(){
		int x, y, dir;
		x=(int)(10*Math.random());
		y=(int)(10*Math.random());
		dir=(int)(100*Math.random()/25);    
		while(!ok){
			ok=true;
			x=(int)(10*Math.random());
			y=(int)(10*Math.random());
			dir=(int)(100*Math.random()/25);    
			if(dir==0)
			{
				while(y<1){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<2; i++){
					o=computer[x][y-i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==1)
			{
				while(x>8){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<2; i++){
					o=computer[x+i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==2)
			{
				while(y>8){
					y=(int)(10*Math.random());
				}
				for (int i=0; i<2; i++){
					o=computer[x][y+i];
					if (o==1){
						ok=false;
					}
				}
				
			}
			if (dir==3)
			{
				while(x<1){
					x=(int)(10*Math.random());
				}
				for (int i=0; i<2; i++){
					o=computer[x-i][y];
					if (o==1){
						ok=false;
					}
				}
				
			}
		}
		
		if(dir==0)
		{
			for (int i=0; i<2; i++){
				computer[x][y-i]=1;
				patrolpos[i]=x*10+y-i;
			}
		}
		if (dir==1)
		{
			for (int i=0; i<2; i++){
				computer[x+i][y]=1;
				patrolpos[i]=(x+i)*10+y;
			}
		}
		if (dir==2)
		{
			for (int i=0; i<2; i++){
				computer[x][y+i]=1;
				patrolpos[i]=x*10+y+i;
			}
		}
		if (dir==3)
		{
			for (int i=0; i<2; i++){
				computer[x-i][y]=1;
				patrolpos[i]=(x-i)*10+y;
			}
		}
		
	}
	
	public void run(){// to be in here so can compile
	}
	
	
	public void init() {
		
		for (int i=0; i<10; i++){//initializes the guessed matrix to be all 2's(not been guessed)
			for (int j=0;j<10; j++){
				guessed[i][j]=2;
			}
		}
		for (int i=0; i<2; i++){//initializes array to be all zeros
			patrolpos[i]=0;
		}
		for (int i=0; i<2; i++){
			destroyerpos[i]=0;
		}
		for (int i=0; i<2; i++){
			subpos[i]=0;
		}
		for (int i=0; i<2; i++){
			carrierpos[i]=0;
		}
		for (int i=0; i<2; i++){
			battlepos[i]=0;
		}
		battleshipHitCt=0;//initialize all hit counts
		destroyerHitCt=0;
		subHitCt=0;
		patrolHitCt=0;
		carrierHitCt=0;
	    //get all boat positions
		getCarrier();
		ok=false;
		getBattle();
		ok=false;
		getDestroyer();
		ok=false;
		getSub();
		ok=false;
		getPatrol();
	}
	
	public void paint(Graphics g) { //this is the shots paint method... draws a line from its last position to its current position, basically
	   if (!init && !won){//draws screen before play is pushed
			g.setColor(col.white);
			g.fillRect(0,0,600,320); 
			g.setColor(col.black);
			g.fillRect(20,20,30,25);
			g.setColor(col.white);
			g.drawString("PLAY", 23,30);
			g.setColor(col.black);
			g.drawString("This is different that usual battleship, here the goal is",23,65);
			g.drawString("to find all of the computers ships in the least number of guesses.",23,85);
			g.drawString("<30   turns  --- You have too much luck!", 23, 105);
			g.drawString("31-50 turns  --- Excellent!", 23, 125);
			g.drawString(">=51  turns  --- You have no skills!", 23, 145);
			g.drawString("PRESS PLAY TO BEGIN", 23, 165);
		}
		if (init && !won){//draws grid and messages
			g.setColor(col.black);
			g.fillRect(0,0,600,320); //makes big, black rectangle washover
			g.setColor(col.white);
			g.drawString("# of Guesses = " + guesses,500, 280);
			for (int i=0; i<11; i++)
				g.drawLine(20,20+i*28, 300, 20+i*28); 
			for (int i=0; i<11; i++)
				g.drawLine(20+i*28,20,20+i*28,300);
			char ch='A';
			for (int i=0; i<10; i++){//draws letter accross the top
				g.drawString(ch+" ",30+28*i,13);
				ch++;
			}
			ch='1';
			for (int i=0; i<9; i++){//draws numbers down the side
				g.drawString(ch+" ",10,40+28*i);
				ch++;
			}
			g.drawString("10", 6,290);
			g.drawString(message,420,40);
			for (int i=0; i<numDestroyed; i++){
				g.drawString(message2[i], 305, 40+(i+1)*20); 
			}
			g.setColor(col.black);
			//next puts in any circles already guessed
			for (int i=0; i<10; i++)
				for (int j=0; j<10;j++){
					if (guessed[i][j]==1)	 {
						g.setColor(col.red);
						g.fillOval(i*28+30, j*28+30, 10,10);
					}
					if (guessed[i][j]==0)	 {
						g.setColor(col.white);
						g.fillOval(i*28+30, j*28+30, 10,10);
					}
				}
		}
	}
	
	public boolean seeifahit(int x, int y){//sees if the shot was a hit or not
		if(computer[x][y]==1)
			return true;
		return false;
	}
	
	public String getshiptype(int x, int y){//returns the name of the ship that was hit
		for (int i=0;i<4; i++)
			if (battlepos[i]==x*10+y){
				battleshipHitCt++;
				return "Battleship";
		    }
		for (int i=0;i<3; i++)
			if (subpos[i]==x*10+y){
				subHitCt++; 
				return "Submarine";
			}
		for (int i=0;i<2; i++)
			if (patrolpos[i]==x*10+y){
				patrolHitCt++;
				return "Patrol Boat";
			}
		for (int i=0;i<5; i++)
			if (carrierpos[i]==x*10+y){
				carrierHitCt++;
				return "Carrier";
			}
		for (int i=0;i<3; i++)
			if (destroyerpos[i]==x*10+y){
				destroyerHitCt++;
				return "Destroyer";
			}
		return "  ";
	}
	
	public void gameOver(){//displays guesses and ends 
		if (!won){
			Graphics g = getGraphics() ;
			g.setColor(col.black);
			g.fillRect(0,0,600,320); //makes big, black rectangle washover
			g.setColor(col.white);
			g.drawString("YOU WIN!!", 200,100);
			String out=new String("It took you "+guesses+" tries!");
			g.drawString(out, 200,120);
			g.drawString("Press refresh on your browser to play again", 200, 150);
			won=true;  
		}
	}
	
	public boolean destroyed(){
		
		if(battleshipHitCt==4 && battleOK)
		{	
			battleOK=false;
			return true;
		}
		if(carrierHitCt==5 && carrierOK)
		{	
			carrierOK=false;
			return true;
		}
		if(subHitCt==3 && subOK)
		{	
			subOK=false;
			return true;
		}
		if(patrolHitCt==2 && patrolOK)
		{	
			patrolOK=false;
			return true;
        }
		if(destroyerHitCt==3 && destroyerOK)
		{	
			destroyerOK=false;
			return true;
		}
		return false;
	}
	
	public boolean mouseDown(Event e, int x, int y) {//handles when a mouse key is pressed(either key)
		String type= new String("");
		if (!won){
			message="";
			Graphics g = getGraphics() ;
			g.setColor(col.white);
			int xindex, yindex, val;
			if (x>20 && y>20 && y<300 && x<300 && init){
				guesses++;
				g.setColor(col.black);
				g.fillRect(490,260, 550, 285);		 
				g.setColor(col.white);
				g.drawString("# of Guesses = " + guesses,500, 280);
				g.setColor(col.black);
				g.fillRect(419,30,580,95);
				g.setColor(col.white);
				xindex=(x-20)/28;//converts x coordinate into index(A-J) in form of (0-9)
				yindex=(y-20)/28;//converst y coordinate into index(0-9)
				val=guessed[xindex][yindex];
				if (val==2){
					if (seeifahit(xindex,yindex)){
						type=getshiptype(xindex, yindex);
						hits++;
						g.setColor(col.white);
						guessed[xindex][yindex]=1;
						if (!destroyed()){
							message=type + " Hit";
							g.drawString(message, 420, 40);
						}
						else{
							g.setColor(col.white);
							message2[numDestroyed]=new String("");
							message2[numDestroyed]=type + "Destroyed";
							numDestroyed++;
							g.drawString(message2[numDestroyed-1] , 305, 40+(numDestroyed)*20);
						}
						g.setColor(col.red);
					}
					else guessed[xindex][yindex]=0;
					g.fillOval(xindex*28+30, yindex*28+30, 10,10);
				}
                else {
					g.setColor(col.white);
					message="That has already been guessed";
					g.drawString(message,420,40);
				}
			}
			
			if (x>20 && x<40 && y>20 && y<40 && !init){
				init=true;
				paint(g);
			}
			if (hits>=17){
				gameOver();
				System.exit(0);
			}
		}
		return true;
	}
}
