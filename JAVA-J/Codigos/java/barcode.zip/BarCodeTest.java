/*
 * @(#)BarCodeTest.java	1.00 97/Nov Umberto Marzo  umarzo@eniware.it
 *
 * Copyright (c) 1997 Umberto Marzo All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
 * THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR
 * ITS DERIVATIVES.
     Last change:  U    18 Dec 97    4:51 pm
 */
import java.applet.Applet;
import java.awt.*;
import BarCode3of9;

public class BarCodeTest extends Applet
{
    BarCode3of9 bc;
    // GUI components declaration
    Label l1,l2,l3,l4,l5,l6,l7,l8,l9;
    Panel p,p0,p1,p2,p3,p4,p5,p6,p7,p8,p9;
    TextField tf;
    Checkbox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8,cb9,cb10,cb11,cb12,cb13,cb14,cb15,cb16;
    CheckboxGroup cbg1,cbg2,cbg3,cbg4,cbg5;

    Choice ch=new Choice();
    Choice ch1=new Choice();
    int fontdim=8;

    public void init()  {
	p=new Panel();

        setLayout (new BorderLayout());
	setBackground (Color.lightGray);
	l1=new Label("Insert text to encode:");
       	tf=new TextField("HELLO",40);
        p1=new Panel();
	p1.add(l1);p1.add(tf);
	p.add(p1);

        l2=new Label("Select a variant:");
	ch.addItem("CODE3OF9");
        ch.addItem("CODE3OF9CHK");
	p2=new Panel();
	p2.add(l2);p2.add(ch);
	p.add(p2);

        l3=new Label("Choose a dimension:");
        cbg2=new CheckboxGroup();
	cb3=new Checkbox("small",cbg2,true);
        cb4=new Checkbox("medium",cbg2,false);
        cb5=new Checkbox("large",cbg2,false);
	p3=new Panel();
	p3.add(l3);p3.add(cb3);p3.add(cb4);p3.add(cb5);
	p.add(p3);

        l5=new Label("Text inside:");
        cbg1=new CheckboxGroup();
	cb1=new Checkbox("Text Yes",cbg1,true);
        cb2=new Checkbox("Text No",cbg1,false);
	p5=new Panel();
	p5.add(l5);p5.add(cb1);p5.add(cb2);
	p.add(p5);

        l6=new Label("Select a font:");
        Toolkit  toolKit=getToolkit();
        String[] fList=toolKit.getFontList();
        for(int n=0;n<fList.length;n++)
             ch1.addItem(fList[n]);

	p6=new Panel();
	p6.add(l6);p6.add(ch1);
	p.add(p6);

        l7=new Label("Font size:");
        cbg4=new CheckboxGroup();
	cb9=new Checkbox("8",cbg4,true);
        cb10=new Checkbox("10",cbg4,false);
        cb11=new Checkbox("12",cbg4,false);
        cb12=new Checkbox("14",cbg4,false);
        cb13=new Checkbox("16",cbg4,false);
	p7=new Panel();
	p7.add(l7);p7.add(cb9);p7.add(cb10);p7.add(cb11);p7.add(cb12);p7.add(cb13);
	p.add(p7);

        l8=new Label("Text alignment:");
        cbg5=new CheckboxGroup();
	cb14=new Checkbox("Baseline",cbg5,false);
        cb15=new Checkbox("Middleline",cbg5,false);
        cb16=new Checkbox("Topline",cbg5,true);
	p8=new Panel();
	p8.add(l8);p8.add(cb14);p8.add(cb15);p8.add(cb16);
	p.add(p8);

	add("Center",p);

	p0=new Panel();


        bc=new BarCode3of9();
	// customization of the component
        bc.setDimension ( BarCode3of9.SMALL );
        bc.setTextInside ( true );
	bc.setStyle ( BarCode3of9.CODE3OF9 );
        //bc.setBackground ( Color.lightGray );
	bc.setForeground ( Color.black );
	bc.setFont ( getFont() );
	bc.setTextAlign	( BarCode3of9.TOPLINE );
	// resize the component to fit a barcode of 8 char length string
	bc.resize(bc.requestedMinimunSize("12345678"));
        try {
           bc.setString("HELLO");
       	} catch (Exception e){}
	// finally add the component
        p0.add(bc);
        
	add("East",p0);
	

    }
    public boolean action( Event evt, Object arg )
    {
	if ( evt.target instanceof Checkbox ) {

            if (((Checkbox)evt.target).getLabel().equals("Text Yes")) {
	          bc.setTextInside(true);
                  cb9.enable();cb10.enable();cb11.enable();cb12.enable();cb13.enable();
                  cb14.enable();cb15.enable();cb16.enable();ch1.enable();
	    }
            if (((Checkbox)evt.target).getLabel().equals("Text No"))  {
	         bc.setTextInside(false);
		 cb9.disable();cb10.disable();cb11.disable();cb12.disable();cb13.disable();
                 cb14.disable();cb15.disable();cb16.disable();ch1.disable();
	    }
            if (((Checkbox)evt.target).getLabel().equals("small")) bc.setDimension(BarCode3of9.SMALL);
            if (((Checkbox)evt.target).getLabel().equals("medium")) bc.setDimension(BarCode3of9.MEDIUM);
            if (((Checkbox)evt.target).getLabel().equals("large")) bc.setDimension(BarCode3of9.LARGE);

            if (((Checkbox)evt.target).getLabel().equals("8"))  fontdim=8;
            if (((Checkbox)evt.target).getLabel().equals("10"))  fontdim=10;
	    if (((Checkbox)evt.target).getLabel().equals("12"))  fontdim=12;
            if (((Checkbox)evt.target).getLabel().equals("14"))  fontdim=14;
            if (((Checkbox)evt.target).getLabel().equals("16"))  fontdim=16;

            if (((Checkbox)evt.target).getLabel().equals("Baseline"))   bc.setTextAlign(BarCode3of9.BASELINE);
            if (((Checkbox)evt.target).getLabel().equals("Middleline")) bc.setTextAlign(BarCode3of9.MIDDLELINE);
	    if (((Checkbox)evt.target).getLabel().equals("Topline"))    bc.setTextAlign(BarCode3of9.TOPLINE);
	}

	if ( evt.target instanceof TextField ) {
	   try {
	   bc.setString(tf.getText());
	   } catch (Exception e) { tf.setText(e.getMessage()); tf.selectAll(); }
        }

        if ( evt.target instanceof Choice ) {
	    if ( evt.target==ch )    bc.setStyle(ch.getSelectedIndex());

            if ( evt.target==ch1 )    bc.setFont(new Font(ch1.getSelectedItem(),0,fontdim));


        }



	return true;
    }


}

