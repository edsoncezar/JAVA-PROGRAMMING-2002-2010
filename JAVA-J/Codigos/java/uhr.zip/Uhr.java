/******************************************************************
*                                                                 *
*        Uhr                                                      *
*                                                                 *
*        Author: Michael Kraus                                    *
*        Date: 1997/1998/1999                                     *
*        Version: 1.3                                             *
*        JDK Version: 1.0.2                                       *
*                                                                 *
*        Please contact me via email or visit my homepage:        *
*        michael.kraus@informatik.uni-muenchen.de                 *
*        www.informatik.uni-muenchen.de/~michael.kraus            *
*                                                                 *
*        Use this applet like this:                               *
*        <APPLET code="Uhr.class" width=200 height=200>           *
*        <PARAM name="timezone" value="120">                      *
*        </APPLET>                                                *
*                                                                 *
******************************************************************/

import java.applet.*;
import java.awt.*;
import java.lang.*;
import java.util.*;

public class Uhr extends Applet implements Runnable
{
	Thread thread;
	ParameterUtilities parameterUtilities;

	Polygon lastsecondpolygon;
	Polygon lastminutepolygon;
	Polygon lasthourpolygon;

	int center_x;
	int center_y;

	int timezoneoffset;

	private static final int LOCALTIMEZONEOFFSET=new Date().getTimezoneOffset();

	Color hourcolor;
	Color minutecolor;
	Color secondcolor;

	int hourhand;
	int minutehand;
	int secondhand;

	int none=0;
	int slide=1;
	int bound=2;
	int off=0;
	int on=1;

	String handvalues[]=
	{
		"none","slide","bound"
	};

	String secondhandvalues[]=
	{
		"off","on"
	};

	Color fifteenminutecolor;
	Color fiveminutecolor;
	Color oneminutecolor;

	int fifteenminute;
	int fiveminute;
	int oneminute;

	int diamonds=1;
	int lines=1;
	int numbers=2;

	String minutevalues[]=
	{
		"none","diamonds","numbers"
	};

	String oneminutevalues[]=
	{
		"none","lines","numbers"
	};

	Color dialcolor;
	Color dialedgecolor;

	int dial;
	int withedge=1;
	int withoutedge=2;

	String dialvalues[]=
	{
		"none","with edge","without edge"
	};

	private static final int UNDEFINED=0xffff;

	public void init()
	{
		Color backgroundcolor;

		thread=null;
		parameterUtilities=new ParameterUtilities(this);

		lastsecondpolygon=new Polygon();
		lastminutepolygon=new Polygon();
		lasthourpolygon=new Polygon();

		timezoneoffset=parameterUtilities.getIntegerParameter("timezone",UNDEFINED);

		secondhand=parameterUtilities.getStringArrayParameter("second hand",secondhandvalues,on);
		minutehand=parameterUtilities.getStringArrayParameter("minute hand",handvalues,bound);
		hourhand=parameterUtilities.getStringArrayParameter("hour hand",handvalues,slide);

		oneminute=parameterUtilities.getStringArrayParameter("1 minute",oneminutevalues,lines);
		fiveminute=parameterUtilities.getStringArrayParameter("5 minute",minutevalues,diamonds);
		fifteenminute=parameterUtilities.getStringArrayParameter("15 minute",minutevalues,diamonds);

		dial=parameterUtilities.getStringArrayParameter("dial",dialvalues,withedge);

		dialcolor=parameterUtilities.getColorParameter("dial color",Color.lightGray);
		dialedgecolor=parameterUtilities.getColorParameter("dial edge color",Color.darkGray);

		if((backgroundcolor=parameterUtilities.getColorParameter("background color",null))!=null)
			setBackground(backgroundcolor);

		secondcolor=parameterUtilities.getColorParameter("second hand color",Color.red);
		minutecolor=parameterUtilities.getColorParameter("minute hand color",hourcolor);
		hourcolor=parameterUtilities.getColorParameter("hour hand color",Color.black);

		oneminutecolor=parameterUtilities.getColorParameter("1 minute color",Color.darkGray);
		fiveminutecolor=parameterUtilities.getColorParameter("5 minute color",Color.white);
		fifteenminutecolor=parameterUtilities.getColorParameter("15 minute color",Color.black);
	}

	Polygon getDiamond(int seconds,double angle,double forwards,double backwards,double sideways)
	{
		Polygon polygon=new Polygon();

		double leftsin=Math.sin((seconds-angle)*Math.PI/30);
		double leftcos=Math.cos((seconds-angle)*Math.PI/30);
		double middlesin=Math.sin(seconds*Math.PI/30);
		double middlecos=Math.cos(seconds*Math.PI/30);
		double rightsin=Math.sin((seconds+angle)*Math.PI/30);
		double rightcos=Math.cos((seconds+angle)*Math.PI/30);

		polygon.addPoint(center_x+(int)(center_x*forwards*middlesin),center_y-(int)(center_y*forwards*middlecos));
		polygon.addPoint(center_x+(int)(center_x*sideways*leftsin),center_y-(int)(center_y*sideways*leftcos));
		polygon.addPoint(center_x+(int)(center_x*backwards*middlesin),center_y-(int)(center_y*backwards*middlecos));
		polygon.addPoint(center_x+(int)(center_x*sideways*rightsin),center_y-(int)(center_y*sideways*rightcos));

		return polygon;
	}

	void drawNumber(Graphics graphics,int seconds,int number,double size,double radius)
	{
		Font font=new Font("TimesRoman",Font.PLAIN,(int)(Math.min(center_x,center_y)*size));
		FontMetrics fontmetrics=getFontMetrics(font);

		String string=(new Integer(number)).toString();

		int x=center_x+(int)(center_x*radius*Math.sin(seconds*Math.PI/30));
		int y=center_y-(int)(center_y*radius*Math.cos(seconds*Math.PI/30));

		x-=fontmetrics.stringWidth(string)/2;
		y+=fontmetrics.getAscent()/2;

		graphics.setFont(font);
		graphics.drawString(string,x,y);
	}

	public void paint(Graphics graphics)
	{
		int n;
		Dimension dimension=size();

		center_x=dimension.width/2;
		center_y=dimension.height/2;

		lastsecondpolygon=new Polygon();
		lastminutepolygon=new Polygon();
		lasthourpolygon=new Polygon();

		if(dial==withedge)
		{
			graphics.setColor(dialedgecolor);
			graphics.fillOval(0,0,dimension.width,dimension.height);

			graphics.setColor(dialcolor);
			graphics.fillOval((int)(dimension.width*.02),(int)(dimension.height*.02),(int)(dimension.width*.96),(int)(dimension.height*.96));
		}		
		else if(dial==withoutedge)
		{
			graphics.setColor(dialcolor);
			graphics.fillOval(0,0,dimension.width,dimension.height);
		}

		for(n=0;n<60;n++)
		{
			if(n%15==0&&fifteenminute==diamonds)
			{
				graphics.setColor(fifteenminutecolor);
				graphics.fillPolygon(getDiamond(n,.4,1,.8,.9));
			}
			else if(n%15==0&&fifteenminute==numbers)
			{
				graphics.setColor(fifteenminutecolor);
				drawNumber(graphics,n,n==0?12:n/5,.17,.9);
			}
			else if(n%5==0&&fiveminute==diamonds)
			{
				graphics.setColor(fiveminutecolor);
				graphics.fillPolygon(getDiamond(n,.2,.95,.85,.9));
			}
			else if(n%5==0&&fiveminute==numbers)
			{
				graphics.setColor(fiveminutecolor);
				drawNumber(graphics,n,n==0?12:n/5,.1,.9);
			}
			else if(oneminute==lines)
			{
				double sin=Math.sin(n*Math.PI/30);
				double cos=Math.cos(n*Math.PI/30);

				graphics.setColor(oneminutecolor);
				graphics.drawLine(center_x+(int)(center_x*.88*sin),center_y-(int)(center_y*.88*cos),center_x+(int)(center_x*.92*sin),center_y-(int)(center_y*.92*cos));
			}
			else if(oneminute==numbers)
			{
				graphics.setColor(oneminutecolor);
				drawNumber(graphics,n,n,.05,.9);
			}
		}
	}

	Polygon getHand(double seconds,double forwards,double backwards,double sideways)
	{
		Polygon polygon=new Polygon();

		double sin=Math.sin(seconds*Math.PI/30);
		double cos=Math.cos(seconds*Math.PI/30);

		polygon.addPoint(center_x+(int)(center_x*forwards*sin),center_y-(int)(center_y*forwards*cos));
		polygon.addPoint(center_x+(int)(center_x*sideways*cos),center_y+(int)(center_y*sideways*sin));
		polygon.addPoint(center_x-(int)(center_x*backwards*sin),center_y+(int)(center_y*backwards*cos));
		polygon.addPoint(center_x-(int)(center_x*sideways*cos),center_y-(int)(center_y*sideways*sin));

		return polygon;
	}

	void drawHand(Graphics graphics,Polygon polygon)
	{
		graphics.fillPolygon(polygon);
		graphics.drawLine(polygon.xpoints[0],polygon.ypoints[0],polygon.xpoints[2],polygon.ypoints[2]);
	}

	public void update(Graphics graphics)
	{
		Polygon hourpolygon=new Polygon();
		Polygon minutepolygon=new Polygon();
		Polygon secondpolygon=new Polygon();

		double hours=0;
		double minutes;
		double seconds;
		long time;

		Date date=new Date();

		if(timezoneoffset!=UNDEFINED)
		{
			time=date.getTime();
			time+=LOCALTIMEZONEOFFSET*60*1000;
			time+=timezoneoffset*60*1000;
			date.setTime(time);
		}

		seconds=date.getSeconds();

		if(minutehand==slide)
			minutes=date.getMinutes()+seconds/60;
		else
			minutes=date.getMinutes();

		if(hourhand==slide)
			hours=date.getHours()+minutes/60;
		if(hourhand==bound)
			hours=date.getHours();

		if(hourhand!=none)
			hourpolygon=getHand(hours*5,.4,.1,.05);
		if(minutehand!=none)
			minutepolygon=getHand(minutes,.7,.2,.04);
		if(secondhand==on)
			secondpolygon=getHand(seconds,.8,.3,.03);

		if(dial!=none)
			graphics.setColor(dialcolor);
		else
			graphics.setColor(getBackground());

		if(hourhand!=none)
			drawHand(graphics,lasthourpolygon);
		if(minutehand!=none)
			drawHand(graphics,lastminutepolygon);
		if(secondhand==on)
			drawHand(graphics,lastsecondpolygon);

		if(hourhand!=none)
		{
			graphics.setColor(hourcolor);
			drawHand(graphics,hourpolygon);
		}

		if(minutehand!=none)
		{
			graphics.setColor(minutecolor);
			drawHand(graphics,minutepolygon);
		}

		if(secondhand==on)
		{
			graphics.setColor(secondcolor);
			drawHand(graphics,secondpolygon);
		}

		lasthourpolygon=hourpolygon;
		lastminutepolygon=minutepolygon;
		lastsecondpolygon=secondpolygon;
	}

	public void run()
	{
		while(true)
		{
			repaint();

			try
			{
				thread.sleep(1000-System.currentTimeMillis()%1000);
			}
			catch(InterruptedException exception)
			{
			}
		}
	}

	public void start()
	{
		if(thread==null)
		{
			thread=new Thread(this);
			thread.start();
		}
	}

	public void stop()
	{
		if(thread!=null)
		{
			thread.stop();
			thread=null;
		}
	}
}

