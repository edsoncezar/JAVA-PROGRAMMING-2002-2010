/*
Scroll Window Applet 1.0

Copyright (c) 2000 By Goodwin Software

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 or the Licenses, or (at your option) any later version.

This program is distrubuted in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABLITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.

For any questions or comments regarding this program, please e-mail us a support@goodwinsoftware.com.
*/

import java.awt.*;
import java.applet.*;
import java.awt.image.*;

public class ScrollWindow extends Applet implements Runnable {
    Image winScratch;
    Graphics gScratch;
    Thread runner;
    String[] lines = new String[1000];
    int nlines, mlines, topline, fmh;
    Color outerborder = new Color(0xCCCCCC);
    Color middleborder = new Color(0x000000);
    Color innerborder = new Color(0xCCCCCC);
    Color textcolor = new Color(0x00FF00);
    Color textbackground = new Color(0x000000);
    boolean isRunning = false;
    int delay = 2;

    public void init() {
        int i;
        String s;

        Font f = new Font("Helvetica", Font.PLAIN, 12);
        FontMetrics fm = getFontMetrics(f);
        fmh = fm.getHeight();
        mlines = (getSize().height - 26) / fmh;
        winScratch = createImage(this.getSize().width, this.getSize().height);
        gScratch = winScratch.getGraphics();
        setBackground(Color.white);
        s = getParameter("delay");
        if (s != null)
           delay = Integer.parseInt(s);
        s = getParameter("outerborder");
        if (s != null)
          outerborder = new Color(Integer.parseInt(s, 16));
        s = getParameter("middleborder");
        if (s != null)
          middleborder = new Color(Integer.parseInt(s, 16));
        s = getParameter("innerborder");
        if (s != null)
          innerborder = new Color(Integer.parseInt(s, 16));
        s = getParameter("textcolor");
        if (s != null)
          textcolor = new Color(Integer.parseInt(s, 16));
        s = getParameter("textbackground");
        if (s != null)
          textbackground = new Color(Integer.parseInt(s, 16));
        for (i = 0; i < 1000; i++) {
            lines[i] = getParameter("line" + (i + 1));
            if (lines[i] == null)
                break;
        }
        nlines = i;
        topline = 0;
     }

    public void start() {
        if (runner == null) {
            runner = new Thread(this);
            runner.start();
        }
    }

    public void stop() {
        runner = null;
    }

    public void run() {
        Thread thisThread = Thread.currentThread();

        while (runner == thisThread) {
            repaint();
            if (isRunning && nlines > mlines) {
                topline++;
                if (topline == nlines)
                    topline = 0;
            }
            isRunning = true;
            try {
                Thread.sleep(delay * 1000);
            } catch(InterruptedException e) { }
        }
    }

    public void paint(Graphics g) {
        int w, h, i, cnt;
        String[] dlines = new String[mlines];

        w = getSize().width;
        h = getSize().height;
        Font f = new Font("Helvetica", Font.PLAIN, 12);
        cnt = 0;
        for (i = 0; i < mlines; i++) {
            if (topline + i < nlines) {
                dlines[i] = lines[topline + i];
            }
            else {
                if (nlines > mlines) {
                    dlines[i] = lines[cnt];
                    cnt++;
                }
                else {
                    dlines[i] = "";
                }
            }
        }
        gScratch.setColor(outerborder);
        gScratch.drawRect(0, 0, w - 1, h - 1);
        gScratch.drawRect(1, 1, w - 3, h - 3);
        gScratch.setColor(middleborder);
        gScratch.drawRect(2, 2, w - 5, h - 5);
        gScratch.drawRect(3, 3, w - 7, h - 7);
        gScratch.setColor(innerborder);
        gScratch.drawRect(4, 4, w - 9, h - 9);
        gScratch.drawRect(5, 5, w - 11, h - 11);
        gScratch.setColor(textbackground);
        gScratch.fillRect(6, 6, w - 12, h - 12);
        gScratch.setFont(f);
        gScratch.setColor(textcolor);
        for (i = 0; i < mlines; i++) {
            gScratch.drawString(dlines[i], 8, fmh * (i + 1) + 8);
        }
         g.drawImage(winScratch, 0, 0, this);
    }

    public final void update(Graphics g) {
        paint(g);
    }

}
