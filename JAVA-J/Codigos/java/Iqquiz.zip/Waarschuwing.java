// Credits box
// -----------------
// Bavo Bruylandt

import java.awt.*; import java.awt.event.*;import java.net.*;import java.applet.*;

class Waarschuwing extends Frame
 	           implements WindowListener, ActionListener {

  
Button ok, visit;
Iqapplet iq;

  public Waarschuwing (Iqapplet iq,String s) {
  	super(s);
  	this.iq = iq;
  	setSize(400,400);
    ok = new Button("Cool...");
    ok.addActionListener(this);
    setLayout(null);
 		ok.setBounds(40,300,140,40);
		add(ok);
    visit = new Button("Visit Homemadejava");
    visit.addActionListener(this);
 		visit.setBounds(220,300,140,40);
		add(visit);
  	setLocation(250,50);
  	Color bg2 = new Color(0,0,122);
    setBackground (bg2);
    addWindowListener (this);
    setVisible(true);
    }
    
	public void paint(Graphics g) {
	
			Font f = new Font("Garamond", Font.BOLD, 20);
			g.setFont(f);
			g.setColor(Color.yellow);
			g.drawString("Credits :",170,50);
			Font p = new Font("Garamond", Font.PLAIN, 15);
			g.setFont(p);
			g.setColor(Color.white);
			g.drawString("Idea By DaHazard",60,100);
			g.drawString("Programming By DaHazard",60,130);
			g.drawString("Questions by DaHazard and Eysenck",60,160);
			g.drawString("Graphics By DaHazard and Spectrum",60,190);
			g.drawString("To use a registered version please",60,220);
			g.drawString("visit Http://www.homemadejava.com",60,250);
			g.drawString("Or mail to javadesign@pi.be",60,280);

		}
	        	
 
	         	
  public void windowClosed (WindowEvent evt) {}
  public void windowDeiconified (WindowEvent evt) {}
  public void windowIconified (WindowEvent evt) {}
  public void windowActivated (WindowEvent evt) {}
  public void windowDeactivated (WindowEvent evt) {}
  public void windowOpened (WindowEvent evt) {}
  public void windowClosing (WindowEvent evt) {
    this.dispose();
  }
	  
	 	 public void actionPerformed(ActionEvent evt) {
	 	if (evt.getSource() == ok) {
	 		this.dispose();
	 	}
	 	else {
	 		try {
	 			iq.getAppletContext().showDocument(new URL("Http://www.homemadejava.com"),"newWindow");
	 		}
	 		catch (MalformedURLException mfurl) {
	 		}
	 }         	

	 }         	
        	
}