
import java.awt.*;
import java.util.*;


class Wind 
{
	private int xco,yco;
	private int width, height;
	private boolean alive;
	private int maxX,maxY;
	private int depth;
	private int sign = 1;
	private int speed =1;
	private int strength;
	
	public Wind(int x,int y) 
	{
		maxY = y;
		maxX = x;
		xco = 100;
		yco=100;
		width = 50;
		height = 50;
		depth = 1;
	}
	
	public boolean isAlive() 
	{
		return alive;
	}
	
	public int getXco() 
	{
		return xco;
	}
	
	public int getYco() 
	{
		return yco;
	}
	
	public int getWidth() 
	{
		return width;
	}
	
	public int getHeight() 
	{
		return height;
	}
	
	public int getDepth() 
	{
		return depth;
	}
	
	public void newWind() 
	{
		xco = (int)(Math.random()*maxX-50);
		yco = (int)(Math.random()*maxY-50);
		depth = (int)(Math.random()*3);
		speed = (int)(Math.random()*3)+1;
		sign = sign*(-1);
		strength = (int)(Math.random()*3)+1;
		width = 100;
		height = 50;
		alive = true;
	}
	
	public void move() 
	{
		if (getXco()+getWidth() < 0 || getXco() > maxX) alive = false;
		xco = getXco()+(speed)*sign;
		
	}
	
	public int getSign() 
	{
		return sign;
	}
	
	public int getStrength() 
	{
		return strength;
	}
	
}