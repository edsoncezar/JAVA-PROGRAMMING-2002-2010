
import java.awt.*;
import java.util.*;


class Snow 
{
	private int xco, yco;
	private int depth;
	private int weight;
	private int drift;
	private int driftSign;
	private int maxY, maxX;
	private boolean alive;
	private int size;
	
	public Snow(int width,int height) 
	{
		this.maxY = height;
		this.maxX = width;
		driftSign = 1;
		
	}
	
	public boolean isAlive() 
	{ 
		return alive;
	}
	
	private void enable() 
	{
		alive = true;
	}
	
	private void disable() 
	{
		alive = false;
	}
	
	private void randSnowFlake() 
	{
		setYco(0);
		setXco((int)(Math.random()*maxX));
		setWeight((int)(Math.random()*8));
		setDepth((int)(Math.random()*3));
		setSize((int)(Math.random()*2)+1);
		enable();
	}
	
	public void newFlake() 
	{
		randSnowFlake();
	}
	
	private void setXco(int x) 
	{
		this.xco = x;
	}
	
	private void setYco(int y) 
	{
		this.yco = y;
	}
	
	private void setDepth(int d) 
	{
		this.depth = d;
	}
	
	private void setSize(int s) 
	{
		size = s;
	}

	private void setWeight(int w) 
	{
		if (w > 2) 
		this.weight = w;
		else this.weight = 2;
	}
	
	public void move() 
	{
		if (getYco()%2 == 0) drift();
		setYco(getYco()+weight/2);
		setXco(getXco()+getDrift());
		if (getYco() > maxY) disable();
	}
	
	public void dodge(int x) 
	{
		setXco(getXco()+x);
	}
	
	private void drift() 
	{
		if (drift <= 0) 
		{
			drift = (int)(Math.random()*10);
			driftSign = driftSign*(-1);
		}
		drift--;
	}
	
	private int getDrift() 
	{
		if (drift >0) return driftSign;
		else return 0;
	}
	
	public int getYco()
	{
		return yco;
	}
	
	public int getXco()
	{
		return xco;
	}
	
	public int getDepth() 
	{
		return depth;
	}
	
	public int getSize() 
	{
		return size;
	}
	
}