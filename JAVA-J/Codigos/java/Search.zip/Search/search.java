import java.applet.*;
import java.awt.*;
import java.lang.*;
import java.net.URL;


public class search extends Applet implements Runnable {
  Thread theengine;
  Frame theframe;
  Point zer = new Point(0,0);
  List whatisdone;
  int numofen = -1; //engen number
  int i = 0; //counter
  String winvar;
  Image logo; // i Media
  Button gonow; //go button
  List searchen; //list of engens
  TextField search; //what the person types field
  String searchstr; //what they typed
  String selected; //the sel. search
  String sites[] = new String[15];
  String address[] = new String[16];
  String steps[] = new String[5];

    public void init() {
      sites[0] = "http://www.google.com/search?q=";
      sites[1] = "http://search.yahoo.com/bin/search?p=";
      sites[2] = "http://search.excite.com/search.gw?lk=webcrawler&s=";
      sites[3] = "http://search.ebay.com/search/search.dll?MfcISAPICommand=GetResult&ht=1&SortProperty=MetaEndSort&query=";
      sites[4] = "http://search.lycos.com/main/?query=";
      sites[5] = "http://download.cnet.com/downloads/1,10150,0-10001-103-0-1-7,00.html?tag=srch&qt=";
      sites[6] = "http://www.goto.com/d/search/p/go/?Partner=go_home&Keywords=";
      sites[7] = "http://www.aj.com/main/askjeeves.asp?ask=";
      sites[8] = "http://search.excite.com/search.gw?c=web&search=";
      sites[9] = "http://www.looksmart.com/r_search?look=&key=";
      sites[10] = "http://www.searchpower.com/engine/searchtheweb.cgi?query=";
      sites[11] = "http://hotbot.lycos.com/?MT=";
      sites[12] = "http://cnet.search.com/search?timeout=3&tag=ex.cn.1.srch.cnet&q=";
      sites[13] = "http://www.mamma.com/Mamma?p1=&timeout=2&query=";
      sites[14] = "http://search.dogpile.com/texis/search?q=";
      address[0] = "Google";
      address[1] = "Yahoo";
      address[2] = "Web Crawler";
      address[3] = "E-bay";
      address[4] = "Lycos";
      address[5] = "C-Net Download";
      address[6] = "Go";
      address[7] = "Ask Jeeves";
      address[8] = "Excite";
      address[9] = "Look Smart";
      address[10] = "Search Power";
      address[11] = "Hot Bot";
      address[12] = "C-Net";
      address[13] = "Mamma";
      address[14] = "Dogpile";
      address[15] = "Search All";
      steps[0] = "Finding ";
      steps[1] = "Searching......";
      steps[2] = "Found matching Query for:";
      steps[3] = "";
      steps[4] = "Done";
      searchen = new List(3,false);
      theframe = new Frame("Multi-Search");
      whatisdone = new List(5,false);

      for (i = 0;i<16;i=i+1) {
        searchen.addItem(address[i]);
      } //for

      logo = getImage(getDocumentBase(), "searchi.gif");
      gonow = new Button("Go!");
      search = new TextField(25);
      gonow.setForeground(Color.blue);
      setBackground(Color.cyan);
      add(search);
      add(gonow);
      add(searchen);
      theframe.add(whatisdone);
      theframe.resize(200,200);
      theframe.show();
    } //init

    public void paint (Graphics g) {
      g.drawImage(logo,82,75,this);
    }
    
    public void start() {
      if (theengine == null) {
        theengine = new Thread(this);
      }
      theengine.start();
    }

    public void stop() {
      theframe.dispose();
      if (theengine != null && theengine.isAlive()) {
        theengine.stop();
      } 
    }

    public void run() {
      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
      Thread currentThread = Thread.currentThread();
    }

    public boolean keyDown(Event evt, int key) {
      if (10 == key) {
        deliverEvent(new Event(gonow,Event.ACTION_EVENT,null));
        return true;
      }
      return false;
    }

    public boolean gotFocus(Event evt, Object what) {
      if (evt.target == gonow) {
        getAppletContext().showStatus("Press To Search");
        return true;
      }
      return false;
    }

    public boolean action(Event evt,Object what) {

      if ((evt.target == gonow) && (searchen.getSelectedItem() == null)) {
        getAppletContext().showStatus("No Search Engine");
        return true;
      }

      if ((evt.target == gonow) && (searchen.getSelectedItem() == "Search All")) {
        searchstr = search.getText();
        searchstr.toLowerCase();
        
        if (searchstr == "") {
          getAppletContext().showStatus("No Query");
        }


        searchstr = searchstr.replace(' ', '+'); 

        whatisdone.addItem(steps[0] + "All");
        whatisdone.addItem(steps[1]);

        getAppletContext().showStatus("Searching...........");

        for (i=0;i<15;i=i+1) {
          winvar = Integer.toString(i);
          try {
            getAppletContext().showDocument(new URL(sites[i] + searchstr), "newwin" + winvar);
          } catch (java.net.MalformedURLException e) {
          }
        } // for for
        whatisdone.addItem(steps[2]);
        whatisdone.addItem(steps[3] + searchstr);
        whatisdone.addItem(steps[4]);
        whatisdone.addItem(" ");
        whatisdone.addItem(" ");
        whatisdone.addItem(" ");
      getAppletContext().showStatus("Searched");
      return true;
      } // if

      if (evt.target == gonow) {

        System.out.println("<center> Hello </center>");
        
        searchstr = search.getText();
        searchstr.toLowerCase();
        
        if (searchstr == "") {
          getAppletContext().showStatus("No Query");
        }


        getAppletContext().showStatus("Searching...........");

        searchstr = searchstr.replace(' ', '+'); 
        for (i=0;i<15;i=i+1) {
          selected = searchen.getSelectedItem();
          if (selected.equals(address[i])) {
            numofen = i;
          }
          getAppletContext().showStatus("Searching Engines: " + address[i]);
        }

        whatisdone.addItem(steps[0] + address[numofen]);
        whatisdone.addItem(steps[1]);

        try {
          getAppletContext().showDocument(new URL(sites[numofen] + searchstr), "prodwin");
        } catch (java.net.MalformedURLException e) {
        }
        whatisdone.addItem(steps[2]);
        whatisdone.addItem(steps[3] + searchstr);
        whatisdone.addItem(steps[4]);
        whatisdone.addItem(" ");
        whatisdone.addItem(" ");
        whatisdone.addItem(" ");
        getAppletContext().showStatus("Searched");
        return true;
      } // if
         return false;
    } // end to action method

} //class end
