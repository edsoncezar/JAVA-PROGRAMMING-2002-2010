import java.applet.*;
import java.awt.*;

public class tinyHScroll extends Applet
    implements Runnable {		// Threaded application
 
    int delay=50,                       // delay, controls scroll speed
      xpos=0,                           // X position
      ypos=0,                           // Y position
      length,
      direction=0;                      // Direction of scroll (0=right to left)

    Image offImage, bg;                 // Double buffering to eliminate
    Graphics offGrfx;                   // frame flicker

    Color background, fontColor;

    boolean customFont = false;

    Thread runner;

    String outString = new String("");
    String Message = new String("");

    Font outFont;

    public void init() {
        int size;

        /****  Get attributes, if available  ****/
        String bgRed$      = getParameter("BGRED");
        String bgGreen$    = getParameter("BGGREEN");
        String bgBlue$     = getParameter("BGBLUE");
        String fgRed$      = getParameter("FGRED");
        String fgGreen$    = getParameter("FGGREEN");
        String fgBlue$     = getParameter("FGBLUE");
        String background$ = getParameter("BACKGROUND");
        String delay$      = getParameter("DELAY");
        String fontName$   = getParameter("FONTNAME");
        String fontSize$   = getParameter("FONTSIZE");
        String ypos$       = getParameter("YPOS");
        String direction$  = getParameter("DIRECTION");
               Message     = getParameter("MESSAGE");

        /****    Prep execute attributes    ****/
        if (ypos$ != null) 
          ypos = Integer.parseInt(ypos$);

        if (direction$ != null) 
          direction = Integer.parseInt(direction$);

        if (delay$ != null) 
	  delay = Integer.parseInt(delay$);

        if ((fontSize$ != null) && (fontName$ != null)) {
            size = Integer.parseInt(fontSize$);
            outFont = new Font(fontName$, Font.PLAIN, size);
            customFont = true;
        }

        /****    Prep string information    ****/
        length = Message.length();

        /****      Convert color values     ****/
        int Red=255;
        if (bgRed$ != null)
	  Red = Integer.parseInt(bgRed$);

        int Green=255; 
        if (bgGreen$ != null)
	  Green = Integer.parseInt(bgGreen$);

        int Blue=255;
        if (bgBlue$ != null)
	  Blue = Integer.parseInt(bgBlue$);

        int fRed=0;
        if (fgRed$ != null)
          fRed = Integer.parseInt(fgRed$);

        int fGreen=0; 
        if (fgGreen$ != null)
          fGreen = Integer.parseInt(fgGreen$);

        int fBlue=0;
        if (fgBlue$ != null)
          fBlue = Integer.parseInt(fgBlue$);

        if (background$ !=null)
          bg = getImage(getDocumentBase(), background$);

        /****     Set background color    ****/
        fontColor = new Color(fRed, fGreen, fBlue);

        /****     Set background color    ****/
        background = new Color(Red, Green, Blue);
        setBackground(background);

        offImage = createImage(size().width, size().height);
        offGrfx = offImage.getGraphics();

        xpos = size().width + 10;
    }

    public void paint(Graphics screen) {
          offGrfx.setColor(background);
          offGrfx.fillRect(0,0,size().width, size().height);
          if (bg != null)
            offGrfx.drawImage(bg, 0, 0, null);
          offGrfx.setColor(fontColor);
          try { offGrfx.setFont(outFont); }
          catch (NullPointerException e) { }
          offGrfx.drawString(Message, xpos, ypos);
          screen.drawImage(offImage, 0, 0, this);
    }

    public void update(Graphics screen) {
          paint(screen); 
    }

    public void start() {
        if (runner == null) {
            runner = new Thread(this);
            runner.start();
        }
    }

    public void run() {
        FontMetrics fm;

        if (customFont)
            {
              fm = getFontMetrics(outFont);
              length = fm.stringWidth(Message);
            }
        else
            {
              length = 7 * length;
            }

        if (ypos==0) ypos = (int)(0.5 * size().height);

        while(true)
            {
               repaint();
               if (direction == 0) {
                   xpos--;
                   if (xpos <= -(length)) xpos=size().width+10;
               }
               else {
                   xpos++;
                   if (xpos >= size().width) xpos = -(length);
               }

               try { Thread.sleep(delay); }
               catch (InterruptedException e) { }
            }
    }

    public void stop() {
        if (runner != null) {
            runner.stop();
            runner = null;
        }
    }
}
