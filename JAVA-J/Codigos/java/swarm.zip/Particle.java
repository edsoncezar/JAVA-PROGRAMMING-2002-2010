//Particle class
//Created by Jeremy BRooks, August 2001
//jbrooks@kahuna.clayton.edu
//http://kahuna.clayton.edu/~jbrooks/applets
//
//Implementation of a swarming paricle.

public class Particle
{
	
	float velocityX, velocityY, x, y;

        public Particle()
	{
	}
	
	public void initialize(int mx, int my)
	{
		velocityX = (float)((Math.random()*0.5)-0.25f);
		velocityY = (float)((Math.random()*0.5)-0.25f);
		x = (float)(mx+velocityX);
		y = (float)(my+velocityY);
	}

	public void update(float[] v1, float[] v2, float[] v3, float[] v4, float[] v5, int i, boolean chaseMouse)
	{
		velocityX+=(v1[0]+v2[0]+v3[0]+v4[0]+v5[0]);
		velocityY+=(v1[1]+v2[1]+v3[1]+v4[1]+v5[1]);
		
		x+=velocityX;
		y+=velocityY;
                
		if(i==0 && !chaseMouse)
		{
			x+=velocityX*1.6f;
	                y+=velocityY*1.6f;
		}
	
		if(Math.abs(velocityX) > 5.0f)
			velocityX = (velocityX/Math.abs(velocityX))*5.0f;

		if(Math.abs(velocityY) > 5.0f)
			velocityY = (velocityY/Math.abs(velocityY))*5.0f;

	}


			

}
