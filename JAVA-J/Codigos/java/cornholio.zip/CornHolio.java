/** 
 CornHolio.java
 - jafar@staff.prodigy.com
 Apr 22 '96
 */

import java.applet.AudioClip;
import java.awt.*;

public class CornHolio extends java.applet.Applet { 

	static AudioClip sound;
	public String _sound;
	Button button=null;

public void init() { 
	String text;
	text=((text=getParameter("text")) != null) ? text : "Sound Clip";
	_sound=((_sound=getParameter("sound")) != null) ? _sound : "cornholio.au" ;

	setLayout(new BorderLayout());
	button= new Button(text);
	add("Center",button);
	sound= getAudioClip(getCodeBase(), _sound);
}

public boolean action(Event event, Object what) {
 if (event.target instanceof Button) {
	if (sound != null) sound.play();
    return true;
 }
 return false;
}

}
