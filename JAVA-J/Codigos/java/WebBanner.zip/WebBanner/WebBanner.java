import java.awt.*;
import java.net.*;
import java.util.*;
import java.applet.*;


public class WebBanner extends Applet implements Runnable
{
    // Status Message
    String szStatusWindow;

    // Credits
    String Author;

    // Font characterics
    Font hfont;
    FontMetrics hfm;

    // Thread booleans
    boolean bloaded;
    boolean bStatusWindow;

    // Load/Loop threads
    Thread loopThread;
    Thread loadThread;

    // Create off screen image
    Image offImage;
    Graphics offScreen;

    // Image Vector
    Vector vImageStats;

    // Image characterics
    int iImage;
    int iDelay;
    int iTotalImages;
    int iCurrentImageCnt;
    boolean bUrlActive;
    boolean bAuthor;
    Color BackgroundColor;

    // Initialize
    public void init()
    {
        Graphics g;
        Dimension d;

        // Find the size of the screen
        g = getGraphics();
        d = getSize();

        // Create the off screen image
        offImage = createImage(getSize().width, getSize().height);
        offScreen = offImage.getGraphics();

        // Create font
        hfont = new Font("TimesRoman", Font.ITALIC, 15);
        hfm = getFontMetrics(hfont);

        // Initialize variables
        iImage = 0;
        iDelay = 0;
        iTotalImages = 0;
        iCurrentImageCnt = 0;
        bUrlActive = false;
        bAuthor = false;
        bloaded = false;
        bStatusWindow = false;
        Author = "WebBanner - Copyright(c) 2001 WebAppstogo";
        vImageStats	= new Vector();
    }

    public void loadImages()
    {
        // read in image parameters
        String szImageName;
        String szImage;
        String szTemp;
        String szUrl;
        int iCnt  = 0;

        Image imgNew = null;
        Image imgOld = null;

        // Make sure Status param exists
        szStatusWindow = getParameter ("Status");
        if (szStatusWindow != null)
        {
            bStatusWindow = true;
        }

        // Make sure author param exists
        szTemp = getParameter ("Author");
        if (szTemp == null)
        {
            return;
        }

        // Make sure we have the right author
        if (szTemp.equalsIgnoreCase(Author))
        {
            bAuthor = true;
        }
        else
        {
            // No author name, no dice
            return;
        }

        // Get Delay param - Used to delay n milliseconds between displayed images
        szTemp = getParameter ("Delay");
        if (szTemp == null)
        {
            iDelay = 5000;
        }
        else
        {
            iDelay = Integer.parseInt(szTemp);
            if (iDelay < 1)
                iDelay = 1;
        }

        // Back ground color
        szTemp = "background";
        String sBackGround = getParameter (szTemp);
        if (sBackGround == null)
        {
            BackgroundColor = Color.black;
        }
        else
        {
            BackgroundColor = getColor(getParameter(szTemp));
        }

        // Determine how many images to load
        while (true)
        {
            szImageName = "Image" + ++iCnt;
            szImage = getParameter (szImageName);
            if (szImage == null)
            {
                break;
            }
        }

        // Keep count of total images to process
        iTotalImages = iCnt;
        iCnt = 0;

        // Send Loading Images status message
        showStatus("Loading Images...");

        // Loop for grabbing images
        while (true)
        {
            // Increment counter for images/urls
            ++iCnt;

            // Parse URL's
            szTemp = "Url" + iCnt;
            szUrl = getParameter (szTemp);

            // Parse image files
            szImageName = "Image" + iCnt;
            szImage = getParameter (szImageName);
            iCurrentImageCnt = iCnt-1;

            // No more images to load, break out
            if (szImage == null)
            {
                break;
            }
            else
            {
                // Load the images
                try
                {
                    imgNew	= getImage(new URL(getDocumentBase(), szImage));
                }
                catch (MalformedURLException e)
                {}

                // Wait for image to load completely
                while (imgNew.getWidth(this) == -1) { delay(100); }

                // Keep track of all images and URL's
                vImageStats.addElement(new ImageStats(imgNew, szUrl));
            }
        }

        // Refresh screen
        repaint();

        // Show credits in status bar or user defined message
        if (bStatusWindow)
            showStatus(szStatusWindow);
        else
            showStatus(Author);
    }

    // Lets get this show on the road
    public void start()
    {
        if (loopThread == null)
        {
            loopThread = new Thread(this);
            loopThread.start();
        }
        if (!bloaded && loadThread == null)
        {
            loadThread = new Thread(this);
            loadThread.start();
        }
    }

    // Lets end this show
    public void stop()
    {
        if (loopThread != null)
        {
            //loopThread.stop();
            loopThread = null;
            vImageStats.removeAllElements();
        }
        if (loadThread != null)
        {
            //loadThread.stop();
            loadThread = null;
        }
    }

    public void run()
    {
        long startTime;

        // Lower this thread's priority and get the current time.
        Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
        startTime = System.currentTimeMillis();

        // Run thread for loading sounds.
        if (!bloaded && Thread.currentThread() == loadThread)
        {
            loadImages();
            bloaded = true;
            loadThread = null;
        }

        // Main loop
      while (Thread.currentThread() == loopThread)
        {
            // It all starts here!!
            if (!bUrlActive)
            {
                startBanner();
            }

            // Refresh screen
            repaint();

            // Delay for a little
            try
            {
                startTime += 10;
                Thread.sleep(Math.max(0, startTime - System.currentTimeMillis()));
            }
            catch (InterruptedException e)
            {
                break;
            }
        }
    }

    Color getColor(String param)
    {
        int r, g, b;
        // use StringTokenizer to parse the color paramter which is
        // in "R,G,B" form. Then return the new Color.
        StringTokenizer st = new StringTokenizer(param, ",");
        try
        {
            r = Integer.parseInt(st.nextToken());
            g = Integer.parseInt(st.nextToken());
            b = Integer.parseInt(st.nextToken());
            return new Color(r, g, b);
        }
        catch (Exception e)
        {
            return Color.black;
        }
    }

    // Mouse entered
    public boolean mouseEnter(Event evt, int x, int y)
    {
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return true;
    }

    // Mouse exited
    public boolean mouseExit(Event evt, int x, int y)
    {
        setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        return true;
    }

    // Mouse button detected
    public boolean mouseDown(Event evt, int x, int y)
    {
        // If we are still trying to load images, then exit
        if (!bloaded)
            return true;

        // If user already clicked image link, then exit
        if (bUrlActive)
            return true;

        // Loop through image URLs to determine correct URL to jump to
        for (int i=0; i<vImageStats.size(); i++)
        {
            ImageStats ImgStat = (ImageStats)vImageStats.elementAt(i);
            if (ImgStat.IsUrlAvailable())
            {
                AppletContext context = getAppletContext();
                context.showDocument(ImgStat.GetUrl());
                bUrlActive = true;
                return true;
            }
        }
        return true;
    }

    // Loop through and display all image banners
    public void startBanner()
    {
        for (int i=0; i<vImageStats.size(); i++)
        {
            ImageStats ImgStat = (ImageStats)vImageStats.elementAt(i);
            ImgStat = (ImageStats)vImageStats.elementAt(i);
            iImage = i;
            repaint();
            delay(iDelay);
        }
    }

    // Out delay function
    public void delay(int time)
    {
        try
        {
            loopThread.sleep(time);
        }
        catch (InterruptedException e) { }
    }

    public void paint(Graphics g)
    {
        update(g);
    }

    // Lets see something on the screen
    public void update (Graphics g)
    {
        offScreen.setColor(BackgroundColor);
        offScreen.fillRect(0,0,getSize().width,getSize().height);

        // No author, no dice
        if (!bAuthor)
        {
            offScreen.setColor(Color.red);
            offScreen.drawString("Fill in author value with", 0, getSize().height/2);
            offScreen.drawString(Author, 0, getSize().height/2 + hfm.getHeight());
        }
        else
        {
            // Display loading message if were still loading images
            if (!bloaded)
            {
                offScreen.setColor(Color.white);
                offScreen.drawString("Loading image "+iCurrentImageCnt+" of "+(iTotalImages-1), getSize().width/3, getSize().height/2);
            }
            else
            {
                // Draw banner image
                if (vImageStats.size() > 0)
                {
                    ImageStats ImgStat = (ImageStats)vImageStats.elementAt(iImage);
                    offScreen.drawImage (ImgStat.Img, ImgStat.xImagePos, ImgStat.yImagePos, this);
                }
            }
        }

        // Display off-screen image
        g.drawImage(offImage, 0, 0, this);
    }
}

