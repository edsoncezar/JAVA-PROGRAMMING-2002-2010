import java.awt.Image;
import java.net.*;

// Image statistics class
public class ImageStats
{
    int xImagePos;
    int yImagePos;
    Image Img;
    URL UrlLink;
    boolean bUrlLink;

    ImageStats(Image Img, String sUrl)
    {
        this.xImagePos = 0;
        this.yImagePos = 0;
        this.Img = Img;

        try
        {
            UrlLink = new URL (sUrl);
            bUrlLink = true;
        }
        catch (MalformedURLException e)
        {
            bUrlLink = false;
        }
    }

    boolean IsUrlAvailable()
    {
        return bUrlLink;
    }

    URL GetUrl()
    {
        return UrlLink;
    }
}
