/*
ADAM SAWYER
APRIL 7 2000
applet that you click the screen & lines follow your mouse, cool 3d effects!
*/
import java.awt.*;                      //need to draw lines
import java.applet.Applet;              //need for applet
public class cursor extends Applet      //class definition
{
    int mx;                             //varible for holding current mouse position X
    int my;                             //   "     "     "       "      "      "     Y
    final int MAX_NUM = 1000;           //size of array
    int ox[]=new int[MAX_NUM];          //array of int for holding click postions X
    int oy[]=new int[MAX_NUM];          //  "   "   "   "     "      "       "    Y
    int c;                              //counter
    public void init()                  //intialize method
    {
        mx=my=c=0;                      //set varibles to 0
        setBackground(Color.red);       //sets background color
        for(int i=0;i<MAX_NUM;i++)      //loop to set all members of both arrays to 0
            ox[i]=oy[i]=0;              //sets all to 0
    }
    public void paint(Graphics g)       //paint method called y repaint();
    {
        for(int i=0; i<c; i++)    //loop to draw all array elements
        {
            if(ox[i]==0||oy[i]==0)      //dont draw if pints are 0,0
                break;                  //if 0,0 kill loop
            else g.drawLine(ox[i],oy[i],mx,my);//draws line to current mouse postion
        }
        g.drawString("Lines: "+c,1,size().height-5);
    }
    public boolean mouseMove(Event e, int x, int y)//called when mouse is moved
    {
        mx=x;                           //set mx to mouse postion X
        my=y;                           //set my to mouse postion Y
        repaint();
        return true;                    //returns true
    }
    public boolean mouseDown(Event e, int x, int y)//called when mouse is clicked
    {
        ox[c]=x;                        //adds click X to array
        oy[c]=y;                        //adds click Y to array
        c++;                            //increments C
        return true;                    //returns true
    }
    public boolean mouseDrag(Event e, int x, int y)//called when the mouse is being dragged
    {
        ox[c]=x;                        //sets the draging X to the array
        oy[c]=y;                        //  "   "     "    Y  "  "    "
        mx=x;                           //sets the current mouse position X to the draggin point
        my=y;                           //  "   "     "      "       "    Y  "  "     "      "
        c++;                            //increments c
        repaint();                      //calls paint()
        return true;                    //return true
    }
}
                                        // end of program