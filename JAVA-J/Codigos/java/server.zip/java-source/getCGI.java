/******************************************************************************************
*  *                            getCGI.class
**
**          methods concerning POST or FORM data
**          All scripts should extend this class and use its methods
**
**          Note: all data from a POST is stored in the Query Property List Automatically
**          This is not to specifications since 
**          the script should read data directly from the client when a POST operation is 
**          detected.
**          Any third party Scripts should be modified to take this into account or
**          modify the runOBJ object in the Connection class to pass the STDin and STDout
**          to the CGI script
    
            public  getCGI (Properties Info) 
                < System Properties, including the Query_String Request >

            
            methods associated with System Properties

            public  boolean containsInfoFieldKey(String key) 
            public  Enumeration getInfoPropertyNames() 
            public  String getInfoField(String field) 

            methods associated with Query-String Data

            public  boolean containsQueryFieldKey(String key) 
            public  Enumeration getQueryPropertyNames() 
            public  String getQueryField(String field)
**
*******************************************************************************************/
import  java.io.*;
import  java.util.*;



abstract class  getCGI {
     public Properties  query;
     public Hashtable  Info;     
         
     public getCGI(Hashtable Info) {
        query = new Properties();                   
        this.Info  = Info;
        extractQuery();
    
        }
        
    /** Query_String Methods **/
    public  boolean containsQueryFieldKey(String key) {
        if (query.containsKey((String)key))
            return true;
        return false;
    }
    public String getQueryField(String s) {
        if (containsQueryFieldKey(s))
        return (String)query.getProperty(s);
        return (String)null;
    }
    public  Enumeration getQueryPropertyNames() {
        return (query.propertyNames());
    }
 
       /** Info Property Methods **/
    public  boolean containsInfoFieldKey(String key) {
        if (Info.containsKey((String)key))
            return true;
        return false;
        }
    public  String getInfoField(String field) {
        if ( containsInfoFieldKey(field))
            return((String)Info.get(field));
            return (String)null;
    }
    public  Enumeration getInfoKeyNames() {
        return (Info.keys());
    }
  
    
    
    /** Simplified output Method **/
    public  void out (String s){
        System.out.println(s);
    }
    
    /**     extract the Query_String form the Info Properties. break them up into
    ***     <key><value> pairs and store to Query Property list **/
    private void extractQuery(){
        if (!Info.containsKey("QUERY_STRING")) {
        return;
        }
            int pos = 0;
            String name = null;
            StringBuffer parse;
		    StringBuffer buff = new StringBuffer();
            parse = new StringBuffer((String)Info.get("QUERY_STRING"));    
            while (pos < parse.length()) {
			switch ( parse.charAt(pos) ) {
				case '=' :
					name = buff.toString();
					buff.setLength(0);
					break;
				case '+' :
					buff.append(" ");
		    		break;
		        case '%' :
		            String s = (String)Info.get("QUERY_STRING");
		            s = s.substring(pos+1,pos+3);
		            Integer I = new Integer("0");
		            int i = I.parseInt(s,16);
		            buff.append((char)i);
		            pos +=2;
		            break;
				case '\n':
				case '&' :
					query.put(name, buff.toString());
					buff.setLength(0);
					break;
				default :
					buff.append((char)parse.charAt(pos));
    		}
			pos++;
		}
		query.put( name, buff.toString() ); 
	}
 
}