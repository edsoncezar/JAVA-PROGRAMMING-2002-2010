/*                        Script example
**
**      if accepted, display form
**      submit form. action is processed by processFor script
**/

import  java.util.*;


    class EmailForm extends getCGI {
    
     public  EmailForm(Hashtable Info) {
        super(Info);
        out(    "<b><h2><center>Report Review<br></b></h2><hr><br>");
        
  		out(    "<FORM METHOD='POST' ACTION='java-bin/processMailForm.cl'>" + 
  		        "<TABLE>"+
  		        "<tr>" +
			    "<td>Your Name</td>"+
			    "<td><input name = MYNAME  value = ></td></tr>" +
			    "<tr>"+
			    "<td>Email Address</td><td><input name = EMAIL value = ></td></tr>"+
			    "<tr><td>" +
			    "Comments?</td>"+
			    "<td><textarea name = TEXT wrap = physical rows = 5 cols = 30></textarea></td></tr>"+
			    "<tr><td></td>" +
			    "<td><INPUT TYPE='submit' VALUE='Submit'></td></tr>"+
			    "</table>" +
			    "<br><Input type = checkbox name = SENDMAIL value = >Check to be added to our newsletter" +
			    "</FORM>" 
			);
	  
	  }      	
 
  
 
 
}