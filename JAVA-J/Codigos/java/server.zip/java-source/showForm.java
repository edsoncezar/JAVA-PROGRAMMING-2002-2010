/*                        Script example
**
**      if accepted, display form
**      submit form. action is processed by processFor script
**/

import  java.util.*;


    class showForm extends getCGI {
   
     public  showForm(Hashtable Info) {
        super(Info);
  		out("<FORM METHOD='POST' ACTION='java-bin/processForm.cl'><table><tr><td>");
			out("Name</td><td><input name = myname  value = ></td><td>");
			out("State</td><td><input name = mystate value = ></td><td></td><td>");
			out("<INPUT TYPE='submit' VALUE='Show results'></td></tr></table>");
			out("</FORM>" );
	  
	  }      	
 
  
 
       
}