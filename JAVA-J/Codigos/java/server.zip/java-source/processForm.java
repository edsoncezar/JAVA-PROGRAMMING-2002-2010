/*                        Script example
**
**      request password authorization.
**      if accepted, display form
**      submit form. action is processed by processFor script
**/

import  java.util.*;


    class processForm extends getCGI {
   
     public  processForm(Hashtable Info) {
        super(Info);
  		out("<br><b>You entered the following information</b><br><br>");
		out("Your name is " + getQueryField("myname")+"<br>");
		out("Your state is " + getQueryField("mystate")+"<br><br>");
		out("That was pretty easy ... right ?");
		return;
	  }      	
 
}