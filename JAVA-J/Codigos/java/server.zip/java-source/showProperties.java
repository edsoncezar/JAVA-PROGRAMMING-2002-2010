/*                        Script example
**
**      very simple script that reads the Properties passed from the 
**      connection class and displays them to the user
**
**/

import  java.util.*;


    class showProperties extends getCGI {
   
     public  showProperties(Hashtable Info) {
       
        super(Info);
        Enumeration e = Info.keys();
        out("<b>Return Typical Script property list to the browser. This arguments are available to all CGIScripts that Extend the GetCGI class</b><br><br>");
		while ( e.hasMoreElements() ) {
			String name = (String) e.nextElement();
			String value = (String)Info.get(name );
			out("<br>" + name + " = " +  value);
		}
	  
	  }      	
 
  
 
       
}