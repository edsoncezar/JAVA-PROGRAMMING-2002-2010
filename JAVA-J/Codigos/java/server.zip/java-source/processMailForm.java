/*                        Script example
**
**      request password authorization.
**      if accepted, display form
**      submit form. action is processed by processFor script
**/

import  java.util.*;


    class processMailForm extends getCGI {
   
     public  processMailForm(Hashtable Info) {
        super(Info);
        mail mymail = new mail(getInfoField("MAIL_SERVER"),25);
        mymail.MesgTo(getInfoField("MAIL_ADDRESS"));
        mymail.MesgSubject("Response to Book review");
        mymail.MesgFrom(getQueryField("EMAIL"));
        mymail.MesgBody(getQueryField("TEXT"));
        mymail.MesgSend();
  		out("<br><b>Thank you for the review</b><br><br>");
		
	  }      	
 
}