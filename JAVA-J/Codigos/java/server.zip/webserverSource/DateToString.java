
/***                    DataToString.class
****    return the supplied long time in Country Specific Format 
***/


import java.util.*;
import java.text.*;  

    public class   DateToString { 
    
    private DateToString () {}
    
    public  final static String DateToTimeZone(long time, String timezone, Locale loc) {   
    
        TimeZone tz = TimeZone.getTimeZone(timezone);
        tz.setDefault(tz);
        DateFormat df =  DateFormat.getInstance();
        df.setTimeZone(tz);
        String dString = df.getDateInstance(DateFormat.MEDIUM).format(new Date(time));
        String tString = df.getTimeInstance(DateFormat.LONG,loc).format(new Date(time));
        dString = dString + " " + tString;
        StringTokenizer tok = new StringTokenizer (dString,"+");
        return (String)tok.nextToken();
  
    }

}