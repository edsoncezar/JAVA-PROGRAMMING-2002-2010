/***                       showDirectoryTree.class
****    called if root directory was requested and no default index.html file exists
****
****
****    public boolean showTree(String , String , PrintStream )
****        rootdirectory of file
****        file name
****        output stream to send data
****
****/

import java.io.*;
import java.util.*;
import java.net.*;
import java.text.*;  
import DateToString.*;

    public  class    showDirectoryTree {
        
    
        public boolean showTree(String rootDirectory, String dir, PrintStream out) {

            String back = new String(dir);
            String s = new String();
            File f = new File(rootDirectory+ dir);
            if (!f.exists()) {
              return false;    
            }
            String[] list = f.list();
            try {
                InetAddress me = InetAddress.getLocalHost();
                s = s + "http://"+me.getHostAddress(); 
            }catch (UnknownHostException e) {}
            StringTokenizer tok = new StringTokenizer(back,"/");
            while (tok.countTokens()>1)
                s = s + "/" + tok.nextToken();
            s = s+ "/";
            /* now, send the directory tree */
            out.println("HTTP/1.0 200 OK");
            out.println("Content-Type: text/html");
            out.println();
            out.println("<PRE><b><h2>Index of ~ /" +dir + " </h2></b>");
            out.println("<hr>");
            out.println("   <b><u>File</u>                    <u>Last-Modified</u>                  <u>Size</u></b>\n");
            out.println("<img src = /images/back.gif>"+"  <A HREF ="+s+ " >" + "Parent Directory " + "</A>");
            for ( int i =0; i<list.length; i++ ) {
            File thisfile = new File(rootDirectory+dir,list[i]);
            if( thisfile.isDirectory()) 
            out.println("<img src = /images/folder.gif>"+"  <A HREF = " +  list[i]+ "/" +">"+list[i]+"</A>");
            }
            for ( int i =0; i<list.length; i++ ) {
                int j =list[i].length() ;
                File thisfile = new File(rootDirectory+dir,list[i]);
                if( thisfile.isFile()) {
                    if(list[i].endsWith(".gif"))
                    out.print("<img src = /images/giffile.gif>"+"  <A HREF = " + list[i]+">"+list[i]+"</A>");
                else
                if(list[i].endsWith(".zip"))
                    out.print("<img src = /images/zip.gif>"+"  <A HREF = " + list[i]+">"+list[i]+"</A>");
                else
                if(list[i].endsWith(".wav"))
                    out.print("<img src = /images/wav.gif>"+"  <A HREF = " + list[i]+">"+list[i]+"</A>");
                else
                    out.print("<img src = /images/text.gif>"+"  <A HREF = " + list[i]+">"+list[i]+"</A>");
                while ( j++ < 20 ) 
                    out.print(" ");
                Date w = new Date(thisfile.lastModified());
                out.print(DateToString.DateToTimeZone(thisfile.lastModified(), "GMT", Locale.UK));
                j= DateToString.DateToTimeZone( thisfile.lastModified(),"GMT",Locale.UK).length() ;
                while (j++ < 35) 
                    out.print(" ");
                out.println(  ( (thisfile.length()/1000) + 1)+" K");
            }
        } 
        out.println("</PRE>");
        out.close();
        return true;
    }
    
 }