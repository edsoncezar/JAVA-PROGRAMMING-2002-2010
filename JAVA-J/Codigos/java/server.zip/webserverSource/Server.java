/**********************************************************************
**                          Server.class
**
**  BASIC server. Handles HTML, images, javaScript, Java Applets
**
**
***********************************************************************/
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;


public class Server implements Runnable
{
		ServerSocket lSocket;
        String wwwRoot;
        String port ;
        Thread thread;
        Hashtable SysProperties = new Hashtable();

        
        
    public Server(String port, String wwwRoot){
            this.port = port ;
            this.wwwRoot = wwwRoot;
            
		    SysProperties.put("WWW_ROOT",wwwRoot);
            SysProperties.put("HOME_ROOT",System.getProperty("user.dir"));
            /* read in any defaults set up by the user that are added to the System properties list **/
            try {
                StringTokenizer tok =null;
                BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir")+"\\defaults.ini"));
                String s = null;
                int i = 0;
                while ( (s = br.readLine()) != null)
                    if((s.trim().charAt(0) != ';') )  { // allow for comments
                       tok = new StringTokenizer(s,":");
		                if(tok.countTokens() ==2) // throw away errors
		                SysProperties.put(tok.nextToken().trim(),tok.nextToken().trim());        
                     }        
                     
             br.close();
            System.out.println("\n" + SysProperties.get("VERSION"));
            System.out.println("Running from :" + wwwRoot);
             
             
            }catch (IOException e) {}
            try {
                /* see if password list exists */
                 BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir")+"\\" + SysProperties.get("PASSWORD_FILE")));
                br.close();
            }catch (IOException e) {
                /** No password list exists so create one with admin rights and one user **/
                try {
                    File f = new File(System.getProperty("user.dir")+ "\\"+  SysProperties.get("PASSWORD_FILE"));    
                    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(System.getProperty("user.dir")+ "\\" +  SysProperties.get("PASSWORD_FILE"))));
                    out.write("administrator,admin,admin,1");
                    out.write("\r\n");
                    out.write("guest user, user,guest,2");
                    out.write("\r\n");
                    out.close();
                }catch (IOException b) {}
            }
    		try{    // set up a socket on supplied port( typically  80 )
                lSocket = new ServerSocket (Integer.parseInt(port));
		    }catch(IOException e) {}
		     
		    
            start();
	    }
	
	    public void start(){
	    if (thread==null) { 
	            thread=new Thread(this);
	            thread.start();
	        }
	    }
	
	    public void run()
	    {
	    /**
	    *   Wait for a Client connection. When detected create instance of
	    *   Connection class Run().  method in Connection class performs all 
	    *   communication with the client.
	    **/
	        try{
			    while(true)
			    {
			        
			    Socket clientSocket = lSocket.accept();
                Connection cs = new Connection (clientSocket , SysProperties);
                }
		    }
		    catch(IOException e) {}
	    }
    
	    static public void main(String args[])
	    {
	        /**     if no argument, make WWW_ROOT location \wwwroot under the directory
	        ***     we are launching the application, else make it the argument
	        ***/
	        try
		    {
		        if ( args.length == 0)
		            new Server("80" , System.getProperty("user.dir")+ "\\wwwroot" );
		        else
		            new Server("80" , args[0] );
		    } catch (Throwable t)	{ System.exit(0); }
	    }
    }

