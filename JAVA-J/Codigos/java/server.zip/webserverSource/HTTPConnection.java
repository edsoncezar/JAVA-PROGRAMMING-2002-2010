    /************************************************************************
    **                      HTTPConnection.class
    **
    **  All methods are concerned with connections and processing
    **  the clients requests. Form or POST information is handled
    **  by the getCGI base class
    **
    *************************************************************************/
import java.io.*;
import java.util.*;
import java.net.*;
import java.text.*;
import DateToString.*;

    abstract class   HTTPConnection {

        public Hashtable            Info;
        public Properties           Response;
        public Hashtable            CGIProps;
        protected BufferedReader    in;
        protected PrintStream       out;
        public  Cookie              cookie ;
        private String              Host;
        public  Socket              client ;
        boolean SSIInclude         = false;
        String OK                   = "HTTP/1.0 200 OK";
        String CACHEDTRUE           = "HTTP/1.0 304 Not modified";


    public HTTPConnection (Hashtable sys) {
            Info        = new Hashtable();
            Response    = new Properties();
            CGIProps    = new Properties();
            // Save system data for possible use       
            try {
                InetAddress me = InetAddress.getLocalHost();
                Host = me.getHostAddress();
            }catch (UnknownHostException e) {}
            putField ("HOST_ADDR",Host);
            Enumeration e = System.getProperties().propertyNames();
		    while ( e.hasMoreElements() ) {
			        String name = (String) e.nextElement();
			        String value = (String)System.getProperty( name );
			        Info.put(name,value);
			
		    }
		    e = sys.keys();
	        while ( e.hasMoreElements() ) {
			        String name = (String) e.nextElement();
			        String value = (String)sys.get( name );
			        Info.put(name,value);
			
            }

    }

    public void SetIO (BufferedReader in, PrintStream out) {
            this.in = in;
            this.out = out;

        }

    /*** the following three methods are usered to extract info from INFO about this connection ***/
    public  String getField(String field) {
        if (Info.containsKey((String)field))
         return(String)Info.get(field);
         else
         return "Invalid";
        }

    public  void putField(String s, String field) {
            Info.put(s,field);
        }

    public  boolean containsFieldKey(String key) {
        if (Info.containsKey((String)key))
            return true;
        return false;
        }


    /***    Routine to process the input from the Connection .Save all lines to Property list INFO
    ****    if POST detected , save all data from client in "Query_String" Parameter ***/
    public void  getURLInfo() {
            try{
                while (SaveToProperties(in.readLine()) != null) {}
            }catch(IOException e) {}
            StripRequestLine();
            setUserInfo();
            if(containsFieldKey("POST")) {
                SavePostData();  
                Enumeration e = Info.keys();
      	        while ( e.hasMoreElements() ) {
			        String name = (String) e.nextElement();
			        String value = (String)Info.get( name );
			        CGIProps.put(name,value);
                }

            }
            
    }
    
    /*** save the data from a POST command to the "Query_String" parameter in the INFO properties list ***/
    private void    SavePostData(){
            String s = null;
            if ( containsFieldKey("Content-length") )
                s = (String)getField("Content-length");
            else
                s = (String)getField("Content-Length");
            CGIProps.put("CONTENT-LENGTH",s);                  
            int count = new Integer(s).intValue();
            if(count ==0) return; //nada
            byte[] ch = new byte[count];
            for ( int i = 0; i<count;i++) 
                try{
                    ch[i] = (byte)in.read();
                }catch(IOException e){}
            CGIProps.put("QUERY_STRING",new String(ch));  
            
            
     }
     
    /*** this routine examines the POST or GET command and save parameters in the INFO Properties list
    ***  for possible later use :
    ***
    *** DocumentPath    - Path of the requested document
    *** Document        - Actual document name less extension
    *** DocumentExt     - Document Extension
    *** cgiBase         - DocumentPath converted to Windows ctiteria
    ***/
    public  void StripRequestLine() {
            StringTokenizer tok ;
            if (containsFieldKey("GET"))
              tok = new StringTokenizer(getField("GET")," ");
            else
              tok = new StringTokenizer(getField("POST")," ");
            String s = tok.nextToken();
            if( s.endsWith("/")) { // just default them
                putField("DOCUMENT_PATH",s.substring(0,s.length()));
                putField("DOCUMENT","Nil");    
                putField("DOCUMENT_EXT","Nil");
                putField("CGI_BASE","\\");
                return;
            }
            int st = 0;
            int en = s.lastIndexOf('/');
            putField("DOCUMENT_PATH",s.substring(st,en+1));
            tok = new StringTokenizer( s.substring(en+1,s.length()),".");
            putField("DOCUMENT",tok.nextToken());
            
            if(tok.hasMoreTokens())
                putField("DOCUMENT_EXT",tok.nextToken());
            else
                putField("DOCUMENT_EXT","Nil");
            s = getField("WWW_ROOT");
            putField("ROOT_BASE",s.substring(0,s.lastIndexOf('\\') ));       
            putField("CGI_BASE",getField("DOCUMENT_PATH").replace('/','\\'));
            tok = new StringTokenizer(getField("CGI_BASE"),"\\");
            while(tok.countTokens()>1) 
              putField("CGI_BASE","\\"+tok.nextToken()+"\\");   
      }

    
    /***                      return the requested URL. 
    ****    if no document name given, retrun either the <default> parameter or a windowtype tree
    ****    if cach request, process and return the URL or the "304 Not Modified"
    ****    determine if Binary or Text response is requried
    ****/
    public  String GetRequestedURL() {

            File f = null; 
            StringTokenizer tok = new StringTokenizer(getField("GET"));
            String requestedFile = tok.nextToken(); // get the URL
            if ( requestedFile.endsWith("/")){
                /** see if index file of Directory tree should be displayed **/
                f = new File(getField("WWW_ROOT") + requestedFile + getField("DEFAULT_URL"));
                if (f.exists())
                    requestedFile = requestedFile + "/" +getField("DEFAULT_URL");
                else
                {
                showDirectoryTree dt = new showDirectoryTree();
                if ( !(dt.showTree(getField("WWW_ROOT"),requestedFile, out) ))
                outputTextFile("/" +getField("ERROR_URL"));
                out.close();
                return (String)null;
                }
             }
            else
                f = new File(getField("WWW_ROOT") + requestedFile);
            if (!f.canRead()) {
                requestedFile = "/" + getField("ERROR_URL"); // can't find the document
                f = new File(getField("WWW_ROOT") + requestedFile);
            }
            Response.put("Last-Modified",DateToString.DateToTimeZone(f.lastModified(),"GMT",Locale.UK));
            Response.put("Content-Type",getDataType(requestedFile));
            Response.put("Content-Length",new Integer((int)f.length()).toString());
            if (allowCache() && ifModifiedSince(f.lastModified())) 
                sendResponseHeader(CACHEDTRUE); 
            
            else{
                sendResponseHeader(OK);
                if ( Response.getProperty("Content-Type").equals("text/html")) 
                    outputTextFile(requestedFile);
                else
                    outputBinaryFile(requestedFile);
                } 
            return requestedFile;
    } 
     
    
    /***    save all input lines from the browser for possible use in the INFO Properties table ***/
    
    private String SaveToProperties (String line) {
        System.out.println(line);
            if (line.length() ==0) return (String)null;
            String s = null;
            StringTokenizer tok = new StringTokenizer(line,":");
            if ( tok.hasMoreTokens()) s = tok.nextToken();
            if ( tok.hasMoreTokens()){
                String q = tok.nextToken("\n").trim();
                Info.put(s,q);
            }
            else {
                tok = new StringTokenizer(line," ");
                s = tok.nextToken();
                Info.put(s,tok.nextToken("\n").trim());
            }
            return "OK";
    }
   
    /***    Determine the data type to send back. Default is HTML ***/
    private  String getDataType(String requestedFile){   
            
        if ( requestedFile.toLowerCase().endsWith(".gif"))
            return "image/gif";
        if ( requestedFile.toLowerCase().endsWith(".jpg"))
            return "image/jpg";
        if ( requestedFile.toLowerCase().endsWith(".class"))
            return "application/x-java-applet";
        if ( requestedFile.toLowerCase().endsWith(".zip"))
            return "application/zip";
        if ( requestedFile.toLowerCase().endsWith(".txt"))
            return "text/plain";
        return  "text/html"; // default
    }

    /***    Return a simple Response header ***/
    private void sendResponseHeader(String resp) {
            out.println(resp);
            out.println("Content-Type: " + Response.getProperty("Content-Type"));
            out.println("Content-Length: "+ Response.getProperty("Content-Length"));                
            out.println("Last-Modified:"+ Response.getProperty("Last-Modified")+"\n");                
            
    }
    
    /***    request was for a HTML document. May run thru the SSI parser to see if additional
    ****    processing is required.
    ****/
    private void outputTextFile ( String requestedFile) {
            SSIParser           SSI = null;
            SSIInclude = false;
            if ( getField("DOCUMENT_EXT").toLowerCase().equals( getField("SSI").toLowerCase()))  {
                SSIInclude = true;
                SSI   = new SSIParser(Info,out);
            }
            try {
            String line = null;
            BufferedReader br = new BufferedReader(new FileReader(getField("WWW_ROOT")+ requestedFile));
             while ( (line = br.readLine()) != null)
             if ( SSIInclude)
             SSI.checkForSSICommand(line);
             else
               out.println(line);
            br.close();
    
         }catch(IOException e) {}
    }
    
    /***    Binary File of some sort ****/
    private  void outputBinaryFile (String requestedFile) {
           try {
            int chr = 0;
            FileInputStream bi = new FileInputStream(getField("WWW_ROOT")+requestedFile);
            while ( (chr = bi.read()) != -1) 
                out.write((byte)chr);
             bi.close();
            } catch (IOException e) {}
     } 
    
    
    /***    Check the current document on the server matches the document at the browser ***/           
    public  boolean ifModifiedSince( long fileDate) {
        if (Info.get("If-Modified-Since") != null) {
            StringTokenizer tok = new StringTokenizer((String)Info.get("If-Modified-Since"),";");
            Date nd = new Date((String)tok.nextToken().trim());
            if (fileDate == nd.getTime()) 
                return true;
            }
            return false;
    }
    
    /** check if Pragma for no cache is requested **/
    private boolean allowCache() {
        if ( containsFieldKey("Pragma"))
            if(getField("Pragma").toLowerCase().equals("no-cache")) return false;
        return true;
    }
    
    // add some misc. info 
    public  void    setUserInfo() {
        
                Info.put("HTTP_USER_AGENT",getField("User-Agent"));     
                Info.put("DOCUMENT_URI",getField("Referer")); 
                InetAddress me = client.getInetAddress();
                Info.put("REMOTE_ADDR",me.getHostAddress());
                Info.put("REMOTE_HOST",me.getHostName());
	            Info.put("DOCUMENT",getField("DOCUMENT"));
	            Info.put("DOCUMENT_EXT",getField("DOCUMENT_EXT"));
	    
	         
        
   
        }
 
        
}/*** End Class ***/
        
        
           
   
   

        
        
        