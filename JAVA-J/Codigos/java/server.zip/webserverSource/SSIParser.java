/***                    SSIParser. class
****
****    This class handles alll SSI and Virtual commands requested from the browser
***/

import java.io.*;
import java.util.*;
import java.net.*;
import  DateToString.*;

    public  class   SSIParser {
    Hashtable Info;
    Properties Hits;
    PrintStream out;


    public  SSIParser( Hashtable Info, PrintStream out) {
     this.Info = Info;
     this.out = new PrintStream(out);
    }


    /***    Scan the text line for possible SSI Commands ***/
    public  void checkForSSICommand( String s) {
    int pos = 0;
        while (pos != s.length() ) {
        if ( s.charAt(pos)!= '<') {
            out.print(s.charAt(pos++));
            if (pos >= s.length()) return;
            }
            else
            {
                String test = s.substring(pos,s.length());
                if ( pos == (pos = parseForSSI(test, pos))) out.print(s.charAt(pos++));
            }
       }
    }

   /*** Possible Server Side Include statement. Check for "virtual" or "echo" ***/
    private int parseForSSI( String s, int pos) {
      
        int i = 0, j= 0, ssiEnd = 0;
        if ( (i = s.indexOf('#')) == -1) return pos; // nothing there
        ssiEnd = s.indexOf('>');
        if ( i>ssiEnd) return pos;
        if ( (j = s.indexOf(' ',i)) == -1) return pos;
        String type = s.substring(i+1,j).trim();
        if ( (i = s.indexOf('=',j)) == -1) return pos;
        String cmd = s.substring(j+1,i).trim();
        if ( (j = s.indexOf('>',i)) == -1) return pos;
        String dest = s.substring(i+1,j).trim();

        if( cmd.toLowerCase().equals("virtual")) {
            SendVirtual(dest);
            return pos+ssiEnd+1;
        }
        else
        if( cmd.toLowerCase().equals("var")) {
            processVarCommand(dest);
            return pos + ssiEnd+1 ;
        }
        
      return pos;
    }


   /***     SSI Echo Command Requested . Process and Return ***/
    public   void    processVarCommand(String s) {
        StringTokenizer tok = new StringTokenizer(s," ");
        s = tok.nextToken().replace('"',' ').trim();
        if ( s.equals("LAST_MODIFIED")) {
                tok = new StringTokenizer(getField("GET"));
                File f = new File(getField("WWW_ROOT")+ "/" + tok.nextToken());
                out.println(DateToString.DateToTimeZone(f.lastModified(),"GMT",Locale.UK));
        }
        if ( s.equals("SERVER_NAME"))
                out.print(getField("SERVER_NAME"));
        if ( s.equals("SERVER_SOFTWARE"))
                out.print(getField("SERVER_SOFTWARE"));
        if ( s.equals("HTTP_USER_AGENT"))
                out.print(getField("User-Agent"));
        if ( s.equals("REMOTE_HOST"))
                out.print(getField("REMOTE_HOST"));
        if ( s.equals("DOCUMENT_URI"))
                out.print(getField("Referer"));
        if ( s.equals("REMOTE_ADDR"))
                out.print(getField("REMOTE_ADDR"));
    }

    /***    Virtual request Detected. Process and Return ***/
    public  void    SendVirtual(String s) {
        BufferedReader br = null;
        StringTokenizer tok = new StringTokenizer(s,"\"");
        s = tok.nextToken().trim();
        if (( (s.indexOf('?')) == -1))
        {
        try {
            String line = null;
            if (s.charAt(0) == '/')
                br = new BufferedReader(new FileReader(getField("WWW_ROOT")+ s));
            else
                br = new BufferedReader(new FileReader(getField("WWW_ROOT")+ "/" + s));
             while ( (line = br.readLine()) != null)
                out.print(line);
            br.close();

         }catch(IOException e) {out.println(s);}
        }
        else // parameters exist. Either an error or a script.
        {
            /** code here to handle more complex virtual statements*/
        }
    }

    private  String getField(String field) {
         return( (String)Info.get(field));
        }






}