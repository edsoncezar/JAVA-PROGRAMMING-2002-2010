/**                           Cookie.class
***
***
***     public Cookie ( Properties, PrintStream )
***         pass the Info property list 
***         pass the output Stream
***
***
***     boolean getAuthorization(boolean setpassword) does the following :
***
***         check for Authorization variable
***         if not found, send 401 message to browser and request password
***         if found, verify password is in database 
***         if setpassword is true then set cookie. ( not currently implemented
***         in the server)
***         if still false, re- request password
***
***     int getPasswordLevel()
***     return the password level if a cookie is set
***     2 = general user   1 = administrator 0 = not found
***
***     void    Unauthorized()
***         simple HTML page return to user if not authorized

***/

import java.util.*;
import java.io.*;
import  Codecs.*;

    public  class   Cookie {
        private Hashtable Info;
        private PrintStream output;
        public  int AccessLevel = 0;
        
        public  Cookie(Hashtable Inf, PrintStream out) {
            Info   = Inf;
            output = out;
        }
    
    /*  If getAuthorization was requested with the boolean parameter TRUE then
    **  a Cookie was set in the users browser equal to the encoded password
    **  This routine will check for a cookie and return the password level of
    **  the user based on the password.txt information.
    **  NOTE: the server currently does nothing with this function.
    */
    public  int getPasswordLevel() {
        if (containsInfoFieldKey("Cookie")){
        // verify the password cookie is valid
        StringTokenizer tok = new StringTokenizer(getInfoField("Cookie"),"=");
        String s = tok.nextToken();
        if ( tok.hasMoreTokens())
            s = tok.nextToken("\n").trim();
        if ( checkPassWord64(s))return AccessLevel;
        return 0;        
        }
        return 0;
    }
    
    /*  Request a password from the user until it either aggrees with a 
    **  user in the password.txt file, or the user gives up.
    **  If setCookie parameter is TRUE, set a cookie in the users browser equal
    **  to the encoded username:password string
    */
     public   boolean getAuthorization(boolean setCookie) {
         if (!containsInfoFieldKey("Authorization")) {

            // force the browser to bring up password screen
            out("HTTP/1.0 401 Authorization Required");
            out("WWW-Authenticate: Basic Realm = "+getInfoField("RESTRICTED_DIR"));
            out("\n");
            return false;
            }
         else
         {
            StringTokenizer tok = new StringTokenizer(getInfoField("Authorization"));
            String s = tok.nextToken();
            if ( tok.hasMoreTokens())
               s = tok.nextToken().trim();
            // check if the returned password (encoded64) are any of our passwords
            if ( checkPassWord64(s)){
                if (setCookie){
                    out("HTTP/1.0 200 OK");
                    out("Set-Cookie: userid =" + s + "; Path=/;");
                    out("\n");
                }
             return true;    
            }
            else
            {
                // still disagreed, keep asking
                out("HTTP/1.0 401 Authorization Required");
                out("WWW-Authenticate: value=Basic Realm ="+getInfoField("Restricted"));
                out("\n");
                return false;
            }
          }
   }
    
    private boolean checkPassWord64(String pass64) { 
     // if more than 100 passwords, modify this area
        String[] realname   = new String[100];
        String[] users      = new String[100];
        String[] passwords  = new String[100];
        String[] levels     = new String[100];
        String[] url        = new String[100];
        int i = 0;
        boolean ok = false;
        try {
            BufferedReader br = 
                new BufferedReader(new FileReader(Info.get("HOME_ROOT") +"\\" + Info.get("PASSWORD_FILE")));
               
            String line = br.readLine();
            while (line != null ) {
            
                StringTokenizer tok = new StringTokenizer(line,",");
                realname[i] = tok.nextToken();
                users[i] = tok.nextToken();
                passwords[i] = tok.nextToken();
                levels[i] = tok.nextToken();
                if (tok.hasMoreTokens()) 
                    url[i] = tok.nextToken();
               else
                    url[i] = "NULL";
               i++;
               line = br.readLine();
           } 
            br.close();           
           }catch (IOException e) {}
           for ( i = 0;i<users.length; i++) {
             if ( Codecs.base64Encode(users[i]+":"+passwords[i]).equals(pass64)){
                AccessLevel = new Integer(levels[i]).intValue();
              
                return true;
            }
           }
      return false;
    }
 
    public   void    UnAuthorized() {
       out("<b><h3>HTTP/1.0 401  You are not Authorized to Enter This Area</b>");
      
    }  
      

    /** some utilities needed for this class **/
    private void out(String s) {
        output.println(s);
    }
    private  boolean containsInfoFieldKey(String key) {
        if (Info.containsKey((String)key))
            return true;
        return false;
    }
    public  String getInfoField(String field) {
         if (Info.containsKey((String)field))
            return((String)Info.get(field));
         else
            return "Invalid";
    }
 }