/**************************************************************************
***                             runObj.class
***
*** Use the Class and reflection classes to instantiate a object based on
**  the supplied String name .
**
**  Assumes found class contains the following Constructor . All Java CGIScripts
**  must conform to this format. 
**
        public Obj ( Hashtable h )
**
**************************************************************************/
import java.awt.*;
import java.util.*;
import java.lang.reflect.*;

public	class	runObj {
	public   runObj(String name, Hashtable p) {
	    Constructor   con   = null;
	    Class         cl    = null;
        Object        obj   = null;
    try{
      cl =  Class.forName(name);
      }catch (ClassNotFoundException e) {}
    try{
      con = cl.getConstructor (new Class[] {Hashtable.class} );
      }catch (NoSuchMethodException e){}
    try {
      obj = con.newInstance(new Object[] {p});
      }catch (InstantiationException e){}
       catch (IllegalAccessException e){}
       catch (IllegalArgumentException e){}
       catch (InvocationTargetException e){}
    }


  }












