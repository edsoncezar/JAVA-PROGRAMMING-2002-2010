
/***********************************************************************
**                      Connection.class  
***                  extends HTTPConnection
***
***     This class does all the work. All methods for processing data
**      reside in the HTTPConnection base class
***
************************************************************************/
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class Connection extends HTTPConnection  implements Runnable
{
	protected   BufferedReader  in ;
	protected   PrintStream     out;
    Thread      thread          = null;

    public Connection (Socket client, Hashtable sys)
	{
	       
	    super(sys);
	    this.client = client;
	    /** make the connection and run **/
	    try{    
		    in = new BufferedReader(new InputStreamReader(client.getInputStream())); 
    		out = new PrintStream (client.getOutputStream());
		} catch( IOException ee) {
		    try {
		        client.close();
		    }catch (IOException e) {
			return; }
		}
		SetIO(in, out); // notify superclass of socket
		start();   
    }
    
    public void start(){
	    if (thread==null) { 
	            thread=new Thread(this);
	            thread.start();
	    }
	}
	
	public void run()
	{
	        
         getURLInfo();              // read the request from the client
         /** check if restricted areas  and password needed **/
         StringTokenizer tok = new StringTokenizer(getField("RESTRICTED_DIR"),",");
         while ( tok.hasMoreTokens() ){
         String s = tok.nextToken().trim().toLowerCase();   
         if (s.equals(getField("DOCUMENT_PATH"))) {
         cookie = new Cookie(Info,out);
         if ( !cookie.getAuthorization(false )){
                      cookie.UnAuthorized();
                      out.close(); // you can't get in
                      return ;
                }
            }
         }
         if (doScript() )
                doJavaCGI();            // request was a post or a direct java CGI reference
         else
           GetRequestedURL();  // normal response back to the client
        out.close();                // finished, kill the connection
    }

    
    // check if extension is valid CGI script
    public  boolean doScript() {
     
        if(containsFieldKey("POST") && containsFieldKey("CGI_EXT")) {
            StringTokenizer tok = new StringTokenizer(getField("CGI_EXT"),",");
            while (tok.hasMoreTokens()){
               if ( getField("DOCUMENT_EXT").equals(tok.nextToken().toLowerCase()))
                   return true;
            }
         
        }
         return false;  
    }
            
            
            
    
/********************************************************************************
**                          CGI Script Handler
**
**                   Java class scripts under \java-bin
**                currently assumes all scripts are Java classes
**
**      runObj class creates an instance of a class based on the String supplied. 
*********************************************************************************/

    void    doJavaCGI() {

            /** Redirect STDout to the URL stream **/
            PrintStream ps = System.out;
            System.setOut(out);
            runObj ro = new runObj(getField("DOCUMENT"),CGIProps);              
            // restore STDout
            System.setOut(ps);
         }
    }
