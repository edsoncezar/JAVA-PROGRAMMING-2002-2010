import java.awt.*;
import java.applet.Applet;
import java.util.Hashtable;

public class ShootingGallery extends Applet	{
	static Image background;
	static Graphics g;
	static int score;
	static int loadX=10,loadY=10,loadXStep=5,loadYStep=5;
	Target tempTarget;
	Bullet tempBullet;
	static Hashtable targetHashtable=new Hashtable(),keyHashtable=new Hashtable();	//hashtables for targets & keys
	MediaTracker imageTracker;
	Button newGameButton;
	public void init()	{
		imageTracker=new MediaTracker(this);
		for (int i=1;i<37;i++)	{
			Gun.gunArray[i-1]=getImage(getCodeBase(),"gun" + i + ".gif");
			imageTracker.addImage(Gun.gunArray[i-1],0);
		}
		background=getImage(getCodeBase(),"ShootingGalleryBg.gif");
		imageTracker.addImage(background,0);
		Target.duck_left=getImage(getCodeBase(),"duckLeft.gif");
		imageTracker.addImage(Target.duck_left,0);
		Target.duck_right=getImage(getCodeBase(),"duckRight.gif");
		imageTracker.addImage(Target.duck_right,0);
		for (int i=1;i<5;i++)	{
			Target.duckFallLeft[i-1]=getImage(getCodeBase(),"duckLeft" + i + ".jpg");
			imageTracker.addImage(Target.duckFallLeft[i-1],0);
		}
		for (int i=1;i<5;i++)	{
			Target.duckFallRight[i-1]=getImage(getCodeBase(),"duckRight" + i + ".jpg");
			imageTracker.addImage(Target.duckFallRight[i-1],0);
		}
		imageTracker.checkID(0,true);
		g=getGraphics();
		Target.g=getGraphics();
		Bullet.g=getGraphics();
		score=0;
		Bullet.ammo=15;
		setLayout(new BorderLayout());
		newGameButton=new Button("New Game");
		add("South",newGameButton);
		g.setColor(Color.white);
		g.fillRect(0,0,300,350);
		while(!imageTracker.checkAll())	{
			g.setColor(Color.black);
			g.drawString("Loading Images...",loadX,loadY);
			System.out.println("Loading images...");
			try	{
			Thread.sleep(250);
			} catch(Exception e)	{}
			g.setColor(Color.white);
			g.drawString("Loading Images...",loadX,loadY);
			if ((loadX>=290) || (loadX<=0))
				loadX=0-loadX;
			loadX+=loadX;
			if ((loadY>=340) || (loadY<=0))
				loadY=0-loadY;
			loadY+=loadY;
		}
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		tempTarget=new Target(0,true);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		tempTarget=new Target(40,false);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		try	{
			Thread.sleep(Target.delay*110);
		} catch(Exception e)	{}
		tempTarget=new Target(160,true);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		tempTarget=new Target(200,false);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		try	{
			Thread.sleep(Target.delay*200);
		} catch(Exception e)	{}
		tempTarget=new Target(80,true);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
		tempTarget=new Target(120,false);
		g.drawImage(background,0,0,this);
		g.setColor(Color.black);
		g.drawString("Score: " + score,10,310);
	}
	public void stop()	{
		for (int i=0;i<6;i++)	{
			if (keyHashtable.get(new Integer(i))!=null)	{
				tempTarget=(Target)targetHashtable.get(new Integer(i).toString());
		//		tempTarget.fall();
				tempTarget.stop();
			}
		}
	}
	public void start()	{
		for (int i=0;i<6;i++)	{
			if (keyHashtable.get(new Integer(i))!=null)	{
				tempTarget=(Target)targetHashtable.get(new Integer(i).toString());
				tempTarget.start();
			}
		}
	}
	public void destroy()	{
		for (int i=0;i<6;i++)	{
			if (keyHashtable.get(new Integer(i))!=null)	{
				tempTarget=(Target)targetHashtable.get(new Integer(i).toString());
		//		tempTarget.fall();
				tempTarget.stop();
			}
		}
	}
	public void paint(Graphics g)	{
		//if (!imageTracker.checkAll())	{
		//	g.drawString("Loading Images...",130,150);
		//} else	{
			g.drawImage(background,0,0,this);
			g.setColor(Color.black);
			g.drawString("Score: " + score,10,310);
			g.drawString("Ammo: " + Bullet.ammo,240,310);
		//}
	}
	public boolean mouseMove(Event e, int x, int y)	{
		if(y<=40)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[0],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[1],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[2],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[3],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[4],140,241,this);
			else
				g.drawImage(Gun.gunArray[5],140,241,this);
		}
		else if (y<=80)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[6],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[7],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[8],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[9],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[10],140,241,this);
			else
				g.drawImage(Gun.gunArray[11],140,241,this);
		}
		else if (y<=120)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[12],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[13],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[14],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[15],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[16],140,241,this);
			else
				g.drawImage(Gun.gunArray[17],140,241,this);
		}
		else if (y<=160)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[18],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[19],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[20],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[21],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[22],140,241,this);
			else
				g.drawImage(Gun.gunArray[23],140,241,this);
		}
		else if (y<=200)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[24],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[25],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[26],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[27],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[28],140,241,this);
			else
				g.drawImage(Gun.gunArray[29],140,241,this);
		}
		else if (y<=240)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[30],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[31],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[32],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[33],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[34],140,241,this);
			else
				g.drawImage(Gun.gunArray[35],140,241,this);
		}
		return true;
	}
	public boolean mouseDrag(Event e, int x, int y)	{
		if(y<=40)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[0],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[1],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[2],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[3],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[4],140,241,this);
			else
				g.drawImage(Gun.gunArray[5],140,241,this);
		}
		else if (y<=80)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[6],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[7],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[8],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[9],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[10],140,241,this);
			else
				g.drawImage(Gun.gunArray[11],140,241,this);
		}
		else if (y<=120)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[12],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[13],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[14],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[15],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[16],140,241,this);
			else
				g.drawImage(Gun.gunArray[17],140,241,this);
		}
		else if (y<=160)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[18],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[19],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[20],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[21],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[22],140,241,this);
			else
				g.drawImage(Gun.gunArray[23],140,241,this);
		}
		else if (y<=200)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[24],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[25],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[26],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[27],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[28],140,241,this);
			else
				g.drawImage(Gun.gunArray[29],140,241,this);
		}
		else if (y<=240)	{
			if (x<=50)
				g.drawImage(Gun.gunArray[30],140,241,this);
			else if (x<=100)
				g.drawImage(Gun.gunArray[31],140,241,this);
			else if (x<=150)
				g.drawImage(Gun.gunArray[32],140,241,this);
			else if (x<=200)
				g.drawImage(Gun.gunArray[33],140,241,this);
			else if (x<=250)
				g.drawImage(Gun.gunArray[34],140,241,this);
			else
				g.drawImage(Gun.gunArray[35],140,241,this);
		}
		return true;
	}
	public boolean mouseDown(Event e, int x, int y)	{
		if (Bullet.ammo>0)	{
			if ((y<238) && (y>=0) && (x>=0) && (x<=300))	{	//make sure shot is on-screen
				tempBullet=new Bullet(x,y);
				tempBullet.start();
				for (int i=0;i<6;i++)	{	//loop through targets to check for hits
					if (keyHashtable.get(new Integer(i))!=null)	{
						tempTarget=(Target)targetHashtable.get(new Integer(i).toString());
						if ((x+Bullet.radius>=tempTarget.x) && (x-Bullet.radius<=tempTarget.x+46) && (y+Bullet.radius>tempTarget.y) && (y-Bullet.radius<tempTarget.y+39))	{
							tempTarget.fall();
							if (targetHashtable.size()==0)
								newLevel();
						}
					}
				}
				try	{
					Thread.sleep(300);
				} catch(Exception ee)	{}
				Bullet.ammo--;
				repaint();
			}
		}
		return true;
	}
	public boolean action(Event e, Object arg)	{
		if (e.target instanceof Button)	{
			newGame();
		}
		return super.action(e,arg);
	}
	public boolean mouseEnter(Event e, int x, int y)	{
		setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
		return true;
	}
	public boolean mouseExit(Event e, int x, int y)	{
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		return true;
	}
	public void newGame()	{
		for (int i=0;i<6;i++)	{
			if (keyHashtable.get(new Integer(i))!=null)	{
				tempTarget=(Target)targetHashtable.get(new Integer(i).toString());
				tempTarget.fall();
				tempTarget.stop();
			}
		}
		score=0;
		Bullet.ammo=15;
		Target.masterKey=0;
		Target.delay=15;
		Target.step=1;
		keyHashtable=new Hashtable();
		tempTarget=new Target(0,true);
		tempTarget.start();
		tempTarget=new Target(40,false);
		tempTarget.start();
		try	{
			Thread.sleep(Target.delay*70);
		} catch(Exception e)	{}
		tempTarget=new Target(80,true);
		tempTarget.start();
		tempTarget=new Target(120,false);
		tempTarget.start();
		try	{
			Thread.sleep(Target.delay*70);
		} catch(Exception e)	{}
		tempTarget=new Target(160,true);
		tempTarget.start();
		tempTarget=new Target(200,false);
		tempTarget.start();
		repaint();
	}
	public void newLevel()	{
		Bullet.ammo=15;
		Target.masterKey=0;
		if (score%1800==0)
			Target.step++;
		else
			Target.delay--;
		keyHashtable=new Hashtable();
		tempTarget=new Target(0,true);
		tempTarget.start();
		tempTarget=new Target(40,false);
		tempTarget.start();
		try	{
			Thread.sleep(Target.delay*(long)(Math.random()*90+90));
		} catch(Exception e)	{}
		tempTarget=new Target(80,true);
		tempTarget.start();
		tempTarget=new Target(120,false);
		tempTarget.start();
		try	{
			Thread.sleep(Target.delay*(long)(Math.random()*90+90));
		} catch(Exception e)	{}
		tempTarget=new Target(160,true);
		tempTarget.start();
		tempTarget=new Target(200,false);
		tempTarget.start();
		repaint();
	}
}
public class Gun	{
	static Image[] gunArray=new Image[36];
}
public class Bullet extends Thread	{
	int x, y;
	static Color col=Color.magenta;
	static int radius=3;
	static Graphics g;
	static int ammo;
	Bullet(int x, int y)	{
		this.x=x;
		this.y=y;
	}
	public void run()	{
		g.setColor(col);
		g.fillOval(this.x-radius,this.y-radius,2*radius,2*radius);
		try	{
			sleep(250);
		} catch(Exception e)	{}
		g.setColor(Color.white);
		g.fillOval(this.x-radius,this.y-radius,2*radius,2*radius);
		this.stop();
	}

}
public class Target extends Thread	{
	static Image duck_left;
	static Image duck_right;
	static Image[] duckFallLeft=new Image[4];
	static Image[] duckFallRight=new Image[4];
	static Graphics g;
	static int masterKey=0;
	int x,y,key;
	String s;
	static int delay=15,step=1;
	boolean dir, alive=true;
	Target(int y, boolean dir)	{
		if (dir)	{
			this.x=-45;
		} else	{
			this.x=299;
		}
		this.y=y;
		this.dir=dir;
		this.key=masterKey;
		ShootingGallery.targetHashtable.put(new Integer(this.key).toString(),this);
		ShootingGallery.keyHashtable.put(new Integer(this.key),new Integer(this.key));
		masterKey++;
	}
	public void run()	{
		while (alive)	{
			if (dir)	{
				while	(this.x<300)	{
					g.drawImage(duck_right,this.x,this.y,new ShootingGallery());
					try	{
						sleep(delay);
					} catch (Exception e)	{}
					g.setColor(Color.white);
					g.fillRect(this.x,this.y,step,39);
					this.x+=step;
				}
			}
			else	{
				while	(this.x>(-45))	{
					g.drawImage(duck_left,this.x,this.y,new ShootingGallery());
					try	{
						sleep(delay);
					} catch (Exception e)	{}
					g.setColor(Color.white);
					g.fillRect(this.x+45,this.y,step,39);
					this.x-=step;
				}
			}
			dir=!dir;
		}
	}
	public void fall()	{
		this.alive=false;
		this.stop();
		ShootingGallery.targetHashtable.remove(new Integer(this.key).toString());
		ShootingGallery.keyHashtable.remove(new Integer(this.key));
		ShootingGallery.score+=100;
		if (!dir)	{
			for (int i=0;i<4;i++)	{
				try	{
				sleep(200);
				} catch(Exception e)	{}
				g.drawImage(duckFallLeft[i],this.x,this.y,new ShootingGallery());
			}
		}
		else	{
			for (int i=0;i<4;i++)	{
				try	{
				sleep(200);
				} catch(Exception e)	{}
				g.drawImage(duckFallRight[i],this.x,this.y,new ShootingGallery());
			}
		}
		g.setColor(Color.white);
		g.fillRect(this.x,this.y,47,39);
	}
} 