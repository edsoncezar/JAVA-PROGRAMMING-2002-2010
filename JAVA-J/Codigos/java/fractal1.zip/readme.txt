****************************** FRACTAL **********************************
FRACTAL - Java Applet by Eckhard Roessel                       03/29/2001
-------------------------------------------------------------------------

Please download and unzip FRACTAL.ZIP in a new directory.
List of Files:

 readme.txt     this file
 fractal.java   the java source code
 fractal.jar    the applet - compressed
 fractal.htm    the HTML-page
 fraktal.jpg    the background picture
 mandelbrot.jpg a picture of Benoit Mandelbrot
 spektral.jpg   the sprectral colors
 form.css       the style-sheet file

*************************************************************************

Please send me an eMail, if you want to use the applet at your site
and add a link to my homepage.

                     www.eckhard-roessel.de

*************************************************************************

Have Fun!
Eckhard Roessel

