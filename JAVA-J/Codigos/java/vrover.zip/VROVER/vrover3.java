/*
** vrover applet **
(c) 1997 Vitas Ramanchauskas, vitas@webdon.com, http://webdon.com, ICQ:3024702

You may use this applet freely.
All I ask is that you add a link to my home page: http://webdon.com,
if possible.
html tag: <a href="http://webdon.com">Vitas' site</a>
...or take my funny banner ;-)

About me.
> 28 y.o. software developer.

> Applications, DLLs, Drivers (including VxDs), ActiveX controls,
  utilities, libraries.. ..for Windows 95/NT, Win 3.x, DOS

> C++, Java, Forth, Assembler (including Pentium features,
  virtual & protected modes, MMX.. ..as well as antique PDP-11 & i8080)

> Win32 SDK, DDK, Video for Windows SDK, OLE, ActiveX (including controls),
  COM, MFC, ATL, Image processing, Multimedia, Internet programming (HTML,
  CGI,ISAPI,Java,...), security & cryptography ...more!

> Deep knowledge of system internals

> Skilled in mathematics, physics & digital electronics
*/

import java.applet.*;
import java.awt.*;
import java.net.*;


public class vrover3 extends Applet implements Runnable
{
        private int butCnt = 0;                                                         // buttons number
        private boolean horiStyle = false;              // true if horizontal layout
        private int activeIndex = -1;                                   // current button index
        private Thread   m_vrover = null;

        private Graphics m_Graphics;
        private Image    m_Images[];
        private int      m_nImgWidth  = 0;
        private int      m_nImgHeight = 0;
        private boolean  m_fAllLoaded = false;
        private final int NUM_IMAGES = 4;

        private String m_url[] = new String[50];
        private String m_text[] = new String[50];
        private String m_frame[] = new String[50];
        private Color m_fgColor = new Color(255,255,40);
        private Color m_bkColor = new Color(135,170,180);
        private int w = 80, h = 32;

        private final String PARAM_url = "url";
        private final String PARAM_frame = "frame";
        private final String PARAM_text = "text";
        private final String PARAM_bkColor = "bkColor";
        private final String PARAM_fgColor = "fgColor";
        private final String PARAM_w = "w";
        private final String PARAM_h = "h";
        private final String PARAM_style = "style";

        public vrover3()
        {
                m_url[0] = "index.htm";
                m_text[0] = "Pressme";
                m_frame[0] = "_self";
        }

        public String getAppletInfo()
        {
                return "Name: vrover\r\n" +
                       "Author: Vitas Ramanchauskas\r\n" +
                       "Created solely";
        }

        public String[][] getParameterInfo()
        {
                String[][] info =
                {
                        { PARAM_url, "String", "HREF" },
                        { PARAM_frame, "String", "Target frame" },
                        { PARAM_w, "Integer", "button width" },
                        { PARAM_h, "Integer", "button height" },
                        { PARAM_bkColor, "Integer", "Background Color" },
                        { PARAM_fgColor, "Integer", "Foreground Color" },
                        { PARAM_text, "String", "Text to be displayed" },
                        { PARAM_style, "Integer", "Style" },
                };
                return info;
        }

        private int parse(String dst[], String src)
        {
                int x=0, i=0;
                while(true)
                {
                        int n = src.indexOf(',', x);
                        if(n==-1)
                        {
                                dst[i] = src.substring(x);
                                break;
                        }
                        else
                                dst[i] = src.substring(x, n);
                        dst[i] = dst[i].trim();
                        x = n+1;
                        i++;
                }
                return i+1;
        }

        public void init()
        {
                String param;

                param = getParameter(PARAM_url);
                if (param != null)
                        parse(m_url, param);

                param = getParameter(PARAM_bkColor);
                if (param != null)
                {
                        m_bkColor = new Color(Integer.parseInt(param));
                        setBackground(m_bkColor);
                }

                param = getParameter(PARAM_fgColor);
                if (param != null)
                        m_fgColor = new Color(Integer.parseInt(param));

                param = getParameter(PARAM_text);
                if (param != null)
                        butCnt = parse(m_text, param);

                param = getParameter(PARAM_frame);
                if (param != null)
                        parse(m_frame, param);

                param = getParameter(PARAM_w);
                if (param != null)
                        w = Integer.parseInt(param);
                param = getParameter(PARAM_h);
                if (param != null)
                        h = Integer.parseInt(param);
                param = getParameter(PARAM_style);
                if (param != null)
                        horiStyle = (Integer.parseInt(param)==1);
        }

        private void displayImage(Graphics g, int n, int phase)
        {
                if (!m_fAllLoaded)
                        return;

                if(horiStyle)
                        g.drawImage(m_Images[phase],
                                           w*n+5, (h - m_nImgHeight) / 2, null);
                else
                        g.drawImage(m_Images[phase],
                                           5, n*h+(h - m_nImgHeight) / 2, null);
        }

        private void draw1(Graphics g, int n)
        {
                Rectangle r;
                if(horiStyle)
                        r = new Rectangle(w*n,0,w,h);
                else
                        r = new Rectangle(0,n*h,w,h);
                if (m_fAllLoaded)
                {
                        g.clearRect(r.x, r.y, r.width, r.height);
                        g.setColor(new Color(192,192,192));
                        g.drawLine(r.x, r.y, r.x+r.width-2, r.y);
                        g.drawLine(r.x, r.y, r.x, r.y+r.height-2);
                        g.setColor(new Color(120,120,120));
                        g.drawLine(r.x+r.width-2, r.y+1, r.x+r.width-2, r.y+r.height-2);
                        g.drawLine(r.x+1, r.y+r.height-2, r.x+r.width-2, r.y+r.height-2);
                        g.setColor(new Color(0,0,0));
                        g.drawLine(r.x+r.width-1, r.y, r.x+r.width-1, r.y+r.height-1);
                        g.drawLine(r.x, r.y+r.height-1, r.x+r.width-1, r.y+r.height-1);
                        displayImage(g, n, 0);          // always in base (dark) state
                }
                g.setColor(m_fgColor);
                g.drawString(m_text[n], r.x+25, r.y+r.height/2 +
                        g.getFontMetrics().getAscent()/2);
        }

        public void paint(Graphics g)
        {
                for(int i=0; i<butCnt; i++)
                        draw1(g, i);
        }

        public void start()
        {
                setBackground(m_bkColor);
                if (m_vrover == null)
                {
                        m_vrover = new Thread(this);
                        m_vrover.start();
                }
        }

        public void stop()
        {
                if (m_vrover != null)
                {
                        m_vrover.stop();
                        m_vrover = null;
                }

        }

        public void run()
        {
    if (!m_fAllLoaded)
                {
                        m_Graphics = getGraphics();
                repaint();
                m_Images   = new Image[NUM_IMAGES];

                MediaTracker tracker = new MediaTracker(this);
                String strImage;

                for (int i = 1; i <= NUM_IMAGES; i++)
                {
                        strImage = "phase" + i + ".gif";
                            m_Images[i-1] = getImage(getCodeBase(), strImage);
          tracker.addImage(m_Images[i-1], 0);
                }
                        try
                        {
                                tracker.waitForAll();
                                m_fAllLoaded = !tracker.isErrorAny();
                        }
                        catch (InterruptedException e)
                        {
                        }

                        if (!m_fAllLoaded)
                        {
                            stop();
                            m_Graphics.drawString("Error loading images!", 10, 40);
                            return;
                        }

                        // Assuming all images are same width and height.
                    m_nImgWidth  = m_Images[0].getWidth(this);
                    m_nImgHeight = m_Images[0].getHeight(this);
        }
                repaint();


// Yeah! You've found it! I want to know where my applet is used
// Follow code (you'll remove it of course ;) ) tries to open
// non-existent image at webdon.com...
// ...and I'll see this request in my log...
// It is possible to do applet copy-protection...
                MediaTracker trk = new MediaTracker(this);
    try
                {trk.addImage(getImage(new URL("http://webdon.com/vrover3.gif")),0);
                try
                {       trk.waitForAll(4444);   }
                catch (InterruptedException e)
                {}
                }
                catch (MalformedURLException e)
                {}
        }

        // converts (x,y) coordinate to Active Index (index of current button)
        private int xy2ai(int x, int y)
        {
                return horiStyle? x/w:y/h;
        }

        private void validateAI(int x, int y)
        {
                if(xy2ai(x,y) != activeIndex && m_fAllLoaded)
                {
                        if(activeIndex!=-1)
                        {
                                // turn off previous button indicator
                                displayImage(m_Graphics, activeIndex, 0);
                        }
                        // hilight new one
                        activeIndex = xy2ai(x,y);
                        displayImage(m_Graphics, activeIndex, 1);
                }
        }

        public boolean mouseDown(Event evt, int x, int y)
        {
                if(m_fAllLoaded)
                {
                        // fade in
                        validateAI(x, y);
                        displayImage(m_Graphics, xy2ai(x,y), 2);
                        try{
                                Thread.sleep(60);
                        }
                        catch (InterruptedException e)
                        {}
                        displayImage(m_Graphics, xy2ai(x,y), 3);
                        try{
                                Thread.sleep(60);
                        }
                        catch (InterruptedException e)
                        {}
                }
                return true;
        }

        public boolean mouseUp(Event evt, int x, int y)
        {
                if(activeIndex==-1)
                        return true;
                // fade out
                validateAI(x, y);
                displayImage(m_Graphics, xy2ai(x,y), 2);
                try
                {
                        Thread.sleep(60);
                }
                catch (InterruptedException e)
                {
                        ;
                }
                displayImage(m_Graphics, xy2ai(x,y), 1);

                // jump through hyperlink
                URL theUrl;
                try {
                        theUrl = new URL(getDocumentBase(), m_url[activeIndex]);
                        getAppletContext().showDocument(theUrl,
                                (m_frame[activeIndex]==null)? "_self":m_frame[activeIndex]);
                }
                catch (MalformedURLException e)
                {
                }

                return true;
        }

        public boolean mouseEnter(Event evt, int x, int y)
        {
                if(m_fAllLoaded)
                {
                        activeIndex = xy2ai(x,y);
                        displayImage(m_Graphics, activeIndex, 1);
                }
                return true;
        }

        public boolean mouseMove(Event evt, int x, int y)
        {
                validateAI(x,y);
                return true;
        }

        public boolean mouseExit(Event evt, int x, int y)
        {
                if(m_fAllLoaded)
                {
                        displayImage(m_Graphics, activeIndex, 0);
                        activeIndex = -1;
                }
                return true;
        }
}
