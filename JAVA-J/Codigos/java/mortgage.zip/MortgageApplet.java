//******************************************************************************
// MortgageApplet.java:	Applet
//
//******************************************************************************
import java.applet.*;
import java.awt.*;
import MortgageDialog;
import MortgageFunctions;


//==============================================================================
// Main Class for applet MortgageApplet
//
//==============================================================================
public class MortgageApplet extends Applet
{

	// Variables
	final	int		YLOOKUPTBL_LIMIT = 120;
			double	yLookUptbl[][] = new double[YLOOKUPTBL_LIMIT][2];
			double graphValues[][] = new double[25][2];

	MortgageDialog		mdb = new MortgageDialog( this );
	MortgageFunctions	mf;




	// MortgageApplet Class Constructor
	//--------------------------------------------------------------------------
	public MortgageApplet()
	{
		// TODO: Add constructor code here
	}

	// APPLET INFO SUPPORT:
	//		The getAppletInfo() method returns a string describing the applet's
	// author, copyright date, or miscellaneous information.
    //--------------------------------------------------------------------------
	public String getAppletInfo()
	{
		return "Name: MortgageApplet\r\n" +
		       "Author: David Schell\r\n" +
		       "Copyright Precedent Systems Consultants\r\n" +
		       "Created with Microsoft Visual J++ Version 1.0";
	}


	// The init() method is called by the AWT when an applet is first loaded or
	// reloaded.  Override this method to perform whatever initialization your
	// applet needs, such as initializing data structures, loading images or
	// fonts, creating frame windows, setting the layout manager, or adding UI
	// components.
    //--------------------------------------------------------------------------
	public void init()
	{
        // If you use a ResourceWizard-generated "control creator" class to
        // arrange controls in your applet, you may want to call its
        // CreateControls() method from within this method. Remove the following
        // call to resize() before adding the call to CreateControls();
        // CreateControls() does its own resizing.
        //----------------------------------------------------------------------
		// resize(400, 300);

		// Create the standard controls
		mdb.CreateControls();
		mdb.IDC_BUTTON_CALCULATE.setForeground( Color.blue );
		mdb.IDC_BUTTON_CALCULATE.setFont(new Font("Arial",Font.BOLD,18));

		mdb.IDC_MONTHLY_TYPE.setState(true);
		mdb.IDC_CALCULATE_USING_TERM.setState(true);
		mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();

		// Load the Graph Look Up Table
		double dollarValue = 0;
		double yCoordinate	= 370;

		for (int i=0; i<YLOOKUPTBL_LIMIT;i++){
			yLookUptbl[i][0] = dollarValue;
			yLookUptbl[i][1] = yCoordinate;

			dollarValue += 18.75;
			yCoordinate -= 1.25;
		}


		mdb.IDC_PRINCIPAL_TEXTBOX.setText("150000");
		mdb.IDC_INTEREST_RATE_TEXTBOX.setText("6.75");
		mdb.IDC_TERM_TEXTBOX.setText("25");


	}

	// Place additional applet clean up code here.  destroy() is called when
	// when you applet is terminating and being unloaded.
	//-------------------------------------------------------------------------
	public void destroy()
	{
		// TODO: Place applet cleanup code here
	}

	// MortgageApplet Paint Handler
	//--------------------------------------------------------------------------
	public void paint(Graphics g)
	{
		int pos=0,i=0, pb=0;

		g.drawRect(20,18,110,100);
		g.drawRect(20,148,110,55);

		// Draw x & y axis
		g.drawLine(80,220,80,370);
		g.drawLine(80,370,330,370);
		g.setFont(new Font("Arial", Font.BOLD,12));
		g.drawString("Years",200,400);
		g.setFont(new Font("Arial",Font.BOLD,12));
		g.setColor(Color.red);
		g.drawString("Interest",20,385);
		g.setColor(Color.blue);
		g.drawString("Principal",20,400);
		g.setColor(Color.black);

		// Change font and draw y plot points.
		g.setFont(new Font("Arial",Font.PLAIN,10));
		for (pos=90,i=1;i<26;i++){
			g.drawLine(pos,365,pos,375);
			if ((i % 5) == 0){
				if (i<=9){
					pb = 2;
				}
				else{
					pb = 4;
				}
				g.drawString(Integer.toString(i),pos-pb,385);
			}
			pos += 10;
		}

		// Draw bars and dollar amounts on the x axis
		g.setFont(new Font("Arial",Font.PLAIN,10));
		String s="$  ";
		for(pos=360,i=1;i<16;i++){
			g.drawLine(75,pos,85,pos);
			if (i*150 > 999) s = "$ ";
			g.drawString(s+Integer.toString(i*150),35,pos+5);
			pos -= 10;
		}


		//if (displayGraph) 
		drawGraph(g);



	}

	private void drawGraph(Graphics myGraphics){

		int oldxpos = 80;
		int oldyPpos = 0;
		int oldyIpos = 0;
		int newyPpos = 220;
		int newyIpos = 220;
		int i,j;
		int xpos=90;
		boolean firstTime = true;



		for (i=0;i<25;i++,xpos+=10){

			if (graphValues[i][0] == 0.) break;

			// Locate x for the Principal
			for(j=0;j<120;j++){
				if (graphValues[i][0] <= yLookUptbl[j][0]){
					newyPpos =  (int) java.lang.Math.round(yLookUptbl[j][1]);
					j=120;
				}
			}

			// Locate x for the Interest
			for(j=0;j<120;j++){
				if (graphValues[i][1] <= yLookUptbl[j][0]){
					newyIpos = (int) java.lang.Math.round(yLookUptbl[j][1]);
					j=120;
				}
			}


			if (firstTime) {
				oldyPpos = newyPpos;
				oldyIpos = newyIpos;
				firstTime = false;
			}

		  myGraphics.setColor(Color.blue);
		  myGraphics.drawLine(oldxpos,oldyPpos,xpos,newyPpos);

		  myGraphics.setColor(Color.red);
		  myGraphics.drawLine(oldxpos,oldyIpos,xpos,newyIpos);

		  oldyPpos = newyPpos;
		  oldyIpos = newyIpos;
		  oldxpos = xpos;
		}

	}


	//		The start() method is called when the page containing the applet
	// first appears on the screen. The AppletWizard's initial implementation
	// of this method starts execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void start()
	{
		// TODO: Place additional applet start code here
	}
	
	//		The stop() method is called when the page containing the applet is
	// no longer on the screen. The AppletWizard's initial implementation of
	// this method stops execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void stop()
	{
	}

	private void msgbox(String msg){
		showStatus(msg);
	}

	/*
	/ Catch the enter key and mouse click on the Calculate button
	*/
	public boolean action(Event evt, Object obj){

		String fieldValue = (String) obj;

		// If the event target was a button ... process calculate
		if (evt.target instanceof Button){
			if (fieldValue.equals("Calculate")){
				setupMortgage();
				return true;
			}
		}
		// If the event was the enter key in a TextField
		else if (evt.target instanceof TextField){
			moveNext(evt, fieldValue);
		  return true;
		}

		return false;
	}


	/*
	/ Use this function to capture the tab keys so we can move to the next/previous fields.
	/*/
	public boolean keyUp(Event evt, int key){

		// If it is the tab key.
		if ('\t' == (char) key){

			String fieldValue = "";

			// If this is a field text ... get its current value
			if (evt.target instanceof TextField){
				TextField tf = getTextField(evt);
				fieldValue = tf.getText();
			}


			// If the shift key is down ... move to the previous field.
			if (evt.shiftDown()){
				movePrevious(evt, fieldValue);
			}
			else{
				// Move to the next componet
				moveNext(evt, fieldValue);
			}

			return true;
		}
		return false;
	}

	/*
	/  moveNext will move to the next component based on the value of the field.
	/*/
	private void moveNext(Event evt, String fieldValue){

		// Validate the field before we doing anything else
		boolean moveNext = moveNext = validateFieldValue(evt, fieldValue);
		

		// If we still need to move next ... determine where we are and move to the next 
		// comonent.
			if (moveNext){
			if (isEventComponent(evt, mdb.IDC_MONTHLY_TYPE)){
				mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_SEMI_MONTHLY_TYPE)){
				mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_BI_WEEKLY_TYPE)){
				mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_WEEKLY_TYPE)){
				mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();
			}							       
			else if (isEventComponent(evt, mdb.IDC_PRINCIPAL_TEXTBOX)){
				mdb.IDC_INTEREST_RATE_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_INTEREST_RATE_TEXTBOX)){
				mdb.IDC_TERM_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_TERM_TEXTBOX)){
				mdb.IDC_PAYMENT_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_PAYMENT_TEXTBOX)){
				mdb.IDC_BUTTON_CALCULATE.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_BUTTON_CALCULATE)){
				mdb.IDC_MONTHLY_TYPE.requestFocus();
			}

		}

	}

	/*
	/  movePrevious will move to the previous component based on the value of the field.
	/*/
	private void movePrevious(Event evt, String fieldValue){

		// Validate the field before we doing anything else
		boolean movePrevious = movePrevious = validateFieldValue(evt, fieldValue);
		

		// If we still need to move previous ... determine where we are and move to the
		// previous comonent.
		if (movePrevious){
			if (isEventComponent(evt, mdb.IDC_MONTHLY_TYPE)){
				mdb.IDC_BUTTON_CALCULATE.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_SEMI_MONTHLY_TYPE)){
				mdb.IDC_BUTTON_CALCULATE.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_BI_WEEKLY_TYPE)){
				mdb.IDC_BUTTON_CALCULATE.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_WEEKLY_TYPE)){
				mdb.IDC_BUTTON_CALCULATE.requestFocus();
			}							       
			else if (isEventComponent(evt, mdb.IDC_PRINCIPAL_TEXTBOX)){
				mdb.IDC_MONTHLY_TYPE.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_INTEREST_RATE_TEXTBOX)){
				mdb.IDC_PRINCIPAL_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_TERM_TEXTBOX)){
				mdb.IDC_INTEREST_RATE_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_PAYMENT_TEXTBOX)){
				mdb.IDC_TERM_TEXTBOX.requestFocus();
			}
			else if (isEventComponent(evt, mdb.IDC_BUTTON_CALCULATE)){
				mdb.IDC_PAYMENT_TEXTBOX.requestFocus();
			}

		}

	}

	/*
	/ gets the TextField associated with the event.
	*/
	private TextField getTextField(Event evt){

		TextField tf = null;
		if (isEventComponent(evt, mdb.IDC_PRINCIPAL_TEXTBOX)){
			tf = mdb.IDC_PRINCIPAL_TEXTBOX;
		}
		else if (isEventComponent(evt, mdb.IDC_INTEREST_RATE_TEXTBOX)){
			tf = mdb.IDC_INTEREST_RATE_TEXTBOX;
		}
		else if (isEventComponent(evt, mdb.IDC_TERM_TEXTBOX)){
			tf = mdb.IDC_TERM_TEXTBOX;
		}
		else if (isEventComponent(evt, mdb.IDC_PAYMENT_TEXTBOX)){
			tf = mdb.IDC_PAYMENT_TEXTBOX;
		}

		return tf;
	}


	/*
	/  Validates the field value
	*/
	private boolean validateFieldValue( Event evt, String fieldValue){

		int fieldValueLength = fieldValue.length();


		// If the field length is not zero ... make sure it is a double.
		if (fieldValueLength != 0){
			if (getDouble(fieldValue," ") == -1.){
					return false;
			}
		}
		// If the Field is the Principal or the Interest Rate ... they are mandatory
		else if (isEventComponent(evt, mdb.IDC_PRINCIPAL_TEXTBOX)){
			msgbox("Principal is Mandatory");
			return false;
		}
		else if (isEventComponent(evt, mdb.IDC_INTEREST_RATE_TEXTBOX)){
			msgbox("Interest Rate is Mandatory");
			return false;
		}
		// If term is selected as way to calcualte ... then term is mandatory
		else if (isEventComponent(evt, mdb.IDC_TERM_TEXTBOX)){
			if (mdb.IDC_CALCULATE_USING_TERM.getState()){
				msgbox("Term is Mandatory");
			}
		}
		// If payment is selected as way to calculate ... then payment is mandatory
		else if (isEventComponent(evt, mdb.IDC_PAYMENT_TEXTBOX)){
			if (mdb.IDC_CALCULATE_USING_PAYMENT.getState()){
				msgbox("Payment is Mandatory");
			}
		}

		return true;

	}

	/*
	/  Calculate the mortgage
	*/
	private void setupMortgage(){
		
		int mortgageType = 1;
		boolean CalculateUsingTerm = mdb.IDC_CALCULATE_USING_TERM.getState();
		double principal;
		double term;
		double interest;
		double payment;
		int calculateUsing;
		Double tmp;
		MsgBox mb;


		if (mdb.IDC_MONTHLY_TYPE.getState()){
		 	mortgageType = MortgageFunctions.MORTGAGETYPE_MONTHLY;
		}
		else if (mdb.IDC_SEMI_MONTHLY_TYPE.getState()){
		 	mortgageType = MortgageFunctions.MORTGAGETYPE_SEMIMONTHLY;
		}
		else if (mdb.IDC_BI_WEEKLY_TYPE.getState()){
		 	mortgageType = MortgageFunctions.MORTGAGETYPE_BIWEEKLY;
		}
		else if (mdb.IDC_WEEKLY_TYPE.getState()){
		 	mortgageType = MortgageFunctions.MORTGAGETYPE_WEEKLY;
		}


		if (mf != null) mf = null;
		
		
		principal = getDouble(mdb.IDC_PRINCIPAL_TEXTBOX.getText(),"Principal");
		if (principal == -1.) return;

		interest = getDouble(mdb.IDC_INTEREST_RATE_TEXTBOX.getText(),"Interest Rate");
		if (interest == -1.) return;

		if (CalculateUsingTerm){
			term = getDouble(mdb.IDC_TERM_TEXTBOX.getText(),"Term");
			if (term == -1.) return;
			payment = 0.;
			calculateUsing = MortgageFunctions.CALCULATEUSING_TERM;
		}
		else{
			payment = getDouble(mdb.IDC_PAYMENT_TEXTBOX.getText(),"Payment");
			if (payment == -1.) return;
			term = 0.;
			calculateUsing = MortgageFunctions.CALCULATEUSING_PAYMENT;
		}

		// Calculate the Mortgage
		mf = new MortgageFunctions(mortgageType,principal,interest,term,payment,calculateUsing);
		
		if (CalculateUsingTerm){
			mdb.IDC_PAYMENT_TEXTBOX.setText(Double.toString(MortgageFunctions.Round(mf.getPayment(),2)));
		}
		else{
			mdb.IDC_TERM_TEXTBOX.setText(Double.toString(MortgageFunctions.Round(mf.getTerm(),2)));
			if (!mf.getWillPaymentCoverInterest()){
				msgbox("Payment Will Not Cover Interest ... Increase Payment");
			}
		}

		// Set the calculated totals.
		mdb.IDC_TOTAL_INTEREST_TEXTBOX.setText(formatCurrency(MortgageFunctions.Round(mf.getTotalInterest(),2)));
		mdb.IDC_TOTAL_COST_TEXTBOX.setText(formatCurrency(MortgageFunctions.Round(principal+mf.getTotalInterest(),2)));


		// Get the Graph Values.
		graphValues = mf.getGraphValues();
		this.repaint();

	}

	// Converts the string to a double return -1 if there is a problem.
	private	double getDouble(String textField, String textFieldLabel){
		double returnValue = -1.;

		try{
			returnValue = Double.valueOf(textField).doubleValue();
		}
		catch (ArithmeticException e){
			msgbox("Arithmetic Exception Error Converting Text Field (" + textFieldLabel +  ") To Number " + e.toString());
		}
		catch (Exception e){
			msgbox("Error Converting Text Field (" + textFieldLabel + ") To Number " + e.toString());
		}

		return returnValue;
	}

	// Determines if the event that was triggered came from the specified component.
	private boolean isEventComponent(Event evt, Component f){
		Rectangle r = f.bounds();
		if (evt.x == r.x && evt.y == r.y){
			return true;
		}
		return false;
	}

	// Format Currency
	private String formatCurrency( double currency){
		String s = Double.toString(currency);
		int l = s.length();
		String result = "$"+s;



		return result;
	}

}

