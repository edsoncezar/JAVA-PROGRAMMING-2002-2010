//------------------------------------------------------------------------------
// MortgageDialog.java:
//		Implementation of "control creator" class MortgageDialog
//------------------------------------------------------------------------------
import java.awt.*;
import DialogLayout;

public class MortgageDialog
{
	Container    m_Parent       = null;
	boolean      m_fInitialized = false;
	DialogLayout m_Layout;

	// Control definitions
	//--------------------------------------------------------------------------
	CheckboxGroup group1;
	Checkbox      IDC_MONTHLY_TYPE;
	Checkbox      IDC_SEMI_MONTHLY_TYPE;
	Checkbox      IDC_BI_WEEKLY_TYPE;
	Checkbox      IDC_WEEKLY_TYPE;
	Label         IDC_MORTGAGE_TYPE_LABEL;
	Button        IDC_BUTTON_CALCULATE;
	TextField     IDC_PRINCIPAL_TEXTBOX;
	TextField     IDC_INTEREST_RATE_TEXTBOX;
	TextField     IDC_TERM_TEXTBOX;
	TextField     IDC_PAYMENT_TEXTBOX;
	Label         IDC_MORTGAGE_SPECIFICS_LABEL;
	Label         IDC_PRINCIPAL_LABEL;
	Label         IDC_INTEREST_RATE_LABEL;
	Label         IDC_TERM_LABEL;
	Label         IDC_PAYMENT_LABEL;
	Label         IDC_TOTAL_INTEREST_LABEL;
	TextField     IDC_TOTAL_INTEREST_TEXTBOX;
	Label         IDC_TOTAL_COST_LABEL;
	TextField     IDC_TOTAL_COST_TEXTBOX;
	Label         IDC_CALCULATE_USING_LABEL;
	CheckboxGroup group2;
	Checkbox      IDC_CALCULATE_USING_TERM;
	Checkbox      IDC_CALCULATE_USING_PAYMENT;


	// Constructor
	//--------------------------------------------------------------------------
	public MortgageDialog (Container parent)
	{
		m_Parent = parent;
	}

	// Initialization.
	//--------------------------------------------------------------------------
	public boolean CreateControls()
	{
		// CreateControls should be called only once
		//----------------------------------------------------------------------
		if (m_fInitialized || m_Parent == null)
			return false;

		// m_Parent must be extended from the Container class
		//----------------------------------------------------------------------
		if (!(m_Parent instanceof Container))
			return false;

		// Since a given font may not be supported across all platforms, it
		// is safe to modify only the size of the font, not the typeface.
		//----------------------------------------------------------------------
	    Font OldFnt = m_Parent.getFont();
	    if (OldFnt != null)
	    {
			Font NewFnt = new Font(OldFnt.getName(), OldFnt.getStyle(), 8);

    		m_Parent.setFont(NewFnt);
	    }

		// All position and sizes are in dialog logical units, so we use a
		// DialogLayout as our layout manager.
		//----------------------------------------------------------------------
		m_Layout = new DialogLayout(m_Parent, 406, 150);
		m_Parent.setLayout(m_Layout);
		m_Parent.addNotify();

		Dimension size   = m_Layout.getDialogSize();
		Insets    insets = m_Parent.insets();
		
		m_Parent.resize(insets.left + size.width  + insets.right,
                        insets.top  + size.height + insets.bottom);

		// Control creation
		//----------------------------------------------------------------------
		group1 = new CheckboxGroup ();
		IDC_MONTHLY_TYPE = new Checkbox ("Monthly", group1, false);
		m_Parent.add(IDC_MONTHLY_TYPE);
		m_Layout.setShape(IDC_MONTHLY_TYPE, 23, 19, 55, 14);

		IDC_SEMI_MONTHLY_TYPE = new Checkbox ("Semi-Monthly", group1, false);
		m_Parent.add(IDC_SEMI_MONTHLY_TYPE);
		m_Layout.setShape(IDC_SEMI_MONTHLY_TYPE, 23, 32, 55, 16);

		IDC_BI_WEEKLY_TYPE = new Checkbox ("Bi-Weekly", group1, false);
		m_Parent.add(IDC_BI_WEEKLY_TYPE);
		m_Layout.setShape(IDC_BI_WEEKLY_TYPE, 23, 46, 50, 14);

		IDC_WEEKLY_TYPE = new Checkbox ("Weekly", group1, false);
		m_Parent.add(IDC_WEEKLY_TYPE);
		m_Layout.setShape(IDC_WEEKLY_TYPE, 23, 60, 44, 10);

		IDC_MORTGAGE_TYPE_LABEL = new Label ("Mortgatge Type", Label.CENTER);
		m_Parent.add(IDC_MORTGAGE_TYPE_LABEL);
		m_Layout.setShape(IDC_MORTGAGE_TYPE_LABEL, 25, 7, 55, 10);

		IDC_BUTTON_CALCULATE = new Button ("Calculate");
		m_Parent.add(IDC_BUTTON_CALCULATE);
		m_Layout.setShape(IDC_BUTTON_CALCULATE, 119, 81, 106, 15);

		IDC_PRINCIPAL_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_PRINCIPAL_TEXTBOX);
		m_Layout.setShape(IDC_PRINCIPAL_TEXTBOX, 167, 20, 58, 13);

		IDC_INTEREST_RATE_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_INTEREST_RATE_TEXTBOX);
		m_Layout.setShape(IDC_INTEREST_RATE_TEXTBOX, 167, 34, 58, 14);

		IDC_TERM_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_TERM_TEXTBOX);
		m_Layout.setShape(IDC_TERM_TEXTBOX, 167, 50, 58, 12);

		IDC_PAYMENT_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_PAYMENT_TEXTBOX);
		m_Layout.setShape(IDC_PAYMENT_TEXTBOX, 167, 65, 58, 13);

		IDC_MORTGAGE_SPECIFICS_LABEL = new Label ("Mortgage Specifics", Label.LEFT);
		m_Parent.add(IDC_MORTGAGE_SPECIFICS_LABEL);
		m_Layout.setShape(IDC_MORTGAGE_SPECIFICS_LABEL, 137, 7, 70, 10);

		IDC_PRINCIPAL_LABEL = new Label ("Principal:", Label.LEFT);
		m_Parent.add(IDC_PRINCIPAL_LABEL);
		m_Layout.setShape(IDC_PRINCIPAL_LABEL, 117, 22, 44, 11);

		IDC_INTEREST_RATE_LABEL = new Label ("Interest Rate:", Label.LEFT);
		m_Parent.add(IDC_INTEREST_RATE_LABEL);
		m_Layout.setShape(IDC_INTEREST_RATE_LABEL, 117, 36, 47, 10);

		IDC_TERM_LABEL = new Label ("Term:", Label.LEFT);
		m_Parent.add(IDC_TERM_LABEL);
		m_Layout.setShape(IDC_TERM_LABEL, 117, 50, 30, 9);

		IDC_PAYMENT_LABEL = new Label ("Payment:", Label.LEFT);
		m_Parent.add(IDC_PAYMENT_LABEL);
		m_Layout.setShape(IDC_PAYMENT_LABEL, 119, 66, 42, 9);

		IDC_TOTAL_INTEREST_LABEL = new Label ("Total Interest:", Label.LEFT);
		m_Parent.add(IDC_TOTAL_INTEREST_LABEL);
		m_Layout.setShape(IDC_TOTAL_INTEREST_LABEL, 119, 99, 46, 10);

		IDC_TOTAL_INTEREST_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_TOTAL_INTEREST_TEXTBOX);
		m_Layout.setShape(IDC_TOTAL_INTEREST_TEXTBOX, 167, 97, 57, 15);

		IDC_TOTAL_COST_LABEL = new Label ("Total Cost:", Label.LEFT);
		m_Parent.add(IDC_TOTAL_COST_LABEL);
		m_Layout.setShape(IDC_TOTAL_COST_LABEL, 117, 115, 45, 10);

		IDC_TOTAL_COST_TEXTBOX = new TextField ("");
		m_Parent.add(IDC_TOTAL_COST_TEXTBOX);
		m_Layout.setShape(IDC_TOTAL_COST_TEXTBOX, 167, 114, 57, 15);

		IDC_CALCULATE_USING_LABEL = new Label ("Calculate Using", Label.LEFT);
		m_Parent.add(IDC_CALCULATE_USING_LABEL);
		m_Layout.setShape(IDC_CALCULATE_USING_LABEL, 25, 88, 56, 10);

		group2 = new CheckboxGroup ();
		IDC_CALCULATE_USING_TERM = new Checkbox ("Term", group2, false);
		m_Parent.add(IDC_CALCULATE_USING_TERM);
		m_Layout.setShape(IDC_CALCULATE_USING_TERM, 20, 99, 45, 15);

		IDC_CALCULATE_USING_PAYMENT = new Checkbox ("Payment", group2, false);
		m_Parent.add(IDC_CALCULATE_USING_PAYMENT);
		m_Layout.setShape(IDC_CALCULATE_USING_PAYMENT, 20, 114, 50, 10);

		m_fInitialized = true;
		return true;
	}
}
