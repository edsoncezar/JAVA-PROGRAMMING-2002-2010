import java.awt.*;

public class MsgBox {

	public MsgBox(String message){
		this(message,"Message Box");
	}

	public MsgBox(String message, String title){
		int width = message.length() * 6;
		if (width < 200){
			width = 200;
		}

		Frame frame = new Frame();
		messageBox mb = new messageBox(frame, message, title);
		mb.resize(width,100);
		mb.show();
		frame = null;
	}
}

class messageBox extends Dialog{
	private Panel southPanel;
	private Button cb_OK;
	private Label lb_message;

	public messageBox(Frame parent, String output, String title) {

		super(parent, title, true);
		//Add an exit button and a grid panel.
		southPanel = new Panel();
		lb_message = new Label(output);
		southPanel.setBackground(Color.lightGray);
		southPanel.setLayout(new FlowLayout());
		southPanel.add(cb_OK = new Button("OK"));
		add("South", southPanel);
		add("North", lb_message);
	}

	public boolean handleEvent (Event event) {
		if (event.target == cb_OK) { //Was the exit button pushed?
			dispose();
		}
		else {
			// Otherwise, let the superclass handle it
			return super.handleEvent(event);	
		}
		return true;
	}
}
