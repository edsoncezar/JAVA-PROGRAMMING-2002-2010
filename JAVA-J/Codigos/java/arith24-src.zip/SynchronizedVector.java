/*
 * @(#)SynchronizedVector.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

import java.util.Vector;

/**
 * A vector to store the found solution, if solution not available yet,
 * the access method will wait here until the solution become available
 */
public class SynchronizedVector
{
   private Vector vector;
   private boolean available;
   
   public SynchronizedVector()
   {
      vector = new Vector();
      available = false;
   } // constructor   

   public synchronized Vector get() 
   {
      while (available == false) 
      {
         try 
         {
            wait();
         } //try
         catch (InterruptedException e) 
         { 
         } //catch
      } //while
      notifyAll();
      return vector;
    } // get

    public synchronized void put(Vector vector) 
    {
        this.vector = vector;
        available = true;
        notifyAll();
    } //put
}  // SynchronizedVector
   

