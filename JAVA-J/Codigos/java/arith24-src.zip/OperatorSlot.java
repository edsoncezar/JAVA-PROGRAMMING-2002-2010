/*
 * @(#)OperatorSlot.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

/**
 * Slot to hold an operator
 */
public class OperatorSlot extends DraggingSlot implements Type
{
   static final int WIDTH = 27,
                    HEIGHT = 40;
   public OperatorSlot( int x, int y)
   {
      super( x, y, 0, 0 );
      type = OPERATOR_SLOT;
      width = WIDTH;
      height = HEIGHT;
   } // constructor   
   
   public int getType()
   {
      return OPERATOR;
   } // getType
   
} // OperatorSlot