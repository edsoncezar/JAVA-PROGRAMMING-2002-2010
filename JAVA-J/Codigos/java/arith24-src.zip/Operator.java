/*
 * @(#)Operator.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

import java.awt.*;

/**
 * an arithmetic operator, has an image associated with it and 
 * can be drawn and dragged around
 */
public class Operator extends DraggingImage implements Type
{
   /*
    * names of operaters
    */
   static final String [] OP_NAMES = 
            { 
               "add", "minus",  "multi", 
               "div", "oparen", "cparen" 
            };
   /*
    * charactor symbols of operators
    */
   static final char [] OP_SYMBOLS = 
            { '+', '-', '*', '/', '(', ')'};
   
   /*
    * enum of operators
    */
   static final int ADD = 0, 
                    MINUS = 1, 
                    MULTI = 2,
                    DIV = 3,
                    OPAREN = 4,
                    CPAREN = 5;
   /*
    * total number of operators
    */
   static final int OP_NUMBER = 6;
   
   int opId;         // ADD ... CPAREN
   char opSymbol;    // +, -, *, /, (, )
   
   public Operator(int opId, Image image, DraggingArea highestContainer)
   {
      super(image, highestContainer);
      
      
      this.opId = opId;
      opSymbol = OP_SYMBOLS[opId];
      
   } // 3 param id constructor   
   
   public Operator(int opId, int x, int y, Image image, DraggingArea container)
   {
      super(x, y, image, container);
      
      
      this.opId = opId;
      opSymbol = OP_SYMBOLS[opId];
      
   } // 5 param id constructor   
   
   
   public Operator(char symbol, Image image, DraggingArea highestContainer)
   {
      super(image, highestContainer);
      
      opSymbol = symbol;
      for(int i = 0; i < OP_NUMBER; i++)
      {
         if( symbol == OP_SYMBOLS[i] )
         {
            opId = i;
            break;
         } // if
      } // for  
   } // symbol constructor   
   
   public char getOpSymbol()
   {
      return opSymbol;
   } // getOpSymbol   
   
   public Character getValue()
   {
      return new Character(opSymbol);
   } // getOpSymbol   
   
   public int getType()
   {
      return OPERATOR;
   } // getType
   
} // Operator