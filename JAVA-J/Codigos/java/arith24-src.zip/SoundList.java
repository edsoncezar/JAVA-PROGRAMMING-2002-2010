import java.applet.*;
import java.net.URL;

/**
 * Loads and holds a bunch of audio files whose locations are specified
 * relative to a fixed base URL.
 * Credit: Sun
 */
class SoundList extends java.util.Hashtable
{
   Applet applet;
   URL baseURL;

   public SoundList(Applet applet, URL baseURL)
   {
      super(5); 
      this.applet = applet;
      this.baseURL = baseURL;
   } //constructor

   public void startLoading(String relativeURL)
   {
      new SoundLoader(applet, this,
                      baseURL, relativeURL);
   } //startLoading

   public AudioClip getClip(String relativeURL)
   {
      return (AudioClip)get(relativeURL);
   } //getClip

   public void putClip(AudioClip clip, String relativeURL)
   {
       put(relativeURL, clip);
   } //putClip
   
   public synchronized void playClip(String relativeURL)
   {
      AudioClip clip;
      
      clip = getClip(relativeURL);
      
      if (clip != null) 
      {  
         clip.play();    
      } //if 
      else 
      {
          applet.showStatus("Sound " + relativeURL + " not loaded yet.");
      } //else
   } //playClip   
      
} //SoundList
