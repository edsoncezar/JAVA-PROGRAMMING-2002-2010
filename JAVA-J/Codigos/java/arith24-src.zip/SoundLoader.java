
import java.applet.*;
import java.net.URL;

/**
 * Loads a sound file
 * Credit: Sun 
 */
class SoundLoader extends Thread 
{
   Applet applet;
   SoundList soundList;
   URL baseURL;
   String relativeURL;

   public SoundLoader(Applet applet, SoundList soundList,
                      URL baseURL, String relativeURL) 
   {
      this.applet = applet;
      this.soundList = soundList;
      this.baseURL = baseURL;
      this.relativeURL = relativeURL;
      setPriority(MIN_PRIORITY);
      start();
   } //constructor

   public void run() 
   {
      AudioClip audioClip = applet.getAudioClip(baseURL, relativeURL);

      //AudioClips load too fast for me!
      //Simulate slow loading by adding a delay of up to 10 seconds.
       try 
       {
          sleep((int)(Math.random()*10000));
       } //try 
       catch (InterruptedException e) 
       {
       } //catch
       soundList.putClip(audioClip, relativeURL);
   } //run
} //SoundLoader
