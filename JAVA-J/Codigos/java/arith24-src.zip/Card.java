/*
 * @(#)Card.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

import java.awt.*;

/**
 * A playing card, can be drawn and dragged around
 * user should take care of the match between image and suit/value
 */
public class Card extends DraggingImage implements Type
{
   // class varibles
   static final String [] SUIT_NAMES = 
            { 
               "club", "diamond", "heart", "spade" 
            };
            
   static final int CLUB = 0,
                    DIAMOND = 1,
                    HEART = 2,
                    SPADE = 3;
   
   int suit;        // either CLUB, DIAMOND, HEART or SPADE
   int value;       // 1 - 13 
   
   public Card(int suit, int value, Image image, DraggingArea container) 
   {
      super(image, container);
      this.suit = suit;
      this.value = value;
      
	} // 4 param constructor
   
   public Card(int cardId, Image image, DraggingArea container)
   {
      super(image, container);
      
      // id should follow a suit-first order
      suit  = cardId / 13;
      value = cardId % 13 + 1;
      
   } // 3 param constructor
   
   public Card(int cardId, int x, int y, Image image, DraggingArea container)
   {
      super(x, y, image, container);
      
      // id should follow a suit-first order
      suit  = cardId / 13;
      value = cardId % 13 + 1;
      
   } // 5 param constructor
   
   
   public int getCardValue()
   {
      return value;
   } // getCardValue   
   
   public Integer getValue()
   {
      return new Integer(value);
   } // getValue  
   
   public int getType()
   {
      return CARD;
   } // getType
		
} // Card
