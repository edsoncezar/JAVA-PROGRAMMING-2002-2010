/*
 * @(#)PlayingStatus.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

import java.util.Observable;

public class PlayingStatus extends ObservableInteger
{
   static final int DEALED = 1,
                    WAITING = 0,
                    ROUND_OVER = 2;
   
   public PlayingStatus()
   {
      super(ROUND_OVER);
   } // 0 param constructor
   
   public PlayingStatus(int status)
   {
      super(status);
   } // 1 param constructor

} // PlayingStatus