/*
 * @(#)ScoreKeeper.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

import java.awt.*;

public class ScoreKeeper extends Label
{
   int score;
   int increase;
   double levelWeight;
   
   // value of answer
   static final int NO_NO = 1,      //no solution, answer no solution
                    NO_HAS = -2,    //no solution, answer has
                    HAS_NO = -1,    //has solution, answer no
                    HAS_WRONG = -2,
                    HAS_RIGHT = 2,
                    TIME_OUT = -1;
   
   // value of levelWeight
   static final double BEGINNER = 1,
                       INTERMEDIATE = 1.5,
                       EXPERT = 2;
                    
   public ScoreKeeper()
   {
      super("Score:    0", Label.LEFT);
      setFont(new Font("Helvetica", Font.BOLD, 16));
      setForeground(Color.black);
      score = 0;
      increase = 100;
      levelWeight = BEGINNER;
   } // constructor   
   
   public void resetScore()
   {
      score = 0;
      setText("Score: " + score);
   } // resetScore   
   
   public int getScore()
   {
      return score;
   } //getScore   
   
   public void updateScore(int answer, double timePassProportion)
   {
      double timeBonus;
      if(answer > 0)     
      {
         // correct answer, the less the time passed, the more bonus
         timeBonus = 1 - timePassProportion;
      } //if
      else timeBonus = timePassProportion;
      
      score = score + (int)(levelWeight * answer * increase * timeBonus);
      setText("Score: " + score);
   } //updateScore
   
   public void setLevelWeight(double levelWeight)
   {
      this.levelWeight = levelWeight;
   } // setLevelWeight   
   
} // scoreKeeper