public interface Type
{
   public int  getType();
   
   public int  CARD = 0,
               OPERATOR = 1;
} // Type