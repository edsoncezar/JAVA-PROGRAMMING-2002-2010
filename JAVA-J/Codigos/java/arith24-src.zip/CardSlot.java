/*
 * @(#)CardSlot.java Version 1.0 98/03/12
 * 
 * Copyright (c) 1998 by Huahai Yang
 * 
 * Use at your own risk. I do not guarantee the fitness of this 
 * software for any purpose, and I do not accept responsibility for 
 * any damage you do to yourself or others by using this software.
 * This file may be distributed freely, provided its contents 
 * are not tampered with in any way.
 *
 */

/**
 * Slot to hold a card
 */
public class CardSlot extends DraggingSlot implements Type
{
   static final int WIDTH = 75,
                    HEIGHT = 99;
   public CardSlot( int x, int y)
   {
      super( x, y, 0, 0 );
      type = CARD_SLOT;
      width = WIDTH;
      height = HEIGHT;
   } // constructor   
   
   public int getType()
   {
      return CARD;
   } // getType
   
} // CardSlot   
