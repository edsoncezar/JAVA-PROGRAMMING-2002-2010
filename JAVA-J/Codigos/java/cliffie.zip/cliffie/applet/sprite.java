/***********************************************************************************************
	Klassenavn: sprite
	Arver: - 
	Beskrivelse:	superklasse for alle sprites								
************************************************************************************************/
import java.awt.*;
import java.applet.*;


public abstract class sprite {
	
	protected int x_pos;							// Objektets x..
	protected int y_pos;							// ..og y-posisjon

	protected MediaTracker tracker;		// Til � kontrollere nedlasting/oppdeling av bilder
	protected Applet parentApplet;			// En peker til hoved-appleten
	protected Graphics offScrGC;				// En peker til buffer-bildet
	
	protected Rectangle collision;		// Objektets kollisjons-rektangel 

	
	/***********************************************************************************************
		Metodenavn: draw
		Beskrivelse: abstakt metode for opptegning av en sprite
	************************************************************************************************/
	public abstract void draw();	
	
	
	/***********************************************************************************************
		Metodenavn: getPosX/getPosY
		Beskrivelse: returnerer spritens x/y-posisjon
	************************************************************************************************/
	public int getPosX(){return x_pos;}
	public int getPosY(){return y_pos;}

	
	/***********************************************************************************************
		Metodenavn: move
		Beskrivelse: beveger spriten til (x,y)-posisjonen
	************************************************************************************************/
	public void move(int x, int y){
		x_pos = x;
		y_pos = y;
	}

	
	/***********************************************************************************************
		Metodenavn: collisionDetected
		Beskrivelse: sjekker om spriten s kolliderer med denne
	************************************************************************************************/
	public boolean collisionDetected(sprite s){ 
		Rectangle r1 = new Rectangle(collision.x+x_pos,collision.y+y_pos,collision.width,collision.height);
		Rectangle r2 = new Rectangle(s.collision.x+s.x_pos,s.collision.y+s.y_pos,s.collision.width,s.collision.height);
 
		return r1.intersects(r2);
	} 

	/***********************************************************************************************
		Metodenavn: getCollision
		Beskrivelse: returnerer kollisjons-rektangelet til spriten
	************************************************************************************************/
	public Rectangle getCollision(){return collision;}

} // class sprite