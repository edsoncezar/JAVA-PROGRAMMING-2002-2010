/***********************************************************************************************
	Klassenavn: help
	Arver: Frame
	Beskrivelse: �pner et hjelp-vindu
************************************************************************************************/
import java.awt.*;
import java.net.URL;
import java.applet.*;

public class help extends Frame {

	private Font fb, fp, fg;
	private int status = 0;
	private Color bgcolor = null;
						  
  /***********************************************************************************************
		Metodenavn: help (konstukt�r)
		Beskrivelse: legger til meny-valg og setter vinduets st�rrelse
	************************************************************************************************/
	public help(String title) {
    
    super(title);
    bgcolor = new Color(0,115,63);
    setBackground(bgcolor);
    setLayout(new GridLayout(1,1));
  
    fb = new Font("Helvetica", Font.BOLD, 12);
		fp = new Font("Helvetica", Font.PLAIN, 12);
		fg = new Font("Helvetica", Font.BOLD, 18);		
	
		MenuBar mb = new MenuBar();
    Menu m = new Menu("Menu");
    m.add(new MenuItem("Help"));
    m.add(new MenuItem("About"));
    m.add(new MenuItem("-"));
    m.add(new MenuItem("Exit"));
    mb.add(m);
    setMenuBar(mb);	    
    status = 1;
    
    move(100,100);
	
		resize(600,450);
	}

  /***********************************************************************************************
		Metodenavn: action
		Beskrivelse: forandrer status n�r noe har blitt valgt fra menyen
	************************************************************************************************/
	public boolean action(Event evt, Object arg) {
    String label = (String)arg;
    
    if (evt.target instanceof MenuItem) {    	
      if (label.equals("Help")) status = 1;
     	else if (label.equals("About")) status = 2;
     	else if (label.equals("Exit")) {
      	status = 1;
      	hide();
      }
    	repaint();
			return true;
    }
    else return false;		
  } 
    
  /***********************************************************************************************
		Metodenavn: handleEvent
		Beskrivelse: lukker hjelp-vinduet 
	************************************************************************************************/
	public boolean handleEvent(Event evt) {
 		if (evt.id == Event.WINDOW_DESTROY) {
     	status = 1;
     	hide();
  	}
	 return super.handleEvent(evt);
  }
    
  /***********************************************************************************************
		Metodenavn: paint
		Beskrivelse: skriver ut tekst til vinduet avhenging av status
	************************************************************************************************/
	public void paint(Graphics g) {
  	  	  	
  	if (status == 1)
  	{		
  			g.setColor(bgcolor);
  			g.fillRect(0,0,600, 450);
  			g.setColor(Color.white);
  	 		g.setFont(fb);
  	 		g.drawString("The plot:", 20, 100);
  	 		g.setFont(fp);
  	 		g.drawString("In this game you have the great opportunity to be a mailman (more correct: Cliff Clavin from Cheers).", 20, 115);
  	 		g.drawString("You start the game with four lives, a full beer mug, the score of zero points and you got five minutes", 20, 130);
  	 		g.drawString("to complete the round.", 20, 145);
  	  	g.drawString("You maneuver Cliff by using the arrow keys. When you stand in front of the correct mail box (marked", 20, 160);
  	 		g.drawString("with a red arrow), you press \"enter\" to deliver the letter. You have probably already figured out", 20, 175);
  	 		g.drawString("that this is how you collect points in this game. The red arrow will then move to the next mailbox.", 20, 190);
 	  	 	g.drawString("It's not an easy job working as a mailman. You have to look out for cars and dogs. If a car hits you or", 20, 205);
 	  	 	g.drawString("a dog bites you, you will lose a life. It's also important that you make regular visits to the bar", 20, 220);
 	  	 	g.drawString("Cheers to fill up with beer, or else you will lose a life. When you lose a life, Cliff will automatically go", 20, 235);
 	  		g.drawString("to his favorite place to have a beer, and lick his wounds.", 20, 250);
 	  		g.setFont(fb);
  	 		g.drawString("Keys:", 20, 300);	
  	 		g.setFont(fp);
  	 		g.drawString("Arrow keys - Move Cliff in the direction the arrow points.", 20, 315);	
  	 		g.drawString("Enter - Deliver the letter or enter Cheers.", 20, 330);	
  	 		g.drawString("p - Pause the game.", 20, 345);	
  	 		g.drawString("F1 or h - Help.", 20, 360);
  	 		g.drawString("Esc or q - Quit current game.", 20, 375);  	 			 		
  	}
  	else if (status == 2)
  	{  			
  	 		g.setColor(bgcolor);
  			g.fillRect(0,0,600,450);
  			g.setColor(Color.white);
  	 		drawCenterText(fg, 100, "Game developers:", g);	
  	 		drawCenterText(fg, 150, "Robert Nilsen   (Programming/graphics)", g);
  	 		drawCenterText(fg, 200, "Mikkel Sj�lie    (Programming/graphics)", g);
  	 		drawCenterText(fg,  300, "Copyright 1998", g); 		 	 		
  	}
  }  
  
  /***********************************************************************************************
		Metodenavn: drawCenterText
		Beskrivelse: sentrerer tekst
	************************************************************************************************/
  public void drawCenterText(Font fo, int y, String s, Graphics gr) {
  
	  int l = getFontMetrics(fo).stringWidth(s);
	  gr.setFont(fo);
  	gr.drawString(s, (size().width - l)/2, y);
  }
  	 
} // class help