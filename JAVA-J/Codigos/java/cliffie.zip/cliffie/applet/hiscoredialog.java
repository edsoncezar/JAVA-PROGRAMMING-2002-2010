/***********************************************************************************************
	Klassenavn: hiscoredialog
	Arver: Dialog
	Beskrivelse: lar deg skrive inn navnet ditt p� en hiscore-liste	
************************************************************************************************/
import java.awt.*;
import java.applet.*;
import java.awt.image.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.lang.Math;
import cliffie;

public class hiscoredialog extends Dialog {
	
	private TextField name;
	private Label text;
	private int score;
		
	/***********************************************************************************************
		Metodenavn: hiscoredialog (konstrukt�r) 
		Beskrivelse: setter opp en dialogboks med tekstfelt og knapp  
	************************************************************************************************/
	public hiscoredialog(Frame parent){
			
			super(parent,"Congratulations!",true);
			
			setLayout(new FlowLayout());
			setBackground(Color.white);
			setFont(new Font("Helvetica",Font.PLAIN,12));
						
	
			text = new Label("Enter your name for the hiscore list", Label.CENTER); 
			add(text);
			
			name = new TextField(10);
			add(name);
			
			Button ok = new Button("OK");
			add(ok); 
								
			resize(230,120);
			setResizable(false);
			move(300,200);
	} 
	
	/***********************************************************************************************
		Metodenavn: enterHiscore 
		Beskrivelse: viser dialog for innskriving av navn
	************************************************************************************************/
	public void enterHiscore(int s){
		score = s;
		show();
		name.requestFocus();
	}
	
	/***********************************************************************************************
		Metodenavn: getName 
		Beskrivelse: returnerer navnet fra dialogboksen
	************************************************************************************************/
	public String getName(){return name.getText();}
	
	
	/***********************************************************************************************
		Metodenavn: action  
		Beskrivelse: registrerer og behandler trykk p� OK-knapp
	************************************************************************************************/
	public boolean action(Event evt, Object arg){
		if ((String)arg == "OK"){
			hide();
			return true;
		}	else return false;
	}
	
} // class hiscoredialog