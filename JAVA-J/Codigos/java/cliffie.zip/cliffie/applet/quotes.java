/***********************************************************************************************
	Klassenavn: quotes
	Arver: - 
	Beskrivelse:	laster inn og velger ut et sitat
************************************************************************************************/
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.util.*;
import java.net.URL;

public class quotes {
	
	private InputStream quoteFile = null;
	private final int numberOfQuotes = 45;
	private String theQuotes[];
	private String line = null;
	private int counter = 0;
	private int activeQuote;
	private Random rand = null;
	private Applet parentApplet;
	
	/***********************************************************************************************
		Metodenavn: quotes (konstrukt�r)
		Beskrivelse: henter inn quotes fra fil 
	************************************************************************************************/
	public	quotes(Applet applet) {
				
		parentApplet = applet;
		rand = new Random();

		theQuotes = new String[numberOfQuotes];
				
		try {
			quoteFile = new URL(parentApplet.getCodeBase(), "quotes.txt").openStream();		
		} catch(Exception e) {}
	
		DataInputStream textFile = new DataInputStream(quoteFile);
		
		try {
			
			while ((line = textFile.readLine()) != null) {
				theQuotes[counter] = line;
				counter++;				
			}	
		} catch (IOException e) {
		} finally {
			try{
				textFile.close();
			} catch (IOException e){}
		}	
		
	}	

	/***********************************************************************************************
		Metodenavn: getQuote 
		Beskrivelse: returnerer et tilfeldig sitat
	************************************************************************************************/
	public String getQuote() {
		activeQuote = Math.abs(rand.nextInt()) % numberOfQuotes;
		return theQuotes[activeQuote];
	}  	

} // class quotes