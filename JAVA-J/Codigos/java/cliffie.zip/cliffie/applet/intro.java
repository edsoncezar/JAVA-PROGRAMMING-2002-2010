/***********************************************************************************************
	Klassenavn: intro
	Arver: - 
	Beskrivelse: styrer meny-overgangene
************************************************************************************************/
import java.awt.*;
import java.applet.*;
import java.awt.image.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.lang.Math;

public class intro {

	private MediaTracker tracker;		// Til � kontrollere nedlasting
	private Applet parentApplet;			// En peker til hoved-appleten
	private Graphics offScrGC;				// En peker til buffer-bildet
		                      
	private final String imageName = "introscreen.gif";
	private final String soundImageName = "sound.gif";
	private final int picWidth = 668;		// Bredden..
	private final int picHeight = 400; 	// ..og h�yden p� bildet
			
	private final int soundPosX = 71;	 // X og Y for hvor lydmerket
	private final int soundPosY = 194; // skal tegnes
	
	private int offScrDrawY;	// Hvor bildet skal tegnes for bruk av copyArea-funk.
	
	private boolean music = true;
	private Image soundPics[] = new Image[2]; 
	private Image rawSoundImage;
	
	private final int numberOfButtons = 5;
		
	// ID for de Forskjellige knappene:
	
	public final int BUTTON_hiscores = 0;
	public final int BUTTON_music = 1;
	public final int BUTTON_newgame = 2;
	public final int BUTTON_quotes = 3;
	public final int BUTTON_help = 4;	
	
	
	// Status for overgang mellom spill/intro-bilde:
		
	private int transStatus = 0; // 0 = i introstilling, 1 = i spillmodus,  
					         							// 2 = overgang til spill, 3 = overgang fra spill  
	
	private int transX = 0; // Avstanden de to bildehalvdene har fra midten
	private final int transSpeed = 20;
		
	// Rectangler for de forskjellige knappene p� bildet:
	private final int buttons[][] = {{12,156,117,29}, {12,189,93,28}, {550,140,118,29},
															      {573,172,96,28}, {597,204,72,29}};
	
	private Image introPic;	// Intro-bildet
	private boolean hasPaintedOnce = false;
		
	
	/***********************************************************************************************
		Metodenavn: intro (konstrukt�r) 
		Beskrivelse: initierer, henter/kutter opp "music"-ikonet 
	************************************************************************************************/	
	public intro(int y, MediaTracker mt, int mt_id, Graphics g, Applet applet){
		
		parentApplet = applet;
		offScrGC = g;		
		tracker = mt;
		
		offScrDrawY = y;
						
		try {
			// Henter inn:
			rawSoundImage = parentApplet.getImage(parentApplet.getCodeBase(), soundImageName);
			introPic = parentApplet.getImage(parentApplet.getCodeBase(), imageName);
	   	
	   	tracker.addImage(rawSoundImage, mt_id+99);
	   	tracker.addImage(introPic, mt_id);

		} catch (Exception e) {e.printStackTrace();}
	
		// Deler opp bildet i to musikk-ikoner (av/p�):
		soundPics[0] = parentApplet.createImage(new FilteredImageSource(rawSoundImage.getSource(),new CropImageFilter(0,0,19,18)) );		 		
		soundPics[1] = parentApplet.createImage(new FilteredImageSource(rawSoundImage.getSource(),new CropImageFilter(19,0,19,18)) );		 		
		
		tracker.addImage(soundPics[0], mt_id+100);
		tracker.addImage(soundPics[1], mt_id+100);
	}
	
	/***********************************************************************************************
		Metodenavn: checkButton 
		Beskrivelse: returnerer ID til knappen som er blitt trykket (-1 hvis ingen)
	************************************************************************************************/	
	public int checkButton(int x,int y){
		int activeButton = -1;
		
		for (int i = 0; i < numberOfButtons; i++)
			if ((new Rectangle(buttons[i][0],buttons[i][1],buttons[i][2],buttons[i][3])).inside(x,y)){
				activeButton = i;
				break;
			} 
	
		return activeButton;	
	}


	/***********************************************************************************************
		Metodenavn: musicEnabled
		Beskrivelse: returnerer true hvis musikken er p�
	************************************************************************************************/	
	public boolean musicEnabled(){return music;}
	
	
	/***********************************************************************************************
		Metodenavn: changeMusic
		Beskrivelse: sl�r av/p� musikken
	************************************************************************************************/	
	public void changeMusic(){
		music ^= true;
		offScrGC.drawImage(soundPics[(music ? 1:0)],soundPosX,offScrDrawY+soundPosY,parentApplet); 
	} 
	
	
		
	/***********************************************************************************************
		Metodenavn: inTransition, inClosingTransition, inOpeningTransition, 
		            transitionOpen, transitionClosed 
		Beskrivelse: metoder for � avgj�re om intro-bildet er "�pnet"/"lukket" eller i mellomtilstand
	************************************************************************************************/	
	public boolean inTransition(){return transStatus > 1;}
	public boolean inClosingTransition(){return transStatus == 3;}
	public boolean inOpeningTransition(){return transStatus == 2;}
	public boolean transitionOpen(){return transStatus == 1;}
	public boolean transitionClosed(){return transStatus == 0;}
		
	
	/***********************************************************************************************
		Metodenavn: doTransition
		Beskrivelse: setter igang overgangen fra/til intro-bildet
	************************************************************************************************/	
	public void doTransition(){
		if (transStatus == 0) transStatus = 2;
		else if (transStatus == 1) transStatus = 3;		
	}
	
		
	/***********************************************************************************************
		Metodenavn: draw
		Beskrivelse: tegner introbildet ved bruk av copyArea
	************************************************************************************************/	
	public void draw(){
		
		// Sjekker om bildet har blitt tegnet til offscreen-bildet
		
		if (hasPaintedOnce){
		
			if (transStatus == 0) // Ingen overgang
				offScrGC.copyArea(0,offScrDrawY,picWidth,picHeight,0,-offScrDrawY-1); 
			
			else if (transStatus == 2){ // Overgang til spill  
				transX += transSpeed;
				if (transX >= picWidth/2) transStatus = 1;
				
				offScrGC.copyArea(0,offScrDrawY,picWidth/2,picHeight,-transX,-offScrDrawY-1);
				offScrGC.copyArea(picWidth/2,offScrDrawY,picWidth/2,picHeight,transX,-offScrDrawY-1);
			}
			else if (transStatus == 3){ // Overgang fra spill
				transX -= transSpeed;
				if (transX <= 0) transStatus = 0;
	
				offScrGC.copyArea(0,offScrDrawY,picWidth/2,picHeight,-transX,-offScrDrawY-1);
				offScrGC.copyArea(picWidth/2,offScrDrawY,picWidth/2,picHeight,transX,-offScrDrawY-1);
			}
		
		} else {
			// Kopierer bildet til offscreen-bildet ved f�rste opptegning:
			offScrGC.drawImage(introPic,0,offScrDrawY,parentApplet); 
			hasPaintedOnce = true;														
		}
	}
	

} // Class intro