#!/usr/local/bin/perl

####################################################################
#                                                                  #
#  CC_LOG BY CGI CITY IS A VERY SIMPLE LOGGING PROGRAM WHICH LOGS  #
#  THE HITS TO A SINGLE WEB PAGE. IT COLLECTS INFORMATION          #
#  INCLUDING DATE/TIME OF HIT, BROWSER AGENT USED BY THE VISITOR,  #
#  HOST IP ADDRESSES, AND HTTP REFERRERs (WHENEVER AVAILABLE).     #
#                                                                  #
#  THIS PROGRAM MAY BE USED AND DISTRIBUTED FREELY PROVIDED        #
#  NO MODIFICATIONS ARE MADE TO THE CODE.                          #
#                                                                  #
#  Copyright (c) 1998-1999 - CGI City - All rights reserved        #
#  Author: Peter N. Go - cgicity@icthus.net                        #
#                                                                  #
####################################################################
#                                                                  #
#  DISCLAIMER:                                                     #
#  In no event will CGI City be liable to the user of this script  #
#  or any third party for any damages, including any lost profits, #
#  lost savings or other incidental, consequential or special      #
#  damages arising out of the operation of or inability to operate #
#  this script, even if user has been advised of the possibility   #
#  of such damages.                                                #
#                                                                  #
####################################################################

####################################################################
#                                                                  #
#  INSTRUCTIONS:                                                   #
#  1. Change the first line of this script to point correctly to   #
#     your host server's Perl interpreter.                         #
#  2. Under the "ASSIGN THE VARIABLES" section below, change the   #
#     2 variables as needed.                                       #
#  3. Upload this script to your cgi-bin directory and chmod it    #
#     to 777                                                       #
#  4. Upload the file named "log.html" to a directory of your      #
#     choice in your web host server. That directory and the file  #
#     must both be chmod 777                                       #
#  5. Insert an SSI call within your HTML code like this:          #
#     <!--#exec cgi="/path/to/cc_log.pl"-->                        #
#  6. To check your logs, simply view the log.html file from your  #
#     favorite browser.                                            #
#     For example: http://yoursite.com/directory/log.html          #
#                                                                  #
#  NOTE:                                                           #
#  This script will only log the hits of the page where it is      #
#  being called from. This is typically usefull for logging hits   #
#  to the main page.                                               #
#                                                                  #
####################################################################

#######################
## ASSIGN THE VARIABLES
#######################

## ENTER YOUR OWN IP ADDRESS HERE TO AVOID LOGGING YOUR OWN 
## HITS WHEN YOU VISIT YOUR OWN SITE; OTHERWISE, LEAVE IT AS IS

$me = "0.0.0.0";  

## ENTER THE FULL PATH TO WHERE YOU WILL KEEP THE 
## LOG FILES; THIS DIRECTORY AND THE LOG FILE MUST BE 
## MUST BE chmod 777

$log = "/www/path/to/logfiles/log.html";

#############################
## DO NOT EDIT PAST THIS LINE
#############################

$getdate = `date +"%D %T %Z"`; 
chop ($getdate);

if ($ENV{'REMOTE_ADDR'} eq $me) {               
} 
  
else {
    open (LOG, ">>$log");
    print "Content-type: text/html\n\n ";
    print LOG " [ <B>Time:</B> $getdate ] - \n";
    print LOG " [ <B>With:</B> $ENV{'HTTP_USER_AGENT'} ] - \n";
    print LOG " [ <B>Host:</B> $ENV{'REMOTE_HOST'} ] - \n";
    print LOG "[ <B>From:</B> <A HREF=$ENV{'HTTP_REFERER'}>$ENV{'HTTP_REFERER'}</A> ]<BR>\n\n";
    close (LOG);  

}
exit;