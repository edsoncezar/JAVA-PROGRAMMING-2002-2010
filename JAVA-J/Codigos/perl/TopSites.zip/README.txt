#######################################################
#		Top Sites version 1.3
#     
#    		Created by Solution Scripts
# 		Email: solutions@solutionscripts.com
#		Web: http://solutionscripts.com
#
#######################################################
#
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Solution Scripts  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified free of charge, so long as this copyright notice, the header 
# above and all the footers in the program that give me credit remain 
# intact. Please also send me an email, and let me know 
# where you are using this script. 
#
# By using this program you agree to indemnify Solution Scripts from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
######################################################

HISTORY
-------------------
Tuesday, April 14, 1998 - Version 1.3
- Database reading writing enhanced
- No need for new_member.html
- Lots of new error messages

Monday, January 05, 1998 - Version 1.2
- Flock introduced
- Option to change how often html updated

Tuesday, December 16, 1997
- Last minor bug to be fixed for now :(

Monday, December 15, 1997 #2
- Fixed a bug :)

Monday, December 15, 1997
- Cleaned code up
- get to post in newuser.cgi
- Added header and footer files
- Recreate HTML by using topsites.cgi?ID=0

November 14, 1997
- Public Release

-------------------------------------------------------------------------------------------------------
You can now recreate you rankings on demand by using the url
http://yourserver.com/cgi/topsites.cgi?ID=0
--------------------------------------------------------------------------------------------------------



INSTALLATION INSTRUCTIONS


Edit variables.pl it is the only script you need to edit. 
If the path to perl on your server is different from 
#!usr/bin/perl then you will need to change it on the first line 
of both newuser.cgi and topsites.cgi

Below and in variables.pl
are explanations of what you need to change.

Edit headers.txt and footers.txt with any html you like, these will appear on the top and 
bottom of your topsites ranking......... Both files need to be in the same dir as cgi files
 
 Upload all files to your cgi-bin or a create a new dir and chmod it 777
All files must be uploaded in ascii
Chmod all files as follows ..........

 topsites.cgi - 755
 newuser.cgi - 755
 counts.txt - 666
 time.txt - 666


members.db will be created on first member addition. 
When testing to have script create topsites.html without waiting 24 hours,
upload time.txt to your server and then test again..........

topsites.html will be created when topsites.cgi is run ......
And automatically recreated based on the time you specify as
long as click thrus are coming in...

To recreate the thml file whenever you want, run topsites.cgi

The new_member.html file is no longer needed, although it will still work.
To get people to sign up, direct them to the newuser.cgi file......

Any Questions ........... Please post them to Solution Scripts CGI Forum
at http://solutionscripts/forum

Other cgi needs or would you like us to edit and setup top sites for you or we
have a professional version of Top Sites Available.......
http://solutionscripts/

Note: Some servers will not let you read from a browser a file in your cgi bin
Should this be the case for you, you need to have the path and location variables
point to a dir that can be readable thru a browser. Make sure that dir is writable.....

The following is what you need to edit in variables.pl -- Not here.........

###########################################################
$variables{'topsite_name'}="Top Sites Demo";
	# THE NAME OF YOUR TOP SITES
	# the name of your program
	# something like, The top 10 coolest web sites.
	
$variables{'path_to_topsites'}="/mnt/web/public-html/yourname";
	# FULLPATH TO WHERE TOPSITES.HTML SHOULD BE CREATED
	# With out the tralling slash..... 
	# some cgi bins will not let you read from them, for more info see the readme file

$variables{'topsite_location'}="http://www.your-server.com/cgi-bin/topsites";
	# LOCATION OF THE DIR TOPSITES WILL BE CREATED IN
	# Full url of the topsites dir. 
	# WITHOUT the tralling slash 
	
$variables{'topsite_location_cgi'}="http://www.your-server.com/cgi-bin/topsites";
	# LOCATION OF THE CGI DIR TOPSITES FILES ARE IN
	# Full url of the topsites dir. 
	# WITHOUT the tralling slash 


$variables{'topsite_image'}="http://www.your-server.com/you/topsites_image.gif";
$variables{'image_width'}="400";
$variables{'image_height'}="40";
	# YOUR PROGRAM IMAGE
	# This is the image that shows up on the members html code that
	# everyone must click on to view your top sites list
	# image_width is the width of the image
	# image_height is the height of the image

$variables{'your_email'}="you\@bigfoot.com";
     	# REPLY TO FOR MEMBER EMAILS:
     	# This is your Email address, and is used to form the Email header sent
    	# from the server Email system. This should be a valid Email address
   	# so members know where to send questions about your Top Sites. 
     	# NOTE: THE SLASH PRECEEDING THE \@ SYMBOL IS REQUIRED INSIDE DOUBLE 
     	# QUOTES.


  $variables{'mail_prog'}="/usr/sbin/sendmail";
     	# PATH TO MAILER PROGRAM:
     	# This has to point to your sendmail program. If your server does not
     	# have sendmail, you may need to modify the open(MAIL,"|$mailprog -t");
     	# lines in all of the scripts to support whatever format your server
     	# email system requires. If you are not sure, ask your server 
     	# administrator. If you have a virtual domain with your own root 
     	# directory, look in the /usr/sbin ,  /usr/lib, /usr/bin, and similar
     	# directories, for a program named sendmail. If it does not exist, 
     	# ask your server admin what is the correct calling method. This is a
     	# server dependent problem, and we at Solution Scripts cannot help you with 
     	# this. If you have other working scripts that send email, look at 
     	# them for clues.

  $variables{'num_to_show'} = "10";
	# NUMBER OF MEMBERS TO RANK
	# The number of members you want to show in your rankings
	# 10,50,100 what ever
	# It will not matter if number of members is lower than num_to_show

  $variables{'num_banners'} = "1";
	# NUMBER OF MEMBERS BANNERS TO DISPLAY
	# in your rankings top _ get banner displayed
	# 1,5 anything or 0 for none

   $variables{'update_time'} = "86400";
	# NUMBER OF SECONDS BETWEEN UPDATES
	# 86400 = 24 hours
	# 3600 = 1 hour
	# NOTE: no matter what you change this value to, it will still 
	# be a 24 hours before an acount shows up......	

   $variables{'use_flock'} = "0";
	# FILE LOCKING
	# 0 = off   1 = on
	# If you can use file locking set this value to 1
