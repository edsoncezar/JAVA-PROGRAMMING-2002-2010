#######################################################
#		Top Sites version 1.3
#     
#     		Created by: Solution Scripts 
# 		Email: solutions@elitehost.com
#		Web: http://virtual-mktg.com/tiwatson
#
#######################################################
#
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Solution Scripts  All Rights Reserved.
#
# This program is being distributed as freeeware.  It may be used and
# modified free of charge, so long as this copyright notice, the header 
# above and all the footers in the program that give me credit remain 
# intact. Please also send me an email, and let me know 
# where you are using this script. 
#
# By using this program you agree to indemnify Solution Scripts from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
######################################################
# NOTE: You may need to change the /usr/bin/perl line above, 
# and in all the other scripts. The actual path to perl is 
# often different on different server types. If you do not 
# know what it should be set to ask your server admin, or 
# look at other working scripts in your cgi-bin to see what
# they use. This is the ONLY modification required in all of
# the other scripts. All of the following variables MUST be
# set properly before beginning any tests. 
#
###################
# file chmod commands
###################
# topsites.cgi - 755
# newuser.cgi - 755
# counts.txt - 666
# members.db - 666
# time.txt - 666


$variables{'topsite_name'}="Top Sites Demo";
	# THE NAME OF YOUR TOP SITES
	# the name of your program
	# something like, The top 10 coolest web sites.

$variables{'path_to_topsites'}="/mnt/web/guide/solutionscripts/vault/topsites/fdemo";
	# FULLPATH TO WHERE TOPSITES.HTML SHOULD BE CREATED
	# With out the tralling slash..... 
	# some cgi bins will not let you read from them, for more info see the readme file

$variables{'topsite_location'}="http://solutionscripts.com/vault/topsites/fdemo";
	# URL OF WHERE TOPSITES.HTML WILL RESIDE
	# Full url of the topsites dir. 
	# WITHOUT the tralling slash 
	
$variables{'topsite_location_cgi'}="http://solutionscripts.com/vault/topsites/fdemo";
	# LOCATION OF THE CGI DIR TOPSITES FILES ARE IN
	# Full url of the topsites dir. 
	# WITHOUT the tralling slash 

$variables{'topsite_image'}="http://solutionscripts.com/vault/topsites/fdemo/topsites_image.gif";
$variables{'image_width'}="400";
$variables{'image_height'}="40";
	# YOUR PROGRAM IMAGE
	# This is the image that shows up on the members html code that
	# everyone must click on to view your top sites list
	# image_width is the width of the image
	# image_height is the height of the image

$variables{'your_email'}="solutions\@solutionscripts.com";
     	# REPLY TO FOR MEMBER EMAILS:
     	# This is your Email address, and is used to form the Email header sent
    	# from the server Email system. This should be a valid Email address
   	# since Top Sites sends email to new accounts. 
     	# NOTE: THE SLASH PRECEEDING THE \@ SYMBOL IS REQUIRED INSIDE DOUBLE 
     	# QUOTES.


  $variables{'mail_prog'}="/usr/sbin/sendmail";
     	# PATH TO MAILER PROGRAM:
     	# This has to point to your sendmail program. If your server does not
     	# have sendmail, you may need to modify the open(MAIL,"|$mailprog -t");
     	# lines in all of the scripts to support whatever format your server
     	# email system requires. If you are not sure, ask your server 
     	# administrator. If you have a virtual domain with your own root 
     	# directory, look in the /usr/sbin ,  /usr/lib, /usr/bin, and similar
     	# directories, for a program named sendmail. If it does not exist, 
     	# ask your server admin what is the correct calling method. This is a
     	# server dependent problem, and we at Solution Scripts cannot help you with 
     	# this. If you have other working scripts that send email, look at 
     	# them for clues.

  $variables{'num_to_show'} = "25";
	# NUMBER OF MEMBERS TO RANK
	# The number of members you want to show in your rankings
	# 10,50,100 what ever
	# It will not matter if number of members is lower than num_to_show

  $variables{'num_banners'} = "2";
	# NUMBER OF MEMBERS BANNERS TO DISPLAY
	# in your rankings top _ get banner displayed
	# 1,5 anything or 0 for none

   $variables{'update_time'} = "3600";
	# NUMBER OF SECONDS BETWEEN UPDATES
	# 86400 = 24 hours
	# 3600 = 1 hour
	# NOTE: no matter what you change this value to, it will still 
	# be a 24 hours before an acount shows up......	

   $variables{'use_flock'} = "1";
	# FILE LOCKING
	# 0 = off   1 = on
	# If you can use file locking set this value to 1

## END OF REQUIRED MODIFICATIONS
1;



