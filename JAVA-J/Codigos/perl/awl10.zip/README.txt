XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
Auction Weaver 1.07
Copyright 2000, Diran Alemshah
Released - 12/08/2000

CGI Script Center 
http://www.cgiscriptcenter.com
comcart@cgiscriptcenter.com
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



==========================================================
Updates:

1.0 - 02/16/2000  Released!

==========================================================

Auction Weaver LITE was designed to give anyone the ability
to host their own Internet Auctions instantly!  


1.01 - 03/31/2000 - Bug Fix

Users using the option to post without registering were
experiencing an error, which kept requesting for all required
variables to be completed, even when they were.

Fixed.


1.02 - 08/29/2000

Found a security problem which we've fixed in version 1.02.  We
do recommend upgrading to everyone using a previous version.


1.03 - 09/02/2000

READ commands were being run without the "<" READ symbol. This
allowed outside manipulation.  Fixed in version 1.03.  Upgrading
is highly recommended.

1.04 - 09/05/2000

Mistake made the editing of version 1.03.  This gave a "file not
found" error when creating a new directory.  Fixed in version
1.04.


1.05 - 09/25/2000

Thanks to Steve Christey of MITRE, we were able to discover and
fix several loopholes which would allow knowledgable remote
users the ability to delete some of your Auction Weaver data
files.


1.06 - 11/08/2000

During the edit of version 1.04, we added some text
used to test the deletion of items that were past their
expiration date.  That text was not removed properly
after the editing, which keeps Auction Weaver Lite
from properly moving items to a "Closed Auction" status.
Version 1.06 fixes this problem.  Once installed, click
on the links for the items in question, which will move
the item in question to the "Closed Auction" list.

Some submissions were producing unusual lines with
no information and a date of 1969 in them.  The error
was caused by the way the data was stored.  Version 1.06
fixes this problem.  New posts will not have this problem.

1.07 - 12/08/2001

Added the capability of changing the currency sybmol.


EDITING AND INSTALLATION INSTRUCTIONS:
################################################################

Start by opening the auctionweaver.pl file in a text editor,
preferably Notepad (but any text editor will do).  Find the:

#################################################################
#CONFIGURABLE OPTIONS START HERE
#################################################################

title heading.

The first item on the list is the BODY tag information.  Here is where
you can designate the specific background colors, graphics, link colors,
visited link colors, etc.

# Here you can specify the text color, link colors, 
$bodyspec = "BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#0000FF\" VLINK=\"#0000FF\" ALINK=\"#FF0000\" BACKGROUND=\"\"";


Next, you will need to choose your Administration Username and Password.
Be sure to choose names or strings that are not easily guessed.  Please
DO NOT use the default settings, as you run the risk of giving access
to your administration panel to anyone that has a copy of this program.

# Choose your Administration Username
$adminlogin = "admin";

# Choose your Administration Password
$adminpass = "pass";



Next, enter your administration e-mail address.

# Choose your Administration E-mail address
# Be sure to place a backslash before the \@ symbol.
# The backslash is required by Perl.
# Example:  youraddress\@yourhost.com
$from_email_address = "you\@yourserver.com";;


Auction Weaver can use Unix's Sendmail or any SMTP mail server
(for NT users).  Choose the settings as described below (in
your script file, of course.. not here. :))

# If you are using Sendmail (most Unix servers do)
# be sure to type set this variable to:
# $mailusing = 'sendmail'
# If you are using Sockets SMTP mail, set this variable to:
# $mailusing = 'sockets'
$mailusing = 'sendmail';




Please your Sendmail path in the variable setting below (on
the auctionweaver.pl file).  If you are using Sockets (SMTP)
mail, you can leave this variable blank.

# If you are using Sendmail, type the full directory path
# to your Sendmail here.
# Example: $mailprog = "/usr/bin/senmail";
# If you are using Sockets(SMTP) mail, leave this blank:
# Example: $mailprog = "";
$mailprog = "/usr/bin/sendmail";



This setting is used to Override Auction Weaver, if the
program tells you that your path to your Sendmail is incorrect.
Some servers will respond with an error that the path is
incorrect, even when it is correct.  This setting allows
you to override what your server tells Auction Weaver.  Most
of you will not need to use this setting.

# Auction Weaver will check to make sure your above
# $mailprog path is correct.  Every once in a while,
# the server will say the path you have given is incorrect
# when it is actually correct.  If you receive an Incorrect
# Path error message on the screen, and you're SURE the path
# is corect, place a 1 between the quotes below
# Example $mailprog_ok "1";
# Otherwise, do not edit this variable.
$mailprog_ok = "";


If you've chosen to use Sockets(SMTP) mail, you can set the
path to your SMTP mail server here (in the auctionweave.pl file).

# If you use the Sockets mail routine, you'll need to define
# an SMTP mail server path here.
# Example: $smtp_addr = "mail.yourserver.com";
$smtp_addr = "";


Your server *should* be able to create a default Data directory path for
you, just by leaving this setting blank.  If, however, you wish for your
users data to be mainatained in a more secure directory, like a non-web
accessible directory, place the full directory path to the directory you
create here (in the auctionweaver.pl file).



# the data_path is the directory path to the directory where you would like
# your Auction Weaver data files stored.
# A protected directory  would be advisable.
# Example: $data_path = "/full/directory/path/to/data";
# where "data" is a directory you have created.
# Leave it empty for default settings
# or add your own path here.
$data_path = "";



If you wish Auction Weaver to use its own formatted e-mails to notify
your Auction participants of the status of their auctions or bids, you
can leave this field blank.  If, however, you prefer to format your
own e-mails, you may do so with the files found in the "emailtemplates.zip"
file, included with the auctionweaver.pl.  Once you've modified the templates,
upload them to the directory path that you show in the variable below (once
again, in the auctionweaver.pl file).

# Leave it empty for NO templates.  If you wish to use your own e-mail templates,
# use the ones provided with the Auction Weaver .zip file.  DO NOT alter the
# actual template file names, but feel free to modify the contents of each file,
# then upload those templates to the directory name you provide here.
# If you leave this path blank, Auction Weaver will include its own pre-defined
# e-mails in place of the template e-mails.
$email_templates_dir = "";


Here you can define the alternating colors that will appear each time a new
cateogory or item is inputed.

# ALTERNATING TABLE COLORS
@colors = ('#CCCC99','#FFFFFF');



If you wish to keep a record of "Closed" auctions (past their close date),
leave this setting at its default "1".  If you wish for all auctions to be
deleted from the records after their completion, leave the quotation marks
empty.

# If you wish Auction Weaver to maintain an archieve of "Closed Auctions", be
# sure to keep this set to "1", which is the default setting.
# Otherwise, remove the 1 or replace it with a 0 (Zero).
# Example: $keep_closed_auctions = ""; 
$keep_closed_auctions = "1";



If you wish to require your auction participants to register prior to
posting or bidding, leave this configuration variable with the default
setting.  If you don't require anyone to register, you remove the "1"
from between the quotes.

# If you would like your users to register prior to allowing them
# the ability to post a new item, leave this default setting of "1".
# If you would like to give anyone the ability to post items or bids
# without registering, remove the "1" from between the quotes or
# replace it with a "0".
# Example: $require_user_reg = "";
$require_user_reg = "1";



I think this one is self-explanitory...

# If you would like to set a maximum time that any auction
# remains active, after the most recent bid, set the number
# of minutes here.  For example, a user might post an item for
# bid and set a 365 day auction.  You, the administrator, might
# not want any auction available that long.  Here you can set
# the number of minutes after the most recent bid before the
# auction closes.
# Example - for 1 day, set 1440 minutes: $howmany = "1440";
$howmany = "";


File Locking is available on most Web Severs, (Except for Win95/98
servers).  File Locking helps to ensure that your data files do
not get corrupted during heavy usage.  Leave the default setting
unless your server does not support File Locking.

# If you have problems with FILE LOCKING (example: Win95/98 servers)
# set this to 0 (Zero), otherwise, leave the default value of "1".
$flock = "1";


Self-explanitory...

# Place the name of your website here. 
$sitename = "Test Site";


Auction Weaver queries your web server for the server's "Server Name".
This is usually the fully qualified Domain Name of the web server.
If you experience any problems with incomplete links in e-mails, missing
the domain name, you may need to place the path here.  We recommend
leaving it as it is by default initially.  Only modify it if you
experience any problems.

# You shouldn't need to modify this path.  If, however, your server
# does not give this information to Auction Weaver, you may have
# to set the path manually.  Your server path would appears something
# like: $server_name = "www.yourserver.com";
# If you need to set this variable manually, do not use an http://
# in the $server_name variable.
$server_name = "";


(if your server requires .cgi extensions, be sure to rename
the auctionweaver.pl file to auctionweaver.cgi).  This will bring
up your form.


You can find a help forum at: http://support.cgiscriptcenter.com

Enjoy!


CGI Script Center
http://www.cgiscriptcenter.com

Auction Weaver is a registered trademark of
Elite Web Design and Marketing, Inc. and
Diran Alemshah. Copyright 2000.