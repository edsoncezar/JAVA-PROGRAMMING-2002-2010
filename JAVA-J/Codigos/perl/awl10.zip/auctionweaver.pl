#! /usr/bin/perl

############################################
##                                        ##
##          Auction Weaver Lite           ##
##          by CGI Script Center          ##
##       (e-mail cgi@elitehost.com)       ##
##                                        ##
##             version:  1.07             ##
##       last modified:  12/08/2001       ##
##           copyright (c) 2000           ##
##                                        ##
##    latest version is available from    ##
##          The CGI Script Center         ##
##     http://www.cgiscriptcenter.com     ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright Elite Web Design and Marketing, Inc., and Diran Alemshah 2000
# All Rights Reserved.
#
# This program may be used in accorance with the steps outlined
# in this copyright notice.

# Selling the code for this program without prior written consent
# is expressly forbidden, and at no time can this copyright notice
# be removed. 

# DO NO redistribute this program over the Internet or in any other
# medium.  In all cases copyright and header must remain intact.

# LICENSOR'S PROGRAM IS COPYRIGHTED AND LICENSED (NOT SOLE).
# LICENSOR DOES NOT SELL OR TRANSFER TITLE TO THE LICENSED
# PROGRAM TO YOU. YOUR LICENSE OF THE LICENSED PROGRAM WILL
# NOT COMMENCE UNTIL YOU HAVE EXECUTED THIS AGREEMENT AND AN
# AUTHORIZED REPRESENTATIVE OF LICENSOR HAS RECEIVED, APPROVED,
# AND EXECUTED A COPY OF IT AS EXECUTED BY YOU.
# 1. License Grant.</B> Licensor hereby grants to you, and you
# accept, a nonexclusive license to use the downloaded computer
# programs, object code form only (collectively referred to as
# the &quot;Software&quot;), and any accompanying User Documentation,
# only as authorized in this License Agreement. The Software may be
# used on any website owned by Licensee, or if Licensee is a company
# or corporation, any website owned by Licensee company or corporation.
# You agree that you will not assign, sublicense, transfer, pledge,
# lease, rent, or share your rights under this License Agreement.
# You agree that you may not reverse assemble, reverse compile, or
# otherwise translate the Software. Upon loading the Software
# into your computer, you may make a copy of the Software for
# backup purposes. You may make one copy of any User's Manual
# provided for backup purposes. Any such copies of the Software
# or the User's Manual shall include Licensor's copyright and other
# proprietary notices. Except as authorized under this paragraph,
# no copies of the Program or any portions thereof may be made by
# you or any person under your authority or control.
# 
# EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, LICENSOR
# DISCLAIMS ANY AND ALL PROMISES, REPRESENTATIONS, AND WARRANTIES
# WITH RESPECT TO THE LICENSED PROGRAM, INCLUDING ITS CONDITION,
# ITS CONFORMITY TO ANY REPRESENTATION OR DESCRIPTION, THE EXISTENCE
# OF ANY LATENT OR PATENT DEFECTS, ANY NEGLIGENCE, AND ITS
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
# 5. Limitation of Liability. Licensor's cumulative liability
# to you or any other party for any loss or damages resulting
# from any claims, demands, or actions arising out of or relating
# to this Agreement shall not exceed the license fee paid to Licensor
# for the use of the Program (Free - $0.00). In no event shall
# Licensor be liable for any indirect, incidental, consequential,
# special, or exemplary damages or lost profits, even if Licensor
# has been advised of the possibility of such damages.
# 6. Proprietary Protection. Licensor shall have sole and exclusive
# ownership of all right, title, and interest in and to the Licensed
# Program and all modifications and enhancements thereof (including
# ownership of all trade secrets and copyrights pertaining thereto),
# subject only to the rights and privileges expressly granted to you
# herein by Licensor. This Agreement does not provide you with title
# or ownership of the Licensed Program, but only a right of limited
# use. You must keep the Licensed Program free and clear of all claims,
# liens, and encumbrances.
# 7. Restrictions. You may not use, copy, modify, or distribute the
# Licensed Program (electronically or otherwise), or any copy,
# adaptation, transcription, or merged portion thereof, except as
# expressly authorized by Licensor. You may not reverse assemble,
# reverse compile, or otherwise translate the Licensed Program.
# Your rights may not be transferred, leased, assigned, or sublicensed
# except for a transfer of the Licensed Program in its entirety to
# (1) a successor in interest of your entire business who assumes
# the obligations of this Agreement or (2) any other party who is
# reasonably acceptable to Licensor, enters into a substitute
# version of this Agreement, and pays an administrative fee intended
# to cover attendant costs. No service bureau work, multiple-user
# license, or time-sharing arrangement is permitted, except as
# expressly authorized by Licensor. If you use, copy, or modify
# the Licensed Program or if you transfer possession of any copy,
# adaptation, transcription, or merged portion of the Licensed
# Program to any other party in any way not expressly authorized
# by Licensor, your license is automatically terminated.
# 8. Licensor's Right Of Entry. You hereby authorize Licensor
# to enter your premises in order to inspect the Licensed Program
# in any reasonable manner during regular business hours to verify
# your compliance with the terms hereof.
# 9. Injunctive Relief. You acknowledge that, in the event
# of your breach of any of the foregoing provisions, Licensor
# will not have an adequate remedy in money or damages. Licensor
# shall therefore be entitled to obtain an injunction against such
# breach from any court of competent jurisdiction immediately upon
# request. Licensor's right to obtain injunctive relief shall not
# limit its right to seek further remedies.
# 10. Trademark. COMMISSION CART(TM), ACCOUNT MANAGER(TM), PICLINK
# ADVERTISER(TM), BANDWIDTH PROTECTOR(TM), PC CONFIGURATOR(TM),
# Auction Weaver(TM) are all trademarks of Licensor. No right,
# license, or interest to such trademark is granted hereunder,
# and you agree that no such right, license, or interest shall
# be asserted by you with respect to such trademark.
# 11. Governing Law.  This License Agreement shall be construed
# and governed in accordance with the laws of the State of California,
# USA.
# 12. Costs of Litigation. If any action is brought by either party
# to this License Agreement against the other party regarding the
# subject matter hereof, Lincensor shall be entitled
# to recover, in addition to any other relief granted, reasonable
# attorney fees and expenses of litigation.
# 13. Severability. Should any term of this License Agreement be
# declared void or unenforceable by any court of competent
# jurisdiction, such declaration shall have no effect on the
# remaining terms hereof.
# 14. No Waiver. The failure of either party to enforce any
# rights granted hereunder or to take action against the other
# party in the event of any breach hereunder shall not be deemed
# a waiver by that party as to subsequent enforcement of rights
# or subsequent actions in the event of future breaches.
# 15. Integration.  THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE
# STATEMENT OF LICENSOR'S OBLIGATIONS AND RESPONSIBILITIES TO YOU
# AND SUPERSEDES ANY OTHER PROPOSAL, REPRESENTATION, OR OTHER
# COMMUNICATION BY OR ON BEHALF OF LICENSOR RELATING TO THE
# SUBJECT MATTER HEREOF
# PROGRAM DESCRIPTION:

# Whew!  That was a mouthful! :)  On to the configurations!


##################################################################
#CONFIGURABLE OPTIONS START HERE
#################################################################
# Here you can specify the text color, link colors, 
$bodyspec = "BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#0000FF\" VLINK=\"#0000FF\" ALINK=\"#FF0000\" BACKGROUND=\"\"";

# Choose your Administration Username
$adminlogin = "admin";

# Choose your Administration Password
$adminpass = "pass";

# Choose your Administration E-mail address
# Be sure to place a backslash before the \@ symbol.
# The backslash is required by Perl.
# Example:  youraddress\@yourhost.com
$from_email_address = "youraddress\@yourserver.com";

# If you are using Sendmail (most Unix servers do)
# be sure to type set this variable to:
# $mailusing = 'sendmail'
# If you are using Sockets SMTP mail, set this variable to:
# $mailusing = 'sockets'
$mailusing = 'sendmail';

# If you are using Sendmail, type the full directory path
# to your Sendmail here.
# Example: $mailprog = "/usr/bin/senmail";
# If you are using Sockets(SMTP) mail, leave this blank:
# Example: $mailprog = "";
$mailprog = "/usr/bin/sendmail";

# Auction Weaver will check to make sure your above
# $mailprog path is correct.  Every once in a while,
# the server will say the path you have given is incorrect
# when it is actually correct.  If you receive an Incorrect
# Path error message on the screen, and you're SURE the path
# is corect, place a 1 between the quotes below
# Example $mailprog_ok "1";
# Otherwise, do not edit this variable.
$mailprog_ok = "";

# If you use the Sockets mail routine, you'll need to define
# an SMTP mail server path here.
# Example: $smtp_addr = "mail.yourserver.com";
$smtp_addr = "";




# For area's that use currency other then the American Dollar.
# Change this to your currency.
#
# Example(UK):  $currency = "�";
# Example(USA): $currency = "\$";

$currency = "\$";


# the data_path is the directory path to the directory where you would like
# your Auction Weaver data files stored.
# A protected directory  would be advisable.
# Example: $data_path = "/full/directory/path/to/data";
# where "data" is a directory you have created.
# Leave it empty for default settings or add your own path here.
$data_path = "";


# Leave it empty for NO templates.  If you wish to use your own e-mail templates,
# use the ones provided with the Auction Weaver .zip file.  DO NOT alter the
# actual template file names, but feel free to modify the contents of each file,
# then upload those templates to the directory name you provide here.
# If you leave this path blank, Auction Weaver will include its own pre-defined
# e-mails in place of the template e-mails.
$email_templates_dir = "";


# ALTERNATING TABLE COLORS
@colors = ('#CCCC99','#FFFFFF');


# If you wish Auction Weaver to maintain an archieve of "Closed Auctions", be
# sure to keep this set to "1", which is the default setting.
# Otherwise, remove the 1 or replace it with a 0 (Zero).
# Example: $keep_closed_auctions = ""; 
$keep_closed_auctions = "1";

# If you would like your users to register prior to allowing them
# the ability to post a new item, leave this default setting of "1".
# If you would like to give anyone the ability to post items or bids
# without registering, remove the "1" from between the quotes or
# replace it with a "0".
# Example: $require_user_reg = "";
$require_user_reg = "1";

# If you would like to set a maximum time that any auction
# remains active, after the most recent bid, set the number
# of minutes here.  For example, a user might post an item for
# bid and set a 365 day auction.  You, the administrator, might
# not want any auction available that long.  Here you can set
# the number of minutes after the most recent bid before the
# auction closes.
# Example - for 1 day, set 1440 minutes: $howmany = "1440";
$howmany = "";


# If you have problems with FILE LOCKING (example: Win95/98 servers)
# set this to 0 (Zero), otherwise, leave the default value of "1".
$flock = "1";
$LOCK_EX = "2";

# Place the name of your website here. 
$sitename = "Test Site";

# You shouldn't need to modify this path.  If, however, your server
# does not give this information to Auction Weaver, you may have
# to set the path manually.  Your server path would appears something
# like: $server_name = "www.yourserver.com";
# If you need to set this variable manually, do not use an http://
# in the $server_name variable.
$server_name = "";

# Congratulations.  You have completed the basic configuration
# options.  You are ready to install your Auction Weaver Lite.



## Optional Configurations below ##

# If you have Auction Weaver create your DATA directory for you, it
# will set the permissions of the directory for you, in the setting
# below:
$datapermissions = "0755";


# Auction Weaver will create a directory called REGISTER for you. It
# will set the permissions of the directory for you, in the setting
# below:
$registerpermissions = '0755';

# Auction Weaver will create a directory called CLOSED for you, if
# you choose to keep closed auction informtion. It
# will set the permissions of the directory for you, in the setting
# below:
$closedpermissions = '0755';

# Auction Weaver will create individual CATEGORY directories for you.
# It will set the permissions of the directory for you, in the setting
# below:
$categorypermissions = '0755';



## DO NOT EDIT BELOW THIS LINE! ###
###################################
$|++;
use CGI;
$q = new CGI;
## END - DO NOT EDIT ABOVE THIS LINE ##
#######################################

$server_name = $ENV{'SERVER_NAME'} if ($server_name eq "");
$script_url = $ENV{'SCRIPT_NAME'};#Url of your auctionweaver.pl script
########################
# If $email_templates_dir points to a valid directory .. 
# upload the following fi#les --- open each file to find the appropriate variables in a sample template

$dutch_auction_status_message = "dastatus.tlt" ;#dutch auction status message
$bid_passed_message = "bpassed.tlt";#message to be passed to the next lower bidder for normal auction
$winner_message = "wmessage.tlt";#winner message for top bidder-normal auction
$winner_message_rb = "wmessagerb.tlt";#winner message for top bidder who has bid less than reserve bid
$seller_message = "smessage.tlt";#seller messgae for normal auction
$winners_message_da = "wmessageda.tlt";#winners message for ALL dutch auction winners
$seller_message_da = "smessageda.tlt";#seller message for dutch auction
$login_message = "lmessage.tlt";#initial login info 
########################



if ($ENV{'SCRIPT_FILENAME'}) {
$script_filename = $ENV{'SCRIPT_FILENAME'};
$script_filename =~ s/\\/\//g;
} elsif ($ENV{'PATH_TRANSLATED'}) {
$script_filename = $ENV{'PATH_TRANSLATED'};
$script_filename =~ s/\\/\//g;
}

@all = split(/\// , $script_filename);
$cgifile = $all[$#all];
if ($data_path eq "") {
($data_path = $script_filename) =~ s/\/$cgifile$// ;
$data_path .= "/DATA";
} 

umask(000);

$datapermissions = oct($datapermissions);
$registerpermissions = oct($registerpermissions);
$closedpermissions = oct($closedpermissions);
$categorypermissions = oct($categorypermissions);

mkdir ("$data_path" , $datapermissions);
chmod ($datapermissions, "$data_path");
if ($require_user_reg == 1)
{
$register_path = $data_path."/register";
mkdir ("$register_path" , $registerpermissions);
chmod ($registerpermissions, "$register_path");
}




#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#CONFIGURABLE OPTIONS END HERE
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
$f = 0;
$version = "1.07";
$links = <<12345;


        <FONT SIZE="-2" FACE="Arial, Helvetica">
        <A HREF="$script_url?flag1=1&search=1"><B>Search</B></A>
        || <A HREF="$script_url"><B>Categories</B></A> ||
        <A HREF="$script_url?flag1=1&adminsection=1"><B>Category Admin</B></A> ||
        <A HREF="$script_url?flag1=1&additem=1"><B>Add Item</B></A>


12345

    $links .= <<12345 if ($require_user_reg == 1);
        ||
        <A HREF="$script_url?flag1=1&register=1"><B>Register</B></A> ||
        <A HREF="$script_url?flag1=1&edit=1"><B>Edit User Info</B></A> ||
        <A HREF="$script_url?flag1=1&closed=1"><B>View Closed Auctions</B></A>
12345

# $links .= <<12345 if ($keep_closed_auctions == 1);
# 12345

&get_cat;

&get_numberof_items;
$flag1 = $q->param('flag1');
&first if ($flag1 eq "");
$addcat = $q->param('addcat');
&formcat if ($addcat eq  "1");


@pnames = $q->param;
foreach $pp(@pnames)
{
if ($q->param($pp) eq 'Delete' && $addcat ne "")
{
    &delete_cat($pp);
    exit(1);

}
}

if ($addcat eq  "2") {
    &addcat;
    &get_cat;
    &get_numberof_items;
    &formcat;
     
}
$catdir = $q->param('catdir');
## Added 105 ##
if (($catdir) && (!($catdir =~ /^cat[0-9]+$/))) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory<BR>";
exit;
}
$catdir =~ s/\.\.\\//g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
## Added 105 ##

## Added 105 ##
$item = $q->param('item');
$additem = $q->param('additem');
$additemflag = $q->param('additemflag');
$preview = $q->param('preview');
$addregister = $q->param('addregister');
$register = $q->param('register');
$edit = $q->param('edit');
$editactual = $q->param('editactual');
$fromfile = $q->param('fromfile');

## Added 105 ##
&fromcheck;
$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
$fromfile =~ s/\///g;
## Added 105 ##
$placebid = $q->param('placebid');
$closed = $q->param('closed');
$closed1 = $q->param('closed1');
$closed2 = $q->param('closed2');
$search = $q->param('search');
$fromsearch = $q->param('fromsearch');

$adminsection = $q->param('adminsection');
$logged = $q->param('logged');


&admin_login if ($adminsection ne "");
&admin_check if ($logged ne "");

&expand_cat($catdir) if ($catdir ne "" && $item eq "" &&  $fromfile eq "");
&form_item if ($additem ne "" && $additemflag eq "");
&preview if ($preview ne  "");
&add_item if ($additemflag ne "");
&form_register if ($register ne "" && $addregister eq "");
&add_user if ($addregister ne "");
&form_edit if ($edit ne "" && $editactual eq ""); 
&edit if ($editactual ne "");
&show_item if ($fromfile ne "" && $placebid eq "");
&place_bid if ($placebid ne "");
&form_closed if ($closed ne "");
&closed1 if ($closed1 ne "");
&closed2 if ($closed2 ne "");
&form_search if ($search ne "");
&search if ($fromsearch ne "");
exit(1);

sub search {
    &print_header;
#    print <<"12345";
#<table><tr><td>$links</td><td>

#12345

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Search Results
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

    $words = $q->param('words');
    $radio = $q->param('radio');
    &form_search if ($words eq "");
    open(CATFILE , "<$data_path/category.file") || &error("$data_path/category.file $!");
    @catyboys = <CATFILE>;
    chomp(@catyboys);
    close(CATFILE);
    $matched = 0;
    for ($xx = 0; $xx <= $#catyboys ; $xx++)
{
next if ($catyboys[$xx] eq "");
($catdir , $caty) = split(/:/ , $catyboys[$xx]);
opendir(CATDIR , "$data_path/$catdir") || &error("$data_path/$catdir");
@allfiles = readdir(CATDIR);
close(CATDIR);
@truefiles = grep(/\.dat/ , @allfiles);
foreach $file(@truefiles)
{
if (-T "$data_path/$catdir/$file") 

{
				open (FILE, "<$data_path/$catdir/$file") || &error("$data_path/$catdir/$file $!");
				($itemname, $reservebid, $bidinc, $desc, $image, @bids) = <FILE>;
				close FILE;
		chomp ($itemname, $reservebid, $bidinc, $desc, $image, @bids); 
				@lastbid = split(/####/,$bids[$#bids]);
					     
                              ($timy = $file) =~ s/\.dat//;
				@closetime = localtime($timy);
			       $closetime[4] = $closetime[4] + 1;
                              if ((($itemname =~ /$words/i) || ($desc =~ /$words/i) || ($words =~ /$itemname/i) || ($words =~ /$desc/i)) && ($radio eq 'keyword'))
{
    $matched++;
#print <<EOF  if ($matched == 1);   
if ($matched == 1) {

$num = 0;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Category</B></FONT></TD>
        <TD WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item</B></FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Closes</B></FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>#
        Bids</B></FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Highest
        Bid</B></FONT></TD>
      </TR>
      </TABLE>

EOF
}
    print <<"12345";
     <TABLE BORDER="0" WIDTH="500" BGCOLOR="$colors[$num]">
      <TR>
        <TD WIDTH="150"><A HREF="$script_url?flag1=1&catdir=$catdir"><FONT SIZE="-1" FACE="Arial, Helvetica">$caty</FONT></A></TD>
        <TD WIDTH="150"><A HREF="$script_url?flag1=1&catdir=$catdir&fromfile=$timy%2Edat"><FONT SIZE="-1" FACE="Arial, Helvetica">$itemname</FONT></A></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Arial, Helvetica">$closetime[4]/$closetime[3]</FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Arial, Helvetica">$#bids</FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Arial, Helvetica">$lastbid[2]</FONT></TD>
      </TR>
      </TABLE>
12345

$num++;
if ($num == 2) {
$num =0;
}

}#actualsearchif
elsif ($radio eq 'username')

{
    @temp = grep(/$words/i , @bids);
   if ($temp[0] ne "") {

$matched++;
#    print <<"12345"  if ($matched == 1);
if ($matched == 1) {

$num = 0;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Category</B></FONT></TD>
        <TD WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item</B></FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Closes</B></FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>#
        Bids</B></FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Highest
        Bid</B></FONT></TD>
      </TR>
      </TABLE>

EOF
} #matched

    print <<"12345";
     <TABLE BORDER="0" WIDTH="500" BGCOLOR="$colors[$num]">
      <TR>
        <TD WIDTH="150"><A HREF="$script_url?flag1=1&catdir=$catdir"><FONT SIZE="-1" FACE="Arial, Helvetica">$caty</FONT></A></TD>
        <TD WIDTH="150"><A HREF="$script_url?flag1=1&catdir=$catdir&fromfile=$timy%2Edat"><FONT SIZE="-1" FACE="Arial, Helvetica">$itemname</FONT></A></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Arial, Helvetica">$closetime[4]/$closetime[3]</FONT></TD>
        <TD WIDTH="50"><FONT SIZE="-1" FACE="Arial, Helvetica">$#bids</FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Arial, Helvetica">$lastbid[2]</FONT></TD>
      </TR>

12345
$num++;
if ($num == 2) {
$num =0;
}

}#tempif

}#actualsearchover


}#test text file if


}#foreach truefiles

}#catyboy for





print <<"12345" if ($matched > 0);

</table></td></tr></table>


12345

    print <<"12345" if ($matched == 0);
Sorry no match found</td></tr></table>

12345
    &print_footer;
exit(1);

}#supysubdupy sub


sub form_search {
&print_header;

print <<EOF;
<form action=$script_url method=post>
EOF
&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Auction Search
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
print<<EOF;
    <TABLE>
      <TR>
        <TD>
        <CENTER> <FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>SEARCH</B></FONT><BR>
        <INPUT TYPE="text" NAME="words" VALUE="$words"><BR>
        <TABLE BORDER="0">
          <TR>
            <TD><INPUT TYPE="radio" NAME="radio" VALUE="username" CHECKED="CHECKED"></TD>
            <TD><FONT SIZE="-2" FACE="Arial, Helvetica"><B>USERNAME SEARCH</B></FONT></TD>
          </TR>
          <TR>
            <TD><INPUT TYPE="radio" NAME="radio" VALUE="keyword"></TD>
            <TD><FONT SIZE="-2" FACE="Arial, Helvetica"><B>KEYWORD SEARCH</B></FONT></TD>
          </TR>
        </TABLE><INPUT TYPE="hidden" NAME="fromsearch" VALUE="1"><INPUT TYPE="hidden" NAME="flag1" VALUE="1"><INPUT TYPE="submit" NAME="submit" VALUE="Go get it !"></CENTER></TD>
      </TR>
    </TABLE>

</form>

EOF

&print_footer;
exit(1);
}

sub closed2 {
    $bidfile  = $q->param('bidfile');
    ## Added 105 ##
    $bidfile =~ s/\.\.\///g;
    $bidfile =~ s/\.\.//g;
    $bidfile =~ s/\///g;
  if (! ($bidfile =~ /^[0-9]+$/)) {
    print "ERROR: bad filename\n";
    exit;
  }
    ## Added 105 ##
    $username = $q->param('username');
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    $username =~ s/\///g;
    ## Added 105 ##

   open (FILE, "<$data_path/closed/$bidfile.dat") || &error("$data_path/closed/$bidfile.dat $!");
	($itemname, $reservebid, $bidinc, $desc, $image, @bids) = <FILE>;
	close (FILE);
    
    chomp($itemname, $reservebid, $bidinc, $desc, $image, @bids);
$oldimage = $image;
	@firstbid = split(/####/,$bids[0]);
	@lastbid = split(/####/,$bids[$#bids]);
    

&print_header;

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Closed Items
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;


$image = "<br><center><IMG SRC='$image'></center>" if ($image);
print <<"12345";

    <TABLE>
      <TR>
        <TD>
        <CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>$itemname</B></FONT><BR>
         $image<BR>
        <HR SIZE="1" WIDTH="400"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$desc</FONT><HR WIDTH="400" SIZE="1"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bids</B></FONT></CENTER></TD>
      </TR>
    </TABLE>
    <CENTER>
    <TABLE>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Username</B></FONT></TD>
        <TD>
        <CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid
        placed on</B></FONT></CENTER></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid value</B></FONT></TD>
      </TR>
    </TABLE></CENTER>

12345

	foreach $bid (@bids) {
		@linebid = split(/####/,$bid);
		$bidtime = localtime($linebid[3]);
print<<EOF;
    <TABLE>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$linebid[0]</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$bidtime</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$currency$linebid[2]</FONT></TD>
      </TR>
    </TABLE>
EOF
	}


		$dtt = localtime($firstbid[3]);
		print <<"12345";

<HR SIZE="1" WIDTH="400">
    <CENTER><BR><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Seller
    Information</B></FONT></CENTER>
    <TABLE>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Username :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[0]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Email :</FONT></TD>
        <TD><A HREF="mailto:$firstbid[1]"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[1]</FONT></A></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Item placed in
        auction </FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$dtt</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Name :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[4]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Street address :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[5]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">City :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[6]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">State :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[7]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Zip :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$firstbid[8]</FONT></TD>
      </TR>
    </TABLE>
    
    <P><BR>
       </P>
<HR SIZE="1" WIDTH="400">

12345
$dtt = localtime($lastbid[3]);    

print <<"12345";


    <CENTER><BR>
    <B><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Highest Bidder Info</FONT></B></CENTER>
    <TABLE>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Username :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[0]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Email :</FONT></TD>
        <TD><A HREF="mailto:$lastbid[1]"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[1]</FONT></A></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Bid placed on</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$dtt</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Name :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[4]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Street address :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[5]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">City :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[6]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">State :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[7]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Zip :</FONT></TD>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$lastbid[8]</FONT></TD>
      </TR>
    </TABLE>
    <HR SIZE="1" WIDTH="400">

12345

    print <<"12345";
    <CENTER>
    <TABLE BORDER="0" WIDTH="400">
      <TR>
        <TD ALIGN="CENTER"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Highest
        Bid : $currency$lastbid[2]</B></FONT></TD>
      </TR>
      <TR>
        <TD ALIGN="CENTER">
        <CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">Other bids</FONT><BR>
        <BR>
          </CENTER></TD>
      </TR>
    </TABLE></CENTER>
12345

    for ($xx = 1; $xx < $#bids ; $xx++)

{
@linebid = split(/####/,$bids[$xx]);

    print <<"12345";
    <CENTER>
    <TABLE BORDER="0" WIDTH="400" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER"><A HREF="mailto:$linebid[1]"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$linebid[0]</FONT></A></TD>
      </TR>
    </TABLE></CENTER>
12345

}

    print "</center></td></tr></table><br>";

print <<"12345";
<form action=$script_url method=post>
<center>
<input type=hidden name=additem value=1>
<input type=hidden name=flag1 value=1>
<input type=hidden name=itemname value="$itemname">
<input type=hidden name=image value="$oldimage">
<input type=hidden name=username value="$username">
<input type=hidden name=desc value="$desc">
<input type=submit name=submit value="Post This Item Again">
</form>

12345

    &print_footer;
exit(1);
}



sub closed1

{

    $username = $q->param('username');
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    $username =~ s/\.\.//g;
    $username =~ s/\///g;
    ## Added 105 ##
    $password = $q->param('password');
    $return = 0;
    $return = &check_username_password($username , $password) ;
    if ($return == 0)
{
    &form_closed;
    exit(1);
} 

$userfile = $register_path."/$username".".dat";
open(USERFILE, "<$userfile") || &error ("$userfile $!");
($password, $email, $name, $staddress, $city, $state , $zip , @userbids) = <USERFILE>;
chomp ($password, $email, $name, $staddress, $city, $state , $zip , @userbids);
close (USERFILE);

&print_header;

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>No Closed Items
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;


print <<"12345";
    <TABLE WIDTH="500">
      <TR>
        <TD ALIGN="CENTER"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Closed
        Items for $name</B></FONT></TD>
      </TR>
    </TABLE>
12345

    $found =   0;


foreach $bidfile(@userbids)

{

    $file = $data_path."/closed/"."$bidfile.dat";
if (-T  "$file")

{
    $found =  1;
                        open (FILE, "<$file") || &error ("$file $!");
  ($itemname, $reservebid, $bidinc, $desc, $image, @bids) = <FILE>;
			close (FILE);
  chomp($itemname, $reservebid, $bidinc, $desc, $image,@bids);
print <<"12345";

<a href="$script_url?bidfile=$bidfile&flag1=1&username=$username&closed2=1">$itemname</a><br>

12345

}


}

print "No closed items for you" if ($found == 0);
  print "</center></td></tr></table>";
  &print_footer;
exit(1);

}

sub form_closed
{
&print_header;

print <<EOF;
<form action="$script_url" method=post>
<input type=hidden name=flag1 value=1>
<input type=hidden name=closed1 value=1>
EOF

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>View Closed Auctions
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
if ($error_message) {
print<<EOF;
<CENTER><table><tr><td><center>$error_message</center></td><tr><table></CENTER>
EOF
}
print<<EOF;
    <CENTER>
    <TABLE BORDER="0" BGCOLOR="#FFFFFF" CELLPADDING="4">
      <TR>
        <TD ALIGN="RIGHT"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Username</B></FONT></TD>
        <TD ALIGN="CENTER"><INPUT TYPE="text" NAME="username" VALUE="$username"></TD>
      </TR>
      <TR>
        <TD ALIGN="RIGHT"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Password</B></FONT></TD>
        <TD ALIGN="CENTER"><INPUT TYPE="password" NAME="password" VALUE="$password"></TD>
      </TR>
      <TR>
        <TD COLSPAN="2">
        <CENTER><INPUT TYPE="submit" NAME="submit" VALUE="View List"></CENTER></TD>
      </TR>
    </TABLE></CENTER>
</FORM>
EOF

&print_footer;
}

sub place_bid {

    
    $username = $q->param('username');
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    $username =~ s/\.\.//g;
    $username =~ s/\///g;
    ## Added 105 ##
    $passwordin = $q->param('password');
    $bid = $q->param('bid');
    $bid = sprintf ("%.2f",$bid);
    $catdir = $q->param('catdir');
    ## Add 105 ##
if (!($catdir =~ /^cat[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory.<BR>";
exit;
}
$catdir =~ s/\.\.\///g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
unless ($catdir) {
print "Content-type: text/html\n\n";
print "You have not chosen a category.<BR>";
exit;
}
    ## Add 105 ##
    $nobiditem = $q->param('nobiditem');
    $nobiditem = 1 if ($nobiditem eq  "");
   
if ($require_user_reg == 1)
{
$userfile = $register_path."/$username".".dat";
unless (open(USERFILE, "<$userfile"))
{
    $error_message = "Invalid Username";
    &show_item;    
    exit(1);
}
($password, $email, $name, $staddress, $city, $state , $zip , @userbids) = <USERFILE>;
chomp ($password, $email, $name, $staddress, $city, $state , $zip , @userbids);
close (USERFILE);


    $salt = "#x";
    $crypty = crypt($passwordin , $salt);  
if ($crypty ne $password)
{
    $error_message = "Invalid Password";
    &show_item;
        
    exit(1);

}

}
else

{
    $email = $q->param('email');
    $name = $q->param('name');
    $staddress = $q->param('staddress');
    $city = $q->param('city');
    $state = $q->param('state');
    $zip = $q->param('zip');   
    
if ($username eq "" || $email eq "")

{
    $error_message = "Enter the fields marked with *";
    &show_item;    
    exit(1);

}
if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ || $email !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/ && $email ne "") 
{
$error_message = "Invalid email  !!";
&show_item;
exit(1);
}

}
## MODIFIED BY DIRAN
#$data_path =~ s/..\///g;
## Added 105 ##
if (!($catdir =~ /^cat[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory.<BR>";
exit;
}
## Added 105 ##
$catdir =~ s/\.\.\\//g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
## Added 105 ##
unless ($catdir) {
print "Content-type: text/html\n\n";
print "You have not chosen a category.<BR>";
exit;
}
$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
$fromfile =~ s/\///g;
&fromcheck;
## MODIFIED BY DIRAN

open (FROMFILE, "<$data_path/$catdir/$fromfile") || &error("$data_path/$catdir/$fromfile $!");
	($itemname, $reservebid, $bidinc, $desc, $image, $noitems , @bids) = <FROMFILE>;
chomp ($itemname, $reservebid, $bidinc, $desc, $image, $noitems , @bids);
close FROMFILE;
$nb = $#bids;
@firstbid = split(/####/ , $bids[0]);
@lastbid = split(/####/ , $bids[$#bids]);
$cbid = $lastbid[2] + $bidinc;
$vbid = $cbid if ($noitems == 1);
# $vbid = $firstbid[2] if ($noitems > 1);
$vbid = $firstbid[2] + $bidinc  if ($noitems > 1);
## MODIFIED BY DIRAN
if ($bid < $vbid)
## MODIFIED BY DIRAN


{
    $error_message = "Invalid Bid";
    &show_item;
    exit(1);    

}


if ($nobiditem =~ /[^0-9]/ || $nobiditem > $noitems)

{

  $error_message = "Invalid number of items";
  &show_item;
  exit(1);

}

open (FROMFILE, ">>$data_path/$catdir/$fromfile") || &error("$data_path/$catdir/$fromfile $!");
if ($flock == 1)
{
     flock (FROMFILE, 2);
     seek(FROMFILE, 0, 2);

}
$currenttime = time;
$line2 = "$username####$email####$bid####$currenttime####$name####$staddress####$city####$state####$zip####$nobiditem\n";
print FROMFILE $line2;
flock (FROMFILE , 8) if ($flock == 1);
close(FROMFILE);

($itemno = $fromfile) =~ s/\.dat//gi;
$haveflag = 0;

if ($require_user_reg == 1)
{
foreach $bbids(@userbids)
{
    $ity = "$catdir$itemno";
if ( $ity eq $bbids)
{
    $haveflag = 1;

}
}

if ($haveflag == 0)
{
unless (open(USERFILE, ">>$userfile"))
{
    &error("$userfile $!");

}
print USERFILE $ity."\n";
close (USERFILE);

}

}
open (FROMFILE, "<$data_path/$catdir/$fromfile") || &error("$data_path/$catdir/$fromfile $!");
	($itemname, $reservebid, $bidinc, $desc, $image, $noitems , @bids) = <FROMFILE>;
chomp ($itemname, $reservebid, $bidinc, $desc, $image, $noitems , @bids);
close FROMFILE;

($iitem = $fromfile ) =~ s/\.dat//gi;
if ($noitems == 1)
{
$subject = "There was a better bid";

if ($email_templates_dir ne "" && $bid_passed_message ne "")

{

  
    $gbid = $bid; 
    $gauction = $iitem; 
    $gurl = "http://$server_name$script_url?flag1=1&catdir=$catdir&fromfile=$itemno%2Edat";
    $message = "";
    $message = &email_parser("$bid_passed_message");

}

else

{

$message = <<12345;

Your bid on $iitem has been passed ,  If you want to place a higher bid, please visit\:\n\n\t http://$server_name$script_url?flag1=1&catdir=$catdir&fromfile=$itemno%2Edat\n\nThe current high bid is $currency$bid

12345

}
$from = $from_email_address;
$to =  $lastbid[1];                         ; 
&sendmail($to , $from , $subject , $message);
wait;

}
else
{

    for ($ty = 0; $ty <= $#bids ; $ty++)

{
@templine = split (/####/ , $bids[$ty]);
#####$line2 = "$username####$email####$bid####$currenttime####$name####$staddress####$city####$state####$zip####$nobiditem\n";
                   $result[$ty] = $ty;
		   $bid1[$ty] = $templine[2];
                   $nobid1[$ty] =  $templine[9];
                   $time1[$ty] = $templine[3];
                   $username1[$ty] = $templine[0];
                   $email1[$ty] = $templine[1];
}
&dutch_auction;
$subject = "Current status of Dutch auction.";
$message = <<12345;

The TOP $noitems Bids are shown here in that order..\n

12345

 $act = $noitems - 1 ;
 

if ($email_templates_dir ne "" && $dutch_auction_status_message ne "")

{
 
for ($ac = 0 ; $ac <= $act ; $ac++)

{
    $ldtime = localtime($time1[$newresult[$ac]]); 
    $gusername = $username1[$newresult[$ac]];
    $gbid = $bid1[$newresult[$ac]];
    $gnitems = $nobid1[$newresult[$ac]];
    $gbidtime = $ldtime; 
    $message .= &email_parser("$dutch_auction_status_message" , 1);
}
$message = $gtop.$message.$gbottom;
$gtop = "";
$gbottom = "";
}
else
{
 for ($ac = 0 ; $ac <= $act ; $ac++)

{
$ldtime = localtime($time1[$newresult[$ac]]); 
$message .= <<12345

USERNAME: $username1[$newresult[$ac]] \n
BID:  $bid1[$newresult[$ac]] \n
NUMBER OF ITEMS BIDDED : $nobid1[$newresult[$ac]] \n
BID TIME : $ldtime \n\n
------------------------------------------------- \n\n
12345
}
}


for ($tyt = 0 ; $tyt <= $#newresult ; $tyt++)

{
$from = $from_email_address;
$to = $email1[$newresult[$tyt]]; 
&sendmail($to , $from , $subject , $message);
wait;
}
}


unless ($err) {
&print_header;
}
$dtime = localtime($currenttime);

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid Received
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

print <<"12345";

    <CENTER>
    <TABLE WIDTH="500">
      <TR>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$username , Your bid for
        <B>$currency$bid</B> has been placed on <B><A HREF="http://$server_name$script_url?flag1=1&catdir=$catdir&fromfile=$itemno%2Edat">$itemname</A></B>
        ( <B><A HREF="http://$server_name$script_url?flag1=1&catdir=$catdir&fromfile=$itemno%2Edat">$itemno</A></B>
        ) exactly at $dtime.</FONT> </TD>
      </TR>
    </TABLE></CENTER>
12345

&print_footer;

return 1;

}


sub show_item

{




## Added 105 ##

## MODIFIED BY DIRAN
$data_path =~ s/\.\.\///g;
## Added 105 ##
if (!($catdir =~ /^cat[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory.<BR>";
exit;
}
## Added 105 ##
$catdir =~ s/\.\.\\//g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
## Added 105 ##
unless ($catdir) {
print "Content-type: text/html\n\n";
print "You have not chosen a category.<BR>";
exit;
}
$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
&fromcheck;

## Added 105 ##
## MODIFIED BY DIRAN

####$line1 = "$itemname\n$reservebid\n$bidinc\n$desc\n$image\n";  
#######$line2 = "$username####$email####$startbid####$currenttime####$name####$staddress####$city####$state####$zip\n";   
       ($endtime = $fromfile) =~ s/\.dat//gi; 


       open(CATFILE , "<$data_path/category.file");
if ($LOCK_EX) {
     flock (CATFILE, $LOCK_EX);
}

       @content = <CATFILE>;
       close(CATFILE); 

       @temp = grep(/$catdir:/i , @content);
       ($dummy , $cattitle) = split(/:/ , $temp[0]);
       open (FROMFILE, "<$data_path/$catdir/$fromfile") || &error("$data_path/$catdir/$fromfile $!");
if ($LOCK_EX) {
     flock (FLOCKFILE, $LOCK_EX);
}

	($itemname, $reservebid, $bidinc, $desc, $image,$noitems, @bids) = <FROMFILE>;
	close FROMFILE;
       chomp($itemname, $reservebid, $bidinc, $desc, $image,$noitems, @bids);
	@firstbid = split(/####/,$bids[0]);
	@lastbid = split(/####/,$bids[$#bids]);
	$thistime = localtime(time);
	$closetime = localtime($endtime);
#	$image = "<br><center><IMG SRC='$image'></center><hr>" if ($image);

## Added version 1.06
foreach $line($desc) {
#chomp($line);
#$desc =~ s/\r//g;
#$line =~ s/\r//g;
$line =~ s/\\n/\n/g;
}
##


&print_header;
&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>$itemname
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF

&theader3;
#<table><tr><td align=top>$links</td><td><center><h4>$itemname</h4></center>$image<br>
if ($image) {
print <<"12345";
    <CENTER>
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD ALIGN="CENTER"><IMG SRC="$image"></TD>
      </TR>
      <TR>
        <TD ALIGN="CENTER"><HR SIZE="1"></TD>
      </TR>
    </TABLE></CENTER>
12345
}

#if ($noitems > 1);
if ($noitems > 1) {
print <<EOF;


<CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Dutch Auction
    Style</B></FONT><BR></CENTER>

EOF
}

print <<EOF;
    <CENTER>
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Category</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$cattitle</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item posted
        by</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$firstbid[0]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Number of
        items</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$noitems</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bids</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$#bids</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Last bid</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$lastbid[2]</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Current time</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$thistime</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid closes at</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$closetime</FONT></TD>
      </TR>
    </TABLE></CENTER>
EOF

if ($howmany) { 
    
  $hsec = $howmany * 60;
  $hsec  = $lastbid[3] + $hsec;
  $dhsec = localtime($hsec);


print <<EOF;

    <CENTER>
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD WIDTH="215" NOWRAP="NOWRAP"></TD>
        <TD>
        
        <P><FONT SIZE="-1" FACE="Arial, Helvetica">(or at) $dhsec</FONT></P></TD>
      </TR>
    </TABLE></CENTER>
EOF

}

print <<"12345";

    <CENTER>
    <TABLE WIDTH="500">
      <TR>
        <TD COLSPAN="4"><HR SIZE="1"></TD>
      </TR>
      <TR>
        <TD COLSPAN="4" ALIGN="CENTER">
        <CENTER>
        <TABLE BORDER="0" CELLPADDING="1" WIDTH="500">
          <TR>
            <TD BGCOLOR="#000000">
            <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
              <TR>
                <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Description</B></FONT></TD>
              </TR>
            </TABLE></TD>
          </TR>
        </TABLE></CENTER>
        <TABLE BORDER="0" WIDTH="350">
          <TR>
            <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">$desc</FONT></TD>
          </TR>
        </TABLE></TD>
      </TR>
      <TR>
        <TD COLSPAN="4"><HR SIZE="1"></TD>
      </TR>
      <TR>
        <TD COLSPAN="4" ALIGN="CENTER">
        <CENTER>
        <TABLE BORDER="0" CELLPADDING="1" WIDTH="500">
          <TR>
            <TD BGCOLOR="#000000">
            <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
              <TR>
                <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Previous
                Bids</B></FONT></TD>
              </TR>
            </TABLE></TD>
          </TR>
        </TABLE></CENTER></TD>
      </TR>
      <TR>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Username</B></FONT></TD>
        <TD WIDTH="200"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid
        placed on</B></FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid
        Value</B></FONT></TD>
        <TD WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>#
        of Items</B></FONT></TD>
      </TR>
    </TABLE></CENTER>
12345

#<hr>
#<center>$desc</center><br><hr>
#<center>Previous Bids</center>
#<center><table><tr><td>Username</td><td><center>Bid placed on</center></td><td>Bid value</td><td>Number of Items</td></tr>



      $num=0;
	foreach $bid (@bids) {
		@linebid = split(/####/,$bid);
		$bidtime = localtime($linebid[3]);
		
print <<EOF;
    <CENTER>
    <TABLE BORDER="0" WIDTH="500" BGCOLOR="$colors[$num]" CELLPADDING="0" CELLSPACING="0">
      <TR>
        <TD WIDTH="100" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$linebid[0]</FONT></TD>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$bidtime</FONT></TD>
        <TD WIDTH="100" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$linebid[2]</FONT></TD>
        <TD WIDTH="100" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$linebid[9]</FONT></TD>
      </TR>
    </TABLE></CENTER>
EOF
$num++;
if ($num == 2) {
$num =0;
 }
}

#		print "</table>";
		$time = time;
 if (($time > $endtime) || ($time > $hsec && $howmany >= 1)) {
print<<EOF;
    <CENTER><BR>
    <FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>ITEM CLOSED FOR
    BIDDING</B></FONT><BR>
      </CENTER>
EOF

#print "Content-type: text/html\n\n";
#print "In Show Item<BR>";
#exit;

		&item_closed;
	}
	else {
		&form_for_placing_bid;
	

		&print_footer;

}
} 


sub form_for_placing_bid {

## MODIFIED BY DIRAN
#$data_path =~ s/..\///g;
## Added 105 ##
if (!($catdir =~ /^cat[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory.<BR>";
exit;
}
## Added 105 ##
$catdir =~ s/\.\.\\//g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
## Added 105 ##
unless ($catdir) {
print "Content-type: text/html\n\n";
print "You have not chosen a category.<BR>";
exit;
}
$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
$fromfile =~ s/\///g;
&fromcheck;
## MODIFIED BY DIRAN

    $atleast = $lastbid[2] + $bidinc;
    
if ($noitems > 1) {

# $firstbid[2] = sprintf ("%.2f",$firstbid[2]);
$vbid = $firstbid[2] + $bidinc  if ($noitems > 1);
$vbid = sprintf ("%.2f",$vbid);

print <<"12345";
    <CENTER><BR><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Place Bid</B><BR>
    <BR>
     Last Bid : <B>$currency$lastbid[2]</B> Your Bid must be at least Start bid <B>$currency$vbid</B><BR>
    </FONT></CENTER>
12345
} else {
$atleast = sprintf ("%.2f",$atleast);
print <<"12345";
    <CENTER><BR><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Place Bid</B><BR>
     <BR>
     Last Bid : <B>$currency$lastbid[2]</B> Your Bid must be at least <B>$currency$atleast</B><BR>
    </FONT></CENTER>
12345
}
print <<"12345"; 
<center><br><b>$error_message</b></br>

<form action=$script_url method=post>
<input type=hidden name=flag1 value=1>
<input type=hidden name=fromfile value="$fromfile">
<input type=hidden name=placebid value=1>
<input type=hidden name=catdir value="$catdir">
    <TABLE WIDTH="400">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Username</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="username" VALUE="$username"></TD>
      </TR>
    </TABLE>
12345

if ($require_user_reg == 1) {
    print <<"12345";
    <TABLE WIDTH="400">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Password</B></FONT></TD>
        <TD><INPUT TYPE="password" NAME="password" VALUE=""></TD>
      </TR>
    </TABLE>
12345

}
else
{
    print <<"12345";
    <TABLE WIDTH="400">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Email</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="email" VALUE="$email"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Name</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="name" VALUE="$name"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Street
        Address</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="staddress" VALUE="$staddress"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>City</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="city" VALUE="$city"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>State</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="state" VALUE="$state"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP" ><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Zip</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="zip" VALUE="$zip"></TD>
      </TR>
      </TABLE>
12345

}

#if ($atleast) {
#$lowestbid = "$atleast";
#} else {
#$lowestbid = "$firstbid[2]";
#}

if ($noitems > 1) {

# $lowestbid = "$firstbid[2]";
$lowestbid = "$vbid";
} else {

$lowestbid = "$atleast";
}


    print <<"12345";
    <TABLE WIDTH="400">
      <TR>
        <TD NOWRAP="NOWRAP" WIDTH="200"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid
        Value</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="bid" VALUE="$lowestbid"></TD>
      </TR>
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Number
        of items</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="nobiditem" VALUE="$nobiditem"></TD>
      </TR>
      <TR>
        <TD COLSPAN="2" ALIGN="CENTER"><INPUT TYPE="submit" NAME="sbutton" VALUE="BID"></TD>
      </TR>
    </TABLE>

12345
}

sub copyfile {
    ($sourcefile, $destfile) = @_;
    open (SOURCE , "<$sourcefile") || &error("$sourcefile $!");
    open (DEST , ">$destfile") || &error("$destfile $!");
       while($com = <SOURCE>)
{
  
print DEST  $com;     

}

close (SOURCE);
close(DEST);
return 1;
}

sub item_closed

{
if ($keep_closed_auctions == 1)
{

## MODIFIED BY DIRAN
#$data_path =~ s/..\///g;
## Added 105 ##
if (!($catdir =~ /^cat[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "$catdir is not an Auction Weaver category directory.<BR>";
exit;
}
## Added 105 ##
$catdir =~ s/\.\.\\//g;
$catdir =~ s/\.\.//g;
$catdir =~ s/\///g;
## Added 105 ##
unless ($catdir) {
print "Content-type: text/html\n\n";
print "You have not chosen a category.<BR>";
exit;
}
$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
$fromfile =~ s/\///g;
&fromcheck;
## MODIFIED BY DIRAN

    $closed_dir = "closed";
   
#print "$data_path<BR>";
#print "$closed_dir<BR>";
#print "$catdir<BR>";
#print "$fromfile<BR>";


    mkdir ("$data_path/$closed_dir" , $closedpermissions) unless ( -d "$data_path/$closed_dir");
     chmod ($closedpermissions, "$data_path/$closed_dir");
    &copyfile("$data_path/$catdir/$fromfile" , "$data_path/$closed_dir/$catdir$fromfile");
}
unlink($sourcefile) || 	&error("$sourcefile $!");
wait;

if ($noitems == 1)
{
if ($lastbid[2] >= $reservebid) {
    $to = $lastbid[1];
        $subject = "Auction Close: $itemname";
      $from = $from_email_address;

if ($email_templates_dir ne "" && $winner_message ne "")

{
    $gbidtime = $endtime;
    $gbid = $lastbid[2];
    $gname = $firstbid[4];
    $gstaddress = $firstbid[5];
    $gcity = $firstbid[6];
    $gstate = $firstbid[7];
    $gzip = $firstbid[8];
$message = &email_parser ("$winner_message");
 
}

else
{
    $message= <<12345;

You have WON the AUCTION $endtime .\nYour winning bid was $currency$lastbid[2].\n\nSeller Info\n-----------------------\nName : $firstbid[4]\nStreet Address : $firstbid[5]\nCity : $firstbid[6]\nState : $firstbid[7]\nZip : $firstbid[8]\n\n

12345

}
	&sendmail($to  , $from , $subject , $message); 
		}
		else 
{
 $to = $lastbid[1];
    $from = $from_email_address;
        $subject = "Auction Close: $itemname";


if ($email_templates_dir ne "" && $winner_message_rb ne "")

{
    $gbidtime = $endtime;
    $gbid = $lastbid[2];
    $gname = $firstbid[4];
    $gstaddress = $firstbid[5];
    $gcity = $firstbid[6];
    $gstate = $firstbid[7];
    $gzip = $firstbid[8];
    $gauction = $endtime;
$message = &email_parser ("$winner_message");
 
}

else

{
    $message= <<12345;
Your bid for Auction $endtime was the best one even though .\nYour bid ($currency$lastbid[2]) was less than the RESERVE BID \n\nSeller Info\n-----------------------\nName : $firstbid[4]\nStreet Address : $firstbid[5]\nCity : $firstbid[6]\nState : $firstbid[7]\nZip : $firstbid[8]\n\n

12345

}
&sendmail($to  , $from , $subject , $message , $winner_message_rb); 
			
		}
$to = $firstbid[1];
$from = $from_email_address;
$subject = "Auction Close: $itemname";
if ($email_templates_dir ne "" && $seller_message ne "")
{

    $gbidtime = $endtime;
    $gbid = $lastbid[2];
    $gname = $lastbid[4];
    $gstaddress = $lastbid[5];
    $gcity = $lastbid[6];
    $gstate = $lastbid[7];
    $gzip = $lastbid[8];
    $gauction = $endtime;
    $grbid = $reservebid;
    $message = &email_parser ("$seller_message");
 
}
else
{
$message = <<12345;
Auction $endtime Is Now Closed.\nThe highest bid was $currency$lastbid[2] (Your reserve was: $currency$reservebid).\n\nBidder Info\n---------------\nName : $lastbid[4]\nStreet Address : $lastbid[5]\nCity : $lastbid[6]\nState : $lastbid[7]\nZip : $lastbid[8]\n\n

12345

}
&sendmail($to  , $from , $subject , $message ); 
}
else
{

for ($ty = 0; $ty <= $#bids ; $ty++)

{
@templine = split (/####/ , $bids[$ty]);
#####$line2 = "$username####$email####$bid####$currenttime####$name####$staddress####$city####$state####$zip####$nobiditem\n";
                   $result[$ty] = $ty;
		   $bid1[$ty] = $templine[2];
                   $nobid1[$ty] =  $templine[9];
                   $time1[$ty] = $templine[3];
                   $username1[$ty] = $templine[0];
                   $email1[$ty] = $templine[1];
}
&dutch_auction;
@templine = "";
$lastgood = $newresult[$#newresult];
@templine = split (/####/ , $bids[$lastgood]);
$goodbid = $templine[2]; 
$ai = $noitems;
for ($yyt = 0; $yyt <= $#newresult ; $yyt++)
{
    next if ($ai < 1);
    $from = $from_email_address;
    $to = $email1[$newresult[$yyt]];
    $subject = "Auction closed";
    $bidyboy = $newresult[$yyt];
    @templine = "";
    @templine = split (/####/ , $bids[$bidyboy]);

if ($email_templates_dir ne "" && $winners_message_da ne "")

{

    $gbid = $goodbid;
    $gname = $firstbid[4];
    $gstaddress = $firstbid[5];
    $gcity = $firstbid[6];
    $gstate = $firstbid[7];
    $gzip = $firstbid[8];
    $gauction = $endtime;
 $gnitems = $templine[9];
 $gaitems = $ai;
    $message = &email_parser ("$winners_message_da");


}
else
{
    $message  = <<12345;

You have WON the DUTCH AUCTION $endtime .\nYour winning bid was $currency$goodbid for $templine[9] Items \nAvailable Items $ai\nSeller Info\n-----------------------\nName : $firstbid[4]\nStreet Address : $firstbid[5]\nCity : $firstbid[6]\nState : $firstbid[7]\nZip : $firstbid[8]\n\n

12345
}
&sendmail($to  , $from , $subject , $message); 




if ($email_templates_dir ne "" && $seller_message_da ne "")

{

 $gbid = $templine[2];
    $gname = $templine[4];
    $gstaddress = $templine[5];
    $gcity = $templine[6];
    $gstate = $templine[7];
    $gzip = $templine[8];
    $gauction = $endtime;
 $gnitems = $templine[9];
    $bidder_info .= &email_parser ("$seller_message_da");

}
else
{

$bidder_info .= "---------------------------\nName : $templine[4]\nStreet Address : $templine[5]\nCity : $templine[6]\nState : $templine[7]\nZip : $templine[8]\nBid Value : $templine[2]\nNumber of Items : $templine[9] \n\n";

}
$ai = $ai - $templine[9];

}
    $to = $firstbid[1];
    $from = $from_email_address;
    $subject = "Auction Close";
    

if ($email_templates_dir ne "" && $seller_message_da ne "")

{

    $message = $gtop.$bidder_info.$gbottom;
}
else
{
$message = <<12345;
Auction $endtime Is Now Closed.\n\nBidders Info $bidder_info

12345

}
&sendmail($to  , $from , $subject , $message); 
}
}
sub edit

{
&get_form_register_param;    
&check_form_edit;
$userfile = $register_path."/$username".".dat";
open(USERFILE, "<$userfile") || &error("$userfile $!");
($password8, $email8, $name8, $staddress8, $city8, $state8 , $zip8 , @userbids8) = <USERFILE>;
chomp ($password8, $email8, $name8, $staddress8, $city8, $state8 , $zip8 , @userbids8);
close (USERFILE);
$email = $email8 if ($email eq "");
$name = $name8 if ($name eq "");
$staddress = $staddress8 if ($staddress eq "");
$city = $city8 if ($city eq "");
$state = $state8 if ($state eq "");
$zip = $zip8 if ($zip eq "");

    $salt = "#x";
    $crypty = crypt($newpass1, $salt); 

open (USERFILE , ">$register_path/$username.dat") || &error("$register_path/$username.dat  $!");
    $line = "$crypty\n$email\n$name\n$staddress\n$city\n$state\n$zip\n";
    print USERFILE $line;
    print @userbids8;
    close(USERFILE);
    
## MODIFIED BY DIRAN
print "Content-type: text/html\n\n";
## MODIFIED BY DIRAN


&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>User Details Edited
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF

&theader3;

print <<"12345";
    <CENTER>
    <TABLE WIDTH="500">
      <TR>
        <TD ALIGN="CENTER">
        <CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Your
        details have been succesfully edited</B></FONT></CENTER></TD>
      </TR>
    </TABLE></CENTER>
12345
&print_footer;
exit(1);

}

sub check_form_edit

{
$userfile = $register_path."/$username".".dat";
unless (open(USERFILE, "<$userfile"))
{
    $error_message = "Invalid login";
    &form_edit;

}
($password8, $email8, $name8, $staddress8, $city8, $state8 , $zip8 , @userbids8) = <USERFILE>;
chomp ($password8, $email8, $name8, $staddress8, $city8, $state8 , $zip8 , @userbids8);
close (USERFILE);

    $salt = "#x";
    $crypty = crypt($oldpass, $salt); 

if ($crypty ne $password8)
{

 $error_message = "Invalid login";
 &form_edit;
}
if ($newpass1 ne $newpass2)
{
$error_message = "New passwords DONT match !!";
&form_edit;
}
if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ || $email !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/ && $email ne "") 
{
$error_message = "Invalid email  !!";
&form_edit;
}
 
}


sub form_edit

{
&print_header;
print <<EOF;
<form action=$script_url>
<input type=hidden name=flag1 value=1>
<input type=hidden name=editactual value=1>
EOF

if ($error_message) {
print<<EOF;
<table><tr><td><center><b>$error_message</b></center><td><tr><table>
EOF
}
&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Edit User Information
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
print<<EOF;

    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Username</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="username" VALUE="$username"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Old Password</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="oldpass" VALUE=""></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>New Password</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="newpass1" VALUE=""></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>New Password
        (again)</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="newpass2" VALUE=""></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Email</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="email" VALUE="$email"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Full Name</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="name" VALUE="$name"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Street
        Address</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="staddress" VALUE="$staddress"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>City</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="city" VALUE="$city"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>State</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="state" VALUE="$state"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Zip</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="zip" VALUE="$zip"></TD>
      </TR>
      <TR>
        <TD COLSPAN="2" ALIGN="CENTER"><INPUT TYPE="submit" NAME="submit" VALUE="Submit"></TD>
      </TR>
    </TABLE>

</form>

EOF


    &print_footer;
    exit(1);

}


sub add_user
{

    &check_form_register;
    $newpassword = &password_making;
    $salt = "#x";
    $crypty = crypt($newpassword , $salt);  
    open (USERFILE , ">$register_path/$username.dat") || &error("$register_path/$username.dat  $!");
    $line = "$crypty\n$email\n$name\n$staddress\n$city\n$state\n$zip\n";
    print USERFILE $line;
    close (USERFILE);    
    &print_header;
    
&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>User Information
        Received</B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

print <<EOF;
    <CENTER>
    <TABLE WIDTH="500">
      <TR>
        <TD>
        <CENTER><FONT SIZE="-1" FACE="Arial, Helvetica">Your login details
        have been mailed to $email</FONT></CENTER></TD>
      </TR>
    </TABLE></CENTER>
EOF

    &print_footer;
    $to = $email;
    $from = $from_email_address;
    $subject = "YOUR LOGIN DETAILS";

if ($email_templates_dir ne "" && $login_message ne "")
{

 $gusername = $username;
 $gpassword = $newpassword;
 $message = &email_parser ("$login_message");

}
else
{
    $message = "\nyour login details are as follows:-\n\nUsername : $username\nPassword : $newpassword \n";
}
&sendmail($to , $from , $subject , $message );
    exit(1);

}

sub send_mail

{
    $to = $_[0];
    $from = $_[1];
    $subject = $_[2];
    $message = $_[3];
    ## MODIFIED BY DIRAN
    #open(MAIL,"| $MAIL") ;
    open (MAIL, "|$MAIL -t") || print ("Can't open $MAIL!\n");
    ## MODIFIED BY DIRAN

print MAIL "To: $to\n";
print MAIL "From: $from\n";
print MAIL "Subject: $subject\n";

print MAIL <<"12345";

$message 

12345


close(MAIL);

}



sub sendmail {


	my($to, $from, $subject, $message, $tempfile) = @_;

	if (lc $mailusing eq 'sendmail') {
            if (-e $mailprog) {
            open (MAIL, "|$mailprog -t");
            } else {
            unless ($mailprog_ok) {
            print "Content-type: text/html\n\n";
            print "The path to your Sendmail: $mailprog doesn't seem to be correct<BR>";
            $err = "1";
            }
            }

		print MAIL "To: $to\n";
		print MAIL "From: $from\n";
		print MAIL "Subject: $subject\n";
		print MAIL "$message\n";
		close MAIL;
		}
	else
			{
			$err = &sockets_mail($to, $from, $subject, $message); 
			if ($err < 1)
                        
				{
                         print "Content-type: text/html\n\n";
                         print "<br>\nSendmail error # $err<br>\n";}			
			}
			
}


sub sockets_mail {

    my ($to, $from, $subject, $message) = @_;

    my ($replyaddr) = $from;
   
    if (!$to) { return -8; }

    my ($proto, $port, $smptaddr);

    my ($AF_INET)     =  2;
    my ($SOCK_STREAM) =  1;

    $proto = (getprotobyname('tcp'))[2];
    $port  = 25;

    $smtpaddr = ($smtp_addr =~ /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
                    ? pack('C4',$1,$2,$3,$4)
                    : (gethostbyname($smtp_addr))[4];

    if (!defined($smtpaddr)) { return -1; }

    if (!socket(S, $AF_INET, $SOCK_STREAM, $proto))             { return -2; }
    if (!connect(S, pack('Sna4x8', $AF_INET, $port, $smtpaddr))) { return -3; }

    # my($oldfh) = select(S); $| = 1; select($oldfh);

    select(S);
    $| = 1;
    select(STDOUT);

    $_ = <S>; if (/^[45]/) { close S; return -4; }

    print S "helo localhost\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }

    print S "mail from: $from\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }
   
    print S "rcpt to: $to\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -6; }
    

    print S "data\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }



    print S "Content-Type: text/plain; charset=us-ascii\r\n";
    print S "To: $to\r\n";
    print S "From: $from\r\n";
    print S "Reply-to: $replyaddr\r\n" if $replyaddr;
    print S "Subject: $subject\r\n\r\n";
    print S "$message";
    print S "\r\n.\r\n";

    $_ = <S>; if (/^[45]/) { close S; return -7; }

    print S "quit\r\n";
    $_ = <S>;

    close S;
    return 1;
}








sub password_making

{
    srand;
    $ena = "";
    $digits = int(rand(2));
    $limit = $digits + 4;
    for ($xx = 0 ; $xx <= $limit ; $xx =$xx + 2)
{  

    srand;
    $retval = rand(25);
    $retval = $retval + 97;
    $t = chr($retval);
    $ena = $ena.$t;
    $f = int(rand(10)) + 1;
    $ena = $ena.$f;
    
}
$ena =~ s/[o0ijl]/$digits/g;
return $ena;
}

sub get_form_register_param

{

    $username = $q->param('username');
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    ## Added 105 ##
    #$password1 = $q->param('password1');
   #$password2 = $q->param('password2');
   $email = $q->param('email');
 $name = $q->param('name');
$staddress = $q->param('staddress');
$city = $q->param('city');
$state = $q->param('state');
$zip = $q->param('zip');
    $oldpass = $q->param('oldpass');
    $newpass1 = $q->param('newpass1');
  $newpass2 = $q->param('newpass2');
    return 1;
}

sub check_form_register

{
    &get_form_register_param;
      $username =~ s/ //g;
      ## Added 105 ##    
      $username =~ s/\.\.\///g;
      ## Added 105 ##   
    $return = &check_duplicate_username($username);
  if ($return == 1)
{
$error_message = "Username is already taken";
&form_register;

}
   if ($username eq "" || $email eq "" || $name eq "")
{
$error_message = "Enter all required fields marked with *";
&form_register;    
}
#if ($password1 ne $password2)
#{
#$error_message = "Passwords DONT match !!";
#&form_register;
#}
if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ || $email !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/ && $email ne "") 
{
$error_message = "Invalid email  !!";
&form_register;
}
}

sub check_duplicate_username

{
    $c = $_[0];
  if (-f "$register_path/$c.dat") 
{

    return 1;
}
else
{ 
    return 0 ;
}
}
sub form_register {

&print_header;
print <<EOF;
<form action=$script_url>
<input type=hidden name=flag1 value=1>
<input type=hidden name=addregister value=1>
EOF


&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Auction Registration
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
if ($error_message) {
print<<EOF;
<CENTER><table><tr><td><b>$error_message</b></td></tr><table></CENTER>
EOF
}
print<<EOF;

    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Username</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="username" VALUE="$username"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Email</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="email" VALUE="$email"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>*Full Name</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="name" VALUE="$name"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Street
        Address</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="staddress" VALUE="$staddress"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>City</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="city" VALUE="$city"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>State</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="state" VALUE="$state"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Zip</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="zip" VALUE="$zip"></TD>
      </TR>
      <TR>
        <TD COLSPAN="2" ALIGN="CENTER"><INPUT TYPE="submit" NAME="submit" VALUE="Submit"></TD>
      </TR>
    </TABLE>

</form>
EOF

&print_footer;

    exit(1);
}

sub add_item

{
    &get_item_param;
if ($require_user_reg == 1)
{
  $userfile = $register_path."/$username".".dat";
open(USERFILE, "<$userfile") || &error("$userfile $!");
($password, $email, $name, $staddress, $city, $state , $zip , @userbids) = <USERFILE>;
chomp ($password, $email, $name, $staddress, $city, $state , $zip , @userbids);
close (USERFILE);      

}
$line1 = "$itemname\n$reservebid\n$bidinc\n$desc\n$image\n$noitems\n";  
$line2 = "$username####$email####$startbid####$currenttime####$name####$staddress####$city####$state####$zip####1\n";
$dltime = localtime($currenttime);
$lookfile = $endtime.".dat";
$itemfile = $data_path."/".$formdirname."/".$endtime.".dat";
open(ITEMFILE , ">$itemfile");
print ITEMFILE $line1;
print ITEMFILE $line2;
close(ITEMFILE);
&print_header;

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item Posted
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

print <<"12345";

    <CENTER>
    <TABLE WIDTH="500">
      <TR>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">Dear $name, your Item <B><A HREF="http://$server_name$script_url?flag1=1&catdir=$formdirname&fromfile=$lookfile">$itemname</A></B>
        has been succesfully added to the category <B><A HREF="http://$server_name$script_url?flag1=1&catdir=$formdirname">$formtitle</A></B>
        on <B>$dltime</B> . Wishing you a good sale.</FONT></TD>
      </TR>
    </TABLE></CENTER>
12345
    &print_footer;
exit(1);
}

sub preview {
    &check_preview;
    &print_header;
    $time = time;
    $currenttime = localtime($time);
    $endtime = $days * 86400 + $time;
    $closetime = localtime($endtime); 

    ## MODIFIED BY DIRAN
    $desc =~ s/<//g;
    $desc =~ s/>//g;
    $desc =~ s/\.\.\///g;
    $desc =~ s/\.\.//g;
    $desc =~ s/\///g;
    ## MODIFIED BY DIRAN

## Added version 1.06
$desc1 = $desc;

foreach $line($desc1) {
#chomp($line);
#$desc =~ s/\r//g;
$line =~ s/\r//g;
$line =~ s/\n/\\n/g;
}
##


print<<EOF;
<form action=$script_url method=post>
<input type=hidden name=flag1 value=1>
<input type=hidden name=additemflag value=1>
<input type=hidden name=endtime value=$endtime>
<input type=hidden name=currenttime value=$time>
<input type=hidden name=email value="$email">
<input type=hidden name=name value="$name">
<input type=hidden name=staddress value="$staddress">
<input type=hidden name=email value="$city">
<input type=hidden name=state value="$state">
<input type=hidden name=zip value=$zip>
EOF

&theader2;
print<<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item Preview
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
print<<EOF;

    <TABLE BORDER="0" CELLPADDING="2">
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="itemname" VALUE="$itemname"><FONT SIZE="-1" FACE="Arial, Helvetica">$itemname</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Category</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="category" VALUE="$category"><FONT SIZE="-1" FACE="Arial, Helvetica">$formtitle</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Image Url</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="image" VALUE="$image"><FONT SIZE="-1" FACE="Arial, Helvetica">$image</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Description</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="desc" VALUE="$desc1"><FONT SIZE="-1" FACE="Arial, Helvetica">$desc</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item Placed
        At</B></FONT></TD>
        <TD><FONT SIZE="-1" FACE="Arial, Helvetica">$currenttime</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Close After</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="days" VALUE="$days"><FONT SIZE="-1" FACE="Arial, Helvetica">$days
        days (ie on $closetime)</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Username</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="username" VALUE="$username"><FONT SIZE="-1" FACE="Arial, Helvetica">$username</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Starting Bid</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="startbid" VALUE="$startbid"><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$startbid</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Reserve Bid</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="reservebid" VALUE="$reservebid"><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$reservebid</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bid Increment</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="bidinc" VALUE="$bidinc"><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$bidinc</FONT></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Number of
        Items</B></FONT></TD>
        <TD><INPUT TYPE="hidden" NAME="noitems" VALUE="$noitems"><FONT SIZE="-1" FACE="Arial, Helvetica">$noitems</FONT></TD>
      </TR>
    </TABLE>
EOF




#    print $matterboy;
 if ($noitems > 1) {
print <<EOF;
<CENTER><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Dutch Auction
    Style</B></FONT><BR></CENTER>
EOF
}


    print <<"12345";
</table><br><center><input type=submit name=submit value=Submit></center></td></tr></table>

12345

    &print_footer;

    exit(1);
}


sub get_item_param
{

 $itemname = $q->param('itemname');
    $category = $q->param('category');
($formdirname , $formtitle) = split(/:/ , $category);
    $image = $q->param('image');
      $days = $q->param('days');   
$desc = $q->param('desc'); 
$username = $q->param('username');
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    $username =~ s/\.\.//g;
    $username =~ s/\///g;
    ## Added 105 ##
 $password = $q->param('password');
 $startbid = $q->param('startbid');   
 $reservebid = $q->param('reservebid');   
 $bidinc = $q->param('bidinc');
 $endtime = $q->param('endtime');
 $currenttime = $q->param('currenttime');
 $noitems = $q->param('noitems');

if ($require_user_reg != 1)
{
    $email = $q->param('email');
    $name = $q->param('name');
    $staddress = $q->param('staddress');
    $city = $q->param('city');
    $state = $q->param('state');
    $zip = $q->param('zip');   
}

return 1;   
}



sub check_preview

{
    &get_item_param;
$days = 14 if ($days eq "");
 $startbid = 1 if ($startbid eq "");

 ## MODIFIED BY DIRAN
 unless ($startbid =~ /^[0-9]+(\.[0-9]*)?$/) {
$error_message = "USE only numbers in Startbid";    
&form_item ;
 exit;
 }
 
 $startbid = sprintf("%1.2f",$startbid);
 $reservebid =~ s/\,//g;
 ## MODIFIED BY DIRAN
 
 $reservebid = $startbid if ($reservebid eq "" || $reservebid < $startbid);

 ## MODIFIED BY DIRAN
 unless ($reservebid =~ /^[0-9]+(\.[0-9]*)?$/) {
$error_message = "USE only numbers in reserve bid";     
&form_item ;
 exit;
 }
 $reservebid = sprintf("%1.2f",$reservebid);
 ## MODIFIED BY DIRAN

 $bidinc = 1 if ($bidinc eq "");   
# if ($itemname eq "" || $username eq "" || $password eq "")
if ($itemname eq "" || $username eq "")
{
    $error_message = "Enter the required fields marked with *";
    &form_item;
}
if ($require_user_reg == 1)
{
$result = &check_username_password($username , $password);
&form_item if ($result == 0);
}
### INVALID NUMBER ## MODIFIED BY DIRAN
if ($noitems ne "" && $noitems < 1 )
#######################################
{


    $error_message = "Number of  items INVALID";
    &form_item;

}
if ($noitems ne "")
{
unless($noitems =~ /^[0-9]+(\.[0-9]*)?$/)
{
$error_message = "Enter ONLY numbers in number of items";
    &form_item;

}
}
$noitems = 1 if ($noitems eq "");

if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ || $email !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/ && $email ne "") 
{
    $error_message = "Invalid email";
    &form_item;

}
}

sub check_username_password

{

    $username = $_[0];
    ## Added 105 ##    
    $username =~ s/\.\.\///g;
    $username =~ s/\.\.//g;
    $username =~ s/\///g;
    ## Added 105 ##
    $passwordin = $_[1];
    $userfile = $register_path."/$username".".dat";
unless (open(USERFILE, "<$userfile"))
{
    $error_message = "Invalid username";
    return 0;

}
($password, $email, $name, $staddress, $city, $state , $zip , @userbids) = <USERFILE>;
chomp ($password, $email, $name, $staddress, $city, $state , $zip , @userbids);
close (USERFILE);
$error_message = "Invalid password";
    
    $salt = "#x";
    $crypty = crypt($passwordin , $salt); 
  
return 0 if ($crypty ne $password);
return 1;

}


sub form_item {

&get_item_param;
&get_cat;
&print_header;

if ($dirname[0] eq "" && $#dirname == 0) {

    print <<"12345";
<table><tr><td>$links</td><td>NO CATEGORIES DEFINED .. <br><br><b>Enter a new category then , enter an item</b></td></tr></table>

12345
    &print_footer;
    exit(1);
}
    print <<EOF;

<form action=$script_url method=post>
<input type=hidden name=flag1 value=1>
EOF
&theader2;
print <<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Add New Item
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

if ($error_message) {
print "<center><b>$error_message</b></center>";
}

print<<EOF;

<TABLE BORDER = "0" WIDTH="500" BGCOLOR="#FFFFFF"><tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>*Item</B></FONT></td><td><input type=text name=itemname value="$itemname"></td></tr><tr><td><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Category</B></FONT></td><td><select name=category>

EOF

    for ($xx = 0 ; $xx <= $#dirname ; $xx++)
{
    $hochmu = "";
    $hochmu = "SELECTED" if ($xx == 0);
    print <<"12345";
<option value="$dirname[$xx]:$title[$xx]" $hochmu>$title[$xx]

12345
}
print <<"12345";

</select></td></tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Image Url</B></FONT></td><td><input type=text name=image value="$image"></td></tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Close After</B></FONT></td><td><input type=text name=days value=$days><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Days</B></FONT></td></tr><tr><td WIDTH="50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Description</B></FONT></td><td><textarea name=desc cols=20 rows=4>$desc</textarea></td></tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>*Username</B></FONT></td><td><input type=text name=username value="$username"></td></tr>

12345


if ($require_user_reg == 1)

{
    print <<"12345";

<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>*Password</B></FONT></td><td><input type=password name=password value=""></td></tr>

12345

}
else
{
 print <<"12345";

<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>*Email></B></FONT></td><td><input type=text name=email value="$email">
</tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Name</B></FONT></td><td><input type=text name=name value="$name">
</tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Street Address</B></FONT></td><td><input type=text name=staddress value="$staddress">
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>City</FONT></B></td><td><input type=text name=city value="$city">
</tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>State</B></FONT></td><td><input type=text name=state value="$state">
</tr>
<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Zip</B></FONT></td><td><input type=text name=zip value="$zip">
</tr>

12345

}

    print <<"12345";

<tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Starting Bid</B></FONT></td><td><input type=text name=startbid value=$startbid></td></tr><tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Reserve Bid</B></FONT></td><td><input type=text name=reservebid value=$reservebid></td></tr><tr><td WIDTH = "50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Bid Increment</B></FONT></td><td><input type=text name=bidinc value=$bidinc></td></tr><tr><td WIDTH="50%"><FONT SIZE="-1" FACE="Verdana,Arial, Helvetica"><B>Number of Items (at least 2)<br>(Dutch Auction style)</B></FONT></td><td><input type=text name=noitems value=$noitems></td></tr></table>
<TABLE WIDTH = "500" BGCOLOR="#FFFFFF"><TR><TD><CENTER><input type=submit name=preview value=preview></CENTER></td></tr></table>
12345
#&theader3;
&print_footer;
exit(1);
}


sub addcat

{
       
@dirname1 = @dirname; 
@dummy = map( s/cat//gi , @dirname1);
@sorted = sort num_last (@dirname1);    
$lastused = $sorted[$#sorted];
$tobeused = $lastused + 1;
if ($q->param('sbutton') eq 'Add')
{

    
    $newcat = $q->param('newcat');
    $newcat =~ s/<//g;
    $newcat =~ s/>//g;
    $newcat =~ s/\.\.\///g;
    $newcat =~ s/\.\.//g;
    $newcat =~ s/\///g;
    $newdir = "cat$tobeused";
    $line = join(":" , $newdir , $newcat);
    if (-e  "$data_path/category.file")
{
open (CATEGORYFILE , ">>$data_path/category.file") || &error("$data_path/category.file $!");
}
else
{
open (CATEGORYFILE , ">$data_path/category.file") || &error("$data_path/category.file $!");
}
    print CATEGORYFILE $line."\n";
    close(CATEGORYFILE);
    $newcat = "";
}
}
sub formcat {
$num = 0;
&print_header;
&theader2;    
print <<EOF;
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Category
        Administration</B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;

## Added 105 ##
$alogin = $q->param('alogin');
$apass = $q->param('apass');
## Added 105 ##


print<<EOF;
<form action="$script_url" method=get>
<INPUT TYPE="HIDDEN" NAME="alogin" VALUE="$alogin">
<INPUT TYPE="HIDDEN" NAME="apass" VALUE="$apass">
<input type=hidden name=flag1 value=1>
EOF

    print <<"12345" if ($error_message ne "");

<center><br>$error_message</br></center>
12345

print <<"12345";
    <input type=hidden name=addcat value=2>


12345

    for ($xx = 0 ; $xx <= $#dirname ; $xx++)
{

    next if ($dirname[0] eq "" && $#dirname == 0);
    print <<"12345";
<CENTER>
    <TABLE BORDER="0" WIDTH="500" BGCOLOR="$colors[$num]">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$dirname[$xx]</FONT></TD>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$title[$xx]</FONT></TD>
        <TD WIDTH="100" NOWRAP="NOWRAP"><INPUT TYPE="submit" NAME="$dirname[$xx]" VALUE="Delete"></TD>
      </TR>
    </TABLE></CENTER>
12345
$num++;
if ($num == 2) {
$num =0;
}
}

print <<"12345";
    <CENTER>
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica">New
        category</FONT></TD>
        <TD WIDTH="200" NOWRAP="NOWRAP"><INPUT TYPE="text" NAME="newcat" VALUE="$newcat"></TD>
        <TD WIDTH="100" NOWRAP="NOWRAP"><INPUT TYPE="submit" NAME="sbutton" VALUE="Add"></TD>
      </TR>
    </TABLE></CENTER>
</form>

12345


&print_footer;
exit(0);

}



sub expand_cat

{

    &print_header;
&print_cat_head1;


$dirname = $_[0];
chomp($dirname);


## MODIFIED BY DIRAN
$dirname =~ s/\.\.\///g;
$dirname =~ s/\.\.//g;
$dirname =~ s/\///g;

if (!($dirname) || ($dirname eq '')) {
print "No directory was given<BR>";
exit;
}


$fromfile =~ s/\.\.\///g;
$fromfile =~ s/\.\.//g;
$fromfile =~ s/\///g;
&fromcheck;


## MODIFIED BY DIRAN

    @totalfiles = "";
    @actualitemfiles = "";
    opendir (CATDIR , "$data_path/$dirname") || &error("$data_path/$dirname $!");
    @totalfiles = readdir (CATDIR);
    closedir(CATDIR);
    @actualitemfiles = grep (/^[^\.]/ , @totalfiles);

    $num = 0; ## MODIFIED BY DIRAN
    foreach $fromfile(@actualitemfiles)
{
    open (FROMFILE , "<$data_path/$dirname/$fromfile");
    ($name , $rprice , $binc , $desc , $image , @bids) = <FROMFILE>;
    chomp($name , $rprice , $binc , $desc , $image , @bids);
			@lastbid = split(/####/,$bids[$#bids]);
			$file =~ s/\.dat//;
			@finishtime = localtime($fromfile);
			$finishtime[4]++;
		        $extra = "";
			$extra = "*" if ($image ne "");
                        $fromfile =~ s/\./%2E/g;

print<<EOF;

    <TABLE BORDER="0" CELLSPACING="0" WIDTH="500" BGCOLOR="$colors[$num]">
      <TR>
        <TD WIDTH="200" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica"><A HREF="$script_url?flag1=$flag1&catdir=$dirname&fromfile=$fromfile">$name&nbsp;$extra</A></FONT></TD>
        <TD WIDTH="75" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$finishtime[4]/$finishtime[3]</FONT></TD>
        <TD WIDTH="50" ALIGN="RIGHT" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$#bids</FONT></TD>
        <TD WIDTH="175" ALIGN="RIGHT" NOWRAP="NOWRAP"><FONT SIZE="-1" FACE="Arial, Helvetica">$currency$lastbid[2]</FONT></TD>
      </TR>
    </TABLE>
EOF
$num++;
if ($num == 2) {
$num =0;
}
}

print<<EOF;
    <TABLE BORDER="0" WIDTH="500">
      <TR>
        <TD><FONT SIZE="-2" FACE="Arial, Helvetica"><B>* Image Available</B></FONT><BR>
        </TD>
      </TR>
    </TABLE>
EOF

&print_cat_foot1;
&print_footer;
exit(0);

}

sub print_cat_head1 { 

&theader2;
    print <<"12345";

        <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
          <TR>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7" WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Item
            Name</B></FONT></TD>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7" WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Bids
            Close</B></FONT></TD>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7" WIDTH="100"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>#
            of Bids</B></FONT></TD>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7" WIDTH="150"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Highest
            Bid</B></FONT></TD>
          </TR>
        </TABLE>
12345
&theader3;
}


sub print_cat_foot1 {

##     print <<"12345";
## </table><br>
## * --- the item has a image <br></td></tr></table>

#  12345


}

sub get_numberof_items

{
    
    for ($xx = 0 ; $xx <= $#dirname ; $xx++)

{
    next if ($dirname[$xx] eq "");
    opendir (CATDIR , "$data_path/$dirname[$xx]") ||  &error("$data_path/$dirname[$xx] $! ");

    @totalfiles = readdir(CATDIR);
    
closedir(CATDIR);
@actualitemfiles = grep (/^[^\.]/ , @totalfiles);
     $nitems = $#actualitemfiles + 1; 
    $nitems = 0 if ($actualitemfiles[0] eq "");	
    $noi{$dirname[$xx]} = $nitems;
}

}

sub get_cat
{
    $f = 0;
    @dirname = "";
    @title = "";
    return 1 if( !(-e "$data_path/category.file"));
open(CATEGORYFILE , "<$data_path/category.file") || &error("$data_path/category.file $!");
############
 #  0    1    2     3     4    5     6     7     8
# ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =localtime(time);
###########
while ($data = <CATEGORYFILE>)
{
chomp($data);
($dirname[$f] , $title[$f]) = split(/:/ , $data);
unless (-d "$data_path/$dirname[$f]")
{


    mkdir("$data_path/$dirname[$f]", $categorypermissions) || &error("$data_path/$dirname[$f] $! ");
chmod ($categorypermissions , "$data_path/$dirname[$f]");
}
$f = $f + 1;
}
close(CATEGORYFILE);
}




sub first

{
$flag1 = 1;    
&print_header;
    &first_part1;
    &first_matter;
    &first_part2;   
    &print_footer;
    exit(0);
 } 


sub first_part1

{

 print <<"12345";
<CENTER>
    <TABLE BORDER="0">
      <TR>
        <TD WIDTH="500" ALIGN="LEFT"><FONT SIZE="-2" FACE="Arial, Helvetica"><CENTER>
12345

    print $links;

    print <<"12345";
 </FONT></CENTER>
        </TD>
      </TR>
    </TABLE>
    <TABLE BORDER="0" WIDTH="500" CELLPADDING="1" CELLSPACING="0">
      <TR>
        <TD BGCOLOR="#FFFFFF"><HR SIZE="1"></TD>
      </TR>
      <TR>
        <TD BGCOLOR="#000000">
        <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
          <TR>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Categories</B></FONT></TD>
            <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Number
            of Items</B></FONT></TD>
          </TR>
        </TABLE></TD>
      </TR>

    </TABLE><BR>


12345


}

sub first_matter

{
$num = 0;
    for ($xx = 0 ; $xx<=$#title ; $xx++)


{

## ADDED TODAY
if ($title[$xx]) {  

 print <<"12345"; 


    <TABLE BORDER="0" CELLSPACING="0" WIDTH="500" BGCOLOR="$colors[$num]">
      <TR>
        <TD><A HREF="$script_url?flag1=$flag1&catdir=$dirname[$xx]"><FONT SIZE="-1" FACE="Arial, Helvetica">
          $title[$xx]</FONT></A></TD>
        <TD WIDTH="75" NOWRAP="NOWRAP" ALIGN="RIGHT"><FONT SIZE="-1" FACE="Arial, Helvetica">$noi{$dirname[$xx]}</FONT></TD>
      </TR>
    </TABLE>

12345
$num++;
if ($num == 2) {
$num =0;
}

} ## ADDED TODAY

}

}


sub first_part2

{

    print <<"12345";
</CENTER>


12345


}



sub print_header {
   print $q->header;
#    print $q->start_html;

open (FILE,"<$data_path/header.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	} 
 @headerfile = <FILE>;
 close(FILE);
print<<EOF;
<HTML><HEAD><TITLE></TITLE></HEAD><BODY $bodyspec>
EOF
foreach $line(@headerfile) {
print "$line";
  }
}

sub print_footer {
# print $q->end_html;
print "</CENTER>";
open (FILE,"<$data_path/footer.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	} 
 @footerfile = <FILE>;
 close(FILE);
foreach $line(@footerfile) {
print "$line";

}

print<<EOF;
    <CENTER>
    <TABLE BORDER="0" WIDTH="500">
      <TBODY>
      <TR>
        <TD><HR SIZE="1"></TD>
      </TR>
      <TR>
        <TD ALIGN="CENTER"><FONT SIZE="-2" FACE="verdana, arial, helvetica">
        $sitename maintained with <A HREF="http://www.auctionweaver.com/" TARGET="_blank"><B>Auction Weaver LITE
          $version</B></A></FONT><BR><BR></TD>
      </TR></TBODY>
    </TABLE></CENTER>
</BODY></HTML>
EOF

}


sub error

{
    &print_header;
    print $_[0];
    &print_footer;
    exit(0);

}



sub num_last

{
    my ($num_a , $num_b);

    $num_a = $a =~ /^[0-9]/;
    $num_b = $b =~ /^[0-9]/;
     if ($num_a && $num_b)
{

    $retval = $a <=> $b;
}
elsif ($num_a)
{
    $retval = 1;
}
elsif ($num_b)
{

    $retval = -1;
}
else
{
    $retval = $a cmp $b;

}
$retval;

}



sub dutch_auction

{

$yy = $#bid;
@tbid = "";
@tnobid = "";
@ttime = "";
@tbid = @bid1;
@tnobid = @nobid1;
@ttime = @time1;
@result = "";
for ($zz = 0 ; $zz <= $yy ; $zz++)
{
    $bb = $yy - $zz;
for ($dd = 0 ; $dd < $bb ; $dd++)
{

if ($tbid[$dd] < $tbid[$dd + 1])

{
    $temp = $tbid[$dd];
   $tbid[$dd] = $tbid[$dd + 1];
    $tbid[$dd + 1] = $temp;
    $temp = $tnobid[$dd];
   $tnobid[$dd] = $tnobid[$dd + 1];
    $tnobid[$dd + 1] = $temp;
 $temp = $ttime[$dd];
   $ttime[$dd] = $ttime[$dd + 1];
    $ttime[$dd + 1] = $temp;
    $temp =  $result[$dd];
    $result[$dd] = $result[$dd + 1];
    $result[$dd + 1] = $temp;
    $temp = "";
}
elsif ($tbid[$dd] == $tbid[$dd + 1])
{
if ($tnobid[$dd] < $tnobid[$dd + 1])
{
$temp = $tbid[$dd];
   $tbid[$dd] = $tbid[$dd + 1];
    $tbid[$dd + 1] = $temp;
    $temp = $tnobid[$dd];
   $tnobid[$dd] = $tnobid[$dd + 1];
    $tnobid[$dd + 1] = $temp;
 $temp = $ttime[$dd];
   $ttime[$dd] = $ttime[$dd + 1];
    $ttime[$dd + 1] = $temp;
    $temp =  $result[$dd];
    $result[$dd] = $result[$dd + 1];
    $result[$dd + 1] = $temp;
    $temp = "";

}
elsif ($tnobid[$dd] == $tnobid[$dd + 1])
{
if ($ttime[$dd] >  $ttime[$dd + 1])
{
$temp = $tbid[$dd];
   $tbid[$dd] = $tbid[$dd + 1];
    $tbid[$dd + 1] = $temp;
    $temp = $tnobid[$dd];
   $tnobid[$dd] = $tnobid[$dd + 1];
    $tnobid[$dd + 1] = $temp;
 $temp = $ttime[$dd];
   $ttime[$dd] = $ttime[$dd + 1];
    $ttime[$dd + 1] = $temp;
    $temp =  $result[$dd];
    $result[$dd] = $result[$dd + 1];
    $result[$dd + 1] = $temp;
    $temp = "";

}

}
}
}
}
$vcx = 0;
@newresult = "";
for ($xy = 0; $xy <= $#result ; $xy++)
{
$temp = $username1[$result[$cc]];
if ($temp ne "")
{
    $newresult[$vcx] = $result[$cc];
    @dummy = map (s/$temp//ig , @username1); 
    $vcx++;

}
}
}



sub email_parser

{

    local($filename , $flag , $middle , $aall , @all ,$nall ,  $xx);

    $filename = $_[0];
    $flag = $_[1];
    open(EPFILE ,  "<$email_templates_dir/$filename") || &error("$email_templates_dir/$filename $!");
    @all = <EPFILE>;
    close(EPFILE);
    
if ($flag == 1)

{
    $nall = join("#a#b" , @all);
    ($gtop , $middle , $gbottom) = split(/%%BREAK%%/ , $nall);
    @all = "";
    @all = split(/#a#b/ , $middle); 

}

for ($xx = 0 ; $xx <= $#all ; $xx++)
{
    $all[$xx] =~ s/%%USERNAME%%/$gusername/gi;
    $all[$xx]  =~ s/%%BID%%/$gbid/gi;
    $all[$xx]  =~ s/%%NITEMS%%/$gnitems/gi;
    $all[$xx]  =~ s/%%BIDTIME%%/$gbidtime/gi;
    $all[$xx]  =~ s/%%AUCTION%%/$gauction/gi;
    $all[$xx]  =~ s/%%NAME%%/$gname/gi;
    $all[$xx]  =~ s/%%STADDRESS%%/$gstaddress/gi;
    $all[$xx]  =~ s/%%CITY%%/$gcity/gi;
    $all[$xx]  =~ s/%%STATE%%/$gstate/gi;
    $all[$xx]  =~ s/%%ZIP%%/$gzip/gi;
    $all[$xx]  =~ s/%%RBID%%/$grbid/gi;
    $all[$xx]  =~ s/%%AITEMS%%/$gaitems/gi;
    $all[$xx]  =~ s/%%PASSWORD%%/$gpassword/gi;
    $all[$xx]  =~ s/%%URL%%/$gurl/gi;
    
}
$aall = join("" , @all);
return $aall;
}


sub theader2 {
print<<EOF;

<CENTER>
    <TABLE BORDER="0">
      <TR>
        <TD WIDTH="500" ALIGN="LEFT"><FONT SIZE="-2" FACE="Arial, Helvetica"><CENTER>
EOF

    print $links;

print <<EOF;
 </FONT></CENTER>
        </TD>
      </TR>
    </TABLE>
    <TABLE BORDER="0" WIDTH="500" CELLPADDING="1" CELLSPACING="0">
      <TR>
        <TD BGCOLOR="#FFFFFF"><HR SIZE="1"></TD>
      </TR>
      <TR>
        <TD BGCOLOR="#000000">


EOF
}


sub theader3 {
print<<EOF;

      </TD>
      </TR>

    </TABLE><BR>

EOF
}




sub delete_cat

{

&blindcheck;

    $cc = 0;
    $cat = $_[0];

if (($cat) && (!($cat =~ /^cat[0-9]+$/)) || ($cat eq "")) {
print "Content-type: text/html\n\n";
print "$cat is not an Auction Weaver category directory.<BR>";
exit;
}
$cat =~ s/\.\.\\//g;
$cat =~ s/\.\.//g;
$cat =~ s/\///g;



open (CATFILE , "<$data_path/category.file") || &error("$data_path/category.file $!");
    @allcats = <CATFILE>;
    close(CATFILE);
    chomp(@allcats);
    for ($xx = 0 ; $xx <= $#allcats ; $xx++)

{

($catid , $catname) = split(/:/ , $allcats[$xx]);
if ($catid eq $cat)
{
    next;
}
$newcats[$cc] = $allcats[$xx]."\n"; 
$cc++;
}
open (CATFILE , ">$data_path/category.file") || &error("$data_path/category.file $!");
print CATFILE @newcats;
close(CATFILE);
 opendir (CATDIR , "$data_path/$cat") || &error("$data_path/$cat $!");
  @totalfiles = readdir (CATDIR);
 closedir(CATDIR);
@actualitemfiles = grep (/^[^\.]/ , @totalfiles);
foreach $file(@actualitemfiles)
{

    unlink("$data_path/$cat/$file") || &error("$data_path/$cat/$file $!");
    wait;
}

rmdir("$data_path/$cat") || &error("$data_path/$cat $!");
wait;
&get_cat;
&get_numberof_items;

    &formcat;
}


sub admin_login

{
&print_header;



&theader2;
print<<EOF;
    <FORM ACTION="$script_url" METHOD="post">
    <TABLE BORDER="0" WIDTH="500" CELLSPACING="0">
      <TR>
        <TD ALIGN="CENTER" BGCOLOR="#f7f7e7"><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Administration Login
        </B></FONT></TD>
      </TR>
    </TABLE>
EOF
&theader3;
if ($error_message) {
print "<center><h4>$error_message</h4></center>";
}
    
print <<"12345";
    <CENTER>
    <INPUT TYPE="hidden" 
    NAME="logged" VALUE="1"><INPUT TYPE="hidden" NAME="flag1" VALUE="1">
    <TABLE>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Login</B></FONT></TD>
        <TD><INPUT TYPE="text" NAME="alogin" VALUE="$alogin"></TD>
      </TR>
      <TR>
        <TD><FONT SIZE="-1" FACE="Verdana, Arial, Helvetica"><B>Password</B></FONT></TD>
        <TD><INPUT TYPE="password" NAME="apass" VALUE=""></TD>
      </TR>
      <TR>
        <TD COLSPAN="2">
        <CENTER><INPUT TYPE="submit" NAME="sbutton" VALUE="Enter"></CENTER></TD>
      </TR>
    </TABLE></CENTER></FORM>
12345

&print_footer;
}


## Added 105 ##
sub blindcheck {

    $alogin = $q->param('alogin');
    $apass  = $q->param('apass');


if ($adminlogin eq "admin" || $adminpass eq "pass") {
$error_message = "Change your default Admin name and password";
&admin_login;
exit;
}

if ($adminlogin ne $alogin || $adminpass ne $apass) {
    $error_message = "Invalid Admin login";
    &admin_login;
    exit;
 } 
}


sub fromcheck {
$tempfrom = $fromfile;
$tempfrom =~ s/.dat//g;

if (($tempfrom) && ($tempfrom !~ /^[0-9]+$/)) {
print "Content-type: text/html\n\n";
print "Not a valid file<BR>";
exit;
}
}

## Added 105 ##


sub admin_check

{
    $alogin = $q->param('alogin');
    $apass  = $q->param('apass');

if ($adminlogin eq "admin" || $adminpass eq "pass") {
$error_message = "Change your default Admin name and password";
&admin_login;
exit;
}

if ($adminlogin ne $alogin || $adminpass ne $apass)
{

    $error_message = "Invalid Admin login";
    &admin_login;
}
else
{

&formcat ;

} 
exit(1);
}