###
#######################################################
#		Home Free v1.16
#     
#    		Created by Solution Scripts
# 		Email: solutions@solutionscripts.com
#		Web: http://solutionscripts.com
#
#######################################################
#
#
# COPYRIGHT NOTICE:
#
# Copyright 1998 Solution Scripts  All Rights Reserved.
#
# Selling the code for this program without prior written consent is
# expressly forbidden. In all cases
# copyright and header must remain intact.
#
#######################################################

Welcome to Home Free, below are the installation instructions for installing Home Free 
on your server. Home Free uses a few perl modules which should have come with
the release of perl, and thus be installed on your server. It you are having problems
with the modules, please let us know so we can help you fix the situation.

New Features as of version 1.1 -- Friday, July 31, 1998
-- Fixed security issue due in rename portion
-- Fixed ../../filename.html security issue
-- Random password generator not being random on some servers, fixed
-- Headers and footers now place below the opening body tag
-- Ability to add file types to list of useable extensions
-- Directory listing added, allows users to get more visibility
-- Ability to add more space to individual accounts
-- Toggle headers and footers of individual accounts
-- Update headers and footers on all pages through admin
-- Terms and Conditions option added

Edit the variables.pl file to the settings you want. Descriptions of the 
variables are listed below the variable itself. 

You must make a image dir for the icons somewhere on your site. Upload the 5
icons images contained in the zip file to a dir of your choice.....
Set the url of this dir in the variables.pl

If necessary change the path to perl on the first line of the 3 cgi scripts to the newest version
of perl 5 installed on the server. It should be something like #!/usr/bin/perl 
If you are not sure what it is, ask your server host, they can tell you....

All files should be uploaded to the same dir.... it can be the cgi-bin
or a dir which has been chmoded 777

Upload all scripts in ASCII, they will not work if they are not uploaded in ASCII

chmod the files to the following........

variables.pl -- no chmod
new.cgi -- 755
admin.cgi -- 755
manager.cgi -- 755

Run admin.cgi to set your admin password.

Your installation is done............

##########################################

About Home Free features and how they work.......


To allow people to sign up for a free account, send them to the new.cgi file.
When they sign up, a random password is chosen for them and sent to their email address
thus you know the email address is valid, and that only one account per email address
is given......


For members to login into their file manager, send them to manager.cgi 
Once logged in they have access to allthe file manager features. 
Your headers and footers are always placed on the tops and bottoms of
every html file uploaded or created by them.


The new Directory Listing can be accessed in a number of different ways.
To view all of the accounts, call the new.cgi file like:

http://yourdomain.com/cgi-bin/homefree/new.cgi?view=all

To break them down into a smaller list, change the all to a letter
and it will return all accounts starting with that letter.....

http://yourdomain.com/cgi-bin/homefree/new.cgi?view=s

The above will return all the accounts that start with s

If the member has entered a site name and description, that will be 
list, or just the name they entered will be listed.

If you turn off dir listing in the variables.pl file, the members
will not be able to add or update their site name or description.

To add more space, above and beyond the amount you selected in
the variables.pl file, log into the admin.cgi script, and enter
the account name you want to add more space to into the 
"view account" box, then press the "view account" button..
You will then see the space to add or remove space to a file...
To remove space, set the text back back to zero or the lesser amount you want

As of version 1.1 you may make all new users "Agree" to terms and conditions
for gaining an account and free web pages. To turn this option on, set
the term variable in variables.pl to 1. Then in the admin.cgi script,
you can add and edit your terms and conditions by selecting the rules.txt file from 
the list of those to edit. You can enter any html in the rules file, but
remember that the "Terms and Conditions" is hard coded into the script, as is the
checkbox for clicking to accept the terms.




#######################

Due in the next big release (no date for release set, please don't ask)

-- Multiple Dirs.
-- Built in guestbook
-- page generator for those who don't know HTML 

If you have a suggestion, post a message at the Home Free Forum and 
see what others think..... we are open to all ideas.....

#######################

Any questions please visit the Home Free members lounge at
http://solutionscripts.com/lounge/homefree

or email us at solutions@solutionscripts.com