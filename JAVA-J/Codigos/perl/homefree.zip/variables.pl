
#######################################################
#		Home Free v1.16
#     
#    		Created by Solution Scripts
# 		Email: solutions@solutionscripts.com
#		Web: http://solutionscripts.com
#
#######################################################
#
#
# COPYRIGHT NOTICE:
#
# Copyright 1998 Solution Scripts  All Rights Reserved.
#
# Selling the code for this program without prior written consent is
# expressly forbidden. In all cases
# copyright and header must remain intact.
#
#######################################################

#######
#
# Edit all the variables below, they all have descriptions below
# If you have a question about these variables, post a message
# to the Home Free Member Lounge Forum at:
# http://solutionscripts.com/lounge/homefree/forum.cgi
#
# Upload this file in the same dir as all of the other cgi files
# This file does not need to be chmoded.........
#
#######

$variables{'free_name'}="Home Free Demo";
		# THE NAME OF YOUR HOME FREE PROGRAM

$variables{'path'}="/mnt/web/guide/solutionscripts/vault/homefree";
		# FULLPATH TO WHERE YOU WANT THE DATA TO BE STORED
		# With out the tralling slash..... 
		# this is the full path to the dir where the data files are located
		# If it can be below your root ...... put it there....
	
$variables{'free_path'}="/mnt/web/guide/solutionscripts/vault/homefree";
		# FULLPATH TO WHERE YOU WANT THE FREE HOMEPAGES TO BE STORED
		# With out the tralling slash..... 
		# this is the full path to the dir where the data files are located
		# THIS DIR MUST DO HAVE ANY DIRS IN IT
	
$variables{'total_size'}="250";
		# AMOUNT OF SPACE YOU WANT TO GIVE OUT TO EACH MEMBER
		# space in kilobytes ... can be changed at anytime
		# You can also add space to each ind. account though the admin script

$variables{'url'}="http://solutionscripts.com/vault/homefree";
		# FULL URL OF WHERE THE HOME PAGES DIRS WILL BE.......
		# The url the members will use and give out so they can access their files.......

$variables{'url_to_icons'}="http://solutionscripts.com/icons";
		# FULL URL OF WHERE THE THE ICON IMAGES ARE.......
		# The url the of the icons dir, used for the acounts file manager......

$variables{'manager'}="http://solutionscripts.com/vault/homefree/manager.cgi";
		# FULL URL OF THE MANAGER CGI FILE
		# This is the full url to the manager.cgi file..................	

$variables{'your_email'}="youremail\@domain.com";
     	# REPLY TO FOR MEMBER EMAILS:
     	# This is your Email address, and is used to form the Email header sent
    	# from the server Email system. This should be a valid Email address
   		# since Home Free sends email to new accounts. 
     	# NOTE: THE SLASH PRECEEDING THE \@ SYMBOL IS REQUIRED INSIDE DOUBLE 
     	# QUOTES.


$variables{'mail_prog'}="/usr/sbin/sendmail";
     	# PATH TO MAILER PROGRAM:
     	# This has to point to your sendmail program. If your server does not
     	# have sendmail, you may need to modify the open(MAIL,"|$mailprog -t");
     	# lines in all of the scripts to support whatever format your server
     	# email system requires. If you are not sure, ask your server 
     	# administrator. If you have a virtual domain with your own root 
     	# directory, look in the /usr/sbin ,  /usr/lib, /usr/bin, and similar
     	# directories, for a program named sendmail. If it does not exist, 
     	# ask your server admin what is the correct calling method. This is a
     	# server dependent problem, and we at Solution Scripts cannot help you with 
     	# this. If you have other working scripts that send email, look at 
     	# them for clues.

$variables{'dir'} ="1";
		# Directory Listing: on = 1 off = 0
		# Allows users to add a web site name
		# and Description, to be used in account listings
		# For more on Directory Listings, see the readme.txt file......

$variables{'term'} ="1";
		# Terms and Conditions: on = 1 off = 0
		# Make users agree to your terms and conditions
		# Edit the terms via the rules.txt in the admin script
	
$variables{'credit'} ="1";
		# credits: on = 1 off = 0
		# print the.....always on in admin script...
		# Home Free
		# Created by Solution Scripts
	

## END OF REQUIRED MODIFICATIONS
1;
