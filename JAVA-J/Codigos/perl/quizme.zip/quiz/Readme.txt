Quiz Me!  
A FREE Quiz CGI/PERL Script from MikeSpice.com
Version .5
-------------------------------------------------
mike@mikespice.com
http://www.mikespice.com

SUMMARY
------------------------------------------------
This script gives your users a quiz based on 
questions and answers that you give it.  It grades
the quiz and tells them how they did, prints out
some neat graphs, and tells them what their score
tells them.  It can be used to make quizzes like
Cozmo magazines "Have you met the perfect man" type
of quizes or tests of knowledge.  This is all done
easily by editing a plain text file that contains
all of the questions and answers (sample is included).


DISTRIBUTION / LICENSE
-------------------------------------------------
This software is free to use and distribute.  You
may also make any changes that you want and distribute
it also.  The only thing that I ask is that you leave
the "provided by MikeSpice.com" with the link to 
my site www.mikespice.com in the generated HTML.
If you make changes, you may change it to something
like "provided by a MODIFIED script from mikespice.com"
or something of that nature.  The script is FREE, please
help me out!  Also, please email me if you use my 
script (just for kicks so I can see my stuff doing
good for people).

INSTALLATION
---------------------------------------------------
1. put the script somewhere where it can be executed
(normally your cgi-bin) and chmod 755 quiz.cgi (make
it executeable).

2. put the sample quiz.dat (or create any other .dat
files based on this template in the same directory.
This file is basically just a list of questions,
answers, and how much each answer is worth.

3. make sure that the script has permmissions to write
to its own directory (normally this is only safe if
the script is run as you as the user). 

4. Now point your
web browser to it and it should work.  You will need 
to tell the script which .dat file to use.  This is
done easiy by haveing ?quiz=whatever.dat after the
script name.

For example:
http://www.yourserver.com/cgi-bin/quiz/quiz.cgi?quiz=quiz
this will use quiz.dat as the file to read teh questions
and answers from.

Thanks it!

Have fun!

TODO
-----------------------------------------------------
1. somehow encrypt the values of the answers in the
quiz html so that users cannot look at the source and
see how much each question is worth

2. nothing else unless you tell me.

For help or to tell me what you think email:
mike@mikespice.com
