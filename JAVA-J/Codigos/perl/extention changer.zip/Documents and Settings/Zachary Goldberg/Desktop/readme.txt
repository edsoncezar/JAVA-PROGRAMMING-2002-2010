########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
Explanation:
This has to be the shortest code ever written that does something. It does exactly what it says it does, but rapidedly and quickly. Basicly, it takes as many files as are in its local folder, that end in X extention and changes them to Z extention, in about 2 seconds. Even if its 500 files. It is meant for home use, as in on your local pc, just double click the file and it goes. Unfortunatly, unlike tournament.pl everything must be edited inside the file. Still, its only 2 or 3 variables.
Installation: Copy ExtentionChanger.pl to the directory with the files you want to change and, open/run click it(double click usualy works find).