#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#editable variables ;
#$name = the name of the files you want to change.;
$name=123;
files(press #control f and type sleep then the number after it is the number of #seconds, change it for all 3.;
use CGI::Carp qw(fatalsToBrowser);  
use strict; 
use File::Copy; 
my $filename="flt-scb";
 
my $DirWhereTheFilesAre = '.'; 
 
 
opendir DIR, $DirWhereTheFilesAre; 
my @list = grep (!/^\.\.?$/, readdir(DIR));  
closedir DIR; 
my $counter = 0;  
my $newextention=".r0".$counter; 
  for my $File (@list) {  
 (my $Name, my $Ext) = split(/\./,$File);  
if($Name eq $filename)   
{
if ($counter < 10){
$newextention=".r0".$counter;
}
if($counter >10) { 
$newextention=".r".$counter;
}
if($counter == 10) { 
$newextention=".r".$counter;
}
my $NewFile = "$Name$newextention"; 
copy($File,$NewFile); 
$counter++;
print "File ";
print $Name;
print $Ext;
print "Changed to ";
print $Name;
print $newextention;
print "!\n";
sleep 0;
}
else
{
print "Sorry, ";
print $Name;
print ".";
print $Ext;
print " is not compatible";  
print "\n";
sleep 0;
}
 
}  
print "finished!";
print "files that you currently have set to compatible are";
print $filename;
sleep 100; 
