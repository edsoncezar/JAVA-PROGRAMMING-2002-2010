### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Frames
Version: 1.0

Info:

G.Frame is a good way to link to other sites without losing your visitors. 

Use this for linking to other sites:

http://www.yourdomain.com/cgi-bin/gframes.cgi?url=http://www.yahoo.com


G.Scripts @ http://www.grantszone.co.uk/scripts/