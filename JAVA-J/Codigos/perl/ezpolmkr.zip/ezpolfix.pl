#!/usr/bin/perl
#
# this tool is used to convert the index.html from version 1.2 to 1.3 - as you know
# version 1.2 generated links that displayed html only.  version 1.3 generates links that
# invoke the ezpoltkr script dynamically so that it can detect dup votes, active status
# and expired surveys.
#
# if you wish to convert your index.html to 1.3, do the following:
# 0. save your current index.html in the survey directory
# 1. change the variables below
# 2. install this to your cgi-bin directory
# 3. invoke the script directly (ie. type its full URL in your browser's URL window).
# 4. when the "new" index page shows, click on file...save... and store in a temporary
#    directory as 'index.html'
# 5. upload this to your survey directory
#
# ezpolfix.cgi  - used for changing all the links in the index page of the survey
# directory so they call the script instead of displaying html
# 3/10/2000 by manny juan
#
$win95=0;
$cgi='pl';  # suffix for script - cgi or pl

# this the subdirectory where html and data files reside
$userdir="survey";

# Set this to your base HTML directory. This is a PATH not a URL
$base_dir = "/isp/htdocs/your.isp.com/yourname/$userdir";

# This is your URL of where the new HTML pages will be kept - keep the trailing slash
$baseurl = "http://your.isp.com/yourname/$userdir/";

# URL where the scripts reside 
$cgiurl = "http://your.isp.com/yourname/cgi-bin";

# This is the index of all generated pages
# This file should be chmod to 777 and placed in the userpages directory
$indexpage = "$base_dir/index.html";

# Suck the index page, and write the new entry to it
open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
@lines = <FILE>;
close(FILE);
$sizelines = @lines;

print "Content-type: text/html\n\n";
for ($a = 0; $a <= $sizelines; $a++) {

    $_ = $lines[$a];
    $r=$lines[$a];
    if (/$baseurl.*html/) {
        $r=~s/$baseurl/$cgiurl\/ezpoltkr.$cgi\?action\=Start\&userdir\=$userdir\&pagename\=/;
        $r=~s/\.html//;
        print $r;
        }
    else {
        print $r;
        }
    }
exit;
