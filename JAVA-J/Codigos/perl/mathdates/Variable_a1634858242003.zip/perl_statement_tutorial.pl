#Perl conditional testing script

#anything after the hash (#) sign is a comment and is ignored.
#please read through this tutorial code and look to the right side of the script for
#comments on anything you don't know about

$number=0;  #initializes a scaler variable called number.
            #scalars are variables that use only one number
            #this sets the variable $number to the value of 0

print "\nEnter a number less then thirty and greater then three: ";  #prints out something to the screen
                                                                     #first, prints out the \n operator,
                                                                     #which starts a new line, and then some text
                                                                     #note how the line ends with the semicolon.
                                                                     #most lines must end with this
$number = <STDIN>; #changes the value of $number (previously 0) to <STDIN>
                   #<STDIN> is a way of giving a prompt to the user, it allows them to type something in,
                   #so this sets $number to whatever the person types.
chomp ($number); #this gets rid of the 'Enter' part of when someone types something.
                 #when someone types somethng and presses 'Enter', the program returns the "\n" sign
                 #we saw before, so if you typed three above, perl would return this:
                 #"3\n";
                 #the command chomp gets rid of the \n for us,, i.e. it always removes the last character of a variable
if ($number >= 30) {  #IF, this tests to see, in this case, IF the number we entered ($number)
                      #is >= (greater than or equal to) 30

	until ($number <= 30) { #if it is, then UNTIL it is equal or less then 30,
	print "$number minus 1 = "; #print this,
  print ($number - 1); #then print this
  print "\n"; #then print a new linr
	$number--; #then decrease $number by one. the -- (minus-minus) bit is the same as writing this:
             #$number = ($number - 1);
		}
  }
elsif ($number <= 3) { #in this case, IF the number is <= (lesser then or equal to) 3
 	until ($number >= 3) {  #if it is, then UNTIL it is equal or more than 3,
	print "$number plus 1 = "; #print this, and
  print ($number + 1); #print this, and
  print "\n"; #print a new line and
  $number++; #increment $number by one, the same as saying $number = ($number + 1)
		}
}
else { #else, if the number is between 3 and thirty, then
print "\nNumer is fine, thanks!"; #print this
}
#run this script a few times, try entering a large number, like 9999, or a negative number, like -9999, or a number
# between 3 and thirty, like 10.
#any questions, please email thomast@journalist.com



