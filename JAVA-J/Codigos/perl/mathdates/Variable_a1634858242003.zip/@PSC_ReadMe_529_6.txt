Title: Variable and Conditional Tutorial
Description: A simple perl script with a tutorial built in, this progam asks for a numbe beween 3 and 30. If the user enters a number bigger than 30 or less then 3, the program counts up or down accordingly. Please Vote!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=529&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
