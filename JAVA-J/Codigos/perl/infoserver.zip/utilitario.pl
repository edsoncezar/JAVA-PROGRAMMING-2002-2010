#!/usr/bin/perl
print "Content-type: text/html\n\n";
print "<center><font face=verdana><b>UTILITARIO.PL</b></font></center><br><br>";
while (($key,$value) = each %ENV)
{
print "<font face=verdana size=1><b> $key </b> =<i> $value </i></font><br>";
}
print "<br><center><font face=arial size=1><a href=utilitario.zip>Utilitario.pl</a> - Desenvolvido por </font><a href=mailto:mad_scientist\@bol.com.br style=\"text-decoration: none\"><font face=arial size=1 color=#000000>Gabriel Vieira de Melo</font></a></center>";
