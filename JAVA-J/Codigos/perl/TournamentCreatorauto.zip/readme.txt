########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
Upgrade:
v.75-.80 :
Simply Run install.pl.  Your current tournaments without a password will not be lost.  Simple when it promts you for a password, leave the field blank.  It should accept the password, then go to options to implement a new password.
v.70-.80 :
Simply Run install.pl.  Your current tournaments without a password will not be lost.  Simple when it promts you for a password, leave the field blank.  It should accept the password, then go to options to implement a new password.s
v.70-.75 :
Simply Run install.pl.  Your current tournaments without a password will not be lost.  Simple when it promts you for a password, leave the field blank.  It should accept the password, then go to options to implement a new password.
Installation (Automatic):

Copy install.pl, chmod to 755
run install.pl
move index.jpg to the html safe directory, if you didnt specify one, put it in the place with install.pl
Your done!
Unfortunatly a couple problems occur on some servers.  The main one is chmoding.  
If you get an error trying to run Tournament Creator after an auto install, chmod the files manualy,(all .pl files) to 755.


Installation (Manual):  Extract all files...make sure u have the following
- Tournament.pl -Chmod 755
- viewtournament.pl -Chmod 755 
- edittournament.pl -Chmod 755
- docs.pl -Chmod 755
- editsplit.pl -Chmod 755
- htmlsplit.pl -Chmod 755
- index.pl -Chmod 755
- makehtml.pl -Chmod 755
- viewsplit.pl -Chmod 755
- logo.jpg -Chmod 666 (in directory that can be specified in index.pl[via web browser])
-t-empty -Chmod 755
-t-options-empty -Chmod 755
-tournamenthtml-empty -Chmod 755
Chmoding Directories is not always a must.  Usualy they are created as 755 automaticaly.

Purpose-To create and make easily ediable tournaments for gaming clans, bingo night or whatever suits you best.
Enjoy Webrecka of www.echelondesign.netfirms.com!
Change log:
v.80
---Additions---
- Advanced template system.
- Alignment of names.


--MAJOR FIXS--
- Redid all of the sinlge sided tournaments! -300 lines each
- Many minor changes.

v.75
---Additions---
- make html viewable directory customizable
- extra br's in options.
- extra space above the main section of panel.
- Remove info about change document settings under change document settings.
- Set default options
- Password each tournament

--MAJOR FIXS--
- make html for non split tournament 
- edit tournament non split, (effected view tournament as well)
- view and make html tournament non split

--Security Fixs--
Opening a tournament can also make a file, not anymore!