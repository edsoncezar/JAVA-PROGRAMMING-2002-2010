#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
print "Content-type:text/html\n\n";
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
parse_form();
$goto=$FORM{'goto'};
@goes = ("mkd","pwpl","tpl","inpl","docpl","espl","htsppl","mkhtpl","vspl","vtpl","etpl");

install("Making Directories")             if ( $goto eq "mkd" );
finish()             if ( $goto eq "finished" );
install("Making Tournament.pl")             if ( $goto eq "tpl" );
install("Making Index.pl")             if ( $goto eq "inpl" );
chmodd()          if ( $goto eq "chmod" );
install("Making Password.pl")             if ( $goto eq "pwpl" );
install("Making docs.pl")             if ( $goto eq "docpl" );
install("Making editsplit.pl")             if ( $goto eq "espl" );
install("Making htmlsplit.pl")             if ( $goto eq "htsppl" );
install("Making makehtml.pl")             if ( $goto eq "mkhtpl" );
install("Making viewsplit.pl")             if ( $goto eq "vspl" );
install("Making viewtournament.pl")             if ( $goto eq "vtpl" );
install("Making edittournament.pl")             if ( $goto eq "etpl" );

new();
sub chmodd{
@filelist = ("index.pl","Tournament.pl","password.pl","docs.pl","editsplit.pl","htmlsplit.pl","makehtml.pl","viewtournament.pl","viewsplit.pl","edittournament.pl");
$mode=755;
chmod $mode, @filelist;
print qq~
<html><body bgcolor="#444455" text="#000000"><center>
<head>
<title>Echelon Installer: Tournament Creator</title>
</head>
<table  bgcolor="#D6D6CE"><tr>
  <Td colspan=10 align=center>
<table border=3 bordercolor=black ><Tr><Td align=center width=100%>
  Echelon Script Installer:Tournament Creator</td></tr></table></td>
    
  </tr>
  <tr>
    <td align=center valign=top height"311"><br><br>
  <strong><b>Chmoding all files</b></strong><br><br> <a href="install.pl?goto=finshed"><br> click here if you are not moved in 10 seconds</a>  
    </td>
  </tr>
</table>
</div></body>

</html>
~;
print qq~
<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=finished">
~;
exit;
}
sub finish{
print qq~
<html><body bgcolor="#444455" text="#000000"><center>
<head>
<title>Echelon Installer: Tournament Creator</title>
</head>
<table  bgcolor="#D6D6CE"><tr>
  <Td colspan=10 align=center>
<table border=3 bordercolor=black ><Tr><Td align=center width=100%>
  Echelon Script Installer: Tournament Creator</td></tr></table></td>
    
  </tr>
  <tr>
    <td align=center valign=top height"311"><br><br>
  <strong><b>Finished!</b></strong><br>To use Tournament Creator Go to <a href="index.pl">Here</a> and use the password you specified in the begining.  Enjoy another fine Echelon product! 
    </td>
  </tr>
</table>
</div></body>

</html>
~;
exit;
}
sub new{
print qq~
<html><body bgcolor="#444455" text="#000000"><center>
<head>
<title>Echelon Installer: Tournament Creator</title>
</head>
<table  bgcolor="#D6D6CE"><tr>
  <Td colspan=10 align=center>
<table border=3 bordercolor=black ><Tr><Td align=center width=100%>
  Echelon Script Installer:Tournament Creator</td></tr></table></td>
    
  </tr>
  <tr>
    <td align=center valign=top height"311" width="20%">
   What will the password be for Tournament Creator? (the password you use to gain access 
to the actual script)<form action="install.pl" method=get>
<input name="pw"><br>
What is the path to an "html safe" directory.  Please add a trailing slash[html is no good html/ is](if unknown leave blank)<br>
<input name="path">
<input type=hidden name=go value=go>
<input type=hidden name=goto value=mkd>
<input type=hidden name=goees value=1>
<br>
<input type=submit value="Install now!">
    </td>
    
  </tr>
</table>
</div></body>

</html>
~;
}
sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
    }
}
sub install{
($status)=@_;
$goees=$FORM{'goees'};
$path=$FORM{'path'};
$pw=$FORM{'pw'};
print qq~
<html><body bgcolor="#444455" text="#000000"><center>
<head>
<title>Echelon Installer: Tournament Creator</title>
</head>
<table  bgcolor="#D6D6CE"><tr>
  <Td colspan=10 align=center>
<table border=3 bordercolor=black ><Tr><Td align=center width=100%>
  Echelon Script Installer:Tournament Creator</td></tr></table></td>
    
  </tr>
  <tr>
    <td align=center valign=top height"311"><br><br>
  <strong><b> $status</b></strong><br><br> <a href="install.pl?goto=$goes[$goees]&pw=$pw&path=$path"><br> click here if you are not moved in 10 seconds</a>  
    </td>
  </tr>
</table>
</div></body>

</html>
~;
if($status eq "Making Directories"){
$path=$FORM{'path'};
$pw=$FORM{'pw'};
$path =~ s/\%2F/\//g;
$Direc="t";
$mode="755";
mkdir $Direc, $mode;
$Direc="options";
mkdir $Direc, $mode;
mkdir $path;
$Direc=$path."tournamenthtml";
mkdir $Direc, $mode;
print qq~
<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=pwpl&pw=$pw&path=$path&goees=2">
~;
}
if($status eq "Making Password.pl"){
$passwordpl="password.pl";
$path=$FORM{'path'};
$pw=$FORM{'pw'};
open_file( "FILE1", ">", $passwordpl);  
$data= qq~$pw|$path|~; $data=$data.q~<table bordercolor=$bordercolor border=$borderwidth bgcolor=$tbbgcolor width=$bw>�<tr>�<td width=$bw>�<font color=$fontcolor size=$fontsize face=$font>�<div align=$fontpos>$current</div>�</font>�</td>�</tr>�</table>�|</td>�</tr>�</table>�</td>�<td>�<table border=$chborderwidth  bordercolor=$chbordercolor bgcolor=$chtbbgcolor width=$chbw>�<tr>�<td width=$chbw>�<font size=$chfontsize color=$chfontcolor face=$chfont>�<div align=$fontpos>�$champ�</div>�</font>�</td>�</tr>�</table>�</td>�<td>� ~;
&write_file( "FILE1", $data);
close(FILE1);  
print qq~
<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=tpl&goees=3">
~;
}
if($status eq "Making Index.pl"){

$data = q*#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka##v####################
#Because we here are so good at what we do, you dont have
# to edit a single line of code.  Every Single thing is 
#web based.  No variables at all require editing.
# All you have to do is make a directory "t" in the same directory
#as this file  the script will do the rest.  But, because we like you
# if you do decide to read the code, we included what stuff does
#happy hunting
print "Content-type:text/html\n\n";
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
getpath();
$path2=$path."logo.jpg";
print qq~
<html><head><title>Tournament Creator v.75</title></head>
<body bgcolor="#444455">
<center><img src=$path2></center>
<br>
~;



parse_form();
$check = $FORM{'check'};
&path            if ( $check eq "path" );
$pwfile="password.pl";
getpath();
if ($data[0] ne ""){
print qq~
<center>Please enter the password as defined in the correct password file
<form action="index.pl" method=post>
<input type=hidden value="check" name="check">
<input name="pw" type=password>
<input type=submit value=Submit>
</form>
~; 
}else{
print qq~
<center>This is your first time using tournament.pl, to keep it more secure please enter a password for later use(can be changed ladder in file password.pl)
<form action="index.pl" method=post>
<input type=hidden value="set" name="check">
<input name="pw">
<input type=submit value=Submit>
</form>
~; 
}
$check = $FORM{'check'};
&set            if ( $check eq "set" );
&check            if ( $check eq "check" );
sub check2{
&open_file( "FILE1", "", $pwfile );    
while ( ( $line = &read_file("FILE1") ) ) {
        @data = split ( /\|/, $line );
    }
}
sub getpath{
$pwfile="password.pl";
check2();
$pw=$data[0];
$path=$data[1];
}
sub check{
$pwfile="password.pl";
&open_file( "FILE1", "", $pwfile );    
while ( ( $line = &read_file("FILE1") ) ) {
        @data = split ( /\|/ , $line );
    }
$pw=$FORM{'pw'};
if($pw ne $data[0]){
print $data[0];
print "<font  color=red>Error please try again</font>";
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="pw=wrong122e262865; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
}else{
print qq~

<SCRIPT LANGUAGE="JavaScript">
document.cookie="pw=$data[0]";
</SCRIPT>
<font color=green>Correct click <a href="tournament.pl">here</a> to continue</font>
<center>What is the path to an html/image compatable directory?(with trailing slash, so /html is no good /html/ is good)(also note, in this directory must lie, logo.jpg and tournamenthtml folder!)</center>
<center><input type=hidden value=path name=check><input type=test name=path><br><input type=submit value=Change></center>
<br>For preview purposes this is removed from the preview~;


}
}
sub path{
$pwfile="password.pl";
check2();
print qq~
<center><font color=green>Path changed click <a href="tournament.pl">here</a> to continue</font></center>
~;
$pwfile="password.pl";
$pw=$data[0];
$t=$data[2];
$to=$data[3];
$path=$FORM{'path'};
&open_file( "FILE1", ">", $pwfile );
    &write_file( "FILE1", $pw ."|");
&write_file( "FILE1", $path ."|");    
&write_file( "FILE1", $t);   
&write_file( "FILE1", "|");
&write_file( "FILE1", $to);
close(FILE1);
exit;
}
sub set{
$pw=$FORM{'pw'};
$pwfile="password.pl";

do {
        open( FILE1, '>' . $pwfile ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $pwfile;
&open_file( "FILE1", ">", $pwfile );
    &write_file( "FILE1", $pw ."|");
$abc = q~<table bordercolor=$bordercolor border=$borderwidth bgcolor=$tbbgcolor width=$bw>�<tr>�<td width=$bw>�<font color=$fontcolor size=$fontsize face=$font>�<div align=$fontpos>$current</div>�</font>�</td>�</tr>�</table>�|~;
$abcd= q~</td>�</tr>�</table>�</td>�<td>�<table border=$chborderwidth  bordercolor=$chbordercolor bgcolor=$chtbbgcolor width=$chbw>�<tr>�<td width=$chbw>�<font size=$chfontsize color=$chfontcolor face=$chfont>�<div align=$fontpos>�$champ�</div>�</font>�</td>�</tr>�</table>�</td>�<td>�|~;
&write_file( "FILE1", "|");
&write_file( "FILE1", $abc);
&write_file( "FILE1", $abcd);


    close(FILE1);
}
sub first{

}



sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
  
  }
}
sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename )
      
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
sub getcookies {
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookies{$name} = $value;
        }
    }
}
1;
*;
$file="index.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=docpl&goees=5">~;
}
if($status eq "Making Tournament.pl"){
$file="tournament.pl";
open_file( "FILE1", ">", $file);  
$data= q*#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#Because we here are so good at what we do, you dont have
# to edit a single line of code.  Every Single thing is 
#web based.  No variables at all require editing.
# All you have to do is make a directory "t" in the same directory
#as this file  the script will do the rest.  But, because we like you
# if you do decide to read the code, we included what stuff does
#happy hunting

#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!

#I dont even know if i use all these but there here
use Fcntl;
use CGI::Cookie;
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
require "edittournament.pl";
require "viewtournament.pl";
require "makehtml.pl";
require "viewsplit.pl";
require "htmlsplit.pl";
require "editsplit.pl";
require "docs.pl";
#so we dont get any download errors
print "Content-type:text/html\n\n";

#alas the most important part of the code, the sub is alll the way on the bottom
#the whole script is functions, every function is called from inside this sub

&parse_form;
getcookies();
$pwfile="password.pl";
&open_file( "FILE1", "", $pwfile );    
while ( ( $line = &read_file("FILE1") ) ) {
        @pw = split ( /\|/, $line );
    }
$pw[2] =~ tr/\�/\r/;
$pw[3] =~ tr/\�/\r/;
 
if ($cookies{'pw'} ne $pw[0]){
print "error your password is incorrect go back to <a href=\"index.pl\">here</a>(index.pl) to try again";
exit;
}
getcookies();

$docs=$FORM{'docs'};
if ($docs eq "1" || $docs eq "0"){
if($docs != $cookies{docs}){
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="docs=$docs; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
}
}else{
$docs=$cookies{docs};
}
$searchstring = $FORM{'searchstring'};
if ( $searchstring ne "final" ) {
    header();
}
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="ss=$searchstring; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
&checkpw       if ( $searchstring eq "checkpw" );
&ot             if ( $searchstring eq "ot" );
&nt             if ( $searchstring eq "nt" );
&t1             if ( $searchstring eq "t1" );
&vpw             if ( $searchstring eq "vpw" );
&t2             if ( $searchstring eq "t2" );
&finaledt       if ( $searchstring eq "finaledt" );
&naes           if ( $searchstring eq "naes" );
&mktbls1        if ( $searchstring eq "mktbls1" );
&makeoptionstrn        if ( $searchstring eq "makeoptionstrn" );
&viewtournament if ( $searchstring eq "final" );
&mktblsed       if ( $searchstring eq "edit" );
&nameedit       if ( $searchstring eq "nameedit" );
&optionstrn        if ( $searchstring eq "options" );
&makeoptions    if ( $searchstring eq "makeoptions" );
&makeoptions2    if ( $searchstring eq "makeoptions2" );
&htmlsplit         if ( $searchstring eq "htmlsplit" );
&askpw         if ( $searchstring eq "askpw" );
&domain         if ( $searchstring eq "" );
&ent         if ( $searchstring eq "ent" );
&ect         if ( $searchstring eq "ect" );
&dbhelp         if ( $searchstring eq "dbhelp" );
&makehtml       if ( $searchstring eq "makehtml" );

print "</table>";

ender2();
sub checkpw {
 
getoptions();
if ($FORM{'password'} eq $option[18]){
getcookies();
finaledt();
}else{
getcookies();
#print $cookies{'filename2'};
askpw("Error Try Again");
}
}
sub vpw{
$filename    = $FORM{'filename'};
 if ( $filename !~ /\.db$/ ) {
        $error = "The name of the tournament must end in .db";
        dead($error);
    }
$filee       = "t/" . $filename;
if(-e $filee){
}else{
$error = "Your Tournament Does not exist, please go back and try again.";
        dead($error);
}
askpw();
}
sub askpw {
($error)=@_;
$filename    = $FORM{'filename'};

if ($filename ne ""){
    $fileoptions = "options/" . $filename;
    $filee       = "t/" . $filename;
if (-e $filee){
    print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="filename2=$filename; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
 }
}
print qq~

<center>$error <br> What is this tournament password?</center>
<form action="tournament.pl" method=post>
<input type=hidden value="checkpw" name="searchstring">
<center><input type=password name="password"></center>
<center><input type=submit value="Verify"></center>
</form>
~;
}
sub makehtml {
}

sub dead {
    ($error) = @_;
    print $error;
    ender2();
}

sub security {

    ($file) = @_;
    if ( length($text) > 15 ) {
        die 'You must not enter anything longer than 15 characters';
    }
}
sub getpath{
$pwfile="password.pl";
&open_file( "FILE1", "", $pwfile );   
getdata();
$pathtemp=$data[1];
$path=$pathtemp."logo.jpg";
}
sub header {
getcookies();
getpath();
    print qq~

<html>
<head>
<title>Echelon: Tournament Creator v.80</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#444455" text="#0000EE">
<table width=100% height=100%><tr><Td valign=top>
<table width=100%><tr><td valign=top width=100%>
<table width=100% height=100% valign=top><tr><Td width=100% colspan=5 valign=top>
  <tr> 
    <Td valign=top align=center colspan=5 height="100" width=100%><img src=$path width=500 height="100"></td>
  </tr></td></tr><tr><table width=100%><tr>
<Td width=200 valign=top border=1 bordercolor=black bgcolor="#EEEEEE"  height="166">
~;
getall();
print qq~
Current Tournament:<br>
$cookies{filename2}<br><hr>
Number of People:<br>
$data[0]<br><hr>
Split or single sided<br>
$double<br><hr>
Do you want to be able to view documentation?<br>
<form action="tournament.pl" method=post>
Documentation On<input type=radio name="docs" value="1"><br>
Documentation Off<input type=radio name="docs" value="0"><br>
<input type=hidden value=$searchstring name="searchstring">
<input type=submit value="Change Documentation Settings"><br><font size="-1"> </font><br><hr>
</form>
</td>
<td valign=top border=1 bordercolor=black bgcolor="#EEEEEE" align=center height="166">
~;
}

sub ender {
    print "</table>";

}

sub ender2 {
    
if($docs == 1){
print "</td></tr><td valign=top border=1 bordercolor=black bgcolor=#EEEEEE colspan=10>";
docs();
}else{
print "</td></tr>";
}
    exit;
}
sub checkdocs{
$sets="settings.pl";
do {
        open( FILE1, '>' . $sets ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $sets;
$settings=$docs;
 &open_file( "FILE1", ">", $sets );
    &write_file( "FILE1", $settings . "|" );
    close(FILE1);
}
sub statusoftbl {
    print qq~
<table width=200 border=1 bordercolor=black  bgcolor="#EEEEEE" align=center><tr><td>Your current table is here:</td>
</tr><tr><td align=center>
~;
    viewtournament();
    print qq~
</tr></td>
</table>

~;
}

#this is the main menu, open, make a tournament
sub domain {
    print qq~
What do you want to do?<br>
<form action="tournament.pl" method="post">
Make a new tournament?<INPUT TYPE=radio NAME="searchstring" VALUE="nt"><br>
Open a tournament?<INPUT TYPE=radio NAME="searchstring" VALUE="ot">
<br><input type=submit value="Go">
</form>
~;
}

#this one takes info, and makes the tournament file, and asks how many people in the tournament
sub t1 {
    $filename  = $FORM{'filename'};
    $filenpath = "t/" . $filename;
    $filee     = "t/" . $filename;
    if ( length($filee) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }
    if ( $filee !~ /\.db$/ ) {
        $error = "The name of the tourny must end in .db";
        dead($error);
    }
    do {
        open( FILE1, '>' . $filee ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $filee;
    $filename = $FORM{'filename'};
    print qq~

<SCRIPT LANGUAGE="JavaScript">
document.cookie="filename2=$filename; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>

how many people in this tourny?
<form action="tournament.pl" method="post">
<INPUT NAME="firstnum" VALUE="2"><br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="t2">
<input type=submit value="go">
</form>
~;
}

sub t2 {
    $first = $FORM{'firstnum'};
    if ( length($first) > 20 ) {
        $error = "You must not enter anything longer than 20 characters";
        dead($error);
    }
    if ( $first !~ /\A[0-9_]/ ) {
        $error = "The number of people in a tournament must be a number";
        dead($error);
    }
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookies{$name} = $value;
        }
    }

    $fileee = "t/" . $cookies{filename2};
    &open_file( "FILE1", ">>", $fileee );
    &write_file( "FILE1", $first . "|" );
    close(FILE1);
    status();

}

sub status {
    getcookies();
    $tment = "t/" . $cookies{filename2};
    &open_file( "FILE1", "", $tment );
    getdata();
    forms();
}

sub status1 {
    getcookies();
    $tment = "t/" . $cookies{filename2};
    &open_file( "FILE1", "", $tment );
    getdata();
    close(FILE1);
}

sub forms {
    $let      = $data[0];
    $filename = $cookies{filename2};
    print qq~
What are the names of these people<form action="tournament.pl" method="post">


~;
    for ( $let ; $let >= 1 ; $let-- ) {
        print qq~
<input name="name$let">
~;
    }
    print qq~
<br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="naes">
<input type=submit>
</form>
<SCRIPT LANGUAGE="JavaScript">
document.cookie="filename2=$filename; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
}

sub naes {
    getcookies();
    $tment = "t/" . $cookies{filename2};

    &open_file( "FILE1", "", $tment );
    getdata();
    close(FILE1);
    $numof = $data[0];
    for ( $i = $numof ; $i >= 1 ; $i-- ) {
        &open_file( "FILE1", "", $tment );
        getdata();
        $adf = "name" . $i;
        $nop = $FORM{"$adf"};
        if ( length($nop) > 15 ) {
            $error = "You must not enter anything longer than 15 characters";
            dead($error);
        }
        $fileee = "t/" . $cookies{filename2};
        &open_file( "FILE2", ">>", $fileee );
        &write_file( "FILE2", $nop . "|" );
        close(FILE2);
    }

#print qq~
#Do you want a one sided or two sided tournament?
#<br>
#<form action="tournament.pl" method=post>
#Two sides<input type=radio name=split value=split>
#One side<input type=radio name=split value=single>
#
#
#123
#<INPUT TYPE=hidden NAME="searchstring" VALUE="makeoptions2"><br>
#<input type=submit value="Continue">
#</form>
#~;


   options();
}



sub finaledt {
    print qq~
<center>$notice</center><br>
Where do you wish to go?<br>
<form action="tournament.pl" method="post">

<table width=150>
	<tr>
		<td width=100>Final Mode? </td>
		<td><INPUT TYPE=radio NAME="searchstring" VALUE="final">
			</td>
 	</tr>
	<tr>
		<td width=150>Edit Tournament? 
			</td>
		<td>
			<INPUT TYPE=radio NAME="searchstring" VALUE="edit">
			</td>
	</tr>
	<tr>
		<td width=150>
			Edit Options? 
		</td>
		<td>
			<INPUT TYPE=radio NAME="searchstring" VALUE="options">
		</td>
	</tr>
	<tr>
		<td width=150>
			Main Menu?
		</td>
		<td>
			 <INPUT TYPE=radio NAME="searchstring" VALUE="">
		</td>
	</tr>
</table>
<input type=submit value="Go to Selected Location">
</form>
~;
}
sub optionstrn {
    getall1();
    $optionsfile = $tment3;
    do {
        open( FILE1, '>' . $optionsfile ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $optionsfile;
    &open_file( "FILE1", "", $tment3 );
    getoptionsdata();
    close(FILE1);
    &open_file( "FILE1", "", $optionsfile );
    getoptionsdata();
    close(FILE1);
    print qq~
<form action="tournament.pl" method=post>


The Background color(hex or normal)(\$bgcolor)<br><input name="bgcolor" value=$option[3]><br>
Tournament Password?<br><input name="password" value=$option[18]><br>
<hr width=100%>Name options<hr width=100%>
The color of your names (\$fontcolor)<br><input name="fontcolor" value=$option[0]><br>
The font type for each individual name(\$font)<br>
<select name="font" size=1>
~;
           getoptions();
if($font eq ""){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Arial"){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if ($font eq "Times New Roman"){
print qq~
<option>Times New Roman</option>
                <option>Arial</option>
          <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Courier"){
print qq~
 <option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
         
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Veranda"){
print qq~
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
        
		<option>Geneva</option>
~;
}
if($font eq "Geneva"){
print qq~
<option>Geneva</option>
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>

~;
}
print qq~
              </select><br>
Font size(2-5)(\$fontsize)<br> <input name="fontsize" value=$option[5]><br>
Name position(\$fontpos)<br>
<select name="fontpos" size=1>
~;
if ($fontpos eq "Left"){
print qq~
                <option>Left</option>
                <option>Center</option>
                <option>Right</option>
~;
}
if ($fontpos eq "Center"){
print qq~
                
 <option>Center</option>
<option>Left</option>
               
                <option>Right</option>

~;
}
if ($fontpos eq "Right"){
print qq~
<option>Right</option>
                <option>Left</option>
               
                
 <option>Center</option>
~;
}
                if ($fontpos eq ""){
print qq~
<option>Center</option>                
<option>Left</option>
                
                <option>Right</option>
~;
}
print qq~





              </select><br>
The size border around the names is(1-10)(\$borderwidth)<br> <input name="borderwidth" value=$option[2]><br>
Your border color around names is(\$bordercolor)<br> <input name="bordercolor" value=$option[1]><br>
What length do you want the box the name is in to be (50-300)(\$bw)<br><input name="bw" value=$option[16]><br>

Table background color(\$tbbgcolor)<br><input name="tbbgcolor" value=$option[6]><br>

<hr width=100%>Champion's Name options<hr width=100%>
The color of his/her name(\$chfontcolor)<br><input name="chfontcolor" value=$option[7]><br>
The font type for each individual name(\$chfont)<br>
<select name="chfont" size=1>
~;
getoptions();
if($chfont eq "Arial"){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq ""){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if ($chfont eq "Times New Roman"){
print qq~
<option>Times New Roman</option>
                <option>Arial</option>
          <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Courier"){
print qq~
 <option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Veranda"){
print qq~
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Geneva"){
print qq~
<option>Geneva</option>
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>


~;
}


print qq~
</select><br>
Font size(2-5)(\$chfontsize)<br> <input name="chfontsize" value=$option[8]><br>
Name position(\$chfontpos)<br>
<select name="chfontpos" size=1>
~;
                if ($chfontpos eq ""){
print qq~
<option>Center</option>                
<option>Left</option>
                
                <option>Right</option>
~;
}
                if ($chfontpos eq "Left"){
print qq~
                <option>Left</option>
                <option>Center</option>
                <option>Right</option>
~;
}
if ($chfontpos eq "Center"){
print qq~
 <option>Center</option>
                <option>Left</option>
               
                <option>Right</option>

~;
}
if ($chfontpos eq "Right"){
print qq~
<option>Right</option>
                <option>Left</option>
               
                
 <option>Center</option>
~;
}
print qq~
              </select><br>
The size border around the names is(1-10)(\$chborderwidth)<br> <input name="chborderwidth" value=$option[9]><br>
Your border color around names is (\$chbordercolor)<br><input name="chbordercolor" value=$option[10]><br>
What length do you want the box the name is in to be (50-300)(\$chbw)<br><input name="chbw" value=$option[17]><br>
Table background color(\$chtbbgcolor)<br><input name="chtbbgcolor" value=$option[11]><br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="makeoptionstrn">
<input type=submit value="edit options">
</form>
</td></tr><tr><Td bgcolor=#EEEEEE width=100% colspan=2>
		Below are two text boxes.  Left is for normal people, right is for the champion.  They 				represent the actual code that is printed.  The variable list and there values are listed 		above.		
		</td>
	</tr><tr><td bgcolor=#EEEEEE colspan=2>
<table bgcolor=#EEEEEE width=100%>
		
	<tr>
		<td>
~;
&open_file( "FILE1", "", $tment4 );
gettemp();
print qq~
			<form action="tournament.pl" method=post>
				<textarea name="editnorm" rows=10 cols=100 wrap="hard">$normaltemp</textarea>
				<br>
				<center>
<INPUT TYPE=hidden NAME="searchstring" VALUE="ent">					
<input type=submit value="Edit Normal Syntax">
				</center>
			</form>
		</td></tr><tr>
		<td>
			<form action="tournament.pl" method=post>
			<textarea name="editch" rows=10 cols=100>$championtemp</textarea>
			<br>
			<center>
<INPUT TYPE=hidden NAME="searchstring" VALUE="ect">		
		<input type=submit value="Edit Champion Syntax"> 				</center>
			</form>
		</td>
	</tr>
</table></td></tr>
~;
}




sub options {
    getall1();
    $optionsfile = $tment3;
    do {
        open( FILE1, '>' . $optionsfile ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $optionsfile;
    &open_file( "FILE1", "", $tment3 );
    getoptionsdata();
    close(FILE1);
    &open_file( "FILE1", "", $optionsfile );
    getoptionsdata();
    close(FILE1);
    print qq~
<form action="tournament.pl" method=post>


The Background color(hex or normal)<br><input name="bgcolor" value="#444455"><br>
Tournament Password?<br><input name="password" value="$option[19]"><br>
<hr width=100%>Name options<hr width=100%>
The color of your names <br><input name="fontcolor" value="black"><br>
The font type for each individual name<br>
<select name="font" size=1>
~;
           getoptions();
if($font eq ""){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Arial"){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if ($font eq "Times New Roman"){
print qq~
<option>Times New Roman</option>
                <option>Arial</option>
          <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Courier"){
print qq~
 <option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
         
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($font eq "Veranda"){
print qq~
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
        
		<option>Geneva</option>
~;
}
if($font eq "Geneva"){
print qq~
<option>Geneva</option>
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>

~;
}
print qq~
              </select><br>
Font size(2-5)<br> <input name="fontsize" value="2"><br>
Name position<br>
<select name="fontpos" size=1>
~;
if ($fontpos eq "Left"){
print qq~
                <option>Left</option>
                <option>Center</option>
                <option>Right</option>
~;
}
if ($fontpos eq "Center"){
print qq~
                
 <option>Center</option>
<option>Left</option>
               
                <option>Right</option>

~;
}
if ($fontpos eq "Right"){
print qq~
<option>Right</option>
                <option>Left</option>
               
                
 <option>Center</option>
~;
}
                if ($fontpos eq ""){
print qq~
<option>Center</option>                
<option>Left</option>
                
                <option>Right</option>
~;
}
print qq~





              </select><br>
The size border around the names is(1-10)<br><input name="borderwidth" value="2"><br>
Your border color around names is<br> <input name="bordercolor" value="black"><br>
What length do you want the box the name is in to be (50-300)<br><input name="bw" value="150"><br>

Table background color<br><input name="tbbgcolor" value="#E3E3E3"><br>

<hr width=100%>Champion's Name options<hr width=100%>
The color of his/her name<br><input name="chfontcolor" value="black"><br>
The font type for each individual name<br>
<select name="chfont" size=1>
~;
getoptions();
if($chfont eq "Arial"){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq ""){
print qq~
                <option>Arial</option>
                <option>Times New Roman</option>
                <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if ($chfont eq "Times New Roman"){
print qq~
<option>Times New Roman</option>
                <option>Arial</option>
          <option>Courier</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Courier"){
print qq~
 <option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
		<option>Veranda</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Veranda"){
print qq~
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>
		<option>Geneva</option>
~;
}
if($chfont eq "Geneva"){
print qq~
<option>Geneva</option>
		<option>Veranda</option> 
<option>Courier</option>
<option>Times New Roman</option>
                <option>Arial</option>


~;
}


print qq~
</select><br>
Font size(2-5)<br> <input name="chfontsize" value="4"><br>
Name position<br>
<select name="chfontpos" size=1>
~;
                if ($chfontpos eq ""){
print qq~
<option>Center</option>                
<option>Left</option>
                
                <option>Right</option>
~;
}
                if ($chfontpos eq "Left"){
print qq~
                <option>Left</option>
                <option>Center</option>
                <option>Right</option>
~;
}
if ($chfontpos eq "Center"){
print qq~
 <option>Center</option>
                <option>Left</option>
               
                <option>Right</option>

~;
}
if ($chfontpos eq "Right"){
print qq~
<option>Right</option>
                <option>Left</option>
               
                
 <option>Center</option>
~;
}
print qq~
              </select><br>
The size border around the names is(1-10)<br> <input name="chborderwidth" value="3"><br>
Your border color around names is <br><input name="chbordercolor" value="black"><br>
What length do you want the box the name is in to be (50-300)<br><input name="chbw" value="200"><br>
Table background color<br><input name="chtbbgcolor" value="#E3E3E3"><br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="makeoptionstrn">
Do you want a one sided or two sided tournament?<br>
Two sides<input type=radio name="split" value="split">
One side<input type=radio name="split" value="single"  checked>
<br>
<font color=red size="+1">Warning: A split tournament with less than 4 or 5 people might not come out right, as making a tournament with this many is pointless and usualy not vital</font><br>
<br>Below are two text boxes.  Top is for normal people, Bottom is for the champion.  They represent the actual code that is printed.  The variable list and there values are listed above.<br>		
				<textarea name=editnorm rows=10 cols=40>$pw[2]</textarea>
				<br>
			<textarea name=editch rows=10 cols=40>$pw[3]</textarea>
			<br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="makeoptions">
<input type=submit value="Edit Initial Options">
</form>
~;
}

sub makeoptions2 {

    getall();
    $split= $FORM{'split'};
    &open_file( "FILE1", ">>", $tment3 );
    &write_file( "FILE1", $split . "|" );    
close(FILE1);
    finaledt();
}













sub makeoptionstrn {

    getall();
  
$bgcolor = $FORM{'bgcolor'};
    if ( $bgcolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Bgcolor \nYou must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($bgcolor) > 10 ) {
        $error = "You must not enter anything longer than 10 characters";
        dead($error);
    }
getoptions();  
    $double = $option[4];
    $borderwidth = $FORM{'borderwidth'};
    if ( $borderwidth !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Borderwidth \nYou must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($borderwidth) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }

    $fontcolor = $FORM{'fontcolor'};
    if ( $fontcolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Fontcolor \n You must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($fontcolor) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }
    $bordercolor = $FORM{'bordercolor'};
    if ( $bordercolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Bordercolor \nYou must not enter anything other than Letters or numbers  or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($bordercolor) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }
$fontsize = $FORM{'fontsize'};
$tbbgcolor = $FORM{'tbbgcolor'};
$chfontcolor = $FORM{'chfontcolor'};
$chfontsize = $FORM{'chfontsize'};
$chborderwidth = $FORM{'chborderwidth'};
$chbordercolor= $FORM{'chbordercolor'};
$chtbbgcolor = $FORM{'chtbbgcolor'};
$font = $FORM{'font'};
$fontpos = $FORM{'fontpos'};
$chfont = $FORM{'chfont'};
$chfontpos = $FORM{'chfontpos'};
$bw = $FORM{'bw'};
$chbw = $FORM{'chbw'};
$password = $FORM{'password'};
    &open_file( "FILE1", ">", $tment3 );
    &write_file( "FILE1", $fontcolor . "|" );
    &write_file( "FILE1", $bordercolor . "|" );
    &write_file( "FILE1", $borderwidth . "|" );
    &write_file( "FILE1", $bgcolor . "|" );
    &write_file( "FILE1", $double . "|" );
    &write_file( "FILE1", $fontsize . "|" );
&write_file( "FILE1", $tbbgcolor . "|" );
&write_file( "FILE1", $chfontcolor . "|" );
&write_file( "FILE1", $chfontsize . "|" );
&write_file( "FILE1", $chborderwidth . "|" );
&write_file( "FILE1", $chbordercolor . "|" );
&write_file( "FILE1", $chtbbgcolor . "|" );
&write_file( "FILE1", $font . "|" );
&write_file( "FILE1", $fontpos . "|" );
&write_file( "FILE1", $chfont . "|" );
&write_file( "FILE1", $chfontpos . "|" ); 
&write_file( "FILE1", $bw . "|" ); 
&write_file( "FILE1", $chbw . "|" ); 
&write_file( "FILE1", $password . "|" ); 
finaledt();
}
sub ent{
getall();
$template=$FORM{'editnorm'};
&open_file( "FILE1", "", $tment4 );
gettemp();
close(FILE1); 
$template =~ tr/\n/\�/;
$templates[0]=$template;
&open_file( "FILE1", ">", $tment4 );
&write_file( "FILE1", $templates[0] . "|" ); 
&write_file( "FILE1", $templates[1] . "|" ); 
$notice="<font color=green>Template Edit Successful!</font>";
finaledt();
}
sub ect{
getall();
$template=$FORM{'editch'};
&open_file( "FILE1", "", $tment4 );
gettemp();
close(FILE1);
$template =~ tr/\n/\�/;
$templates[1]=$template;
&open_file( "FILE1", ">", $tment4 );
&write_file( "FILE1", $templates[0] . "|" ); 
&write_file( "FILE1", $templates[1] . "|" ); 
$notice="<font color=green>Template Edit Successful!</font>";
finaledt();
}
sub makeoptions {

    getall();
    $bgcolor = $FORM{'bgcolor'};
    if ( $bgcolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Bgcolor \nYou must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($bgcolor) > 10 ) {
        $error = "You must not enter anything longer than 10 characters";
        dead($error);
    }
    $double = $FORM{'split'};
    $borderwidth = $FORM{'borderwidth'};
    if ( $borderwidth !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Borderwidth \nYou must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($borderwidth) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }

    $fontcolor = $FORM{'fontcolor'};
    if ( $fontcolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Fontcolor \n You must not enter anything other than Letters or numbers or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($fontcolor) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }
    $bordercolor = $FORM{'bordercolor'};
    if ( $bordercolor !~ /\A[0-9A-Z#a-z_ ]+\Z/ ) {
        $error =
"Bordercolor \nYou must not enter anything other than Letters or numbers  or a Pound sign(#) {for hex code}";
        dead($error);
    }
    if ( length($bordercolor) > 15 ) {
        $error = "You must not enter anything longer than 15 characters";
        dead($error);
    }
$fontsize = $FORM{'fontsize'};
$tbbgcolor = $FORM{'tbbgcolor'};
$chfontcolor = $FORM{'chfontcolor'};
$chfontsize = $FORM{'chfontsize'};
$chborderwidth = $FORM{'chborderwidth'};
$chbordercolor= $FORM{'chbordercolor'};
$chtbbgcolor = $FORM{'chtbbgcolor'};
$font = $FORM{'font'};
$fontpos = $FORM{'fontpos'};
$chfont = $FORM{'chfont'};
$chfontpos = $FORM{'chfontpos'};
$bw = $FORM{'bw'};
$chbw = $FORM{'chbw'};
$password = $FORM{'password'};
    &open_file( "FILE1", ">", $tment3 );
    &write_file( "FILE1", $fontcolor . "|" );
    &write_file( "FILE1", $bordercolor . "|" );
    &write_file( "FILE1", $borderwidth . "|" );
    &write_file( "FILE1", $bgcolor . "|" );
    &write_file( "FILE1", $double . "|" );
    &write_file( "FILE1", $fontsize . "|" );
&write_file( "FILE1", $tbbgcolor . "|" );
&write_file( "FILE1", $chfontcolor . "|" );
&write_file( "FILE1", $chfontsize . "|" );
&write_file( "FILE1", $chborderwidth . "|" );
&write_file( "FILE1", $chbordercolor . "|" );
&write_file( "FILE1", $chtbbgcolor . "|" );
&write_file( "FILE1", $font . "|" );
&write_file( "FILE1", $fontpos . "|" );
&write_file( "FILE1", $chfont . "|" );
&write_file( "FILE1", $chfontpos . "|" ); 
&write_file( "FILE1", $bw . "|" ); 
&write_file( "FILE1", $chbw . "|" ); 
&write_file( "FILE1", $password . "|" ); 

getall();
$template=$FORM{'editnorm'};
$template2=$FORM{'editch'};
&open_file( "FILE1", ">", $tment4 );
$template =~ tr/\n/\�/; 
$template2 =~ tr/\n/\�/;
&write_file( "FILE1", $template . "|" ); 
&write_file( "FILE1", $template2 . "|" ); 
     
finaledt();
}
sub getoptions {
    $tment3 = "options/" . $cookies{filename2};
    do {
        open( FILE1, '>' . $tment3 ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $tment3;
    &open_file( "FILE1", "", $tment3 );
    getoptionsdata();
    close(FILE1);
    $fontcolor   = $option[0];
    $bordercolor = $option[1];
    $borderwidth = $option[2];
    $bgcolor     = $option[3];
    $double      = $option[4];
	$fontsize = $option[5];
	$tbbgcolor = $option[6];
	$chfontcolor = $option[7];
	$chfontsize = $option[8];
	$chborderwidth = $option[9];
	$chbordercolor= $option[10];
	$chtbbgcolor = $option[11];
	$font = $option[12];
	$fontpos = $option[13];
	$chfont = $option[14];
	$chfontpos = $option[15];
        $bw = $option[16];
        $chbw = $option[17]; 
	$password = $option[18];
}

sub getall1 {
    getcookies();
    $tment3 = "options/" . $cookies{filename2};
    do {
        open( FILE1, '>' . $tment3 ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $tment3;
    $tment2 = "t/" . $cookies{filename2};
    &open_file( "FILE1", "", $tment2 );
    getdata();
    getnames();
}

sub getall {
    getcookies();

    $tment2 = "t/" . $cookies{filename2};
    do {
        open( FILE1, '>' . $tment2 ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $tment2;
    $tment3 = "options/" . $cookies{filename2};
$temp=$cookies{filename2}."template.db";
$tment4 = "options/" . $temp;    
do {
        open( FILE1, '>' . $tment4 ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $tment4;
do {
        open( FILE1, '>' . $tment3 ) || die 'Can\'t create file: ' . $!;
        close F;
    } unless -e $tment3;
    &open_file( "FILE1", "", $tment2 );
    getdata();
    getnames();
    getoptions();
close("FILE1");
&open_file( "FILE1", "", $tment4 );
gettemp();
}

sub nameedit {
    getcookies();
    $tfms  = $FORM{'tfms'};
    $tment = "t/" . $cookies{filename2};
    $rnd2[0] = $cookies{rnd2};
    &open_file( "FILE1", "", $tment );
    getdata();
    close(FILE1);
    $let2 = $data[0];

    if ( $tfms != "" ) {
        for ( $j = 1 ; $j <= $tfms ; $j++ ) {
            $sarc = $FORM{"$j"};
            if ( $sarc eq "" ) {
            }
            else {
                $data[$j] = $sarc;
            }
        }
    }
    else {
        for ( $j = 1 ; $j <= $let2 ; $j++ ) {
            $sarc = $FORM{"$j"};
            if ( $sarc eq "" ) {
            }
            else {
                $data[$j] = $sarc;
            }
        }
    }

    $let1   = $data[0];
    $tmentn = "t/" . $cookies{filename2};
    &open_file( "FILE2", ">", $tmentn );
    &write_file( "FILE2", $data[0] . "|" );
    close(FILE2);
    &open_file( "FILE1", ">>", $tmentn );
    if ( $tfms != "" ) {
        for ( $i = 1 ; $i <= $tfms ; $i++ ) {
            $current = $data[$i];
            &write_file( "FILE1", $current . "|" );
        }
    }
    else {
        for ( $i = 1 ; $i <= $let1 ; $i++ ) {
            $current = $data[$i];
            &write_file( "FILE1", $current . "|" );
        }
    }
    close(FILE1);
    getcookies();
    $rnd2[0] = $cookies{rnd2};
    $rnd = $rnd2[0];
    &open_file( "FILE2", ">>", $tmentn );
    &write_file( "FILE2", $rnd . "|" );
    close(FILE2);

    if ( $rnd ne "" ) {
        for ( $j = $rnd ; $j >= 1 ; $j-- ) {
            &open_file( "FILE1", "", $tment );
            getdata();

            $fileee = "t/" . $cookies{filename2};
            &open_file( "FILE2", ">>", $fileee );
            &write_file( "FILE2", $rnd2[$j] . "|" );
            close(FILE2);
        }
    }
    finaledt();
}

sub mktbls {
    getcookies();
    $tment2 = "t/" . $cookies{filename2};
    &open_file( "FILE1", "", $tment2 );
    getdata();
    getoptions();
    getnames();
    print qq~
<table width=150><tr><td>
~;
    $let = $data[0];

    for ( $d = 1 ; $d <= $let ; $d++ ) {
        $person = $names[$d];
        print qq~
<tr><td width=130><table border=3  bordercolor=$bordercolor width=100%><tr><td width=130 align=center><font color=$fontcolor>$person</font></td></tr></table></td></tr>
~;
    }

    print qq~
</td><td></td></tr></table>
~;
}

sub mktbls1 {
   $filename    = $FORM{'filename'};
   $fileoptions = "options/" . $filename;
    $filee       = "t/" . $filename;
if (-e $filee){
    print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="filename2=$filename; expires=Monday, 04-Apr-3010 05:00:00 GMT";
</SCRIPT>
~;
    finaledt();
}else{
print "error, tournament does not exist";
}
}

sub ot {
    print "Content-type:text/html\n\n";
    
#<form action="tournament.pl" method="post">
print qq~
What is the name of this tournament that your are opening?(filename)<br>~;
#<INPUT TYPE=hidden NAME="searchstring" VALUE="vpw">
#<input type=submit value="Load Tournament">
#</form>

    $dir = "t/";
    opendir( DIR, $dir ) || die $!;
    my @files = readdir DIR;
    print "all your tournaments are listed below";
    print "<br>";
@files2= grep(/\.db$/,@files) ;
print "<table width=150 align=center>";
    for $123 (@files2) {

print qq~
<Tr><td align=left>
<form action="tournament.pl" method=post">
<INPUT TYPE=hidden NAME="searchstring" VALUE="vpw">
<input type="submit" value="$123" name="filename" size=150>
</td></tr>
~;
      }
}

sub dbhelp {
    print qq~
it must end in .db<br>filename.db is acceptable
<br>filename is not
~;
 
}

sub nt {
    print qq~
<form action="tournament.pl" method="post">
What is the name of this tourny?(filename)<INPUT NAME="filename" VALUE=""><br>
<INPUT TYPE=hidden NAME="searchstring" VALUE="t1">
<input type=submit value="Next">
</form>
<font color=red>Must end in .db and cannot exceed 15 characters!</font><br>
<font color=black>Click <a href="tournament.pl?searchstring=dbhelp">here</a> if you dont understand
~;
}
###################################################
#####Backend Subroutines Called many times#########
###################################################
sub getoptionsdata {
    while ( ( $line = &read_file("FILE1") ) ) {
        @option = split ( /\|/, $line );
    }
}

sub getcookies {
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookies{$name} = $value;
        }
    }
}

sub getdata {
    while ( ( $line = &read_file("FILE1") ) ) {
        @data = split ( /\|/, $line );

    }
}
sub gettemp {
    while ( ( $line = &read_file("FILE1") ) ) {
        @templates = split (/\|/, $line);
    }
$templates[0] =~ tr/\�/ /; 
$templates[1] =~ tr/\�/ /; 
$normaltemp=$templates[0];
$championtemp=$templates[1];
close("FILE1");
}
sub getnames {
    $num = $data[0];
    for ( $c = 1 ; $c <= $num ; $c++ ) {
        $names[$c] = $data[$c];
    }
}

sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
    }
}

sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
*;
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=inpl&goees=4">~;

}
if($status eq "Making docs.pl"){
$data = q*sub docs{

print "Documentation of current location :<br>";
&otd             if ( $searchstring eq "ot" );
&ntd            if ( $searchstring eq "nt" );
&t1d             if ( $searchstring eq "t1" );
&t2d             if ( $searchstring eq "t2" );
&finaledtd       if ( $searchstring eq "finaledt" );
&naesd           if ( $searchstring eq "naes" );
&mktbls1d        if ( $searchstring eq "mktbls1" );
&makeoptionstrnd        if ( $searchstring eq "makeoptionstrn" );
&viewtournamentd if ( $searchstring eq "final" );
&mktblsedd       if ( $searchstring eq "edit" );
&nameeditd       if ( $searchstring eq "nameedit" );
&optionstrnd        if ( $searchstring eq "options" );
&makeoptionsd    if ( $searchstring eq "makeoptions" );
&makeoptions2d    if ( $searchstring eq "makeoptions2" );
&htmlsplitd         if ( $searchstring eq "htmlsplit" );
&domaind         if ( $searchstring eq "" );
&dbhelpd         if ( $searchstring eq "dbhelp" );
&makehtmld       if ( $searchstring eq "makehtml" );

}
sub otd{
print qq~
All your tournaments are listed above.  Type in the exact name of the tournament, case sensitive, with the ".db".  It will then promt you
for a password.  If you do not know any, simple leave the field blank.  If you need to find your password, go to the
 .db file(in the /t foler), and the last option (the 19th) will be your password.
~;
}
sub ntd{
print qq~
This shall be what your tournament that you are currently making, shall be referred to from here on in.  When you load it
you load exactly what you are typing now.  If it helps, write down the name for future reference.  The rules
for this name are: 1) It must not be more than 15 characters(letters/numbers) long.  The last the characters
must be .db (so you only really get 12).<br> Examples: <br>1) Filename.db | Correct<br>2)<strike>Filename.db
</strike> | Incorrect<br>3) 123456789123.db | Correct<br>4) <strike>1234567891234.db</strike> | Incorrect
~;
}
sub domaind{
print qq~
Here is were we make our choice.  If you have previously made a tournament with Tournament Creator, go to 
Open A Tournament.  If you have not, then go to Make a New Tournament.
~;
}
1;
*;
$file="docs.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=espl&goees=6">~;

}
if($status eq "Making editsplit.pl"){
$data= q*
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!
sub editsplit{
getall();
    getoptions();
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$adder=0;
$newodd=0;
print qq~
<body bgcolor=$bgcolor><form action="tournament.pl" method=post> <table><tr><Td><table><tr><Td>
~;
gettotal();
$chnum=$total+1;
print "<INPUT TYPE=hidden NAME=searchstring VALUE=nameedit>
<INPUT TYPE=hidden NAME=tfms VALUE=$chnum>";
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="1"){
print "<table border=$bordercolor border=$borderwidth width=150><tr><td>";
print $current;
print "</td></tr><tr><Td><input size=20 name=$forloop value=$data[$forloop]></td></tr></table>";
$odd++;
}
}
print "</td>";
finishodd();
$champ=$data[$chnum];
print "</td></tr></table></td><td>";
print "Champion";
print "<table border=1 width=150><tr><td>";
print $champ;
print "</td></tr><tr><Td><input size=20 name=$chnum value=$champ></td></tr></table>";
#print "</td><td>";
for ($forloop = 1; $forloop <= $total; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="0"){
$even++;
$table[$forloop]="<table border=$bordercolor border=$borderwidth width=150><tr><td> $current </td></tr><tr><Td><input size=20 name=$forloop value=$data[$forloop]></td></tr></table>";
$feven++;
}else{
}
}
$abc=$data[0];
$flag=0;
makeeven();


#finisheven();
#$totaleven=$feven+$curev2;
#print $totaleven;
#makeeven();
print qq~
</td></tr><Tr><Td colspan=100><input type=submit value="Make All Above 
changes"></td></tr></table>
~;
} #end viewsplit

sub makeeven{
if($abc%2=="1"){
$abc++;
}
$eek=$total/2;
if($flag==0){
for ($forloop = $eek; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $table[$record];
}else{
$back[$adder]=$back[$adder] . $table[$record];
}
$safetynew++;
$record++;
}
}else{
for ($forloop = $abc; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $table[$record];
}else{
$back[$adder]=$back[$adder] . $table[$record];
}
$safetynew++;
$record++;
}
}
if($flag==0){
$flag++;
}
if($safetynew >= 150){
print "error";
ender2();
}
$abcd=$abc/2;
$abc=$abcd;
if($abc==".5"|| $abc=="1"){
$adder++;
finishitoff();
}else{
$adder++;
makeeven();
}
}
sub finishitoff{
if($record%2=="1"){
$record++;
}
for($p=$adder; $p>=0; $p--){
print "</td><td>";
print $back[$p];
}
}
sub finisheven{
print "<br>";

if($even%2=="1"){
$even++;
}
for($ev=$even/2; $ev > 0; $ev--){
$neweven+=1;
$curev=$firm+$neweven;
$curent=$data[$curev];
$curev2++;
$safety2++;
}


$rows=1;
if($curev%2 == "1"){
$curev++;
}
#print $even;
#print $curev2;
#curmak();
#print $rows;

if($safety2 > 50){
ender2();
}
$diveven=$even/2;
$even=$diveven;
if($even==".5" || $even=="1"){
}else{
finisheven();
}
}
sub curmak{
$curmak=$curev2/2;
$curev2=$curmak;
$rows++;
$safety3++;
if($safety3 >50){
print "safety overload";
ender2();
}
if($curev2==".5" || $curev2=="1"){
}else{
curmak();
}
}
sub finishodd{
print "<td>";
if($odd%2=="1"){
$odd++;
}
for($od=$odd/2; $od > 0; $od--){
$newodd+=1;
$curod=$firm+$newodd;
if($curod%2 == 0){
$newodd++;
$curod=$firm+$newodd;
}
$current=$data[$curod];
print "<table border=1 width=150><tr><td>";
print $current;
print "</td></tr><tr><Td><input size=20 name=$curod value=$data[$curod]></td></tr></table>";
$safety++;
}
print "</td>";
$divodd=$odd/2;
$odd=$divodd;
if($odd==".5" || $odd=="1"){
}else{
finishodd();
}
}

sub gettotal{
if($start%2 == ".5"){
$start+=.5;
}
if($start%2 == "1"){
$start++;
}

$startdivtwo=$start/2;
$total=$total+$startdivtwo;
$start=$startdivtwo;
if($start=="1"){
$total++;
}else{
gettotal();
}
}
1;
*;

$file="editsplit.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=htsppl&goees=7">~;
}
if($status eq "Making htmlsplit.pl"){
$data = q*
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!
sub htmlsplit{
getall();
    getoptions();
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$adder=0;
$newodd=0;
$name=$cookies{filename2};
$name =~ tr/\.db/\.ht/;
$name = $name."ml";
 $htmlfile = $pathtemp ."tournamenthtml/" . $name;
    $html     = $cookies{filename2};
    $htmlname = $html . ".html";
    do {
        open( FILE1, '>', $htmlfile ) || die 'Can\'t create file: 
' . $!;
        close F;
    } unless -e $htmlfile;
    &open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "<body bgcolor=$bgcolor> <table><tr><Td><table><tr><Td>";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);
spgettotale();
$chnum=$total+1;
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="1"){
    &open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = eval("return \"$normaltemp\";");
    &write_file( "FILE1", $currenthtml );
    close(FILE1);
$odd++;
}
}
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "</td>";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);
spfinishodde();

$champ=$data[$chnum];


&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = eval("return \"$championtemp\";");
$next= "<table ><tr><Td>";
    &write_file( "FILE1", $currenthtml );
    &write_file( "FILE1", $next );
    close(FILE1);





for ($forloop = 1; $forloop <= $total; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="0"){
$even++;
$table[$forloop]=eval("return \"$normaltemp\";");
$feven++;
}else{
}
}
$abc=$data[0];
$flag=0;
spmakeevene();



print qq~
Your file was created successfully and you can view it <a href="$htmlfile">here</a><br>It is in the html folder and is saved as $htmlname <br>To go back to the menu click <a href="tournament.pl?searchstring=finaledt">here</a>

</td></tr></table>
~;
} 

sub spmakeevene{
if($abc%2=="1"){
$abc++;
}
$eek=$total/2;
if($flag==0){
for ($forloop = $eek; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $table[$record];
}else{
$back[$adder]=$back[$adder] . $table[$record];
}
$safetynew++;
$record++;
}
}else{

for ($forloop = $abc; $forloop >= 0; $forloop--){
$rowss++;
}
$height= 100/$rowss;
for ($forloop = $abc; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
$tbl = "<tr height=\"$height%\" align=center><td height=\"$height%\" align=center>$table[$record]</td></tr>";
if($table[$record] eq ""){
}else{
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $tbl;
}else{
$back[$adder]=$back[$adder] . $tbl;
}
}
$safetynew++;
$record++;
}
}
if($flag==0){
$flag++;
}
$abcd=$abc/2;
$abc=$abcd;
if($abc==".5"|| $abc=="1"){
$adder++;
spfinishitoffe();
}else{
$adder++;
spmakeevene();
}
}
sub spfinishitoffe{
if($record%2=="1"){
$record++;
}
$adder=$adder-1;
for($p=$adder; $p>=0; $p--){
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "<td height=100% align=center><table height=100% align=center>
$back[$p]</table></td>";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);

}
}
sub spfinishevene{
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "<br>";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);

if($even%2=="1"){
$even++;
}
for($ev=$even/2; $ev >= 0; $ev--){
$neweven+=1;
$curev=$firm+$neweven;
$curent=$data[$curev];
$curev2++;
$safety2++;
}
$rows=1;
if($curev%2 == "1"){
$curev++;
}
$diveven=$even/2;
$even=$diveven;
if($even==".5" || $even=="1"){
}else{
spfinishevene();
}
}



sub spcurmake{
$curmak=$curev2/2;
$curev2=$curmak;
$rows++;
$safety3++;

if($curev2==".5" || $curev2=="1"){
}else{
spcurmake();
}
}
sub spfinishodde{
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "<td align=center height=100%><table height=100% align=center >";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);
if($odd%2=="1"){
$odd++;
}
for($od=$odd/2; $od > 0; $od--){
$rows3++;
}
$height=100/$rows3;
for($od=$odd/2; $od > 0; $od--){
$newodd+=1;
$curod=$firm+$newodd;
if($curod%2 == 0){
$newodd++;
$curod=$firm+$newodd;
}
$current=$data[$curod];
$ebal= eval("return \"$normaltemp\";");
$ebbal="</td></tr>";
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "<tr><td height=\"$height%\">";
    &write_file( "FILE1", $currenthtml );
    &write_file( "FILE1", $ebal );
    &write_file( "FILE1", $ebbal );
    close(FILE1);
}
&open_file( "FILE1", ">>", $htmlfile );
    $currenthtml = "</table></td>";
    &write_file( "FILE1", $currenthtml );
    close(FILE1);
$divodd=$odd/2;
$odd=$divodd;
if($odd==".5" || $odd=="1"){
}else{
spfinishodde();
}
}

sub spgettotale{
if($start%2 == ".5"){
$start+=.5;
}
if($start%2 == "1"){
$start++;
}

$startdivtwo=$start/2;
$total=$total+$startdivtwo;
$start=$startdivtwo;
if($start=="1"){
$total++;
}else{
gettotale();
}
}
1;
*;
$file="htmlsplit.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=mkhtpl&goees=8">~;
}
if($status eq "Making makehtml.pl"){
$data = q*
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!
sub makehtml {
    getall();
    getoptions();
if ($split eq "split"){
htmlsplit();
exit;
} 
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$adder=0;
$newodd=0;
$name=$cookies{filename2};
$name =~ tr/\.db/\.ht/;
$name = $name."ml";
    $htmlfile = $pathtemp."tournamenthtml/" . $name;

    $html     = $cookies{filename2};
    $htmlname = $html . ".html";
    do {
        open( FILE1, '>' . $htmlfile ) || die 'Can\'t create file: 
' . $!;
        close F;
    } unless -e $htmlfile;
 print qq~
Your file was created successfully and you can view it <a href="$htmlfile">here</a><br>It is in the html folder and is saved as $name <br>To go back to the menu click <a href="tournament.pl?searchstring=finaledt">here</a>
~; 
&open_file( "FILE1", ">", $htmlfile );
$head="<body bgcolor=$bgcolor> <table><tr><Td><table><tr><Td>";
&write_file( "FILE1", $head );
  close(FILE1);
$td="<td>";
$std="</td>";
$str="</tr>";
$tr="<tr>";
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $td );
    close(FILE1);
  
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
$input= eval("return \"$normaltemp\";");
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $input );
    close(FILE1);
$odd++;
}
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $std );
    close(FILE1);
modd();
}








 


sub modd{
$mod="<td align=center height=100%><table height=100% align=center>";
$beg="<tr><td height=\"$height%\">";
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $mod );
    close(FILE1);
if($odd%2=="1"){
$odd++;
}
if($odd=="2"){
$newodd++;
$curod=$firm+$newodd;
$champ=$data[$curod];
$input= eval("return \"$championtemp\";");
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $input );
    close(FILE1);
}else{
for($od=$odd/2; $od > 0; $od--){
$rows++;
}
$height=100/$rows;
for($od=$odd/2; $od > 0; $od--){
$newodd++;
$curod=$firm+$newodd;
$current=$data[$curod];
$input= eval("return \"$normaltemp\";");
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $beg );
    &write_file( "FILE1", $input );
    &write_file( "FILE1", $std );
    &write_file( "FILE1", $str );	
    close(FILE1);
$safety++;
}
 &open_file( "FILE1", ">>", $htmlfile );
    &write_file( "FILE1", $std );
$stable="</table>";
    &write_file( "FILE1", $stable);    
close(FILE1);
$divodd=$odd/2;
$odd=$divodd;
if($odd==".5" || $odd=="1"){
}else{
modd();
}
}
}
1;  
*;
$file="makehtml.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=vspl&goees=9">~;
}
if($status eq "Making viewsplit.pl"){
$data= q*
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!
sub viewsplit{
getall();
    getoptions();
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$adder=0;
$newodd=0;
print qq~
<body bgcolor=$bgcolor> <table ><tr><Td><table ><tr><Td>
~;




gettotale();
$chnum=$total+1;
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="1"){
print eval("return \"$normaltemp\";");
$odd++;
}
}
print "</td>";
finishodde();

$champ=$data[$chnum];
print eval("return \"$championtemp\";");
print "<table ><tr><Td>";
for ($forloop = 1; $forloop <= $total; $forloop++ ){
$current=$data[$forloop];
if($forloop%2=="0"){
$even++;
$table[$forloop]=eval("return \"$normaltemp\";");
$feven++;
}else{
}
}
$abc=$data[0];
$flag=0;
makeevene();



print qq~

</td></tr></table>
<form action="tournament.pl" method=post>
<input type=hidden value="htmlsplit" name="searchstring">
<input type=submit value="Make the html file?">
</form>
~;
} 


sub makeevene{
if($abc%2=="1"){
$abc++;
}
$eek=$total/2;


if($flag==0){
for ($forloop = $eek; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
$tbl = "$table[$record]";
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $tbl;
}else{
$back[$adder]=$back[$adder] . $tbl;
}
$safetynew++;
$record++;
}
}else{

for ($forloop = $abc; $forloop >= 0; $forloop--){
$rowss++;
}
$height= 100/$rowss;
for ($forloop = $abc; $forloop > 0; $forloop--){
$outof=$adder;
$outof2=$even+$record;
$tbl = "<tr height=\"$height%\" align=center><td height=\"$height%\" align=center>$table[$record]</td></tr>";
if($table[$record] eq ""){
}else{
if($abc >= $data[0]){
$back[$outof]=$back[$outof] . $tbl;
}else{
$back[$adder]=$back[$adder] . $tbl;
}
}
$safetynew++;
$record++;
}
}
if($flag==0){
$flag++;
}
$abcd=$abc/2;
$abc=$abcd;
if($abc==".5"|| $abc=="1"){
$adder++;
finishitoffe();
}else{
$adder++;
makeevene();
}
}
sub finishitoffe{
if($record%2=="1"){
$record++;
}
$adder=$adder-1;
for($p=$adder; $p>=0; $p--){
print "<td  height=100% align=center><table height=100% align=center  >";
print $back[$p];
print "</table></td>";
}
}

















sub finishevene{
print "<br>";

if($even%2=="1"){
$even++;
}
for($ev=$even/2; $ev >= 0; $ev--){
$neweven+=1;
$curev=$firm+$neweven;
$curent=$data[$curev];
$curev2++;
$safety2++;
}


$rows=1;
if($curev%2 == "1"){
$curev++;
}



$diveven=$even/2;
$even=$diveven;
if($even==".5" || $even=="1"){
}else{
finishevene();
}
}
sub curmake{
$curmak=$curev2/2;
$curev2=$curmak;
$rows++;
$safety3++;

if($curev2==".5" || $curev2=="1"){
}else{
curmake();
}
}
sub finishodde{
print "<td align=center height=100%><table height=100% align=center >";
if($odd%2=="1"){
$odd++;
}
for($od=$odd/2; $od > 0; $od--){
$rows3++;
}
$height=100/$rows3;
for($od=$odd/2; $od > 0; $od--){
$newodd+=1;
$curod=$firm+$newodd;
if($curod%2 == 0){
$newodd++;
$curod=$firm+$newodd;
}
$current=$data[$curod];
print "<tr><td height=\"$height%\">";
print eval("return \"$normaltemp\";");
print "</td></tr>";
$safety++;
}
print "</table></td>";
$divodd=$odd/2;
$odd=$divodd;
if($odd==".5" || $odd=="1"){
}else{
finishodde();
}
}

sub gettotale{
if($start%2 == ".5"){
$start+=.5;
}
if($start%2 == "1"){
$start++;
}

$startdivtwo=$start/2;
$total=$total+$startdivtwo;
$start=$startdivtwo;
if($start=="1"){
$total++;
}else{
gettotale();
}
}
1;
*;
$file="viewsplit.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=vtpl&goees=10">~;
}
if($status eq "Making viewtournament.pl"){
$data=q*

########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#Because we here are so good at what we do, you dont have
# to edit a single line of code.  Every Single thing is 
#web based.  No variables at all require editing.
# All you have to do is make a directory "t" in the same directory
#as this file  the script will do the rest.  But, because we like you
# if you do decide to read the code, we included what stuff does
#happy hunting

#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!

sub viewtournament {
    getall();

    getoptions();
if ($double eq "split"){
viewsplit();
ender2();
}
    print qq~
<body bgcolor=$bgcolor> <table border=0 bordercolor=purple><tr><Td><table width=130 
bordercolor=orange border=0><tr><td>
~;
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$rows=0;
$adder=0;
$newodd=0;
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
print eval("return \"$normaltemp\";");
$odd++;
}
print "</td>";
vodd();
print qq~
</tr><tr><td><form action="tournament.pl" method=post>
<input type=hidden name="searchstring" value="makehtml">
<input type=submit value="Make the html file?">
</form>
</td></tr>
~;
}



sub vodd{
print "<td align=center height=100%><table height=100% align=center>";
if($odd%2=="1"){
$odd++;
}
if($odd=="2"){
$newodd++;
$curod=$firm+$newodd;
$champ=$data[$curod];
print eval("return \"$championtemp\";");
print "</td>";
}else{
for($od=$odd/2; $od > 0; $od--){
$rows++;
}
$height=100/$rows;
for($od=$odd/2; $od > 0; $od--){
print "<tr><td height=\"$height%\">";
$newodd++;
$curod=$firm+$newodd;
$current=$data[$curod];
print eval("return \"$normaltemp\";");
$safety++;
print "</td></tr>";
}

print "</table></td>";

$divodd=$odd/2;
$odd=$divodd;

if($odd==".5" || $odd=="1"){
}else{
vodd();
}
}
}
1;  
*;
$file="viewtournament.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=etpl&goees=11">~;
}
if($status eq "Making edittournament.pl"){
$data= q*
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#DO NOT EDIT BELOW HERE, OR RISK SCRIPT NOT WORKING!
sub mktblsed {
getall();
getoptions();
if ($double eq "split"){
editsplit();
ender2();
} 
    print qq~
<table border=0 bordercolor=purple><tr><Td><table width=130 
bordercolor=orange border=0><tr><td>
<form action="tournament.pl" method=post>
~;
$total=$data[0];
$start=$data[0];
$firm=$data[0];
$adder=0;
$newodd=0;
for ($forloop = 1; $forloop <= $data[0]; $forloop++ ){
$current=$data[$forloop];
$input=" 
      <table border=1 height=1>
        <tr> 
          <td align=center height=1>$current 
           <br>
              <input name=\"$forloop\" value=\"$current\" size=\"20\">
            
          </td>
        </tr>
      </table>
";
print $input;
$odd++;
}
print "</td>";
eodd();

$tfms=$curod+1;
print qq~
<INPUT TYPE=hidden NAME="searchstring" VALUE="nameedit">
<INPUT TYPE=hidden NAME="tfms" VALUE="$tfms">
<td></td></tr></table>
<center><input type=submit value="Make All Above 
changes"></center>
</form>
~;

    $filename  = $FORM{'filename'};
    $filenpath = "t/" . $filename;
    $filee     = "t/" . $filename;
    $tmss      = $tfms - 1;
    print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="filename2=$filename; domain="",expires=Monday, 
04-Apr-3010 05:00:00 GMT";
document.cookie="rnd2=$tmss; domain="",expires=Monday, 04-Apr-3010 
05:00:00 GMT";
</SCRIPT>
~;
}
sub eodd{
print "<td>";
if($odd%2=="1"){
$odd++;
}
if($odd=="2"){
$newodd++;
$curod=$firm+$newodd;
$champ=$data[$curod];
$input="
      <table border=1 height=1>
        <tr> 
          <td align=center height=1>$champ 
           <br>
              <input name=\"$curod\" value=\"$champ\" size=\"20\">
            
          </td>
        </tr>
      </table>
";
print $input;
print "</td>";
}else{

for($od=$odd/2; $od > 0; $od--){
$newodd++;
$curod=$firm+$newodd;
$current=$data[$curod];
$input="
      <table border=1 height=1>
        <tr> 
          <td align=center height=1>$current 
           <br>
              <input name=\"$curod\" value=\"$current\" size=\"20\">
            
          </td>
        </tr>
      </table>
";
print $input;
$safety++;
}
print "</td>";
$divodd=$odd/2;
$odd=$divodd;
if($odd==".5" || $odd=="1"){
}else{
eodd();
}
}
}
1;
*;
$file="edittournament.pl";
open_file( "FILE1", ">", $file);  
write_file( "FILE1", $data);
print qq~<META HTTP-EQUIV="REFRESH" CONTENT="4 URL=install.pl?goto=chmod&goees=12">~;

}
exit;
}
sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
