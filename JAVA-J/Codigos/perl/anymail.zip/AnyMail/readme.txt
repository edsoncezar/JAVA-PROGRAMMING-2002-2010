			AnyMail version 1.12

This script is a basic form mailer which will allow you to receive the results of any form
in email. You can use an unlimited number of form fields, and can specify the email address
that each form is sent to, as well as the follow-up page that the user is sent to upon 
submission. Another neat feature is the ability to specify one of the form fields as the 
subject line. Use as many different forms as you need, all from one script.

---------------- Configuration ---------------- 

The first line of the script must be the correct path to Perl, as with all such scripts:
#!/usr/bin/perl

The only other required items are,

$admin_address = 'you@yourdomain.com';

This must be set. You can specify the mailing address in each form, but this will act as 
your default address so any forms that don't have the To address specified will send to the
$admin_address.�

$bounce_url = "http://www.yourdomain.com";

This url will be used if someone calls the script directly, or if someone trys to use the form
from a website not listed in the @ok_domains array ( see next item ). You can set this to 
whatever you wish.

@okay_domains = qw(veinotte.com ad-eagle.com pass-iton.com);

This array is a space separated list of domains that can use this form. So if you have more
than one domain, add each one in this array with a space between them. If the script is called
from a domain that is not in this list the user will be sent to the $bounce_url above.�
Note: This script should not be considered secure. It depends on the environment variable 
HTTP_REFERER. If the HTTP_REFERER is defined, the script checks it against the domains in the 
@okay_domains array. If it is not defined it does not check. Since the HTTP_REFERER is not 
always available, this function cannot be considered completely reliable, though it is 
unlikely that a site could use the program from your server consistantly without being jumped 
to the bounce_url once in a while, which makes using it from someone elses server  unattractive.

$location_of_sendmail = '/usr/sbin/sendmail';

Did we mention this script is meant for Unix and relatives only? Set your path to Sendmail above,
and that should be it for the configurations. Just put the script in your cgi-bin and make sure
it is executable ( chmod 0755 )

$at_symbol_replacement = '~';

This option was added so that you can use the AnyMailAddress option without putting an actual
email address in the source of your html pages, and still be able to use one copy of the script
from multiple forms, sending to multiple email addresses. So instead of using:
<input type="hidden" name="AnyMailAddress" value="admin@veinotte.com">
You can use this:
<input type="hidden" name="AnyMailAddress" value="admin~veinotte.com">

You can substitute  the @ symbol with whatever you have set in the option above. The default is
a tilde (~) but you can use whatever you wish. THen the program will take this address and replace
the tilde with an actual @ symbol. No need to put email addresses inside your html!

More on this option below.
---------------- Now for configuring your forms ---------------- 

As stated, the results from any form can be sent, and you can point as many forms are you need
to at the script. There are however a couple of field names that are reserved, and must be used
correctly in each form.

FromEmail
If your form asks for the users email address, it should be named FromEmail like so:  
<input type="text" name="FromEmail" size="15">
This will use the persons email in the from field of the email that you receive.

followup
This should be the full URL to the page you want the user sent to after they submit, and is a
hidden form field. The form field would look something like this:

<input type="hidden" name="followup" value="http://www.cgi.veinotte.com/thanks.htm">

AnyMailAddress
This is the address that the form will send the results to. The form field, hidden again, will
look like so:

<input type="hidden" name="AnyMailAddress" value="admin@veinotte.com">

If you leave this field out, the script will use the $admin_address specified in the script 
itself.

Again, if you do not wish to leave actual email addresses in your html files, change this to use
whatever you have set in your configs as the $at_symbol_replacemnet. If you are using ~ then
set this form field like so:
<input type="hidden" name="AnyMailAddress" value="admin~veinotte.com">

subject_line
The subject_line field allows you to specify any existing fields as the subject line in the 
email. If you had a form with the following fields, the form field "request" would be used as
the subject line in the email by setting the subject_line field with value="request":
So if you had the following fields in your form:

name
request
FromEmail
followup
AnyMailAddress

You could make the subject line of the email become the value of the request field like this:
<input type="hidden" name="subject_line" value="request">

A complete form would look something like this:

<form method="post" action="/cgi-bin/anymail.cgi">
Field one:<input type="text" name="one" size="15"><br>
Field two:<input type="text" name="two" size="15"><br>
Field Three<input type="text" name="three" size="15"><br>
Field Four: <input type="text" name="four" size="15"><br>
Email: <input type="text" name="FromEmail" size="15"><br>
<input type="hidden" name="subject_line" value="three">
<input type="hidden" name="AnyMailAddress" value="you@yourdomain.com">
<input type="hidden" name="followup" value="http://www.yourdomain.com/thanks.htm">
<br><input type="submit" value="send">
</form>

