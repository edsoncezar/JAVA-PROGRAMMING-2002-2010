#!/usr/local/bin/perl
#Change the line above to point to Perl

#Multi File Content Search and Replace v1.1
#Created by Leow Kah Man (kmleow@bigfoot.com)
#Copyright � 2001 Leow Kah Man
#You are only allowed to distribute the unmodified script.
#WARNING! This script is very dangerous! Use it with great care!
#Disclaimer: I will not be held responsible for whatever damages that may occur.

#Features:
#Able to search for keyword(s) inside multiple files in a directory and replace
#them with anything you specify.
#Case sensitive/insensitive searching.
#With/without Prompt before replacing.
#Time elapsed during search and replace process.

#History:
#1.0-The first official release.
#1.1-Fixed a major bug regarding missing newline characters in replaced files.
#	-Added case sensitive/insensitive search capability.

#YOU DO NOT NEED TO MODIFY ANYTHING BELOW. JUST EXECUTE THE SCRIPT.

#Variable declaration section
$filesfound=0;
$filesmodified=0;

#Introduction
print "Multi File Search and Replace v1.1\n";
print "Created by Leow Kah Man (kmleow\@bigfoot.com)\n";
print "Copyright � 2001 Leow Kah Man\n";
print "You are only allowed to distribute the unmodified script.\n\n";
print "WARNING! This script is very dangerous! Use it with great care!\n\n";
print "Disclaimer: I will not be held responsible for whatever damages that may occur.\n\n";

#Ask user some questions
while ($dir eq '') { #What directory to search?
	print "Enter the full path of the directory of files that you want to search withoout the slash at the end:\n";
	$dir=<STDIN>; chomp($dir);
}
opendir(DIR,$dir) or &dirnotfound($dir); #Open directory

while ($search eq '') { #Search for?
	print "What do you want to search for?\n";
	$search=<STDIN>; chomp($search);
}

while ($replace eq '') { #Replace with?
	print "Replace $search with?\n";
	$replace=<STDIN>; chomp($replace);
}

while ((lc($casesensitive) ne 'y') and (lc($casesensitive) ne 'n')) { #Perform case sensitive/insensitive search?
	print "Perform case sensitive search? (Y/N) ";
	$casesensitive=<STDIN>; chomp($casesensitive);
}

while ((lc($prompt) ne 'y') and (lc($prompt) ne 'n')) { #Confirmation prompt?
	print "\nRequire confirmation before replacing anything? (Y/N) ";
	$prompt=<STDIN>; chomp($prompt);
}

#Confirm with the user whether to proceed or not
while ((lc($confirm) ne 'y') and (lc($confirm) ne 'n')) {
	print "\nAre you sure you want to proceed? (Y/N) ";
	$confirm=<STDIN>; chomp($confirm);
} if ($confirm eq 'n') {print "Search aborted\n"; exit;}

print "\nBegin searching for $search and replacing it with $replace\n";

$starttime=time; #Record starting time

@directories = readdir DIR; #Read directory contents
foreach $file (@directories) {
	$found=0; #Reset the found match(es) variable
	@filecontent=(); #Clear variable that temporarily stores file contents
	if (substr($file,0,1) eq '.') {next;} #'.'=this directory, '..'=up 1 level
	open(INF,"$dir\\$file") or next; #Open file for input. If fail to open, it is a directory, so goto next file
	@filecontent=<INF>; #Read entire file contents into variable
	close(INF); #Close file
	print "Searching in $dir\\$file\n";
	if ($casesensitive eq 'y') { #Perform case sensitive search
		foreach $line (@filecontent) {
			if ($line =~ s/$search/$replace/g) { $found = 1; }
		}
	} elsif ($casesensitive eq 'n') { #Perform case insensitive search
		foreach $line (@filecontent) {
			if ($line =~ s/$search/$replace/gi) { $found = 1; }
		}
	} if (!$found) { next; } #Next loop if search string not found
	++$filesfound; #Increase the files found counter
	if ($prompt eq 'y') { #Prompt user before making any replacements
		while ((lc($proceed) ne 'y') and (lc($proceed) ne 'n')) {
			print "Found search string in $file. Modify it? (Y/N) ";
			$proceed=<STDIN>; #Ask user for delete confirmation
			chomp($proceed); #Remove the "\n"
		}
		if (lc($proceed) eq 'y') { #User confirmed yes
			$proceed=0; #Reset the $proceed variable
			if (open(OUTF,">$dir\\$file")) { #Open file for output
				print "Modifying $file\n";
				foreach $line (@filecontent) {
					print OUTF $line; #Write modified variable into file
				}
				close(OUTF); #Close file
				++$filesmodified; #Increase the files modified counter
			} else { print "Error opening $file for output"; } #Error opening file for output
		} else { print "Not modifying $file\n"; } #User confirmed no
	} else { #Automatically make replacements without prompting user
		print "Found search string in $file, modifying file\n";
		if (open(OUTF,">$dir\\$file")) { #Open file for output
			foreach $line (@filecontent) {
				print OUTF $line; #Write modified variable into file
			}
			close(OUTF); #Close file
			++$filesmodified; #Increase the files modified counter
		} else { #Error opening file for output
			print "Error opening $file for output";
		}
	}
}

closedir DIR; #Close directory

#Output result of search and replace to user
print "\nFinished searching and replacing in ".(time-($starttime))." seconds.\n";
print "Number of file(s) containing search keyword(s): $filesfound\n";
print "Number of file(s) modified: $filesmodified\n"; #Tell how many files modified

exit; #Exit

sub dirnotfound {print "Error: $_[0] directory not found."; exit;}
