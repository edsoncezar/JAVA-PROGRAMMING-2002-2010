#######################################################
#		404 Manager version 1.0
#
#     	Created by: Solution Scripts 
# 		Email: solutions@solutionscripts.com
#		Web: http://solutionscripts.com
#
#######################################################
#
#
# COPYRIGHT NOTICE:
#
# Copyright 2000 Solution Scripts  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified free of charge, so long as this copyright notice, the header 
# above and all the footers in the program that give me credit remain 
# intact. Please also send me an email, and let me know 
# where you are using this script. 
#
# By using this program you agree to indemnify Solution Scripts from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
######################################################

HISTORY:
-------------------------------------
1.0 -- Monday, April 17, 2000
          Public-Release
-------------------------------------

404 Manager is a program that allows you to view simply and easily requests that
returned a 404 status on your server. The 404 Manager shows you how many requests
have been made for that url, overall, this month, and this day, plus the number 
since you last viewed the 404 Manager.

The other cool feature of 404 Manager is that it also logs the referring URLs to these
404 requests. By clicking on any "Page URI" from the main 404 Manager screen, a new 
window will open with the complete history for pages that have referred that particular
URL, along with complete stats.


404 Manager is also simple to install.
Follow these easy instructions.

1. Open notfound.cgi in a text editor
2. make sure #!/urs/bin/perl is set to where perl is located
3. Edit the $data_path to point towards a directory you want used for the data files
   (there will be a lot of data files, we suggest you make a new directory just for the 404 Manager)
   (This directory must be writable by the using the web server runs as, this usually means chmoding to 666)
4. Set $strip = 1 if you want the QUERY_STRING (anything after ? in the url) to be removed.
5. Add any additional HTML you want shown on the 404 not found page displayed to end user.
   (404 File not found and a short message is already displayed to end user, this is for adding more)
   
6. Open 404manager.cgi in a text editor
7. make sure #!/urs/bin/perl is set to where perl is located
8. Set $data_path to the same directory as is set in notfound.cgi 
9. Edit the $total_day variables to show number of days to keep non active referrers on the list
10. Upload both to cgi-bin in ASCII and chmod them to 755
11. Set Apache to use notfound.cgi as the ErrorDocument

If you have control over the httpd.conf file for Apache simply replace
any current ErrorDocument 404 lines with..

ErrorDocument 404 /cgi-bin/404/notfound.cgi


If you have a virtual account and can use .htaccess files, create or edit
a .htaccess file in your document root (the directory that holds your main
index.html file) and add the following.

ErrorDocument 404 /cgi-bin/404/notfound.cgi

/cgi-bin/404/notfound.cgi = The virtual location of where you installed notfound.cgi 


12. To check the 404's, run the 404manager.cgi from any web browser 
(enter the url in your browsers address bar.)

That is all.....


We do not offer email support for 404 Manager, if you have a problem with the
program, please direct any questions to the cgi forum at
http://forum.solutionscripts.com/


Solution Scripts
http://solutionscripts.com