# Ringlink $Id: startup.pl,v 1.15 2003/07/25 15:33:04 gunnarh Exp $
#
# Things to be done at startup of the Apache server when running
# Ringlink under mod_perl
#
# This file shall be run through a PerlRequire directive.
# For example:
#
#   PerlRequire "C:/Program/IndigoPerl/apache/conf/startup.pl"
#

use strict;

# This is instead of changing the second line in every executable
# Ringlink file.
use lib 'C:/My Documents/SourceForge/CVS/Ringlink/cgi-bin/ringlink/lib';

# Preloading of Ringlink related modules
use rlmain();
use ring();
use site();

use Archive::Zip();
use Archive::Zip::Tree();
use CGI::Carp();
use File::Find();
use Locale::PGetText();
use Mail::Sender();
use MIME::QuotedPrint();
use Tie::File();

use Fcntl();
use LWP::UserAgent();
use SDBM_File();
use Symbol();

1;

