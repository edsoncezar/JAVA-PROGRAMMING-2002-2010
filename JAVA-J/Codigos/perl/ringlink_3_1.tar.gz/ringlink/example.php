<?php // Ringlink $Id: example.php,v 1.8 2003/07/21 13:08:36 gunnarh Exp $
/*
The purpose with this file is to illustrate how output from the Ringlink
program can be passed to some other program, in this case a PHP script.

To test it, you need to
- Set the three variables below
- Upload this file and example.css
- Set the $rlmain::extappURL variable in rlconfig.pm to the URL of this file

Note that the set-up may behave differently if $rlmain::extappURL includes
the full URL (starting with 'http://'), compared to a relative or absolute
URL. You may want to test both to decide which you prefer.

The configuration of some PHP installations prevents PHP (through the PHP
open_basedir directive) from being able to read files outside the document
root. If that's the case for you, you may need to move the Ringlink data
directory to somewhere outside the cgi-bin.
*/

// Full path to the Ringlink data directory
$datapath = 'C:/My Documents/SourceForge/localtest/data';

// URL to style sheet
$styleURL = 'example.css';

// If this is set to 0 (zero), the ordinary Ringlink output is displayed
$phpframe = 1;

//---------------------------------------------------------------------------//

function noload() {
    echo "<br /><b>You shall not load (or reload) this file directly. Its purpose is"
        ." to display Ringlink output when called via a redirect from Ringlink.</b>";
}

function charsetheader($datapath) {
    preg_match ('/<meta http-equiv="Content-Type" .+ charset=[\w-]+" \/>/',
                implode ('', file ("$datapath/top.txt")), $charset);
    return $charset[0]."\n";
}

function removefiles($datapath) {
    unlink ("$datapath/top.txt");      // This deletes the temporary files
    unlink ("$datapath/main.txt");     // in the Ringlink data directory.
    unlink ("$datapath/bottom.txt");   // Appropriate for security reasons.
}

if ($phpframe) {
    if (is_file ("$datapath/main.txt")) {
        echo "<html>\n"
            ."<head>\n"
            .charsetheader($datapath)
            ."<meta http-equiv=\"Content-Style-Type\" content=\"text/css\" />\n"
            ."<link rel=\"stylesheet\" type=\"text/css\" href=\"$styleURL\" />\n"
            ."</head>\n"
            ."<body>\n"
            ."<center>\n"
            .implode('', file("$datapath/main.txt")) /* Here it grabs the Ringlink output */
            ."</center>\n"
            ."</body>\n"
            ."</html>\n";
        removefiles($datapath);
    } else {
        noload();
    }    
} else {
    if (is_file ("$datapath/main.txt")) {
        echo implode('', file("$datapath/top.txt"))
            .implode('', file("$datapath/main.txt"))
            .implode('', file("$datapath/bottom.txt"));
        removefiles($datapath);
    } else {
        noload();
    }    
}

?>