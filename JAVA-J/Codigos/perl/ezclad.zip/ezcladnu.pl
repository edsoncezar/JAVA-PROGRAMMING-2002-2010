#!/usr/bin/perl
require 'date.pl';
###########################################################################
#                                                                         #
#        Classifieds.pl - Perl Script for Posting Classified Ads          #
#                                                                         #
#           Written by Greg Mathews - greg@notts.net            #
#modified by manny juan - manny@jps.net, http://www.inet-images.com/manny #
# 
# ezcladnu.pl v1.2 11/16/99 added View ALL button for viewing all ads  
###########################################################################

$basedir="/home/htdocs/your.isp.com/website/";
$baseurl="http://www.isp.com/website/";
$mailprog = "/usr/sbin/sendmail";

# DO NOT MAKE ANY CHANGES BELOW THIS LINE             
###########################################################################
@gtoday=localtime(time);
$today=&today();    
$d=$gtoday[3];
$m=$gtoday[4];
$y=$gtoday[5];
$m+=1;
if($y<50) {$y+=2000} else {$y+=1900};
$shortdate="$m/$d/$y";

&UnWeb;

$AdSubject = $in{'AdSubject'};
$DeptEntry = $in{'DeptEntry'};
($Department, $DeptName) = split(/\|/, $DeptEntry);
$Description = $in{'Description'};
$EMailAddress = $in{'EMailAddress'};
$pagename = $in{'pagename'};
$Linkurl = $in{'Linkurl'};
$RealName = $in{'RealName'};
$return_name=$in{'return'};  #who the mail is from.
$Selection = $in{'Selection'};
$userdir  = $in{'userdir'};
$maxdepn  = $in{'maxdepn'};
$maxdays  = $in{'maxdays'};
$colorset = $in{'colorset'};
$mycatk = $in{'mycatk'};

($bkgdc, $textc, $linkc, $vlinkc) = split('~', $colorset);

$AdsFile  = "$basedir$userdir/$pagename";
$badreturn= "$baseurl$userdir/$pagename.html";
$returnURL= "$baseurl$userdir/$pagename.html";
$viewdir  = "$baseurl$userdir/$pagename.html";

$DelRealName = $in{'DelRealName'};
$DelEMailAddress = $in{'DelEMailAddress'};
$DelAdNo = $in{'DelAdNo'};

$Description =~ s/&&/<br><br>/g;
$AdNumber = 0;

if ($Selection eq "ViewAds") {
    if ($Department eq "") {
        # User did not choose a department to view so return the error message and quit
        &PrintHeader;
        print "<html>\n";
        print "<head>\n";
        print "<title>Error Message</title>\n";
        print "</head>\n";
        print "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";
        print "\n";
        print "<h1>An Error Has Occurred:</h1><p>\n";
        print "You did not choose a department to view ads in.  Please choose one by selecting the button next to the appropriate department.<p>\n";
        print "<hr><p><center><a href=$badreturn>Return to the Form</a><p><hr>\n";
        print "powered by <b>ezclad.pl</b> found at <a href=\"http://www.inet-images.com/manny\">manny juan's script page</a>";
        print "</body>\n";
        print "</html>\n";
        
        # make a call to exit to end the script now, we had an error
        exit;
        }
    else {
        &viewads;
		exit;
        }
    }

if ($Selection eq "ViewALL") {
	$Department="ALL";
	&viewads;
	exit;
	}

if ($Selection eq "DeleteAd") {
    if (($DelRealName eq "") || ($DelEMailAddress eq "") || ($DelAdNo eq "")) {
        &PrintHeader;
        print "<html>\n";
        print "<head>\n";
        print "<title>Error Message</title>\n";
        print "</head>\n";
        print "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";
        print "\n";
        print "<h1>An Error Has Occurred:</h1><p>\n";
        print "A field was left empty.  Name, Email and Ad number must be filled in completely before the ad can be deleted.<p>\n";
        print "<hr><p><center><a href=$badreturn>Return to the Form</a><p><hr>\n";
        print "powered by <b>ezclad.pl</b> found at <a href=\"http://www.inet-images.com/manny\">manny juan's script page</a>";
        print "</body>\n";
        print "</html>\n";
        
        # make a call to exit to end the script now, we had an error
        exit;
        }
    else {
        &delad;
		exit;
        }
    }

if (($RealName eq "") || ($EMailAddress eq "") 
    || ($Department eq "") || ($Description eq "")) {
        # something was blank, return the error message
        &PrintHeader;
        print "<html>\n";
        print "<head>\n";
        print "<title>Error Message</title>\n";
        print "</head>\n";
        print "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";
        print "\n";
        print "<h1>An Error Has Occurred:</h1><p>\n";
        print "A field was left empty (maybe department?). ";
        print "All fields must be filled in completely before the ad can be posted.<p>\n";
        print "<hr><p><center><a href=$badreturn>Return to the Form</a><p><hr>\n";
        print "powered by <b>ezclad.pl</b> found at <a href=\"http://www.inet-images.com/manny\">manny juan's script page</a>";
        print "</body>\n";
        print "</html>\n";
        
        # make a call to exit to end the script now, we had an error
        exit;
}

# Lock the file for security so the file is not damaged if more than one user tries to access it at the same time.
&PrintHeader;
        
$quit = 0;
while ($quit != 1) {
    if (-e "$AdsFile.lok") {
        # The file exists, time to take a nap
        sleep(1);
    }
    else {
    
    # Create the lock file, thereby locking the Classified Ad file
    open (LOCK,">$AdsFile.lok");
    close LOCK;
    }
    
    # Open the data file to read the number of the last post
    open (ADFILE, "$AdsFile.adn");
    $AdNumber = <ADFILE>;
    # chop $AdNumber;

    # Update the Ad Number by one
    $AdNumber = $AdNumber + 1;
    
    # Rewrite the data file
    open (ADFILE, ">$AdsFile.adn");
    print ADFILE $AdNumber;
    close(ADFILE);

#   save the current ad
    $currad = "$AdNumber|$Department|$AdSubject|$shortdate|$RealName|$EMailAddress|$Linkurl|$Description";

    # Append the user's ad and description to the ad file
    open(ADFILE,"$AdsFile.ads") || die $!;
    @main = <ADFILE>;
    close(ADFILE);
    open(ADFILE,">$AdsFile.ads") || die $!;
    print ADFILE "$AdNumber|$Department|$AdSubject|$shortdate|$RealName|$EMailAddress|$Linkurl|$Description\n";
    $depctr{$Department}++;
    foreach $main_line (@main) {
        ($AdNumber,$Department,$AdSubject,$shortdate,$RealName,$EMailAddress,$Linkurl,$Description)
        = split(/\|/, $main_line);
        ($m, $d, $y) = split(/\//,$shortdate);
        $itemdate = &jday($m, $d, $y);
        $age= ($today - $itemdate);
        if (($age <= $maxdays) && ($depctr{$Department} < $maxdepn)) {
            print ADFILE "$main_line";
            $depctr{$Department}++;
            }
        }
    # unlock the lock file
    unlink("$AdsFile.lok");

#   restore the current ad
    ($AdNumber,$Department,$AdSubject,$shortdate,$RealName,$EMailAddress,$Linkurl,$Description)
    = split(/\|/, $currad);

    open( MAIL, "|$mailprog $EMailAddress" )
    || die "can't open sendmail: $email: $!\n";
    print MAIL "To: $EMailAddress\n";
    print MAIL "Subject: Classified Ad Response\n";
    print MAIL "From: $return_name\n";
    print MAIL "Reply-to: $return_name\n\n";

    print MAIL "   Thank you for the entry to the\n";
    print MAIL "   Classifieds on our site. Your entry to $DeptName looks like:\n\n";

    print MAIL "Ad No.: $AdNumber - Subject: $AdSubject - Posted on: $shortdate\n";
    print MAIL "Reply to: $RealName at <a href=\"mailto: $EMailAddress\">$EMailAddress</a>\n";
    print MAIL "$Description\n";
    print MAIL "$Linkurl\n";
    print MAIL "Webmaster.\n";
    close(MAIL);

    #--------------------------------
    #
    #Send your keeper's notification out.
    #

    if( $return_name ne "" )
    {
        open( MAIL, "|$mailprog $return_name" )
        || die "can't open sendmail notify: $return_name: $!\n";
        print MAIL "To: $return_name\n";
        print MAIL "Subject:Classified Ad Notification\n";
        print MAIL "From: $RealName <$EMailAddress>\n\n";
        print MAIL "I have just made the following entry to $DeptName:\n\n";

        print MAIL "Ad No.: $AdNumber - Subject: $AdSubject - Posted on: $shortdate<br>\n";
        print MAIL "Reply to: $RealName at <a href=\"mailto: $EMailAddress\">$EMailAddress</a><br>\n";
        print MAIL "$Description\n";
        print MAIL "$Linkurl</a>";

    }
    close(MAIL);
    
    # Return the user to the Return URL
#    print "<meta http-equiv=\"refresh\" content=\"1; url=$returnURL\">\n";

    print "<html><body>";
    print "<h2>Post Ad Completion</h2>";
    print "<p>Your ad has been added to $DeptName.";
    print "<p><a href=$returnURL>Return to Classifieds</a>";
    print "</body></html>";

    $quit = 1;

}

sub UnWeb {

   # Get the input
   read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

   # Split the name-value pairs
   @pairs = split(/&/, $buffer);

   foreach $pair (@pairs) {
      ($name, $value) = split(/=/, $pair);
		 
      # Un-Webify plus signs and %-encoding
      $value =~ tr/+/ /;
      $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
      $value =~ s/<!--(.|\n)*-->//g;

      if ($allow_html != 1) {
         $value =~ s/<([^>]|\n)*>//g;
      }
      else {
         unless ($name eq 'body') {
        $value =~ s/<([^>]|\n)*>//g;
         }
      }

      $in{$name} = $value;
   }

}


#######################
# Print HTML Header

sub PrintHeader {
    print "Content-type: text/html\n\n";
}

sub viewads {
    open(ADFILE,"$AdsFile.ads") || die $!;
    @main = <ADFILE>;
    close(ADFILE);
    &PrintHeader;
    print "<html>";
	if ($Department eq 'ALL') {
		@catlist=split(/\./,$mycatk);
	}
	else {
		@catlist=($Department);
	}
    print "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";

    print "<center><table border=1 width=62%>";
	foreach $cat (@catlist) {
		if ($cat eq "") {
			# do nothing
			}
		else {
			print "<tr><td bgcolor=$vlinkc align=center><font color=$bkgdc>";
			if($Department eq 'ALL') {
				print "<center><h3>Ads for $cat</h3></center></td></tr>";
				}
			else {
				print "<center><h3>Ads for $DeptName</h3></center></td></tr>";
				}
			foreach $main_line (@main) {
				($AdNumber,$Dept,$AdSubject,$shortdate,$RealName,$EMailAddress,$Linkurl,$Description)
				= split(/\|/, $main_line);
				if($Dept eq $cat) {
					print "\n<tr><td bgcolor=$linkc align=center><font color=$bkgdc><b>$AdSubject</b></font></td></tr>";
					print "\n<tr><td bgcolor=$bkgdc><font color=$linkc>Ad No. $AdNumber - Posted on $shortdate</font><br>";
					print "\n<a href=\"mailto:$EMailAddress\">[Email]</a>";
					print "&nbsp;&nbsp;<a href=\"$Linkurl\">[Homepage]</a><br>";
					print "\n$Description<br></td></tr>";
					}
				}
			}
		}
    print "</table></center>";
    print "</body></html>";
    }

sub delad {
    open(ADFILE,"$AdsFile.ads") || die $!;
    @main = <ADFILE>;
    close(ADFILE);
    &PrintHeader;
    print "<html>";
    print "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";

    $addel=0;
    foreach $main_line (@main) {
        ($AdNumber,$Dept,$AdSubject,$shortdate,$RealName,$EMailAddress,$Linkurl,$Description)
        = split(/\|/, $main_line);
        if (($AdNumber eq $DelAdNo) and ($DelRealName eq $RealName) and ($DelEMailAddress eq $EMailAddress)) {
            print "<table border=1 width=50%>";
            print "<tr><td>$AdSubject</td></tr>";
            print "<tr><td>Ad No. $AdNumber - Posted on $shortdate<br>";
            print "<a href=\"mailto:$EMailAddress\">[Email]</a>";
            print "&nbsp;&nbsp;<a href=\"$Linkurl\">[Homepage]</a><br>";
            print "$Description</td></tr>";
            print "</table>\n";
            print "<p>The ad above has been deleted";
            print "<p><a href=$returnURL>Return to Classifieds</a>";
            $addel=1;
            }
        }
    if ($addel==0) {
        print "Ad No. $DelAdNo not found for $DelRealName, $DelEMailAddress; please go back and re-enter name, email and ad number";
        }
    else {
        open(ADFILE,">$AdsFile.ads") || die $!;
        foreach $main_line (@main) {
            ($AdNumber,$Dept,$AdSubject,$shortdate,$RealName,$EMailAddress,$Linkurl,$Description)
            = split(/\|/, $main_line);
            if (($AdNumber eq $DelAdNo) and ($DelRealName eq $RealName) and ($DelEMailAddress eq $EMailAddress)) {
                # do nothing (ie. delete it)
                }
            else {
                print ADFILE $main_line;
                }    
            }
        close(ADFILE);
        }
    print "</body></html>";
    }

sub dummy {
    &PrintHeader;
    print "<html>\n";
    print "<head>\n";
    exit;
    }

