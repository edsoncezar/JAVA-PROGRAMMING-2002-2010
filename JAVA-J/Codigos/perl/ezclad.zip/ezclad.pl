#!/usr/bin/perl
# 
# ezclad.pl - EZ Classfied Ad Page Generator - by Manny Juan <manny@jps.net> 4/3/99
# http://www.inet-images.com/manny/clad/
#
# this program was adapted from ezhomepg.pl
#
# This will give your visitors the opportunity to set up a classified ad page on your
# site. the generated classified ad page uses ezcladnu.pl, patterned after greg mathews'  
# classified.cgi script, and modified so it could automatically generate the required
# files from a fill-in form.
#
# ezclad.pl v1.2 11/16/99 added view ALL button for viewing all ads
#####################################################################################
$SIG{__DIE__} = \&Error_Msg;

sub Error_Msg {
    $msg = "@_";
    print "\ncontent-type: text/html\n\n";
    print "The following error occurred : $msg\n";
    exit;
}

# Get the input
read(STDIN, $input, $ENV{'CONTENT_LENGTH'});

    # split the input
    @pairs = split(/&/, $input);

    # split the name/value pairs
    foreach $pair (@pairs) {

    ($name, $value) = split(/=/, $pair);

    $name =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/<([^>]|\n)*>//g;
    if ($name eq 'cat') {
       push (@{$FORM{$name}}, $value);
       }
    else {
        $FORM{$name} = $value;
        }
    }
$userdir = $FORM{'userdir'};

######################################################################################
# set variables HERE

$win95=0;

# Set this to your base HTML directory. This is a PATH not a URL
$base_dir = "/home/htdocs/your.isp.com/website/$userdir";

$cgiurl = "http://www.isp.com/website/cgi-bin";

# This is your URL of where the new HTML pages will be kept - keep the trailing slash
$baseurl = "http://www.isp.com/website/$userdir/";

# This is a URL and dir for the images sub directory in the userpages directory.
# Create the images directory in the userpages directory. This is where
# you will upload your background images
$imageurl = $baseurl;

# This is the path for user pages. You don't really need to change this
# Just make sure to create a directory: userpages and chmod it 777
$page_dir = "$base_dir/";

# This is the index of all generated pages
# This file should be chmod to 777 and placed in the userpages directory
$indexpage = "$base_dir/index.html";

# This is the location of the data.txt file. This holds each user's
# login name and e-mail address for confirmation
$data = "$base_dir/data.txt";
$catlist = "$base_dir/catlist.txt";

#Site title

$title="EZ Classified Ads Mall";

# self explanatory variables for your site logo
$logo = "$imageurl/mjmall.jpg";
$logoalt = "Cyber Mall";

# Location of the sendmail program
$sendmail = '/usr/sbin/sendmail';

# Your e-mail address here
$myemail = 'email@isp.com';

# That's it.

# DO NOT CHANGE ANYTHING BELOW THIS LINE
######################################################################################

# Lets do some translating first
$usrname = $FORM{'usrname'};
$login = $FORM{'login'};
$email = $FORM{'email'};
$pagename = $FORM{'pagename'};
$headline = $FORM{'headline'};
$updact = $FORM{'updact'};
$colorset = $FORM{'colorset'};
$maxdays = $FORM{'maxdays'};
$maxdepn = $FORM{'maxdepn'};
$retlink = $FORM{'retlink'};
$mycats = join('|',@{$FORM{'cat'}});

# convert to hash
%mycatd = split('\|',$mycats);

# build string containing all my keys
$mycatk ="";
foreach $tag (keys %mycatd) { # For every tag 
    $mycatk .= ".$tag";
    }

$gbparms="$maxdays~$maxdepn~$retlink~$mycatk";

# If the user tries to add more than one word in
# the page name field, this will put an underscore
# in the spaces to make it one word
$pagename =~ s/ /_/g;

if ($FORM{'action'} eq "New Page") {
    &newpage;
    }
if ($FORM{'action'} eq "Create Page") {
    &create;
    }
if ($FORM{'action'} eq "Edit Page") {
    &confirm("edit");
    }
if ($FORM{'action'} eq "checkuser") {
    &checkuser;
    }
if ($FORM{'action'} eq "recreate") {
    &recreate;
    }
if ($FORM{'action'} eq "Delete Page") {
    &confirm("delete");
    }
    exit;

sub newpage {
    local($usrname, $email, $headline,  $pagename, $colorset, $gbparms);

    ($usrname, $email, $headline,  $pagename, $colorset, $gbparms) = split(/&&/, "");

    # To avoid any security risks. Take out the HTML tags added when HPM translated
    # the && to: <br><br>. They will be re-translated to: && Once the user updates
    # the page, the: && will be put back to: <br><br>

    # print the edit-page form

    print "content-type: text/html\n\n";
    print "<html><head><title>Create Your Own Classified Ads Page</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<table width=75% cellspacing=2 cellpadding=2 border=0>\n";
    print "<tr><td width=100% align=left valign=top>\n";
    print "<p><font face=\"Arial, Geneva\"><h2>Create Your Own Home Classified Ads Page</h2></font></p>\n";
    print "<p>Below is an empty form for you to fill in. The next five fields (<b>bold</b>) are required.\n";
    print "You can edit any part of your page later</p>\n";
    print "<p></p>\n";
    print "<form action=\"$cgiurl/ezclad.pl\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<input type=hidden name=\"action\" value=\"Create Page\">\n";
    print "<b>Your name:</b><br>\n";
    print "<font size=\"-1\">(will appear in page as link to your email)</font><br>\n";
    print "<input type=text size=40 name=\"usrname\" value=\"$usrname\"><br><br>\n";
    print "<h3>(The next 3 fields will be used for editing)<h3>\n";
    print "<b>Login Id:</b>\n";
    print "<font size=\"-1\">(one word only you should know, used later for editing)</font><br>\n";
    print "<input type=text size=40 name=\"login\" value=\"$login\"><br><br>\n";
    print "<b>Your e-mail:</b>\n";
    print "<font size=\"-1\">(used for editing, will also appear in page)</font><br>\n";
    print "<input type=text size=40 name=\"email\" value=\"$email\"><br><br>\n";
    print "<b>Your page:</b>\n";
    print "<font size=\"-1\">(one word, will become the name of your html file)</font><br>\n";
    print "<input type=text size=40 name=\"pagename\" value=\"$pagename\"><br><br>\n";
    print "<b>headline:</b>\n";
    print "<font size=\"-1\">(how your page will be listed in index)</font><br>\n";
    print "<input type=text size=40 name=\"headline\" value=\"$headline\"><br><br>\n";
    print "</td></tr></table>\n";

    &build_form_content($usrname, $email, $headline,  $pagename, $colorset, $gbparms);
    print "<P><input type=submit value=\"create page\">\n";
    print "</form>\n";
    print "</body></html>\n";
    }

sub create {

    # Now, lets do some error checking. Making sure they filled out each field
    # This is pretty low tech now. I'll improve it later
    &missing(missing_name) unless $usrname;
    &missing(missing_email) unless $email;
    &missing(missing_pagename) unless $pagename;

    # if they try to name their page "index" This will stop them
    if (uc($pagename) eq "INDEX") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
        print "<p>You cannot name your page <b>index</b>\n";
        print "Please go back and re-name your page</p>\n";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        exit;
        }
    # if they Don't give their page a headline This will stop them
    if ($headline eq "") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<p>You MUST give your page a <b>headline</b>\n";
        print "Please go back and enter one for your page</p>\n";
        exit;
        }

    # if the user tries to name their page 
    # something that is already taken
    # this will HOPEFULLY stop them :)
    # This block was written by Norm
    if (-e "$page_dir$pagename\.html") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<p>The page name: <b>$pagename</b>\n";
        print "is already taken.\n";
        print "Please go back and rename your page</p>\n";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        exit;
        }

    &chk_bad_maxdepn;
    &chk_bad_maxdays;
    &chk_no_cat;

    #now, lets create our new html page
    &buildpage_top($colorset,$gbparms);
    &buildpage_bot;
    &save_page_data;

    # Write the login name and email address to a separate file for confirmation
    # when they want to edit their page
    open (FILE, ">>$data") || die "I can't open >>$data\n";
    if($win95==0){flock (FILE, 2) or die "can't lock data file\n";}
    print FILE "$login&&$email&&$pagename\n";
    close(FILE);


    # Suck the index page, and write the new entry to it
    open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
    @lines = <FILE>;
    close(FILE);
    $sizelines = @lines;

    # Now, re-open the links file, and add the new link
    open(FILE, ">$indexpage") || die "I can't open that file >$indexpage\n";
    if($win95==0){flock (FILE, 2) or die "can't lock index file\n";}

    for ($a = 0; $a <= $sizelines; $a++) {

        $_ = $lines[$a];

        if (/<!--begin-->/) {

            print FILE "<!--begin-->\n";
            print FILE "<p><font face=\"Arial, Geneva\" size=4><a href=\"$baseurl$pagename.html\">$headline</a></font></p>\n";

        } else {
            print FILE $_;
            }
        }
    close(FILE);


    # Give the user a response
    print "content-type: text/html\n\n";
    print "<html><head><title>thanks</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<BR><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";

    print "Your page has been created, and you will receive an e-mail confirming this!\n";
    print "Your URL is: <a href=\"$baseurl$pagename\.html\">\n";
    print "$baseurl$pagename\.html</a>\n";
    print "Remember to press Reload.\n";
    print "Thanks for your participation!\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";


    # Send the user an e-mail confirming their page
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $usrname <$email>\n";
    print MAIL "From: $myemail\n";
    print MAIL "Subject: Your new URL on the $title\n";
    print MAIL "Your page can be viewed at the URL below:\n";
    print MAIL "\n";
    print MAIL "$baseurl$pagename\.html\n";
    print MAIL "\nThank you for using the $title\n";
    print MAIL "\n\nThe Mall Manager - $myemail\n";
    close (MAIL);

    # Notify us when someone creates a page
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $myemail\n";
    print MAIL "From: $usrname <$email>\n";
    print MAIL "Subject: $title New Page Report\n";
    print MAIL "$usrname created a new page:\n";
    print MAIL "$baseurl$pagename\.html\n";
    close(MAIL);

    }

sub recreate {
    &chk_bad_maxdepn;
    &chk_bad_maxdays;
    &chk_no_cat;

    #now, lets create our new html page
    # Suck the guestbook page
    open(FILE, "$page_dir$pagename.html") || die "I can't open that file page_dir$pagename.html\n";
    if($win95==0){flock (FILE, 1) or die "can't lock data file\n";}
    @lines = <FILE>;
    close(FILE);
    $sizelines = @lines;

    &buildpage_top($colorset, $gbparms);

    # rewrite the older entries, start from marker until end
    $sw=0;
    for ($a = 0; $a <= $sizelines; $a++) {
        $_ = $lines[$a];
        if(/<!--begin-->/) {$sw=1;}
        if ($sw==1) {
            print HTML "$_"; 
            }
        }
    &save_page_data;

    &ntfy_usr_edt;

    # Give the user a response
    print "content-type: text/html\n\n";
    print "<html><head><title>thanks</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\" border=0></CENTER>\n";
    print "<P><BR><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "Your page has been revised, and you will receive an e-mail confirming this!\n";
    print "Your URL is: <a href=\"$baseurl$pagename\.html\">\n";
    print "$baseurl$pagename\.html</a>\n";
    print "Remember to press Reload.\n";
    print "Thanks for your participation!\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";
    }

sub ntfy_usr_edt {
    # Send the user a notice that their page has been re-done
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $usrname <$email>\n";
    print MAIL "From: $myemail\n";
    print MAIL "Subject: Your Changes on the $title\n";
    print MAIL "Your revised page can be viewed at the URL below:\n";
    print MAIL "\n";
    print MAIL "$baseurl$pagename\.html\n";
    print MAIL "\nOnce again thank you for using the $title\n";
    print MAIL "\n\nThe Mall Manager\n";
    close (MAIL);
    }

sub chk_bad_maxdepn {
    if ($maxdepn !~ /^(\d){1,3}$/) {
        &input_error("invalid or unreasonable value for max items in a category (enter 1 to 99)");
        exit;
        }
    }
sub chk_bad_maxdays {
    if ($maxdays !~ /^(\d){1,3}$/) {
        &input_error("invalid or unreasonable value for max retention days (enter 1 to 99)");
        exit;
        }
    }
sub chk_no_cat {
    if ($mycatk eq "") {
        &input_error("no ad categories selected (please select from list)");
        exit;
        }
    }
sub input_error {
    local ($errmsg) = @_;
    print "content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
    print "<body>";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<h1>Input Error!</h1><h3>$errmsg.</h3>\n";
    print "<p>Please go back and correct</p>\n";
    }
sub buildpage_top {
    local ($colorset, $gbparms) = @_;
    if ($colorset eq "") {$colorset='FFFFFF~333333~006699~999900';}
    ($bkgdc, $textc, $linkc, $vlinkc) = split('~', $colorset);
    ($maxdays,$maxdepn,$retlink,$mycatk) = split('~',$gbparms);

    open(HTML, ">$page_dir$pagename\.html") || die "I can't create that file >$page_dir$pagename\.html\n";
    if($win95==0){flock (HTML, 2) or die "can't lock html file\n";}

    print HTML "<html><head><title>easy classified ad page by ezclad.pl</title></head>\n";
    print HTML "<body bgcolor=\"#$bkgdc\" TEXT=\"#$textc\" link=\"#$linkc\" vlink=\"#$vlinkc\">\n";
#   print HTML "\n<!--banner code here-->";
#    print HTML "<center><h3>classified ads</h3></center>\n";
    print HTML <<EOHTML;
<hr><table width=100%><tr><td bgcolor=$vlinkc align=center><font color=$bkgdc><center>
<h1>$headline</h1>
</center></font></td></tr></table>
EOHTML

    print HTML "<A HREF=\"$retlink\">Return</A>\n";
    print HTML "<br><A HREF=\"$baseurl\">Visit EZ Classified Ads Mall</A>\n";
    print HTML "<form method=POST action=\"$cgiurl/ezcladnu.pl\">";
    print HTML <<EOHTML;
<hr><table width=50%><tr><td bgcolor=$linkc align=center><font color=$bkgdc><center>
<H2>Instructions</H2>
</center></font></td></tr></table>
EOHTML

    print HTML "<table cellpadding=10>";
    print HTML "<tr><td valign=top width=\"35%\">";
    print HTML "<br><br>";
    print HTML "<table width=100%><tr><td bgcolor=$vlinkc align=center><font color=$bkgdc><center>";
    print HTML "<b>Select Department here:</b>";
    print HTML "</center></font></td></tr></table>";

    foreach (@{$FORM{'cat'}}) {
        ($catname,$catdesc) = split('\|',$_);
        if ( $mycatk =~ /\.$catname/ ) {
            print HTML "\n<br><input type=radio name=\"DeptEntry\" value=\"$_\"> $catdesc";
            }
        }
    print HTML "</td><td>";
    print HTML <<EOHTML;
<P><B>Submitting Your Classified Ad</B><BR>
To submit your classified ad, select department at left and fill out the form below completely.
If the form is not filled out completely, your ad will not be added to the system.  
When done, select the "Post Ad" button on this page.<P>

<B>Viewing Classified Ads</B><BR>
To view classified ads, select one of the departments at left available for viewing.
Then, select the "ViewAds" button on this page.
<p>Or, press the "ViewALL' button to view all ads.
<P>

<B>Removing your Classified Ads</B><BR>
If you have posted a classified ad and wish to remove it at any time (ie. it has been sold), 
enter your name, email and number of ad to delete, then press the "Delete Ad" button.
<P>
</td></tr></table>
<hr><table width=50%><tr><td bgcolor=$linkc align=center><font color=$bkgdc><center>
<H2>View Ads</H2>
</center></font></td></tr></table>

Select Department from list, then press this button:
<p><input type=submit name="Selection" value="ViewAds">
<p>or simply press this button to view all ads:
<p><input type=submit name="Selection" value="ViewALL">
<hr><table width=50%><tr><td bgcolor=$linkc align=center><font color=$bkgdc><center>
<H2>Post Ad</H2>
</center></font></td></tr></table>

Select Department from list, fill in all fields, then press "Post Ad" button below:
<p>
<TABLE border=0>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">Your Name:</FONT></B></TD>
<TD><INPUT type=text name="RealName" size=50></TD></TR>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">E-Mail Address:</FONT></B></TD>
<TD><INPUT type=text name="EMailAddress" size=50></TD></TR>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">HomePage URL:</FONT> </B></TD><TD>
<INPUT type=text name="Linkurl" size=50 value="http://"></TD></TR>
</TABLE>
<B><FONT face="COMIC SANS MS,ARIAL">What is the subject of your ad?</FONT></B>
<INPUT type=text name="AdSubject" size=40 maxlength=40><P>
<FONT face="COMIC SANS MS,ARIAL"><B>Please enter a brief description below</B> (No HTML! No CR! Use && to start new paragraph.):</FONT><BR>
<TEXTAREA name="Description" cols=60 rows=5 wrap=virtual></TEXTAREA><P>
<P>
<INPUT type=submit name="Selection" value="PostAd">
<hr><table width=50%><tr><td bgcolor=$linkc align=center><font color=$bkgdc><center>
<H2>Delete Ad</H2>
</center></font></td></tr></table>
<P>Use these fields for ad deletion, then press "Delete Ad" button below:
<p>
<TABLE border=0>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">Your Name:</FONT></B></TD>
<TD><INPUT type=text name="DelRealName" size=50></TD></TR>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">E-Mail Address:</FONT></B></TD>
<TD><INPUT type=text name="DelEMailAddress" size=50></TD></TR>
<TR><TD><B><FONT face="COMIC SANS MS,ARIAL">Ad Number:</FONT> </B></TD><TD>
<INPUT type=text name="DelAdNo" size=10></TD></TR>
</TABLE>
<P>
<INPUT type=submit name="Selection" value="DeleteAd">
<hr><table width=50%><tr><td bgcolor=$linkc align=center><font color=$bkgdc><center>
<H2>Reset Form</H2>
</center></font></td></tr></table>

<P><INPUT type=reset value="Clear All"><P>
EOHTML

    print HTML "\n<input type=hidden name=userdir value=\"$userdir\">";
    print HTML "\n<input type=hidden name=pagename value=\"$pagename\">";
    print HTML "\n<input type=hidden name=maxdepn value=\"$maxdepn\">";
    print HTML "\n<input type=hidden name=maxdays value=\"$maxdays\">";
    print HTML "\n<input type=hidden name=colorset value=\"$colorset\">";
    print HTML "\n<input type=hidden name=mycatk value=\"$mycatk\">";
    print HTML "\n<input type=hidden name=return value=\"$email\">";
    print HTML "\n</form>";
    print HTML "\n<hr>\n";
    }

sub buildpage_bot {
    print HTML "<!--begin-->\n";
    print HTML "<!--end-->\n";
    print HTML "<center><a href=\"mailto:$email\">$usrname</a></font></center>\n";
    print HTML "<center><font size=-1>";
    print HTML "This page was generated by <b>ezclad.pl</b> found at ";
    print HTML "<a href=http://www.inet-images.com/manny/>manny juan's script page</a></font>\n";
    print HTML "</center>\n";
    print HTML "</body></html>\n";
    close(HTML);
    }

sub save_page_data {
    # Write all of the input into a flat file.
    open(FILE, ">$page_dir$pagename\.dat") || die "I can't create that file >$page_dir$pagename\.dat\n";
    if($win95==0){flock (FILE, 2) or die "can't lock user data file\n";}
    print FILE "$usrname&&$email&&$headline&&$pagename&&$colorset&&$gbparms\n";
    close(FILE);
    chmod 0777, '$page_dir$pagename.dat';
    if (-e "$page_dir$pagename.adn") {
        # do nothing
        }
    else {
        open(ADNFILE, ">$page_dir$pagename.adn") || die "I can't create that file >$page_dir$pagename.adn\n";
        if($win95==0){flock (ADNFILE, 2) or die "can't lock adn file\n";}
        print ADNFILE "0\n";
        close(ADNFILE);
        }
    if (-e "$page_dir$pagename.ads") {
        # do nothing
        }
    else {
        open(ADSFILE, ">$page_dir$pagename.ads") || die "I can't create that file >$page_dir$pagename.ads\n";
        if($win95==0){flock (ADSFILE, 2) or die "can't lock ads file\n";}
        print ADSFILE "\n";
        close(ADSFILE);
        }
    }

# Standard error message for any missing required fields
sub missing {
    local ($missing) = @_;
    print "content-type: text/html\n\n";

    print "<HTML><head><TITLE>You missed something</TITLE></head>\n";
    print "<body>\n";
    &put_banner;    
    print "You forgot to fill in one of the fields. Please go back and make\n";
    print "sure that all required fields are filled in! $missing\n";
    print "</body></HTML>\n";
    exit;
    }

sub confirm {
    local ($updact) = @_;

    print "content-type: text/html\n\n";
    print "<html><head><title>$updact Confirmation</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\" >\n";
    &put_banner; 
    print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\"  border=0></CENTER>\n";
    print "<P><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "<p><h3>Please Enter your login name, e-mail and name of your file to $updact</h3></p>\n";
    print "<form action=\"$cgiurl/ezclad.pl\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<P><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "Login name:<br>\n";
    print "<input size=40 type=text name=\"login\"><br><br>\n";
    print "E-mail:<br>\n";
    print "<input size=40 type=text name=\"email\"><br><br>\n";
    print "Name of your file:<br>\n";
    print "<input type=text size=40 name=\"pagename\"><br><br>\n";
    print "<input type=submit value=submit>\n";
    print "<input type=hidden name=\"action\" value=\"checkuser\">\n";
    print "<input type=hidden name=\"updact\" value=\"$updact\">\n";
    print "</FONT>\n";
    print "</form></body></html>\n";
    }

sub checkuser {
    open(FILE, "$data") || die "I can't open $data\n";  
    if($win95==0){flock (FILE, 1) or die "can't lock data file\n";}

    while(<FILE>) {
    chop;       
    @all = split(/\n/);

    foreach $line (@all) {
    ($loginname, $loginemail, $loginpagename) = split(/&&/, $line);
    if($loginname eq "$login" && $loginemail eq "$email" && $loginpagename eq "$pagename") {
        $match = 1;
        if($updact eq "edit") {
          &edit($loginpagename);
          }
        else {
          &delpage($loginpagename);
          }
        }
      }
    }

    close(FILE);

    if (! $match) {
        &error;
        }

    # del entry from data
    if($updact eq "delete") {

        # Suck the index page, and write the new entry to it
        open(FILE, "$data") || die "I can't open that file $data\n";
        if($win95==0){flock (FILE, 1) or die "can't lock data file\n";}
            @lines = <FILE>;
            close(FILE);
            $sizelines = @lines;

        # Now, re-open the links file, and comment out the page to delete
        open(FILE, ">$data") || die "I can't open that file >$data\n";
        if($win95==0){flock (FILE,2) or die "can't lock index file for append\n";}
        chop;
                for ($a = 0; $a <= $sizelines; $a++) {
                $_ = $lines[$a];
                $w = $_;
                $w =~ s/\cM//g;
                $w =~ s/\n//g;
        ($loginname, $loginemail, $loginpagename) = split(/&&/, $w);
        if($loginname eq "$login" && $loginemail eq "$email" && $loginpagename eq "$pagename") {
              # do nothing  (ie. don't write)
              } 
            else {
              if($w eq "") {
                # do nothing (skip)
                }
              else {
                print FILE "$w\n";
                }
              }
            }
        close(FILE);
        print "content-type: text/html\n\n";
        print "<html><head><title>$updact Confirmation</title></head>\n";
        print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\" >\n";
        &put_banner; 
        print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\" border=0></CENTER>\n";
        print "<P><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
        print "<p>your page has been deleted";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        print "</form></body></html>\n";
      }
    }

sub edit {

    local ($editfile) = @_;
    
    open(FILE, "$page_dir$editfile\.dat") || die "I can't open $page_dir$editfile\.dat\n";
    if($win95==0){flock (FILE, 1) or die "can't lock data file for edit\n";}

    while(<FILE>) {
    chop;
    @datafile = split(/\n/);

    foreach $line (@datafile) {
        &build_edit_form($line);
            }
         }
    close(FILE);
    }

sub delpage {
    local ($editfile) = @_;
    $cnt=unlink "$page_dir$editfile\.dat", "$page_dir$editfile\.html";
    $cnt=unlink "$page_dir$editfile\.ads", "$page_dir$editfile\.adn";

    # Suck the index page, and write the new entry to it
    open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and comment out the page to delete
    open(FILE, ">$indexpage") || die "I can't open that file >$indexpage\n";
    if($win95==0){flock (FILE, 2) or die "can't lock index file to delete entry\n";}

            for ($a = 0; $a <= $sizelines; $a++) {

            $_ = $lines[$a];

        if (/$pagename.html/) {
          # do nothing  (ie. don't write)
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);

    }

sub build_edit_form {
    local ($line) = @_;
    local($usrname, $email, $headline,  $pagename, $colorset, $gbparms );

    ($usrname, $email, $headline,  $pagename, $colorset, $gbparms) = split(/&&/, $line);

    ($maxdays,$maxdepn,$retlink,$mycatk) = split('~',$gbparms);

    # To avoid any security risks. Take out the HTML tags added when HPM translated
    # the && to: <br><br>. They will be re-translated to: && Once the user updates
    # the page, the: && will be put back to: <br><br>

    # print the edit-page form

    print "content-type: text/html\n\n";
    print "<html><head><title>Edit Your Page</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner; 
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<table width=75% cellspacing=2 cellpadding=2 border=0>\n";
    print "<tr><td width=100% align=left valign=top>\n";
    print "<p><font face=\"Arial, Geneva\"><h2>Edit Your Page</h2></font></p>\n";
    print "<p>Below is a form with the contents\n";
    print "of the classified ads page you created. You can edit any part of your page</p>\n";
    print "<p></p>\n";
    print "<form action=\"$cgiurl/ezclad.pl\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<input type=hidden name=\"action\" value=\"recreate\">\n";
    print "Your name:<br>\n";
    print "<input type=text size=40 name=\"usrname\" value=\"$usrname\"><br><br>\n";
    print "Your e-mail:<br>\n";
    print "<input type=text size=40 name=\"email\" value=\"$email\"><br><br>\n";
    print "headline:<br>\n";
    print "<input type=text size=40 name=\"headline\" value=\"$headline\"><br><br>\n";
    print "</td></tr></table>\n";
    print "Name of HTML file: <b>$pagename</b><br><br>\n";
    print "<input type=hidden name=\"pagename\" value=\"$pagename\">\n";

    &build_form_content($usrname, $email, $headline,  $pagename, $colorset, $mycatk);
    print "<P><input type=submit value=\"update page\">\n";
    print "</form>\n";
    print "</body></html>\n";
    }

sub build_form_content {
    local ($usrname, $email, $headline,  $pagename, $colorset, $mycatk)=@_;

    print "<b>Select Preset Colors:</b>";
    print "<SELECT NAME=\"colorset\">";
    &put_clropt($colorset,'01','FFFFFF~333333~006699~999900');
    &put_clropt($colorset,'02','CCCCCC~000000~0000CC~660066');
    &put_clropt($colorset,'03','FFFF00~FF6600~FF0033~336633');
    &put_clropt($colorset,'04','CCCC66~330000~CC0000~003300');
    &put_clropt($colorset,'05','FFFF99~330000~CC0000~333333');
    &put_clropt($colorset,'06','99CCCC~000066~0000CC~003366');
    &put_clropt($colorset,'07','CC99FF~000000~FF0033~660066');
    &put_clropt($colorset,'08','CCFF99~666600~006699~003300');
    &put_clropt($colorset,'09','FFCC00~330000~CC0000~660066');
    &put_clropt($colorset,'10','00FF33~0000CC~FF0099~660066');
    &put_clropt($colorset,'11','006699~CCFFCC~FFFF00~00FFFF');
    &put_clropt($colorset,'12','330000~FF6666~FFCC00~CCFF99');
    &put_clropt($colorset,'13','003300~CCCC66~FFFFFF~FFFF00');
    &put_clropt($colorset,'14','333333~CCCCCC~FF6666~CCCC66');
    &put_clropt($colorset,'15','666600~FFFFFF~FFFF00~99CCFF');
    &put_clropt($colorset,'16','000000~99CCFF~FFFF00~CCCC66');
    &put_clropt($colorset,'17','333333~FFFFFF~99CCFF~CC99FF');
    &put_clropt($colorset,'18','CC0000~FFFFFF~FFFF00~00FFFF');
    print "\n</SELECT>";
    print "<br><img src=\"$baseurl/ezpalette.gif\"><br><br>\n";
    print "<b>Max Days:</b> maximum days (ie. expiration age)<br>\n";
    print "<input type=text size=5 name=\"maxdays\" value=\"$maxdays\"><br><br>\n";
    print "<b>Max Items:</b> maximum number of entries in each category<br>\n";
    print "<input type=text size=5 name=\"maxdepn\" value=\"$maxdepn\">\n";

    open(FILE, "$catlist") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock cat file\n";}
    @catlines = <FILE>;
    close(FILE);
    print "<br><br><b>Select the desired Ad Categories:</b>\n";
    foreach (@catlines) {
        chop;
        ($catname,$catdesc) = split('\|',$_);
        print "\n<br><input type=\"Checkbox\" name=\"cat\" value=\"$_\"";
        if ( $mycatk =~ /\.$catname/ ) { print " checked"; }
        print ">$catdesc";
        }

    print "\n<br><br><b>Return Link (URL):</b>link here when user clicks Return<br>\n";
    print "<input type=text size=50 name=\"retlink\" value=\"$retlink\"><br><br>\n";
    }

sub put_clropt  {
    local ($colorset, $id, $colors)=@_;
    print "\n<OPTION VALUE=\"$colors\"";
    if ($colorset eq $colors) {print " SELECTED";}
    print ">$id";
    }

sub error {
    local ($updact) = @_;
    print "content-type: text/html\n\n";
    print "<html><head><title>Permission Denied</title></head>\n";
    print "<body>\n";
    &put_banner; 
    print "<p><h1>Permission Denied</h1></p>\n";
    print "You do not have permission to $updact\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";
    exit;
    }
sub put_banner {
    # do nothing
    }
