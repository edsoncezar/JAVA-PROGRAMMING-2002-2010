#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
($data{username})=shift(@data)=~/=(.+)/;
($password)=shift(@data)=~/=(.+)/;
$encpass=crypt($password,$password);
$authline="$data{username}:$encpass";
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	if ($_=~/^$authline/)
	{
		chop;
		@user=split(":",$_);
		$flag=1;
		last;
	}
}
if (!$flag)
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">Wrong username or password</font></li>|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
$data{gender}=$user[3];
$data{group}=$user[2];
open (F,"<$mainpath/bases/users.cnt");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	($user,$data{count})=split(":",$_);
	last if ($user eq $data{username});
}
open (F,"<$mainpath/template/$data{group}.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
