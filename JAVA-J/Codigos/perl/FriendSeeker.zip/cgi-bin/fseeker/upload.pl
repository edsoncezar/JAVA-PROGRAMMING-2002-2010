#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
binmode STDIN;
read (STDIN,$buf,$ENV{CONTENT_LENGTH});
#while ($line=<STDIN>)
#{
#	$buf=$buf.$line;
#}


#pARSE dATA
($boundary)=$ENV{CONTENT_TYPE}=~/boundary="([^"]+)"/; #";
($boundary)=$ENV{CONTENT_TYPE}=~/boundary=(\S+)/ unless $boundary;
$boundary="--".$boundary;
@file=split("\r\n$boundary",$buf);
foreach (@file)
{
	s/\r\n\r\n/delimeter/;
}
($field,$name)=split("delimeter",$file[0]);
($field,$file)=split("delimeter",$file[1]);
#($ext)=$field=~/filename=".+\.(.+)"/;
#$ext=~tr/A-Z/a-z/;
if ($file=~/JFIF/)
{
	$ext="jpg";
}
elsif ($file=~/GIF/)
{
	$ext="gif";
}
else {push (@errors,qq|<li><font size="2" color="#85B5E3">Please, use JPG or GIF file</font></li>\n|);}
if (length($file)>$maxphotosize)
{
	$ext="";
	push (@errors,qq|<li><font size="2" color="#85B5E3">Filesize is too big. Please, use JPG of GIF file with filesize is not greater than 100 Kb</font></li>\n|);
}
&error if ($ext ne "gif" && $ext ne "jpg");
open (F,">$mainpath/photoes/$name.$ext");
binmode F;
print F $file;
close (F);
open (FL, "<$mainpath/template/sucupl.tpl");
@htmlpage=<FL>;
close (FL);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;

sub error
{
open (F,"<$mainpath/template/error.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}