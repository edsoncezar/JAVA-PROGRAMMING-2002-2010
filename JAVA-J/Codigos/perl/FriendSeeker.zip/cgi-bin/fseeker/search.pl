#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

$data{title}="Search Results";
if ($ENV{REQUEST_METHOD} eq "GET")
{
	@query=split("&",$ENV{QUERY_STRING});
	foreach(@query){/([^=]+)=(.*)/ && do {$data{$1}=$2;}}
	$method=$data{method};
	&$method;
}
sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;






sub initial
{
open (F,"<$mainpath/template/search.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub search
{
$title="<b>Search results</b>";
open (F,"<$mainpath/bases/$data{lookingforwho}.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
$sp=$data{sex};
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
if (!$data{agefrom}){$data{agefrom}=0;}
if (!$data{ageto}){$data{ageto}=100;}
@found=();
while($i<scalar(@entry))
{
	$flag=0;
	($garbage,$info)=split("#",$entry[$i]);
	@garbage=split(":",$garbage);
	@info=split(":",$info);
	if ($info[5]=~/$sp/ && $garbage[3] eq "yes")
	{
		if ($data{country} eq "notset" || $data{country}==$info[0])
		{
			if($data{lookingforwhat})
			{
				@lookforw=split(",",$data{lookingforwhat});
				foreach (@lookforw)
				{
					if ($info[5]=~/\b$_\b/)
					{
						$flag=1;
						last;
					}
				}
			}
			else {$flag++;}
			if($data{indoor})
			{
				@feti=split(",",$data{indoor});
				foreach (@feti)
				{
					if ($info[4]=~/\b$_\b/)
					{
						$flag++;
						last;
					}
				}
			}
			else {$flag++;}
			if($data{outdoor})
			{
				@feti=split(",",$data{outdoor});
				foreach (@feti)
				{
					if ($info[3]=~/\b$_\b/)
					{
						$flag++;
						last;
					}
				}
			}
			else {$flag++;}
			if ($flag==3){push(@found,$i);}
		}
	}
	$i++;
}
$title=qq|<b><font color="#A5A500">Search Results</b>|;
$destination="get_$data{lookingforwho}";
&$destination;
}

sub get_man
{
foreach $found(@found)
{
	($garbage,$info,$mpersonal)=split("#",$entry[$found]);
	@minfo=split(":",$mpersonal);
	if ($data{race} eq "any" || $data{race} eq $minfo[1])
	{
		if ($data{drink} eq "any" || $data{drink} eq $minfo[25])
		{
		if ($data{smoke} eq "any" || $data{smoke} eq $minfo[24])
		{
		if ($data{drug} eq "any" || $data{drug} eq $minfo[26])
		{
		if ($data{religion} eq "any" || $data{religion} eq $minfo[23])
		{
		if ($data{looks} eq "any" || $data{looks} eq $minfo[14])
		{
		chop($um=substr($minfo[0],0,3));
		chop($ud=substr($minfo[0],3,3));
		$uy=substr($minfo[0],6,2);
		$udate="$uy$um$ud";
		$age=$tdate-$udate;
		$age=substr($age,2,2);
		if ($age>=$data{agefrom} && $age<=$data{ageto})
		{
			if ($data{role} eq "any" || $data{role}==$minfo[20])
			{
				if ($data{trait})
				{
					@trait=split(",",$data{trait});
					foreach (@trait)
					{
						if ($minfo[15]=~/\b$_\b/)
						{
							push(@ffound,$found);
							last;
						}
					}
				}
				else {push(@ffound,$found);}
			}
		}
		}
		}
		}
		}
		}
	}
}
$data{items}=join(",",@ffound);
if (scalar(@ffound)>30)
{
	if ($data{startitem}>0)
	{
		$nstart=$data{startitem}-1;
		push(@bottom,qq|<td width="50%" align="left"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/prevad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
	if ($data{startitem}*30+30<scalar(@ffound))
	{
		$nstart=$data{startitem}+1;
		push(@bottom,qq|<td width="50%" align="right"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/nextad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
}
$start=$data{startitem}*30;
if ($start+30<scalar(@ffound))
{
	$end=$start+30;
}
else
{
	$end=scalar(@ffound);
}
$i=$start;
while ($i<$end)
{
	($garbage)=split("#",$entry[$ffound[$i]]);
	@garbage=split(":",$garbage);
	push(@result,qq|<li><a href="$cgi/browse.pl?method=get&username=$data{username}&group=$data{group}&title=ADView&lookingforwho=$data{lookingforwho}&items=$ffound[$i]">$garbage[1]</a></li>|);
	$i++;
}
push(@result,qq|<li><b>Nothing found</b></li>|) if (!@result);
open (F,"<$mainpath/template/preget.tpl");
$title="Search Results";
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub get_woman
{
foreach $found(@found)
{
	($garbage,$info,$mpersonal)=split("#",$entry[$found]);
	@minfo=split(":",$mpersonal);
	if ($data{race} eq "any" || $data{race}==$minfo[1])
	{
		if ($data{drink} eq "any" || $data{drink} eq $minfo[24])
		{
		if ($data{smoke} eq "any" || $data{smoke} eq $minfo[23])
		{
		if ($data{drug} eq "any" || $data{drug} eq $minfo[25])
		{
		if ($data{religion} eq "any" || $data{religion} eq $minfo[22])
		{
		if ($data{looks} eq "any" || $data{looks} eq $minfo[13])
		{
		chop($um=substr($minfo[0],0,3));
		chop($ud=substr($minfo[0],3,3));
		$uy=substr($minfo[0],6,2);
		$udate="$uy$um$ud";
		$age=$tdate-$udate;
		$age=substr($age,2,2);
		if ($age>=$data{agefrom} && $age<=$data{ageto})
		{
			if ($data{role} eq "any" || $data{role}==$minfo[19])
			{
				if ($data{trait})
				{
					@trait=split(",",$data{trait});
					foreach (@trait)
					{
						if ($minfo[14]=~/\b$_\b/)
						{
							push(@ffound,$found);
							last;
						}
					}
				}
				else {push(@ffound,$found);}
			}
		}
		}
		}
		}
		}
		}
	}
}
$data{items}=join(",",@ffound);
if (scalar(@ffound)>30)
{
	if ($data{startitem}>0)
	{
		$nstart=$data{startitem}-1;
		push(@bottom,qq|<td width="50%" align="left"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/prevad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
	if ($data{startitem}*30+30<scalar(@ffound))
	{
		$nstart=$data{startitem}+1;
		push(@bottom,qq|<td width="50%" align="right"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/nextad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
}
$start=$data{startitem}*30;
if ($start+30<scalar(@ffound))
{
	$end=$start+30;
}
else
{
	$end=scalar(@ffound);
}
$i=$start;
while ($i<$end)
{
	($garbage)=split("#",$entry[$ffound[$i]]);
	@garbage=split(":",$garbage);
	push(@result,qq|<li><a href="$cgi/browse.pl?method=get&username=$data{username}&group=$data{group}&title=ADView&lookingforwho=$data{lookingforwho}&items=$ffound[$i]">$garbage[1]</a></li>|);
	$i++;
}
push(@result,qq|<li><b>Nothing found</b></li>|) if (!@result);
open (F,"<$mainpath/template/preget.tpl");
$title="Search Results";
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

