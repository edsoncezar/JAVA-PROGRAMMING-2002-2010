#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

$data{username}=$ENV{QUERY_STRING};
if (!$data{username})
{
	print "HTTP/1.0 302 Found\n" if ($sysid eq "Windows");
	print "Location: $url/index.html\n\n";
	exit;
}
unless ($ENV{HTTP_REFERER}=~/^$cgi/)
{
	print "HTTP/1.0 302 Found\n" if ($sysid eq "Windows");
	print "Location: $url/index.html\n\n";
	exit;
}
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	if ($_=~/^$data{username}:/)
	{
		$flag=1;
		@user=split(":",$_);
		last;
	}
}
if (!$flag)
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">Wrong username or password</font></li>|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
$data{gender}=$user[3];
$data{group}=$user[2];
open (F,"<$mainpath/bases/users.cnt");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	($user,$data{count})=split(":",$_);
	last if ($user eq $data{username});
}
open (F,"<$mainpath/template/$data{group}.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
