#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}


if ($ENV{REQUEST_METHOD} eq "GET")
{
	@query=split("&",$ENV{QUERY_STRING});
	foreach(@query){/([^=]+)=(.*)/ && do {$data{$1}=$2;$data{$1}=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;}}
	$method=$data{method};
	&$method;
}
sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;

sub initial
{
open (F,"<$mainpath/hotlist/$data{username}.lst");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	push (@result,qq|<option value="$_">$_ </option>|);
}
open (F,"<$mainpath/template/hotlist.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;

}

sub adduser
{
if ($data{group} ne "surfer")
{
	open (F,">>$mainpath/hotlist/$data{username}.lst");
	flock (F, $LOCK_EX);
	print F "$data{dataline}\n";
	flock (F, $LOCK_UN);
	close (F);
	$title="ADD USER TO HOTLIST";
	push (@status,qq|<li><font size="2" color="#85B5E3">User was added successfully to your HotList!</font></li>\n|);
	open (F,"<$mainpath/template/success.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
push (@errors,qq|<li><font size="2" color="#85B5E3">You are not registered user and have not hotlist</font></li>\n|);
open (F,"<$mainpath/template/error.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub email
{
if ($data{receiver} eq "nonemail" && !$data{recepient})
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">Undefined recepient</font></li>\n|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
$data{receiver}=$data{recepient} if ($data{receiver} eq "nonemail");
if ($data{group} eq "surfer")
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">You are not registered user and cannot send email</font></li>\n|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
open (F,"<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	($username,$password,$email)=split(":",$_);
	if ($username eq $data{receiver})
	{
		srand;
		$mailid=int(rand 999999);
		open (F,">>$mainpath/mailbox/$username");
		flock (F, $LOCK_EX);
		print F "$mailid\n";
		print F "$data{username}\n";
		print F "$data{subject}\n";
		$ltime=scalar localtime;
		print F "$ltime\n";
		print F "$data{body}\n";
		print F "-----ENDLETTER-----\n";
		flock (F, $LOCK_UN);
		close (F);
		$title="SEND MAIL";
		push (@status,qq|<li><font size="2" color="#85B5E3">Your email was sent successfully!</font></li>\n|);
		open (F,"<$mainpath/template/success.tpl");
		@html=<F>;
		close(F);
		$html=join("\n",@html);
		print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
		print "content-type: text/html\n\n";
		eval $html;
		exit;
	}
}
push (@errors,qq|<li><font size="2" color="#85B5E3">Unknown recipient</font></li>\n|);
open (F,"<$mainpath/template/error.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub removeuser
{
open (F,"+<$mainpath/hotlist/$data{username}.lst");
flock(F,$LOCK_EX);
@users=<F>;
foreach(@users)
{
	chop;
	next if ($_ eq $data{receiver});
	push (@nusers,"$_\n");
}
truncate(F,0);
seek(F,0,0);
print F @nusers;
flock (F, $LOCK_UN);
close(F);
&initial;
}