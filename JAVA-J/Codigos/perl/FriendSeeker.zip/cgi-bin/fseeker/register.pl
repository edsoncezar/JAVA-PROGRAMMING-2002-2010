#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
($destination)=shift(@data)=~/=(.+)/;
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}


&$destination;

sub stage0
{
if ($data{sex} eq "none")
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre gender (male or female)</font></li>\n|);
}
if (!$data{loginname} || $data{loginname}=~/\W+/)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, use correct login name (use only letters or digits)</font></li>\n|);
}
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/^$data{loginname}:/)
	{
		$flag=1;
		push (@errors,qq|<li><font size="2" color="#85B5E3">User <b>$data{loginname}</b> is already exist in database. Please, choose other login name.</font></li>\n|);
		last;
	}
}
open (F,"<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/:$data{email}\n/)
	{
		$flag=1;
		push (@errors,qq|<li><font size="2" color="#85B5E3">Too many acounts: to increase the quality of this site we only allow one ad per email adress</font></li>\n|);
		last;
	}
}
unless ($data{email}=~/^\w+@\w+\.\w+/)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, use correct email adress.</font></li>\n|);
}
if ($flag){&error;}
$comment="Step 1";
$stage=$data{sex}."1";
$dataline="$data{loginname}:$data{email}:$data{sex}";
open (F,"<$mainpath/template/signup1.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub man1
{
if ($data{country} eq "notset")
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre country</font></li>\n|);
}
if (!$data{province} && $data{state} eq "0")
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre state or province</font></li>\n|);
}
if (!$data{city} || $data{city}=~/W+/)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre city</font></li>\n|);
}
@temp=split(",",$data{outdoor});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 outdoor activities</font></li>\n|);
}
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one outdoor activity</font></li>\n|);
}
@temp=split(",",$data{indoor});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 indoor activities</font></li>\n|);
}
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one indoor activity</font></li>\n|);
}
@temp=split(",",$data{lookingforwho});
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one gender you look</font></li>\n|);
}
@temp=split(",",$data{lookingforwhat});
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one reason to meet somebody</font></li>\n|);
}
if ($flag){&error;}
$data{state}=$data{province} if ($data{state} eq "0");
$comment="Step 2";
$stage="man2";
$dataline="$data{dataline}#$data{country}:$data{state}:$data{city}:$data{outdoor}:$data{indoor}:$data{lookingforwho}:$data{lookingforwhat}";
open (F,"<$mainpath/template/signup2m.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub man2
{
if (!$data{bday_day})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill your birthday date field</font></li>\n|);
}
if (!$data{bday_year})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill your birthday year field</font></li>\n|);
}
$data{bday_day}="0$data{bday_day}" if (length($data{bday_day})==1);
$udate="19$data{bday_year}$data{bday_month}$data{bday_day}";
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
$check=$tdate-$udate;
if ($check<180000)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">You must be at least 18 years old</font></li>\n|);
}
if (!$data{decorations})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one decoration</font></li>\n|);
}
if (!$data{trait})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one trait</font></li>\n|);
}
@temp=split(",",$data{trait});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 traits</font></li>\n|);
}
if ($flag){&error;}
$comment="Step 3";
$stage="man3";
$dataline="$data{dataline}#$data{bday_month}.$data{bday_day}.$data{bday_year}:$data{race}:$data{marital}:$data{height}:$data{body}:$data{haircolor}:$data{hair_length}:$data{facial_hair}:$data{body_hair}:$data{publichair}:$data{eye_color}:$data{eyewear}:$data{decorations}:$data{endowment}:$data{looks}:$data{trait}:$data{sex_orient}";
open (F,"<$mainpath/template/signup3.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub man3
{
if (!$data{occupation})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill occupation field</font></li>\n|);
}
if ($flag){&error;}
$comment="Final Step";
$stage="final";
$dataline="$data{dataline}:$data{children}:$data{sexuality}:$data{howoften}:$data{role}:$data{safesex}:$data{howinbed}:$data{religion}:$data{smoke}:$data{drink}:$data{drugs}:$data{education}:$data{occupation}:$data{position}:$data{dress}";
open (F,"<$mainpath/template/signup4.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub woman1
{
if ($data{country} eq "notset")
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre country</font></li>\n|);
}
if (!$data{province} && $data{state} eq "0")
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre state or province</font></li>\n|);
}
if (!$data{city} || $data{city}=~/W+/)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, choose youre city</font></li>\n|);
}
@temp=split(",",$data{outdoor});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 outdoor activities</font></li>\n|);
}
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one outdoor activity</font></li>\n|);
}
@temp=split(",",$data{indoor});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 indoor activities</font></li>\n|);
}
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one indoor activity</font></li>\n|);
}
@temp=split(",",$data{lookingforwho});
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one gender you look</font></li>\n|);
}
@temp=split(",",$data{lookingforwhat});
if (scalar(@temp)==0)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one reason to meet somebody</font></li>\n|);
}
if ($flag){&error;}
$data{state}=$data{province} if ($data{state} eq "0");
$comment="Step 2";
$stage="woman2";
$dataline="$data{dataline}#$data{country}:$data{state}:$data{city}:$data{outdoor}:$data{indoor}:$data{lookingforwho}:$data{lookingforwhat}";
open (F,"<$mainpath/template/signup2w.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub woman2
{
if (!$data{bday_day})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill your birthday date field</font></li>\n|);
}
if (!$data{bday_year})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill your birthday year field</font></li>\n|);
}
$data{bday_day}="0$data{bday_day}" if (length($data{bday_day})==1);
$udate="19$data{bday_year}$data{bday_month}$data{bday_day}";
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
$check=$tdate-$udate;
if ($check<180000)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">You must be at least 18 years old</font></li>\n|);
}
if (!$data{decorations})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one decoration</font></li>\n|);
}
if (!$data{trait})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick at least one trait</font></li>\n|);
}
@temp=split(",",$data{trait});
if (scalar(@temp)>5)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, pick not more than 5 traits</font></li>\n|);
}
if ($flag){&error;}
$comment="Step 3";
$stage="woman3";
$dataline="$data{dataline}#$data{bday_month}.$data{bday_day}.$data{bday_year}:$data{race}:$data{marital}:$data{height}:$data{body}:$data{haircolor}:$data{hair_length}:$data{body_hair}:$data{publichair}:$data{eye_color}:$data{eyewear}:$data{decorations}:$data{brasize}:$data{looks}:$data{trait}:$data{sex_orient}";
open (F,"<$mainpath/template/signup3.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub woman3
{
if (!$data{occupation} || $data{occupation}=~/W+/)
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill occupation field</font></li>\n|);
}
if ($flag){&error;}
$comment="Final Step";
$stage="final";
$dataline="$data{dataline}:$data{children}:$data{sexuality}:$data{howoften}:$data{role}:$data{safesex}:$data{howinbed}:$data{religion}:$data{smoke}:$data{drink}:$data{drugs}:$data{education}:$data{occupation}:$data{position}:$data{dress}";
open (F,"<$mainpath/template/signup4.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub final
{
if (!$data{title})
{
	$flag=1;
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, fill title field</font></li>\n|);
}
if ($flag){&error;}
$data{profile}=~s/\r\n/ /g;
$data{profilewant}=~s/\r\n/ /g;
$data{hobbys}=~s/\r\n/ /g;
@dataline=split("#",$data{dataline});
($username,$useremail,$usergender)=split(":",shift(@dataline));
@grbg=split(":",$dataline[0]);
$grbg=pop(@grbg);
$dataline=join("#",@dataline);
srand;
$userpass=int(rand 99999999);
$encpass=crypt($userpass,$userpass);
if ($group eq "platinum")
{
	open (F,">>$mainpath/platinum/.htpasswd");
	print F "$username:$encpass\n";
	close(F);
}
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$montha=$calendar{$montha}+1;
if ($montha==13)
{
	$montha="01";
	$year=$year+1;
}
$montha="0$montha" if (length($montha)==1);
$tdate="$year$montha$datea";
open (F,">>$mainpath/bases/users.db");
flock (F, $LOCK_EX);
print F "$username:$encpass:silver:$usergender:$tdate\n";
flock (F, $LOCK_UN);
close(F);
open (F,">>$mainpath/bases/users.cnt");
flock (F, $LOCK_EX);
print F "$username:0\n";
flock (F, $LOCK_UN);
close(F);
open (F,">>$mainpath/backup/upf.sct");
flock (F, $LOCK_EX);
print F "$username:$userpass:$useremail\n";
flock (F, $LOCK_UN);
close(F);
open (F,">>$mainpath/bases/$usergender.db");
flock (F, $LOCK_EX);
if ($grbg=~/4/ || $grbg=~/3/)
{
	print F "$username:$data{title}:$useremail:no#$dataline#$data{profile}#$data{profilewant}#$data{hobbys}\n";
}
else
{
	print F "$username:$data{title}:$useremail:yes#$dataline#$data{profile}#$data{profilewant}#$data{hobbys}\n";
}
flock (F, $LOCK_UN);
close(F);
open (MAIL,"|$mailprog");
print MAIL "To: $useremail\n";
print MAIL "From: $ownemail\n";
print MAIL "Subject: Registration Information\n\n";
$ltime=scalar localtime;
print MAIL "Received from FriendSeeker $ltime\n\n";
print MAIL "-" x 75 . "\n\n";
print MAIL "Login: $username\n";
print MAIL "Password: $userpass\n";
close (MAIL);
open (F,"<$mainpath/template/final.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub error
{
open (F,"<$mainpath/template/error.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}