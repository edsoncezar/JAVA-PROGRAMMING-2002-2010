#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

if ($ENV{REQUEST_METHOD} eq "GET")
{
	@query=split("&",$ENV{QUERY_STRING});
	foreach(@query){/([^=]+)=(.*)/ && do {$data{$1}=$2;}}
	$method=$data{method};
	&$method;
}
sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;

sub initial
{
open (F,"<$mainpath/template/modify.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub delpic
{
unlink ("$mainpath/photoes/$data{username}.jpg") if (-e "$mainpath/photoes/$data{username}.jpg");
unlink ("$mainpath/photoes/$data{username}.gif") if (-e "$mainpath/photoes/$data{username}.gif");
&initial;
}

sub delacc
{
open (F,"+<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$group,$gender,$exp)=split(":",$_);
		next;
	}
	push(@nusers,$_);
}
truncate(F,0);
seek(F,0,0);
print F @nusers;
flock (F, $LOCK_UN);
close(F);
open (F,"+<$mainpath/bases/$gender.db");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		next;
	}
	push(@gusers,$_);
}
truncate(F,0);
seek(F,0,0);
print F @gusers;
flock (F, $LOCK_UN);
close(F);
open (F,"+<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		next;
	}
	push(@busers,$_);
}
truncate(F,0);
seek(F,0,0);
print F @busers;
flock (F, $LOCK_UN);
close(F);
open (F,"+<$mainpath/bases/users.cnt");
flock(F,$LOCK_EX);
@users=<F>;
close(F);
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		next;
	}
	push(@cusers,$_);
}
truncate(F,0);
seek(F,0,0);
print F @cusers;
flock (F, $LOCK_UN);
close(F);
unlink ("$mainpath/mailbox/$data{username}");
unlink ("$mainpath/hotlist/$data{username}.lst");
print "HTTP/1.0 302 Found\n" if ($sysid eq "Windows");
print "Location: $url/index.html\n\n";
exit;
}

sub chpass
{
$encpass=crypt($data{password},$data{password});
open (F,"+<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$group,$gender,$exp)=split(":",$_);
		$_="$name:$encpass:$group:$gender:$exp";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @users;
flock (F, $LOCK_UN);
close(F);
open (F,"+<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$email)=split(":",$_);
		$_="$name:$data{password}:$email";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @users;
flock (F, $LOCK_UN);
close(F);
&initial;
}

sub chmail
{
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$group,$gender,$exp)=split(":",$_);
		last;
	}
}
open (F,"+<$mainpath/bases/$gender.db");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		@info=split("#",$_);
		@usrdat=split(":",$info[0]);
		$usrdat[2]=$data{email};
		$info[0]=join(":",@usrdat);
		$_=join("#",@info);
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @users;
flock (F, $LOCK_UN);
close(F);
open (F,"+<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$email)=split(":",$_);
		$_="$name:$pass:$data{email}\n";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @users;
flock (F, $LOCK_UN);
close(F);
&initial;
}

sub chprofile
{
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$group,$gender,$exp)=split(":",$_);
		last;
	}
}
open (F,"<$mainpath/bases/$gender.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		@info=split("#",$_);
		@usrdat=split(":",$info[0]);
		last;
	}
}
$comment="Step 1";
$stage=$gender."1";
$dataline="$usrdat[0]:$usrdat[2]:$gender";
$group=$data{group};
open (F,"<$mainpath/template/chpf1.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}
