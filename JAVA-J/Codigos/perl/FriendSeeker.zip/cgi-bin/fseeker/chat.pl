#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}
($week,$month,$date,$time,$year)=split(" ",scalar localtime);
$date="$week, $month $date, $year at $time";
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		$value =~ s/<!--(.|\n)*-->//g;
		$value =~ s/<([^>]|\n)*>//g if ($allow_html != 1);
		$FORM{$field}=$value;
	}
}
open (F,">$mainpath/temp/$FORM{'username'}");
print F 1;
close(F);
open (CHAT,"<$mainpath/bases/chat");
@messages=<CHAT>;
close(CHAT);
print "Content-type: text/html\n\n";
print "<html><head><meta HTTP-EQUIV=\"Refresh\" content=\"$refresh;url=$cgi/chat.pl?username=$FORM{username}\"></head><body bgcolor=black text=\"#A5A500\"><font face=\"Arial\">\n";
@messages=reverse(@messages);
$i=0;
while ($i<$numofmes)
{
	print "$messages[$i]\n";
	$i++;
}
print "</font></body></html>";
