#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}

$destination=$data{method};
&$destination;

sub password
{
unless ($data{email}=~/^\w+@\w+\.\w+/)
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">Please, use correct email adress.</font></li>\n|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
open (F,"<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@users)
{
	chop;
	($username,$password,$email)=split(":",$_);
	if ($email eq $data{email})
	{
		open (MAIL,"|$mailprog");
		print MAIL "To: $email\n";
		print MAIL "From: $ownemail\n";
		print MAIL "Subject: Registration Information\n\n";
		$ltime=scalar localtime;
		print MAIL "Received from FriendSeeker $ltime\n\n";
		print MAIL "-" x 75 . "\n\n";
		print MAIL "Login: $username\n";
		print MAIL "Password: $password\n";
		close (MAIL);
		print "HTTP/1.0 302 Found\n" if ($sysid eq "Windows");
		print "Location: $url/login.html\n\n";
		exit;
	}
}
push (@errors,qq|<li><font size="2" color="#85B5E3">Your email adress is not found in our database.</font></li>\n|);
open (F,"<$mainpath/template/error.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub email
{
if ($data{group} eq "surfer")
{
	push (@errors,qq|<li><font size="2" color="#85B5E3">You are not registered user and cannot send email</font></li>\n|);
	open (F,"<$mainpath/template/error.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
srand;
$mailid=int(rand 999999);
open (F,">>$mainpath/mailbox/$data{receiver}");
flock (F, $LOCK_EX);
print F "$mailid\n";
print F "$data{username}\n";
print F "$data{subject}\n";
$ltime=scalar localtime;
print F "$ltime\n";
print F "$data{body}\n";
print F "-----ENDLETTER-----\n";
flock (F, $LOCK_UN);
close (F);
$title="SEND MAIL";
push (@status,qq|<li><font size="2" color="#85B5E3">Your email was sent successfully!</font></li>\n|);
open (F,"<$mainpath/template/success.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}
