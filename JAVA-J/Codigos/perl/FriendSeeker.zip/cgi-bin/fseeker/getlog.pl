#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

@data=split("&",$ENV{QUERY_STRING});
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
open (F,"<$mainpath/log/$data{file}");
flock(F,$LOCK_EX);
@log=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@log)
{
	chop;
	($usrnm,$cnter)=split(":",$_);
	push (@found,qq~<tr><td width="20%"></td><td width="40%">$usrnm</td><td width=40%><font color="#A5A500" size="2"><b>$cnter</b></font></a></td></tr>\n~);
}
unshift (@found,qq~<tr><td width="20%"></td><td width="40%"><font color="#85B5E3"><b>USERNAME OR IP</b></font></td><td width=40%><font color="#85B5E3"><b>VIEWED ADS</b></font></a></td></tr>\n~);
open (F,"<$mainpath/template/log.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
