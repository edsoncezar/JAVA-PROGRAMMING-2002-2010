#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;

sub man
{
open (F,"<$mainpath/template/admin.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub mail
{
open (F,"<$mainpath/template/maillist.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub gen
{
open (F,"<$mainpath/template/genset.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub genset
{
open (F, ">fseeker.cfg");
print F qq~######################################################################
# FriendSeeker v1.0 (Released 06.19.99)		                     #
#--------------------------------------------------------------------#
# Copyright 1999 Michael "TRXX" Sissine                              #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx\@trxx.co.uk                                                    #
######################################################################
\$mainpath="$data{mainpath}";
\$sysid="$data{sysid}";
%calendar=('Jan','01','Feb','02','Mar','03','Apr','04','May','05','Jun','06','Jul','07','Aug','08','Sep','09','Oct','10','Nov','11','Dec','12');
\$mailprog="$data{mailprog}";
\$ownemail='$data{ownemail}';
\$cgi="$data{cgi}";
\$url="$data{url}";
\$enablechat=$data{enablechat};
\$numofmes=$data{numofmes};
\$maxmes=$data{maxmes};
\$refresh=$data{refresh};
\$maxphotosize=$data{maxphotosize};
\$LOCK_SH=1;
\$LOCK_EX=2;
\$LOCK_NB=4;
\$LOCK_UN=8;
~;
close (F);
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}
open (F,"<$mainpath/template/genset.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub log
{
opendir(Dir,"$mainpath/log/");
@files=readdir(Dir);
closedir(Dir);
shift(@files);
shift(@files);
foreach(@files)
{
	if ($_=~/log$/)
	{
		$year=substr($_,0,4);
		$month=substr($_,4,2);
		$date=substr($_,6,2);
		push (@found,qq~<tr><td width="20%"></td><td width="40%">$month.$date.$year</td><td width=40%><a href="$cgi/getlog.pl?username=$data{username}&group=$data{group}&file=$_"><font color="#A5A500" size="2"><b>Check Log</b></font></a></td></tr>\n~);
	}
}
push (@found,qq~<tr><td width=20%></td><td width="40%">No log files</td><td width=40%></td></tr>\n~) if (scalar(@found)==0);
open (F,"<$mainpath/template/log.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}


sub delfriend
{
open (F,"+<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
foreach (@users)
{
	if ($_=~/^$data{name}:/)
	{
		next;
	}
	push(@nusers,$_);
}
truncate(F,0);
seek(F,0,0);
print F @nusers;
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/template/admin.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub chpass
{
$encpass=crypt($data{password},$data{password});
open (F,"+<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
close(F);
foreach (@users)
{
	if ($_=~/^$data{username}:/)
	{
		($name,$pass,$group,$gender,$exp)=split(":",$_);
		$_="$name:$encpass:$group:$gender:$exp";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @users;
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/template/admin.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub addfriend
{
$encpass=crypt($data{pass},$data{pass});
open (F,"<$mainpath/bases/users.db");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close(F);
foreach (@users)
{
	if ($_=~/^$data{name}:/)
	{
		push (@errors,qq|<li><font size="2" color="#85B5E3">User <b>$data{name}</b> is already exist in database. Please, choose other login name.</font></li>\n|);
		open (F,"<$mainpath/template/error.tpl");
		@html=<F>;
		close(F);
		$html=join("\n",@html);
		print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
		print "content-type: text/html\n\n";
		eval $html;
		exit;
	}
}
open (F,">>$mainpath/bases/users.db");
flock(F,$LOCK_EX);
print F "$data{name}:$encpass:friend:0:99999999\n";
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/template/admin.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub chlimit
{
open (F,">$mainpath/log/limit");
flock(F,$LOCK_EX);
print F "$data{silver}\n$data{surfer}\n";
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/template/admin.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub maillist
{
open (F,"<$mainpath/backup/upf.sct");
flock(F,$LOCK_EX);
@emails=<F>;
flock(F,$LOCK_UN);
close (F);
$count=0;
if (@emails>0)
{
	foreach(@emails)
	{
		chop;
		($nm,$ps,$em)=split(":",$_);
		$count++;
		open (MAIL,"|$mailprog");
		print MAIL "To: $em\n";
		print MAIL "From: $ownemail\n";
		print MAIL "Subject: $data{subject}\n\n";
		print MAIL "$data{body}\n\n";
		close (MAIL);
		}
	}
open (F,"<$mainpath/template/mailstat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
