#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

@country=("Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antarctica","Antigua and Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia and Herzegowina","Botswana","Bouvet Island","Brazil","British Indian Ocean Territory","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","China","Christmas Island","Cocos (Keeling) Islands","Colombia","Comoros","Congo","Cook Islands","Costa Rica","Cote D'Ivoire","Croatia","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","France, Metropolitan","French Guiana","French Polynesia","French Southern Territories","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hong Kong SAR PRC","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","D.P.R. Korea","Korea","Kuwait","Lao People's Republic","Latvia","Lebanon","Lesotho","Liberia","Libyan Arab Jamahiriya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","Northern Mariana Islands","Norway","Oman","Pakistan","Palau","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Pitcairn","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russian Federation","Saint Kitts and Nevis","Saint Lucia","Saint Vincent and the Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","Spain","Sri Lanka","St Helena","St Pierre and Miquelon","Sudan","Suriname","Svalbard and Jan Mayen Islands","Swaziland","Sweden","Switzerland","Syrian Arab Republic","Taiwan Region","Tajikistan","Tanzania","Thailand","Togo","Tokelau","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan","Turks and Caicos Islands","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan","Vanuatu","Venezuela","Viet Nam","Virgin Islands (British)","Virgin Islands (US)","Wallis and Futuna Islands","Western Sahara","Yemen","Zaire","Zambia","Zimbabwe");
@genders=("none","woman","none","none","none","none","man");
@race=("Prefer not to say","African Descent / Black","American Indian / Native American","Arabic","Asian","Caucasian / White","Eastern Indian","Eskimo","Hispanic / Latino","Mediterranean","Polynesian / Micronesian / Melanesian / Filipino");
@marital=("Prefer not to say","Single","Married","Divorced","Separated","Currently in a relationship");
@height=("Prefer not to say","Under 5 ft. (under 152cm)","5 ft. - 5 ft. 2 in. (152cm - 158cm)","5 ft. 2.1 in. - 5 ft. 4 in. (159cm - 162.5cm)","5 ft. 4.1 in. - 5 ft. 6 in. (162.5cm - 167.5cm)","5 ft. 6.1 in. - 5 ft. 8 in. (168cm - 172.5cm)","5 ft. 8.1 in. - 5 ft. 10 in. (173cm - 177.5cm)","5 ft. 10.1 in. - 6 ft. (178cm - 182.5cm)","6 ft. - 6 ft. 2 in. (183cm - 188cm)","6 ft. 2.1 in. - 6 ft. 4 in. (189cm - 193cm)","Over 6 ft. 4 in. (over 193cm)");
@body=("Prefer not to say","Slim","Thin and round","Average","Hard/musculair","Round and soft","Defined","A little extra","Large");
@haircolor=("Prefer not to say","Black","Brown","Blonde","Red","Grey","Auburn");
@hairlength=("Prefer not to say","Bald","Bald on top","Thinning","Shaved","Short straight hair","Short curly/wavy hair","Medium straight hair","Medium curly/wavy hair","Long straight hair","Long curly/wavy hair","Afro","Dreadlocks");
@facialhair=("Prefer not to say","None","Mustache","Goatee","Sideburns","Beard");
@bodyhair=("Prefer not to say","Average","Hairy","Shaved","Little","None");
@mpublichair=("Prefer not to say","Average","Hairy","Shaved","Little","None");
@eyecolor=("Prefer not to say","Black","Brown","Blue","Hazel","Green","Gray","Other");
@eyewear=("Prefer not to say","Glasses","Contacts","Either","None");
@decorations=("","Earrings","Body Piercings","Tattoos","Other","None","Prefer not to say");
@endowment=("Prefer not to say","Short / Thick","Short / Thin","Average","Long / Thick","Long / Thin","Very Long / Thick");
@looks=("Prefer not to say","Very good looks","Above average looks","Average looks","Less then average looks");
@traits=("","Cautios","Romantic","Optimistic","Cheerful","Realistic","Daring","Wild","Quiet","Serene","Naive","Sheltered","Bleak","Moody","Intelligent");
@sexorient=("Prefer not to say","Straight","Gay Only","Bisexual","Curious","Transgender","Open to anything");
@wpublichair=("Prefer not to say","Average","Trimmed","Shaved","Brushy","None");
@brasize=("","Prefer not to say","32","34","36","38","40","42","44","44+","Prefer not to say","A","B","C","D","DD","DD+");
@children=("Prefer not to say","I have no children","I have 1-2 children","I have 3-4 children","I have 5 or more","Im expecting a child soon","I dont like children","I want children in the future","I have children but they live on their own");
@sexuality=("Prefer not to say","Most important thing in my life","It is very important","Its important but there are other things in life","Many other things are more important to me","Not important");
@howoften=("Prefer not to say","All the time","Several times a day","Atleast once a day","5 or more times a week","A few times a week","About once a week","A few times a month","Once a month or less");
@role=("Prefer not to say","Dominant (Master)","Submissive","Switch","Does not apply");
@safesex=("Prefer not to say","Yes","Sometimes","No","Always");
@howinbed=("Prefer not to say","I always take the initiative","Average","I like to be lead");
@religion=("Prefer not to say","Not Religios","Christian","Catholic","Protestant","Jewish","Hindu","Islamic","Muslim","Buddhist","Atheist","New age","Other");
@smoke=("Prefer not to say","I dont smoke","Im a light smoker","Im an ocasional smoker","Im a heavy smoker","I smoke Cigar/pipe");
@drink=("Prefer not to say","I dont drink","Im a ocasional drinker","Im a social drinker","Im a heavy drinker");
@drugs=("Prefer not to say","I dont use any drugs","I occasionaly do drugs","I frequently use drugs");
@education=("Prefer not to say","Have not finished high school yet","High School","A technical degree or training/ 2 year degree","College freshman","College sophomore","College junior","College senior","4 year degree","Craftsman","Masters degree","Doctoral degree","Professional degree");
@position=("Prefer not to say","I don't have many of the things I really want","I'm just about where I want to be","I want a bit more, but I have everything I need","I have plans to take more control of my life","I will ask my mother");
@dress=("Prefer not to say","I like to get dressed up","I dress casual","I dress for the occasion","What ever is clean","Tuxedo","Jeans / T-shirts","Grunge");
@lookingforwho=("","Woman","Couple","Gay Couple","Lesbian Couple","Group","Man");
@lookingforwhat=("","Online relationship (Email/chat)","Phone fantasies","Performing only (little/no contact)","Watching only (little/no contact)","Active participation","Short therm relationship","Long therm relationship","Marriage","Erotic email exchange");
@outdoor=("","Sport/Athletics","Travel/Sightseeing","Automobiles/Motorcycles","Camping/Fishing/Hiking","Biking","Photography","Picnics in the park","Swimming/Skiing/WSurfing","Snow Skiing","Golf","Tennis/Raquetball","Tan maintenance","Girl/Boy watching","Horseback riding","Sailing","Scuba diving");
@indoor=("","Programming/Computing","Dancing","Theater/Movies","Listening to recordings","Bowling","Avid book reading","Cooking/Culinary arts","Watching TV","Weight lifting","Photography","Wine tastings","Video games","Hot tubbing","Bar hopping","Model railroading");


if ($ENV{REQUEST_METHOD} eq "GET")
{
	@query=split("&",$ENV{QUERY_STRING});
	foreach(@query){/([^=]+)=(.*)/ && do {$data{$1}=$2;$data{$1}=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;}}
	$method=$data{method};
	&$method;
}
sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;

sub initial
{
open (F,"<$mainpath/template/browse.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub browse_country
{
open (F,"<$mainpath/bases/$data{lookingforwho}.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
$sp=$data{sex};
@found=();
while($i<scalar(@entry))
{
	($garbage,$info)=split("#",$entry[$i]);
	@garbage=split(":",$garbage);
	@info=split(":",$info);
	if ($info[5]=~/$sp/ && $garbage[3] eq "yes")
	{
		if ($found[$info[0]] ne ""){$found[$info[0]]="$found[$info[0]],$i";}
		else {$found[$info[0]]=$i;}
	}
	$i++;
}
$i=0;
while($i<scalar(@found))
{
	if ($found[$i] ne "")
	{
		push(@result,qq|<li><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$country[$i]&lookingforwho=$data{lookingforwho}&items=$found[$i]">$country[$i]</a></li>|);
	}
	$i++;
}
push(@result,qq|<li><font color="#85B5E3" size="2">Nothing found</font></li>|) if (!@result);
open (F,"<$mainpath/template/preget.tpl");
$title="$data{lookingforwho} looking for a $genders[$data{sex}]";
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub browse_age
{
open (F,"<$mainpath/bases/$data{lookingforwho}.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
$sp=$data{sex};
@found=();
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
while($i<scalar(@entry))
{
	($garbage,$info,$source)=split("#",$entry[$i]);
	@garbage=split(":",$garbage);
	@info=split(":",$info);
	if ($info[5]=~/$sp/ && $garbage[3] eq "yes")
	{
		@source=split(":",$source);
		chop($um=substr($source[0],0,3));
		chop($ud=substr($source[0],3,3));
		$uy=substr($source[0],6,2);
		$udate="$uy$um$ud";
		$age=$tdate-$udate;
		$age=substr($age,2,2);
		if ($found[$age] ne ""){$found[$age]="$found[$age],$i";}
		else {$found[$age]=$i;}
	}
	$i++;
}
$i=0;
while($i<scalar(@found))
{
	if ($found[$i] ne "")
	{
		push(@result,qq|<li><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$i years&lookingforwho=$data{lookingforwho}&items=$found[$i]">$i Years Old</a></li>|);
	}
	$i++;
}
push(@result,qq|<li><font color="#85B5E3" size="2">Nothing found</font></li>|) if (!@result);
open (F,"<$mainpath/template/preget.tpl");
$title="$data{lookingforwho} looking for a $genders[$data{sex}]";
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub browse_photo
{
open (F,"<$mainpath/bases/$data{lookingforwho}.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
$sp=$data{sex};
@found=();
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
while($i<scalar(@entry))
{
	($garbage,$info)=split("#",$entry[$i]);
	@garbage=split(":",$garbage);
	@info=split(":",$info);
	if ($info[5]=~/$sp/ && $garbage[3] eq "yes")
	{
		@garbage=split(":",$garbage);
		if (-e "$mainpath/photoes/$garbage[0].jpg" || -e "$mainpath/photoes/$garbage[0].gif"){push(@items,$i);}
	}
	$i++;
}
$data{items}=join(",",@items);
&preget if (@items);
push(@result,qq|<li><font color="#85B5E3" size="2">Nothing found</font></li>|);
open (F,"<$mainpath/template/preget.tpl");
$title="$data{lookingforwho} looking for a $genders[$data{sex}]";
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub preget
{
open (F,"<$mainpath/bases/$data{lookingforwho}.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
@items=split(",",$data{items});
if (scalar(@items)>30)
{
	if ($data{startitem}>0)
	{
		$nstart=$data{startitem}-1;
		push(@bottom,qq|<td width="50%" align="left"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/prevad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
	if ($data{startitem}*30+30<scalar(@items))
	{
		$nstart=$data{startitem}+1;
		push(@bottom,qq|<td width="50%" align="right"><a href="$cgi/browse.pl?method=preget&username=$data{username}&group=$data{group}&title=$data{title}&lookingforwho=$data{lookingforwho}&items=$data{items}&startitem=$nstart"><img src="$url/images/nextad.gif" border="0"></a></td>|);
	}
	else
	{
		push(@bottom,qq|<td width="50%"></a></td>|);
	}
}
$start=$data{startitem}*30;
if ($start+30<scalar(@items))
{
	$end=$start+30;
}
else
{
	$end=scalar(@items);
}
$i=$start;
while ($i<$end)
{
	($garbage)=split("#",$entry[$items[$i]]);
	@garbage=split(":",$garbage);
	push(@result,qq|<li><a href="$cgi/browse.pl?method=get&username=$data{username}&group=$data{group}&title=ADView&lookingforwho=$data{lookingforwho}&items=$items[$i]">$garbage[1]</a></li>|);
	$i++;
}
open (F,"<$mainpath/template/preget.tpl");
$title=$data{title};
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub get
{
($week,$montha,$datea,$time,$year)=split(" ",scalar localtime);
$datea="0$datea" if (length($datea)==1);
$tdate="$year$calendar{$montha}$datea";
open (F,"<$mainpath/log/limit");
flock(F,$LOCK_EX);
@limit=<F>;
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/log/$tdate.log");
flock(F,$LOCK_EX);
@log=<F>;
flock(F,$LOCK_UN);
close(F);
foreach(@log)
{
	($user,$count)=split(":",$_);
	if ($user eq $data{username} || (!$data{username} && $user eq $ENV{REMOTE_ADDR}))
	{
		if ($data{group} eq "silver")
		{
			if ($count eq $limit[0])
			{
				$limitflag=1;
				last;
			}
		}
		if ($data{group} eq "surfer")
		{
			if ($count eq $limit[1])
			{
				$limitflag=1;
				last;
			}
		}
		chop($count);
		$count++;
		$flag=1;
		$_="$user:$count\n";
		last;
	}
}
if ($limitflag){&error;}
if ($flag)
{
open (F,">$mainpath/log/$tdate.log");
flock (F, $LOCK_EX);
print F @log;
flock (F, $LOCK_UN);
close(F);
}
else
{
	open (F,">>$mainpath/log/$tdate.log");
	flock (F, $LOCK_EX);
	if ($data{username}){print F "$data{username}:1\n";}
	else {print F "$ENV{REMOTE_ADDR}:1\n";}
	flock (F, $LOCK_UN);
	close(F);
}
$destination="get_$data{lookingforwho}";
&$destination;
exit;
}

sub get_man
{
open (F,"<$mainpath/bases/man.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
($userdata,$common,$personal,$aboutme,$aboutyou,$hobby)=split("#",$entry[$data{items}]);
@userdata=split(":",$userdata);
@common=split(":",$common);
@personal=split(":",$personal);
if (-e "$mainpath/photoes/$userdata[0].jpg" && $data{group} ne "surfer"){$filename="$userdata[0].jpg";}
elsif (-e "$mainpath/photoes/$userdata[0].gif" && $data{group} ne "surfer"){$filename="$userdata[0].gif";}
else {$filename="nophoto.jpg";}
chop($um=substr($personal[0],0,3));
chop($ud=substr($personal[0],3,3));
$uy=substr($personal[0],6,2);
$udate="$uy$um$ud";
$age=$tdate-$udate;
$age=substr($age,2,2);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My age is:</b></td><td width="60%"><font color="#85B5E3">$age years</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I live in:</b></td><td width="60%"><font color="#85B5E3">$common[2]/$common[1]/$country[$common[0]]</font></td></tr>\n|);			
@outd=split(",",$common[3]);
foreach (@outd){$_=$outdoor[$_];}
$outd=join (" / ",@outd);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My favorite outdoor activities are:</b></td><td width="60%"><font color="#85B5E3">$outd</font></td></tr>\n|);
@ind=split(",",$common[4]);
foreach (@ind){$_=$indoor[$_];}
$ind=join (" / ",@ind);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My favorite indoor activities are:</b></td><td width="60%"><font color="#85B5E3">$ind</font></td></tr>\n|);
@forwho=split(",",$common[5]);
foreach (@forwho){$_=$lookingforwho[$_];}
$forwho=join (" / ",@forwho);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I want to meet:</b></td><td width="60%"><font color="#85B5E3">$forwho</font></td></tr>\n|);
@forwhat=split(",",$common[6]);
foreach (@forwhat){$_=$lookingforwhat[$_];}
$forwhat=join (" / ",@forwhat);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>For:</b></td><td width="60%"><font color="#85B5E3">$forwhat</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My race is:</b></td><td width="60%"><font color="#85B5E3">$race[$personal[1]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My marital status is:</b></td><td width="60%"><font color="#85B5E3">$marital[$personal[2]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My height is:</b></td><td width="60%"><font color="#85B5E3">$height[$personal[3]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body style is:</b></td><td width="60%"><font color="#85B5E3">$body[$personal[4]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My hair color is:</b></td><td width="60%"><font color="#85B5E3">$haircolor[$personal[5]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My hair length is:</b></td><td width="60%"><font color="#85B5E3">$hairlength[$personal[6]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My facial hair is:</b></td><td width="60%"><font color="#85B5E3">$facialhair[$personal[7]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body hair is:</b></td><td width="60%"><font color="#85B5E3">$bodyhair[$personal[8]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My public hair is:</b></td><td width="60%"><font color="#85B5E3">$mpublichair[$personal[9]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My eye color is:</b></td><td width="60%"><font color="#85B5E3">$eyecolor[$personal[10]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My eyewear is:</b></td><td width="60%"><font color="#85B5E3">$eyewear[$personal[11]]</font></td></tr>\n|);
@decor=split(",",$personal[12]);
foreach (@decor){$_=$decorations[$_];}
$decor=join (" / ",@decor);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body decorations are:</b></td><td width="60%"><font color="#85B5E3">$decor</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My endowment is:</b></td><td width="60%"><font color="#85B5E3">$endowment[$personal[13]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I am looks:</b></td><td width="60%"><font color="#85B5E3">$looks[$personal[14]]</font></td></tr>\n|);
@trait=split(",",$personal[15]);
foreach (@trait){$_=$traits[$_];}
$trait=join (" / ",@trait);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My character is:</b></td><td width="60%"><font color="#85B5E3">$trait</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My sex orientation is:</b></td><td width="60%"><font color="#85B5E3">$sexorient[$personal[16]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I have children:</b></td><td width="60%"><font color="#85B5E3">$children[$personal[17]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My sexuality to me is:</b></td><td width="60%"><font color="#85B5E3">$sexuality[$personal[18]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I want to have sex:</b></td><td width="60%"><font color="#85B5E3">$howoften[$personal[19]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My role is:</b></td><td width="60%"><font color="#85B5E3">$role[$personal[20]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I practice save sex:</b></td><td width="60%"><font color="#85B5E3">$safesex[$personal[21]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>In bed:</b></td><td width="60%"><font color="#85B5E3">$howinbed[$personal[22]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My religion is:</b></td><td width="60%"><font color="#85B5E3">$religion[$personal[23]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I smoke:</b></td><td width="60%"><font color="#85B5E3">$smoke[$personal[24]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I use alcohol:</b></td><td width="60%"><font color="#85B5E3">$drink[$personal[25]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I use drugs:</b></td><td width="60%"><font color="#85B5E3">$drugs[$personal[26]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My education is:</b></td><td width="60%"><font color="#85B5E3">$education[$personal[27]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My occupation is:</b></td><td width="60%"><font color="#85B5E3">$personal[28]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I stand in life:</b></td><td width="60%"><font color="#85B5E3">$position[$personal[29]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I am dress:</b></td><td width="60%"><font color="#85B5E3">$dress[$personal[30]]</font></td></tr>\n|);
open (F,"+<$mainpath/bases/users.cnt");
flock(F,$LOCK_EX);
@usrdat=<F>;
foreach (@usrdat)
{
	($usrdat,$counter)=split(":",$_);
	if ($usrdat eq $userdata[0])
	{
		chop($counter);
		$counter++;
		$_="$usrdat:$counter\n";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @usrdat;
flock (F, $LOCK_UN);
close(F);
open (F,"<$mainpath/template/ad.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub get_woman
{
open (F,"<$mainpath/bases/woman.db");
flock(F,$LOCK_EX);
@entry=<F>;
flock(F,$LOCK_UN);
close(F);
($userdata,$common,$personal,$aboutme,$aboutyou,$hobby)=split("#",$entry[$data{items}]);
@userdata=split(":",$userdata);
@common=split(":",$common);
@personal=split(":",$personal);
if (-e "$mainpath/photoes/$userdata[0].jpg" && $data{group} ne "surfer"){$filename="$userdata[0].jpg";}
elsif (-e "$mainpath/photoes/$userdata[0].gif" && $data{group} ne "surfer"){$filename="$userdata[0].gif";}
else {$filename="nophoto.jpg";}
chop($um=substr($personal[0],0,3));
chop($ud=substr($personal[0],3,3));
$uy=substr($personal[0],6,2);
$udate="$uy$um$ud";
$age=$tdate-$udate;
$age=substr($age,2,2);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My age is:</b></td><td width="60%"><font color="#85B5E3">$age years</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I live in:</b></td><td width="60%"><font color="#85B5E3">$common[2]/$common[1]/$country[$common[0]]</font></td></tr>\n|);			
@outd=split(",",$common[3]);
foreach (@outd){$_=$outdoor[$_];}
$outd=join (" / ",@outd);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My favorite outdoor activities are:</b></td><td width="60%"><font color="#85B5E3">$outd</font></td></tr>\n|);
@ind=split(",",$common[4]);
foreach (@ind){$_=$indoor[$_];}
$ind=join (" / ",@ind);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My favorite indoor activities are:</b></td><td width="60%"><font color="#85B5E3">$ind</font></td></tr>\n|);
@forwho=split(",",$common[5]);
foreach (@forwho){$_=$lookingforwho[$_];}
$forwho=join (" / ",@forwho);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I want to meet:</b></td><td width="60%"><font color="#85B5E3">$forwho</font></td></tr>\n|);
@forwhat=split(",",$common[6]);
foreach (@forwhat){$_=$lookingforwhat[$_];}
$forwhat=join (" / ",@forwhat);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>For:</b></td><td width="60%"><font color="#85B5E3">$forwhat</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My race is:</b></td><td width="60%"><font color="#85B5E3">$race[$personal[1]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My marital status is:</b></td><td width="60%"><font color="#85B5E3">$marital[$personal[2]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My height is:</b></td><td width="60%"><font color="#85B5E3">$height[$personal[3]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body style is:</b></td><td width="60%"><font color="#85B5E3">$body[$personal[4]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My hair color is:</b></td><td width="60%"><font color="#85B5E3">$haircolor[$personal[5]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My hair length is:</b></td><td width="60%"><font color="#85B5E3">$hairlength[$personal[6]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body hair is:</b></td><td width="60%"><font color="#85B5E3">$bodyhair[$personal[7]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My public hair is:</b></td><td width="60%"><font color="#85B5E3">$wpublichair[$personal[8]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My eye color is:</b></td><td width="60%"><font color="#85B5E3">$eyecolor[$personal[9]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My eyewear is:</b></td><td width="60%"><font color="#85B5E3">$eyewear[$personal[10]]</font></td></tr>\n|);
@decor=split(",",$personal[11]);
foreach (@decor){$_=$decorations[$_];}
$decor=join (" / ",@decor);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My body decorations are:</b></td><td width="60%"><font color="#85B5E3">$decor</font></td></tr>\n|);
@bra=split(",",$personal[12]);
foreach (@bra){$_=$brasize[$_];}
$bra=join (" / ",@bra);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My bra size is:</b></td><td width="60%"><font color="#85B5E3">$bra</font></td></tr>|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I am looks:</b></td><td width="60%"><font color="#85B5E3">$looks[$personal[13]]</font></td></tr>\n|);
@trait=split(",",$personal[14]);
foreach (@trait){$_=$traits[$_];}
$trait=join (" / ",@trait);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My character is:</b></td><td width="60%"><font color="#85B5E3">$trait</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My sex orientation is:</b></td><td width="60%"><font color="#85B5E3">$sexorient[$personal[15]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I have children:</b></td><td width="60%"><font color="#85B5E3">$children[$personal[16]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My sexuality to me is:</b></td><td width="60%"><font color="#85B5E3">$sexuality[$personal[17]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I want to have sex:</b></td><td width="60%"><font color="#85B5E3">$howoften[$personal[18]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My role is:</b></td><td width="60%"><font color="#85B5E3">$role[$personal[19]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I practice save sex:</b></td><td width="60%"><font color="#85B5E3">$safesex[$personal[20]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>In bed:</b></td><td width="60%"><font color="#85B5E3">$howinbed[$personal[21]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My religion is:</b></td><td width="60%"><font color="#85B5E3">$religion[$personal[22]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I smoke:</b></td><td width="60%"><font color="#85B5E3">$smoke[$personal[23]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I use alcohol:</b></td><td width="60%"><font color="#85B5E3">$drink[$personal[24]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>Do I use drugs:</b></td><td width="60%"><font color="#85B5E3">$drugs[$personal[25]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My education is:</b></td><td width="60%"><font color="#85B5E3">$education[$personal[26]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>My occupation is:</b></td><td width="60%"><font color="#85B5E3">$personal[27]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I stand in life:</b></td><td width="60%"><font color="#85B5E3">$position[$personal[28]]</font></td></tr>\n|);
push(@result,qq|<tr><td width="40%" valign="top" align="right"><b>I am dress:</b></td><td width="60%"><font color="#85B5E3">$dress[$personal[29]]</font></td></tr>\n|);
open (F,"+<$mainpath/bases/users.cnt");
flock(F,$LOCK_EX);
@usrdat=<F>;
foreach (@usrdat)
{
	($usrdat,$counter)=split(":",$_);
	if ($usrdat eq $userdata[0])
	{
		chop($counter);
		$counter++;
		$_="$usrdat:$counter\n";
		last;
	}
}
truncate(F,0);
seek(F,0,0);
print F @usrdat;
flock (F, $LOCK_UN);
close(F);
open (F,"<$mainpath/template/ad.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub error
{
open (F,"<$mainpath/template/error.tpl");
push(@errors,qq|<li><font size="2" color="#85B5E3">You can not view more than $count ads per day</font></li>|);
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}
