#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

if ($ENV{REQUEST_METHOD} eq "GET")
{
	@query=split("&",$ENV{QUERY_STRING});
	foreach(@query){/([^=]+)=(.*)/ && do {$data{$1}=$2;$data{$1}=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;}}
	$method=$data{method};
	&$method;
}
sysread(STDIN,$data,$ENV{CONTENT_LENGTH});
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$method=$data{method};
&$method;

sub initial
{
open (F,"<$mainpath/mailbox/$data{username}");
flock(F,$LOCK_EX);
@messages=<F>;
flock(F,$LOCK_UN);
close(F);
$messages=join("",@messages);
@messages=split("-----ENDLETTER-----\n",$messages);
foreach(@messages)
{
	($id,$from,$subj,$mdate,@msg)=split("\n",$_);
	if ($id=~/R$/)
	{
		push (@mails,"<tr><td><input type=checkbox name=ids value=$id></td><td><font size=2 color=\"#A5A500\">$from</font></td><td><a href=\"$cgi/mailbox.pl?method=getmail&username=$data{username}&group=$data{group}&id=$id\"><font size=2 color=\"#A5A500\">$subj</font></a></td><td><font size=2 color=\"#A5A500\">$mdate</font></td></tr>\n");
		$rm++;
	}
	else
	{
		push (@mails,"<tr><td><input type=checkbox name=ids value=$id></td><td><b><font size=2 color=\"#A5A500\">$from</font></b></td><td><b><a href=\"$cgi/mailbox.pl?method=getmail&username=$data{username}&group=$data{group}&id=$id\"><font size=2 color=\"#A5A500\">$subj</font></a></b></td><td><b><font size=2 color=\"#A5A500\">$mdate</font></b></td></tr>\n");
		$nm++;
	}
}
$rm=0 if (!$rm);
$nm=0 if (!$nm);
$tm=$rm+$nm;
if ($tm==0)
{
	push (@mails,"<tr><td><br><font size=4 color=\"#A5A500\"><center><b>NO MAIL</b></center></font></td></tr>\n");
}
else
{
	unshift (@mails,"<tr><td colspan=4><br><font size=4 color=\"#A5A500\"><center><b>YOU HAVE $nm ($tm) NEW MESSAGES</b></center></font></td></tr>\n<tr><td width=\"5%\">&nbsp;</td><td width=\"20%\"><b>From</b></td><td width=\"35%\"><b>Subject</b></td><td width=\"30%\"><b>Date</b></td></tr>\n");
	push (@mails,"<tr><td colspan=4><br><center><input type=submit value=\"Delete marked messages\"></center></td></tr>\n");
}
open (F,"<$mainpath/template/mailbox.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub Delete
{
open (F,"+<$mainpath/mailbox/$data{username}");
flock(F,$LOCK_EX);
@messages=<F>;
$messages=join("",@messages);
@messages=split("-----ENDLETTER-----\n",$messages);
foreach(@messages)
{
	($id,$from,$subj,$mdate,@msg)=split("\n",$_);
	next if ($data{ids}=~/\b$id\b/);
	push (@nmessages,$_);
}
truncate(F,0);
seek(F,0,0);
foreach(@nmessages)
{
	print F $_."-----ENDLETTER-----\n";
}
flock(F,$LOCK_UN);
close(F);
&initial;
}

sub getmail
{
open (F,"+<$mainpath/mailbox/$data{username}");
flock(F,$LOCK_EX);
@messages=<F>;
$messages=join("",@messages);
@messages=split("-----ENDLETTER-----\n",$messages);
foreach(@messages)
{
	($id,$from,$subj,$mdate,@msg)=split("\n",$_);
	$msg=join("\n",@msg);
	if ($id eq $data{id})
	{
		if ($id=~/R$/)
		{
			$_="$id\n$from\n$subj\n$mdate\n$msg\n";
		}
		else
		{
			
			$_=$id."R\n$from\n$subj\n$mdate\n$msg\n";
			$data{id}.="R";
		}
		$fromu=$from;
		$mes=$msg;
		last;
	}
}
truncate(F,0);
seek(F,0,0);
foreach(@messages)
{
	print F $_."-----ENDLETTER-----\n";
}
flock(F,$LOCK_UN);
close(F);
open (F,"<$mainpath/template/getmail.tpl");
@html=<F>;
close(F);
$html=join("\n",@html);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $html;
exit;
}

sub Reply
{
srand;
$mailid=int(rand 999999);
open (F,">>$mainpath/mailbox/$data{receiver}");
flock (F, $LOCK_EX);
print F "$mailid\n";
print F "$data{username}\n";
print F "$data{subj}\n";
$ltime=scalar localtime;
print F "$ltime\n";
print F "$data{body}\n";
print F "-----ENDLETTER-----\n";
flock (F, $LOCK_UN);
close (F);
&initial;
}
