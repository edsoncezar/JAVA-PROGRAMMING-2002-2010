#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}
($week,$month,$date,$time,$year)=split(" ",scalar localtime);
$date="$week, $month $date, $year at $time";
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		$value =~ s/<!--(.|\n)*-->//g;
		$value =~ s/<([^>]|\n)*>//g if ($allow_html != 1);
		$FORM{$field}=$value;
	}
}
$destination=$FORM{'method'};
&$destination;

sub post
{
	open (F,"<$mainpath/bases/chat");
	@messages=<F>;
	close(F);
	if (scalar(@messages)>=$maxmes){open (CHAT,">$mainpath/bases/chat");}
	else {open (CHAT,">>$mainpath/bases/chat");}
	flock (CHAT, $LOCK_EX);
	print CHAT "<b><em>$FORM{'username'}: </em><br>$FORM{'message'}</b><br><FONT SIZE=1>$date - $ENV{'REMOTE_HOST'}</FONT><BR><hr>\n";
	flock (CHAT, $LOCK_UN);
	close (CHAT);
	open (F,"<$mainpath/template/chat.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}

sub whois
{
	open (F, "+<$mainpath/bases/whois");
	flock(F,$LOCK_EX);
	@userlist=<F>;
	foreach $userlist(@userlist)
	{
		($uname,$uip,$umail,$utime)=split("\t",$userlist);
		$time=-M "$mainpath/temp/$uname";
		if ($time>0.08)
		{
			unlink ("$chatpath/temp/$uname");
			next;
		}
		push(@nuserlist,$userlist);
	}
	truncate(F,0);
	seek(F,0,0);
	print F @nuserlist;
	flock (F,$LOCK_UN);
	close(F);
	foreach(@nuserlist)
	{
		chop;
		($uname,$uip,$utime)=split("\t",$_);
		push(@found,"<tr><td>$uname</td><td>$utime</td><td>\n");
	}
	open (F,"<$mainpath/template/whois.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}

sub logoff
{
	open (F,"<$mainpath/bases/whois");
	flock(F,$LOCK_EX);
	@users=<F>;
	foreach(@users)
	{
		chop;
		($uname,$uip,$utime)=split("\t",$_);
		next if ($uname eq $FORM{'username'});
		push (@nusers,"$uname\t$uip\t$utime\n");
	}
	truncate(F,0);
	seek(F,0,0);
	print F @nusers;
	flock (F, $LOCK_UN);
	close(F);
	unlink ("$mainpath/temp/$FORM{'username'}");
	print "Location: $cgi/getmain.pl?$FORM{'username'}\n\n";
	exit;
}

sub init
{
	open (F,"<$mainpath/bases/chat");
	@messages=<F>;
	close(F);
	if (scalar(@messages)>=$maxmes){open (CHAT,">$mainpath/bases/chat");}
	else {open (CHAT,">>$mainpath/bases/chat");}
	flock (CHAT, $LOCK_EX);
	print CHAT "<b><em><font color=\"#85B5E3\">$FORM{'username'} has joined the chat</font></em></b><BR><hr>\n";
	flock (CHAT, $LOCK_UN);
	close (CHAT);
	open (F,"<$mainpath/template/chat.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
