#!/bin/perl
######################################################################
# FriendSeeker v1.1               		                     #
#--------------------------------------------------------------------#
# Copyright 1999-2000 TRXX Programming Group                         #
# Developed by Michael L. Sissine                                    #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
#rEADiNG vARiABLES fROM fiLE
open (F, "<fseeker.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}
($week,$month,$date,$time,$year)=split(" ",scalar localtime);
$date="$week, $month $date, $year at $time";
unless ($enablechat)
{
	if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
	else {($data=$ENV{QUERY_STRING});}
	@data=split("&",$data);
	foreach (@data)
	{
		/([^=]+)=(.*)/ && do
		{
			($field,$value)=($1,$2);
			$value=~s/\+/ /g;
			$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
			$data{$field}=$value;
		}
	}
	open (F,"<$mainpath/template/nochat.tpl");
	@html=<F>;
	close(F);
	$html=join("\n",@html);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $html;
	exit;
}
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		$FORM{$field}=$value;
	}
}
open (F,">$mainpath/temp/$FORM{'username'}");
print F 1;
close(F);
open (F,">>$mainpath/bases/whois");
flock (F, $LOCK_EX);
print F "$FORM{'username'}\t$ENV{'REMOTE_ADDR'}\t$time\n";
flock (F, $LOCK_UN);
close(F);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "Content-type: text/html\n\n";
print qq~
<html>
<head>
<title>FriendSeeker - Chat</title>
</head>
<frameset framespacing="0" frameborder="0" cols="570,*">
<frame name="chat" src="$cgi/chat.pl?username=$FORM{'username'}" scrolling="yes" marginwidth=0 marginheight=0>
<frame name="menu" src="$cgi/mchat.pl?username=$FORM{'username'}&group=$FORM{'group'}&method=init" scrolling="no" marginwidth=0 marginheight=0>
</frameset>
~;
