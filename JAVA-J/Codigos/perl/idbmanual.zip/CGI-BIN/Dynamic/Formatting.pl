########################################
############Echelon Design##############
#Product= IDB                          #
#Version= 4.0                          #
#File=Dynamic Formats		       #
#Purpose=For the advanced users who    #
#Wish to play around with the          #
#formatting of IDB		       #
########################################
########################################
#The Impressions page
$dynfor{'impressions'}=qq~
 <table><tr><td valign=top>
 <table bgcolor="$template{tablebg}" border="$template{tableborderwidth}"  bordercolor="$template{tablebordercolor}">
<Tr>
<td colspan=3>
Impressions
</td>
</tr>
<tr>
<Td>
Item
</td>
<td>
Impressions
</td>
</tr>
[%itemsimpressions%]
</table>
~;
#The Click Page
$dynfor{'clicks'}=qq~
<table><tr><td valign=top>
 <table bgcolor="$template{tablebg}" border="$template{tableborderwidth}"  bordercolor="$template{tablebordercolor}">
<Tr>
<td colspan=3>
Clicks
</td>
</tr>
<tr>
<Td>
Item
</td>
<td>
Clicks
</td>
</tr>
[%itemsclicks%]
</table>
~;
#The Reordering Page
$dynfor{'reorder'}=qq~
<html><style type="text/css">
<!--
TEXTAREA {
font-family: Times;
font-size: 12pt;
font-weight: normal
} 
-->
</style> 
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">

<tr><td colspan=2>Reorder The items(If you dont leave a number item gets added last)</td></tr>
<td><form action="index.pl" method=post>
[%files%]
<input type=hidden name=action value=order>
<input type=hidden name=level value=1>
</td>
</tr>
<tr>
<Td align=center colspan=2>
<input type=submit>
</form>
</body>
</html>
~;
#the small solo search form
$dynfor{'searchform'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<Td align=center>
Search By Name:
</td>
</tr>
<tr>
<Td align=center>
<form action="Sources/search.pl" method=post>
<input name=words>
<br>
<input type=submit>
</td>
</tr>
</form>
</table>
~; 
#this is the entire Update form page
$dynfor{'form'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr><Td align=center>
<b>[%title%]</b>
</td></tr>
<tr><Td align=center>
<form action="index.pl?action=add" method=post>
<input type=hidden name=action value="[%action%]">
<input type=hidden name=level value="[%level%]">
<input type=hidden name=user value=[%user%]>
[%fields%]
</form>
~;
#page to select an item to update
$dynfor{'updatepage'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<td align=center>
<form action="index.pl" method="post">
<input type=hidden name=level value=1>
<input type=hidden name=action value=update>
<input type=hidden name=user value=[%user%]>
Select An Item to update<br>
<select name=name>
[%items%]
</select><br>
<input type=submit>
</td>
</tr>
</table>
</body>
</html>
~;
#page to remove an item
$dynfor{'removepage'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
    <Td align=center> <form action="index.pl" method="post"> 
      <input type=hidden name=level value=1>
<input type=hidden name=action value=remove>
      Select An Item to Remove<br>
      <select name=name>
[%items%]
</select>
      <br>
      <input type=submit>
</td>
</tr>
</table>
</body>
</html>
~;

#the admin "Panel"
$dynfor{'adminpanel'}= qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<td align=center colspan=7>
Admin Panel
</td>
</tr>
[ifstatus]
<tr>
<Td colspan=10 align=center>
[%status%]
</tD>
</tr>
[endifstatus]
<tr>
<Td align=center>
<a href="index.pl?action=display">
 Display(front/guest end)</a> </td>
<Td align=center>
<a href="index.pl?action=search&user=[%user%]">
 Search for items</a> </td>
<Td align=center>
<a href="index.pl?action=pform&user=[%user%]">
 Add An Item</a> </td>


 <Td align=center><a href="index.pl?action=update&user=[%user%]">Update An Item </a></td>


 <Td align=center><a href="index.pl?action=remove&user=[%user%]">Remove an item</a> </td>
<Td align=center>
<a href="index.pl?action=order&user=[%user%]">
 Reorder Items</a> </td>

</tr>
<Tr><td colspan=7 align=center>
You are logged in as [%user%]</td></tr><tr><td colspan=7 valign=top>[%userpanel%]</td></tr>
</table>
</center>
</body>
</html>
~;
#A Login Page
$dynfor{'adminsection'}= qq~   
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>

<form action=index.pl method=post>
 <Td align=center>User</td></tr>
	

<tr>
 <Td align=center>
 <input name=user>
</td></tr>
 <Td align=center>Password</td></tr>
	

<tr>
 <Td align=center>
 <input type=password name=pw>
</td></tr><tr> 
<Td align=center>
<input type=hidden name=level value=1>
<input type=hidden name=action value=form>
<input type=submit value="Verify Me">
</form>Not Registered?<br><a href="index.pl?action=register">Register</a>
</td>
</tr>
</table>
</body>
</html>
~;

#If the password is wrong print this
$dynfor{'badpw'}= qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>

    <Td align=center><font color=red>
Password Incorrect Try again
</font></td></tr>
<tr>
<form action=index.pl method=post>
 <Td align=center>User</td></tr>
	

<tr>
 <Td align=center>
 <input name=user>
</td></tr>
 <Td align=center>Password</td></tr>
	

<tr>
 <Td align=center>
 <input name=pw type=password>
</td></tr><tr> 
<Td align=center>
<input type=hidden name=level value=1>
<input type=hidden name=action value=form>
 <input type=checkbox name=stay value=1>Remeber Me?<br>
<input type=submit value="Verify Me">
</form>
Not Registered?<br><a href="index.pl?action=register">Register</a>
</td>
</tr>
</table>
</body>
</html>
~;
#this is the template that is printed for each record that is found from the search
$dynfor{'printrecord'}= qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">

<tr><Td>
<a href="[%link%]"><img src="[%imgsrc%]" width=[%width%] height="[%height%]"></a>
</td><td valign=top>
<a href="[%link%]">[%title%]</a><br>
[%desc%]
<hr width=100%>
~;
#this is printed for how many items to view on each page.  You can change
#these numbers by simply changing anything that says a number, will work fine.
#note, this section is also called [%numberoptions%]
$dynfor{'ntd'}=qq~
How many items on each page?
<a href="index.pl?action=display&ntd=5&page=[%number%]">5</a> <a href="index.pl?action=display&ntd=10&page=[%number%]">10</a>
~;
#this is printed before the actual projects in "display" section
$dynfor{'topdisplay'}=qq~
<table>
<tr>
<Td width=60% align=left valign=top>
<table width=100%>
<tr>
<td valign=top>
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<Td align=center>
Search
</td>
</tr>
<tr>
<td>
<form action="Sources/search.pl" method=post>
<input name=words>
</td></tr>
<tr>
<Td align=center>
<input type=submit value=Seach>
</form>
</td>
</tr>
</table>
<br>
[%ifnotloggedin%]
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<Td align=center>
<b>Login</b>
</td>
</tr>
<tr>   
<form action=index.pl method=post>
 <Td align=center>User</td></tr>
	

<tr>
 <Td align=center>
 <input name=user>
</td></tr><tr>
 <Td align=center>Password</td></tr>
	

<tr>
 <Td align=center>
 <input type=password name=pw>
</td></tr><tr> 
<Td align=center>
<input type=hidden name=level value=1>
<input type=hidden name=action value=form>
<input type=checkbox name=stay value=1>Remeber Me?<br>
<input type=submit value="Verify Me"><br></form>
Not Registered?<br><a href="index.pl?action=register">Register</a></td></tr>
</table>
[%endifnotloggedin%]
[%ifloggedin%]
<table bgcolor="$template{'tablebg'}" width=155 border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<td align=center>
Welcome [%user%]
</td></tr>
<tr>
<td align=center>
<a href="index.pl?action=printpanel">
Go to your panel
</a>
<hr width=100%>
<a href="index.pl?action=printpanel">Change Registration Information</a>
<hr width=100%>
<a href="index.pl?action=logout">Logout</a>

</td></tr>
</table>
[%endifloggedin%]
</td><td valign=top>
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<Td colspan=2 align=center>
[%status%]
</td>
</tr>
~;
#this is printed for each item
$dynfor{'displayitem'}=qq~
<tr>
<td width=100 align=center>
<a href="index.pl?action=clickthrough&item=[%item%]&url=[%link%]"><img src="[%imgsrc%]" width=[%width%] border=0 height="[%height%]"></a>
</td><td valign=top align=center>
<a href="index.pl?action=clickthrough&item=[%item%]&url=[%link%]">[%title%]([%percent%])</a><br>
[%desc%]
</td></tr>
~;
#this is the format for the entire link section at the bottom
$dynfor{'linkssection'}=qq~
<tr><td colspan=2>
Pages : [%links%]
Viewing [%printed%] of [%totalitems%]<br>
[%numberoptions%]
</tr></td>
~;

#this is the format for each link at the bottom
#the reason you have another thing, number plus one, is so that they never see a page '0'
$dynfor{'links'}=qq~
<a href="index.pl?action=display&ntd=[%ntd%]&page=[%number%]">[%numberplusone%]</a>
~;
#if some mods are found to add..
$dynfor{'modyes'}=qq~
<input type=hidden name=action value=mod>
<input type=hidden name=modaction value=newmod>
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<Td colspan=3 align=center>
<b>New Mods Found Automaticaly</b>
</td></tr>
<tr>
<Td>Mod</td>
<td>Version</td>
<td>Add?</td>
</tr>
~;
#if no new mods are found....
$dynfor{'modno'}=qq~
<input type=hidden name=action value=mod>
<input type=hidden name=modaction value=newmod>
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<Td colspan=3 align=center>
<b>No New Mods Found Automaticaly</b>
~;
#add a mod manualy
$dynfor{'modadd'}= qq~
<input type=hidden name=total value=$modcount> 
<tr><Td align=center colspan=3>
<b>Add A Mod not listed</b>
<br>FULL filename and/or path<br>
<br>
<input name="echelonofficialother" value=".idbmod.new.pl">
<br>
<input type=submit value="Add These Mods">
</form>
</td>
</tr>
</table>
~;
$dynfor{'backup'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<Td align=center>
Backup the Database
</td></tr>
<tr><td align=center>
Database Backup Name
<hr width=100% color=black>
<form action=index.pl method=post>
<input type=hidden name=action value=backup>
<input type=hidden name=level value=1>
<input type=hidden name=pw value=$FORM{'pw'}>
<input name=dbname>
</td></tr>
<Tr><Td align=center><input type=submit value="Creat Backup">
</td></tr></table>
~;

$dynfor{'alphalist'}=qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<td align=center>
<b>[%title%]</b>
</td></tr>
<tr>
<td align=center>
[%letters%]
</td></tr>
<tr>
<td align=center>
[%list%]
</td>
</tr>
</table>
~;
#if remove is for the super admin to be removing the user
$dynfor{'userpanel'}=qq~
[%ifremove%]
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<tr>
<Td align=center>
[%text%]
</td>
</tr>
</table>
[%endifremove%]
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">

<tr>
<td align=center colspan=2>
<b>[%user%]</b>
</td></tr>
<tr><td>
Username: [%user%]<br>
User Email: [%email%]<br>
User Rank: [%rank%]<br>

Number Of User's Items: [%item_count%]<br>
</td><Td align=center>
Users Items:<br>
[%user_item_list%]
</td></tr>
</table>
~;
1;