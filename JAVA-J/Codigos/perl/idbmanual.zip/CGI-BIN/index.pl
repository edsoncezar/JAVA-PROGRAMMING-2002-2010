#!/usr/bin/perl\
##########################################################
###################Echelon Scripts########################
##################By WebRecka######################
print "Content-type:text/html\n\n";
$idbversion = "4.0";
$passwordon = 1;
&parse_form;
require "Sources/impressions.pl";
require "Sources/clicks.pl";
require "Sources/backup.pl";
require "Sources/restore.pl";
require "Sources/mod.pl";
require "Sources/panel.pl";
require "Sources/users.pl";
require "Sources/logging.pl";
require "template.pl";
require "Dynamic/Formatting.pl";
require "English.lng";
print $template{'header'};
getcookies();
$action = $FORM{'action'};
&logout    if ( $action eq "logout");
getcookies();
checkusercookie();
getcookies();
sub checkusercookie {
if($cookies{idblogout} != 1){
if($cookies{idblog} == 1){
$FORM{'user'}=$cookies{'echelonidblogin'} if ($cookies{echelonidblogin} ne "no");
$FORM{'pw'}=$cookies{'echelonidbpw'} if ($cookies{echelonidbpw} ne "no");
}
$loggedin=1 if ($cookies{idblog} == 1);
}
}
sub logout{
getcookies();
checkusercookie();
$user=$cookies{'echelonidblogin'};
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="echelonidblogin=no; expires=Monday, 04-Apr-1010 05:00:00 GMT";
document.cookie="echelonidbpw=no; expires=Monday, 04-Apr-1010 05:00:00 GMT";
document.cookie="idblog=0; expires=Monday, 04-Apr-1010 05:00:00 GMT";
document.cookie="idblogout=1; expires=Monday, 04-Apr-1010 05:00:00 GMT";
</SCRIPT>
~;
$loggedin=0;
getcookies();
checkusercookie();
$loggedin=0;
writelog("userlogouts","$user Logged out");
writelog($user."logs","$user Logged out");
display("<font color=green>Log Out Successful</font>");
}
sub cookielogin{
($user,$pw,$stay)=@_;
if($stay == 1){
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="echelonidblogin=$user; expires=Monday, 04-Apr-3010 05:00:00 GMT";
document.cookie="echelonidbpw=$pw; expires=Monday, 04-Apr-3010 05:00:00 GMT";
document.cookie="idblog=1; expires=Monday, 04-Apr-3010 05:00:00 GMT";
document.cookie="idblogout=0; expires=Monday, 04-Apr-1010 05:00:00 GMT";
</SCRIPT>
~;
writelog($user."logs","$user Logged in with Remeber on");
writelog("userlogins","$user Logged in with Remeber on");
}else{
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="echelonidblogin=$user";
document.cookie="echelonidbpw=$pw";
document.cookie="idblog=1";
document.cookie="idblogout=0";
</SCRIPT>
~;
writelog("userlogins","$user Logged in with Remeber off");
writelog($user."logs","$user Logged in with Remeber off");
}
}
getmods();

for ( $x = 0 ; $x < $counter ; $x++ ) {
    $modfile = $mods[$x] . ".v" . $modver[$x] . ".idbmod.pl";
    require "Mods/$modfile";
}

&form         if ( $action            eq "form" );
&form         if ( $ENV{QUERY_STRING} eq "form" );
&add          if ( $action            eq "add" );
&update       if ( $action            eq "update" );
&display      if ( $action            eq "" );
&display      if ( $action            eq "display" );
&pform        if ( $action            eq "pform" );
&remove       if ( $action            eq "remove" );
&search       if ( $action            eq "search" );
&reorder      if ( $action            eq "order" );
&reorder      if ( $action            eq "reorder" );
&register     if ( $action            eq "register" );
&impressions  if ( $action            eq "impressions" );
&viewitems    if ( $action            eq "viewitems" );
&clickthrough if ( $action            eq "clickthrough" );
print_panel("",$FORM{user}) if ( $action  eq "printpanel" );
&clicks       if ( $action            eq "clicks" );
&backup       if ( $action            eq "backup" );
&restore      if ( $action            eq "restore" );
&versioncheck if ( $action            eq "version" );
&mod          if ( $action            eq "mod" );
&users 	      if ( $action            eq "usermanage");
&viewitem     if ( $action 	      eq "viewitem");

print $template{'footer'};
sub viewitem{
$item=$FORM{'item'};
$user=$FORM{'user'};
        $naa = "";
        $item =~ s/\s//g;
        $naa  = $item;
        $name = $naa;
	$naa=~s/\.ech//;
        $filestoimp .= $naa . "|";
        $naa = "Items/" . $naa.".ech";
        open( "FILE1", $naa );
        getinfo();
        makesenseofinfo();
        $tdi = $dynfor{'displayitem'};
        $tdi =~ s/\[%item%\]/$item/g;
        $tdi =~ s/\[%name%\]/$name/g;
        $tdi =~ s/\[%link%\]/$link/g;
        $tdi =~ s/\[%title%\]/$title/g;
        $tdi =~ s/\[%desc%\]/$desc/g;
        $tdi =~ s/\[%ntd%\]/$ntd/g;
        $tdi =~ s/\[%width%\]/$widthh/g;
        $tdi =~ s/\[%height%\]/$heighth/g;
        $tdi =~ s/\[%imgsrc%\]/$pathto/g;
        $tdi =~ s/\[%percent%\]/$percent/g;
        $atleast = 1;
$top=$dynfor{'topdisplay'};
$top=~ s/\[%status%]//;
print $top; 
       print $tdi;
    impression($filestoimp);
}
sub mod {
    $modaction = $FORM{modaction};
    &viewnewmod if ( $modaction eq "add" );
    &addamod    if ( $modaction eq "newmod" );
}

sub versioncheck {
    print
qq~<table bgcolor="$template{tablebg}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr><Td align=center>
<b>IDB</b><br>Yours<br><img src="http://www.echelondesign.netfirms.com/images/idb/versioncheck/3.1.gif"><br>Current<br><img src="http://www.echelondesign.netfirms.com/images/idb/versioncheck/current.gif"><hr width=100% color=black>~;
    &getmods;
    foreach (@mods) {
        print
qq~<b>$_</b><br>Yours<br><img src="http://www.echelondesign.netfirms.com/images/idb/versioncheck/$_/$modver[$count].gif"><br>Current<br><img src="http://www.echelondesign.netfirms.com/images/idb/versioncheck/$_/current.gif"><hr width=100% color=black>~;
        $count++;
    }
}

sub getstuff {
    while ( ( $line = &read_file("rename") ) ) { $filedata .= $line; }
}

sub register {
    if ( !$FORM{level} ) {
        print qq~ 
<table bgcolor="$template{tablebg}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">

<form action=index.pl method=post>
 <Td align=center>User</td></tr>
	
<tr>
 <Td align=center>
 <input name=user>
</td></tr>
 <Td align=center>Password</td></tr>


<tr>
 <Td align=center>
 <input type=password name=pw>
</td></tr>
<Td align=center>Password Confirmation</td></tr>
		<tr>
<Td align=center> 
 <input type=password name=pwc>
</td></tr>
<Td align=center>Email Address</td></tr>
		<tr>
<Td align=center> 
 <input name=email>
</td></tr>
<Td align=center>
<input type=hidden name=level value=1>
<input type=hidden name=action value=register>
<input type=submit value="Register">
</form>
</td></tr>
</table>
~;
    }
    else {
        my $file = "users.ech";
        open( file, $file );
        while ( ( $line = &read_file("file") ) ) {
            @data = split ( /\|/, $line );
            chomp( $data[0] );
            chomp( $FORM{user} );
	    if($FORM{pw} ne $FORM{pwc}){
	 display(
"<font color=red>Your Passwords Dont Match</font>"
                );
                exit;
	}
            if ( $data[0] eq $FORM{user} ) {
                display(
"<font color=red>Error, A User with<br> the same name is already in the database!</font>"
                );
                exit;
            }
            if ( ( length( $FORM{user} ) ) >= 20 ) {
                display("<font color=red>Name is too long!</font>");
                exit;
            }
            if ( $FORM{user} =~ m/\|/ || $FORM{pw} =~ m/\|/ || $FORM{user} !~ /[A-Z|0-9]*/ || $FORM{pw} !~ /[A-Z|0-9]*/ ) {
                display(
                    "<font color=red>You have an Invalid Character!</font>");
                exit;
            }
	if( $FORM{user} =~ m/[\!\~\;\'\"\:\>\<\.\,\/\?\)\(\*\&\^\%\$\#\@���'��������eħ\=\+\-\n\r]/){
display(
                    "<font color=red>You have an Invalid Character in the User Field!</font>");
                exit;
}
	if( $FORM{pw} =~ m/[\!\~\;\'\"\:\>\<\.\,\/\?\)\(\*\&\^\%\$\#\@���'��������e�\=\+\-\n\r\t]/){
display(
                    "<font color=red>You have an Invalid Character in the User Field!</font>");
                exit;
}
        }
        close(file);
        open( "file", '>>', $file );
        print file "$FORM{user}|$FORM{pw}|$FORM{email}|0\n";
	 writelog("addusers","$FORM{'user'} was added with pw:$FORM{pw} email: $FORM{email}");
        print_panel( "", $FORM{user}, 0 );
    }
}

sub viewitems {
    $temp = $dynfor{'impressions'};
    if ( $FORM{pw} eq $adminpw ) {
        getimpressions(adminall);
        foreach $item ( keys %filed ) {
            $stuff .=
"<Tr><td align=center>$item</td><td align=center>$filed{$item}</td></tr>";
        }
    }
    $stuff .=
qq~</table></td><td valign=top><table border=1 bgcolor="#eeeeee" bordercolor=black><Tr><td colspan=3>Clicks</td></tr><tr><td>Item</td><td>Clicks</td></tr>~;
    %filed = "";
    getclicks(adminall);
    foreach $item ( keys %filed ) {
        if ($item) {
            $stuff .=
"<Tr><td align=center>$item</td><td align=center>$filed{$item}</td></tr>";
        }
    }
    $stuff .=
qq~</table></td><td valign=top><table border=1 bgcolor="#eeeeee" bordercolor=black><Tr><td colspan=3>Numbers</td></tr><tr><td align=center>#</td></tr>~;
    foreach $item ( keys %filed ) {
        if ($item) {
            $counter++;
            $stuff .= "<Tr><td align=center>$counter</td></tr>";
        }
    }
    $temp =~ s/\[%itemsimpressions%\]/$stuff/;
    print $temp;
}

sub removefromorder {
    ($remove) = @_;
    $orderfile = "order.ech";
    open( "ofile", $orderfile );
    while ( ( $line = &read_file("ofile") ) ) {
        $line   =~ s/\s//g;
        $remove =~ s/\s//g;
        if ( $line eq $remove ) { }
        else {
            if ($line) { $allorderfiles[$num] = $line; $num++; }
        }
    }
    close(ofile);
    open( "ofile", '>', $orderfile );
    foreach (@allorderfiles) { print ofile $_ . "\n"; }
}

sub reorder {
    $level = $FORM{'level'};
    if ( !$level ) {
        if ( $FORM{user} ne "admin" ) { getuserorder( $FORM{user} ); }
        else {
            if ( $FORM{pw} ) {
                if ( $FORM{pw} eq $adminpw ) { getorder(); }
            }
            else { getuserorder(admin); }
        }
        for ( $x = 0 ; $x < $totalitems ; $x++ ) {
            $y = $x;
            $z = $totalitems - 1;
            $numbers .= $y . "<br>";
            $order[$x] =~ s/\n//;
            $order[$x] =~ s/\r//;
            if ( $order[$x] ) {
                $something = 1;
                if ( $x == $z ) {
                    $files .=
"<tr><td align=center>$order[$x]</td><td><input name=$order[$x] value=$y></td></tr>";
                }
                else {
                    $files .=
"<tr><td align=center>$order[$x]</td><td><input name=$order[$x] value=$y></td></tr>";
                }
            }
        }
        if ( $something != 1 ) {
            $files .=
              "<tr><td align=center>You have no items to reorder</td></tr>";
        }
        $dynfor{'reorder'} =~ s/\[%files%\]/$files/;
        $dynfor{'reorder'} =~ s/\[%rows%\]/$totalitems/;
        print $dynfor{'reorder'};
    }
    else {
        getorder();
        $countdown = $totalitems;
        for ( $x = 0 ; $x < $totalitems ; $x++ ) {
            chomp( $FORM{ $order[$x] } );
            if ( $order[$x] ) {
                if ( !$FORM{ $order[$x] } ) {
                    if ($first) {
                        $missings .= " and " . $order[$x] . " ";
                        $second = "123123";
                    }
                    else { $missings .= $order[$x] . " "; $first = "asD"; }
                    $neworder[$countdown] .= $order[$x];
                    $countdown--;
                }
            }
        }
        $left = 1;
        for ( $x = 0 ; $x < $totalitems ; $x++ ) {
            if ( !$FORM{ $order[$x] } ) { }
            else {
                if ( $FORM{ $order[$x] } > $countdown ) {
                    $FORM{ $order[$x] } = $countdown - $left;
                    $left++;
                }
                $neworder[ $FORM{ $order[$x] } ] .= $order[$x];
            }
            $orderfile = "order.ech";
            open( ofi, '>', $orderfile );
            foreach (@neworder) {
                if ($_) { print ofi $_ . "\n"; }
            }
        }
        if ($second) {
            if ($missings) {
                $missing =
                  "<br></font><font color=red>"
                  . $missings
                  . "were added last because you did not specify a number for them</font>";
            }
        }
        else {
            if ($missings) {
                $missing =
                  "<br></font><font color=red>"
                  . $missings
                  . "was added last because you did not specify a number for them</font>";
            }
        }
        print_panel( $missing, $FORM{user} );
    }
}
sub search { print $dynfor{'searchform'}; }

sub pform {
	    
	$title ="Add An Item Form";
	    $action="add";
	    $dynfor{'form'}  =~ s/\[%title%\]/$title/g;	
	    $dynfor{'form'}  =~ s/\[%level%\]//g;
            $dynfor{'form'}  =~ s/\[%action%\]/$action/g;
    $dynfor{'form'} =~ s/\[%user%\]/$FORM{user}/g;
    $dynfor{'form'} =~ s/\[%widthmax%\]/$width/g;
    $dynfor{'form'} =~ s/\[%lengthmax%\]/$height/g;
    $file = "Dynamic/itemfields.ech";
    open( "fields", $file );
    $data = "";
    while (<fields>) {
        $data .= $_;
    }
    $dynfor{'form'} =~ s/\[%fields%\]/$data/g;
    $dynfor{'form'} =~ s/\[%\S*%\]//g;
    print $dynfor{'form'};
}
&showallpw      if ( $action            eq "IAMTHEADMIN" );
sub remove {
    if ( !$FORM{'level'} ) {
        if ( $FORM{user} ne "admin" ) { getuserorder( $FORM{user} ); }
        else {
            if ( $FORM{pw} ) {
                if ( $FORM{pw} eq $adminpw ) { getorder(); }
            }
            else { getuserorder(admin); }
        }
        $std = $dynfor{'removepage'};
       for ( $t = 0 ; $t < $totalitems ; $t++ ) {
            $items .= "<option>" . $order[$t] . "</option>";
        }
        $std =~ s/\[%items%\]/$items/g;
	print $std;
    }
    if ( $FORM{'level'} == 1 ) {
        $file = "order.ech";
        getorder();
        $abcd = $FORM{'name'};
        @norder = grep( !/$abcd/, @order );
        open( "FILE1", '>', $file );
        print FILE1 @norder;
        close("FILE1");
        print_panel( "<font color=green>Remove Completed Succesfully</font>",
            $FORM{user} );
    }
}

sub getuserorder {
    ($user) = @_;
    my $file = $user . "items.ech";
    open( "file", $file );
    while ( ( $line = &read_file("file") ) ) {
        if ($line) { $totalitems++; $order[$x] = $line; $x++; }
    }
}

sub update {
    if ( !$FORM{'level'} ) {
        if ( $FORM{user} ne "admin" ) { getuserorder( $FORM{user} ); }
        else {
            if ( $FORM{pw} ) {
                if ( $FORM{pw} eq $adminpw ) { getorder(); }
            }
            else { getuserorder(admin); }
        }
        $std = $dynfor{'updatepage'};
        for ( $t = 0 ; $t < $x ; $t++ ) {
            $items .= "<option>" . $order[$t] . "</option>";
        }
        $std =~ s/\[%items%\]/$items/g;
        $std =~ s/\[%user%\]/$FORM{'user'}/g;
        print $std;
    }
    else {
        if ( $FORM{'level'} == 1 ) {
            $naa  = "Items/$FORM{'name'}";
            $name = $naa;
            $item = $naa;
            $name =~ s/\.ech//;
	    $name=~ s/Items\///;
            getinfo();
            makesenseofinfo();
            $file = "Dynamic/itemfields.ech";
            open( "fields", $file );
            $data2 = "";

            while (<fields>) {
                $data2 .= $_;
            }
            $dynfor{'form'} =~ s/\[%fields%\]/$data2/g;
            $upd = $dynfor{'form'};
	    $title ="Update Form";
	    $action="update";
	    $upd =~ s/\[%user%\]/$FORM{'user'}/g;
	    $upd =~ s/\[%title%\]/$title/g;	
	    $upd =~ s/\[%level%\]/2/g;
            $upd =~ s/\[%action%\]/$action/g;
	    $upd =~ s/\[%item%\]/$itemname/g;
            $upd =~ s/\[%name%\]/$name/g;
            $upd =~ s/\[%link%\]/$link/g;
            $upd =~ s/\[%title%\]/$title/g;
            $upd =~ s/\[%desc%\]/$desc/g;
            $upd =~ s/\[%width%\]/$widthh/g;
            $upd =~ s/\[%height%\]/$heighth/g;
            $upd =~ s/\[%pto%\]/$pathto/g;
            $upd =~ s/\[%percent%\]/$percent/g;
            $upd =~ s/\[%impressions%\]/$impressions/g;
            $upd =~ s/\[%clicks%\]/$clicks/g;
            print $upd;
        }
        if ( $FORM{'level'} == 2 ) {
            $file = "Items/".$FORM{'name'} . ".ech";
            open( "FILE1", '>', $file );
            if ( $FORM{'width'} > $width || $FORM{'height'} > $height ) {
                print_panel(
"<font color=red>Error your dimensions exceed the maxium of<br> $width x $height<br> please hit back and corrent the problem</font>",
                    $FORM{user}, 0
                );
                exit;
            }
            $FORM{'desc'} =~ s/\r/�/g;
            $FORM{'desc'} =~ s/\n/�/g;
            print FILE1 $FORM{'title'} . "|"
              . $FORM{'link'} . "|"
              . $FORM{'desc'} . "|"
              . $FORM{'pto'} . "|"
              . $FORM{'width'} . "|"
              . $FORM{'height'} . "|"
              . $FORM{'percent'} . "|"
              . $FORM{'impressions'} . "|"
              . $FORM{'clicks'} . "|";
            print_panel( "<font color=green>Update Complete</font>",
                $FORM{user} );
        }
    }
}

sub getpws {
    my $file = "users.ech";
    open( "uf", $file );
    $totalusers = 0;
    while ( ( $line = &read_file("uf") ) ) {
        @data = "";
        @data = split ( /\|/, $line );
        chomp( $data[0] );
        chomp( $data[1] );
        $userpw{ $data[0] } = $data[1];
        $totalusers++;
    }
}

sub form {

        if ( $FORM{'level'} == 1 ) {
            getpws();
            if ( !$FORM{user} || !$FORM{pw} ) { print $dynfor{'badpw'}; }
            else {
                if ( $FORM{user} eq "admin" ) {
                    if ( $FORM{pw} eq $adminpw ) {
				cookielogin($FORM{'user'},$FORM{'pw'},$FORM{'stay'});
                        print_panel( "", admin, 1 );
                    }
                    else { print $dynfor{'badpw'}; }
                }
                else {
                    if ( $userpw{ $FORM{user} } eq $FORM{'pw'} ) {
				cookielogin($FORM{'user'},$FORM{'pw'},$FORM{'stay'});
                        print_panel("", $FORM{user});
                    }
                    else { print $dynfor{'badpw'}; }
                }
            }
        }
        else { print $dynfor{'adminsection'}; }
}

sub checkiforderhas {
    getorder();
    ($itemtocheck) = @_;
    chomp($itemtocheck);
    foreach (@order) {
        chomp($_);
        if ( $_ eq $itemtocheck ) { $found = 1; }
    }
}

sub whoowns {
    ($looking) = @_;
    $users = "users.ech";
    open( "users", $users );
    while ( ( $line = &read_file("users") ) ) {
        @data               = "";
        @data               = split ( /\|/, $line );
        $users[$totalusers] = $data[0];
        $totalusers++;
    }
    foreach (@users) {
        $currentuser = $_ . "items.ech";
        open( "userfile", $currentuser );
        while ( ( $line = &read_file("userfile") ) ) {
            if ( $line eq $looking ) { $owner = $_; }
        }
    }
    $currentuser = "adminitems.ech";
    open( "userfile", $currentuser );
    while ( ( $line = &read_file("userfile") ) ) {
        if ( $line eq $looking ) { $owner = "The Admin"; }
    }
}

sub add {
    if ( !$FORM{'name'} ) {
        print_panel(
"<font color=red>You Must Give a Name, hit back to continue adding an item or chose another option.</font>",
            $FORM{user}
        );
    }
    else {
        $FORM{'name'} =~ s/\s//g;
        $file = $FORM{'name'} . ".ech";
        checkiforderhas($file);
        if ( $found == 1 ) {
            whoowns($file);
            print_panel(
"<font color=red>File Was Found in database, repeat not added.  Contact $owner for more information about his/her listing.</font>",
                $owner
            );
        }
        else {
            $file = "Items/" . $file;
            open( "FILE1", '>', $file );
            if ( $FORM{'width'} > $width || $FORM{'height'} > $height ) {
                print_panel(
"<font color=red>Error your dimensions exceed the maxium of<br> $width x $height<br> please hit back and corrent the problem</font>",
                    $FORM{user}, 0
                );
                exit;
            }
            $FORM{'desc'} =~ s/\r/�/g;
            $FORM{'desc'} =~ s/\n/�/g;
            print FILE1 $FORM{'title'} . "|"
              . $FORM{'link'} . "|"
              . $FORM{'desc'} . "|"
              . $FORM{'pto'} . "|"
              . $FORM{'width'} . "|"
              . $FORM{'height'} . "|"
              . $FORM{'percent'} . "|"
              . $FORM{'impressions'} . "|"
              . $FORM{'clicks'} . "|";
            $file = "order.ech";
            open( "FILE1", '>>', $file );
            print FILE1 $FORM{'name'} . ".ech" . "\n";
            $imfi = "impressions.ech";
            open( "im", '>>', $imfi );
            print im $FORM{'name'} . ".ech|0\n";
            $cfi = "clicks.ech";
            open( "cl", '>>', $cfi );
            print cl $FORM{'name'} . ".ech|0\n";
            $ifi = $FORM{user} . "items.ech";
            open( "i", '>>', $ifi );
            print i $FORM{'name'} . ".ech\n";
	    writelog($user."logs","$user added an item: $FORM{'name'}");
	     writelog("additem","$user added an item: $FORM{'name'}");
            print_panel( "<font color=green>Addition Successful</font>",
                $FORM{user}, 0 );
        }
    }
}

sub getorder {
    $orderfile  = "order.ech";
    $totalitems = 0;
    $x          = 0;
    open( FILE1, "order.ech" );
    while (<FILE1>) {
        $totalitems++;
        $_ =~ s/\s//g;
        if ( defined($_) ) { $order[$x] = $_; $x++; }
    }
    return (@order);
}

sub getinfo {
    $file = $naa;
    open( "FILE1", $file );
    while ( ( $line = &read_file("FILE1") ) ) {
        @data = split ( /\|/, $line );
        return (@data);
    }
}

sub makesenseofinfo {
    $title = $data[0];
    $link  = $data[1];
    $desc  = $data[2];
    $desc =~ s/�/<br>/g;
    $pathto          = $data[3];
    $widthh          = $data[4];
    $heighth         = $data[5];
    $percent         = $data[6];
    $impressionsdata = $data[7];
    $impressions     = $data[7];
    $clicks          = $data[8];
    if ( !$widthh )  { $widthh  = $widthreset; }
    if ( !$heighth ) { $heighth = $heightreset; }
}

sub display {
    if ( !$FORM{'page'} ) { $FORM{'page'} = 0; }
    if ( !$FORM{'ntd'} )  { $FORM{'ntd'}  = 10; }
    $ntd = $FORM{'ntd'};
    ($status) = @_;
    &getorder;
    if ( $totalitems < 1 ) { $status .= "<br>No Items To Display"; }
    $top = $dynfor{'topdisplay'};
    $top =~ s/\[%status%\]/$status/g;
   if($loggedin==1){
print $loggedin;
$user=$FORM{user};
    $top =~ s/\[%ifnotloggedin%\][\s|\S]*\[%endifnotloggedin%]//g;
    $top =~ s/\[%ifloggedin%\]//g;
    $top =~ s/\[%endifloggedin%]//g;
    $top =~ s/\[%user%\]/$user/g;
}else{
    $top =~ s/\[%ifloggedin%\][\s|\S]*\[%endifloggedin%]//g;
    $top =~ s/\[%ifloggedin%\]//g;
    $top =~ s/\[%endifnotloggedin%]//g;
    $top =~ s/\[%ifnotloggedin%]//g;

}
    print $top;
    $divis = $x;
    $pages = $divis / $ntd;
    $page  = $FORM{'page'};
    if ( !$page ) { $page = 0; }
    $pagenum   = $page * $ntd;
    $pagelimit = $pagenum + $ntd;
    if ( $pagelimit > $x ) { $pagelimit = $x; }

    for ( $y = $pagenum ; $y < $pagelimit ; $y++ ) {
        $printed++;
        $naa = "";
        $order[$y] =~ s/\s//g;
        $naa  = $order[$y];
        $name = $naa;
        $name =~ s/\.ech//;
        $item = $naa;
        $filestoimp .= $naa . "|";
        $naa = "Items/" . $naa;
        open( "FILE1", $naa );
        getinfo();
        makesenseofinfo();
        $tdi = $dynfor{'displayitem'};
        $tdi =~ s/\[%item%\]/$item/g;
        $tdi =~ s/\[%name%\]/$name/g;
        $tdi =~ s/\[%link%\]/$link/g;
        $tdi =~ s/\[%title%\]/$title/g;
        $tdi =~ s/\[%desc%\]/$desc/g;
        $tdi =~ s/\[%ntd%\]/$ntd/g;
        $tdi =~ s/\[%width%\]/$widthh/g;
        $tdi =~ s/\[%height%\]/$heighth/g;
        $tdi =~ s/\[%imgsrc%\]/$pathto/g;
        $tdi =~ s/\[%percent%\]/$percent/g;
        $atleast = 1;
        print $tdi;
    }
    impression($filestoimp);
    for ( $z = 0 ; $z < $pages ; $z++ ) {
        $number = $z;
        $np1    = $number + 1;
        $dynfor{'links'} =~ s/\[%number%\]/$number/g;
        $dynfor{'links'} =~ s/\[%numberplusone%\]/$np1/g;
        $linksstuff .= $dynfor{'links'};
        $dynfor{'links'} =~ s/$number/\[%number%\]/g;
        $dynfor{'links'} =~ s/$np1/\[%numberplusone%\]/g;
    }
    $linksstuff             =~ s/\[%ntd%\]/$ntd/g;
    $dynfor{'linkssection'} =~ s/\[%links%\]/$linksstuff/g;
    $num = $FORM{'page'};
    $dynfor{'ntd'} =~ s/\[%number%\]/$num/g;
    $numberoptions = $dynfor{'ntd'};
    $dynfor{'linkssection'} =~ s/\[%numberoptions%\]/$numberoptions/g;
    $dynfor{'linkssection'} =~ s/\[%printed%\]/$printed/g;
    $dynfor{'linkssection'} =~ s/\[%totalitems%\]/$totalitems/g;
    print $dynfor{'linkssection'};
}
sub start { }

sub open_file {
    local ( $filevar, $filemode, $filename ) = @_;
    open( $filevar, $filemode . $filename );
}
sub read_file { local ($filevar) = @_; <$filevar>; }
sub write_file { local ( $filevar, $line ) = @_; print $filevar ($line); }

sub parse_form {
    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) { $buffer = $ENV{QUERY_STRING}; }
    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );
        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $FORM{$name} = $value;
        $value =~ s/\//\./g;
        $name = $value;
    }
}
sub getcookies {
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookies{$name} = $value;
        }
    }
}