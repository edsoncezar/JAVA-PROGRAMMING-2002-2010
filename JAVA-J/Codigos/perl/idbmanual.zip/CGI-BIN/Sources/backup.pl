sub backup {
    if ( $FORM{'pw'} eq $adminpw ) {
        if ( !$FORM{level} ) {
            print $dynfor{'backup'};
        }
        elsif ( $FORM{'level'} == 1 ) {
my $ofh = select;
  $| = 1;
 select $ofh;

            print qq~
<table bgcolor="$template{'tablebg'}" border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}">
<Tr>
<Td align=center>
Beggining Echelon Backup Algorithm:<br>(The Algorithm)<br>\$filebackup =\~ s#/\\%/\\(.*)/\\%/\\\n([\S|\s]*)/\\@/\\\1/\\@/\\#&aelig;$1&Ntilde;$2#g;<br>
~;
            $backupfile = "$FORM{'dbname'}.echelonbackup";
            open( "backup", '>', $backupfile );
            close(backup);
            $userfile = "users.ech";
            open( "userfile", $userfile );
            while ( ( $line = &read_file("userfile") ) ) {
                @data              = "";
                @data              = split ( /\|/, $line );
                $users{ $data[0] } = $data[1];
            }
            $users{"admin"} = "null\n";
            close(userfile);
            open( "backup", '>>', $backupfile );
my $ofh = select backup;
  $| = 1;
 select $ofh;
            print backup
              qq~########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
IDB BACKUP FILE!
Do not edit!
/\\%/\\users.ech/\\%/\\
~;
            print "Getting users...";
            foreach $user ( keys %users ) {
                print backup "$user|$users{$user}";
            }
            print backup qq~/\\@/\\users.ech/\\@/\\~;
            print "Got and Added<br>";
            close(backup);

            foreach $user ( keys %users ) {
                chomp($user);
print "<b>$user ...</b>";
		if(length($user)>3){
print "Getting " . $user . "'s items...";               
$userfiles[$counter] = $user . "items.ech";
                $counter++;
    print "Got and Added<br>";
            	
	}else{
print "removed a blank line";
}
            }

            $counter = "";
            foreach (@userfiles) {
                $tempfile = $_;
                open( "file", $tempfile );
                while ( ( $line = &read_file("file") ) ) {
                    $usersitems{$_} .= "$line";
                    $allitemfiles[$allitemfilecount] = $line;
                    $allitemfilecount++;
                }
                close(file);
            }
            open( "backup", '>>', $backupfile );
            foreach $user ( keys %users ) {
		chomp($user);
		if(length($user)>3){
                $displayer = $user;
                $displayer .= "items.ech";
                print backup qq~
/\\%/\\$displayer/\\%/\\~;
                $userf = $user . "items.ech";
                print backup $usersitems{$userf};
                print backup qq~/\\@/\\$displayer/\\@/\\~;
}            
}

            close(backup);
getorder();
            foreach (@allitemfiles) {
		if(length($_)>4){
                $tempfile = "Items/".$_;
                print "Getting data for $tempfile ...";
                open( "file", $tempfile );
		$linne=0;
                while (<file>) {
			if($linne != 1){                    
			$itemfile{$tempfile} = $_;
			print "<b>$tempfile</b>";
			$linne=1;
			}
                }
                close(file);
                print "Got and Added<br>";
}
            }
            print "Getting ALL ITEMS DATA...";
            open( "backup", '>>', $backupfile );
            foreach (keys %itemfile) {
                $alphafile = $_;
                $betafile  = $alphafile;
                $alphafile =~ s/\n//g;
                print backup qq~/\\%/\\$alphafile/\\%/\\~;
		print "<b><u>$alphafile</u></b>";
		print backup qq~ $itemfile{$betafile} ~;
		print  backup qq~
/\\@/\\$alphafile/\\@/\\~;
            }
            print " Got and Added<br>";
            getorder();
            print "Getting Order.ech...";
            print backup qq~/\\%/\\order.ech/\\%/\\~;  
		$notfirstline=0;
          foreach (@order) {
		if($notfirstline==1){
                print backup "\n".$_;
		}else{
		print backup $_;
		$notfirstline=1;
		}
            }
            print " Got and Added<br>";
            print backup qq~/\\@/\\order.ech/\\@/\\~;
            getclicks(adminall);
            print "Getting Click data...";
            print backup qq~/\\%/\\clicks.ech/\\%/\\~;

            foreach ( keys %filed ) {
                print backup $_. "|" . $filed{$_};
            }
            print " Got and Added<br>";
            print backup q~/\\@/\\clicks.ech/\\@/\\~;
            print "Getting Impression data...";
            getimpressions(adminall);
            print backup q~/\\%/\\impressions.ech/\\%/\\~;

            foreach ( keys %filed ) {
                print backup $_. "|" . $filed{$_};
            }
            print " Got and Added<br>";
            print backup qq~/\\@/\\impressions.ech/\\@/\\
~;
           
            close(backup);
            print "Backup file closed, Finished";

            #End of echelon backup stuff
        }
    }
}
1;