sub impressions {
    $tem = $dynfor{'impressions'};
    my $usser = $FORM{user};
    getimpressions($usser);
    if ( $something != 1 ) {
        $stuff .=
          "<Tr><td align=center colspan=2>No Items To Display</td></tr>";
    }
    else {
        foreach $item ( keys %filed ) {
            $stuff .=
"<Tr><td align=center>$item</td><td align=center>$filed{$item}</td></tr>";
        }
    }
    $tem =~ s/\[%itemsimpressions%\]/$stuff/;
    print $tem;
}
sub getimpressions {
    my $user = shift;
   if ( $user eq "adminall" ) {
getorder(); 
}else {
        getuserorder($user);
    }
  if($user eq "all"){
$imfi = "impressions.ech";
$total=0;
    open( "im", $imfi );
    while (<im> ) {
 @data = split ( /\|/, $_ );
$total+=$data[1];
}
return($total);
close("im");
}
    $imfi = "impressions.ech";
    open( "im", $imfi );
    while (<im> ) {
        @data = split ( /\|/, $_ );
        for ( $y = 0 ; $y < $x ; $y++ ) {
            chomp( $data[0] );
            $data[0]   =~ s/\s//g;
            $order[$y] =~ s/\s//g;

            if ( defined($data[0]) ) {
                if ( $data[0] eq $order[$y] ) {
                    $naa         = "Items/".$data[0];
                    $currentimps = $data[1];
                    $wako        = $data[0];
                    getinfo();
                    makesenseofinfo();
                    $filed{$wako} = $currentimps . "(" . $impressionsdata . ")";
                    $something = 1;
                }
            }
        }
    }
}
sub impression {
    $file   = shift;
    $naa    = $file;
    @filesa = split ( /\|/, $file );
    $imfi   = "impressions.ech";
    open( "im", $imfi );
    while ( ( $line = &read_file("im") ) ) {
        @dat = "";
        @dat = split ( /\|/, $line );
        chomp($file);
        chomp( $dat[0] );
        foreach (@filesa) {
            $naa = $_;
	    getinfo();
            makesenseofinfo();
            chomp($_);
            chomp( $dat[0] );
 	
            if ( $dat[0] eq $_ ) {
                $dat[1]++;
            }

            if ( $dat[1] eq $impressionsdata ) {
                removefromorder($_);
            }
         
        }
       $filed{$dat[0]} = $dat[1];
    }
    close("im");

    open( "imf", '>', $imfi );
    foreach $item ( keys %filed ) {
        $number = $filed{$item};
        $item   =~ s/\r//g;
        $item   =~ s/\n//g;
        $number =~ s/\r//g;
        $number =~ s/\n//g;
        print imf "$item|$number\n";
        $xt++;
    }
}
1;