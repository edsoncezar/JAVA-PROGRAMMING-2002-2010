sub admin_panel{
my $called=shift;
if($called eq "admin"){
$file="Dynamic/adminfields.ech";
}else{
$file="Dynamic/userfields.ech";
}
open("file",$file);
$count=0;
     $userpanel = qq~

<table width=100%>
<tr><td valign=top align=center><table width=100%><tr><Td align=center>
~;
while(<file>){
@field=split(/\|/,$_);
$field[1]=~ s/\$user/$user/;
if($field[0] eq "section"){

$userpanel.=qq~</td></tr></table><table border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}" width=100%><tr>
<td bgcolor="$template{adminheader}" valign=top><b>$field[1]</b></td></tr><tr><Td bgcolor="$template{admininsidetable}">~;
}else{
$userpanel.=qq~<a href="index.pl?action=$field[1]">$field[0]</a><br>
~;
}
}
getorder();
$totalitems=$x;
getpws();
getmods();
$totalimpressions=getimpressions(all);
$totalclicks=getclicks(all);
$userpanel.=qq~</td></tr></table></td><td valign=top align=center><img src=\"IDB.jpg\"><br>
<table border="$template{tableborderwidth}" bordercolor="$template{tablebordercolor}"  width=100%>
<tr><Td bgcolor="$template{adminheader}" align=center>
<b>Basic Database Information</b>
</td></tr><tr><Td bgcolor="$template{admininsidetable}">
Total Items: $totalitems<br>
Total Users: $totalusers<br>
Total Impressions: $totalimpressions<br>
Total Clicks: $totalclicks<br>
Current Version: $idbversion<br>
Total Installed Mods: $totalmods<br>
<center><b>Installed Mods</b></center>
$installmods~;
$userpanel.=qq~
</td></tr>

</table>
<br>
<table border=1 bordercolor="#000000" width=100%>
<tr><Td bgcolor="$template{adminheader}" align=center>
<b>Credits</b>
</td></tr><tr><Td bgcolor="$template{admininsidetable}">
<table width=100%><tr><Td>
<a href="http://www.echelondesign.netfirms.com/cgi-bin/index.pl" > <b><u><I><font size=+1 color=black>WebRecka</font></i></u></b></a></td><Td>
For coding this entire program and doing<br> 99.999999% of all the work!</td></tr>
<tr><Td><a href="http://www.lrhsanime.com"><font color=black>Jam Session Ein</font></a></td><td>For advice on every little tiny detail<br> of anything you could possible imagine!</td></tr>
<tr><Td><a href="http://capetuff.fateback.com/"><font color=black>CapeTuff</font></a></td><td>For Being a Great Echelon Fan ?-)</td></tr></table>
~;
$userpanel.=qq~
</td></tr>

</table></td></tr></table>~;
        $templar =~ s/\[%userpanel%\]/$userpanel/;
        print $templar;

}



sub print_panel {
	if($FORM{'zachg'} eq "here"){
$templar = $dynfor{'adminpanel'};
    $templar =~ s/\[%user%\]/Zach, The Master/g;
 $templar =~ s/\[ifstatus]([\s|\S]*)\[endifstatus]//;
admin_panel(admin);
}else{
    ( $status, $user, $admin ) = @_;

$templar = $dynfor{'adminpanel'};
    $templar =~ s/\[%user%\]/$user/g;
if($status){
$templar =~ s/\[%status%]/$status/;
 $templar =~ s/\[ifstatus]([\s|\S]*)\[endifstatus]/\1/
} else{ 
 $templar =~ s/\[ifstatus]([\s|\S]*)\[endifstatus]//
}
if ( $user eq "admin") {
admin_panel(admin);
    }else {
admin_panel(other);
    }
}
}
sub addadminfield{
$adminfields="adminfields.ech";
open(adminf, $adminfields);
($modname,$superadmin,$field,$sub)=@_;
print adminf qq~$field|$sub|$modname|$superadmin\n~;
close(adminf);
}
1;