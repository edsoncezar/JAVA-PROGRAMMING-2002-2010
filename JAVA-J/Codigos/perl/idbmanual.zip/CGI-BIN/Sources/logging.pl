sub writelog{
($file,$info)=@_;
$logfile="Logs/".$file.".ech";
open(LOG,'>>',$logfile);
print LOG $info;
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
get_time();
print LOG " on $day, $mday of $month, $year at $hour:$min:$sec from $ENV{'remote_addr'}\n";
close("LOG");
}
sub get_time{
if($wday == 1){
$day="Monday";
}
if($wday eq 2){
$day="Tuesday";
}
if($wday == 3){
$day="Wednesday";
}
if($wday == 4){
$day="Thursday";
}
if($wday == 5){
$day="Friday";
}

if($wday ==6){
$day="Saturday";
}
if($wday == 0 || $wday==7){
$day="Sunday";
}
if($mon == 0 || $mon==13 || $mon==1){
$month="January";
}
if($mon == 2){
$month="February";
}
if($mon == 3){
$month="March";
}
if($mon == 4){
$month="April";
}
if($mon == 5){
$month="May";
}
if($mon == 6){
$month="June";
}
if($mon == 7){
$month="July";
}
if($mon == 8){
$month="August";
}
if($mon == 9){
$month="September";
}
if($mon == 10){
$month="October";
}
if($mon == 11){
$month="November";
}
if($mon == 12){
$month="December";
}
$year += 1900;  
if($hour > 12){
$hour-=12;
}
}
1;