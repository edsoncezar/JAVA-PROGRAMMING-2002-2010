sub viewnewmod{
$dir=".";
opendir("DIR",$dir);
@files=readdir(DIR);
@newmods=grep(/(.*)\.v(.*)\.idbmod\.new\.pl/,@files);

if(@newmods){
print $dynfor{'modyes'};
}else{
print $dynfor{'modno'};
}
$modcount=0;
foreach(@newmods){
$oldu=$_;
$_ =~ s/(.*)\.v(.*)\.idbmod\.new\.pl/$1/;
$modname=$modcount."name";
print qq~<tr><Td>$_</td><td>$2</td><td><input type=checkbox name=$modcount value=Y><input type=hidden name="$modname" value="$oldu"></td></tr>~; 
$modcount++;
}
print $dynfor{'modadd'};
}
sub addamod{
for($x=0; $x<$FORM{total}; $x++){
if($FORM{$x} eq "Y"){
@modstoadd[$totaladd]=$x;
$totaladd++;
}
}
if($FORM{'echelonofficialother'} ne ".idbmod.new.pl"){
@modstoadd[$totaladd]="echelonofficalother";
}
getmods();
foreach(@modstoadd){

$tname=$_."name";
$name=$FORM{$tname};
foreach(@mods){
if($tname eq $_){
$nono=1;
}
}
if($nono != 1){
$firsttime=1;
require "$name";
my $filename=$name;
open("rename",$filename);
$filedata="";
&getstuff($filename);
close("rename");
$fileversion=$filename;
$modsname=$filename;
$backup=$filename;
$modsname=~ s/(.*)\.v.*\.idbmod\.new\.pl/$1/;
$fileversion=~ s/.*\.v(.*)\.idbmod\.new\.pl/$1/;
$filename=~ s/(.*\.v.*\.idbmod)\.new\.pl/$1\.pl/;
open("renameto",'>',$filename);
print renameto $filedata;
close(renameto);
$modfile="mods.ech";
open(modf,'>>',$modfile);
print modf $modsname."|".$fileversion."\n";
print "<tr><Td align=center>$modsname verison $fileversion Added<br>$backup renamed to $filename</td></tr>";
unlink($name);
}
}
}
sub getmods{
my $modfile="mods.ech";
open(modfile,$modfile);
$counter=0;
$totalmods=0;
$installmods="";
  while (<modfile>) {
@data="";
@data=split(/\|/, $_);
$mods[$counter]=$data[0];
$data[1]=~ s/\n//;
$modver[$counter]=$data[1];
$counter++;
$totalmods++;
$installmods.="$data[0] Version $data[1] <br>";
}
if($installmods eq ""){
$installmods="No Mods Installed";
}
}
1;