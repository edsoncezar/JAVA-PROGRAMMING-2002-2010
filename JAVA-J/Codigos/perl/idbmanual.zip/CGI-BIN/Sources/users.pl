sub users{
$uaction=$FORM{tuser};
if($uaction eq "viewall"){&view_all_users}
elsif($uaction eq "remove"){&remove_a_user}
elsif($uaction eq "password"){&change_a_password}
elsif($uaction eq "view_user_alphabet"){&print_panel_alphabet}else{
print $u2action;
if($FORM{'u2action'} ne "remove"){
print_user_panel($uaction);
}else{
print_remove_panel($uaction);
}
}
}
sub remove_user{
$user=shift;
$file="users.ech";
$count=0;
open("users",$file) || dienice("PROBLEM: $!");
while(<users>){
chomp($_);
$current=$_;
@data=split(/\|/,$_) ;
if($data[0] ne $user){
$users[$count]=$current;
$count++;
}
}
close("users");
open("users2",'>',$file)  || dienice("PROBLEM: $!");
foreach(@users){
print users2 $_."\n";
}
close("users2");
 writelog("removeuser","admin removed: $user");
}
sub print_remove_panel{
$user=shift;
if($FORM{'check'} eq "complete"){
if($FORM{'items'} eq "remove"){
remove_user($user);
#remove_items($user);
}else{
remove_user($user);
}
}else{
$dynfor{'userpanel'}=~ s/\[%ifremove%]//g;
$dynfor{'userpanel'}=~ s/\[%endifremove%]//g;
$txt=qq~
<form action="index.pl?action=usermanage&tuser=$user&u2action=remove&check=complete" method="POST">
<b>Are you <u>SURE</u> you want to remove<br>$user<br>from the Database?<br>
<input type=checkbox name=items value=remove>Remove the users items<br>
<input type=submit value="Remove $user">
~;

$dynfor{'userpanel'}=~ s/\[%text%]/$txt/g;
$dynfor{'userpanel'}=~ s/\[%user%]/$user/g;
print_user_panel($user);
#print $dynfor{'userpanel'};
}
}
sub remove_a_user{
create_a_list_of_user_initials();
get_list_of_users(all);
$dynfor{'alphalist'}=~s/\[%title%]/Select A Letter To Look Through or select from the list/;
foreach $initial (@initial_list){
if($initial eq "#"){
$initial2="num";
}else{
$initial2=$initial;
}
$initials[$initial_count]=qq~<a href="index.pl?action=usermanage&tuser=view_user_alphabet&u2action=remove&initial=$initial2">$initial</a>~;
$initial_count++;
}
$dynfor{'alphalist'}=~s/\[%letters%]/@initials/;
foreach $name (@names){
$listofnames[$name_count]=qq~<a href="index.pl?action=usermanage&tuser=$name&u2action=remove">$name</a><br>~;
$name_count++;
}
$dynfor{'alphalist'}=~s/\[%list%]/@listofnames/;
print $dynfor{'alphalist'};
}
sub print_panel_alphabet{
create_a_list_of_user_initials();
get_list_of_users($FORM{initial});
$title="Select A Letter To Look Through <br>or<br> Select From the Entire List";
$dynfor{'alphalist'}=~s/\[%title%]/$title/;
foreach $initial (@initial_list){if($initial eq "#"){$initial2="num";}else{
$initial2=$initial;}
$initials[$initial_count]=qq~<a href="index.pl?action=usermanage&tuser=view_user_alphabet&initial=$initial2&u2action=$FORM{'u2action'}">$initial</a>~;
$initial_count++;
}
$dynfor{'alphalist'}=~s/\[%letters%]/@initials/;
foreach $name (@names){
$listofnames[$name_count]=qq~<a href="index.pl?action=usermanage&tuser=$name&u2action=$FORM{'u2action'}">$name</a><br>~;
$name_count++;
}
$dynfor{'alphalist'}=~s/\[%list%]/@listofnames/;
print $dynfor{'alphalist'};

}

sub print_user_panel{
$user=shift;
$dynfor{'userpanel'}=~s/\[%ifremove%][\s|\S]*\[%endifremove%]//;
$dynfor{'userpanel'}=~ s/\[%user%]/$user/g;
$file=$user."items.ech";
open("file",$file);
$item_count=0;
while(<file>){
$_=~s/\.ech//;
$items[$item_count]=qq~<a href="index.pl?action=viewitem&item=$_&user=$user">$_</a><br>~;
$item_count++;
}
$file="users.ech";
open("file",$file);
while(<file>){
@data=split(/\|/,$_);
$userrank{$data[0]}=$data[2]."|".$data[3];
}
@split=split(/\|/,$userrank{$user});
$rank=$split[1];
$email=$split[0];
if($user eq "Admin"){
$rank="Super Admin";
}
$dynfor{'userpanel'}=~ s/\[%rank%]/$rank/g;
$dynfor{'userpanel'}=~ s/\[%item_count%]/$item_count/g;
$dynfor{'userpanel'}=~ s/\[%user_item_list%]/@items/g;
$dynfor{'userpanel'}=~ s/\[%email%]/$email/g;

print $dynfor{'userpanel'};
}
sub view_all_users{
create_a_list_of_user_initials();
get_list_of_users(all);
$title="Select A Letter To Look Through <br>or<br> Select From the Entire List";
$dynfor{'alphalist'}=~s/\[%title%]/$title/;
foreach $initial (@initial_list){
if($initial eq "#"){
$initial2="num";
}else{
$initial2=$initial;
}
$initials[$initial_count]=qq~<a href="index.pl?action=usermanage&tuser=view_user_alphabet&initial=$initial2">$initial</a>~;
$initial_count++;
}
$dynfor{'alphalist'}=~s/\[%letters%]/@initials/;
foreach $name (@names){
$listofnames[$name_count]=qq~<a href="index.pl?action=usermanage&tuser=$name">$name</a><br>~;
$name_count++;
}
$dynfor{'alphalist'}=~s/\[%list%]/@listofnames/;
print $dynfor{'alphalist'};
}
sub get_list_of_users{
@names="";
$usertofind=shift;
if($usertofind eq "num"){
$usertofind="#";
}
if($usertofind eq "all" || $usertofind eq "All"){
$userfile="users.ech";
open("ufile",$userfile);
$nextletter=0;
$n_counter=0;
while(<ufile>){
chomp($_);
@data=split(/\|/,$_);
$names[$n_counter]=$data[0];
$n_counter++;
}
$names[$n_counter]="Admin";
close("ufile");
@names = sort { lc($a) cmp lc($b) } @names; 
}else{
$userfile="users.ech";
open("ufile",$userfile);
$nextletter=0;
$n_counter=0;
while(<ufile>){
chomp($_);
@data=split(/\|/,$_);
$inti=$data[0];
$inti=~ s/(.).*/\1/;
if($inti !~ m/[A-Za-z]/){
$inti="#";
}
if(lc($inti) eq lc($usertofind)){
$names[$n_counter]=$data[0];
$n_counter++;
}
}
if($usertofind eq "A"){
$names[$n_counter]="Admin";
}
close("ufile");

@names = sort { lc($a) cmp lc($b) } @names; 

}
}

sub create_a_list_of_user_initials{
print "<br>";
$userfile="users.ech";
open("ufile",$userfile);
$nextletter=0;
$n_counter=0;
while(<ufile>){
chomp($_);
@data=split(/\|/,$_);
$names[$n_counter]=$data[0];
$n_counter++;
}
close("ufile");
@sorted = sort { lc($b) cmp lc($a) } @names; 
$countme=0;
foreach(@sorted){
$currentleter=$_;
$currentleter=~ s/(.).*/\1/;
if($currentleter !~ m/[A-Za-z]/){
$currentleter="#";
}
chomp($currentleter);
$letters[$countme]=uc $currentleter;
$countme++;
}
$letters[$countme]="A";
foreach $letter (@letters){
chomp($letter);
$found=0;
foreach(@storage){
if($_ eq $letter){
$found=1;
}
}
$storage[$another_counter]=$letter;
$another_counter++;
if($found != 1 ){
chomp($letter);
$finallist[$last_counter]=$letter;
$last_counter++;
}
}
@initial_list = sort { lc($a) cmp lc($b)} @finallist; 
$initial_list[$last_counter]="All";
}
1;