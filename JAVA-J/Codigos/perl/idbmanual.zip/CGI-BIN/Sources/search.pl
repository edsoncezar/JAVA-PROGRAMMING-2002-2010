#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
#WORK ON ME!
&parse_form;
print "Content-type:text/html\n\n";
require "templates.pl";
print $template{'header'};
@word = split (/\s/, $FORM{'words'});
foreach $123 (@word){
$search.=$123." ";
}
$orderfile="../order.ech";
open( "FILE1", $orderfile) || die $!;   
while ( ( $line = &read_file("FILE1") ) ) {

$order[$z]=$line;

$z++;    
}
   for($x=0; $x<$z; $x++){
$sl=$order[$x];
          &chec_record;
          if ($found == "1") {
            $counter++;
            print_record($order[$x]);
          }else{
}
if($counter < 1){
print "<tr><Td>No Matches Found</td></tr>";
}else{
if($counter <2){
print "<tr><Td colspan=2 align=center>$counter Match Found</td></tr>";
}else{
print "<tr><Td colspan=2 align=center>$counter Matches Found</td></tr>";
}
}
    }
print $template{'footer'};
sub getinfo {
$file=$naa;
open("FILE1", $file) || dienice("problem $!"); 
@data="";    
while (<FILE1>) {
        @data = split (/\|/, $_);
    }
return(@data);
}
sub makesenseofinfo{
$title=$data[0];
$link=$data[1];
$desc=$data[2];
$desc=~ s/�/<br>/g;
$pathto=$data[3];
$widthh=$data[4];
$heighth=$data[5];
if(!$widthh){
$widthh=$widthreset;
}
if(!$heighth){
$heighth=$heightreset;
}
}

sub print_record{
$naa="../";
$naa.=$order[$x];
getinfo();
makesenseofinfo();
$tdi=$dynfor{'printrecord'};
$tdi =~ s/\[%link%\]/$link/g;
$tdi =~ s/\[%title%\]/$title/g;
$tdi =~ s/\[%desc%\]/$desc/g;
$tdi =~ s/\[%ntd%\]/$ntd/g;
$tdi =~ s/\[%width%\]/$widthh/g;
$tdi =~ s/\[%height%\]/$heighth/g;
$tdi =~ s/\[%im%\]/$pathto/g;
$tdi =~ s/\[%imgsrc%\]/$pathto/g;
print $tdi;
}




sub chec_record {
   $sfound = 0;

   $found = 0;
   $notfound = 1; 
@words = split(/ /,$search);


 	foreach $aword (@words) {
chomp($aword);
chomp($sl);
$aword =~ s/\s//;
$sl =~ s/\s//;
$sl =~ s/\.ech$//;
$aword2=lc($aword);
 if (lc($aword) eq lc($sl)) {
                  $found = 1;
           }else {
          
      $notfound = 0;
            }
if(lc($sl) =~ m/$aword2/){
                  $found = 1;
         }else {
          
      $notfound = 0;
}
        
}


}
sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
        $name=$value; 
    }
}



sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
