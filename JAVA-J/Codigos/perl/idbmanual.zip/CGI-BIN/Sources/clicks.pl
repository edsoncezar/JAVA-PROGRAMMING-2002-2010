sub clickthrough {
    $item = $FORM{item};
    $url  = $FORM{url};
    $file = "clicks.ech";
    $naa  = $item;
    getinfo();
    makesenseofinfo();
    $file = "clicks.ech";
    open( "file", $file );

    while (<file> ) {
        @dat = "";
        @dat = split ( /\|/, $_ );
        chomp( $dat[0] );
        chomp($item);
        if ( $dat[0] eq $item ) {
            $dat[1]++;
            $found = 1;
        }
        if ( $dat[1] eq $clicks ) {
            removefromorder( $data[0] );
        }
        $filed{ $dat[0] } = $dat[1];
    }
    if ( $found != 1 ) {
        open( "file1", '>>', $file );
        print file1 "$item|1";
   
 }
    else {
        open( "file1", '>', $file );
        foreach $items ( keys %filed ) {
            $number = $filed{$items};
            $items  =~ s/\r//g;
            $items  =~ s/\n//g;
            $number =~ s/\r//g;
            $number =~ s/\n//g;
            print file1 "$items|$number\n";
        }
    }
   print "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"0 URL=$url\">";
}
sub clicks {
    $tem = $dynfor{'clicks'};
    my $user = $FORM{user};
    ($admin) = @_;
    if ( $admin ne "admin" ) {
        getclicks($user);
    }
    else {
        if ( $FORM{pw} eq $adminpw ) {
            getclicks(adminall);
        }
    }
    if ( $something != 1 ) {
        $stuff .=
          "<Tr><td align=center colspan=2>No Items To Display</td></tr>";
    }
    else {
        foreach $item ( keys %filed ) {
            $stuff .=
"<Tr><td align=center>$item</td><td align=center>$filed{$item}</td></tr>";
        }
    }
    $tem =~ s/\[%itemsclicks%\]/$stuff/;
    print $tem;
}
sub getclicks {
    my $user = shift;
if($user eq "all"){
$imfi = "clicks.ech";
$total=0;
    open( "im", $imfi );
  while (<im>) {
@data = split ( /\|/,$_);
$total+=$data[1];
}
close("im");
return($total);
}
    
if ( $user eq "adminall" ) {
        getorder();
    }
    else {
        getuserorder($user);
    }
    $imfi = "clicks.ech";
    open( "im", $imfi );
    while ( ( $line = &read_file("im") ) ) {
        @data = split ( /\|/, $line );
        for ( $y = 0 ; $y < $x ; $y++ ) {
            chomp( $data[0] );
            chomp( $order[$y] );
            $data[0]   =~ s/\s//g;
            $order[$y] =~ s/\s//g;
            if ( $data[0] eq $order[$y] ) {
                $naa           = "Items/".$data[0];
                $currentclicks = $data[1];
                $wakofile      = $data[0];
                getinfo();
                makesenseofinfo();
                $filed{$wakofile} = $currentclicks . "(" . $clicks . ")";
                $something = 1;
            }
        }
    }

}
1;
