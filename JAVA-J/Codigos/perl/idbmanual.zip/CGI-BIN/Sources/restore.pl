
sub restore {
    if ( $FORM{'pw'} eq $adminpw ) {
        if ( !$FORM{level} ) {
            print qq~
<table bgcolor="#eeeeee" border=1 bordercolor=black>
<Tr>
<Td align=center>
Restore a Database
</td></tr>
<tr><td align=center>
Database Backup FileName(with .echelonbackup or other extention)
<form action=index.pl method=post>
<input type=hidden name=action value=restore>
<input type=hidden name=level value=1>
<input type=hidden name=pw value=$FORM{'pw'}>
<input name=dbname value=".echelonbackup"><br>
<input type=submit value="Restore Backup">
</form>
<br>
<font color=red>WARNING THIS WILL REMOVE AND OVERWRITE THE CURRENT DATABASE</font>
<hr width=100% color=black>
Database Backup Name(with .echelonbackup or other extention)
<form action=index.pl method=post>
<input type=hidden name=action value=restore>
<input type=hidden name=level value=2>
<input type=hidden name=pw value=$FORM{'pw'}>
<input name=dbname value=".echelonbackup"><br>
<input type=submit value="Restore Backup">
<br>
<font color=green>This will add the backed up items to the current ones</font>
</td></tr></table>
~;
        }
        elsif ( $FORM{level} == 1 ) {

            $file2 = "order.ech";
            open( file, '>', $file2 );
            $backupfile = "$FORM{'dbname'}";
            open( backupp, $backupfile );
            while ( ( $line = &read_file("backupp") ) ) {
                $file .= $line;
            }
            $filebackup = $file;
            $file       = $filebackup;
            $counter    = 0;

  	    $filebackup =~
 s�/\\%/\\(.*)/\\%/\\([\S|\s]*)/\\@/\\\1/\\@/\\��$1�$2�g;

            @fileinfo = split ( /\�/, $filebackup );
            foreach (@fileinfo) {
$tall++;
                @current = split ( /�/, $_ );
 open( temp, '>', $current[0] );
               print temp $current[1];
            }
            print qq~
<table bgcolor="#eeeeee" border=1 bordercolor=black>
<Tr>
<Td align=center>
Restore a Database
</td></tr>
<tr><td align=center>
$FORM{dbname} Restoration Complete! $tall
</td></tr></table>
~;
$filebackup=~ s/\n/<br>/g;
print $filebackup;
        }
        elsif ( $FORM{level} == 2 ) {
            $backupfile = "$FORM{'dbname'}";
            open( backup, $backupfile );
            while ( ( $line = &read_file("backup") ) ) {
                $file .= $line;
            }
            close(backup);
            $filebackup = $file;
            $file       = $filebackup;
            $counter    = 0;
            $filebackup =~
              s#/\\%/\\(.*)/\\%/\\([\S|\s]*)/\\@/\\\1/\\@/\\#�$1�$2#g;
            $totalitems = 0;
            &getorder;
            @fileinfo = split ( /�/, $filebackup );

            foreach (@fileinfo) {
                @current = split ( /�/, $_ );
  
         for ( $x = 0 ; $x < $totalitems ; $x++ ) {
                    if ( $current[0] eq $order[$x] ) {
                        $overwrite = "yes";
                    }
                }
                if ( $current[0] eq "templates.pl" ) {
                    $overwrite = "yes";
                }

                if ( $overwrite eq "yes" ) {
                    open( temp, '>', $current[0] );
                    print temp $current[1];
                }
                else {
                    open( temp, '>>', $current[0] );
                    print temp $current[1];
                }
            }
            print qq~
<html><body bgcolor="#444455">
<center><img src="http://www.echelondesign.netfirms.com/logo.jpg">
<table bgcolor="#eeeeee" border=1 bordercolor=black>
<Tr>
<Td align=center>
Restore a Database
</td></tr>
<tr><td align=center>
$FORM{dbname} Restoration Complete!
</td></tr></table>
~;
        }
    }
    else {
        print $template{badpw};
    }
}

1;