########################################
############Echelon Design##############
#Product= IDB                          #
#Version= 4.0                          #
#File=Templates			       #
########################################
########################################

##########Some Basic Settings###########
#The Password for the ultimate username-'admin'
$adminpw="admin";
#These are Maximum dimensions for images
$width=100;
$height=100;
#if they dont specify a height these are used
$widthreset=50;
$heightreset=50;
#this is the default number of images per page if none specified
$defnum=10;

#######Some Basic Template Colors#######
$template{bodybgcolor}="#444455";
$template{tableborderwidth}="1";
$template{tablebordercolor}="#000000";
$template{tablebg}="#eeeeee";
$template{adminheader}="#444455";
$template{admininsidetable}="#A9A99D";

####No further editing is required but
####You may wish to change the following html
####sections


#printed at the top of every page
$template{'header'}=qq~
<html>
<head>
<style>
BODY          { scrollbar-face-color: #AFC6DB; scrollbar-shadow-color: #000000; scrollbar-highlight-color: #DEE7EF;
                scrollbar-3dlight-color: #FFFFFF; scrollbar-darkshadow-color: #AFC6DB;
                scrollbar-track-color: #F5F5F5; scrollbar-arrow-color: ##DEE7EF; font-family: Verdana, Helvetica, Arial; 
                font-size:12px; margin-top: 0; margin-left: 0; margin-right: 0; padding-top: 0; padding-left: 0; 
                padding-right: 0; }
a {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-weight: normal; font-variant: normal; text-transform: none; color: #000000; text-decoration: none: none}
A:link        { font-weight: normal; text-decoration: none; color: #005177; }
A:visited        { font-weight: normal; text-decoration: none; color: #005177; }
A:hover       { text-decoration: none; color: #000000; }


</style>
</head>
<body bgcolor="#444455">
<center>
<img src="logo.jpg">

~;

#printed at the bottom of every page
$template{'footer'}=qq~
</center>
</tr>
</td>
</table>
</tr>
</td>
</table>
<center>&copy;2003 Echelon Design<br>Item Database Manager<br>IDB</center>
</body></html>
~;

1;