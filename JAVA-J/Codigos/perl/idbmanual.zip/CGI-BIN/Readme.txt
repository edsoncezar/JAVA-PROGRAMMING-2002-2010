Item DataBase Manager version Four Point Zero 4.0!!!!!!:

Table of Contents:
I::Install
II::Basic Usage Instructions
III::Adding items
IV::Templating
V::Change List
VI::ToDo List
VII::Modding
IX::Other
--------------------------
###########I##########
########Install#######
######################
--------------------------
0) extract files 
1) change path to perl if nessesary in each index.pl and search.pl 
2a) Go through the templats.pl and edit template sections, everything that is printed has a template. 
2b) Change settings at top of templates.pl  The adminpassword is necessary to access the admin user. for backing up and other options.
3) Upload all files and chmod to 755 

------Upgrading------
This part is tough.  For you to manualy upgrade from anything under version 4.0 to version 4.X+ youde need to 
create folders and be moving files like crazy.  Fortunatly, Echelon has provided you with a handy tool available
at Echelon for you to download to upgrade.  It does all the file moving for you.  But, it doesnt do everything.  You still
need to do, manually the following:
-Create all the directories that come in version 4.0.
-Fill the directories "Sources" and "Dynamic" with the items that came in the .zip
-Replace the index.pl, template.pl <-No S, not templates, but now template and any other pls you may have.
-Download the tool, called "IdbUpgrade.pl" and place it in the core directory(with index.pl).
-Run, via a web browser, to IdbUpgrade.pl.  Follow the onscreen instructions and your done!
---------------------

--------------------------------
###############II################
####Basic Usage Instructions#####
#################################
---------------------------------
Logging in: 
In the standard template it comes with a login in the display feature.  
1a)Simply create a user by clicking register.
1b)Or you can login with the admin using the password in templates.pl
-----------------------
The Admin Panel or Menu
-----------------------
Display(front/guest end) 
Click this to view the items

Search for items
Click this to view a search form were you can search by item 'name'. 
Note: This is the same form that comes with the standard template on the main display page

Add An Item
Click this to add an item.  A more detailed documentation on the add form is listed in the add an item section.

Updating items
Displays a dropdown with all available items for you as user X.  Only displays YOUR ITEMS.  The admin has the ability
to update any item.  Once you select an item it will bring you to the add an item form only the old data is in the fields.

Reorder Items 
This allows you to reorder your items only.  The admin can do this with every item.

View Impression/Clickthrough Information
This brings up a table on YOUR ITEM's information.  Displays how many impressions it has(times its been viewed) and click throughs.
Remove an item
Only Displays YOUR ITEMS!  Again it displays the list of your items to be removed from display.

Admin Functions Only:
Backup the database: Creates a NAME.echelonbackup file which stores all the information about your current database.  Use this file
to restore the database at another time.
Restore the database:  This allows you to either add on old items, or completly restore in its exact form an old database.
----------------------
########III###########
####Adding Items######
######################
----------------------
The Form:   
Item Name  
-What the filename for the item will be, also the keywords that the item will be indexed as in the search  
What is the item "title"?  
The title that is displayed in the main page.
Name links to were?  
Were does the title and picture link to?
Description  
The description that is displayed?
Other Info?  
The other info (what comes standard as in parenthesis after the title)
Path to image?  
What is the image?  
The Image Dimensions (width first)
The image's size, cannot excede the maximum as set by templatex.pl  

Number of Impressions Before removal from display(* for never)  
Number of Clicks Before removal from display(* for never) 
If either Clicks or impressions ever hits their respective numbers, they are dropped from the display.
-------------------
########IV#########
####Templating#####
###################
-------------------
One of the main reasons IDB is so great is its magnificent templating system.  It may seem complex at first but is
100% changeable in every way.  Lets start from the ground up.
In order to have a database program we will need a couple things for the user end:
a)a structure or layout(think of it as a blueprint)
b)a color scheme/css (a 3d model of the program)

95% of all users will not even want to bother with A, so ill discuss B now.  In order to edit the scheme of colors
throughout IDB youll need to edit "template.pl".  This is SOO much simpler in version 4.0 than anything under it.  In it 
is a bunch of $template{SOMETHING}=SOMETHING.  Its fairly explanitory how to change which, a visual web based editor for this
will be out soon.  Under those simple variables is 2 other sections, a header and footer.  The header is printed at the top
of every page and contains a simple CSS for font editing and such and the footer contains the copyright which we recommend
you do not touch.

For the other 5% who may wish to edit the structure we have DYNFOR, or Dynamic Formatting.  In the Dynamic Folder we have a 
file, Formatting.pl.  This contains the hard html for each page in IDB.  It uses the variables as set in template.pl although
if you do wish to hardcode colors into sections, or if you want one page to be different, these is the file in which you
need to edit.  There are comments above each section explaining what it does.
-------------------
########V##########
####Chane List#####
###################
-------------------
v4.0
-Made password forms "passwords"
-Top of remove page listed items
-Fixed top of view all items page
-Search was all messed up
-Created Source directory and updated files accordingly.  This makes it slightly harder to install but much easier to develope with.
-begging to lose track of all of them this day
-Updated stuff to point to dir Items/
-Fixed Many bugs
	-Impressions
	-Clicks
	-Reordering
	-Item Viewing
	-Searching
-Updated Admin Panel Seriously
-Updated user registering
-reworked the way items are added
-Created Dynamic Formatting-Structures and Template.pl
-No more long messy templates, edit a couple variables instead
-Made each form in the add an item section dynamic, thus its in the Dynamic folder under itemfields.ech
-Removed a bunch of Dynamic fields and replaced then with "print_panel"s.
-Created Alphabetical user/item find
-Created User Panels
-Created Remove a user
-Created Remove a user and items
-Updated "Register" fields
-No longer can you enter invalid characters in user/password forms
-Logging of adding items, users removing stuff logging in and out in the
-Logs section
-Finally finished ironing out the bugs in the backup system
-Caught a couple more bugs in the impressions system.
v3.1
Additions:
-Version Checking
-Mods
	-Adding
	-Version Checking
fixes:
-fixed the add onto database function, it didnt work right
-fixed impressions/clicks so if their are none its not weird.
-Reording items is sort of, weird.  Fixed.
Updates
-admin menu is a beat neater for admin
v3.0
- added impressions/clicks before being removed in ().
	-not the ones left, but the total
- added the maximum dimensions on the add form
- fixed bugs
	-Making 100s of thousands of items resulting in crash
	-bug in templates.pl for updating
- Added backup/restore features

-------------------
########VI#########
####To Do List#####
###################
-------------------

-------------------
########VII########
######Modding######
###################
-------------------
The modding for IDB is really quite unique.  The script will automatically
detect new mods.  Basic info on the mod MUST BE IN THE
FILENAME!  This is the EXACT FORMAT
MODNAME.vVERSION.idbmod.new.pl
Example:
Weather Mod.v1.0.idbmod.new.pl
Weather mod is an actual mod that is not included in the idb package.
It converts idb into a weather posting program.  You can post
temperature data and chose a picture for the day's weather.

Basic Declaration:
The mod version(picture) is updated by me.  Simply send me a new version number Ill make the pictures and all unless you need too.
$firsttime=1;, is declared in index.pl, this allows the script to determine if it is its first time being run.
Nothing is to be printed in the subroutines that follow $firsttime.  Files can be created but nothing is to be printed to the
screen as this would mess up the add mod screen.
Basicly we are just playing the override game.  Averything idb does is called in the first
20 lines.  SO we can simply call our functions for the new mod instead of the old ones, 
then add an exit; at the end so the old ones aren't called.  Works very well.  Simply
go to templates.pl change the actions(like i did with weather, from add to weather add).
Ide automaticaly "requires" the mod.pl file FIRST! which means it literally runs the mod code.
So if it finds &wadd if ($action eq "add" || $action eq "weatheradd") it will do that
then return back to idbs original code IF IT DIDNT FIND AN EXIT!  Which means you can virtually do anything.
New commands:  Addadminitem(Something,something.something)
	       Adduseritem(something);
Good Luck, if you need help simply post on echelon forums, http://quizwiz.i-m-d.net/yabb/YaBB.pl
Web


-------------------
########IX#########
######Other######
###################
-------------------
Dynamic/itemfields contains the HTML for an add an item page.
This information may be useful for modding.
