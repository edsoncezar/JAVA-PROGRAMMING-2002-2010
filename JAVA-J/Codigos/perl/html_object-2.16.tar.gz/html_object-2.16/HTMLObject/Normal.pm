# Normal.pm - The Normal Class derived from the Base HTML object.
# Created by James Pattie, 04/28/2000.

# Copyright (c) 2000 PC & Web Xperience, Inc. http://www.pcxperience.com/
# All rights reserved.  This program is free software; you can redistribute it
# and/or modify it under the same terms as Perl itself.

# updated 02/24/2001 - naming scheme change.
# updated 11/20/2001 - added support in display routines for using different HTML versions.

package HTMLObject::Normal;
use HTMLObject::Base;
use strict;
use vars qw($AUTOLOAD $VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(HTMLObject::Base Exporter AutoLoader);
@EXPORT = qw(
);

$VERSION = '2.16';

# new
sub new
{
  my $class = shift;
  my $self = $class->SUPER::new(@_);

  $self->setErrorMessage(code => '3003', message => "In Buffering Mode");
  $self->setErrorMessage(code => '3004', message => "In non-Buffering Mode");
  $self->setErrorMessage(code => '3005', message => "Invalid variable or function");
  $self->setErrorMessage(code => '3006', message => "Invalid value");

  $self->setTitle("HTMLObject::Normal") if ($self eq "HTMLObject::Normal");

  $self->{javascriptBody} = "";
  $self->{javascriptOnload} = "";
  $self->{javascriptOnloadParameters} = "";
  $self->{javascriptOnloadOptions} = "";
  $self->{javascriptOnunload} = "";
  $self->{javascriptOnunloadParameters} = "";
  $self->{javascriptOnunloadOptions} = "";
  $self->{javascriptVersion} = "1.1";
  $self->{javascriptIncludes} = [];
  $self->{javascriptRequiredMessage} = "";
  $self->{javascriptRequiredVersion} = "";
  $self->{javascriptErrorHandler} = 1;
  $self->{javascriptErrorHandlerVersion} = "both";
  $self->{javascriptErrorHandlerEmail} = "nobody\@not-a-valid-address.com";
  $self->{javascriptErrorHandlerCode} = "";
  $self->{javascriptErrorHandlerBaseWindowName} = "";

  return $self;
}

#reset
sub reset
{
  my $self = shift;

  $self->SUPER::reset(@_);
  $self->setErrorMessage(code => '3003', message => "In Buffering Mode");
  $self->setErrorMessage(code => '3004', message => "In non-Buffering Mode");
  $self->setErrorMessage(code => '3005', message => "Invalid variable or function");
  $self->setErrorMessage(code => '3006', message => "Invalid value");

  $self->setTitle("HTMLObject::Normal") if ($self eq "HTMLObject::Normal");

  $self->{javascriptBody} = "";
  $self->{javascriptOnload} = "";
  $self->{javascriptOnloadParameters} = "";
  $self->{javascriptOnloadOptions} = "";
  $self->{javascriptOnunload} = "";
  $self->{javascriptOnunloadParameters} = "";
  $self->{javascriptOnunloadOptions} = "";
  $self->{javascriptVersion} = "1.1";
  $self->{javascriptIncludes} = [];
  $self->{javascriptRequiredMessage} = "";
  $self->{javascriptRequiredVersion} = "";
  $self->{javascriptErrorHandler} = 1;
  $self->{javascriptErrorHandlerVersion} = "both";
  $self->{javascriptErrorHandlerEmail} = "nobody\@not-a-valid-address.com";
  $self->{javascriptErrorHandlerCode} = "";
  $self->{javascriptErrorHandlerBaseWindowName} = "";
}

# displayJavaScriptRequirements
sub displayJavaScriptRequirements
{
  my $self = shift;

  my $output = "";

  if (length $self->{javascriptRequiredMessage} > 0)
  {
    my $requiredVersion = '1.0';
    $output = "<script language=\"JavaScript\" type=\"text/javascript\">\n  <!--\n  var _version = 1.0;\n  // -->\n</script>\n";
    if (length $self->{javascriptRequiredVersion} > 0)
    {
      $requiredVersion = $self->{javascriptRequiredVersion};
      $output .= "<script language=\"JavaScript$requiredVersion\" type=\"text/javascript\">\n  <!--\n  _version = $requiredVersion;\n  // -->\n</script>\n";
    }
    $output .= "<script language=\"JavaScript\" type=\"text/javascript\">\n";
    $output .= "  <!--\n" if (!$self->{xhtml});
    $output .= "  <![CDATA[\n" if ($self->{xhtml});
    $output .= "  if (_version < $requiredVersion)\n";
    $output .= "  {\n";
    $output .= "    document.write('$self->{javascriptRequiredMessage}');\n";
    $output .= "    document.write('<br />');\n";
    $output .= "    document.write('<br />');\n";
    $output .= "    document.write('JavaScript Version $requiredVersion was not found!');\n";
    $output .= "  }\n";
    $output .= "  // -->\n" if (!$self->{xhtml});
    $output .= "  ]]>\n" if ($self->{xhtml});
    $output .= "</script>\n";
    $output .= "<noscript>\n$self->{javascriptRequiredMessage}\n</noscript>\n";

    $output =~ s/^(.*)$/    $1/mg;  # do the indentation.
  }

  return $output;
}

# displayJavaScriptIncludes
sub displayJavaScriptIncludes
{
  my $self = shift;

  my $output = "";

  if (scalar @{$self->{javascriptIncludes}} > 0)
  {
    foreach my $include (@{$self->{javascriptIncludes}})
    {
      $output .= "    $include\n";
    }
  }

  return $output;
}

# displayJavaScriptErrorHandler
sub displayJavaScriptErrorHandler
{
  my $self = shift;

  my $output = "";

  if ($self->{javascriptErrorHandler})
  {
    if (length $self->{javascriptErrorHandlerCode} > 0)
    {
      $output .= <<"END_OF_CODE";
  <script language="JavaScript1.1" type="text/javascript">
END_OF_CODE
      if ($self->{xhtml})
      {
        $output .= "  <![CDATA[\n";
      }
      else
      {
        $output .= "  <!--\n";
      }
      $output .= <<"END_OF_CODE";

  // Define the error handler.
  function reportError(msg, url, line)
  {
END_OF_CODE
      $output .= $self->{javascriptErrorHandlerCode};
      $output .= <<"END_OF_CODE";
  }

  // Now register the Error Handler for this window.
  self.onerror = reportError;  // Handle Netscape 4 and IE 4

END_OF_CODE
      if ($self->{xhtml})
      {
        $output .= "  ]]>\n";
      }
      else
      {
        $output .= "  // -->\n";
      }
      $output .= <<"END_OF_CODE";
  </script>
END_OF_CODE
    }
    else
    {
      if ($self->{javascriptErrorHandlerVersion} =~ /^(both|v4)$/)
      {
        $output .= <<"END_OF_CODE";
  <script language="JavaScript1.1" type="text/javascript">
END_OF_CODE
        if ($self->{xhtml})
        {
          $output .= "  <![CDATA[\n";
        }
        else
        {
          $output .= "  <!--\n";
        }
        $output .= <<"END_OF_CODE";

  // This code taken and modified from the book "JavaScript the Definitive Guide 3rd Edition" by David Flanagan.  An O'Reilly Publication.

  // This ensures a unique window for each error.
  var errorCount = 0;

  // email address to mail this error report to.
  var email = "$self->{javascriptErrorHandlerEmail}";

  // Define the error handler.
  function reportError(msg, url, line)
  {
END_OF_CODE
    my $baseName = $self->{javascriptErrorHandlerBaseWindowName} . "Error";
    my $language = $self->getLanguage();
    my $charEncoding = $self->getCharEncoding();

    $output .= <<"END_OF_CODE";
    var w = window.open("", "$baseName"+errorCount++, "resizable,status,width=625,height=475");
    var d = w.document;

    d.open();
    d.writeln('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">');
    d.writeln('<html lang="$language">');
    d.writeln('<head>');
    d.writeln('<meta http-equiv="Content-Type" content="text/html; charset=$charEncoding">');
    d.writeln('</head>');
    d.writeln('<body bgcolor="white">');
    d.writeln('<div align=center>');
    d.writeln('<font size=7 face="helvetica"><b>');
    d.writeln('OOPS.... A JavaScript Error Has Occurred!');
    d.writeln('</b></font><br /><hr size=4 width="80%">');
    d.writeln('<form action="mailto:'+email+'" method=post enctype="text/plain">');
    d.writeln('<font size=3>');
    d.writeln('<i>Click the "Report Error" button to send a bug report to <b>'+email+'</b>.</i><br />');
    d.writeln('<input type="submit" value="Report Error">&nbsp;&nbsp;');
    d.writeln('<input type="button" value="Dismiss" onClick="self.close()">');
    d.writeln('</div><div align=right>');
    d.writeln('<br />Your name <i>(optional)</i>: <input size=42 name="name" value="">');
    d.writeln('<br />Error Message: <input size=42 name="message" value="'+msg+'">');
    d.writeln('<br />Document: <input size=42 name="url" value="'+url+'">');
    d.writeln('<br />Line Number: <input size=42 name="line" value="'+line+'">');
    d.writeln('<br />Browser Version: <input size=42 name="version" value="'+navigator.userAgent+'">');
    d.writeln('<br />Program Version: <input size=12 name="prgVersion" value="1.0">');
    d.writeln('<br />Other Notes: <input size=42 name="notes" value="">');
    d.writeln('<br />HTMLObject Version <b>$VERSION</b>. <input type=hidden name="htmlobjectVersion" value="$VERSION">');
    d.writeln('</form>');
    d.writeln('</div></font>');
    d.writeln('</body>');
    d.write('</html>');
    d.close();

    return true;  // This stops JavaScript from displaying its own error dialog.
  }

  // Now register the Error Handler for this window.
  self.onerror = reportError;  // Handle Netscape 4 and IE 4

END_OF_CODE
        if ($self->{xhtml})
        {
          $output .= "  ]]>\n";
        }
        else
        {
          $output .= "  // -->\n";
        }
        $output .= <<"END_OF_CODE";
  </script>
END_OF_CODE
      }
      if ($self->{javascriptErrorHandlerVersion} =~ /^(both|v5)$/)
      {
        if ($self->{javascriptErrorHandlerVersion} eq "both")
        {
          $output .= <<"END_OF_CODE";

  <script language="JavaScript1.1" type="text/javascript">
END_OF_CODE
          if ($self->{xhtml})
          {
            $output .= "  <![CDATA[\n";
          }
          else
          {
            $output .= "  <!--\n";
          }
          $output .= <<"END_OF_CODE";

END_OF_CODE
        }
        else
        {
          $output .= <<"END_OF_CODE";
  <script language="JavaScript1.5" type="text/javascript">
END_OF_CODE
          if ($self->{xhtml})
          {
            $output .= "  <![CDATA[\n";
          }
          else
          {
            $output .= "  <!--\n";
          }
          $output .= <<"END_OF_CODE";

  // This ensures a unique window for each error.
  var errorCount = 0;

  // email address to mail this error report to.
  var email = "$self->{javascriptErrorHandlerEmail}";

END_OF_CODE
        }
        $output .= <<"END_OF_CODE";
  // Define a Version 5 browser Error Handler.
  // The verbose value can be anything.  If you have it set, then it will output the contents of the
  // error object else the error object is not displayed.
  function reportError5(error, verbose)
  {
END_OF_CODE
        my $baseName = $self->{javascriptErrorHandlerBaseWindowName} . "Error";
        my $language = $self->getLanguage();
        my $charEncoding = $self->getCharEncoding();

        $output .= <<"END_OF_CODE";
    var w = window.open("", "$baseName"+errorCount++, "resizable,status,width=625,height=475");
    var d = w.document;

    d.open();
    d.writeln('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">');
    d.writeln('<html lang="$language">');
    d.writeln('<head>');
    d.writeln('<meta http-equiv="Content-Type" content="text/html; charset=$charEncoding">');
    d.writeln('</head>');
    d.writeln('<body bgcolor="white">');
    d.writeln('<div align=center>');
    d.writeln('<font size=7 face="helvetica"><b>');
    d.writeln('OOPS.... A JavaScript Error Has Occurred! (Version 5 Browser!)');
    d.writeln('</b></font><br /><hr size=4 width="80%" noshade>');
    d.writeln('You are going to have to get the error from the console (<a href="javascript:">javascript:</a>).<br />');
    d.writeln('<hr width="80%" noshade>');
    var urlString = "URL = <b>";
    var browserString = "</b><br />\\nBrowser = <b>";
    var htmlVersion = "</b><br />\\nHTMLObject Version = <b>$VERSION</b>";
    var body = urlString+parent.location+browserString+navigator.userAgent+htmlVersion+"<br />\\n<br />\\nError = ";
    if (arguments.length == 2)  // they specified the verbose value.
    {
      d.writeln('<b>Here are the values passed in in the error object.</b><br />');
      d.writeln('<table border="0">');
      for(var property in error)
      {
        if (property == "name") continue;
        d.writeln('  <tr>');
        d.writeln('    <td align="right"><b>' + property + '</b></td><td align="left">' + error[property] + '</td>');
        d.writeln('  </tr>');
        body += "<br />\\n" + property + " = <b>" + error[property] + "</b>";
      }
      d.writeln('</table>');
      d.writeln('<hr width="80%" noshade>');
    }
    d.writeln('<form action="#" method="post" name="mailForm">');
    d.writeln('<font size=3>');
    d.writeln('<br /><input type="button" value="Dismiss" onClick="self.close()"><br />');
    d.writeln('</div><div align=right>');
    d.writeln('<br />URL: <b>'+parent.location+'</b>');
    d.writeln('<br />Browser: <b>'+navigator.userAgent+'</b>');
    d.writeln('<br />HTMLObject Version <b>$VERSION</b>.');
    d.writeln('</form>');
    d.writeln('<br /><br />Please <a href="mailto:'+email+'?subject='+escape("JavaScript Bug")+'&body='+escape(body)+'" title="Email the maintainer!">contact</a> the maintainer of this program.');
    d.writeln('</div></font>');
    d.writeln('</body>');
    d.write('</html>');
    d.close();

    return false;  // This causes JavaScript to log the error so it is available.
  }

  // Now register the Error Handler for this window.
END_OF_CODE
        if ($self->{javascriptErrorHandlerVersion} eq "both")
        {
          $output .= "  if (document.getElementById && document.createElement) self.onerror = reportError5;  // Handle Mozilla, etc.\n";
        }
        else
        {
          $output .= "  self.onerror = reportError5;  // Handle Mozilla, etc.\n";
        }

        if ($self->{xhtml})
        {
          $output .= "  ]]>\n";
        }
        else
        {
          $output .= "  // -->\n";
        }
        $output .= <<"END_OF_CODE";

  </script>
END_OF_CODE
      }
    }
  }

  return $output;
}

# display
# optional: debug (0|1 defaults to 0)
# returns: html document
# summary: Will generate the HTML Document to display and as long
#          as debug is not set will print it to standard out.
sub display
{
  my $self = shift;
  my %args = ( debug => 0, @_ );
  my $debug = $args{debug};

  my $output = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>display</b> when in non-Buffer mode!");
  }

  my ($tempHeadString, $tempBodyString, $tempJavascriptBody);
  my $headString = $self->getHeadString();
  my $contentTypeString = $self->getContentType();
  my $titleString = $self->getTitle();
  my $bodyString = $self->getBodyString();
  my $language = $self->getLanguage();

  # do any replacement for the tagBuffers that have been defined.
  foreach my $tag (keys %{$self->{tagBuffers}})
  {
    if ($self->{tagBufferModes}->{$tag} eq "single")
    {
      $bodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/;
    }
    else
    {
      $bodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/g;
    }
  }

  if ($contentTypeString =~ /^(text\/html)/i)
  {
    #make sure that all output is properly indented, this way the user doesn't have to do any indentation to fit our output indentation.
    ($tempHeadString = $headString) =~ s/^(.*)$/    $1/mg;  # currently 4 spaces.
    ($tempJavascriptBody = $self->{javascriptBody}) =~ s/^(.*)$/    $1/mg;

    ($tempBodyString = $bodyString) =~ s/^(.*)$/    $1/mg;
    $tempBodyString =~ s/(<textarea.*?>)((?s).*?<\/textarea>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<textarea.*?>/);
    $tempBodyString =~ s/(<pre>)((?s).*?<\/pre>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<pre>/);

    # display Cookies if needed (They apparently must come before the Content-Type: header.)
    my $tempStr = $self->displayCookies();
    $output .= $tempStr if (length $tempStr > 0);

    $output .= "Content-Type: $contentTypeString\n\n"; # Display the Content-Type block.

    # output the Document Type header.
    if ($self->{xhtml})
    {
      $output .= "<?xml version=\"1.0\" encoding=\"$self->{docEncoding}\"?>\n";
      $output .= $self->{xhtmlDoctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    else
    {
      $output .= $self->{doctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    $output .= "<html " . ($self->{xhtml} ? "xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"$language\" " : "") . "lang=\"$language\">\n";
    $output .= "  <head>\n";

    # display Meta Tags if needed.
    $tempStr = $self->displayMetaTags();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Base if needed.
    $tempStr = $self->displayBase();
    $output .= "    $tempStr\n" if (length $tempStr > 0);

    $output .= "    <title>$titleString</title>\n\n";

    # display Links if needed.
    $tempStr = $self->displayLinks();
    $output .= $tempStr if (length $tempStr > 0);

    # display CSS entries if needed.
    $tempStr = $self->displayCSS();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    $output .= "$tempHeadString\n\n" if (length $headString > 0);

    # display JavaScript error handler.
    $tempStr = $self->displayJavaScriptErrorHandler();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Requirements if needed.
    $tempStr = $self->displayJavaScriptRequirements();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Includes if defined.
    $tempStr = $self->displayJavaScriptIncludes();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Block if needed.
    if (length $self->{javascriptOnload} > 0 || length $self->{javascriptOnunload} > 0 || length $self->{javascriptBody} > 0)
    {
      $output .= "    <script language=\"JavaScript$self->{javascriptVersion}\" type=\"text/javascript\">\n";
      $output .= "      <!--\n" if (!$self->{xhtml});
      $output .= "      <![CDATA[\n" if ($self->{xhtml});
      if (length $self->{javascriptOnload} > 0)
      {
        my $tempJavascriptOnload = $self->{javascriptOnload};
        $tempJavascriptOnload =~ s/^(.*)$/        $1/mg;  # 8 spaces.
        $output .= "      function doOnLoad($self->{javascriptOnloadParameters})\n";
        $output .= "      {\n";
        $output .= $tempJavascriptOnload . "\n";
        $output .= "      }\n";
      }
      if (length $self->{javascriptOnunload} > 0)
      {
        my $tempJavascriptOnunload = $self->{javascriptOnunload};
        $tempJavascriptOnunload =~ s/^(.*)$/        $1/mg;  # 8 spaces.
        $output .= "      function doOnUnLoad($self->{javascriptOnunloadParameters})\n";
        $output .= "      {\n";
        $output .= $tempJavascriptOnunload . "\n";
        $output .= "      }\n";
      }
      if (length $self->{javascriptBody} > 0)
      {
        my $tempJavascriptBody = $self->{javascriptBody};
        $tempJavascriptBody =~ s/^(.*)$/      $1/mg;  # 6 spaces.
        $output .= $tempJavascriptBody . "\n";
      }
      $output .= "      // -->\n" if (!$self->{xhtml});
      $output .= "      ]]>\n" if ($self->{xhtml});
      $output .= "    </script>\n\n";
    }

    $output .= "  </head>\n\n";
    $output .= "  <body";
    if (!$self->{xhtml})
    {
      $output .= " bgcolor=\"$self->{bodyBgcolor}\" text=\"$self->{bodyFgcolor}\" link=\"$self->{bodyLinkColor}\" vlink=\"$self->{bodyVlinkColor}\" alink=\"$self->{bodyAlinkColor}\"";
      $output .= " background=\"$self->{bodyImage}\"" if (length $self->{bodyImage} > 0);
    }
    $output .= " onLoad=\"doOnLoad($self->{javascriptOnloadOptions});\"" if (length $self->{javascriptOnload} > 0);
    $output .= " onUnLoad=\"doOnUnLoad($self->{javascriptOnunloadOptions});\"" if (length $self->{javascriptOnunload} > 0);
    $output .= ">\n";
    $output .= "$tempBodyString\n\n" if (length $bodyString > 0);
    $output .= "  </body>\n";
    $output .= "</html>\n";
  }
  else
  {
    $output .= "Content-Type: $contentTypeString\n\n";
    $output .= $bodyString;  # don't want to possibly corrupt anything so we put the original out.
  }

  print $output if (!$debug);

  if ($debug == 1)
  {
    $output = $self->formEncodeString(string => $output);  # fixup all special characters.
    $output =~ s/ /&nbsp;/g;
    $output =~ s/\t/&nbsp;&nbsp;&nbsp;&nbsp;/g;  # replace each tab with 4 spaces
    $output =~ s/\n/<br \/>\n/gm;  # make all line breaks be <br />'s.
  }

  return $output;
}

# startDisplaying
sub startDisplaying
{
  my $self = shift;
  my $output = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>startDisplaying</b> again when in non-Buffer mode!");
  }

  my ($tempHeadString, $tempBodyString, $tempJavascriptBody);
  my $headString = $self->getHeadString();
  my $contentTypeString = $self->getContentType();
  my $titleString = $self->getTitle();
  my $bodyString = $self->getBodyString();
  my $language = $self->getLanguage();

  # do any replacement for the tagBuffers that have been defined.
  foreach my $tag (keys %{$self->{tagBuffers}})
  {
    if ($self->{tagBufferModes}->{$tag} eq "single")
    {
      $bodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/;
    }
    else
    {
      $bodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/g;
    }
  }

  if ($contentTypeString =~ /^(text\/html)/i)
  {
    #make sure that all output is properly indented, this way the user doesn't have to do any indentation to fit our output indentation.
    ($tempHeadString = $headString) =~ s/^(.*)$/    $1/mg;  # currently 4 spaces.
    ($tempJavascriptBody = $self->{javascriptBody}) =~ s/^(.*)$/    $1/mg;

    ($tempBodyString = $bodyString) =~ s/^(.*)$/    $1/mg;
    $tempBodyString =~ s/(<textarea.*?>)((?s).*?<\/textarea>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<textarea.*?>/);
    $tempBodyString =~ s/(<pre>)((?s).*?<\/pre>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<pre>/);

    # display Cookies if needed (They apparently must come before the Content-Type: header.)
    my $tempStr = $self->displayCookies();
    $output .= $tempStr if (length $tempStr > 0);

    $output .= "Content-Type: $contentTypeString\n\n"; # Display the Content-Type block.

    # output the Document Type header.
    if ($self->{xhtml})
    {
      $output .= "<?xml version=\"1.0\" encoding=\"$self->{docEncoding}\"?>\n";
      $output .= $self->{xhtmlDoctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    else
    {
      $output .= $self->{doctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    $output .= "<html " . ($self->{xhtml} ? "xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"$language\" " : "") . "lang=\"$language\">\n";
    $output .= "  <head>\n";

    # display Meta Tags if needed.
    $tempStr = $self->displayMetaTags();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Base if needed.
    $tempStr = $self->displayBase();
    $output .= "    $tempStr\n" if (length $tempStr > 0);

    $output .= "    <title>$titleString</title>\n\n";

    # display Links if needed.
    $tempStr = $self->displayLinks();
    $output .= $tempStr if (length $tempStr > 0);

    # display CSS entries if needed.
    $tempStr = $self->displayCSS();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    $output .= "$tempHeadString\n\n" if (length $headString > 0);

    # display JavaScript error handler.
    $tempStr = $self->displayJavaScriptErrorHandler();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Requirements if needed.
    $tempStr = $self->displayJavaScriptRequirements();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Includes if defined.
    $tempStr = $self->displayJavaScriptIncludes();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    # display Javascript Block if needed.
    if (length $self->{javascriptOnload} > 0 || length $self->{javascriptOnunload} > 0 || length $self->{javascriptBody} > 0)
    {
      $output .= "    <script language=\"JavaScript$self->{javascriptVersion}\" type=\"text/javascript\">\n";
      $output .= "      <!--\n" if (!$self->{xhtml});
      $output .= "      <![CDATA[\n" if ($self->{xhtml});
      if (length $self->{javascriptOnload} > 0)
      {
        my $tempJavascriptOnload = $self->{javascriptOnload};
        $tempJavascriptOnload =~ s/^(.*)$/        $1/mg;  # 8 spaces.
        $output .= "      function doOnLoad($self->{javascriptOnloadParameters})\n";
        $output .= "      {\n";
        $output .= $tempJavascriptOnload . "\n";
        $output .= "      }\n";
      }
      if (length $self->{javascriptOnunload} > 0)
      {
        my $tempJavascriptOnunload = $self->{javascriptOnunload};
        $tempJavascriptOnunload =~ s/^(.*)$/        $1/mg;  # 8 spaces.
        $output .= "      function doOnUnLoad($self->{javascriptOnunloadParameters})\n";
        $output .= "      {\n";
        $output .= $tempJavascriptOnunload . "\n";
        $output .= "      }\n";
      }
      if (length $self->{javascriptBody} > 0)
      {
        my $tempJavascriptBody = $self->{javascriptBody};
        $tempJavascriptBody =~ s/^(.*)$/      $1/mg;  # 6 spaces.
        $output .= $tempJavascriptBody . "\n";
      }
      $output .= "      // -->\n" if (!$self->{xhtml});
      $output .= "      ]]>\n" if ($self->{xhtml});
      $output .= "    </script>\n\n";
    }

    $output .= "  </head>\n\n";
    $output .= "  <body";
    if (!$self->{xhtml})
    {
      $output .= " bgcolor=\"$self->{bodyBgcolor}\" text=\"$self->{bodyFgcolor}\" link=\"$self->{bodyLinkColor}\" vlink=\"$self->{bodyVlinkColor}\" alink=\"$self->{bodyAlinkColor}\"";
      $output .= " background=\"$self->{bodyImage}\"" if (length $self->{bodyImage} > 0);
    }
    $output .= " onLoad=\"doOnLoad($self->{javascriptOnloadOptions});\"" if (length $self->{javascriptOnload} > 0);
    $output .= " onUnLoad=\"doOnUnLoad($self->{javascriptOnunloadOptions});\"" if (length $self->{javascriptOnunload} > 0);
    $output .= ">\n";
    $output .= "$tempBodyString\n\n" if (length $bodyString > 0);
  }
  else
  {
    $output .= "Content-Type: $contentTypeString\n\n";
    $output .= $bodyString;  # don't want to possibly corrupt anything so we put the original out.
  }

  print $output;

  $self->{bufferMode} = 0;
  $self->{currentSection} = "body";
  $|=1;  # turn off perls print buffering.
}

# setFocus
sub setFocus
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setFocus</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('Normal::setFocus', 'Section Name');
  }

  my $focus = shift;

  if ($focus ne "javascript")
  {
    # send it to the parent class to deal with
    $self->SUPER::setFocus($focus);
  }

  if ($self->{contentTypeString} !~ /^(text\/html)$/i)
  {
    $self->setError(code => '1006');
    $self->displayError(title => 'Error:  setFocus', message => 'Focus = "$focus" is invalid when Content-Type = "$self->{contentTypeString}" is used!');
  }

  $self->{currentSection} = $focus;
}

# print
sub print
{
  my $self = shift;

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('print', 'Text');
  }

  my $text = shift;

  if (!$self->{bufferMode})
  {
    print $text;
    return;
  }

  if ($self->{currentSection} eq "javascript")
  {
    $self->{javascriptBody} .= $text;
  }
  else
  {
    $self->SUPER::print($text);
  }
}

# read
sub read
{
  my $self = shift;
  my $text = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>read</b> when in non-Buffer mode!");
  }

  if ($self->{currentSection} eq "javascript")
  {
    $text = $self->{javascriptBody};
  }
  else
  {
    $text = $self->SUPER::read();
  }

  return $text;
}

# delete
sub delete
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>delete</b> when in non-Buffer mode!");
  }

  if ($self->{currentSection} eq "javascript")
  {
    $self->{javascriptBody} = "";
  }
  else
  {
    $self->SUPER::delete();
  }
}

# setJavascriptInclude
# parameters: version, file
sub setJavascriptInclude
{
  my $self = shift;
  my %args = ( @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setJavascriptInclude</b> when in non-Buffer mode!");
  }

  if (!exists $args{'file'})
  {
    $self->doRequiredParameterError('setJavascriptInclude', 'file');
  }

  my $version = $args{'version'};

  if (!exists $args{'version'})
  { # use the default version currently set.
    $version = $self->{javascriptVersion};
  }

  my $file = $args{'file'};

  my $include = "<script language=\"JavaScript$version\" src=\"$file\" type=\"text/javascript\"></script>";
  my $num = scalar @{$self->{javascriptIncludes}};
  $self->{javascriptIncludes}[$num] = $include;
}

# setJavascriptVersion
# takes the string for the version
sub setJavascriptVersion
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setJavascriptVersion</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setJavascriptVersion', 'version');
  }

  my $version = shift;

  $self->{javascriptVersion} = $version;
}

# getJavascriptVersion
sub getJavascriptVersion
{
  my $self = shift;

  return $self->{javascriptVersion};
}

# printJavascriptRequired
# parameters: version, message
sub printJavascriptRequired
{
  my $self = shift;
  my %args = ( message => 'JavaScript is Required to properly view this content!', @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>printJavascriptRequired</b> when in non-Buffer mode!");
  }

  my $version = $args{'version'};
  my $message = $args{'message'};

  if (!exists $args{'version'})
  { # use the default version currently set.
    $version = $self->{javascriptVersion};
  }

  $self->{javascriptRequiredVersion} = $version;
  $self->{javascriptRequiredMessage} = $message;
}

# disableJavascriptErrorHandler
# takes nothing
sub disableJavascriptErrorHandler
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>disableJavascriptErrorHandler</b> when in non-Buffer mode!");
  }

  $self->{javascriptErrorHandler} = 0;
}

# isJavascriptErrorHandlerEnabled
# returns the state of the disable flag.
sub isJavascriptErrorHandlerEnabled
{
  my $self = shift;

  return $self->{javascriptErrorHandler};
}

# void setJavascriptErrorHandlerVersion(version => 'both')
#   This function validates the version value (both, v4, v5) and then
#   sets the javascriptErrorHandlerVersion value to the specified
#   value.  This dictates what error handler code is output if using
#   the default JavaScript Error Handler.  version = 'both' will output
#   both Version 4 and Version 5 compatible error handler methods, while
#   version = 'v4' will only output a Version 4 compatible error handler
#   and version = 'v5' will only output a Version 5 compatible error
#   handler.  The Version 5 error handler will also provide a flag to
#   indicate that the contents of the error object should be displayed
#   if you call the method directly from a try/catch block.

sub setJavascriptErrorHandlerVersion
{
  my $self = shift;
  my %args = ( version => "both", @_ );
  my $version = $args{version};

  if ($version !~ /^(both|v4|v5)$/)
  {
    $self->setError(code => "3006");
    $self->displayError(message => "version = '$version' is invalid!<br />\n");
  }

  $self->{javascriptErrorHandlerVersion} = $version;
}

# scalar getJavascriptErrorHandlerVersion()
#   This function returns the value of javascriptErrorHandlerVersion
#   to allow you to determine what version of the internal JavaScript
#   Error Handler code will be generated.
sub getJavascriptErrorHandlerVersion
{
  my $self = shift;

  return $self->{javascriptErrorHandlerVersion};
}

# setJavascriptErrorHandlerEmail
# parameters: email
sub setJavascriptErrorHandlerEmail
{
  my $self = shift;
  my %args = ( @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setJavascriptErrorHandlerEmail</b> when in non-Buffer mode!");
  }

  my $email = $args{'email'};

  if (length $email == 0)
  {
    $self->doRequiredParameterError('setJavascriptErrorHandlerEmail', 'email');
  }

  $self->{javascriptErrorHandlerEmail} = $email;
}

# getJavascriptErrorHandlerEmail
sub getJavascriptErrorHandlerEmail
{
  my $self = shift;

  return $self->{javascriptErrorHandlerEmail};
}

# setJavascriptErrorHandlerWindow
# parameters: name
sub setJavascriptErrorHandlerWindow
{
  my $self = shift;
  my %args = ( @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setJavascriptErrorHandlerWindow</b> when in non-Buffer mode!");
  }

  my $name = $args{'name'};

  if (! exists $args{'name'})
  {
    $self->doRequiredParameterError('setJavascriptErrorHandlerWindow', 'name');
  }

  $self->{javascriptErrorHandlerBaseWindowName} = $name;
}

# getJavascriptErrorHandlerWindow
sub getJavascriptErrorHandlerWindow
{
  my $self = shift;

  return $self->{javascriptErrorHandlerBaseWindowName};
}

# setJavascriptErrorHandler
# parameters: code
sub setJavascriptErrorHandler
{
  my $self = shift;
  my %args = ( @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setJavascriptErrorHandler</b> when in non-Buffer mode!");
  }

  my $code = $args{'code'};

  if (length $code == 0)
  {
    $self->doRequiredParameterError('setJavascriptErrorHandler', 'code');
  }

  $self->{javascriptErrorHandlerCode} = $code;
}

# setOnload
# parameters: parameters, options, code
sub setOnload
{
  my $self = shift;
  my %args = ( parameters => '', options => '', code => '', @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setOnload</b> when in non-Buffer mode!");
  }

  my $parameters = $args{'parameters'};
  my $options = $args{'options'};
  my $code = $args{'code'};

  if (length $code == 0)
  {
    $self->doRequiredParameterError('setOnload', 'code');
  }
  if ((length $parameters > 0 && length $options == 0) || (length $parameters == 0 && length $options > 0))
  {
    $self->setError(code => '3000');
    $self->displayError(title => 'setOnload', message => 'parameters and options are both required!');
  }

  $self->{javascriptOnload} = $code;
  $self->{javascriptOnloadParameters} = $parameters;
  $self->{javascriptOnloadOptions} = $options;
}

# setOnunload
# parameters: parameters, options, code
sub setOnunload
{
  my $self = shift;
  my %args = ( parameters => '', options => '', code => '', @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setOnunload</b> when in non-Buffer mode!");
  }

  my $parameters = $args{'parameters'};
  my $options = $args{'options'};
  my $code = $args{'code'};

  if (length $code == 0)
  {
    $self->doRequiredParameterError('setOnunload', 'code');
  }
  if ((length $parameters > 0 && length $options == 0) || (length $parameters == 0 && length $options > 0))
  {
    $self->setError(code => '3000');
    $self->displayError(title => 'setOnunload', message => 'parameters and options are both required!');
  }

  $self->{javascriptOnunload} = $code;
  $self->{javascriptOnunloadParameters} = $parameters;
  $self->{javascriptOnunloadOptions} = $options;
}

sub DESTROY
{
  my $self = shift;
}

sub AUTOLOAD
{
  my $self = shift;
  my $type = ref($self) || die "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;	# strip fully-qualified portion
  unless (exists $self->{$name})
  {
    $self->setError(code => "1014");
    $self->displayError(title => "Unknown variable or method!", message => "Can't access `$name' field in object of class $type");
  }
  if (@_)
  {
    return $self->{$name} = shift;
  }
  else
  {
    return $self->{$name};
  }
}

1;
__END__

=head1 NAME

HTMLObject::Normal - Perl extension for HTMLObject.

=head1 SYNOPSIS

  use HTMLObject::Normal;
  my $doc = HTMLObject::Normal->new();

  $doc->setTitle("Test of HTMLObject::Normal");
  $doc->setFocus("body");
  $doc->print(<<"END_OF_BODY");
  <center>
  <h1>HTMLObject::Normal</h1>
  <br />
  This is cool!
  END_OF_BODY

  $doc->setCookie(name => 'cookie name', value => 'This rocks!');

  $doc->setFocus("javascript");
  $doc->print(<<"END_OF_JAVASCRIPT");
    function helloWorld()
    {
      document.write("Hello World");
    }
  END_OF_JAVASCRIPT  # This must be left aligned all the way.

  # cause the helloWorld function to be called when the page has been
  # loaded!
  $doc->setOnload(code => "helloWorld();");

  # Actually generate the entire document, cookie and all!
  $doc->display();

=head1 DESCRIPTION

HTMLObject::Normal builds on the HTMLObject::Base object and provides
JavaScript support that facilitates making Dynamic HTML documents much
easier than before.  See the documentation.html file for more details.
All core methods in the HTMLObject::Base module are available for use
in this module.  For documentation see the HTMLObject::Base man page.

=head1 Exported FUNCTIONS

  scalar new()
    Creates a new instance of the HTMLObject::Normal document type.

  void reset()
    Resets the HTMLObject::Normal document back to the defaults.

  void display( debug => 0|1 )
    optional: debug (defaults to 0)
    This function generates the Normal Document displaying any cookies,
    JavaScript, Base, Links, etc. that were specified by the user plus
    the contents of the Body that the user created.  This function prints
    the generated document to standard out which is then hopefully being
    sent to a web server to process.  If debug is defined (and
    equals 1), then the contents of the current Document are
    returned in a format ready to display in another Document so that the
    user can see what would have been generated and the string is not
    printed out.

  void startDisplaying()
    This function generates the Base Document displaying any cookies,
    plus the contents of the Body that the user created.  This function
    prints the generated document to standard out which is then hopefully
    being sent to a web server to process.  This also sets a flag
    bufferMode to 0 so that the methods know that we are no longer
    buffering user input but should just print it to the standard output.
    The only valid commands are error related, endDisplaying and print.

  void endDisplaying()
    This function closes the document that is currently being displayed
    in non-Buffering mode.  It is not valid to call this more than once.

  void setFocus(section) (scalar value)
    Validates the section name specified and then sets the internal
    pointer to the specified section. The output of any following print,
    read, or delete commands will work with the specified section.
    Modifies $currentSection.  This version handles "javascript" and
    passes everything else to the HTMLObject::Base class to handle.

  void print(string) (scalar value)
    Appends the contents of string to the currently specified section.
    This could modify $headString, $bodyString, $javascriptBody.

  void printTag(tag, value, mode)
    requires: tag, value
    optional: mode (global or single replace)
    appends the contents of value to the tagBuffers->{tag} string.  
    The tagBufferMode is set for the tag based upon the value of mode.  
    If no mode is specified and a mode has not yet been set for the tag, 
    then it is defaulted to single replacement mode, not global 
    replacement.  Tags are only worked with in the BODY section.

  scalar read()
    Returns the contents of the currently specified section. This could
    be $headString, $bodyString, $javascriptBody.

  scalar readTag(tag)
    requires: tag
    returns the string from tagBuffers identified by tag

  void delete()
    Deletes the contents of the currently specified section. You should
    call read() before doing this so you can restore if this was an
    accident. This could modify $headString, $bodyString,
    $javascriptBody.

  void deleteTag(tag)
    required: tag
    We remove the contents from tagBuffers for the tag.

  void setJavascriptInclude(version => '', file => '')
    This function creates an entry in the @javascriptIncludes array that
    will create the code to include the specified javascript file and run
    it at the specified language version. If the version is not
    specified, then "JavaScript" is the default language and version.
    Modifies @javascriptIncludes.

  void setJavascriptVersion(version) (scalar value)
    This function sets what the Javascript version should be for the
    JavaScript body section. If not specified before the user calls
    display(), then the version will be JavaScript1.1. Modifies
    $javascriptVersion.

  scalar getJavascriptVersion()
    This function returns the current JavaScript version that is set in
    javascriptVersion.

  void printJavascriptRequired(version => '', message => '')
    This function will create the <noscript>$message</noscript> tags in
    the head that will be run if the browser does not support scripting
    at all and will also generate the code to display the message if the
    specified version of scripting is not supported. Modifies
    $javascriptRequiredMessage, $javascriptRequiredVersion.

  void disableJavascriptErrorHandler()
    This function sets the variable $javascriptErrorHandler to 0 so
    that I know not to generate that block of code when displaying the
    document.
    
  scalar isJavascriptErrorHandlerEnabled()
    This function returns the value of the javascriptErrorHandler to
    see if it is enabled or disabled.

  void setJavascriptErrorHandlerVersion(version => 'both')
    This function validates the version value (both, v4, v5) and then
    sets the javascriptErrorHandlerVersion value to the specified
    value.  This dictates what error handler code is output if using
    the default JavaScript Error Handler.  version = 'both' will output
    both Version 4 and Version 5 compatible error handler methods, while
    version = 'v4' will only output a Version 4 compatible error handler
    and version = 'v5' will only output a Version 5 compatible error
    handler.  The Version 5 error handler will also provide a flag to
    indicate that the contents of the error object should be displayed
    if you call the method directly from a try/catch block.

  scalar getJavascriptErrorHandlerVersion()
    This function returns the value of javascriptErrorHandlerVersion
    to allow you to determine what version of the internal JavaScript
    Error Handler code will be generated.

  void setJavascriptErrorHandlerEmail(email => '')
    This function will set the value of $javascriptErrorHandlerEmail
    to the value specified.  This is used in the generic JavaScript error
    handler.

  scalar getJavascriptErrorHandlerEmail()
    This function returns the email address that will be used by the
    builtin error handling code.

  void setJavascriptErrorHandler(code => '')
    This function will set the code to use for the JavaScript error
    handler and will assign it to $javascriptErrorHandlerCode.  It is
    up to the user to properly set the return value so that JavaScript
    does not continue to process the error message.  The user must also
    create their own JavaScript window, etc.

  void setJavascriptErrorHandlerWindow(name => '')
    This function will set the base window name to prepend to the
    window creation code used by the builtin error handler.

  scalar getJavascriptErrorHandlerWindow()
    This function returns the window name that will be used by the
    builtin error handler.

  void setOnload(parameters => '', options => '', code => '')
    This function stores the parameters needed by the code, the options
    to pass into the function and the code to be run and then generates
    the doOnLoad JavaScript function in the JavaScript block of code when
    the user calls display(). The onLoad="doOnLoad($options);" code is
    added to the <body> tag when the page is displayed. Modifies
    $javascriptOnloadParameters, $javascriptOnloadOptions,
    $javascriptOnload.

  void setOnunload(parameters => '', options => '', code => '')
    This function stores the parameters needed by the code, the options
    to pass into the function and the code to be run and then generates
    the doOnUnLoad JavaScript function in the JavaScript block of code
    when the user calls display(). The onUnLoad="doOnUnLoad($options);"
    code is added to the <body> tag when the page is displayed. Modifies
    $javascriptOnunloadParameters, $javascriptOnunloadOptions,
    $javascriptOnunload.

=head1 AUTHOR

James A. Pattie, htmlobject@pcxperience.com

=head1 SEE ALSO

perl(1), HTMLObject::Base(3), HTMLObject::FrameSet(3), HTMLObject::ReadCookie(3), HTMLObject::WAP(3).

=cut
