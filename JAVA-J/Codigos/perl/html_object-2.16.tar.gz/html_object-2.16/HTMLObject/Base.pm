# Base.pm - The Base Class that the FrameSet and Normal HTML document Objects
# are derived from.
# Created by James Pattie, 04/27/2000.

# Copyright (c) 2000 PC & Web Xperience, Inc. http://www.pcxperience.com/
# All rights reserved.  This program is free software; you can redistribute it
# and/or modify it under the same terms as Perl itself.

# updated 02/24/2001 - Converted to new method and variable naming convention.
# updated 06/05/2001 - Add non-Buffering mode.
# updated 10/06/2001 - Added debug display code and tag substitution support.
# updated 10/08/2001 - Started to fix the indentation problem with textareas.
# updated 10/15/2001 - Removing the error if the tag doesn't exist in printTag.
# updated 10/23/2001 - Added support to decode a string which has form encoded chars in it.
# updated 11/20/2001 - Added support for selecting the version of HTML to generate a DOCTYPE for.

package HTMLObject::Base;
use strict;
use vars qw($AUTOLOAD $VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

@ISA = qw(Exporter AutoLoader);
@EXPORT = qw(
);

$VERSION = '2.16';

# Internationalization support

my %codeToLanguage = (
		"ab" => "Abkhazian",
		"om" => "Afan",
		"aa" => "Afar",
		"af" => "Afrikaans",
		"sq" => "Albanian",
		"am" => "Amharic",
		"ar" => "Arabic",
		"hy" => "Armenian",
		"as" => "Assamese",
		"ay" => "Aymara",
		"az" => "Azerbaijani",
		"ba" => "Bashkir",
		"eu" => "Basque",
		"bn" => "Bengali",
		"dz" => "Bhutani",
		"bh" => "Bihari",
		"bi" => "Bislama",
		"br" => "Breton",
		"bg" => "Bulgarian",
		"my" => "Burmese",
		"be" => "Byelorussian",
		"km" => "Cambodian",
		"ca" => "Catalan",
		"zh" => "Chinese",
		"co" => "Corsican",
		"hr" => "Croatian",
		"cs" => "Czech",
		"da" => "Danish",
		"nl" => "Dutch",
		"en" => "English",
		"eo" => "Esperanto",
		"et" => "Estonian",
		"fo" => "Faroese",
		"fj" => "Fiji",
		"fi" => "Finnish",
		"fr" => "French",
		"fy" => "Frisian",
		"gl" => "Galician",
		"ka" => "Georgian",
		"de" => "German",
		"el" => "Greek",
		"kl" => "Greenlandic",
		"gn" => "Guarani",
		"gu" => "Gujarati",
		"ha" => "Hausa",
		"he" => "Hebrew", # used to be iw
		"hi" => "Hindi",
		"hu" => "Hungarian",
		"is" => "Icelandic",
		"id" => "Indonesian",
		"ia" => "Interlingua",
		"ie" => "Interlingue",
		"iu" => "Inuktitut",
		"ik" => "Inupiak",
		"ga" => "Irish",
		"it" => "Italian",
		"ja" => "Japanese",
		"jv" => "Javanese",
		"kn" => "Kannada",
		"ks" => "Kashmiri",
		"kk" => "Kazakh",
		"rw" => "Kinyarwanda",
		"ky" => "Kirghiz",
		"rn" => "Kurundi",
		"ko" => "Korean",
		"ku" => "Kurdish",
		"lo" => "Laothian",
		"la" => "Latin",
		"lv" => "Latvian",
		"ln" => "Lingala",
		"lt" => "Lithuanian",
		"mk" => "Macedonian",
		"mg" => "Malagasy",
		"ms" => "Malay",
		"ml" => "Malayalam",
		"mt" => "Maltese",
		"mi" => "Maori",
		"mr" => "Marathi",
		"mo" => "Moldavian",
		"mn" => "Mongolian",
		"na" => "Nauru",
		"ne" => "Nepali",
		"no" => "Norwegian",
		"oc" => "Occitan",
		"or" => "Oriya",
		"ps" => "Pashto",
		"fa" => "Persian",
		"pl" => "Polish",
		"pt" => "Portuguese",
		"pa" => "Punjabi",
		"qu" => "Quechua",
		"rm" => "Rhaeto-Romance",
		"ro" => "Romanian",
		"ru" => "Russian",
		"sm" => "Samoan",
		"sg" => "Sangho",
		"sa" => "Sanskrit",
		"gd" => "Scots Gaelic",
		"sr" => "Serbian",
		"sh" => "Serbo-Croatian",
		"st" => "Sesotho",
		"tn" => "Setswana",
		"sn" => "Shona",
		"sd" => "Sindhi",
		"si" => "Singhalese",
		"ss" => "Siswati",
		"sk" => "Slovak",
		"sl" => "Slovenian",
		"so" => "Somali",
		"es" => "Spanish",
		"su" => "Sundanese",
		"sw" => "Swahili",
		"sv" => "Swedish",
		"tl" => "Tagalog",
		"tg" => "Tajik",
		"ta" => "Tamil",
		"tt" => "Tatar",
		"te" => "Telugu",
		"th" => "Thai",
		"bo" => "Tibetan",
		"ti" => "Tigrinya",
		"to" => "Tonga",
		"ts" => "Tsonga",
		"tr" => "Turkish",
		"tk" => "Turkmen",
		"tw" => "Twi",
		"ug" => "Uigur",
		"uk" => "Ukrainian",
		"ur" => "Urdu",
		"uz" => "Uzbek",
		"vi" => "Vietnamese",
		"vo" => "Volapuk",
		"cy" => "Welsh",
		"wo" => "Wolof",
		"xh" => "Xhosa",
		"yi" => "Yiddish",
		"yo" => "Yoruba",
		"za" => "Zhuang",
		"zu" => "Zulu",
	);
	
# This hash takes the 2 letter abreviation and returns the charset encoding to use with it.  It is possible to return an array if there is more than
# one possible encoding that is standard for that language.
my %codeToCharset = (
		"af" => [ "iso-8859-1", "windows-1252" ],
		"sq" => [ "iso-8859-1", "windows-1252" ],
		"ar" => "iso-8859-6",
		"eu" => [ "iso-8859-1", "windows-1252" ],
		"bg" => "iso-8859-5",
		"be" => "iso-8859-5",
		"ca" => [ "iso-8859-1", "windows-1252" ],
		"hr" => "iso-8859-2",
		"cs" => "iso-8859-2",
		"da" => [ "iso-8859-1", "windows-1252" ],
		"nl" => [ "iso-8859-1", "windows-1252" ],
		"en" => [ "iso-8859-1", "windows-1252" ],
		"eo" => "iso-8859-3",
		"et" => "iso-8859-10",
		"fo" => [ "iso-8859-1", "windows-1252" ],
		"fi" => [ "iso-8859-1", "windows-1252" ],
		"fr" => [ "iso-8859-1", "windows-1252" ],
		"gl" => [ "iso-8859-1", "windows-1252" ],
		"de" => [ "iso-8859-1", "windows-1252" ],
		"el" => "iso-8859-7",
		"he" => "iso-8859-8",
		"hu" => "iso-8859-2",
		"is" => [ "iso-8859-1", "windows-1252" ],
		"ga" => [ "iso-8859-1", "windows-1252" ],
		"it" => [ "iso-8859-1", "windows-1252" ],
		"ja" => [ "shift_jis", "iso-2022", "euc-jp" ],
		"lv" => "iso-8859-10",
		"lt" => "iso-8859-10",
		"mk" => "iso-8859-5",
		"mt" => "iso-8859-3",
		"no" => [ "iso-8859-1", "windows-1252" ],
		"pl" => "iso-8859-2",
		"pt" => [ "iso-8859-1", "windows-1252" ],
		"ro" => "iso-8859-2",
		"ru" => [ "koi-8-r", "windows-1252" ],
		"sr" => "iso-8859-5",
		"sk" => "iso-8859-2",
		"sl" => "iso-8859-2",
		"es" => [ "iso-8859-1", "windows-1252" ],
		"sv" => [ "iso-8859-1", "windows-1252" ],
		"tr" => [ "iso-8859-9", "windows-1254" ],
		"uk" => "iso-8859-5",
	);

my @encodeCharacters = ( '%', '\+', ';', ',', '=', '&', ':', '\s', '\"', '#', '\$', '\/', '\?', '<', '>', '@' );
my %encodeCharactersHash = ( '%' => '%25',
                    '\+' => '%2B',
                    ';' => '%3B',
                    ',' => '%2C',
                    '=' => '%3D',
                    '&' => '%26',
                    ':' => '%3A',
                    '\s' => '+',
                    '\"' => '%22',
                    '#' => '%23',
                    '\$' => '%24',
                    '\/' => '%2F',
                    '\?' => '%3F',
                    '<' => '%3C',
                    '>' => '%3E',
                    '@' => '%40',
                  );

# removed the \$ => \$\$ conversions as they don't appear to be needed and removed ' => &apos;
my @formEncodedCharacters = ( '&amp;', '&lt;', '&gt;', '&quot;', );
my %formEncodedCharactersHash = ( '&lt;' => '<', '&gt;' => '>', '&quot;' => '\"', '&amp;' => '&', );
my @formUnEncodedCharacters = ( '&', '<', '>', '\"', );
my %formUnEncodedCharactersHash = ( '<' => '&lt;', '>' => '&gt;', '\"' => '&quot;', '&' => '&amp;', );

# supported DOCTYPE's
my %doctypesHash = ( "4.0" =>
                       {
                         "strict" => "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">",
                         "loose" => "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/REC-html40/loose.dtd\">",
                       },
                     "4.01" =>
                       {
                         "strict" => "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">",
                         "loose" => "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">",
                       },
                   );

my %xhtmlDocTypesHash = ( "1.0" =>
                          {
                            "strict" => "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">",
                            "loose" => "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">",
                          },
                        );

# new
sub new
{
  my $that = shift;
  my $class = ref($that) || $that;
  my $self = bless {}, $class;

  $self->{error} = 0; # no error initially.
  $self->{errorMessages} = {   1002 => 'Required Parameter missing',
  			1007 => 'Error Code already being used',
  		     };
  $self->setErrorMessage(code => '-1',   message => 'No error occurred');
  $self->setErrorMessage(code => '1000', message => 'Invalid Content-Type Specified');
  $self->setErrorMessage(code => '1001', message => 'Invalid Focus Specified');
  $self->setErrorMessage(code => '1003', message => "Eval'ing setCookie command failed");
  $self->setErrorMessage(code => '1004', message => 'Invalid Date for Cookie Expires');
  $self->setErrorMessage(code => '1005', message => 'Invalid Domain for Cookie');
  $self->setErrorMessage(code => '1006', message => 'Invalid Section used when Content-Type not equal to "text/html"');
  $self->setErrorMessage(code => '1008', message => 'Error Code does not exist');
  $self->setErrorMessage(code => '1009', message => "Invalid Language Code");
  $self->setErrorMessage(code => '1010', message => "Recognized Language Code but No Charset Encoding Known");
  $self->setErrorMessage(code => '1011', message => "Charset Encoding Not Valid");
  $self->setErrorMessage(code => '1012', message => "In Buffering Mode");
  $self->setErrorMessage(code => '1013', message => "In non-Buffering Mode");
  $self->setErrorMessage(code => '1014', message => "Invalid variable or function");
  $self->setErrorMessage(code => '3000', message => 'Parameters and Options are both required if they are to be used');
  $self->setErrorMessage(code => '3001', message => 'Invalid Decoration type specified');
  $self->setErrorMessage(code => '3002', message => 'Value must be specified');
  $self->setErrorMessage(code => '3010', message => "Tag not found");
  $self->setErrorMessage(code => '1015', message => 'Invalid HTML Version');
  $self->setErrorMessage(code => '1016', message => 'Invalid HTML DTD');
  $self->setErrorMessage(code => '1017', message => 'Invalid Value');

  $self->{errorCode} = -1;

  $self->{currentSection} = "head";
  $self->{titleString} = "HTMLObject::Base";
  $self->{contentTypeString} = "text/html";
  $self->{language} = "en";
  $self->{charsetEncoding} = "iso-8859-1";
  $self->{headString} = "";
  $self->{bodyString} = "";
  $self->{bodyBgcolor} = "white";
  $self->{bodyFgcolor} = "black";
  $self->{bodyImage} = "";
  $self->{bodyLinkColor} = "blue";
  $self->{bodyVlinkColor} = "blue";
  $self->{bodyAlinkColor} = "blue";
  $self->{cookies} = [];
  $self->{metaTags} = [];
  $self->{encodeCharacters} = \@encodeCharacters;
  $self->{encodeCharactersHash} = \%encodeCharactersHash;
  $self->{formEncodedCharacters} = \@formEncodedCharacters;
  $self->{formUnEncodedCharacters} = \@formUnEncodedCharacters;
  $self->{formEncodedCharactersHash} = \%formEncodedCharactersHash;
  $self->{formUnEncodedCharactersHash} = \%formUnEncodedCharactersHash;
  $self->{linkTag} = [];
  $self->{baseHrefString} = "";
  $self->{baseTargetString} = "";
  $self->{cssEntries} = [];

  $self->{codeToLanguageHash} = \%codeToLanguage;
  $self->{codeToCharsetHash} = \%codeToCharset;

  $self->{bufferMode} = 1;  # we default to buffer the data.
  $self->{allreadyClosed} = 0; # we default to not yet closing the document.

  $self->{tagBuffers} = ();
  $self->{tagBufferModes} = ();

  # define the DOCTYPE's possible.
  $self->{doctypes} = \%doctypesHash;
  $self->{xhtmlDoctypes} = \%xhtmlDocTypesHash;
  $self->{htmlVersion} = "4.01";
  $self->{htmlDTD} = "loose";
  $self->{xhtml} = 0;  # by default we do not use xhtml code.
  $self->{docEncoding} = "iso-8859-1";

  return $self;
}

# setErrorMessage
# parameters:  code, message
sub setErrorMessage
{
  my $self = shift;
  my %args = ( @_, );

  if (!exists $args{'code'})
  {
    $self->doRequiredParameterError('setErrorMessage', 'code');
  }
  if (!exists $args{'message'})
  {
    $self->doRequiredParameterError('setErrorMessage', 'message');
  }

  my $code = $args{'code'};
  my $message = $args{'message'};

  if (exists $self->{errorMessages}{$code})
  {
    $self->setError(code => '1007');
    $self->displayError(title => 'Error:  setErrorMessage', message => "Error Code = '$code' already exists!");
  }

  # otherwise assign this message and code to the hash.
  $self->{errorMessages}{$code} = $message;
}

# clearErrorMessage
# parameters: code
sub clearErrorMessage
{
  my $self = shift;
  my %args = ( @_, );

  if (!exists $args{'code'})
  {
    $self->doRequiredParameterError('setErrorMessage', 'code');
  }

  my $code = $args{'code'};

  if (!exists $self->{errorMessages}{$code})
  {
    $self->set_error(code => '1008');
    $self->displayError(title => 'Error:  setErrorMessage', message => "Error Code = '$code' does not exist in the errorMessages hash!");
  }

  # otherwise remove this message and code from the hash.
  delete($self->{errorMessages}{$code});
}

# setError - Signals that an error occurred and what the code is.
# parameters: code
sub setError
{
  my $self = shift;
  my %args = ( @_, );

  if (!exists $args{'code'})
  {
    $self->doRequiredParameterError('setError', 'code');
  }

  my $code = $args{'code'};

  $self->{error} = 1;
  $self->{errorCode} = $code;
}

# didErrorOccur - Returns the flag value to indicate if an error occurred.
sub didErrorOccur
{
  my $self = shift;

  return $self->{error};
}

# getErrorMessage - Returns the Error Message created by the class.
sub getErrorMessage
{
  my $self = shift;

  return $self->{errorMessages}{$self->{errorCode}};
}

# getErrorCode - Returns the Error Code of the error that happened.
sub getErrorCode
{
  my $self = shift;

  return $self->{errorCode};
}

# reset
sub reset
{
  my $self = shift;

  $self->{error} = 0; # no error initially.
  %{$self->{errorMessages}} = (   1002 => 'Required Parameter missing',
  			1007 => 'Error Code already being used',
  		     );
  $self->setErrorMessage(code => '-1',   message => 'No error occurred');
  $self->setErrorMessage(code => '1000', message => 'Invalid Content-Type Specified');
  $self->setErrorMessage(code => '1001', message => 'Invalid Focus Specified');
  $self->setErrorMessage(code => '1003', message => "Eval'ing setCookie command failed");
  $self->setErrorMessage(code => '1004', message => 'Invalid Date for Cookie Expires');
  $self->setErrorMessage(code => '1005', message => 'Invalid Domain for Cookie');
  $self->setErrorMessage(code => '1006', message => 'Invalid Section used when Content-Type not equal to "text/html"');
  $self->setErrorMessage(code => '1008', message => 'Error Code does not exist');
  $self->setErrorMessage(code => '1009', message => "Invalid Language Code");
  $self->setErrorMessage(code => '1010', message => "Recognized Language Code but No Charset Encoding Known");
  $self->setErrorMessage(code => '1011', message => "Charset Encoding Not Valid");
  $self->setErrorMessage(code => '1012', message => "In Buffering Mode");
  $self->setErrorMessage(code => '1013', message => "In non-Buffering Mode");
  $self->setErrorMessage(code => '1014', message => "Invalid variable or function");
  $self->setErrorMessage(code => '3000', message => 'Parameters and Options are both required if they are to be used');
  $self->setErrorMessage(code => '3001', message => 'Invalid Decoration type specified');
  $self->setErrorMessage(code => '3002', message => 'Value must be specified');
  $self->setErrorMessage(code => '3010', message => "Tag not found");
  $self->setErrorMessage(code => '1015', message => 'Invalid HTML Version');
  $self->setErrorMessage(code => '1016', message => 'Invalid HTML DTD');
  $self->setErrorMessage(code => '1017', message => 'Invalid Value');

  $self->{errorCode} = -1;

  $self->{currentSection} = "head";
  $self->{titleString} = "HTMLObject::Base";
  $self->{contentTypeString} = "text/html";
  $self->{language} = "en";
  $self->{charsetEncoding} = "iso-8859-1";
  $self->{headString} = "";
  $self->{bodyString} = "";
  $self->{bodyBgcolor} = "white";
  $self->{bodyFgcolor} = "black";
  $self->{bodyImage} = "";
  $self->{bodyLinkColor} = "blue";
  $self->{bodyVlinkColor} = "blue";
  $self->{bodyAlinkColor} = "blue";
  $self->{cookies} = [];
  $self->{metaTags} = [];
  $self->{encodeCharacters} = \@encodeCharacters;
  $self->{encodeCharactersHash} = \%encodeCharactersHash;
  $self->{formEncodedCharacters} = \@formEncodedCharacters;
  $self->{formUnEncodedCharacters} = \@formUnEncodedCharacters;
  $self->{formEncodedCharactersHash} = \%formEncodedCharactersHash;
  $self->{formUnEncodedCharactersHash} = \%formUnEncodedCharactersHash;
  $self->{linkTag} = [];
  $self->{baseHrefString} = "";
  $self->{baseTargetString} = "";
  $self->{cssEntries} = [];

  $self->{codeToLanguageHash} = \%codeToLanguage;
  $self->{codeToCharsetHash} = \%codeToCharset;

  $self->{bufferMode} = 1;  # we default to buffer the data.
  $self->{allreadyClosed} = 0; # we default to not yet closing the document.

  $self->{tagBuffers} = ();
  $self->{tagBufferModes} = ();

  # define the DOCTYPE's possible.
  $self->{doctypes} = \%doctypesHash;
  $self->{xhtmlDoctypes} = \%xhtmlDocTypesHash;
  $self->{htmlVersion} = "4.01";
  $self->{htmlDTD} = "loose";
  $self->{xhtml} = 0;  # by default we do not use xhtml code.
  $self->{docEncoding} = "iso-8859-1";
}

# void setDocumentEncoding(encoding => "UTF-8")
#    requires: encoding - document encoding value default of UTF-8
#    This function sets the documents encoding format.  Your document
#    defaults to iso-8859-1 if you do not use this method to change it.
sub setDocumentEncoding
{
  my $self = shift;
  my %args = (encoding => "UTF-8", @_);
  my $encoding = $args{encoding};

  if (strlen $encoding == 0)
  {
    $self->doRequiredParameterError('Base::setDocumentEncoding', 'encoding');
  }

  $self->{docEncoding} = $encoding;
}

# scalar getDocumentEncoding()
#    returns the current document encoding value.
sub getDocumentEncoding
{
  my $self = shift;

  return $self->{docEncoding};
}

# displayError - Displays the specified error document and then exits.
# requires: title, message
# optional: debug (0|1 defaults to 0)
# summary: if debug = 1, then the current HTMLObject document's display
#          method is called with debug set so that we can display what the
#          document looked like.
sub displayError
{
  my $self = shift;
  my %args = (  title => 'Error: HTMLObject::Base',
  		message => 'An Error Occurred!', debug => 0,
  		@_	# arguments passed in go here.
     );
  my $debug = $args{debug};

  if ($self->{bufferMode})
  {
    my $doc = HTMLObject::Base->new();

    $doc->setTitle($args{'title'});
    $doc->setFocus("body");
    $doc->print("<h1>Error: &nbsp;<b>" . $self->getErrorCode() . "</b> Occurred!</h1>\n");
    $doc->print("Message: &nbsp;" . $self->getErrorMessage() . "\n<br />\n");
    $doc->print("<br />\n<br />\n$args{'message'}\n<br />\n");
    $doc->setStyleEntry(tag => "body", string => "color: #000000; background-color: #ffffff;") if ($self->{xhtml});

    # set the HTMLInfo based upon what was previously set.
    my %docInfo = $self->getHTMLInfo();
    $docInfo{dtd} = "loose" if ($docInfo{dtd} eq "frameset");
    $doc->setHTMLInfo(%docInfo);

    if ($debug == 1)
    {
      my $output = $self->display(debug => 1);
      $output =~ s/^(.*)$/&nbsp;&nbsp;$1/mg;
      $output =~ s/^(.*)$/      $1/mg;

      # need to use css in the future.

      $doc->print(<<"END_OF_CODE");
<br />
<table border="1" cellpadding="0" cellspacing="0" width="100%" bgcolor="lightgreen">
  <tr>
    <td bgcolor="cyan">Your Document would have generated:</td>
  </tr>
  <tr>
    <td>
      <font color="blue">
$output
      </font>
    </td>
  </tr>
</table>
END_OF_CODE
    }

    $doc->display();
  }
  else
  {
    $self->print("<br />\n<h1>Error: &nbsp;<b>" . $self->getErrorCode() . "</b> Occurred!</h1>\n");
    $self->print("Message: &nbsp;" . $self->getErrorMessage() . "\n<br />\n");
    $self->print("<br />\n<br />\n$args{'message'}\n<br />\n");
    $self->print("  </body>\n</html>\n");
  }

  exit 0;
}

# displayCookies
sub displayCookies
{
  my $self = shift;

  my $output = "";
  if (scalar @{$self->{cookies}} > 0)
  {
    foreach my $cookie (@{$self->{cookies}})
    {
      $output .= "Set-Cookie: $cookie\n";
    }
  }

  return $output;
}

# displayMetaTags
sub displayMetaTags
{
  my $self = shift;

  my $output .= "";
  if (scalar @{$self->{metaTags}} > 0)
  {
    foreach my $metaTag (@{$self->{metaTags}})
    {
      $output .= "    $metaTag\n";
    }
  }

  return $output;
}

# displayLinks
sub displayLinks
{
  my $self = shift;

  my $output = "";

  if (scalar @{$self->{linkTag}} > 0)
  {
    foreach my $link (@{$self->{linkTag}})
    {
      $output .= "    $link\n";
    }
  }

  return $output;
}

# displayCSS
sub displayCSS
{
  my $self = shift;

  my $output = "";

  if (scalar @{$self->{cssEntries}} > 0)
  {
    my $tempCSS = "<style type=\"text/css\">\n";
    $tempCSS .= "<!--\n" if (!$self->{xhtml});
    $tempCSS .= "<![CDATA[\n" if ($self->{xhtml});
    foreach my $entry (@{$self->{cssEntries}})
    {
      $tempCSS .= "  " . $entry;
    }
    $tempCSS .= "-->\n" if (!$self->{xhtml});
    $tempCSS .= "]]>\n" if ($self->{xhtml});
    $tempCSS .= "</style>\n";

    $tempCSS =~ s/^(.*)$/    $1/mg;
    $output = $tempCSS;
  }

  return $output;
}

# displayBase
sub displayBase
{
  my $self = shift;

  my $output = "";

  if (length $self->{baseHrefString} > 0 || length $self->{baseTargetString} > 0)
  {
    $output = "<base";
    if (length $self->{baseHrefString} > 0)
    {
      $output .= " href=\"$self->{baseHrefString}\"";
    }
    if (length $self->{baseTargetString} > 0)
    {
      $output .= " target=\"$self->{baseTargetString}\"";
    }
    $output .= ">\n";
  }

  return $output;
}

# display
# optional: debug (0|1 defaults to 0)
# returns: html document.
# summary: Will generate the HTML Document to display and as long
#          as debug is not set will print it to standard out.
sub display
{
  my $self = shift;
  my %args = ( debug => 0, @_ );
  my $debug = $args{debug};
  my $language = $self->getLanguage();

  my $output = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>display</b> when in non-Buffer mode!");
  }

  my ($tempHeadString, $tempBodyString);
  $tempHeadString = $self->getHeadString();
  $tempBodyString = $self->getBodyString();

  # do any replacement for the tagBuffers that have been defined.
  foreach my $tag (keys %{$self->{tagBuffers}})
  {
    if ($self->{tagBufferModes}->{$tag} eq "single")
    {
      $tempBodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/;
    }
    else
    {
      $tempBodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/g;
    }
  }

  if ($self->{contentTypeString} =~ /^(text\/html)$/i)
  {
    #make sure that all output is properly indented, this way the user doesn't have to do any indentation to fit our output indentation.
    $tempHeadString =~ s/^(.*)$/    $1/mg;  # currently 4 spaces.

    $tempBodyString =~ s/^(.*)$/    $1/mg;
    $tempBodyString =~ s/(<textarea.*?>)((?s).*?<\/textarea>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<textarea.*?>/);
    $tempBodyString =~ s/(<pre>)((?s).*?<\/pre>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<pre>/);

    # display Cookies if needed  (they must come before the Content-Type header)
    my $tempStr = $self->displayCookies();
    $output .= $tempStr if (length $tempStr > 0);

    $output .= "Content-Type: $self->{contentTypeString}; charset=$self->{charsetEncoding}\n\n";  # Display the Content-Type block.

    # output the Document Type header.
    if ($self->{xhtml})
    {
      $output .= "<?xml version=\"1.0\" encoding=\"$self->{docEncoding}\"?>\n";
      $output .= $self->{xhtmlDoctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    else
    {
      $output .= $self->{doctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    $output .= "<html " . ($self->{xhtml} ? "xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"$language\" " : "") . "lang=\"$language\">\n";
    $output .= "  <head>\n";

    # display Meta Tags if needed.
    $tempStr = $self->displayMetaTags();
    $output .= $tempStr if (length $tempStr > 0);

    # display Base if needed.
    $tempStr = $self->displayBase();
    $output .= "    $tempStr\n" if (length $tempStr > 0);

    $output .= "    <title>$self->{titleString}</title>\n";

    # display Links if needed.
    $tempStr = $self->displayLinks();
    $output .= $tempStr if (length $tempStr > 0);

    # display CSS entries if needed.
    $tempStr = $self->displayCSS();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    $output .= "    $tempHeadString" if (length $self->{headString} > 0);
    $output .= "  </head>\n\n";
    $output .= "  <body";
    if (!$self->{xhtml})
    {
      $output .= " bgcolor=\"$self->{bodyBgcolor}\" text=\"$self->{bodyFgcolor}\" link=\"$self->{bodyLinkColor}\" vlink=\"$self->{bodyVlinkColor}\" alink=\"$self->{bodyAlinkColor}\"";
      $output .= " background=\"$self->{bodyImage}\"" if (length $self->{bodyImage} > 0);
    }
    $output .= ">\n";
    $output .= "$tempBodyString\n" if (length $self->{bodyString} > 0);
    $output .= "  </body>\n";
    $output .= "</html>\n";
  }
  else
  {
    $output .= "Content-Type: $self->{contentTypeString}\n";
    $output .= "\n";  # Close the Content-Type block.
    $output .= $self->{bodyString};
  }

  print $output if (!$debug);

  if ($debug == 1)
  {
    $output = $self->formEncodeString(string => $output);  # fixup all special characters.
    $output =~ s/ /&nbsp;/g;
    $output =~ s/\t/&nbsp;&nbsp;&nbsp;&nbsp;/g;  # replace each tab with 4 spaces
    $output =~ s/\n/<br \/>\n/gm;  # make all line breaks be <br />'s.
  }

  return $output;
}

# startDisplaying - Displays the currently created document and sets the bufferMode flag to false to indicate we are no longer buffering.
sub startDisplaying
{
  my $self = shift;
  my $language = $self->getLanguage();

  my $output = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>startDisplaying</b> again when in non-Buffer mode!");
  }

  my ($tempHeadString, $tempBodyString);
  $tempHeadString = $self->getHeadString();
  $tempBodyString = $self->getBodyString();

  # do any replacement for the tagBuffers that have been defined.
  foreach my $tag (keys %{$self->{tagBuffers}})
  {
    if ($self->{tagBufferModes}->{$tag} eq "single")
    {
      $tempBodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/;
    }
    else
    {
      $tempBodyString =~ s/($tag)/$self->{tagBuffers}->{$tag}/g;
    }
  }

  if ($self->{contentTypeString} =~ /^(text\/html)$/i)
  {
    #make sure that all output is properly indented, this way the user doesn't have to do any indentation to fit our output indentation.
    $tempHeadString =~ s/^(.*)$/    $1/mg;  # currently 4 spaces.

    $tempBodyString =~ s/^(.*)$/    $1/mg;
    $tempBodyString =~ s/(<textarea.*?>)((?s).*?<\/textarea>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<textarea.*?>/);
    $tempBodyString =~ s/(<pre>)((?s).*?<\/pre>)/$1 . eval{(my $temp = $2) =~ s{^(\s{4})(.*?)$}{$2}mg; return $temp}/mxge if ($tempBodyString =~ /<pre>/);

    # display Cookies if needed  (they must come before the Content-Type header)
    my $tempStr = $self->displayCookies();
    $output .= $tempStr if (length $tempStr > 0);

    $output .= "Content-Type: $self->{contentTypeString}; charset=$self->{charsetEncoding}\n\n";  # Display the Content-Type block.

    # output the Document Type header.
    if ($self->{xhtml})
    {
      $output .= "<?xml version=\"1.0\" encoding=\"$self->{docEncoding}\"?>\n";
      $output .= $self->{xhtmlDoctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    else
    {
      $output .= $self->{doctypes}->{$self->{htmlVersion}}->{$self->{htmlDTD}} . "\n";
    }
    $output .= "<html " . ($self->{xhtml} ? "xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"$language\" " : "") . "lang=\"$language\">\n";
    $output .= "  <head>\n";

    # display Meta Tags if needed.
    $tempStr = $self->displayMetaTags();
    $output .= $tempStr if (length $tempStr > 0);

    # display Base if needed.
    $tempStr = $self->displayBase();
    $output .= "    $tempStr\n" if (length $tempStr > 0);

    $output .= "    <title>$self->{titleString}</title>\n";

    # display Links if needed.
    $tempStr = $self->displayLinks();
    $output .= $tempStr if (length $tempStr > 0);

    # display CSS entries if needed.
    $tempStr = $self->displayCSS();
    $output .= "$tempStr\n" if (length $tempStr > 0);

    $output .= "    $tempHeadString" if (length $self->{headString} > 0);
    $output .= "  </head>\n\n";
    $output .= "  <body";
    if (!$self->{xhtml})
    {
      $output .= " bgcolor=\"$self->{bodyBgcolor}\" text=\"$self->{bodyFgcolor}\" link=\"$self->{bodyLinkColor}\" vlink=\"$self->{bodyVlinkColor}\" alink=\"$self->{bodyAlinkColor}\"";
      $output .= " background=\"$self->{bodyImage}\"" if (length $self->{bodyImage} > 0);
    }
    $output .= ">\n";
    $output .= "$tempBodyString" if (length $self->{bodyString} > 0);
  }
  else
  {
    $output .= "Content-Type: $self->{contentTypeString}\n";
    $output .= "\n";  # Close the Content-Type block.
    $output .= $self->{bodyString};
  }

  $self->{bufferMode} = 0;  # signal we are no longer buffering!
  $self->{currentSection} = "body";
  $|=1;  # turn buffering off in perls print code.

  print $output;
}

# endDisplaying - Prints the document closing tags and sets the allreadyClosed flag to 1 so that you can't call it multiple times.
sub endDisplaying
{
  my $self = shift;

  if ($self->{bufferMode})
  {
    $self->setError(code => "1012");
    $self->displayError(message => "You can not call <b>endDisplaying</b> when in Buffer mode!");
  }
  elsif ($self->{allreadyClosed})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You have already closed out the document!");
  }
  print "  </body>\n</html>\n" if ($self->{contentTypeString} =~ /^(text\/html)$/i);
  $self->{allreadyClosed} = 1;
}

# doRequiredParameterError - Displays the customized title and message and then exits the program.
sub doRequiredParameterError
{
  my $self = shift;
  my $titleName = shift;
  my $messageName = shift;

  $self->setError(code => '1002');
  $self->displayError(title => "Error:  $titleName", message => "<b>$messageName</b> is required!");
}

# setContentType
sub setContentType
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setContentType</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setContentType', 'Content-Type');
  }

  my $temp = shift;

  if ($temp !~ /^(text\/html)$/i)
  {
    $self->{currentSection} = "body";	# make sure the only valid section is the body.
  }

  $self->{contentTypeString} = $temp;
}

# getContentType - Returns the charset encoding if valid.
sub getContentType
{
  my $self = shift;
  my $contentType = $self->{contentTypeString};

  if ($contentType =~ /^(text\/html)$/i)
  {
    $contentType .= "; charset=" . $self->{charsetEncoding};
  }

  return $contentType;
}

# setLanguageEncoding - Sets the language and charset encoding to work with.
sub setLanguageEncoding
{
  my $self = shift;
  my %args = ( language => 'en', encoding => 'iso-8859-1', @_, );
  my $language = $args{'language'};
  my $encoding = $args{'encoding'};

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setLanguageEncoding</b> when in non-Buffer mode!");
  }

  # validate that we have valid language code and encoding values and then that they are valid together.
  if (!exists $codeToLanguage{$language})
  {
    $self->setError(code => '1009');
    $self->displayError(title => "Error: setLanguageEncoding", message => "Language Code = '$language' is not recognized!");
  }
  if (!exists $codeToCharset{$language})
  {
    $self->setError(code => '1010');
    $self->displayError(title => "Error: setLanguageEncoding", message => "Language Code = '$language' does not have a charset encoding!");
  }
  else
  {
    my $charEncoding = $codeToCharset{$language};
    if (ref($charEncoding) eq "ARRAY")
    {
      my @encodings = @{$codeToCharset{$language}};
      my $found = 0;
      for (my $i=0; $i < scalar @encodings && !$found; $i++)
      {
        if ($encodings[$i] eq $encoding)
        {
          $found = 1;
        }
      }
      if (!$found)
      {
        $self->setError(code => '1011');
        $self->displayError(title => "Error: setLanguageEncoding", message => "Charset Encoding = '$encoding' is not valid!");
      }
    }
    else
    {
      if ($charEncoding ne $encoding)
      {
        $self->setError(code => '1011');
        $self->displayError(title => "Error: setLanguageEncoding", message => "Charset Encoding = '$encoding' is not valid!");
      }
    }
  }

  $self->{language} = $language;
  $self->{charsetEncoding} = $encoding;
}

# getLanguage
sub getLanguage
{
  my $self = shift;

  return $self->{language};
}

# getLanguageName
sub getLanguageName
{
  my $self = shift;

  return $codeToLanguage{$self->{language}};
}

# lookupLanguageName
sub lookupLanguageName
{
  my $self = shift;
  my %args = (code => 'en', @_, );  # default to english.
  my $code = $args{'code'};

  my $name = $codeToLanguage{$code};

  return $name;
}

# getCharEncoding
sub getCharEncoding
{
  my $self = shift;

  return $self->{charsetEncoding};
}

# lookupCharEncoding
sub lookupCharEncoding
{
  my $self = shift;
  my %args = (code => 'en', @_, );  # default to english.
  my $code = $args{'code'};

  return $codeToCharset{$code};  # this could be an array ref.
}

# setTitle
sub setTitle
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setTitle</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setTitle', 'Title');
  }

  $self->{titleString} = shift;
}

# getTitle
sub getTitle
{
  my $self = shift;

  return $self->{titleString};
}

# getHeadString
sub getHeadString
{
  my $self = shift;

  return $self->{headString};
}

# getBodyString
sub getBodyString
{
  my $self = shift;

  return $self->{bodyString};
}

# encodeString
# parameters are: string
# returns: url encoded string
sub encodeString
{
  my $self = shift;
  my %args = ( string => "", @_,  # arguments go here.
  	     );

  my $string = $args{'string'};

  if (!exists $args{'string'})
  {
    $self->doRequiredParameterError('encodeString', 'string');
  }

  if (length $string > 0)
  {
    foreach my $char (@{$self->{encodeCharacters}})
    {
      my $value = $self->{encodeCharactersHash}->{$char};
      $string  =~ s/$char/$value/g;
    }
  }

  return $string;
}

# formEncodeString
# takes: string
# returns: form encoded string
sub formEncodeString
{
  my $self = shift;
  my %args = ( string => "", @_ );
  my $string = $args{string};

  if (!exists $args{string})
  {
    $self->doRequiredParameterError('formEncodeString', 'string');
  }

  if (length $string > 0)
  {
    foreach my $char (@{$self->{formUnEncodedCharacters}})
    {
      my $value = $self->{formUnEncodedCharactersHash}->{$char};
      $string =~ s/(?<!\\)$char/$value/g;
    }
  }

  return $string;
}

# formDecodeString
# takes: string
# returns: string which has all form encoded characters replaced with the un-encoded value
sub formDecodeString
{
  my $self = shift;
  my %args = ( string => "", @_ );
  my $string = $args{string};

  if (!exists $args{string})
  {
    $self->doRequiredParameterError('formDecodeString', 'string');
  }

  if (length $string > 0)
  {
    foreach my $value (@{$self->{formEncodedCharacters}})
    {
      my $char = $self->{formEncodedCharactersHash}->{$value};
      $string =~ s/(?<!\\)$value/$char/g;
    }
  }

  return $string;
}

# formProtectString
# takes: string
# returns: string after decoding and then re-encoding the string to protect any special characters you
# created and want to redisplay in an edit field, etc.
sub formProtectString
{
  my $self = shift;
  my %args = ( string => "", @_ );
  my $string = $args{string};

  if (!exists $args{string})
  {
    $self->doRequiredParametersError('formProtectString', 'string');
  }

  if (length $string > 0)
  {
    # protect any \\ already in the document.
    $string =~ s/(?<!\\)\\/\\\\/g;

    # now protect any '|& make sure to not protect anything already protected.
    $string =~ s/(?<!\\)('|&)/\\$1/g;

    # Decode the string to convert any unprotected special chars into their non-special form.
    $string = $self->formDecodeString(string => $string);

    # remove any \&
    $string =~ s/(?<!\\)(\\(&))/$2/g;

    # Encode any unprotected special chars
    $string = $self->formEncodeString(string => $string);

    # remove any \' that are not double protected.
    $string =~ s/(?<!\\)(\\')/'/g;

    # remove any \&(lt;|gt;|quot;|apos;|amp;) that are not double protected
    $string =~ s/(?<!\\)(\\&(lt;|gt;|quot;|apos;|amp;|<|>|'|"|&))/&$2/g;

    # remove any protected \\ in the document.
    $string =~ s/\\\\/\\/g;
  }

  return $string;
}

# setCookie
# parameters are: name, value, expires, path, domain, secure
sub setCookie
{
  my $self = shift;
  my %args = ( name => '',
  	       value => '',
  	       @_,  # arguments go here.
  	     );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setCookie</b> when in non-Buffer mode!");
  }

  my $name = $args{'name'};
  my $value = $args{'value'};

  if (length $name == 0)
  {
    $self->doRequiredParameterError('setCookie', 'name');
  }

  $name = $self->encodeString( string => "$name" );
  $value = $self->encodeString( string => "$value" );

  my $cookie = "$name=$value;";

  if (exists $args{'expires'})
  {
    my $date = $args{'expires'};

    if ($date =~ /^\w{3}\,\s\d{2}\-\w{3}-\d{4}\s\d{2}\:\d{2}\:\d{2}\sGMT$/)
    {
      $cookie .= " expires=$args{'expires'};";
    }
    else
    {
      $self->setError(code => '1004');
      $self->displayError(title => 'setCookie', message => "date = '$date' is invalid!");
    }
  }
  if (exists $args{'path'})
  {
    $cookie .= " path=$args{'path'};";
  }
  if (exists $args{'domain'})
  {
    my $domain = $args{'domain'};
    if ($domain =~ /(.com|.edu|.net|.org|.gov|.mil|.int)$/i && $domain =~ /\..+\.\w{3}$/)
    {
      $cookie .= " domain=$args{'domain'};";
    }
    elsif ($domain !~ /(.com|.edu|.net|.org|.gov|.mil|.int)$/i && $domain =~ /\..+\..+\..+/)
    {
      $cookie .= " domain=$args{'domain'};";
    }
    else
    {
      $self->setError(code => '1005');
      $self->displayError(title => 'setCookie', message => "domain = '$domain' is invalid!");
    }
  }
  if (exists $args{'secure'})
  {
    $cookie .= " secure";
  }

  my $num = scalar @{$self->{cookies}};
  $self->{cookies}[$num] = $cookie;  # store the cookie string in the cookies array.
}

# setCompressedCookie
# parameters: name, @cookies, expires, path, domain, secure
sub setCompressedCookie
{
  my $self = shift;
  my %args = ( name => '',
  	       @_,  # arguments go here.
  	     );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setCompressedCookie</b> when in non-Buffer mode!");
  }

  if (!exists $args{'cookies'})
  {
    $self->doRequiredParameterError('setCompressedCookie', 'cookies');
  }

  my $name = $args{'name'};
  my @localCookies = @{$args{'cookies'}};
  my $cookieValue = "";  # The value for this compressed cookie to be set.

  if (length $name == 0)
  {
    $self->doRequiredParameterError('setCompressedCookie', 'name');
  }
  if (scalar @localCookies == 0)
  {
    $self->doRequiredParameterError('setCompressedCookie', 'cookies');
  }

  for (my $i=0; $i < scalar @localCookies; $i++)
  {
    my $subCookie = $localCookies[$i][0];
    my $subValue  = $localCookies[$i][1];

    $subCookie = $self->encodeString( string => "$subCookie" );
    $subValue = $self->encodeString( string => "$subValue" );

    if (length $cookieValue > 0)
    {
      $cookieValue .= "&" . $subCookie . "::" . $subValue;
    }
    else
    {
      $cookieValue = $subCookie . "::" . $subValue;
    }
  }

  my $arguments = "";
  if (exists $args{'path'})
  {
    $arguments .= ", path => '$args{'path'}'";
  }
  if (exists $args{'domain'})
  {
    $arguments .= ", domain => '$args{'domain'}'";
  }
  if (exists $args{'expires'})
  {
    $arguments .= ", expires => '$args{'expires'}'";
  }
  if (exists $args{'secure'})
  {
    $arguments .= ", secure => ''";
  }

  # now set the cookie by calling setCookie.
  eval("\$self->setCookie(name => \"$name\", value => \"$cookieValue\"$arguments);");
  if ($@)
  {
    $self->setError(code => '1003');
    $self->displayError(title => 'setCompressedCookie', message => "\$@ = $@");
  }
}

# setMetaTag
# parameters:  http-equiv, content
sub setMetaTag
{
  my $self = shift;
  my %args = ( @_,  # arguments go here.
  	     );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setMetaTag</b> when in non-Buffer mode!");
  }

  if (!exists $args{'http-equiv'})
  {
    $self->doRequiredParameterError('setMetaTag', 'http-equiv');
  }
  if (!exists $args{'content'})
  {
    $self->doRequiredParameterError('setMetaTag', 'content');
  }

  my $httpEquiv = $args{'http-equiv'};
  my $content = $args{'content'};

  if (length $httpEquiv == 0)
  {
    $self->doRequiredParameterError('setMetaTag', 'http-equiv');
  }
  if (length $content == 0)
  {
    $self->doRequiredParameterError('setMetaTag', 'content');
  }

  my $metaTag = "<meta http-equiv=\"$httpEquiv\" content=\"$content\">";
  my $num = scalar @{$self->{metaTags}};
  $self->{metaTags}[$num] = $metaTag;  # store the meta tag info for later display.
}

# setFocus
sub setFocus
{
  my $self = shift;

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setFocus', 'Section Name');
  }

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setFocus</b> when in non-Buffer mode!");
  }

  my $focus = shift;

  if ($focus ne "head" && $focus ne "body")
  {
    $self->setError(code => '1001');
    $self->displayError(title => 'Error:  setFocus', message => 'Focus = "$focus" is invalid!');
  }

  if ($self->{contentTypeString} !~ /^(text\/html)$/i && $focus ne "body")
  {
    $self->setError(code => '1006');
    $self->displayError(title => 'Error:  setFocus', message => 'Focus = "$focus" is invalid when Content-Type = "$self->{contentTypeString}" is used!');
  }

  $self->{currentSection} = $focus;
}

# getFocus
sub getFocus
{
  my $self = shift;

  return $self->{currentSection};
}

# print
sub print
{
  my $self = shift;

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('print', 'Text');
  }

  my $text = shift;

  if (!$self->{bufferMode})
  {
    print $text;
    return;
  }

  if ($self->{currentSection} eq "head")
  {
    $self->{headString} .= $text;
  }
  elsif ($self->{currentSection} eq "body")
  {
    $self->{bodyString} .= $text;
  }
}

# printTag
# requires: tag
# optional: value, mode (global or single replace)
# appends the contents of value to the tagBuffers->{tag} string.
# The tagBufferMode is set for the tag
# based upon the value of mode.  If no mode is specified and a mode has not
# yet been set for the tag, then it is defaulted to single replacement
# mode, not global replacement.
# Tags are only worked with in the BODY section.
sub printTag
{
  my $self = shift;
  my %args = ( tag => "", value => "", @_ );
  my $tag = $args{tag};
  my $value = $args{value};
  my $mode = $args{mode};

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>printTag</b> when in non-Buffer mode!");
  }

  if (length $tag == 0)
  {
    $self->doRequiredParameterError('printTag', 'tag');
  }

  # now append to the tagBuffers the string passed in.
  $self->{tagBuffers}->{$tag} .= $value;

  # check on the status of the mode
  if (length $mode > 0)
  {
    if ($mode !~ /^(single|global)$/)
    {
      $self->setError(code => 1014);
      $self->displayError(title => "Base::printTag", message => "tag replacement mode = '$mode' is invalid!");
    }
  }
  else
  {
    # make sure we have a mode set.
    $self->{tagBufferModes}->{$tag} = "single" if (! exists $self->{tagBufferModes}->{$tag});
  }
}

# read
sub read
{
  my $self = shift;
  my $text = "";

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>read</b> when in non-Buffer mode!");
  }

  if ($self->{currentSection} eq "head")
  {
    $text = $self->{headString};
  }
  elsif ($self->{currentSection} eq "body")
  {
    $text = $self->{bodyString};
  }

  return $text;
}

# readTag
# requires: tag
# returns the string from tagBuffers identified by tag
sub readTag
{
  my $self = shift;
  my %args = ( tag => "", @_ );
  my $tag = $args{tag};

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>readTag</b> when in non-Buffer mode!");
  }

  if (length $tag == 0)
  {
    $self->doRequiredParameterError('readTag', 'tag');
  }
  if (! exists $self->{tagBuffers}->{$tag})
  {
    $self->setError(code => "3010");
    $self->displayError(title => "Base::readTag", message => "tag = <b>$tag</b> not found in Body of document!");
  }

  # now return the content of tagBuffers for the specified tag.
  return $self->{tagBuffers}->{$tag};
}

# delete
sub delete
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>delete</b> when in non-Buffer mode!");
  }

  if ($self->{currentSection} eq "head")
  {
    $self->{headString} = "";
  }
  elsif ($self->{currentSection} eq "body")
  {
    $self->{bodyString} = "";
  }
}

# deleteTag
# required: tag
# We remove the contents from tagBuffers for the tag.
sub deleteTag
{
  my $self = shift;
  my %args = ( tag => "", @_ );
  my $tag = $args{tag};

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>deleteTag</b> when in non-Buffer mode!");
  }

  if (length $tag == 0)
  {
    $self->doRequiredParameterError('deleteTag', 'tag');
  }
  if (not exists $self->{tagBuffers}->{$tag})
  {
  $self->setError(code => "3010");
  $self->displayError(title => "Base::deleteTag", message => "tag = <b>$tag</b> not found in Body of document!");
  }
  delete $self->{tagBuffers}->{$tag};  # remove it from the hash, it is now not around to be substitued on when you call display!
  delete $self->{tagBufferModes}->{$tag};  # remove the mode entry also.
}

# setBodyBgcolor
sub setBodyBgcolor
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyColor</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyBgcolor', 'Background Color');
  }

  $self->{bodyBgcolor} = shift;
}

# getBodyBgcolor
sub getBodyBgcolor
{
  my $self = shift;

  return $self->{bodyBgcolor};
}

# setBodyFgcolor
sub setBodyFgcolor
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyFgcolor</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyFgcolor', 'Text Color');
  }

  $self->{bodyFgcolor} = shift;
}

# getBodyFgcolor
sub getBodyFgcolor
{
  my $self = shift;

  return $self->{bodyFgcolor};
}

# setBodyLinkColor
sub setBodyLinkColor
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyLinkColor</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyLinkColor', 'Link Color');
  }

  $self->{bodyLinkColor} = shift;
}

# getBodyLinkColor
sub getBodyLinkColor
{
  my $self = shift;

  return $self->{bodyLinkColor};
}

# setBodyVlinkColor
sub setBodyVlinkColor
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyVlinkColor</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyVlinkColor', 'VLink Color');
  }

  $self->{bodyVlinkColor} = shift;
}

# getBodyVlinkColor
sub getBodyVlinkColor
{
  my $self = shift;

  return $self->{bodyVlinkColor};
}

# setBodyAlinkColor
sub setBodyAlinkColor
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyAlinkColor</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyAlinkColor', 'ALink Color');
  }

  $self->{bodyAlinkColor} = shift;
}

# getBodyAlinkColor
sub getBodyAlinkColor
{
  my $self = shift;

  return $self->{bodyAlinkColor};
}

# setBodyImage
sub setBodyImage
{
  my $self = shift;

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBodyImage</b> when in non-Buffer mode!");
  }

  if (!defined $_[0])
  {
    $self->doRequiredParameterError('setBodyImage', 'Image');
  }

  $self->{bodyImage} = shift;
}

# setBase
# parameters: href, target
sub setBase
{
  my $self = shift;
  my %args = ( href => '', target => '', @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setBase</b> when in non-Buffer mode!");
  }

  my $href = $args{'href'};
  my $target = $args{'target'};

  if (length $href == 0 && length $target == 0)
  {
    $self->doRequiredParameterError('setBase', 'href and/or target');
  }

  $self->{baseHrefString} = $href;
  $self->{baseTargetString} = $target;
}

# setLink
# required: href, rel, type
# optional: name, rev, target, title, charset, hreflang, src, media
sub setLink
{
  my $self = shift;
  my %args = ( @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setLink</b> when in non-Buffer mode!");
  }

  my $href = $args{'href'};
  my $name = $args{'name'};
  my $rel  = $args{'rel'};
  my $rev  = $args{'rev'};
  my $type = $args{'type'};
  my $title = $args{'title'};
  my $target = $args{'target'};
  my $charset = $args{charset};
  my $hreflang = $args{hreflang};
  my $src = $args{src};
  my $media = $args{media};

  if (!exists $args{'href'})
  {
    $self->doRequiredParameterError('setLink', 'href');
  }
  if (!exists $args{'rel'})
  {
    $self->doRequiredParameterError('setLink', 'rel');
  }
  if (!exists $args{'type'})
  {
    $self->doRequiredParameterError('setLink', 'type');
  }

  my $link = "<link href=\"$href\" rel=\"$rel\" type=\"$type\"";
  if (length $title > 0)
  {
    $link .= " title=\"$title\"";
  }
  if (length $rev > 0)
  {
    $link .= " rev=\"$rev\"";
  }
  if (length $name > 0)
  {
    $link .= " name=\"$name\"";
  }
  if (length $target > 0)
  {
    $link .= " target=\"$target\"";
  }
  if (length $src > 0)
  {
    $link .= " src=\"$src\"";
  }
  if (length $hreflang > 0)
  {
    $link .= " hreflang=\"$hreflang\"";
  }
  if (length $charset > 0)
  {
    $link .= " charset=\"$charset\"";
  }
  if (length $media > 0)
  {
    $link .= " media=\"$media\"";
  }
  $link .= ">\n";

  my $num = scalar @{$self->{linkTag}};
  $self->{linkTag}[$num] = $link;
}

# setStyleEntry
# requires: tag
# optional: attributes (ref to hash of name, value pairs to apply to this tag),
#           or string (name:value ; seperated - has to be valid css)
sub setStyleEntry
{
  my $self = shift;
  my %args = ( tag => '', attributes => undef, string => "", @_ );
  my $tag = $args{tag};
  my $attributes = $args{attributes};  # This is a hash ref.
  my $string = $args{string};

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setStyleEntry</b> when in non-Buffer mode!");
  }

  if (length $tag == 0)
  {
    $self->doRequiredParameterError('setStyleEntry', 'tag');
  }

  if ((! defined $attributes) && (length $string == 0))
  {
    $self->doRequiredParameterError('setStyleEntry', 'attributes or string');
  }

  if (length $string == 0 && scalar keys %{$attributes} == 0)
  {
    $self->setError(code => '3000');
    $self->displayError(title => 'setStyleEntry', message => 'You must specify attributes to set for tag = \'$tag\'!');
  }

  # now generate the string that will be added to the css array.
  my $cssString = $tag . " { ";
  if (length $string > 0)
  {
    $cssString .= $string . " ";
  }
  else
  {
    foreach my $name (keys %{$attributes})
    {
      my $value = $attributes->{$name};
      $cssString .= $name . ": " . $value . "; ";
    }
  }
  $cssString .= "}\n";

  my $num = scalar @{$self->{cssEntries}};
  $self->{cssEntries}[$num] = $cssString;
}

# setLinkDecorations
# parameters: link, alink, vlink, hover
sub setLinkDecorations
{
  my $self = shift;
  my %args = ( link => 'none', alink => 'none', vlink => 'none', hover => 'blue', @_, );

  if (!$self->{bufferMode})
  {
    $self->setError(code => "1013");
    $self->displayError(message => "You can not call <b>setLinkDecorations</b> when in non-Buffer mode!");
  }

  my $link  = $args{'link'};
  my $alink = $args{'alink'};
  my $vlink = $args{'vlink'};
  my $hover = $args{'hover'};

  # make sure that the specified decorations are one of (none, underline, overline, line-through, blink)
  if ($link !~ /none|underline|overline|line-through|blink/i)
  {
    $self->setError(code => '3001');
    $self->displayError(title => 'setLinkDecorations', message => "'$link' is invalid decoration for <b>link</b>!");
  }
  if ($alink !~ /none|underline|overline|line-through|blink/i)
  {
    $self->setError(code => '3001');
    $self->displayError(title => 'setLinkDecorations', message => "'$alink' is invalid decoration for <b>alink</b>!");
  }
  if ($vlink !~ /none|underline|overline|line-through|blink/i)
  {
    $self->setError(code => '3001');
    $self->displayError(title => 'setLinkDecorations', message => "'$vlink' is invalid decoration for <b>vlink</b>!");
  }
  if (length $hover == 0)
  {
    $self->setError(code => '3002');
    $self->displayError(title => 'setLinkDecorations', message => "<b>hover</b> must have a color!");
  }

  # create the style sheet entries that defines our text decorations.
  # they must be done in the order of link, visited, hover, active for the
  # css properties to properly cascade!  Found this out in the CSS2 documentation.
  $self->setStyleEntry(tag => "a:link", string => "text-decoration: $link;");

  $self->setStyleEntry(tag => "a:visited", string => "text-decoration: $vlink;");

  $self->setStyleEntry(tag => "a:hover", string => "color: $hover;");

  my %attributes = ( "text-decoration" => $alink );
  $self->setStyleEntry(tag => "a:active", attributes => \%attributes);
}

# scalar makeValidHTML(string)
# requires: string - string to cleanup
# optional:
# returns: cleaned up string
# summary: basically converts all valid html tags to lowercase.
#          converts <br> -> <br /> and <hr> -> <hr />
#          tries to make sure that all attributes are lowercase
#          and double quoted.
#          Look into making sure that all tags have a close tag.
sub makeValidHTML
{
  my $self = shift;
  my %args = ( string => "", @_ );
  my $string = $args{string};

  if (length $string > 0)
  {
    # now we do the processing of the string.
    
    # convert tags to lowercase and their attributes
    $string =~ s/(<A )/<a/g;
    $string =~ s/(<\/A>)/<\/a>/g;
    # do I do a foreach loop that substitutes for the <a ...> tag
    # and then processes the ... part and then re-substitutes back
    # into the big string until there are no more <a ...> tags?
    #$string =~ s/(<a )(HREF=|NAME=)

    $string =~ s/(<B>)/<b>/g;
    $string =~ s/(<\/B>)/<\/b>/g;

    # try to make sure all attributes are ""

    # convert special tags <br>, <hr>
    $string =~ s/(<br>)/<br \/>/g;
    $string =~ s/(<hr>)/<hr \/>/g;
  }

  return $string;
}

sub DESTROY
{
  my $self = shift;
}

sub AUTOLOAD
{
  my $self = shift;
  my $type = ref($self) || die "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;	# strip fully-qualified portion
  unless (exists $self->{$name})
  {
    $self->setError(code => "1014");
    $self->displayError(title => "Unknown variable or method!", message => "Can't access `$name' field in object of class $type");
  }
  if (@_)
  {
    return $self->{$name} = shift;
  }
  else
  {
    return $self->{$name};
  }
}

# bool setHTMLInfo(version, dtd, xhtml)
# requires:
# optional: version, dtd, xhtml - 0/1
# returns: 0=error, 1=ok
# summary: Validates version and type and sets the htmlVersion and htmlDTD variables.
#          If dtd not defined it defaults to "loose".  If version not defined it defaults to "4.01"
#          as long as xhtml = 0, otherwise if xhtml = 1 then version defaults to "1.0".
sub setHTMLInfo
{
  my $self = shift;
  my %args = ( version => "4.01", dtd => "loose", xhtml => "0", @_ );
  my $version = $args{version};
  my $dtd = $args{dtd};
  my $xhtml = $args{xhtml};
  my $errStr = "HTMLObject::Base->setHTMLInfo()  - Error!<br />\n";

  if ($xhtml !~ /^(0|1)$/)
  {
    $self->setError(code => '1017');
    $self->displayError(title => 'setHTMLInfo', message => $errStr . "xhtml = '$xhtml' is invalid!<br />\n");
  }
  if ($xhtml)
  {
    if ($version eq "4.01")
    {
      $version = "1.0";  # they let the default fall through, so we have to change it.
    }
    if ($version !~ /^(1\.0)$/)
    {
      $self->setError(code => '1015');
      $self->displayError(title => 'setHTMLInfo', message => $errStr . "version = '$version' is invalid, XHTML Document!<br />\n");
    }
  }
  else
  {
    if ($version !~ /^(4\.0|4\.01)$/)
    {
      $self->setError(code => '1015');
      $self->displayError(title => 'setHTMLInfo', message => $errStr . "version = '$version' is invalid!<br />\n");
    }
  }
  if ($dtd !~ /^(strict|loose)$/)
  {
    $self->setError(code => '1016');
    $self->displayError(title => 'setHTMLInfo', message => $errStr . "dtd = '$dtd' is invalid!<br />\n");
  }

  $self->{htmlVersion} = $version;
  $self->{htmlDTD} = $dtd;
  $self->{xhtml} = $xhtml;
  
  return 1;
}

# hash getHTMLInfo()
# requires:
# optional:
# returns: hash with version, dtd, xhtml entries = to the current values.
#          Format = {version => X, dtd => Y, xhtml => 1/0}.
sub getHTMLInfo
{
  my $self = shift;
  my %result = ();

  $result{version} = $self->{htmlVersion};
  $result{dtd} = $self->{htmlDTD};
  $result{xhtml} = $self->{xhtml};

  return %result;
}

1;
__END__

=head1 NAME

HTMLObject::Base - Perl extension for HTMLObject.

=head1 SYNOPSIS

  use HTMLObject::Base;
  my $doc = HTMLObject::Base->new();

  $doc->setTitle("Test of HTMLObject::Base");
  $doc->setFocus("body");
  $doc->print(<<"END_OF_BODY");
  <center>
  <h1>HTMLObject::Base</h1>
  <br />
  This is cool!
  END_OF_BODY

  $doc->setCookie(name => 'cookie name', value => 'This rocks!');

  # Actually generate the entire document, cookie and all!
  $doc->display();

=head1 DESCRIPTION

HTMLObject::Base provides the Base methods needed to create a generic
HTML document dynamically.  See documentation.html for complete details.
It now supports Internationalization via the lang and charset
attributes of the html tag and the Content-type.

=head1 Exported FUNCTIONS

  scalar new()
    Creates a new instance of the HTMLObject::Base document type.

  void reset()
    Resets the HTMLObject::Base document back to the defaults.

  void setErrorMessage(code => '', message => '')
    This adds the error message associated with code to the
    errorMessages hash. Modifies %errorMessages.

  void clearErrorMessage(code => '')
    This removes the message associated with code from the
    errorMessages hash. Modifies %errorMessages.

  void setError(code => '')
    This takes the code and sets $error=1, $errorCode = $code. This is a
    helper function for the derived classes to use to signal when an
    error has occurred. Modifies $error and $errorCode.

  scalar didErrorOccurr() - (This is gone in 2.x series.)
    Returns 1 if an error occurred, 0 otherwise.

  scalar didErrorOccur()
    Returns 1 if an error occurred, 0 otherwise.

  scalar getErrorMessage()
    Returns the message that was generated via the code that was set.

  scalar getErrorCode()
    Returns the code that was set to indicate the error that occurred.

  void doRequiredParameterError(title => '', message => '')
    Creates an Error document using the customized title to display the
    error of Required Parameter missing. The specified message is also
    included in the body so that the program can notify the user of what
    variable is missing. Uses displayError() to generate the Error
    document.

  scalar display(debug => 0|1)
    optional: debug (defaults to 0)
    returns: the string that represents the Document.
    This function generates the Base Document displaying any cookies,
    plus the contents of the Body that the user created.  This function
    prints the generated document to standard out which is then hopefully
    being sent to a web server to process.  If debug is defined (and
    equals 1), then the contents of the current Document are
    returned in a format ready to display in another Document so that the
    user can see what would have been generated and the string is not
    printed out.

  void startDisplaying()
    This function generates the Base Document displaying any cookies,
    plus the contents of the Body that the user created.  This function
    prints the generated document to standard out which is then hopefully
    being sent to a web server to process.  This also sets a flag
    bufferMode to 0 so that the methods know that we are no longer
    buffering user input but should just print it to the standard output.
    The only valid commands are error related, endDisplaying and print.

  void endDisplaying()
    This function closes the document that is currently being displayed
    in non-Buffering mode.  It is not valid to call this more than once.

  void displayError(title => '', message => '', debug => 0|1)
    optional: debug (defaults to 0)
    Creates a HTML document that displays the user specified error
    message along with the error message generated by the program. The
    user specified title is used also. The program is exited after the
    document is displayed. Uses display() to generate the actual
    document.  If debug is specified and equals 1, then the
    contents of the calling Document will be output in a viewable format
    so that the user can determine what would have been generated.

  void setContentType(contentType) (scalar value)
    Uses the specified string to set the content-type: header with.
    Modifies $contentTypeString. If $contentType not equal to
    "text/html" then the focus is automatically set to "body".

  scalar getContentType()
    Returns $contentTypeString.  If the content-type string is
    text/html, then the ; charset=xxxx is also appended.

  void setLanguageEncoding(language => 'en', encoding => 'iso-8859-1')
    Sets the language and encoding values to the specified values after
    validating that they exist and are valid together.
    
  scalar getLanguage()
    Returns the value of $language.
    
  scalar getLanguageName()
    Returns the name of the language we are using.
    
  scalar lookupLanguageName(code => 'en')
    Returns the name of the language code that is specified.  Defaults
    to looking up english if nothing specified.  Returns an empty string
    if the language code is not defined in our hash.
    
  scalar getCharEncoding()
    Returns the value of $charsetEncoding.
    
  (scalar or @ ref) lookupCharEncoding(code => 'en')
    Returns the array ref or string that represents the valid charset
    encodings that this language code supports.  Defaults to looking up
    english if nothing specified.

  void setTitle(title)  (scalar value)
    Uses the specified string to set the title with. Modifies
    $titleString.

  scalar getTitle()
    Returns $titleString.

  scalar getHeadString()
    Returns $headString.

  scalar getBodyString()
    Returns $bodyString.

  scalar encodeString(string => '')
    URI encodes the string and returns the result.

  scalar formEncodeString(string => '')
    encode the string to replace all HTML special characters with their
    tag equivalents.  Ex.  & => &amp;
    New feature:  Any special character backslash escaped will not be
    converted.  Ex:  \& => \&

  scalar formDecodeString(string => '')
    takes: string
    returns: string which has all form encoded characters replaced with
             the un-encoded value.  Ex.  &amp; => &
    New feature:  Any special character backslash escaped will not be
    converted.  Ex:  \&amp; => \&amp;

  scalar formProtectString(string => '')
    takes: string
    returns: string after decoding and then re-encoding the string to
             protect any special characters you created and want to
             redisplay in an edit field, etc.  Uses formEncodeString
             and formDecodeString.

  void setCookie(name => '', value => '', expires => '', path => '',
                 domain => '', secure => '')
    Creates an entry in the cookies array that specifies the name=value
    pair and the expiration date and if it is to be secure for the
    specified cookie.  If secure is defined then it is included in the
    Set-Cookie line, else it is left out. The value does not matter as it
    is a tag in the Set-Cookie line and not a name=value item. Modifies
    @cookies.

    Valid formats for the expiration date are:
             Weekday, dd-Mon-yyyy hh:mm:ss GMT
    Valid formats for the domain are:
             The domain must be within the current domain and must have
             2 or more periods depending on the type of domain.
             Ex. ".host.com"

  void setCompressedCookie(name => '', cookies => [name, value],
                           expires => '', path => '', domain => '',
                           secure => '')
    Creates an entry in the cookies array that specifes the name=value
    pair where the value is the embedded cookies to be stored in this
    cookie. The embedded cookies are seperated with a :: but other than
    that everything else is the same as setCookie. The cookies hash
    entry is pointing to an array where each entry is another array with
    the first entry being the name and the second entry the value for
    each embedded cookie. Modifies @cookies.

  void setMetaTag('http-equiv' => '', content => '')
    Creates an entry in the meta_tags array that specifies the http-equiv
    and content values for the specified Meta tag to be created when
    display is called. Modifies @metaTags.

  void setFocus(section) (scalar value)
    Validates the section name specified and then sets the internal
    pointer to the specified section. The output of any following print,
    read, or delete commands will work with the specified section.
    Modifies $currentSection.

  scalar getFocus()
    Returns the currently specified section.

  void print(string) (scalar value)
    Appends the contents of string to the currently specified section.
    This could modify $headString or $bodyString.

  void printTag(tag, value, mode)
    requires: tag
    optional: value, mode (global or single replace)
    appends the contents of value to the tagBuffers->{tag} string.
    The tagBufferMode is set for the tag based upon the value of mode.
    If no mode is specified and a mode has not yet been set for the tag,
    then it is defaulted to single replacement mode, not global
    replacement.  Tags are only worked with in the BODY section.

  scalar read()
    Returns the contents of the currently specified section. This could
    be $headString or $bodyString.

  scalar readTag(tag)
    requires: tag
    returns the string from tagBuffers identified by tag

  void delete()
    Deletes the contents of the currently specified section. You should
    call read() before doing this so you can restore if this was an
    accident. This could modify $headString or $bodyString.

  void deleteTag(tag)
    required: tag
    We remove the contents from tagBuffers for the tag.

  void setBodyBgcolor(color)  (scalar value)
    This function sets the background color for the body. Modifies
    $bodyBgcolor.

  scalar getBodyBgcolor()
    This function returns the background color for the body.

  void setBodyFgcolor(color)  (scalar value)
    This function sets the text color for the body. Modifies
    $bodyFgcolor.

  scalar getBodyFgcolor()
    This function returns the text color for the body.

  void setBodyLinkColor(color)  (scalar value)
    This function sets the default link color for the body. Modifies
    $bodyLinkColor.

  scalar getBodyLinkColor()
    This function returns the default link color for the body.

  void setBodyVlinkColor(color)  (scalar value)
    This function sets the visited link color for the body. Modifies
    $bodyVlinkColor.

  scalar getBodyVlinkColor()
    This function returns the visited link color for the body.

  void setBodyAlinkColor(color)  (scalar value)
    This function sets the active link color for the body. Modifies
    $bodyAlinkColor.

  scalar getBodyAlinkColor()
    This function returns the active link color for the body.

  void setBodyImage(image)  (scalar value)
    This function sets the background image for the body. Modifies
    $bodyImage.

  void setBase(href => '', target => '')
    This function allows the user to specify the base url of the webpage
    or more importantly the default target that all links should point to
    if not explicitly specified. This is mainly used in web pages that
    are in a frameset. Modifies $baseHrefString, $baseTargetString.

  void setLink(href => '', name => '', rel => '', rev => '',
               target => '', title => '', charset => '', src => '',
               hreflang => '', media => '')
    required: href, rel, type
    optional: name, rev, target, title, charset, hreflang, src, media

    This function allows the user to specify a <link> tag item that is
    stored in the @linkTag array to be displayed in the <head> when the
    document is created. Modifies @linkTag.

  void setStyleEntry(tag => '', attributes => undef, string => '')
    requires: tag
    optional: attributes (ref to hash of name, value pairs to apply to
                          this tag),
              or string (name: value; - must be valid css)
    This generates a CSS entry to specify the style for the tag you
    specified.

  void setLinkDecorations(link => 'none', alink => 'none',
                          vlink => 'none', hover => '')
    This function allows the user to specify the decorations that the link,
    visited link, active link and hover link have.  If you specify nothing,
    then by default it turns off all decorations (no underline).  This
    generates a CSS section to specify the link decorations you desire.

  bool setHTMLInfo(version, dtd, xhtml)
    requires:
    optional: version, dtd, xhtml - 0 or 1
    returns: 0=error, 1=ok
    summary: Validates version and dtd and sets the htmlVersion and
             htmlDTD variables.  If dtd not defined it defaults to
             "loose".  If version not defined it defaults to "4.01"
             as long as xhtml = 0, but if xhtml = 1 then version
             defaults to "1.0".
             Possible values for version:
               4.0
               4.01
             Possible values for XHTML versions:
               1.0
             Possible values for dtd:
               strict
               loose

  hash getHTMLInfo()
    requires:
    optional:
    returns: hash with version, dtd, and xhtml entries = to the current
             values.
             Format = {version => X, dtd => Y, xhtml => 1/0}.

  void setDocumentEncoding(encoding => "UTF-8")
    requires: encoding - document encoding value default of UTF-8
    This function sets the documents encoding format.  Your document
    defaults to iso-8859-1 if you do not use this method to change it.
    This is only available if working with an XHTML document.

  scalar getDocumentEncoding()
    returns the current document encoding value.
    This is only available if working with an XHTML document.

  scalar makeValidHTML(string)
    requires: string - string to cleanup
    optional:
    returns: cleaned up string
    summary: basically converts all valid html tags to lowercase.
             converts <br> -> <br /> and <hr> -> <hr />
             tries to make sure that all attributes are lowercase
             and double quoted.
             Look into making sure that all tags have a close tag.

=head1 AUTHOR

James A. Pattie, htmlobject@pcxperience.com

=head1 SEE ALSO

perl(1), HTMLObject::Normal(3), HTMLObject::FrameSet(3), HTMLObject::ReadCookie(3), HTMLObject::WAP(3).

=cut
