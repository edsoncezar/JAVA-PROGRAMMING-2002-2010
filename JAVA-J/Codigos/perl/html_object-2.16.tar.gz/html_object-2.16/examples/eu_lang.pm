# English phrases for the lang.cgi test program.

$Phrases{'Welcome'} = "***Welcome";
$Phrases{'HTMLObject Version ('} = "***HTMLObject Version (";
$Phrases{') - Internationalization Test Page'} = "***) - Internationalization Test Page";
$Phrases{'Select Language'} = "***Select Language";
$Phrases{'Select Character Encoding'} = "***Select Character Encoding";
$Phrases{'Submit'} = "***Submit";
$Phrases{'Reset'} = "***Reset";
$Phrases{'charEncoding required!'} = "***charEncoding required!";
$Phrases{'You must select a Language!'} = "***You must select a Language!";
$Phrases{'Invalid Language!'} = "***Invalid Language!";
$Phrases{'Error: '} = "***Error: ";
$Phrases{'Press Back to return to the previous page.'} = "***Press Back to return to the previous page.";
$Phrases{'Current Language = '} = "***Current Language = ";
$Phrases{'User Specified'} = "***User Specified";
$Phrases{'Language = '} = "***Language = ";
$Phrases{'Character Encoding = '} = "***Character Encoding = ";

1;
