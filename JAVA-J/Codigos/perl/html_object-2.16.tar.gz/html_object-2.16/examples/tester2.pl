#!/usr/bin/perl
# tester2.pl - This will test the HTMLObject Normal object.

use HTMLObject::Normal;
use strict;

my $doc = HTMLObject::Normal->new();

$doc->setCookie(name=>'testing');

$doc->setMetaTag('http-equiv' => 'Refresh', content => '0;http://www.pcxperience.com/index.html');

$doc->setBodyFgcolor("red");
$doc->setBodyBgcolor("blue");

# test the JavaScript output stuff.
$doc->setFocus("javascript");
$doc->print("var test = 100;");

$doc->setFocus("head");
$doc->print("This is invalid!");

$doc->setJavascriptInclude(version => '', file => 'test.js');
$doc->setJavascriptVersion('1.2');
$doc->printJavascriptRequired(version => '1.1');
$doc->setOnload(code => "document.write('<h1>Hello World!</h1>');", options => 'b', parameters => 'a');
$doc->setOnunload(code => "document.write('<h1>GoodBye World!</h1>');", options => 'c', parameters => 'd');

$doc->setLink(href=>'../style.css', type=>'text/css', rel=>'stylesheet', title=>'formal');

$doc->setLinkDecorations();

$doc->setFocus("body");
$doc->print("This is a test!\n<br>");

$doc->display();
