#!/usr/bin/perl
# tester.pl - This will test the HTMLObject Base object.

use HTMLObject::FrameSet;
use strict;

my $doc = HTMLObject::FrameSet->new();
$doc->setHTMLInfo(version => "4.0");

$doc->setCookie(name=>'testing');

my $argString = "reportName=Hello World and Away we - go!";
$argString = $doc->encodeString( string => $argString );

my $content;
my $innerContent;
$innerContent = $doc->createNoframe("This is an embedded No Frames Tag!");
$innerContent .= $doc->createFrame(src => "tester2.cgi?$argString", noresize => '');
$innerContent .= $doc->createFrame(src => 'tester2.cgi', noresize => '', frameborder => 'no', scrolling => 'auto', name => 'left_menu');
$content = $doc->innerFrameset(rows => '30%,*,30%', content => $innerContent);
$content .= $doc->createFrame(src => 'tester2.cgi', name => 'right_menu');
$content .= $doc->createNoframe("Hello World!\nYou need Frame Support enabled!");
$doc->outerFrameset(cols => '*', content => $content);

$doc->display();
