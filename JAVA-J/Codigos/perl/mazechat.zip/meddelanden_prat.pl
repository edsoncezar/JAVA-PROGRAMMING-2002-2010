#!/usr/bin/perl


# Remark these two lines if you get problems
$dir = `pwd`;
chop($dir);

$meddelanden = "$dir/meddelanden.txt"; 
$loggfile = "$dir/loggfile.txt";
# THIS MUST BE THE ABSOLUTE PATH TO YOUR MEDDELANDEN.TXT
# IF YOU REMARK THE TWO LINES ABOVE YOU HAVE TO REPLACE $dir WITH THE ABSOLUTE PATH
# USE TELNET TO ACCESS YOUR ACCOUNT AND MOVE TO THE CGI- LIB . TYPE PWD AND YOU�LL
# GET THE PATH.

$script = "WEB_URL/meddelanden_prat.pl#slut"; 
# THIS IS THE URL TO YOUR SCRIPT 
# THIS IS THE PATH YOU USE FROM YOUR BROWSER TO ACCESS THE SCRIPT
# EXAMPLES OF URL�s :
# http://cgi.computer.com/cgi-bin/meddelanden.pl
# htp://cgi.host.com/htbin/cgiwrap/user/medelanden.pl


%data_received = &User_Data();

foreach $key (sort keys(%data_received)) {
    $inmatning .= "$key:\n";
    foreach (split(" : ", $data_received{$key})) {
       $inmatning .= "$_\n\n";
    }
}

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
   if ($mday < 10) {
      $mday = "0$mday";
   }
$month = ($mon + 1);
 if ($month < 10) {
      $month = "0$month";
   }
$date = "$hour:$min";



$file_dir="";

	if (-e "$meddelanden"){
        open (DATABASE, "$meddelanden") || die ("Fel kontakta webmaster");
	  @nummer = <DATABASE>;
	  close (DATABASE);

		$i=0;
		foreach (@nummer) {
		$i++;
		}	
	$start=($i-40);
	}
      open (DATABASE, ">$meddelanden") || die ("Fel kontakta webmaster");
	if ($i>1) {
		for ($loop=$start; $loop<@database; $loop++) {
		print DATABASE "$nummer[$loop]";
		}
		print DATABASE "$date <B>$data_received{namn}</B>&nbsp; : &nbsp; $data_received{input}<br>\n";
	}else {
	print DATABASE "@nummer";
	print DATABASE "$date <B>$data_received{namn}</B>&nbsp; : &nbsp; $data_received{input}<br>\n";
	}
	close (DATABASE);
	
      open (DATABASE, ">>$loggfile") || die ("Fel kontakta webmaster");
	print DATABASE "$data_received{input}\n";
	close (DATABASE);

			
	print "Content-type: text/html\n\n";
	print "<HTML><TITLE>Enter</TITLE><body text=\"#FFFFFF\" bgcolor=\"#000000\" onLoad=\"document.forms[0].input.focus()\">\n";
	print "<CENTER>\n";
	print "<FORM METHOD=POST ACTION=\"$script\">\n";

	print "<CENTER><b>The Maze Chat</b> ,\n";
	print "<a href=\"http://www.maze.se/\" target=\"_top\">\n";
	print "EXIT</A>\n";
	print "<INPUT TYPE=\"HIDDEN\" NAME=\"namn\" VALUE=\"$data_received{namn}\">\n";
	print "<br>$data_received{namn} : <INPUT TYPE=\"TEXT\" NAME=\"input\" SIZE=\"50\">\n";
	print "</CENTER>\n";
	print "</FORM>\n";
	print "</CENTER></BODY></HTML>\n";






sub User_Data {

local (%user_data, $user_string, $name_value_pair, @name_value_pairs, $name, $value);

read (STDIN,$user_string,$ENV{'CONTENT_LENGTH'});
$user_string =~s/\+/ /g;
@name_value_pairs = split(/&/, $user_string);
foreach $name_value_pair (@name_value_pairs) {
($name, $value) = split(/=/, $name_value_pair);
      $value =~ tr/+/ /;
      $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
      $value =~ s/<!--(.|\n)*-->//g;
      $value =~ s/<([^>]|\n)*>//g;

      $name =~ tr/+/ /;
      $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
      $name =~ s/<!--(.|\n)*-->//g;
      $name =~ s/<([^>]|\n)*>//g;

if (defined($user_data{$name})) {
     $user_data{$name} .= " : " . $value;
} else {
     $user_data{$name} = $value;
}
}
return %user_data;
}

