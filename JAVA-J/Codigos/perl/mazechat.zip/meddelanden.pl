#!/usr/bin/perl


# Remark these two lines if you get problems
$dir = `pwd`;
chop($dir);



$meddelanden = "$dir/meddelanden.txt"; 
# THIS MUST BE THE ABSOLUTE PATH TO YOUR MEDDELANDEN.TXT
# IF YOU REMARK THE TWO LINES ABOVE YOU HAVE TO REPLACE $dir WITH THE ABSOLUTE PATH
# USE TELNET TO ACCESS YOUR ACCOUNT AND MOVE TO THE CGI- LIB . TYPE PWD AND YOU�LL
# GET THE PATH.

$script = "URL/meddelanden.pl#slut"; 
# THIS IS THE URL TO YOUR SCRIPT 
# THIS IS THE PATH YOU USE FROM YOUR BROWSER TO ACCESS THE SCRIPT
# EXAMPLES OF URL�s :
# http://cgi.computer.com/cgi-bin/meddelanden.pl
# htp://cgi.host.com/htbin/cgiwrap/user/medelanden.pl


$exiturl = "http://www.maze.se/";


$file_dir="";

	$namn="Chat Maze interactive media";
	# This is easy to change.

	if (-e "$meddelanden") {
	open (DATABASE, "$meddelanden");
	@meddelanden = <DATABASE>;
    	}


	print "Content-type: text/html\n\n";
	print "<HTML><TITLE>chatchatchat, meddelanden</TITLE>\n";
	print "<META HTTP-EQUIV=\"Refresh\" CONTENT=15>\n";
	print "<body text=\"#FFFFFF\" bgcolor=\"#000000\" link=\"#0000EE\" vlink=\"#551A8B\" alink=\"#FF0000\">";
	print "<CENTER><FONT SIZE=\"5\">ChatChatChat</FONT><br>\n";
	print "<a href=\"$exiturl\" target=\"_top\">EXIT</A>\n";
	print "</CENTER><BR>\n";
	print "@meddelanden\n<A NAME=\"slut\">";
