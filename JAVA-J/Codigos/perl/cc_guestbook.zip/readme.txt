Readme File for CC Guestbook by CGI City (http://icthus.net/CGI-City)
Updated 07/14/98

-----
FILES
-----
The compressed file that you get should include:
1.  cc_guestbook.pl  - the guestbook script written in Perl
2.  guestbook_view.html - the guestbook page which contains all visitors' entries
3.  guestbook_entry.html - the guestbook entry page which your visitors will use to fill out in
    order to sign your guestbook page.
4.  cgi-lib.pl - Perl library/module that parses the data from the entry form.
5.  readme.txt - this file you are now reading


-------------------------
INSTALLATION INSTRUCTIONS
-------------------------
1.  Open the 'cc_guestbook.pl' file using your favorite text editor;
2.  Change the variables under the "ASSIGN VARIABLES" section accordingly;
3.  Using your favorite FTP program, upload the 'cc_guestbook.pl' file to your web host server's 
    cgi-bin directory;
4.  Once uploaded, the 'cc_guestbook.pl' file must be chmod to 755;
--------
5.  Upload the 'cgi-lib.pl' file to the same directory where you placed 'cc_guestbook.pl' 
    and chmod 755;
--------
6.  Upload the 'guestbook_view.html' file to your web host server in a directory if your choice;
    make sure you DO NOT REMOVE the line within this file that says <!--begin-->
7.  Once uploaded, the 'guestbook_view.html' file and the directory where it is located must be 
    chmod to 777;

--------
8.  Upload the 'guestbook_entry.html' file to your web host server; this is the file your guests
    will use to sign in your guestbook; just call it from your browser by typing the appropriate 
    URL ( For example: http://yourdomain.com/guestbook_entry.html )


----------
DISCLAIMER
----------
In no event will CGI City be liable to the user of this script or any third party for any 
damages, including any lost profits, lost savings or other incidental, consequential or 
special damages arising out of the operation of or inability to operate this script, even 
if user has been advised of the possibility of such damages. 







