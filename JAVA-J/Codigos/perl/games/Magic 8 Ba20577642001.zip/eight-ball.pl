#!/usr/bin/perl

#############################################################
#						            #
# Program:  Magic 8 Ball                                    #
#                    					    #
# Coded by:  M. Carter Brown				    #
#   							    #
# Distributed:  Freely: Free to copy and change as you wish #	
#							    #
#############################################################

print "Welcome to the Magic Eight Ball!  Please ask a question:\n";
print "When finished press enter for your answer.\n\n\n";


print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |                  |   |          \n";
print "             |   |         8        |   |          \n";
print "             |   |                  |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

$question = <>;

    $lower=1;
    $upper=8;
    $random = int(rand( $upper-$lower+1 ) ) + $lower;

if ($random == 1)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |                  |   |          \n";
print "             |   |        YES       |   |          \n";
print "             |   |                  |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

if ($random == 2)
{

	print "No\n\n";
}

if ($random == 3)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |   Why Should I   |   |          \n";
print "             |   |    Know That?    |   |          \n";
print "             |   |                  |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";
}

if ($random == 4)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   | Sorry, Just Woke |   |          \n";
print "             |   |   up.  Please    |   |          \n";
print "             |   |     ask Again    |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

if ($random == 5)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |                  |   |          \n";
print "             |   |  Definately Yes  |   |          \n";
print "             |   |                  |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

if ($random == 6)
{
print "\n\n\n\n";	
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |     You Really   |   |          \n";
print "             |   |     Shouldn't    |   |          \n";
print "             |   |                  |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

if ($random == 7)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |      No, But     |   |          \n";
print "             |   |  Tomorrow Looks  |   |          \n";
print "             |   |      Better      |   |          \n";
print "             \\   \\                  /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

if ($random == 8)
{
print "\n\n\n\n";
print "                    ______________             \n";
print "                  /                \\          \n";
print "                 /                  \\          \n";
print "                /                    \\         \n";
print "               /    _______________   \\        \n";
print "              /   /                \\   \\        \n";
print "             /   /                  \\   \\        \n";
print "             |   |   Do you really  |   |          \n";
print "             |   |   Think I can    |   |          \n";
print "             |   |Solve that problem|   |          \n";
print "             \\   \\       ?          /   /         \n";
print "              \\   \\ ______________ /   /          \n";
print "               \\                      /           \n";
print "                \\                    /            \n";
print "                 \\		    /            \n";
print "                  \\ ______________ /             \n";

}

########## End of Randomness... ############



print "\n\nThank you for playing!\n\n";
print "Press any key to continue . . . \n\n";
$reallydone = <>;

######### all over ################


print "I knew you would press that button!\n";
$endend = <>;




