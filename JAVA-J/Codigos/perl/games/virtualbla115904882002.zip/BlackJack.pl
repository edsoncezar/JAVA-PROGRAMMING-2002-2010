#!C:\PERL\bin\perl.exe
require "cgi-lib.pl";

# Perl BlackJack by Patrick Ayers


MAIN:
{
print "Content-type: text/html","\n\n";
print "<HTML>\n<HEAD>\n<TITLE>BLACKJACK!!! get over 200 you win</TITLE>\n</HEAD>\n";
print "<BODY>\n";
print "<P><FONT SIZE=5></FONT></P>\n";
print '<body bgcolor="#808000" text="#FFFFFF">
       <h1 align="center"><b>BlackJack </b></h1><BR>
	(over 200 winner) (Loser is BUST)<BR><BR>
       <table border="0" width="100%" height="330">
       <tr>
       <td width="75%" height="142" valign="top" rowspan="2">';

$Handcount = 0;
$Handcount2 = 0;
$count = 0;
$hits = 0;
$Dealerhits=0;
$gameover = 0;
$score1=0;
$endmessage="";

&getinput;

if ($bet==0)
	{
	print '<form action="blackjack.pl" METHOD="POST">';
	print '<input type="hidden" name="money" value="';
	print $money;
	print '">';
	print 'Please select bet amount <select name="bet" >';
	print '<option>1</option>';
	print '<option>2</option>';
	print '<option>3</option>';
	print '<option>4</option>';
	print '<option>5</option>';
	print '<BR><input type="submit" value="Throw down bet" name="playagain">';

	goto END;
	}
if ($money > 200)
	{
	print "yOU BROKE THE BANK!";
	print '<p>Return to the Game Choice Section <a href="http://www.virtualdrake.com/games/">GAMES</a></p>';
	goto END;
	}
if ($money < 1)
	{
	print "BUSTED!";
	print '<p>Return to the Game Choice Section <a href="http://www.virtualdrake.com/games/">GAMES</a></p>';
	goto END;
	}
if ($count == 0)
{

open(FILETEST,"< Cards.txt");
@Cards = <FILETEST>;
close(FILETEST);
$count = @Cards;
print "<P> -- BlackJack --  </P> \n";
&shuffle;
}

&Deal;

#the Counting of cards


if ($hit eq 'ON')
{
#print "\n<P> Player chooses to hit </P>\n";
$hits++;
}
for ($x=1;$x<=$hits;$x++)
  {
   @Hand1[$x+1] = @Cards[$x+3];
  }
&countcards;
if ($Handcount1 > 21)
  {
   print "BUSTED!";
        $money=$money-$bet;
	&GAMEOVER;
	$gameover = 1;

  }
if ($stand eq 'ON')
{
#print "\n<P> Player chooses to stand </P>\n";
#computer finishes stops at 16 or higher
$stopped = 0;
&countcards;
while ($Handcount2 < 16 && $stopped < 3)
	{
	#print "\n<P>DEALER IS HITTING <P>\n";
	$stopped++;
	$Dealerhits++;
	@Hand2[$Dealerhits+1]= @Cards[$hits+$Dealerhits+4];
	&countcards;
	}
 if ($Handcount2 > 21)
  {
    print "DEALER BUSTED!";
	$money=$money+$bet;
	&GAMEOVER;
	$gameover = 1;

  }
&checkwinner;
}


#   Check who wins


print "<LI> Dealer   \n";
if ($gameover != 1)
{
# output cards for dealer
print '&nbsp; <img border="0" src="';
print "@Hand2[1]";
print '.jpg" width="91" height="135">';
}


if ($gameover == 1)
{
foreach $message (@Hand2)
 {
  for ($message) {
        s/^\s+//;
        s/\s+$//;
    }
print '&nbsp; <img border="0" src="';
print "$message";
print '.jpg" width="91" height="135">';
 }
}

#&getrecord;

print '</td>
       <td width="25%" height="28" valign="top">
       <p align="center">Your Pocket</td>
       </tr>
       <tr>
       <td width="25%" height="108" valign="top">Money ->  '.$money; 
print  '<BR>Current Bet '.$bet;
print '</td>
       </tr><tr>
       <td width="75%" height="145" valign="top">';

foreach $message (@Hand1)
 {
for ($message) 
    {
        s/^\s+//;
        s/\s+$//;
    }
#   output cards for Player

    print '&nbsp; <img border="0" src="';
    print "$message";
    print '.jpg" width="91" height="135">';
  }

if ($gameover != 1)
  {
   &outputform;
  }

print '</td>
    <td width="25%" height="176" valign="top" rowspan="2">Your Hand :'.$Handcount1;

print '      <p>Dealers Hand :';
if ($gameover == 1)
{
print $Handcount2;
}
print '</td>
       </tr>
       <tr>
       <td width="75%" height="29" valign="top">
       <p align="center">
       <form METHOD="POST">';
if ($gameover != 1)
{
}
else
{
print '<input type="hidden" name="username" value="';
print $username;
print '">';
print '<input type="hidden" name="money" value="';
print $money;
print '">';
print '<input type="hidden" name="bet" value="';
print '0';
print '">';
print '<input type="submit" value="PLAY AGAIN" name="playagain">
        <p>Return to the Game Choice Section <a href="http://www.virtualdrake.com/games/">GAMES</a></p>';
        
}
END :
print '       </form>
       <p>&nbsp;</td>
       </tr>
       </table>

</body>

</html>';



}

sub outputform
{
 print '<form Method="post" action="blackjack.pl">';
 print '<p><input type="checkbox" name="C1" value="ON">Hit';
 print 'Me <input type="checkbox" name="C2" value="ON">Stand <input type="submit" value="Submit" name="B1"></p>';

#Export information
 print '<input type="hidden" name="HITS" value="';
 print $hits;
 print '">';
print '<input type="hidden" name="money" value="';
print $money;
print '">';

print '<input type="hidden" name="bet" value="';
print $bet;
print '">';

 print '<input type="hidden" name="Handcount" value="';
 print $Handcount;
 print '">';

 print '<input type="hidden" name="username" value="';
 print $username;
 print '">';


 print '<input type="hidden" name="LINES" value="';
 print $LINES;
 print '">';
 print '</form>';
}



sub shuffle
{
srand;
$LINES="";
for ($x=0;$x<52;$x++)
   {
	$holdcard = @Cards[$x];
	$w = int rand(52);
	@Cards[$x] = @Cards[$w];
	@Cards[$w] = $holdcard;
    }
$LINES = @Cards[0];
for ($x=1;$x<52;$x++)
   {
	$LINES = $LINES." ".@Cards[$x]; 
   }
}

sub Deal
{
	@Hand1[0] = @Cards[0];
	@Hand2[0] = @Cards[1];
	@Hand1[1] = @Cards[2];
	@Hand2[1] = @Cards[3];
}



sub countcards
{
$Handcount2 = 0;
$Handcount1 = 0;

for ($x = 0;$x<(2+$hits);$x++ )
{
$Handcount1 = $Handcount1 + @Hand1[$x];
if (@Hand1[$x] < 1)
   {
	$chopped = @Hand1[$x];
	chop $chopped;
  for ($chopped) {
        s/^\s+//;
        s/\s+$//;
    }
	$Handcount1 = $Handcount1 + 10;
	if ($chopped eq "A")
	{
	$acescount++;
	$Handcount1 = $Handcount1 - 9;
	}
   }
}

while ($acescount > 0)
{
	$acescount--;
	if ($Handcount1 < 12)
	{
	$Handcount1 = $Handcount1 + 10;
	}
}
$acescount = 0;

for ($x = 0;$x<(2+$Dealerhits);$x++ )
{
$Handcount2 = $Handcount2 + @Hand2[$x];
if (@Hand2[$x] < 1)
	{
	#@Hand2[$x] = ~tr/ //;
	$chopped = @Hand2[$x];
	chop $chopped;
  for ($chopped) {
        s/^\s+//;
        s/\s+$//;
    }
	$Handcount2 = $Handcount2 + 10;
	if ($chopped eq "A")
		{
		$acescount++;
		$Handcount2 = $Handcount2 -9;
		}
	}
}
while ($acescount > 0)
{
$acescount--;
	if ($Handcount2 < 12)
	{
	$Handcount2 = $Handcount2 + 10;
	}
}
}


sub getinput
{
if (&ReadParse(*input) && $input{'reset'} == 0)
{
$hit=$input{'C1'};
$stand=$input{'C2'};
$hits=$input{'HITS'};
$Handcount=$input{'Handcount'};
$LINES=$input{'LINES'};
@Cards=split(/ /,$LINES);
$count = @Cards;
$username=$input{'username'};
$password=$input{'password'};
$score1=$input{'score1'};
$bet=$input{'bet'};
$money=$input{'money'};

}
}


sub checkwinner
{
 if ($Handcount1 eq $Handcount2)
	 {
	#&GAMEOVER;
	$gameover = 1;
	 print "PUSH";
 	}

 if ($Handcount2 < $Handcount1 || $Handcount2 > 21)
	{
 	 print "You WIN!";
	#&GAMEOVER;
        $money=$money+$bet;
	$gameover = "1";
	}


if ($Handcount2 < 22)
      {
 	if ($Handcount1 < $Handcount2)
  	{
  	print "YOU LOSE!!";
      $money=$money-$bet;
	#&GAMEOVER;
	$gameover = "1";
	}
      }
}


sub GAMEOVER
{
#print "Content-type: text/html","\n\n";
#print "<HTML>\n<HEAD>\n<TITLE>Game Over</TITLE>\n</HEAD>\n";
#print "<BODY>\n";
#print "<P><FONT SIZE=5></FONT></P>\n";
#print '<h1 align="center">Virtualdrake.com</h1>';
#print '<p>&nbsp;</p>';
#print '<form method="post" action="blackjack.pl">';
#print '<input type="submit" value="BlackJack" name="submit1">';
#print '<input type="hidden" name="username" value="';
#print $username;
#print '">';

#print '</form>';
#print '<p>Return to the Game Choice Section <a href="http://www.virtualdrake.com/games/">www.virtualdrake.com/games</a></p>';
#print '<p>&nbsp;</p>';
#print "</BODY>\n";
}