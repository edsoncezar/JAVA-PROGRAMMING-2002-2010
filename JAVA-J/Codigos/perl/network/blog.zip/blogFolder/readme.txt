Instructions are in the blog.cgi script, preceded by the # sign.
