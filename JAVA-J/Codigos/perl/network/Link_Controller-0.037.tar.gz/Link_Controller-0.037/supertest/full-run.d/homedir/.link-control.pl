#definitions fr 
use vars qw($schedule $links $page_index $link_index $fixlink_cgi 
	    $user_address);

$::user_address = 'linkcontrollertest@linktest.test';
$::links = '0';

1;

