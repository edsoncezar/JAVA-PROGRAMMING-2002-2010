$::links="test-links.bdbm";
$::page_index="link_on_page.cdb";
$::link_index="page_has_link.cdb" ;
