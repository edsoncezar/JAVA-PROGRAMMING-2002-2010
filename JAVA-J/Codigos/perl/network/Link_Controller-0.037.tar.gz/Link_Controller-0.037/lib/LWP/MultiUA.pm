=head1 NAME

MultiUA

=head1 DESCRIPTION

This is a user agent designed to act as different user agents
depending on where it is retrieving from.

=cut
