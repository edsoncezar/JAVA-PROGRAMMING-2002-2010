package WWW::Link_Controller::Version;
$REVISION=q$Revision: 1.27 $ ; 
$VERSION='0.037';
#$WWW::Link_Controller::Version::VERSION=$VERSION;
1;
