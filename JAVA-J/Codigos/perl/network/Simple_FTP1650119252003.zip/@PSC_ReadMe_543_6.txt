Title: Simple FTP Client
Description: This application is a simple FTP Client. Although it may not be the best one out, it was programmed with the main purpose of showing beginners how to handle server responses, to start programming their own clients.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=543&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
