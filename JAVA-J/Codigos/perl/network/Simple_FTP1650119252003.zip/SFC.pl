#!/usr/bin/perl
  
use Net::FTP;

$host = $ARGV[0];
$anonyuser = $ARGV[1];

if("$ARGV[1]" eq "-a") {

                 $username = "anonymous";
                 $password = "-anonymous@";

} else {	

	print("\nSimple FTP Client by Bahaa Naamneh\n");
        print("b_naamneh@hotmail.com - http://www.bsecurity.tk\n");
        print("========================================\n");
        print("\nSpecial commands:\n");
        print("./SFC <host\/ip> -a = Login as Anonymous\n");
        print("bye = exit\n");

        print("\nHost\/IP: ");
        $host = <STDIN>;
        chomp ($host);

        print("\nUsername: ");
        $username = <STDIN>;
        chomp ($username);

        print("\nPassword: ");
        $password = <STDIN>;
        chomp ($password);
    }


 print("Connecting to $host...\n");
 my $ftp = Net::FTP->new($host) or die "Couldn't connect to $host\n";
 print("Connected!\n");
 print("\nSFC>");


 $ftp->login($username, $password)
 or die "Could not log in .\n";
    
 rep:
            
 $command = <STDIN>;

 chomp ($command);

 unless ("$command" eq "bye") {      

                                       
                  @listing = $ftp->$command;
 
                  for($i=0;$i<@listing;$i++) { print "$listing[$i]\n"; }
      
                  print("SFC>");
                        
                  goto rep;

                               }

