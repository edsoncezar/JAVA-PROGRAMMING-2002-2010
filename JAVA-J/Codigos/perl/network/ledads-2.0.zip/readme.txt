################################################################
#		       	LedAds v2.0 
#
# This program is distributed as freeware. We are not
# responsible for any damages that the program causes	
# to your system. It may be used and modified free of 
# charge, as long as the copyright notice
# in the program that give me credit remain intact.
# If you find any bugs in this program. Please feel free 
# to report it to bugs@ledscripts.com.
# If you have any troubles installing this program. Please feel
# free to post a message on our Support Forum.
# Selling this script is absolutely forbidden and illegal.
#
# On another note: This is the 'best' script I've released
# to date, so ripping of the code will really make me made :)
# Just be kind and don't take code. I gave away this program
# to you for free, so please don't abuse my kindness.
################################################################
#
#	               COPYRIGHT NOTICE:
#	
#	         Copyright 2000 Jon Coulter
#	
#	      Author:  Jon Coulter
#	      Web Site: http://www.ledscripts.com
#	      E-Mail: ledjon@ledscripts.com
#	      Support: http://www.ledscripts.com/ (or support@ledscripts.com)
#
#       This program is protected by the U.S. Copyright Law
################################################################

##############################################################
# Purpose: A full-featured, yet simple ad system.
#	   Designed for small to medium sites (sql would be
#	   optimal for sites with more traffic)
#	   Uses DBM files for data storage
##############################################################

Requires:
	SSI
	Perl 5+
	The following perl modules (usually installed by default):
		AnyDBM_File
		CGI
		CGI::Carp
		POSIX
		
	Pretty easy requirements, right?

Note: 
If #!/usr/bin/perl is not the path to perl on you system,
 you need to open all *.cgi and *.pl files (except for ad_config.cgi) and change it.


INSTALLATION
============================
Here's the quick and dirty:
	- Open la_config.cgi and change the username and password (see la_config.cgi for details)
	- Upload all files into a sub-directory of your cgi-bin (like cgi-bin/ledads/)
	- chmod *.cgi and ad.pl files to 755
	- chmod the data directory (cgi-bin/ledads/data if you used the above structure)
	  to 777
	- Run la_admin.cgi and start adding ads!
	- See below for upgrade info

USAGE
============================
	- For html pages, put <!--#exec cgi="/cgi-bin/ledads/la_ad.cgi"--> where you want the ad to show up
	- For php pages, put <? virtual('/cgi-bin/ledads/la_ad.cgi'); ?> where you want the ad to show up
	- For backward compatibility, you can use ad.pl instead of la_ad.cgi
	- Replace the path with the relative one you used.
	  If you used the above path (in the install section), then the code above will be find

UPGRADE:
============================
	- Its simple! Upgrading from led-banners v 1.0 (previous name) is as simple
	  as clicking the 'Import 1.0 Ads' and do what it says!

WARNGING:
============================
	- Uploading images is _not_ suggested (believe it or not). The reason:
	  The ad from and uploaded ad is stored in a dbm file (just like the stats are) for simplicity.
	  This means that any times that image gets called, it has to execute another cgi script (la_image.cgi).
	  This script has to take the overhead of tie-ing into the dbm file and displaying the image.
	  Needless to say, just uploading an image via ftp, and putting the url in, is the 'best' way.
	  If you're on a fast server or just don't care, go ahead and upload images :p. At least it'll work every time that way.
	  

Please e-mail any bugs you find to bugs@ledscripts.com with the details (such as program name and what you did) so that it can be fixed ASAP.