Title: PerlSpy
Description: Do you have pages that you want to keep visitors off such as login and security pages? Do you want to know as soon as a visitor lands in a particular page because you're just curious? Well, PerlSpy is a script that sends you an email alert the moment someone visits any "marked" page with all the info you need to know about that visitor such as IP, Host DNS, exact time of visit, the referring URL, the browser, OS, ...etc.
You can easily "mark" those pages by inserting one line of HTML in them and the script does the rest. 
PerlSpy is not really a security system, it's not a counter either; it's something in between. Its applications are countless and depend only on your imagination and curiosity. Just don't flood yourself with emails if you're expecting millions of visitors :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=335&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
