#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################
print "Content-type:text/html\n\n";

$fullpath="./";
push(@INC, $fullpath);

#load in the required settings
$superuser="superuser.db";
$cfg="banner_cfg.pl";
eval {
require "$cfg";
};
if ($@) {
print "unable to load $cfg. $@";
}

#load in Main.pm
$mainPM="Main.pm";
eval {
require "$mainPM";
};
if ($@) {
print "unable to load $mainPM. $@";
exit;
}


#initialize

$software="Banner Rotator 3.0 MySQL";

#user's ip
if (!$ENV{'REMOTE_HOST'}) {
$IP=$ENV{'REMOTE_ADDR'};
}
else {
$IP=$ENV{'REMOTE_HOST'};
}

$time=time;
$mainAdmin="ad-admin.pl";
$configurAdmin="configur.pl";
$dsn = "DBI:mysql:database=$database;host=$host;user=$sql_user;password=$sql_pass";



#############################################################################
# read the html form inputs and store the inputs into the $buffer variable  #
#############################################################################
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

##################################################################################
# since each input is separated by a &. We can separate all inputs into a array  #
##################################################################################

@pairs = split(/&/, $buffer);

foreach $pair (@pairs) {

#########################################################################################
# since each input is presented as name=value. We can separate them into two variables  #
#########################################################################################        
		
($name, $value) = split(/=/, $pair);

##################
# URL decoding  #
##################
        
		$name =~ tr/+/ /;
        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		
		$value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $input{$name} = $value;
        
	
}

#check the action to perform

#check if the password file exist, if not ask for the new password
open (DETECT,"<$fullpath/$superuser") or &decide;
if ($flock==1) {
flock DETECT, 2; 
}
@detect=<DETECT>;
close (DETECT);
if (!@detect) {
&decide;
}
sub decide {
if ($input{'action'} eq "firsttime") {
&firsttime;
exit;
}
else {
&setup;	
exit;
}
}

#print out the login page if admin name and password is not provoided
if (!$input{'admin'} or !$input{'password'}) {
print <<EOF;
<HTML>
<HEAD>
<TITLE>Banner Rotator</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<center>
<font face="Arial"><font size="+2">Banner Rotator</font><br><br>
Please enter your Super user admin name and password to Login:
<form action="$mainAdmin" method="post">
<b>Super User Admin Name:</b> <input type="text" name="admin">&nbsp;&nbsp;
<b>Password:</b> <input type="password" name="password">
<input type="submit" value="GO">
</form></center>
</body>
</html>
EOF
exit;
}

#verify the admin password
&vpassword;

if ($input{'action'} eq "add_new_banner") {
$description="Add a new banner";
&add_new_banner;
exit;
}
if ($input{'action'} eq "view_stats") {
$description="Banner Stats";
&view_stats;
exit;
}
if ($input{'action'} eq "modify_entry") {
$description="Modify an entry";
&modify_entry;
exit;
}
if ($input{'action'} eq "do_modify_entry") {
$description="Modify and entry";
&do_modify_entry;
exit;
}
if ($input{'action'} eq "delete_entry") {
$description="Delete an entry";
&delete_entry;
exit;
}
if ($input{'action'} eq "do_delete_entry") {
$description="Delete an entry";
&do_delete_entry;
exit;
}


#print out the main page 

&admin_header;

#print out the button to configur.pl

print qq| 
		  <form action="$configurAdmin" method="post">
		  <input type="hidden" name="admin" value="$input{'admin'}">
		  <input type="hidden" name="password" value="$input{'password'}">
		  <input type="hidden" name="action" value="mainPage">
		  <input type="submit" value="Modify Configuration">
		  </form>
	|;


&new_banner;
&display_all_banners;

&admin_footer;

#html tags for adding a new banner
sub new_banner {


print <<EOF;
<form action="ad-admin.pl" method="post">

<table>
  <tr>
    <td><b>Add a new banner</b></td>
	<td>&nbsp;</td>
  </tr>
  <tr>
    <td>Username: </td>
	<td><input name="user" type="text" value=""></td>
  </tr>
  <tr>
    <td>Password: </td>
	<td><input name="password" type="text" value=""></td>
  </tr>
  <tr>
    <td>Forward URL: Must start with http://</td>
	<td><input name="forwardURL" type="text" value=""></td>
  </tr>
  <tr>
    <td>Display: User HTML tags. If it is a banner image, use with &lt;img src="..."&gt;</td>
	<td><textarea name="display"></textarea></td>
  </tr>
  <tr>
    <td>Contact Person: </td>
	<td><input name="contact" type="text" value=""></td>
  </tr>
  <tr>
    <td>Email: </td>
	<td><input name="email" type="text" value=""></td>
  </tr>
  <tr>
    <td>Phone: </td>
	<td><input name="phone" type="text" value=""></td>
  </tr>
  <tr>
    <td>Status: </td>
	<td>Activated <input name="status" type="radio" value="activated" checked> Deactivated<input name="status" type="radio" value="deactivated"></td>
  </tr>
  <tr>
    <td>Advertising Option: </td>
	<td>Exposoures <input name="adverOpt" type="radio" value="exp" checked> Click-throughs <input name="adverOpt" type="radio" value="click" selected></td>
  </tr>
  <tr>
    <td>Initial Credit: </td>
	<td><input name="initial_credit" type="text" value=""></td>
  </tr>
  <tr>
    <td><input type="submit"></td>
	<td>&nbsp;</td>
  </tr>
</table> 
 <input type="hidden" name="admin" value="$input{'admin'}">
<input type="hidden" name="password" value="$input{'password'}">
<input name="action" type="hidden" value="add_new_banner"> 

</form>

EOF


}
#insert the new banner into the sql database
sub add_new_banner {

$time=time;

#check the advertising option
if ($input{'adverOpt'} eq "exp") {
$exp=$input{'initial_credit'};
$click=0;
}
else {
$click=$input{'initial_credit'};
$exp=0;
}

#check if the banner url and link is submitted.
if (!$input{'forwardURL'} or !$input{'display'}) {
&admin_header;

print "Displaying Tags or forwarding URL missing.";

&backToMain;
&admin_footer;
exit;
}


use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);

$sth = $dbh->prepare("INSERT INTO $ad_table (user,pass,forwardURL,display,exp,click,contact,email,phone,status,adverOpt,totalExp,totalClick,createdOn) VALUES('$input{'user'}','$input{'password'}','$input{'forwardURL'}','$input{'display'}','$exp','$click','$input{'contact'}','$input{'email'}','$input{'phone'}','$input{'status'}','$input{'adverOpt'}','0','0','$time')");
$sth->execute or &sql_error($dbh->errstr,2);


#rebuild the banner index file

$sth = $dbh->prepare("Select ID from $ad_table where status='activated'");
$sth->execute or &sql_error($dbh->errstr,2);
$i = 0;
@banner_index="";
while ((@results=$sth->fetchrow) != NULL) {
@banner_index[$i]=@results[0]."\n";
$i++;
}
open (banner_index, ">$fullpath/banners.index") or Main::error("unable to write to $fullpath/banners.index.");
print banner_index @banner_index;
close(banner_index);

#close sql connections
$sth->finish;
$dbh->disconnect;

&admin_header;
print "New banner added.";
&backToMain;
&admin_footer;


}

sub display_all_banners {

use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
#$sth = $dbh->prepare("SELECT ID,user,forwardURL,display,exp,click,contact,email,phone,status,adverOpt,totalExp,totalClick,createdOn FROM $ad_table");
$sth = $dbh->prepare("SELECT ID,user,forwardURL,display, status, createdOn FROM $ad_table ORDER BY ID");
$sth->execute or &sql_error($dbh->errstr,2);


#print out the titles for each field

print "
<table><tr><td><b>ID</b></td>
<td><b>Username</b></td>
<td><b>Display</b></td>
<td><b>Status</b></td>
<td><b>Created on</b></td>
<td><b>Action</b></td>
</tr>";

while ((@results=$sth->fetchrow) != NULL) {

#convert the unix time in array index 5 as account created date
($sec,$min,$hour,$mday,$mon,$year,$wday) = (localtime(@results[5]))[0,1,2,3,4,5,6];
$mon+=1;
$mday = sprintf("%.02d",$mday);
$year += 1900;
@results[5]="$mon/$mday/$year";
print "<tr><td>@results[0]</td><td>@results[1]</td><td><a href=\"@results[2]\">@results[3]</a></td><td>@results[4]</td><td>@results[5]</td>";

#convert < > and " to &lt; &gt and &quot; so we can put the content into a text field without creating errors
@results[2]=~ s/</&lt;/g;
@results[2]=~ s/>/&gt;/g;
@results[3]=~ s/</&lt;/g;
@results[3]=~ s/>/&gt;/g;
@results[2]=~ s/"/&quot;/g;
@results[3]=~ s/"/&quot;/g;

#print out the action option dropdown menu
print "<td>
<form action=\"ad-admin.pl\" method=\"post\"> 
<select name=\"action\">
    <option value=\"view_stats\">View stats
    <option value=\"modify_entry\">Modify entry
	<option value=\"delete_entry\">Delete entry
</select>
<input name=\"user\" type=\"hidden\" value=\"@results[1]\">
<input name=\"ID\" type=\"hidden\" value=\"@results[0]\">
<input name=\"forwardURL\" type=\"hidden\" value=\"@results[2]\">
<input name=\"display\" type=\"hidden\" value=\"@results[3]\">
<input type=\"submit\" value=\"GO\">
 <input type=\"hidden\" name=\"admin\" value=\"$input{'admin'}\">
<input type=\"hidden\" name=\"password\" value=\"$input{'password'}\">
</form>
</td>";

print "</tr>";

}
print "</table>";


#close sql connections
$sth->finish;
$dbh->disconnect;
}

#display individual banner stats

sub view_stats {

use DBI;

$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
$sth = $dbh->prepare("Select * from $ad_table where ID='$input{'ID'}'");
$sth->execute or &sql_error($dbh->errstr,2);
@results=$sth->fetchrow;



#some variables need for the stats page
#

#advertising option
if (@results[11] eq "click") {
$option="Click-throughs";
}
else {
$option="Exposures";
}

#click-throughs ratio
if (@results[12]==0) {
$ratio="0.00";
}
else {
$ratio=sprintf("%.2f",(@results[13]/@results[12])*100);
}
#account created date
($sec,$min,$hour,$mday,$mon,$year,$wday) = (localtime(@results[14]))[0,1,2,3,4,5,6];
$mon+=1;
$mday = sprintf("%.02d",$mday);
$year += 1900;

$date="$mon/$mday/$year";

&admin_header;

#start to print out the stats page
print "
<table>
<tr>
<td>ID: </td>
<td>@results[0]</td>
</tr>
<tr>
<td>Username:</td>
<td>@results[1]</td>
</tr>
<tr>
<td>Forwarding URL: </td>
<td>@results[3]</td>
</tr>
<tr>
<td>Display</td>
<td>@results[4]</td>
</tr>
<tr>";

if (@results[11] eq "exp") {
print "
<td>Exposures remaining</td>
<td>@results[5]</td>
</tr>
";
}
else {
print " 
<tr>
<td>Click-throughs remaining</td>
<td>@results[6]</td>
</tr>
";
}

print "
<tr>
<td>Contact person: </td>
<td>@results[7]</td>
</tr>
<tr>
<td>Contact email: </td>
<td>@results[8]</td>
</tr>
<tr>
<td>Contact phone number: </td>
<td>@results[9]</td>
</tr>
<tr>
<td>Statuss: </td>
<td>@results[10]</td>
</tr>
<tr>
<td>Advertising option: </td>
<td>$option</td>
</tr>
<tr>
<td>Exposures: </td>
<td>@results[12]</td>
</tr>
<tr>
<td>Click-throughs: </td>
<td>@results[13]</td>
</tr>

<tr>
<td>Click-throughs ratio: </td>
<td>$ratio%</td>
</tr>
<tr>

<td>Account created on: </td>
<td>$date</td>
</tr>
</table>
";
&backToMain;
&admin_footer;

#disconnect from the database
$sth->finish;
$dbh->disconnect;

exit;
}

#input form for modifying the banner
sub modify_entry {

use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
$sth = $dbh->prepare("Select * from $ad_table where ID='$input{'ID'}'");
$sth->execute or &sql_error($dbh->errstr,2);
@results=$sth->fetchrow;
$act_checked="";
$deact_checked="checked";
if (@results[10] eq "activated") {
$act_checked="checked";
$deact_checked="";
}
$exp_checked="";
$click_checked="checked";
if (@results[11] eq "exp") {
$exp_checked="checked";
$click_checked="";
}

#convert < > and " to &lt; &gt; and &quot; so we can put the content into a text field without creating errors
@results[3]=~ s/</&lt;/g;
@results[3]=~ s/>/&gt;/g;
@results[4]=~ s/</&lt;/g;
@results[4]=~ s/>/&gt;/g;
@results[3]=~ s/"/&quot;/g;
@results[4]=~ s/"/&quot;/g;

&admin_header;

print <<EOF;
<form action="ad-admin.pl" method="post">
<table>
<tr><td>Username: </td><td><input name="user" type="text" value="@results[1]"></td><tr>
<tr><td>Password: </td><td><input name="user_password" type="text" value="@results[2]"></td><tr>
<tr><td>Forward URL: </td><td><input name="forwardURL" type="text" value="@results[3]"></td><tr>
<tr><td>Display: </td><td><input name="display" type="text" value="@results[4]"></td><tr>
<tr><td>Exposure credits: </td><td><input name="exp" type="text" value="@results[5]"></td><tr>
<tr><td>Click-through credits: </td><td><input name="click" type="text" value="@results[6]"></td><tr>
<tr><td>Contact person: </td><td><input name="contact" type="text" value="@results[7]"></td><tr>
<tr><td>Email: </td><td><input name="email" type="text" value="@results[8]"></td><tr>
<tr><td>Phone: </td><td><input name="phone" type="text" value="@results[9]"></td><tr>
<tr><td>Status: </td><td>Activated <input name="status" type="radio" value="activated" $act_checked> Deactivated<input name="status" type="radio" value="deactivated" $deact_checked></td><tr>
<tr><td>Advertising Option: </td><td>Exposoures <input name="adverOpt" type="radio" value="exp" $exp_checked> Click-throughs <input name="adverOpt" type="radio" value="click" $click_checked></td><tr>
<tr><td>Total Exposures: </td><td><input name="totalExp" type="text" value="@results[12]"></td><tr>
<tr><td>Total Click-throughs: </td><td><input name="totalClick" type="text" value="@results[13]"></td><tr>
</table>
<input name="ID" type="hidden" value="@results[0]">
<input type="hidden" name="admin" value="$input{'admin'}">
<input type="hidden" name="password" value="$input{'password'}">
<input name="action" type="hidden" value="do_modify_entry">
<input type="submit" value="save">
</form>

EOF
&backToMain;
&admin_footer;

}

sub do_modify_entry {
use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
$sth = $dbh->prepare("UPDATE $ad_table SET user='$input{'user'}', pass='$input{'user_password'}', forwardURL='$input{'forwardURL'}', display='$input{'display'}', exp='$input{'exp'}', click='$input{'click'}', contact='$input{'contact'}', email='$input{'email'}', phone='$input{'phone'}', status='$input{'status'}', adverOpt='$input{'adverOpt'}', totalExp='$input{'totalExp'}', totalClick='$input{'totalClick'}' where ID = '$input{'ID'}'");
$sth->execute or &sql_error($dbh->errstr,2);


#rebuild the banner index file

$sth = $dbh->prepare("Select ID from $ad_table where status='activated'");
$sth->execute or &sql_error($dbh->errstr,2);
$i = 0;
@banner_index="";
while ((@results=$sth->fetchrow) != NULL) {
@banner_index[$i]=@results[0]."\n";
$i++;
}
open (banner_index, ">$fullpath/banners.index") or Main::error("unable to write to banners.index.");
print banner_index @banner_index;
close(banner_index);

#close sql connections
$sth->finish;
$dbh->disconnect;

&admin_header;

print "Entry modified.";
&backToMain;
&admin_footer;
}

#ask if the user really want to delete this entry
sub delete_entry {

&admin_header;
print "Delete the following entry?<br><br>
<a href=\"$input{'forwardURL'}\">$input{'display'}</a>
<form action=\"ad-admin.pl\" method=\"post\"> 
<input name=\"action\" type=\"hidden\" value=\"do_delete_entry\">
<input name=\"ID\" type=\"hidden\" value=\"$input{'ID'}\">
 <input type=\"hidden\" name=\"admin\" value=\"$input{'admin'}\">
<input type=\"hidden\" name=\"password\" value=\"$input{'password'}\">
<input type=\"submit\" value=\"Yes\">
</form>
";
&backToMain;
&admin_footer;

}

#actually delte an entry
sub do_delete_entry {

use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
$sth = $dbh->prepare("DELETE FROM $ad_table where ID ='$input{'ID'}'");
$sth->execute or &sql_error($dbh->errstr,2);

#rebuild the banner index file

$sth = $dbh->prepare("Select ID from $ad_table where status='activated'");
$sth->execute or &sql_error($dbh->errstr,2);
$i = 0;
@banner_index="";
while ((@results=$sth->fetchrow) != NULL) {
@banner_index[$i]=@results[0]."\n";
$i++;
}
open (banner_index, ">$fullpath/banners.index") or Main::error("unable to write to $fullpath/banners.index.");
print banner_index @banner_index;
close(banner_index);

#close sql connections
$sth->finish;
$dbh->disconnect;

&admin_header;
print "Entry deleted.";
&backToMain;
&admin_footer;


}


#verify admin password subroutine

sub vpassword {

	$input{'admin'}=~ tr/A-Z/a-z/; 
	$input{'admin'}=~ tr/\s//;
	$input{'password'}=~ tr/A-Z/a-z/; 
	$input{'password'}=~ tr/\s//; 


	my $status=Main::verifyAdmin("$fullpath/$superuser","$input{'admin'}","$input{'password'}","YL","\\|","$fullpath/errorlog.txt","Incorrect Admin logging in attempt|$input{'admin'}|$input{'password'}|$IP|$time");
	if ($status!=1) {
	   
	   &admin_header;
	   print "<h2>Incorrect admin name or password</h2>\n";
           $time=localtime();
	   print "Warning: Your informatoin has been logged for security reasons.<br>\n";
	   print "Your IP Address: $IP<br>";
	   print "Date: $time<br>\n";
	   &admin_footer;
	   exit;
	
	}
	
	
}



#admin header and footer
sub admin_header {
print <<EOF;
<html>
<head>
<title>$software</title>
</head>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0" width="100%">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b>
      </font>
    </td>
  </tr>
  <tr bgcolor="#ffffff">
    <td>
	  <font size="1" face="arial" color="#00000f">
		<b>$description &nbsp;</b>
	  </font>
	</td>
  </tr>
  
 <tr bgcolor="#f0f0ff">
    <td><font size="2" face="arial" color="#000000"><ul>
	<br>
EOF
}

sub admin_footer {

print <<EOF;
	  </ul>
     	</td>
	  </tr>
	    <tr bgcolor="#ffffff">
    <td>
	  <font size="2" face="arial" color="#000000">
		<b>Copyright 1999-2001 CGI-Factory.com of SiliconSoup.com LLC</b>
	  </font>
	</td>
  </tr>
	  </table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>
</body></html>
EOF
$description="";
}


#### back to the main page button

sub backToMain() {

	print qq| 
		  <form action="$mainAdmin" method="post">
		  <input type="hidden" name="admin" value="$input{'admin'}">
		  <input type="hidden" name="password" value="$input{'password'}">
		  <input type="submit" value="Back to the admin main page">
		  </form>
	|;

}

#sql query error handling
sub sql_error ($errorMessage,$errorType) {

#disconnect from the database



	my ($errorMessage,$errorType) = @_;

	#QUERY error
	if ($errorType==2) {
		$sth->finish;
		$dbh->disconnect;	
	}	

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	         <font color="#ff0000"><b>SQL Error message:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Reason/Debugging message:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Additional Info:</b></font><br>
						 Please contact the webmaster or the server admin if you keep getting this message.<br>\n
		   		         If you are the webmaster, there is no need to panic. The scripts are already functioning and that is why you can see this message. The cause of this error is likely to be something minor. For example, incorrect system path or incorrect file permissions.<br>\n
		   	           	 <br><br>
						 If you need any asistance, please visit us at <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	


}


exit;