#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################

#Type in the full system path here if you are using a windows server
$fullpath="./";
####
push(@INC, $fullpath);
#don't change these two vairables unless you know what you are doing
$mainAdmin="ad-admin.pl";
$configurAdmin="configur.pl";
##############################
$cfg="banner_cfg.pl";
#filename for superuser.db
$superuser="superuser.db";
$software="Banner Rotator 3.0 MySQL";

print "Content-type: text/html\n\n";

#import variables. However, use eval to avoid 500 error message 
#when something goes wrong
eval {
require "Main.pm";
};
if ($@) {
&error("Unable to load Main.pm. $@. Please refer to the installation documentation for solutions.");
}

eval {
require "$cfg";
};
if ($@) {
&error("Unable to load $cfg. Please check out the readme file. $@");
}


#user's ip
if (!$ENV{'REMOTE_HOST'}) {
$IP=$ENV{'REMOTE_ADDR'};
}
else {
$IP=$ENV{'REMOTE_HOST'};
}
$time=time;

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
($name, $value) = split(/=/, $pair);
$value =~ tr/+/ /;
$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
$input{$name} = $value;
}

#open the admin password file to see if it exist
open (DETECT,"<$fullpath/$superuser") or &decide;
@detect=<DETECT>;
close (DETECT);

#if the password file is empty, it means it is the first time the user runs setup.pl. Set the admin password.
if (!@detect) {
&decide;
}

#save the password or display the password setting form
sub decide {
if ($input{'action'} eq "firsttime") {
&firsttime;
exit;
}
else {
&setup;	
exit;
}
}


#display the setup page for setting up system variables
if ($input{'action'} eq "mainPage") {
&mainPage;
exit;
}
if ($input{'action'} eq "save") {
&save;
exit;
}


print <<EOF;
<HTML>
<HEAD>
<TITLE>$software</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<center>
<font face="Arial"><font size="+2">
  $software Configurations
</font>
<br>
<br>
Please enter your Super user admin name and password to Login:
<form action="$configurAdmin" method="post">
<b>Super User Admin Name:</b> <input type="text" name="admin">&nbsp;&nbsp;
<b>Password:</b> <input type="password" name="password">
<input type="hidden" name="action" value="mainPage">
<input type="submit" value="ok">
</form>
</center>
</body>
</html>
EOF
exit;

# main page
sub mainPage {

&vpassword;

print <<EOF;
<html>
<head>
  <title>$software</title>
</head>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0">
  <form action="$configurAdmin" method="POST">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b> (Do not use " in any of the fields.)
      </font>
    </td>
  </tr>

  <tr>
    <td>
	  <table border="0" bgcolor="#cccccc" cellspacing="1" cellpadding="1" width="100%">
	    <tr bgcolor="#ffffff">
		  <td width="100%">
			<b>&nbsp;MySQL Server IP or URL:</b>
		  </td>
		  <td>
		    <input type="Text" name="host" value="$host" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
  		    <b>&nbsp;Name of the database assigned to you:</b>
		  </td>
		  <td>
		    <input type="Text" name="database" value="$database" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;MySQL database username:</b>
		  </td>
		  <td>
		    <input type="Text" name="sql_user" value="$sql_user" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;MySQL database password:</b>
		  </td>
		  <td>
		    <input type="Text" name="sql_pass" value="$sql_pass" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;Table name for the script to create and use for the banners:</b>
		  </td>
		  <td>
		    <input type="Text" name="ad_table" value="$ad_table" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;URL to the default banner image when no activated banners are available: Must start with http://</b>
		  </td>
		  <td>
		    <input type="Text" name="default_banner_image" value="$default_banner_image" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;URL to the default banner forward-location when no activated banners are available: Must start with http://</b>
		  </td>
		  <td>
		    <input type="Text" name="default_banner_forward" value="$default_banner_forward" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;URL to the redirect.pl: Must start with http://</b>
		  </td>
		  <td>
		    <input type="Text" name="redirect" value="$redirect" size="60">
		  </td>
		</tr>
	  </table>
	</td>
  </tr>
    <tr bgcolor="#7CA3DE">
    <td>
	<table border="0">
	  <tr>
	    <td>
			<input type="hidden" name="admin" value="$input{'admin'}"><input type="hidden" name="password" value="$input{'password'}">
				  <input type="hidden" name="action" value="save"><input type="submit" value="Modify">
        
		</td>
		</form>
		<td>
		<form action="$mainAdmin\" method=\"post\">
		<input type="hidden" name="action" value="displayAdminMain"><input type="hidden" name="admin" value="$input{'admin'}">
		<input type="hidden" name="password" value="$input{'password'}"><input type="submit" value="Back to the admin main page/Don't save changes">
     	</td></form>
	  </tr>
	  </table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
</html>
EOF
exit;
}
####### save change

sub save {
&vpassword;
$input{'adminEmail'}=~ s/@/\\@/g;
open (main, ">$fullpath/$cfg") or Main::error("Unable to write to $cfg. Please make sure you have chmoded it to \"755\"(chmod it to \"777\" if it still doesn't work)");
print main "\$host=\"$input{'host'}\"\;\n";
print main "\$database=\"$input{'database'}\"\;\n";
print main "\$sql_user=\"$input{'sql_user'}\"\;\n";
print main "\$sql_pass=\"$input{'sql_pass'}\"\;\n";
print main "\$ad_table=\"$input{'ad_table'}\"\;\n";
print main "\$default_banner_image=\"$input{'default_banner_image'}\"\;\n";
print main "\$default_banner_forward=\"$input{'default_banner_forward'}\"\;\n";
print main "\$redirect=\"$input{'redirect'}\"\;\n";
print main "1\;\n";

close(main);


print "The new configuration has been saved. If anything doesn't work out, you can run $configur_admin again to change the settings again. However, if $configur_admin fails to loads itself, you will just have to reupload cfg.pl.\n";
print "<form action=\"$mainAdmin\" method=\"post\">";
print "<input type=\"hidden\" name=\"action\" value=\"displayAdminMain\">";
print "<input type=\"hidden\" name=\"admin\" value=\"$input{'admin'}\">\n";
print "<input type=\"hidden\" name=\"password\" value=\"$input{'password'}\">";
print "<input type=\"submit\" value=\"Back to the admin main page\">";
print "</form>";
print "<font size=\"-1\"><b>Warning: Please close your browser if you want to log off.</b><br>";
print "Copyright 1999-2001 CGI-Factory.com of SiliconSoup.com LLC.</font>";
exit;
}	


	
####this subroutine prints out the admin password setting form
sub setup {


print <<EOF;
<html>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0">
  <form action="$setup" method="POST">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b>
      </font>
    </td>
  </tr>
  <tr bgcolor="#999999">
    <td>
	  <font size="2" face="arial" color="#f0f0f0">
		<b>Please set up your admin name and password</b>
	  </font>
	</td>
  </tr>
  <tr>
  <td cellspacing="0" cellpadding="0">
  		 <table cellspacing="0" cellpadding="0" width="100%">
  		   <tr bgcolor="#f0f0ff">
      		<td>
	  				Admin Name:
			</td>
			<td>		
					<input type=\"text\" name=\"admin_name\">
	  		</td>
  		</tr>
   	   	<tr bgcolor="#ffffff">
       		  <td>
			        Password:
			  </td>
			  <td>
	  			   <input type=\"text\" name=\"password1\">
	  		  </td>
  		 </tr>
       	 <tr bgcolor="#f0f0ff">
       		  <td>
			        Enter the passward again:
			  </td>
			  <td>
	 			 	<input type=\"text\" name=\"password2\">
	 		   </td>
  		 </tr> 
  		</table>
  </td></tr>
  <tr bgcolor="#7CA3DE">
    <td>
	  <input type=\"submit\" value=\"OK\">
	</td>
  </tr>
</table>
<input type=\"hidden\" name=\"action\" value=\"firsttime\">
</form>
</body>
</html>
EOF

exit;

}

#save the admin password
sub firsttime {

$input{'admin_name'}=~ tr/A-Z/a-z/; 
$input{'admin_name'}=~ tr/\s//;
$input{'password1'}=~ tr/A-Z/a-z/; 
$input{'password1'}=~ tr/\s//; 
$input{'password2'}=~ tr/A-Z/a-z/; 
$input{'password2'}=~ tr/\s//; 

@encryptedPassword=Main::encryptPassword($input{'password1'},$input{'password1'},4,"YL");

if (@encryptedPassword[0] == -1) {
print "@encryptedPassword[1]";
exit;
}
if (!$input{'admin_name'}) {
print "Please don't leave the admin name field blank!";
exit;
}


open (PASSWORD, ">$fullpath/$superuser") or Main::error("unable to create the password file");
print PASSWORD "$input{'admin_name'}|@encryptedPassword[1]";
close (PASSWORD);
print "<h2>New admin name and password are saved. Please reload this page to continue setting up this message board.</h2>\n";
exit;
}



###verify the admin password
sub vpassword {

	$input{'admin'}=~ tr/A-Z/a-z/; 
	$input{'admin'}=~ tr/\s//;
	$input{'password'}=~ tr/A-Z/a-z/; 
	$input{'password'}=~ tr/\s//; 


	my $status=Main::verifyAdmin("$fullpath/$superuser","$input{'admin'}","$input{'password'}","YL","\\|","$fullpath/errorlog.txt","Incorrect Admin logging in attempt|$input{'admin'}|$input{'password'}|$IP|$time");
	if ($status!=1) {
	   
	   Main::printHTML("$fullpath/header.txt");
	   print "<h2>Incorrect admin name or password</h2>\n";
       $time=localtime();
	   print "Warning: Your informatoin has been logged for security reasons.<br>\n";
	   print "Your IP Address: $IP<br>";
	   print "Date: $time<br>\n";
	   Main::printHTML("$fullpath/footer.txt");
	   exit;
	
	}
	
	
}

##error handling subroutine. specifile the lockFile path if the file was locked 
sub error($errorMessage,$lockFile) {
	my ($errorMessage,$lockFile) = @_;	
	#clear the lock file	
	if (defined($lockFile)) {
	   &unFlock($lockFile);
	}

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	         <font color="#ff0000"><b>Error message:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Reason/Debugging message:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Additional Info:</b></font><br>
						 Please contact the webmaster or the server admin if you keep getting this message.<br>\n
		   		         If you are the webmaster, there is no need to panic. The scripts are already functioning and that is why you can see this message. The cause of this error is likely to be something minor. For example, incorrect system path or incorrect file permissions.<br>\n
		   	           	 <br><br>
						 If you need any asistance, please visit us at <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	
	
	
}

