#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################
$fullpath="./";
push(@INC, $fullpath);

print "Content-type:text/html\n\n";

#for benchmark purpose
$start=(times)[0];

#load in the required settings
$cfg="banner_cfg.pl";
eval {
require "$cfg";
};
if ($@) {
print "unable to load $cfg. $@";
exit;
}

#load in Main.pm
$mainPM="Main.pm";
eval {
require "$mainPM";
};
if ($@) {
print "unable to load $mainPM. $@";
exit;
}

$dsn = "DBI:mysql:database=$database;host=$host;user=$sql_user;password=$sql_pass";

use DBI;

$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);

&select_banner;

#select banner sub
sub select_banner {
#select a banner to display

#rebuild the banner index file when a banner is expired. $rebuild_index is set to 1 when selec_banner sub is called again(loop)
if ($rebuild_index==1) {
$sth = $dbh->prepare("Select ID from $ad_table where status='activated'");
$sth->execute or &sql_error($dbh->errstr,2);
$i = 0;
@banner_index="";
while ((@results=$sth->fetchrow) != NULL) {
@banner_index[$i]=@results[0]."\n";
$i++;
}
open (banner_index, ">$fullpath/banners.index") or Main::error("unable to write to $fullpath/banners.index.");
print banner_index @banner_index;
close(banner_index);

}
else {
open (banner_index, "<$fullpath/banners.index") or Main::error("unable to open $fullpath/banners.index.");
@banner_index=<banner_index>;
close(banner_index);
}


$index_rows=@banner_index;
open (count, "<$fullpath/bcount.txt") or Main::error("unable to open $fullpath/bcount.txt.");
$count=<count>;
close(count);
$count++;

if ($count >= $index_rows) {
$count=0;
}

# if no activated banners available, display the default banner.
if ($index_rows==0) {
print "<a href=\"$default_banner_forward\"><img src=\"$default_banner_image\" border=\"0\"></a>";
}
else {
open (count, ">$fullpath/bcount.txt") or Main::error("unable to write to $fullpath/bcount.txt.");
print count $count;
close(count);

$id=@banner_index[$count];


$sth = $dbh->prepare("SELECT exp, click, adverOpt FROM $ad_table where ID='$id'");
$sth->execute or &sql_error($dbh->errstr,2);
@results=$sth->fetchrow;
if (@results[2] eq "exp") {

if (@results[0]<=0) {
#the banner is expired, deactivate the banner and reselect a banner
$sth = $dbh->prepare("UPDATE $ad_table SET status='deactivated' where ID='$id'");
$sth->execute or &sql_error($dbh->errstr,2);
$rebuild_index=1;
&select_banner;
}

}
else {
if (@results[1]<=0) {
#the banner is expired, deactivate the banner and reselect a banner
$sth = $dbh->prepare("UPDATE $ad_table SET status='deactivated' where ID='$id'");
$sth->execute or &sql_error($dbh->errstr,2);
$rebuild_index=1;
&select_banner;
}

}
}
#pull the banner data out

$sth = $dbh->prepare("SELECT display, exp, adverOpt, totalExp FROM $ad_table where ID='$id'");
$sth->execute or &sql_error($dbh->errstr,2);

@results = $sth->fetchrow;
print "<a href=\"$redirect?$id\">$results[0]</a><br>";

#store id and exposures into variables
$exp=$results[1];
$totalExp=$results[3]+1;
#decrease exporseur by one and update the database

$exp--;
if (@results[2] eq "exp") {
$sth2 = $dbh->prepare("UPDATE $ad_table SET exp = $exp, totalExp=$totalExp where ID='$id'");
}
else {
$sth2 = $dbh->prepare("UPDATE $ad_table SET totalExp=$totalExp where ID='$id'");
}
$sth2->execute or &sql_error($dbh->errstr,2);


$sth2->finish;
}

$end=(times)[0];
#disconnect from the database
$sth->finish;
$dbh->disconnect;
#print $end-$start;
exit;


#sql query error handling
sub sql_error ($errorMessage,$errorType) {

#disconnect from the database



	my ($errorMessage,$errorType) = @_;

	#QUERY error
	if ($errorType==2) {
		$sth->finish;
		$dbh->disconnect;	
	}	

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	         <font color="#ff0000"><b>SQL Error message:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Reason/Debugging message:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Additional Info:</b></font><br>
						 Please contact the webmaster or the server admin if you keep getting this message.<br>\n
		   		         If you are the webmaster, there is no need to panic. The scripts are already functioning and that is why you can see this message. The cause of this error is likely to be something minor. For example, incorrect system path or incorrect file permissions.<br>\n
		   	           	 <br><br>
						 If you need any asistance, please visit us at <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	


}

