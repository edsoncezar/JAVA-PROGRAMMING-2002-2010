Title: Master P's Messenger
Description: A unique Email messaging for Webmasters. It automatically send all the comments and suggestions to the webmaster's Email address. This script has thank you page, contact page, and the script. Easy to install, no sweat, don't need perl programming knowledge. And the good news is that this Script is a 100% FREE.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=377&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
