MasterP's Messenger v.1.0
http://paoloplace.com/

Note: 
The Demo included in my website(http://paoloplace.com/index2.shtml) can only sent to my email address but if you install the script with correct path the email address will be sent to the email address of the configured script.

Instruction:

1. Configure the contact.html to its correct path to the MAsterP's PErl script(cgi-bin/scriptname.cgi)
2. Configure the Perl script. Each lines has its definition for the guide to config properly.
3. upload all the files according to its folder structure when you unzipped it. The .cgi & .txt is on cgi-bin folder of your webserver.. The html files on the main folder where your index.html is placed.

Chmod:
contact.html 755
thankyou.html 755
.cgi	644
.txt 644

  *** Your instant comment & suggestion Messenger is ready to use ***

For a sign of Thank you, all i just need is your feedback about my script. Please sign to my guestbook and put all your reactions. I appreciate all your opinions (negative&Positive) 

http://paoloplace.com/index2.shtml