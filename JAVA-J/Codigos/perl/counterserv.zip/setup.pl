#NEVER EDIT THIS FILE MANUALLY!!!!
# UNLESS YOU SEE THESE LINES, THEN EDIT THE FIRST 5 VARIABLES AND $Pw_File.
#THEN LET THE MAIN ADMIN TAKE CARE OF THE REST.

$Cgi_Path = "/home/jpsmith/cgi-bin/demo/counter";
$Data_Path = "/home/jpsmith/cgi-bin/demo/counter/data";
$Member_Path = "/home/jpsmith/cgi-bin/demo/counter/members";
$Image_Path = "/home/jpsmith/public_html/demo/counter_images";
$Cgi_Dir = "http://www.jpssoft.com/cgi-bin/demo/counter";
$Image_Directory = "http://www.jpssoft.com/demo/counter_images";

$Image_Data = "$Data_Path/images.dat";
$Pw_File = "$Data_Path/password.txt";
$Data = "$Cgi_Path/setup.pl";
$Member_Data = "$Data_Path/users.dat";

$Counter_Cgi = "counter.cgi";
$New_Cgi = "new.cgi";	
$Edit_Cgi = "member.cgi";	
$Admin_Cgi = "admin.cgi";
$Buffer = 100;

$Site_Title = "JpsSoft Free Counters";
$Page_Color = "#ffffff";
$Font = "Verdana,Tahoma,Arial";
$Font_Size = "2";
$Font_Color = "#000000";
$Link_Color = "#00ff00";
$Active_Link_Color = "#fff0f0";
$Visited_Link_Color = "#dedede";
$Header_Color = "#000080";
$Header_Font = "Verdana,Tahoma,Arial";
$Header_Font_Size = "2";
$Header_Font_Color = "#fde000";
$Window_Color = "#0000ff";
$Window_Font = "Verdana,Tahoma,Arial";
$Window_Font_Size = "2";
$Window_Font_Color = "#ffff00";
$Header = <<EOM;
<center>Welcome to JpsSoft' free counter service.<br>
(This is a header example).
</center>
<br>
EOM
$Footer = <<EOM2;
<br>
<center>
Footer Here
</center>
EOM2
$MHeader = <<EOM3;
<center>
<font face="Verdana,Tahoma,Arial" size="2">
<B>Your Counter</B>
<br>
<TABLE border=0 width=350><TR><TD>
<font face="Verdana,Tahoma,Arial" size="2">
Here you can administer your counter.
You can change the style, logging options, multiple pages, and more.
<BR><BR>
Instructions at the bottom of this page will
tell you how to correctly set up and use your
counter. (This is a header example).
</font>
</TD></TR>
</TABLE>
</center>
<br>
EOM3
$MFooter = <<EOM4;
<br>
<center>
Footer Here
</center>
EOM4
$SHeader = <<EOM5;
<center>
<font face="Verdana,Tahoma,Arial" size="2">
<B>Welcome</B>
<br>
<TABLE border=0 width=350><TR><TD>
<font face="Verdana,Tahoma,Arial" size="2">
Thank you for signing up for JpsSoft free Counter Service.
<BR><BR>
Your Info and login information is below. You should write it down, as you will need it to view your stats and update your counter style and info..
</font>
</TD></TR>
</TABLE>
</center>
<br>
EOM5
$SFooter = <<EOM6;
<br>
<center>
Footer Here
</center>
EOM6
1;

