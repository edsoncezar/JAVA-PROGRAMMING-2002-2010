############################################
#
#
#
#             Run your own Remotly hosted Counter Service v1.0
#
#              By: Jean-Patrick Smith
#
#
#
#
#
#
#############################################
#############################################

Installation Instructions:
1. Check to see if you have all the files:
	admin.cgi
	counter.cgi
	member.cgi
	new.cgi
	password.txt
	setup.pl

2. Open password.txt and set the password. 1 line only.

3. Create a directory for the cgi scripts, one for the data, and one for the members data.

4. Define the following variables in setup.pl
	$Cgi_Path - the full unix path to the scripts
	$Data_Path - the full unix path to the data directory
	$Member_Path - the full unix path to the members data directory
	$Image_Path - the full unix path to where the images will be. (must be accessible through the web, NOT in cgi-bin)
	$Cgi_Dir - the URL of the cgi directory containg the scripts.
	$Image_Directory - the URL of where the images will be

5. Upload the following files onto your server:
   - All files with the .cgi extension should be placed in your cgi directory
   - Password.txt MUST be in the data directory, (or change the variable in setup.pl)
   NOTE: It is important to upload all the files in ASCII mode.

6. Run the admin program and set the options you want.

7. Test it, and your all set. 

Questions? Visit our forum at http://www.jpssoft.com/html/support/forums.shtml
Support: http://www.jpssoft.com/html/support/

Adding counter digits is what will make your service unique, goto the section of your admin called Counter Images.
There are instructions there. For free Counter digits visit the site below, they have tons.
http://www.digitmania.com/contents.html

Some Notes:
When you are adding counter digits in the main admin,
it automatically creates directories for the digits and a small file for the digit in the Image Directory you specified.
So go to the admin section click on counter digits, Goto the bottom of the page and fill in the appropriate info,
then a directory will be made, and all you have to do is upload the counter images to the directory.
(the directory is your $Image_Path/<name of counter image set>)

