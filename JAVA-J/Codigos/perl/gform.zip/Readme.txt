### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Form
Version: 1.0

Info:

G.Form gives your visitors a easy way to contact you, the message then 
gets emailed to you and you can even choice to have a auto-reply sent 
to the sender.

Here is the code:



<form action="http://www.yourdomain.co.uk/cgi-bin/gform.cgi" method="post">

<input type="hidden" name="to_email" value="you@yourdomain.co.uk">
<input type="hidden" name="redirect" value="http://www.yourdomain.co.uk/thanks.html">

Your Name:<br>
<input type="text" name="from_name"><p>
Your Email:<br>
<input type="text" name="from_email"><p>
Subject:<br>
<input type="text" name="subject"><p>
Message:<br>
<textarea cols="40" rows="5" name="body"></textarea><p>

<input type="submit" value="Send Mail">

</form>







G.Scripts @ http://www.grantszone.co.uk/scripts/