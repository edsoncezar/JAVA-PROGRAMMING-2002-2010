##############################################################################
# Cliff's Hangman Version 1.0                                                #
# Copyright 1998 Shaven Ferret Productions                                   #
# Created 10/18/98                                                           #
# Available at http://www.shavenferret.com/scripts                           #
##############################################################################
# COPYRIGHT NOTICE                                                           #
# Copyright 1998 Shaven Ferret Productions All Rights Reserved.              #
#                                                                            #
# This script can be used\modified free of charge as long as you don't       #
# change this header, the part that makes the return link, and any parts     #
# that call the part that makes the return link.  By using this script you   #
# agree to indemnify me from any liability that might arise from its use.    #
#                                                                            #
# Redistributing\selling the code for this program without prior written     #
# consent is expressly forbidden.                                            #
##############################################################################

Hello.  These are the instructions for how to install and use the Hangman
script.  You should have the following files...

        * hangman.cgi ---- the script
        * hangman.txt ---- a list of words and phrases that the game will use
        * readme.txt ----- the file you're reading now
        * images... (you can replace these with your own if you want)
                * black.gif --- a 1X1 pixel black image
                * gallows.gif - the gallows
                * head.gif ---- a really bad picture of my head
                * l_arm.gif --- the right arm (displayed on left)
                * l_foot.gif -- the right foot (displayed on left)
                * l_leg.gif --- the right leg (displayed on left)
                * r_arm.gif --- the left arm (displayed on right)
                * r_foot.gif -- the left foot (displayed on right)
                * r_leg.gif --- the left leg (displayed on right)
                * torso.gif --- the torso
                * l_foot.gif -- the right foot (displayed on left)
                * l_leg.gif --- the right leg (displayed on left)

If you're missing any of these files, you can download them from
http://www.shavenferret.com/scripts/hangman/

Start by opening hangman.cgi in a text editor.  If the path to perl is not
/usr/bin/perl on your system, change the first line to #! and then the path
to perl.  Now scroll down to line 23.  If hangman.txt won't be in the same
directory as hangman.cgi, enter the server path (not the URL) to hangman.txt.
Scroll down to line 26.  If all the words that the game will use share a
common theme, you can enter that theme here to give your users a hint.  Scroll
down to line 30.  Enter the URL of the directory where you plan on putting
all of the files.

Next, you'll probably want to open hangman.txt in your text editor and enter
the words you want the game to use.  This is pretty simple, you just put each
word or phrase on a differant line.  Warning: If you use the text file that
came with this script, all the words will begin with dia.

Upload hangman.cgi and hangman.txt as ascii, and all of the images as binary.
Set hangman.cgi's permissions to 755, and hangman.txt's permissions to 773.

Congratulations, you're done!  

******************************************************************************
* Troubleshooting                                                            
* If you're having problems with the script, please read the following before
* asking me for help.                                                        
******************************************************************************

* Script returns 500 Internal Server Error
        * Make sure you've changed the first line of hangman.cgi to #! and 
          then the path to perl on your system
        * Make sure you've uploaded hangman.cgi as ascii, not binary.
        * Make sure you've set the permissions for hangman.cgi to 755.

* Game is using blanks instead of the words\phrases in hangman.txt
        * Make sure that you've either placed hangman.txt in the same
          directory as hangman.cgi, or entered the server path (not the URL)
          to hangman.txt in hangman.cgi
        * Make sure hangman.txt does not contain any blank lines.
        * Make sure that you've set hangman.txt's permissions to 773.

******************************************************************************

                        If you still need help, go to
                http://www.shavenferret.com/scripts/help.shtml

