#!/usr/bin/perl
#######################################################################
# Title:	CONFIG.pm
# Version: 	1.40
# Date: 	May 14, 2001
# Description:	user defined variables
#
#######################################################################
# COPYRIGHT NOTICE
# Copyright (C) 1998-2001 by Chris Hardie.  All rights reserved.
# For more information, visit
#    http://www.summersault.com/software/db_browser/
#######################################################################
#
# This program is free software; anyone can use, redistribute, and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation (either version 2 of the
# License, or at your option, any later version) so long as this notice
# and the copyright information above remain intact and unchanged.
# Selling this code in any form for any reason is expressly forbidden.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this software; if not, write to
# 	Free Software Foundation, Inc., 59 Temple Place, Suite 330,
# 	Boston, MA  02111-1307 USA
# You may also find the license at:
#  	http://www.gnu.org/copyleft/gpl.html
#
#######################################################################

require Exporter;
@ISA = qw(Exporter);

@EXPORT = qw(
  $database $dbserver $dbport $dbtype $dbuser $dbpass $dbh
  $default_table @active_tables $orahome $proper_names $quick_delete
  $edit_enabled $add_enabled $display_field_types $use_templates
  $bgcolor $textcolor $background 
  $checkboxcolor $fieldboxcolor $databoxcolor $radiobuttoncolor $editcolor $tablewidth
  $titleblock $table_border $cell_spacing $cell_padding $font $template_file
);

use vars qw (
  $database $dbserver $dbport $dbtype $dbuser $dbpass $dbh
  $default_table @active_tables $orahome $proper_names $quick_delete
  $edit_enabled $add_enabled $display_field_types $use_templates
  $bgcolor $textcolor $background 
  $checkboxcolor $fieldboxcolor $databoxcolor $radiobuttoncolor $editcolor $tablewidth
  $titleblock $table_border $cell_spacing $cell_padding $font $template_file
);

# USER DEFINED VARIABLES

$database = "your_database";
# Name of the database to connect to

$dbserver = "localhost";
# hostname of database server

$dbport = "5432";
# port that database server runs on
# (usually only needed for Postgres)

$dbtype = "Pg";
# database type ("Pg" or "Oracle" or "mysql")
# you need DBD module of same name, currently only Postgres, Oracle, or MySQL

$dbuser = "";
# User to connect as

$dbpass = "";
# Password to connect with (blank if none)

$default_table = 'default_table';
# Default table name to work with

@active_tables = ();
# List of tables in the database to work with
# If you leave this blank, DB_Browser will try to get a list of tables from
# your database's data dictionary.  If you populate this, it will ONLY use
# the tables listed here.

# Oracle Home
$orahome = '/usr/oracle/app/oracle/product/8.0.5';

# Set to "1" to display fancy formatting of field names in search
#        "0" to display field names as they come from the database
$proper_names = 1;

# Set to "1" to display option to delete row from search results screen (dangerous)
#        "0" not to
$quick_delete = 0;

# Display the type of field next to each input field
$display_field_types = 1;

# Set to "1" to allow users to edit (and delete) existing records in the database
#        "0" to remove this functionality
$edit_enabled = 1;

# Set to "1" to allow users to add new records to the database
#        "0" to remove this functionality
$add_enabled = 1;

# use HTML::Template module (recommended, if you can; must have HTML::Template installed!!)
$use_templates = 1;

# HTML::Template file
$template_file = "templates/page.tmpl";


# HTML Formatting Variables
$bgcolor = "#ffffff";
$textcolor = "#000000";
#$background ="/textures/finepaper.jpg";
$checkboxcolor = "#007700";
$fieldboxcolor = "#cc9933";
$databoxcolor = "#00baaa";
$radiobuttoncolor = "#332211";
$editcolor = "#cccc99";
$tablewidth = "75%";
$titleblock = "#000099";
$table_border  = '1';
$cell_spacing = '1';
$cell_padding = '1';
$font = '-1';

# End User defined variables
