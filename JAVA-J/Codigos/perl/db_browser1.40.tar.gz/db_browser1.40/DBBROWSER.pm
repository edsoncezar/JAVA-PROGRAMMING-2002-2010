#!/usr/bin/perl
#######################################################################
# Title:	DBBROWSER.pm
# Version: 	1.40
# Date: May 14, 2001
# Description:	the library for DB_Browser
#
#######################################################################
# COPYRIGHT NOTICE
# Copyright (C) 1998-2001 by Chris Hardie.  All rights reserved.
# For more information, visit
#    http://www.summersault.com/software/db_browser/
#######################################################################
#
# This program is free software; anyone can use, redistribute, and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation (either version 2 of the
# License, or at your option, any later version) so long as this notice
# and the copyright information above remain intact and unchanged.
# Selling this code in any form for any reason is expressly forbidden.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this software; if not, write to
# 	Free Software Foundation, Inc., 59 Temple Place, Suite 330,
# 	Boston, MA  02111-1307 USA
# You may also find the license at:
#  	http://www.gnu.org/copyleft/gpl.html
#
#######################################################################

# NOTE: DO NOT MODIFY ANYTHING HERE
# See CONFIG.pm for user defined variables (new in 1.40b3)

package DBBROWSER;
require Exporter;
@ISA = qw(Exporter);

# Make the functions available by default
@EXPORT = qw(
  &execsql
  &fancy_field_name
  &get_cols
  &html_foot
  &html_head
  &parse_form
  &set_field_size
  &create_field
  &error
  &connectdb
  &disconnectdb
  &data_into_form
  &array_in
  &print_tmpl_page
  &mysql_get_pri_key
  %FORM
  $db_browser_version
  @ftypes_text @ftypes_extendedtext @ftypes_numeric @ftypes_date @ftypes_bool
  $DBROWIDNAME $DBLIKENAME
  $POSTGRES $ORACLE $MYSQL
);

use vars qw (
  %FORM
  $db_browser_version
  @ftypes_text @ftypes_extendedtext @ftypes_numeric @ftypes_date @ftypes_bool
  $DBROWIDNAME $DBLIKENAME
  $POSTGRES $ORACLE $MYSQL
);

use strict;
use CONFIG;
use DBI;
use CGI qw/:standard/;

#
#################

$db_browser_version = "1.40";

# Code developers: this is where a lot of abstraction takes place.
# Edit/update this information to add support for other databases
#
# DBROWIDNAME: the name the database uses for a unique (across the entire
#             database) row identifier
# DBLIKENAME: the SQL operator version of Oracle's "like" or Postgres` "~"
# @ftypes_XXX: the data type ids used by the database.  This is used in
#             determining field size, quote delimiters, etc. for dynamic
#             forms and SQL statements.

if ($dbtype eq 'Pg') {
  $POSTGRES = 1;
  $DBROWIDNAME = 'oid';
  $DBLIKENAME = '~~';

  @ftypes_text = ('25', '18', '1043', '1042');
  @ftypes_extendedtext = ('1043', '25');
  @ftypes_numeric = ('23', '701');
  @ftypes_date = ('702', '1082','1083', '1184', '1186');
  @ftypes_bool = ('16');

} elsif ($dbtype eq 'Oracle') {

  $ORACLE = 1;
  $DBROWIDNAME = 'rowid';
  $DBLIKENAME = 'like';

  @ftypes_text = ('12');
  @ftypes_extendedtext = ();
  @ftypes_numeric = ('3');
  @ftypes_date = ('9');
  @ftypes_bool = ();

} elsif ($dbtype eq 'mysql') {

  $MYSQL = 1;

  # $DBROWIDNAME:
  # (See README.MYSQL_USERS for full explanation)
  #
  # With mysql, there is NO default row identifier. So to use this
  # program, you must create one for each table, something like
  # 'rowid INT NOT NULL'
  # or 'rowid INT NOT NULL PRIMARY KEY AUTO_INCREMENT'
  # With mSQL, $DBROWIDNAME = '_rowid';

  $DBROWIDNAME = 'rowid';
  $DBLIKENAME = 'like';

  # Derived from ISO standard for SQL
  @ftypes_text = ('12');
  @ftypes_extendedtext = ('-1');
  @ftypes_numeric = ('2','3','4','5','6','7','8');
  @ftypes_date = ('9','11');
  @ftypes_bool = ('-6');
}

return 1;
exit;


#################
# This routine handles all errors that could happen with any script
#
#################

sub error {

  my ($problem,$script) = @_;

  my $html_out;

  if ($problem eq 'connect') {
     $html_out = "Can't connect to $database: $DBI::errstr.<P>";
  }
  elsif ($problem eq 'prep_sql') {
     $html_out = "Can't prepare statement: $DBI::errstr.<P>";
  }
  elsif ($problem eq 'sql') {
     $html_out = "Can't execute statement: $DBI::errstr<P>\n";
  }
  elsif ($problem eq 'request_method') {
     $html_out = "You used an invalid request method.  Contact the system adinistrator.<P>\n";
  }
  elsif ($problem eq 'referer') {
     $html_out = "You requested this page from an invalid client ($ENV{'REMOTE_HOST'}). Contact the system administrator.<P>\n";
  }
  elsif ($problem eq 'bad') {
     $html_out = "There's some bad stuff going on in the back.  Get out while you can.<P>\n";
     $html_out .= "Relevant errors: $!<P>\n";
  } 
  elsif ($problem eq 'auth') {
     $html_out = "This feature is not enabled for this instance of DB_Browser.<P>\n";
  } 

  else {
    $html_out = "Problem: $problem<P>\n";
  }

  &print_tmpl_page(title=> "Error Results", header=>"Error Results", content=>$html_out);
  exit;

 }

#################
# This routine connects to the database
#
#################

sub connectdb {

  if ($ORACLE) {
    # Oracle
    $ENV{ORACLE_HOME} = "$orahome";
    # Needs to include database host!
    $dbh = DBI->connect($database, $dbuser, $dbpass, $dbtype)
      || error('connect', $0);

  } elsif ($POSTGRES) {
    # Postgres
    my $data_source = "dbi:$dbtype:dbname=$database;host=$dbserver;port=$dbport";
    $dbh = DBI->connect("$data_source", $dbuser, $dbpass)
      || &error("Can't connect to $data_source: $DBI::errstr.", $0);

  } elsif ($MYSQL) {
    # MySQL
    my $data_source = "DBI:mysql:$database:$dbserver";
    $dbh = DBI->connect($data_source, $dbuser, $dbpass)
      || &error("Can't connect to $data_source: $DBI::errstr.", $0);
  }

}

sub disconnectdb {

  # mysql gives a warning for this command
  unless ($MYSQL) { $dbh->disconnect; }

}

#################
# This routine executes a sql statement and returns the results
#
#################

sub execsql {

  my ($sql_statement) = @_;

  my $sth = $dbh->prepare($sql_statement) || &error('prep_sql', $0);

  if ($dbh) {
    if (defined($sql_statement)) {
		  $sth->execute || &error('sql', $0);
    }
    else {
      &error('sql', $0);
    }
  }
  else {
    &error('connect');
  }

  # now that MySQL supports some basic transactions, you may want to modify this
  unless ($MYSQL) { $dbh->commit; }

  return $sth;
}

sub print_tmpl_page {

  my $html;

  my %args = (
    template_file                     => $template_file,
    title                             => undef,
    header                            => undef,
    instruct                          => undef,
    content                           => undef,
    table                             => $default_table,
    @_
  );

  my $navbar = "<CENTER>|";

  if ($edit_enabled) {
    $navbar .= qq { -<A HREF="search.cgi?dbb_db=$args{table}">Search / Edit</a>-} 
  } else {
    $navbar .= qq { -<A HREF="search.cgi?dbb_db=$args{table}">Search</a>-};
  }

  $navbar .= qq { -<A HREF="add.cgi?dbb_db=$args{table}">Add</a>-} if ($add_enabled);

#  $navbar .= qq { -<A HREF="convert.cgi?dbb_db=$args{table}">UpdateBot</a>-} if ($edit_enabled);
  
  $navbar .= qq { |<BR> };

  my $credit = qq {
        <!-- The following lines must remain intact if you want to use this software for free -->
          <a href="http://www.summersault.com/software/db_browser/">DB_Browser</a> v$db_browser_version by 
        <a href="http://www.summersault.com/chris">Chris Hardie</A></CENTER>
  };

  if ($use_templates) {
    require HTML::Template;
    import HTML::Template;
    # open the html template
    my $template = HTML::Template->new(filename => $args{template_file});
  
    # fill in some parameters
    $template->param(
        DOC_TITLE => $args{title},
        CONTENT => $args{content},
        HEADER => $args{header},
        INSTRUCT => $args{instruct},
        NAVBAR => $navbar,
        CREDIT => $credit
    );
    
    # send the obligatory Content-Type
    $html .= "Content-Type: text/html\n\n";
  
    # print the template
    $html .= $template->output;
  } else {
    my %page_content = (
        DOC_TITLE => $args{title},
        CONTENT => $args{content},
        HEADER => $args{header},
        INSTRUCT => $args{instruct},
        NAVBAR => $navbar,
        CREDIT => $credit
    );
    # send the obligatory Content-Type
    $html .= "Content-Type: text/html\n\n";

    $html .= &print_generic_page(%page_content);    
  }
  
  print $html;
}

sub print_generic_page {
# should only be called by print_tmpl_page  
  
  my (%page_content) = @_;

  my $html = qq {
    <html>
    <head>
    <title>DB_Browser: $page_content{DOC_TITLE}</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body bgcolor="#FFFFFF">
    <TABLE BORDER=1>
      <TR>
        <TD BGCOLOR="#000099">
          <FONT COLOR="white" SIZE=-1><CENTER><B>DB_Browser</B></CENTER></FONT>
        </TD>
      </TR>
    </TABLE>
    <P><CENTER><FONT SIZE=+2>$page_content{HEADER}</FONT></CENTER></P>
    <P>$page_content{INSTRUCT}</P>
    <P>$page_content{NAVBAR}</P>
    <P>$page_content{CONTENT}</P>
    <p>&nbsp;</p>
    <P>$page_content{NAVBAR}</P>
    $page_content{CREDIT}
    <p>&nbsp;</p>
    </body>
    </html>
  };

  return $html;
  
}

sub array_in {

  my ($variable, @array) = @_;

  my $i;
  foreach $i (@array) {
    if ($variable == $i) {
      return 1;
    }
  }
  return 0;

}

sub get_cols($) {

  my ($table) = @_;

  my $sql_statement = "select * from $table where (1 = 0)";

  my $query = &execsql($sql_statement);

  my $nfields = $query->{NUM_OF_FIELDS};

  return ($query, $nfields);

}

sub create_field {

  my ($name, $ftype, $precision, $value) = @_;
  my $html;

  my ($size, $size_name);
  if (&array_in($ftype, @ftypes_text)) { 
    $size = 40; 
    $size_name = "text";
  } elsif (&array_in($ftype, @ftypes_bool)) { 
    $size = 2; 
    $size_name = "boolean";
  } elsif (&array_in($ftype, @ftypes_date)) { 
    $size = 10; 
    $size_name = "date/datetime";
  } elsif (&array_in($ftype, @ftypes_numeric)) { 
    $size = 10; 
    $size_name = "numeric";
  } else { 
    $size = 35; 
    $size_name = "other";
  }

  if ((not &array_in($ftype, @ftypes_extendedtext)) && (length($value) < 50)) {
    $html .= qq {<INPUT TYPE=text NAME="$name" SIZE=$size VALUE="$value"> };
  } else {
    $html .= qq {<TEXTAREA NAME="$name" ROWS=3 COLS=40 WRAP=virtual>$value</TEXTAREA>};
  }

  $html .= qq { (<I>$size_name</I>) } if ($display_field_types);

  return $html;

}  


sub fancy_field_name($) {

  my ($fname) = @_;
 
  $fname =~ s/_/ /gi;
  $fname =~ s/(\w+)/\u\L$1/g;

  return $fname;

}

#################
# This routine parses the variables passed in a form into $FORM{'varname'}
#
#################

sub parse_form {
    
#  my %FORM;
  foreach my $v (param) { 
        my @v =  param $v;
        (scalar @v == 1) ? ($FORM{$v} = shift @v) : ($FORM{$v} = \@v);
  }
#  return %FORM;

}

# This converts the results from a $query into a table

sub data_into_form {

  my ($query, $db) = @_;

  my $nfields = $query->{NUM_OF_FIELDS};

  my @data_in_form = "<table 
    width=$tablewidth
    bgcolor=$editcolor 
    border=$table_border 
    cellspacing=$cell_spacing
    cellpadding=$cell_padding>\n\t<TR>\n";

  push(@data_in_form, "<TD>&nbsp;</TD>\n");

  my $fc; # field count

  for($fc=1; $fc != $nfields; $fc++)
  {
     my $fname = $query->{NAME}->[$fc];
     push(@data_in_form, qq {\t\t<TD><CENTER><FONT SIZE=$font><B>
     <INPUT TYPE=SUBMIT NAME="dbb_order_by" VALUE="$fname"></B>
     </FONT></CENTER></TD>\n});
  }

  push(@data_in_form, "\t</TR>\n");

  my (@nrow, $uri_column);
  while (@nrow = $query->fetchrow) {
    push(@data_in_form, "\t<TR><TD><CENTER>\n");
    my $first = 0;
    foreach my $column (@nrow) {
      $column = escapeHTML($column);
      if ($first == 0) {
        $uri_column = $column;
        # Oracle's OIDs sometimes have   
        $uri_column = CGI::escape($uri_column);
        push(@data_in_form, qq{ 
          <A href="edit.cgi?dbb_action=edit&dbb_db=$db&dbb_oid=$uri_column">edit</a>} ) if ($edit_enabled);
        push (@data_in_form, qq  { | 
          <A href="edit.cgi?dbb_action=delete&dbb_db=$db&dbb_oid=$uri_column">delete</a>} ) if ($quick_delete && $edit_enabled);
        push(@data_in_form,"&nbsp;</CENTER></TD>\n");
        $first = 1;
      } else {
         $column=~s/ *$//g;
         push(@data_in_form,"\t\t<TD><FONT
             SIZE=$font>$column&nbsp;</FONT></TD>\n");
      }
    }
    push(@data_in_form,"\t</TR>\n");
  }
  push(@data_in_form,"</Table>\n");
  return(@data_in_form);

}

sub form_list_to_array {
 
  my ($form_list) = @_;
  my @new_array;
 
  if (ref $form_list) {
    (@new_array) = @{$form_list};
  } else {
    push @new_array, $form_list;
  }

  return @new_array;
  
}

sub mysql_get_pri_key {
  
  my ($table) = @_;
  my $pri_key_field;
  
  my $sth = $dbh->prepare("DESCRIBE $table");
  $sth->execute();
  
  while (my $desc = $sth->fetchrow_hashref) {
    if ($desc->{'Key'} eq 'PRI') {
      $pri_key_field = $desc->{'Field'};
    }
  }

  $pri_key_field = $DBROWIDNAME if (!$pri_key_field);

  return $pri_key_field;

}

sub get_active_tables {

  if (scalar(@active_tables) == 0) {
    @active_tables = $dbh->tables();
  };
}

1;
__END__
