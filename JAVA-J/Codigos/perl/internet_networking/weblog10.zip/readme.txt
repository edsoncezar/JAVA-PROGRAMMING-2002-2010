
       4est web designs

 weblog, version 1.70

 Homepage: http://www.semithere.com
 Email: fej84@yahoo.com
 Last modified: 03.14.2003
 This script is � 1998-2003 Forrest Jones

======================================================

INCLUDED IN THIS DISTRIBUTION:
      ver.txt <-> version history
   readme.txt <-> this file
   weblog.cgi <-> the program
template.html <-> the template file

INSTALLATION:
1) Open the weblog.cgi in a text editor and configure
2) Open the template.html in a text editor and edit it, leaving the <!MAIN> tag intact
3) Upload the weblog.cgi and template.html to your server
4) Create directories: working and articles, CHMOD 757
5) Lastly CHMOD the weblog.cgi to 755

HOW TO POST:
Currently there are two supported ways of posting to this weblog.
1) For standard posting you can type this to your web browser:
   http://www.your_url.com/weblog/weblog.cgi?action=post

2) For editing your entries (only works for the current month)
   you can type this to your web browser:
   http://www.your_url.com/weblog/weblog.cgi?action=boss_post

EDITING YOUR ENTRY:
You can edit the active month entries using the boss post screen.
all you do is type in the ID No. of the entry you would like to edit
into the ID Number field and type in the new info into the other fields,
however if you where only editing the text for example, you would not
need to reenter the info into the other boxes as that info is preserved.

IN CLOSING:
If you plan to use this script i would appreciate it if you would add a 
link to my web site.

Have Fun,
 4est