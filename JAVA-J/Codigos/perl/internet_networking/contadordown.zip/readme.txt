                                Contador de Downloads Vers�o 1.0, Iron Scripts

Todos os direitos reservados a Iron Scripts, www.ironscripts.tk
Para obter qualquer tipo de ajuda sobre esse script, utilize nosso forum, em nosso website

Siga abaixo as principais dicas para instala��o do topsites:

INSTALA��O:

      Para a instala��o, transfira todos os arquivos para um diret�rio �nico, e configure o 
config.pl, depois basta dar chmod 755 nos arquivos .cgi e .pl, e 666 no database.inf
      Para utilizar a �rea administrativa, entre no admin.cgi com a senha configurada no config.pl

MODO DE USAR:
      Basta utilizar a url de download "download.cgi?id=XX", onde XX � a id referente ao download.
      Para gerenciamento do script, utilize o admin.cgi

Iron Scripts - Contador de Downloads, Vers�o 1.0 - www.ironscripts.tk
Uma parceria entre Allmasters e Zmaters