$db="database.inf";
## Arquivo de registros
## Recomenda-se usar path

$arq="inflog.inf";
## Arquivo de log da administra��o, ele ser� criado ap�s o primeiro acesso administrativo
## Recomenda-se usar path

$sadm="senha";
## Senha Administrativas

$fdo="http://www.seusite.com/download.cgi";
## URL completa para o download.cgi

################### Formul�rio - N�o Mexa depois daqui

   read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
   if (length($buffer) < 5) {
         $buffer = $ENV{QUERY_STRING};
    }
 
  @pairs = split(/&/, $buffer);
   foreach $pair (@pairs) {
      ($name, $value) = split(/=/, $pair);

      $value =~ tr/+/ /;
      $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

      $FORM{$name} = $value;
      $form{$name} = $value;
      $in{$name} = $value;
   }

1;