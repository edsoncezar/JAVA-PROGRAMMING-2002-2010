#!/usr/bin/perl -w

# Signature sending is optional and will only be used if you click "use sig".
# You can change and save your present copy of Signature by clicking "save sig" otherwise
# it will use the last saved version of it


use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;
require SDBM_File;

my (%sig, %emails);
my $sigsave   = "sig.dbm";
my $lock      = "pass";    #password
my $list      = "list.dbm";

my $adminmail = "admin\@test.com";
my $sendmail  = "/usr/lib/sendmail";
my $unsub     = "http://sulfericacid.perlmonk.org/test/how.pl";  # unsub link

tie %emails, 'SDBM_File', $list, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
}

tie %sig, 'SDBM_File', $sigsave, O_CREAT | O_RDWR, 0644;
if ( !tied %sig ) {
    print "database unsuccessful $!.\n";
}

print header, start_html('Email Management');

print start_form(), table(
    Tr(
        td("Subject: "),
        td(
            textfield(
                -name => 'subject',
                -size => 40
            )
        )
    ),
    Tr(
        td("Message: "),
        td(
            textarea(
                -name    => 'message',
                -columns => 40,
                -rows    => 5
            )
        )
    ),
    Tr(
        td("Signature: "),
        td(
            textarea(
                -name    => 'signature',
                -default => $sig{'default'},
                -columns => 40,
                -rows    => 5
            )
        )
    ),
    Tr(
    	td("Password: "),
    	td(
    		password_field(
    			-name	=> 'password',
    			-size	=> 10
    		)
    	)
    ),
    Tr(
        td(
checkbox(-name=>'use',
			   -value=>'yes',
			   -label=>'Use signature'),
		)
	),	   
	Tr(
		td(           
checkbox(-name=>'save',
			   -value=>'yes',
			   -label=>'Save signature'),
		)

	),
        td(submit('button','submit'))
    ),
  end_form(), 
  hr();
print "Usefull commands:<br>\n";
print "[name]  = user's name<br>\n";
print "[time]  = mailing time<br>\n";
print "[unsub] = unsub url<br><br><br>\n";

if ( param() ) {

# rid ourselves from those nasty params
my $message   = param('message');
my $password  = param('password');
my $subject   = param('subject');
my $signature = param('signature');
my $save      = param('save');
my $use       = param('use');
my $time      = localtime;

if ($password ne $lock) {
print "Wrong password.  Email rejected from server.\n";
}
else {
    if ( $message eq "" || $subject eq "" ) {
        print "Your subject or email content was missing.\n";
        exit;
    }
    else {
    
        if ( $save eq "yes" ) {
        print "<br>";
        print "Saving to database...<br>\n";
                $sig{'default'} = $signature;
                $sig{'stored'} = $sig{'default'};
        print "Your Signature has been saved.<br><br>\n";
    }
        print "<br>\n";

        while ( my ( $key, $value ) = each(%emails) ) {
                    # Email Subs, special commands
                    
            my $editmes = $message;             # let's not edit $message
            $editmes =~ s/\[name\]/$value/g;    #[name] = user name
            $editmes =~ s/\[time\]/$time/g;     #[time] = time sent 
            $editmes =~ s/\[unsub\]/$unsub/g;   #[unsub] = unsubscribe email  

			my $editsig = $signature;           # let's not edit $signature
            $editsig =~ s/\[name\]/$value/g;    #[name] = user name
            $editsig =~ s/\[time\]/$time/g;     #[time] = time sent 
            $editsig =~ s/\[unsub\]/$unsub/g;   #[unsub] = unsubscribe email   
            
            my $editsub = $subject;             # let's not edit $subject
			$editsub =~ s/\[name\]/$value/g;    # [name] = user name       
       
            open( MAIL, "| $sendmail -t" );
            print MAIL "To: $key\n";
            print MAIL "From: $adminmail\n";
            print MAIL "Subject: $editsub\n\n";
            print MAIL "$editmes\n";
             if ( $use eq "yes" && $signature ne "" ) {          
                print MAIL "$editsig\n";
            }
            print MAIL ".\n";
            close(MAIL);         
        }
my $time      = localtime;
print "<b>Email successfully sent on $time</b>";
    }

}
}
untie %emails;
untie %sig;

