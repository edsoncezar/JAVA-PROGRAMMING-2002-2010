#!/usr/local/bin/perl

$|=1;
print "Content-type: text/html\n\n";		

$VERSION='2.0';					
# V1.0 : 06/15/2002
##############################################################################
# This is a freeware script written by Anas Elhalabi, MD.                                               
# You can change anything you want in it, but let me tell you something                     
# It won't really work if you damage the core of it.                                                        
# Other awsome scripts are available on  http://perlmart.cjb.net                                   
# If you need help installing this script you can always go to                                        
# http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
#
# This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License included in this package for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                             
##############################################################################
&init;						


if ($ENV{'QUERY_STRING'} ne '') {		# 
  %form=&receiveget;			# 
}

if ($form{'verifmod'} ne '') {			# 
  &verifie_module($form{'verifmod'});		# 
} elsif ($ENV{'QUERY_STRING'} eq 'listmod') {	#
  &liste_modules;				#
} elsif ($form{'ORD_version'}) {
  &admin_version;
} elsif ($form{'ORD_info'}) {
  &admin_info;
} else {					#
  &main;					# 
}





sub main {
my ($message);

  # Petit formulaire en haut de page
  $message.='<div align="center"><center><form method="GET" action="'.$CONF{'CGI_URL'}.'">';
  $message.=' <input type="submit" name="ORD_version" value="Check for Updates"> &nbsp; ';
  $message.='<input type="submit" name="ORD_info" value="French"></form></center></div>'."\n";

  $message.='<div align="center"><center><table border="0" cellpadding="1" width="90%">'."\n";

  # 
  $message.='<tr bgcolor="#000000"> <td colspan="2" bgcolor=#ffffff> <font face="Verdana,Verdana" size="1" color="#000000"> <b>Server Settings</b> </td> </tr>'."\n";
  $message.=" <tr><td>$FONT Date/Time: </b></font></td><td>$FONT".&getdate."</b></font></td></tr>\n";
  $message.=" <tr><td>$FONT Operating System: </b></font></td><td>$FONT $^O </b></font></td></tr>\n";

  # 
  ($buf1,$buf2)=&get_uname_info;
  $message.=" <tr><td>$FONT Operating System Version: </b></font></td><td>$FONT $buf1 </b></font></td></tr>\n";
  $message.=" <tr><td>$FONT Hardware: </b></font></td><td>$FONT $buf2 </b></font></td></tr>\n";
  $message.=" <tr><td>$FONT Host Name: </b></font></td><td>$FONT ".&hostname."</b></font></td></tr>\n";

  # 
  ($buf1,$buf2,$buf3)=&get_uptime_info;
  $message.=" <tr><td>$FONT Last time rebooted: </b></font></td><td>$FONT $buf1</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT Average Usage: </b></font></td><td>$FONT $buf2</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT Connected Users: </b></font></td><td>$FONT $buf3</b></font></td></tr>\n";
  
  # 
  $message.='<tr bgcolor="#000000"> <td colspan="2" bgcolor=#ffffff> <font face="Verdana,Verdana" size="1" color="#000000"> <b>Software Paths :</b> </td> </tr>'."\n";
  $message.=" <tr><td valign=\"top\">$FONT sendmail  : </b></font></td><td>$FONT".&emplacement_programme('sendmail','/usr/lib/sendmail','/usr/bin/sendmail','/bin/sendmail','/usr/sbin/sendmail','/usr/local/bin/sendmail','/usr/local/lib/sendmail')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT whois  : </b></font></td><td>$FONT".&emplacement_programme('whois','/usr/bin/whois','/bin/whois','/usr/local/bin/whois')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT pgp  : </b></font></td><td>$FONT".&emplacement_programme('pgp','/bin/pgp','/usr/bin/pgp','/usr/local/bin/pgp')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT tar  : </b></font></td><td>$FONT".&emplacement_programme('tar','/bin/tar','/usr/bin/tar','/usr/local/bin/tar')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT gunzip  : </b></font></td><td>$FONT".&emplacement_programme('gunzip','/bin/gunzip','/usr/bin/gunzip','/usr/local/bin/gunzip')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT gzip  : </b></font></td><td>$FONT".&emplacement_programme('gzip','/bin/gzip','/usr/bin/gzip','/usr/local/bin/gzip')."</b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT sh  : </b></font></td><td>$FONT".&emplacement_programme('sh','/bin/sh')."</b></font></td></tr>\n";

  # 
  $message.='<tr bgcolor="#000000"> <td colspan="2" bgcolor=#ffffff> <font face="Verdana,Verdana" size="1" color="#000000"> <b>Perl Info:</b> </td> </tr>'."\n";
  $message.=" <tr><td valign=\"top\">$FONT Installed Perl Version: </b></font></td><td>$FONT $] </b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT /usr/local/bin/perl  installed?: </b></font></td><td>$FONT";
    if (-e "/usr/local/bin/perl") {		# Si /usr/local/bin/perl existe...
      $message.='YES, version :<br>';
      $buf='';
      eval { $buf=`/usr/local/bin/perl -v`;};	# 
      $buf=~ s/copyright.*//is;			# 
      $buf=~ s/^\n+//igs;			#
      $buf=~ s/\n+/<br>/igs;			# 
      $message.="<small>$buf</small>";		#
    } else {					# 
      $message.="NO";				# 
    }
  $message.="</b></font></td></tr>\n";

  $message.=" <tr><td valign=\"top\">$FONT /usr/bin/perl Installed?: </b></font></td><td>$FONT";
    if (-e "/usr/bin/perl") {
      $message.='YES, version :<br>';
      $buf='';
      eval { $buf=`/usr/bin/perl -v`;};
      $buf=~ s/copyright.*//is;
      $buf=~ s/^\n+//igs;
      $buf=~ s/\n+/<br>/igs;
      $message.="<small>$buf</small>";
    } else {
      $message.="NO";
    }
  $message.="</b></font></td></tr>\n";


  # INSTALLED PERL MODULES :
  $message.='<tr bgcolor="#000000"> <td colspan="2" bgcolor=#ffffff> <font face="Verdana,Verdana" size="1" color="#000000"> <b>Installed Perl Modules :</b> </td> </tr>'."\n";
  $message.=" <tr><td valign=\"top\">$FONT List of all installed Perl modules on this server: </b></font></td><td>$FONT <a href=\"$CONF{CGI_URL}?listmod\">CLICK HERE</a><br> (This may be long....,Please wait) </b></font></td></tr>\n";
  $message.=" <tr><td valign=\"top\">$FONT Check if a module is installed<b> AND is running</b>:</b></font></td><td>$FONT <form action=\"$CONF{CGI_URL}\" method=\"GET\">Module's <u>exact</u> Name (without &quot;.pm&quot;) :<br>\n<input type=\"text\" name=\"verifmod\" size=\"16\"><input type=\"submit\" value=\"Go!\"><br><small>Examples: CGI or LWP::Simple or DBD::mysql</small></form> </b></font></td></tr>\n";

  # :
  $message.='<tr bgcolor="#000000"> <td colspan="2" bgcolor=#ffffff> <font face="Verdana,Verdana" size="1" color="#000000"> <b>Variables:</b> </td> </tr>'."\n";

  # Pour),
  # on affiche .
  $ENV{'PATH'}=~ s/\:/\: /gs;		# un peulignes
  foreach $key (sort(keys(%ENV))) {
    $message.=" <tr><td valign=\"top\">$FONT <font color=\"#000000\">$key</b></font>:".($AIDENV{"$key"} ne '' ? "<br><small>$AIDENV{$key}</small>" : '')."</b></font></td><td>$FONT <font color=\"#000000\">".$ENV{"$key"}."</b></font></b></font></td></tr>\n";
  }

  $message.="</table></center></div>\n";

  # On t
  &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$message);

}









#############################################################
############                                                            ###############
############  SUB=ROUTINES made by Anas Elhalabi############
############                                                            ###############
################################################
sub receiveget {
my (%postdata)=();
my ($data,$d,$nom,$valeur)=();

  if ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $data=$ENV{'QUERY_STRING'};
    # s�paration de la chaine par paires nom=valeur
    foreach $d (split('&',$data)) {
      # s�parer les paires nom=valeur 
      ($nom,$valeur)=split('=',$d);
      $nom=&url_decode($nom);
      $valeur=&url_decode($valeur);
      # paires rang�es dans data
      $postdata{$nom}=$valeur;
    }
  }
  return %postdata ;
}
################################################
sub url_decode {
my ($s)=@_;
  #Il faut d�coder les donn�es transmises.
  $s=~ tr/+/ /;
  $s=~ s/%([0-9A-F][0-9A-F])/pack("C",oct("0x$1"))/ge;
  $s;
}
################################################
sub msg_fin {
my ($titre,$tip)=@_;

  ## Made by Anas Elhalabi # aelhalabi@hotmail.com ####################
  ## Please give credit to the author                                                                      #

  print <<_EOM_;
  <html>
  <head> <title>$CGI_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<meta NAME="TITLE" CONTENT="PerlMart ServerTester By Anas Elhalabi">
<meta NAME="DESCRIPTION" CONTENT="ServerTester is a simple Perl script that tells you more than your hosting service does about your server">
<meta NAME="KEYWORDS" CONTENT="Perl,CGI,Server,Serveur,servers,Script,Test,ServerTester,Anas,Elhalabi,Perlmart">
<meta HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<meta HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="French, EN-US">
<meta HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Document">
<meta NAME="REVISIT-AFTER" CONTENT="7 days">
<meta name="robots" content="ALL">
<meta name="rating" content="GENERAL">
<meta http-equiv="expires" content="Mon, 31 Dec 2099 00:00:00 GMT">
<meta http-equiv="pragma" content="no-cache">
<meta name="distribution" content="GLOBAL">
<meta name="copyright" content="This code is Copyright (C) 2000-02 Anas Elhalabi">
<style>
a:link    {color: #CCFF00; text-decoration: none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:visited {color: #CCFF00; text-decoration:none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:hover   {color: BLACK; background-color: #ffcc00; text-decoration: underline overline; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
INPUT { 

	color : #000000;
	background : #ffffff;
	border-top : 1px solid;
	border-bottom : 1px solid;
	border-left : 1px solid;
	border-right : 1px solid;
	font-family : Verdana;
	font-size : 9px;
	font-weight: bold;
	}
  </style></head>
  <body bgcolor="#537895" text="#000000" link="#FF0000" vlink="#FF0000" alink="#FF0000">

  <p>&nbsp;</p>
  <div align="center"><center>

  <table border="0" width="80%" bgcolor="#C0C0C0">
    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><B><font face="verdana" color="#C0C0C0" size="1">$titre</b></font></B></td>
    </tr>
    <tr>
      <td width="100%" bgcolor="#A6A6FF">
       <p>&nbsp;</p>
       <font face="Verdana" size="1"><b>
       $tip</b></b></font>
       <p>&nbsp;</p>
      </td></tr>
		<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST">
		<input type=hidden name="ID" value="16260">
		<tr><td align="center" valign="middle"><font face=verdana size=1><b>Rate this script
</font></b><select name="rate" size="1" style="color: #ff0000; font-family: Verdana; font-size: 10px">
                <option value="5" selected>Excellent!</option>
                <option value="4">Very Good</option>
                <option value="3">Good</option>
                <option value="2">Fair</option>
                <option value="1">Poor</option>
        </select></font><font color="#CCCCCC">
        <input type="submit" value="Rate It!">
        </font></TD></tr></form>

    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><strong>
       <font face="verdana" color="#C0C0C0" size="1">
      $CGI_NAME v$VERSION - &copy;  Script written by Anas Elhalabi,
      Download it for free from: <a href="http://perlmart.cjb.net">[- PerlMart -]</a> </font></strong></td>
    </tr>
  </table>  </center></div>
  </body>
  </html>



_EOM_

  exit(0);
}
################### script will not work if changed !!!!##############################
sub init {
  $CONF{BGCOLOR}="#537895";
  $CONF{'CGI_URL'}=($ENV{'REQUEST_URI'} || $ENV{'SCRIPT_NAME'}); # URL de ce CGI
  $CONF{'CGI_URL'}=~ s/\?.*//gs;
  $CGI_DESC='By Anas Elhalabi';		# script will not work if changed  !
  $CGI_NAME='ServerTester';			# script will not work if changed !!!!
  $PGIMG_URL= $ENV{'SERVER_NAME'} eq 'http://perlmart.hypermart.net' ? 'http://perlmart.hypermart.net/images' : 'http://perlmart.hypermart.net/servtest/images';

  $FONT='<font face="Verdana,Tahoma" size="1"><b>';
  @MODULES=();

  ## 
  %AIDENV=();
  $AIDENV{'DOCUMENT_ROOT'}='Website Root';
  $AIDENV{'GATEWAY_INTERFACE'}='CGI info';
  $AIDENV{'HTTP_ACCEPT_LANGUAGE'}='Language Used';
  $AIDENV{'HTTP_CONNECTION'}='HTTP Connection';
  $AIDENV{'HTTP_COOKIE'}='List of the cookies stored for this site';
  $AIDENV{'HTTP_HOST'}='HTTP of the requesting host';
  $AIDENV{'HTTP_REFERER'}='Referring URL';
  $AIDENV{'HTTP_USER_AGENT'}='Your Browser';
  $AIDENV{'PATH'}='R�pertoires de base, de recherche de prg';
  $AIDENV{'QUERY_STRING'}='Things that follow the ? in a URL';
  $AIDENV{'REMOTE_ADDR'}=' Your IP Address';
  $AIDENV{'REMOTE_HOST'}='Nom d\'h�te de la machine du navigateur-visiteur';
  $AIDENV{'REMOTE_PORT'}='Port used for this request';
  $AIDENV{'REQUEST_METHOD'}='Type of the request (GET/POST/HEAD)';
  $AIDENV{'REQUEST_URI'}='URI of the request';
  $AIDENV{'SCRIPT_FILENAME'}='CGI path in your server';
  $AIDENV{'SCRIPT_NAME'}='URI du CGI en cours d\'�x�cution (avec wrapper �ventuel)';
  $AIDENV{'SERVER_ADMIN'}='Administrator\'s Email';
  $AIDENV{'SERVER_NAME'}='Site\'s Name';
  $AIDENV{'SERVER_PORT'}='Server Port';
  $AIDENV{'SERVER_PROTOCOL'}='Server Protocol';
  $AIDENV{'SERVER_SOFTWARE'}='Nom et version du logiciel serveur web';
  $AIDENV{'HTTP_ACCEPT'}='Types de documents accept�s par le navigateur-visiteur';
  $AIDENV{'AUTH_TYPE'}='M�thode d\'autentification (Basic/Digest/...)';
  $AIDENV{'CONTENT_LENGTH'}='Longeur en octet des donn�es envoy�es (avec m�thodes PUT/POST)';
  $AIDENV{'PROMPT'}='Genre de renseignement inutile que seul Windows peut envoyer...';
  $AIDENV{'REMOTE_USER'}='Login avec lequel le visiteur s\'est �ventuellement identifi� avec .htaccess';
  $AIDENV{'TMP'}=$AIDENV{'TEMP'}='Emplacement du r�pertoire d�di� aux fichiers temporaires';
  $AIDENV{'WINDIR'}='R�pertoire ou Windows est install�';
  $AIDENV{'WINDIRBOOT'}='R�pertoire de d�marrage de Windows';
#  $AIDENV{''}='';
}
################################################
sub getdate {
  my (@day)=('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
  my (@mois)=('','January','February','Mach','April','May','June','July','August','September','October','November','December');
  # On ur
  my ($sec,$min,$hour,$numday,$mois,$annee,$daysem,$dayan,$isdst) =(localtime());
  #     0    1     2      3       4      5       6     7        8
  $mois++;					#
  $annee+=1900;					# 
  return (sprintf ("%s %d %s %d : %02d h %02d mn %02d s<br>\n",$day[$daysem],$numday,$mois[$mois],$annee,$hour,$min,$sec));
}
################################################
sub hostname {
my ($hostname);

  if ($^O=~ /win/i) {				# 
    return '<small>ERROR</small>'; # 
  }


  eval { $hostname=`hostname`; };		
  if (($@) || ($hostname eq '')) {		# 
    eval{ $hostname=`uname -n`; };		# 
  };
  $hostname;					# 
}
################################################
sub get_uname_info {
my ($version,$hardware);

  if ($^O=~ /win/i) {				# 
    $version=$hardware='<small>ERROR</small>'; # 
  } else {					# 

    eval {$version=`uname -r`;};
    chomp($version);				# 
    if (($@) || ($version eq '') ) {		# 
      $version='<small><font color=red>Not Found</font></small>'; #
    }

    #
    #
    eval {$hardware=`uname -m`;};
    chomp($hardware);				# 
    $hardware=~ s/\s+$//;			# 
    if (($@) || ($hardware eq '') ) {		# 
      $hardware='<small>Not Found</small>'; # 
    }
    if ($hardware=~ /^i\d+86/) {		# 
      $hardware.=' (PC)';			# 
    }
  }
  return ($version,$hardware);			# 
}
################################################
sub get_uptime_info {
my ($uptime,$load,$users,$res,@buf,$buf);

  if ($^O=~ /win/i) {				# 
    $uptime=$load=$users='<small>ERROR</small>'; #
  } else {					# 

    eval {$res=`uptime`;};

    # EXAMPLES :
    #
    # SOLARIS Sparc SunOs:
    #  9:26am  up 72 day(s), 15:41,  1 user,  load average: 0.52, 0.51, 0.63
    # BSDi:
    # 7:26AM  up 32 days, 19:41, 3 users, load averages: 0.09, 0.09, 0.04
    # FreeBSD:
    # 3:32PM  up  5:10, 2 users, load averages: 0.08, 0.16, 0.08
    # 3:56PM  up 3 mins, 1 user, load averages: 0.09, 0.07, 0.02

    if (($@) || ($res eq '') ) {		# 
      $uptime=$load=$users='<small><font color=red>Not Applicable</font></small>'; # ... rat�!
    } else {					# SiNO...
      chomp($res);				# 
      # on r�cup�re la charge moyenne :
      # Si le r�sultat contient quelque chose du genre "load average(s) xxxxxx"
      if ($res=~ s/\,*\s*load\s*averages*\s*\:*\s*(.*)//i) {
        $buf=$1;				# 
        $buf=~ s/^\s+//;			#
        @buf=split(/,*\s+/,$buf);		# 
        $load="The Last minute: $buf[0]<br>The last 5 minutes: $buf[1]<br>The last 15 minutes: $buf[2]";
      } else {
        $load='<small>NO D�tect�</small>';
      }

      # on r�cup�re le nombre de connect�s :
      
      if ($res=~ s/\,*\s*(\d+)\s+user\(*s*\)*//i) { # 
        $users=$1;				# 
      } else {					# 
        $users='<small><font color=red>Not Detected</font></small>'; # 
      }


      if ($res=~ /up\s*\:*\s*(.*)\,*/) {
        $uptime=$1;				# 
        $uptime=~ s/day/day/igs;		# 
        $uptime=~ s/min/minute/igs;		# 
                                                # 
        $uptime=~ s/(\d+)\:(\d+)/$1 hour\(s\) $2 minute(s)/igs;
      } else {
        $uptime='<small>NO D�tect�</small>';
      }
    }
  }
  return ($uptime,$load,$users);		# 
}
################################################
sub emplacement_programme {
my ($programme,@places)=@_;			# 
my ($reponse,$which,$buf);


  if ($^O=~ /win/i) { return '<small>ERROR</small>';}


  eval {$buf=`which $programme`;};
  chomp($buf);					#
  $buf=~ s/^\s+//;$buf=~ s/\s+$//;		#

  if (($buf ne '') && (-e "$buf") && (-x "$buf")) { $which=$buf; }


  foreach $buf (@places) {			# 

    if ((-e "$buf") && (-x "$buf") && ($buf ne $which)) {	# 
      $reponse.="$buf<br>";
    }
  }
  $reponse=~ s/<br>$//;				# 
  if ($which ne '') { $reponse="$which<br>$reponse";}
  if ($reponse ne '') {				# 
    return ($reponse);				# 
  } else {					# 
    return '<font color=red>Not Found</font>';			# 
  }
}
################################################
sub verifie_module {
my ($module)=@_;				# 
my ($message);

  if ($module=~ /\s/) {    &msg_fin("$CGI_NAME <br>\n$CGI_DESC","<p>$FONT A Module's name can't have spaces</b></font></p>");}


  eval " use $module";				#
  if ($@) {					# 
    $message=<<_EOM1_;
    <p align="center"><font face="verdana" color="#000000"><b>Perl Module Test : <u>$module</u></b></b></font></p>
    <blockquote>
    <p><font face="verdana" size="2"> <font color="#FF0000">This Perl Module is not installed (or eventually misconfigured).</b></font><br>&nbsp<br>
    <u>The Error Message Is:</u><br>$@ </b></font></p>
    </blockquote>
_EOM1_

    &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$message);

  } else {					# 
    $message=<<_EOM2_;
    <p align="center"><font face="Verdana" color="#000000"><b>Perl Module Test : <u>$module</u></b></b></font></p>
    <blockquote>
    <p><font face="Verdana" size="2"> <font color="#FF0000">The Perl Module is installed--->OK.</b></font><br>&nbsp;<br></b></font></p>
    </blockquote>
_EOM2_

    #
    eval "no $module";				
    &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$message);
  }
}
################################################
sub wanted {
  if ($File::Find::name =~ /\.pm$/) {
    open(MODULE,$File::Find::name) || return;
    while(<MODULE>) {
      if (/^ *package +(\S+);/) {
        push (@MODULES, $1);
        last;
      }
    }
    close(MODULE);
  }
}
################################################
sub maniere_tri {
  return lc($a) cmp lc($b);
}
################################################
sub liste_modules {
my ($nbmodules,$buffer,$module,$message,$numero);

  eval "use File::Find;";

  if ($@) {
    &msg_fin("$CGI_NAME <br>\n$CGI_DESC",
             "<p align=\"center\"><font face=\"Verdana\"><font color=\"#000000\"><b>List of the installed Perl Modules on this server:</b></b></font></b></font></p>
              <p>The Perl module File::Find is not installed on this server !</p>");

  }


  find(\&wanted,@INC);

  # on enl�ve les doublons #
  $buffer='||';
  foreach $module (@MODULES) {
    chomp($module);				# 
    if ($buffer!~ /\|\|$module\|\|/) {
      $buffer.=$module.'||';
    }
  }
  $buffer=~ s/^\|\|//;
  $buffer=~ s/\|\|$//;

  @MODULES=split(/\|\|/,$buffer);
  $buffer='';					# 

  
  @MODULES=sort maniere_tri (@MODULES);		## 
  $nbmodules=@MODULES;				# 


  $message=' <p align="center"><font face="Verdana"><font color="#000000"><b>List of the Perl Modules installed on this server:</b></b></font><br><small>'.$nbmodules.' Now</small></b></font></p>'."\n";

  $message.='<div align="center"><center><table border="0" cellpadding="1" width="90%">'."\n";
  $message.=" <tr>\n";
  $message.='  <td valign="top"><font face="Verdana,Verdana" size="2" color="#000000">'."\n";
  $numero=0;
  foreach $module (@MODULES) {
    $numero++;
    $message.="    $module<br>\n";
    if (($numero == int(($nbmodules/3)+0.67)) || ($numero == int((2*$nbmodules/3)+0.67)) ) {
      $message.='  </td><td valign="top"><font face="Verdana,Verdana" size="2" color="#000000">'."\n";
    }

  }
  $message.="</td></tr></table></center></div>\n";

  &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$message);
}


################################################
sub admin_version {
my ($msg);

  $msg=<<_EOM4_;
    <p align="center"><u><font face="Verdana" color="red" SIZE=2><strong>You are currently using ServerTester Version  $VERSION</strong></b></font></u></p>
    <blockquote>
      <p><font face="Verdana" size="1"><B>This page tells you  <u>in real time</u> wether a newer version of this script has been released on PerlMart.<br>
      <br>Compage the version you are running with the one displayed in the image at the top of this page.<br>If your version is older,  you can get the update by clicking <a href=http://perlmart.cjb.net> here</a>  </b></font></B></p>
    </blockquote>
    

_EOM4_

  &msg_fin("<img src=\"$PGIMG_URL/$VERSION.gif\" ALT=\"$CGI_NAME\"><br><br>$CGI_DESC",$msg);
}
################################################
################################################
sub admin_info {
my ($msg);

$msg=<<_EOM3_;
    <p align="center"><font face="Verdana" color="#000000" size="3"><u><strong>Informations
    sur l'Utilisation de $CGI_NAME :</strong></u></b></font></p>
    
    <p><font face="Verdana" size="2"><u><B>Informations:</B></u><br>
    - <b>Le cas Windows :</b> Si vous �x�cutez ce CGI sur une machine Windows, une partie des informations que donne ce CGI
    n'est pas disponible (not� &quot;ERROR&quot;) car ces informations sont normallement
    obtenues en lan�ant des commandes Unix.<br>&nbsp; <br>
    - <b>Dernier red�marrage :</b> Ceci indique depuis combien de temps le serveur est en fonctionnement
     continue sans red�marrage.<br>&nbsp; <br>
    - <b>Nom d'h�te :</b> C'est le nom de domaine attach� � la machine.<br>&nbsp; <br>
    - <b>Charge moyenne :</b> La charge correspond � l'utilisation des ressources du processeur (principalement).
     Plus la charge est �lev�e, plus le serveur travaille dur... On estime g�n�ralement, qu'une charge
     sup�rieure � 1 signifie que le serveur est sur-utilis�, ce qui ne veut pas dire pour autant que
     les limites de la machine soient atteintes. La valeurs la plus importante � surveiller est la
     charge moyenne sur les 15 derni�res minutes.<br>
     A noter que sur certains syst�mes les valeurs de charge peuvent �tre absentes ou correspondre � l'activit�
     de votre compte seulement (diff�rent de la charge globale du serveur). Cela reste n�anmoins un bon moyen
     de se faire un id�e de l'utilisation de la machine...<br>&nbsp; <br>
    - <b>Utilisateur connect�s :</b> Nombre de connections Telnet (et POP/FTP parfois) en cours.<br>&nbsp; <br>
    - <b>Modules Perl Install�s :</b> Ce sont les modules qui sont install�s dans les r�pertoires d'installation
     de Perl. Si vous avez vos propres modules install�s dans vos r�pertoires, ils ne seront pas pris en compte ici.<br>&nbsp; <br>
    - <b>Variables d'environnement :</b> Ces sont les variables d'environnement transmises par la norme CGI au 
     script Perl. Elles sont accessible dans le script avec \$CGI\{'Nom_variable'\}<br>&nbsp; <br>
</b></font></p>
    
    <p><font face="Verdana" size="2"><u><B>Copyright et Licence d'Utilisation :</B></u><br>
    Merci de ne pas enlever le copyright et les mentions de l'auteur du code<br>
    Ceci est un �change correct de services rendus :-)<br>
    <u>Distribution/revente interdite sans accord de l'auteur.</u> </p>
    <center><p align=\"center\"><form action=\"$CONF{CGI_URL}\" METHOD=\"GET\">\n
    <input type=\"submit\" value=\"Retour\"></form></p></center>

   <p>&nbsp;</p>

_EOM3_


  &msg_fin("<img src=\"$PGIMG_URL/$VERSION.gif\" ALT=\"$CGI_NAME\"><br><br>$CGI_DESC",$msg);
}
################################################
