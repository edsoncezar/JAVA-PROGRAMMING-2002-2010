#!perl.exe


use Net::Ping;
use Time::HiRes qw( gettimeofday tv_interval );



$bytes = 1024;
$timeout = 30;
$pingtype = "icmp";

$ping = Net::Ping->new($pingtype , $timeout , $bytes);
while (true) {
if ($ping->ping($ARGV[0],5)) {
	$t0 = [gettimeofday];
	$elapsed = 1000 * tv_interval( $t0, [gettimeofday]);
	print "Pinging $ARGV[0] with $bytes bytes of data rtt=$elapsed mSecs\n"
} else {
	print "Host Could Not be Reached\n"
}
}