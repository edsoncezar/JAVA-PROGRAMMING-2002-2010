########################################
# 	File Sender v1.0
#       2001 CitruSoft
#  http://citrusoft.tripod.com
#  E-mail: citrusoft@lycos.com
#
########################################
# **************************************
#         VARIABLES
# **************************************
	
 my $path="/public_html/cgi-bin"; 

 my $filebase = '/public_html/cartoline'; 

 my $to='Your_Name@domain.com';	     

 my $bgcolor="white";	             

 my $mailprog = '/usr/sbin/sendmail -t -oi';   

 my $go_after_submit='http://www.YourName.com/ThankYou.htm';	
	
 my $check_referers="yes";

 my @referers=('http://www.YourName.com/'); 

########################################

use strict;  
use locale;                                
use CGI::Carp qw (fatalsToBrowser);
use CGI qw/:standard/;
require "$path/Lite.pm";
$|=1;
###################

# ******************** Check referer *******************************    
         
if ($check_referers eq "yes")
{      
  my($flag)=0;  
 if ($ENV{'HTTP_REFERER'})
  	{    
   		my $ref=$ENV{'HTTP_REFERER'};
     		$ref=~s/^(https?\:\/\/)?(w+\.+)?([a-zA-Z0-9,\-\.]+)(\S+)?/http:\/\/www\.$3\//;
     		foreach my $referer(@referers)
       		{
           		if ($ref eq $referer)
             		{
                  		
                    		$flag=1;
                    		last;
               		}
                 	
         	}
 	}
 else 
 {
 	$flag=1;
 }
      	
     if ($flag!=1)
     {
     	&error;
     }
}
#************************************************************************        

      if (param('to') && param('to') ne "")
      {
      	$to=param('to');
      } 
        
my($subject,$from,$upfile1,$message,$upfile2,$name,$url);

           if (param())
           {
           $name=param('name');
           $url=param('url');
           $subject=param('subject');
           $subject=~s/</&lt/g;
           $from=param('from');
           $from=~s/@/\@/;
           $upfile1=param('upfile1');
           $upfile2=param('upfile2');
           $message=param('message');
           $message=~s/</&lt/g;
           
           }
 
                         
# *************** Errors begin **************************** 
 if (length($subject)<=1)
 {
 	print "Content-type: text/html\n\n";
  	print "<html>\n";
	print "<head>\n";
	print "<title>ERROR! \" at filling the form field <<Subject>>\"</title>\n";
	print "</head>\n";
	print "<body bgcolor=$bgcolor>\n";
	print "<font size='4' face='arial'><center><b>ERROR !</b></font><br>\n";
 	print "<font face='verdana' size='2'>At filling the form field Subject</font></center>\n";
 	print "</body>\n";
	print "</html>\n";
 	exit;
 } 
 unless (&check_mail($from))
 	{
  		print "Content-type: text/html\n\n";
     		print "<html>\n";
		print "<head>\n";
		print "<title>ERROR! \"Uncorrect Email address\"</title>\n";
		print "</head>\n";
		print "<body bgcolor=$bgcolor>\n";
		print "<font size='4' face='arial'><center><b>ERROR!</b></font><br>\n";
	 	print "<font face='verdana' size='2'>Uncorrect Email address</font></center>\n";
		print "</body>\n";
		print "</html>\n";
  	exit;
   	} 

# ***************** Errors end *************************** 

# 88888888888888888 SEND MESSAGE BEGIN 888888888888888888888
 else
 { 
 	my $msg = MIME::Lite->new
		       (Type =>'multipart/mixed',
         		From => "$from", 
			To =>"$to",
 			Subject =>"$subject");
  my ($data);
     	 if ($name ne "" && $name ne " ")
       		{		
   		$data.="Name - $name\n"."-"x60;
     		$data.="\n\n";
         	}
         if ($url ne "" && $url ne " ") 
         	{
   		$data.="Home Page - $url\n"."-"x60;
     		$data.="\n\n";
         	}
     	if ($message ne "" && $message ne " ")     
         	{       		 
		 $data.="$message\n"."-"x60;
   		 $data.="\n\n";
   		}        
          foreach my $field(param)
           { 
              
              if ($field ne "to" && $field ne "subject" && $field ne "from"  && $field ne"upfile1" && $field ne "upfile2" && $field ne "message" && $field ne "name" && $field ne "url" && $field ne "submit")
               {  
      		    $data.="${field}: ";		
                    $data.=param($field);
                    $data.="\n\n";                    
                }
               
        } 
      		$msg->attach(Type=>'TEXT',
                  Data => $data);

	
 	if ($upfile1 ne " " || $upfile2 ne " ")
 	{
# ************* Find file expansion begin ********************* 
            my($exp1,$exp2);
             if (length($upfile1)>=4)
            	{
			$upfile1=~m|\.(\w+)$|;
		 	$exp1=$1;
    		}
 	    if (length($upfile2)>=4)
            	{
			$upfile2=~m|\.(\w+)$|;
		 	$exp2=$1;
    		}      	    	
    
# ************* Find file expansion end ********************* #
#                                                             #
#                                                             #
# ************ Attach binary file begin ********************* #
	if ($exp1 ne " " && $exp1 ne "")
 	{
  	  	$msg->attach
			(Type =>'BINARY',
			Encoding =>'base64',
 	     	 	Path =>"$filebase/$upfile1",
 		       	Filename => "File1.$exp1"
   			);
   	}
	if ($exp2 ne "" && $exp2 ne " ")
 	{
  	  	$msg->attach
			(Type =>'BINARY',
			Encoding =>base64',
 	     	 	Path =>"$filebase/$upfile2",
 		       	Filename => "File2.$exp2"
   			);
   	}
 
   }       
 # ************ Attach binary file end ************************


#	MIME::Lite->send('sendmail',$mailprog);
#	MIME::Lite->send('smtp', "smtp.myisp.net", Timeout=>180);					
 	$msg->send
  
# 8888888888888888888 SEND MESSAGE END 888888888888888888888888888
	
 	print "Location: $go_after_submit\n\n";

  }


# !!!!!!!!!!!!!!!!!!!! SUBS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

# ********************* Check mail *******************************
sub check_mail
{       my($email) = $_[0];

	if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ || 

        ($email !~ /^.+\@localhost$/ && 
        $email !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
        return(0);
    }
   
    else {
        return(1);
    }
}  
# ******************** Check referer *****************************
sub error
{
 	print "Content-type: text/html\n\n";
  	print "<html>\n";
	print "<head>\n";
	print "<title>Access Denied</title>\n";
	print "</head>\n";
	print "<body bgcolor=$bgcolor>\n";
	print "<font size='4' color='red' face='arial'><center><b>ACCESS DENIED !</b></font><br>\n";
 	print "<font face='verdana' size='2'>For download this script please visit our <a href=http://citrusoft.tripod.com/>web site</a>.<br></font></center><br>\n";
 	print "</body>\n";
	print "</html>\n";
 	exit;
}

################################ END #####################################

