#!/usr/bin/perl
# location of Perl (above) - check your doc or ask admin

#############################################################
#                                                            
# Script Source:  CodeBrain.com
# Source URL:     http://www.codebrain.com/perl
# Script Title:   Alpha E-Mailer w/ Autoresponder
# Script Name:    AlphaMail.pl
# Copyright:      1998,1999,2000 by OEC Corp & CodeBrain.com
# Version:        09.01.1999.C (latest)
# Status:         Fully tested, release version 7, Y2K ready
#
# This script may not be redistributed without this header
#
# There are no restrictions on this script - anyone may use
# it, though we appreciate credit where due. Responsibility
# for use of the script is entirely with the user. Please
# note that CodeBrain.com does not support Perl scripts!
#
# Instructions:
#
# - Use WordPad.exe or any plain text editor to edit
# - Set your path to Perl as needed (first line at top)
# - Set ALL variables appropriately (below, see notes)
# - Take special care with the path to your sendmail (below)
# - Send the script to the server in ascii
# - Set script permissions - check your doc or ask admin
# - See a_faq.html for HTML set-ups in alphamail.zip file
# - Required html pages are also provided in alphamail.zip
#
#############################################################



##### SETTABLE VARIABLES ####################################

# URL to go to if there is a problem with form input
$ErrorPage = "http://www.yoursite.com/a_fail.html";

# URL to go to when form has been successfully submitted
$ThankPage = "http://www.yoursite.com/a_thanks.html";

# URL to go to if a 'foreign' referer calls the script
$EvilReferer = "http://www.somesite.com";

# E-mail address to send intake form to (your address)
# If not using PERL 5, escape the @ thus: \@ instead of @ 
$YourEmail = 'yourname@yoursite.com';

# Script works only on your server(s) - ('URL1','URL2')
@referers = ('www.yoursite.com','yoursite.com');

# Location of mail program - check your doc or ask admin
$MailProgram = '/usr/lib/sendmail';

# Subject of the e-mail autoreply to the submitter
$Subject = "Thanks for Your Message!";

# Header line in the auto-reply message
$Header = "GOOBERS UNLIMITED";

# Brief tail message for body of e-mail autoreply
$TailMessage = "If your message requires a reply, we'll get back to you soon.";

# Your signature lines the end of the autoreply e-mail
$Signature1 = "John Q. Public";
$Signature2 = "www.YourSite.com";

##### END OF SETTABLE VARIABLES ############################



##### MAIN PROGRAM #########################################
# ___ Do not edit below this line __________________________

&CheckReferingURL;
&ReadParse;
$Name = $in{'Name'};
$Email = $in{'Email'};
$Message = $in{'Message'};
&CheckEmailAddressFormat;
&CheckFields;
&GetDate;
&SendSubmission;
&SendAutoReply;
print "Location: $ThankPage\n\n";
exit;

# _________________________________________________________

sub SendSubmission {
open (MAIL,"|$MailProgram -t");
print MAIL "To: $YourEmail\n";
print MAIL "From: $Email\n";
print MAIL "Subject: $Subject\n";
print MAIL "$Date\n\n";
print MAIL "E-Mail Message\n\n";
print MAIL "From: $Name\n";
print MAIL "Email: $Email\n\n";
print MAIL "Message:\n\n";
print MAIL "$Message\n\n";
close (MAIL);
}

# _________________________________________________________

sub SendAutoReply {
open (MAIL,"|$MailProgram -t");
print MAIL "To: $Email\n";
print MAIL "From: $YourEmail\n";
print MAIL "Subject: $Subject\n";
print MAIL "$Header\n";
print MAIL "$Date\n\n";
print MAIL "$Subject\n\n";
print MAIL "You sent the following:\n\n";
print MAIL "==============================\n\n";
print MAIL "Name: $Name\n";
print MAIL "Email: $Email\n\n";
print MAIL "Message:\n\n";
print MAIL "$Message\n\n";
print MAIL "==============================\n\n";
print MAIL "$TailMessage\n\n";
print MAIL "Best regards,\n\n\n";
print MAIL "$Signature1\n";
print MAIL "$Signature2\n\n";
close (MAIL);
}

# _________________________________________________________

sub GetDate {
@days = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
@months = ('01','02','03','04','05','06','07','08','09','10','11','12');
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$year = $year+1900;
$Date = "$days[$wday] $months[$mon]/$mday/$year";
}

# _________________________________________________________

sub ReadParse { local (*in) = @_ if @_; 
local ($i, $key, $val); if ( $ENV{'REQUEST_METHOD'} eq "GET" ) 
{$in = $ENV{'QUERY_STRING'};} 
elsif ($ENV{'REQUEST_METHOD'} eq "POST") 
{read(STDIN,$in,$ENV{'CONTENT_LENGTH'});} 
else { 
$in = ( grep( !/^-/, @ARGV )) [0];
$in =~ s/\\&/&/g; } @in = split(/&/,$in);
foreach $i (0 .. $#in) { 
$in[$i] =~ s/\+/ /g; 
($key, $val) = split(/=/,$in[$i],2); 
$key =~ s/%(..)/pack("c",hex($1))/ge; 
$val =~ s/%(..)/pack("c",hex($1))/ge; 
$in{$key} .= "\0" if (defined($in{$key})); 
$in{$key} .= $val; } return length($in); }

# _________________________________________________________

sub CheckEmailAddressFormat {
if (index($Email, "@") < 1)  {&DoEmailError;}
if (index($Email, ".") < 1)  {&DoEmailError;}
if (index($Email, " ") > -1) {&DoEmailError;}
}
sub CheckFields {
if (!$Name || $Name eq ' ') {&DoEmailError;}
if (!$Email || $Email eq ' ') {&DoEmailError;}
if (!$Message || $Message eq ' ') {&DoEmailError;}
}
sub DoEmailError {
print "Location: $ErrorPage\n\n";
exit;
}

# _________________________________________________________

sub CheckReferingURL {
if ($ENV{'HTTP_REFERER'}) {
foreach $referer (@referers) {
if ($ENV{'HTTP_REFERER'} =~ /$referer/i) {
$check_referer = '1';
last;
}}}
else {$check_referer = '1';}
if ($check_referer != 1) {
print "Location: $EvilReferer\n\n";
exit;
}}

# _________________________________________________________

exit;

##### End of Script ########################################