#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################

# Ponha o path completo caso vc use Servidor Windows
$fullpath="./";
####
push(@INC, $fullpath);
# n�o mude estas duas variaveis.. caso vc n�o saiba o que est� fazendo
# don't change these two vairables unless you know what you are doing
$mainAdmin="ad-admin.pl";
$configurAdmin="configur.pl";
##############################
$cfg="banner_cfg.pl";
# nome do arquivo superuser.db
$superuser="superuser.db";
$software="Banner Rotator 3.0 MySQL";

print "Content-type: text/html\n\n";

#import variables. However, use eval to avoid 500 error message 
#when something goes wrong
eval {
require "Main.pm";
};
if ($@) {
&error("Impossivel carregar Main.pm. $@. Please refer to the installation documentation for solutions.");
}

eval {
require "$cfg";
};
if ($@) {
&error("Unable to load $cfg. Please check out the readme file. $@");
}


#user's ip
if (!$ENV{'REMOTE_HOST'}) {
$IP=$ENV{'REMOTE_ADDR'};
}
else {
$IP=$ENV{'REMOTE_HOST'};
}
$time=time;

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
($name, $value) = split(/=/, $pair);
$value =~ tr/+/ /;
$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
$input{$name} = $value;
}

#open the admin password file to see if it exist
open (DETECT,"<$fullpath/$superuser") or &decide;
@detect=<DETECT>;
close (DETECT);

#if the password file is empty, it means it is the first time the user runs setup.pl. Set the admin password.
if (!@detect) {
&decide;
}

#save the password or display the password setting form
sub decide {
if ($input{'action'} eq "firsttime") {
&firsttime;
exit;
}
else {
&setup;	
exit;
}
}


#display the setup page for setting up system variables
if ($input{'action'} eq "mainPage") {
&mainPage;
exit;
}
if ($input{'action'} eq "Salvar") {
&save;
exit;
}


print <<EOF;
<HTML>
<HEAD>
<TITLE>$software</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<center>
<font face="Arial"><font size="+2">
  $software Configurations
</font>
<br>
<br>
Por favor ponha seu Login e Senha para entrar::
<form action="$configurAdmin" method="post">
<b>Login:</b> <input type="text" name="admin">&nbsp;&nbsp;
<b>Senha:</b> <input type="password" name="password">
<input type="hidden" name="action" value="mainPage">
<input type="submit" value="Entrar">
</form>
</center>
</body>
</html>
EOF
exit;

# main page
sub mainPage {

&vpassword;

print <<EOF;
<html>
<head>
  <title>$software</title>
</head>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0">
  <form action="$configurAdmin" method="POST">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b> (N�o use " em qualquer dos campos.)
      </font>
    </td>
  </tr>

  <tr>
    <td>
	  <table border="0" bgcolor="#cccccc" cellspacing="1" cellpadding="1" width="100%">
	    <tr bgcolor="#ffffff">
		  <td width="100%">
			<b>&nbsp;MySQL Server IP ou URL:</b>
		  </td>
		  <td>
		    <input type="Text" name="host" value="$host" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
  		    <b>&nbsp;Nome do banco de dados usado por voc�:</b>
		  </td>
		  <td>
		    <input type="Text" name="database" value="$database" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;Nome de Usu�rio usado pra conectar no banco de dados MySQL:</b>
		  </td>
		  <td>
		    <input type="Text" name="sql_user" value="$sql_user" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;Senha usada para conectar com o banco de dados MySQL:</b>
		  </td>
		  <td>
		    <input type="Text" name="sql_pass" value="$sql_pass" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;Nome da Tebla que ser� criada e usada pelo script:</b>
		  </td>
		  <td>
		    <input type="Text" name="ad_table" value="$ad_table" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;Url do banner padr�o usado caso n�o haja nenhuma conta ativa disponivel: Iniciando com http://</b>
		  </td>
		  <td>
		    <input type="Text" name="default_banner_image" value="$default_banner_image" size="60">
		  </td>
		</tr>
		<tr bgcolor="#ffffff">
		  <td>
			<b>&nbsp;URL pra onde o usu�rio ser� redirecionado quando clicar no banner padr�o usado quando n�o houver contas ativas disponiveis: Iniciando com http://</b>
		  </td>
		  <td>
		    <input type="Text" name="default_banner_forward" value="$default_banner_forward" size="60">
		  </td>
		</tr>
		<tr bgcolor="#f0f0ff">
		  <td>
			<b>&nbsp;URL para o redirect.pl: Iniciando com http://</b>
		  </td>
		  <td>
		    <input type="Text" name="redirect" value="$redirect" size="60">
		  </td>
		</tr>
	  </table>
	</td>
  </tr>
    <tr bgcolor="#7CA3DE">
    <td>
	<table border="0">
	  <tr>
	    <td>
			<input type="hidden" name="admin" value="$input{'admin'}"><input type="hidden" name="password" value="$input{'password'}">
				  <input type="hidden" name="action" value="save"><input type="submit" value="Modificar">
        
		</td>
		</form>
		<td>
		<form action="$mainAdmin\" method=\"post\">
		<input type="hidden" name="action" value="displayAdminMain"><input type="hidden" name="admin" value="$input{'admin'}">
		<input type="hidden" name="password" value="$input{'password'}"><input type="submit" value="Back to the admin main page/Don't save changes">
     	</td></form>
	  </tr>
	  </table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
</html>
EOF
exit;
}
####### save change

sub save {
&vpassword;
$input{'adminEmail'}=~ s/@/\\@/g;
open (main, ">$fullpath/$cfg") or Main::error("Unable to write to $cfg. Please make sure you have chmoded it to \"755\"(chmod it to \"777\" if it still doesn't work)");
print main "\$host=\"$input{'host'}\"\;\n";
print main "\$database=\"$input{'database'}\"\;\n";
print main "\$sql_user=\"$input{'sql_user'}\"\;\n";
print main "\$sql_pass=\"$input{'sql_pass'}\"\;\n";
print main "\$ad_table=\"$input{'ad_table'}\"\;\n";
print main "\$default_banner_image=\"$input{'default_banner_image'}\"\;\n";
print main "\$default_banner_forward=\"$input{'default_banner_forward'}\"\;\n";
print main "\$redirect=\"$input{'redirect'}\"\;\n";
print main "1\;\n";

close(main);


print "A nova configura��o foi salva. Se qualquer coisa n�o funcionar, voc� pode executar o $configur_admin de novo para configurar novamente. Por�m, se $configur_admin falhar, voc� deve enviar o arquivo cfg.pl novamente.\n";
print "<form action=\"$mainAdmin\" method=\"post\">";
print "<input type=\"hidden\" name=\"action\" value=\"displayAdminMain\">";
print "<input type=\"hidden\" name=\"admin\" value=\"$input{'admin'}\">\n";
print "<input type=\"hidden\" name=\"password\" value=\"$input{'password'}\">";
print "<input type=\"submit\" value=\"Voltar pra p�gina de administra��o\">";
print "</form>";
print "<font size=\"-1\"><b>Cuidado: Por favor feche seu navegador pra efetuar log off.</b><br>";
print "Copyright 1999-2001 CGI-Factory.com of SiliconSoup.com LLC.</font>";
print "<br><font face=Verdana size=1 color=black><a href=http://cgi.lipsil.com>CGiBrasil</a> - Sempre uma Nova Tradu��o para VOC�";
exit;
}	


	
####this subroutine prints out the admin password setting form
sub setup {


print <<EOF;
<html>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0">
  <form action="$setup" method="POST">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b>
      </font>
    </td>
  </tr>
  <tr bgcolor="#999999">
    <td>
	  <font size="2" face="arial" color="#f0f0f0">
		<b>Por favor defina Seu Nome de Admin e Senha administrativa</b>
	  </font>
	</td>
  </tr>
  <tr>
  <td cellspacing="0" cellpadding="0">
  		 <table cellspacing="0" cellpadding="0" width="100%">
  		   <tr bgcolor="#f0f0ff">
      		<td>
	  				Nome do Admin:
			</td>
			<td>		
					<input type=\"text\" name=\"admin_name\">
	  		</td>
  		</tr>
   	   	<tr bgcolor="#ffffff">
       		  <td>
			        Senha:
			  </td>
			  <td>
	  			   <input type=\"text\" name=\"password1\">
	  		  </td>
  		 </tr>
       	 <tr bgcolor="#f0f0ff">
       		  <td>
			        Ponha a Senha De novo:
			  </td>
			  <td>
	 			 	<input type=\"text\" name=\"password2\">
	 		   </td>
  		 </tr> 
  		</table>
  </td></tr>
  <tr bgcolor="#7CA3DE">
    <td>
	  <input type=\"submit\" value=\"OK\">
	</td>
  </tr>
</table>
<input type=\"hidden\" name=\"action\" value=\"firsttime\">
</form>
</body>
</html>
EOF

exit;

}

#save the admin password
sub firsttime {

$input{'admin_name'}=~ tr/A-Z/a-z/; 
$input{'admin_name'}=~ tr/\s//;
$input{'password1'}=~ tr/A-Z/a-z/; 
$input{'password1'}=~ tr/\s//; 
$input{'password2'}=~ tr/A-Z/a-z/; 
$input{'password2'}=~ tr/\s//; 

@encryptedPassword=Main::encryptPassword($input{'password1'},$input{'password1'},4,"YL");

if (@encryptedPassword[0] == -1) {
print "@encryptedPassword[1]";
exit;
}
if (!$input{'admin_name'}) {
print "Por favor o Username do admin est� em branco!";
exit;
}


open (PASSWORD, ">$fullpath/$superuser") or Main::error("unable to create the password file");
print PASSWORD "$input{'admin_name'}|@encryptedPassword[1]";
close (PASSWORD);
print "<h2>Novo Username e Senha administrativa definido com sucesso. Por favor de reload para continuar.</h2>\n";
exit;
}



###verify the admin password
sub vpassword {

	$input{'admin'}=~ tr/A-Z/a-z/; 
	$input{'admin'}=~ tr/\s//;
	$input{'password'}=~ tr/A-Z/a-z/; 
	$input{'password'}=~ tr/\s//; 


	my $status=Main::verifyAdmin("$fullpath/$superuser","$input{'admin'}","$input{'password'}","YL","\\|","$fullpath/errorlog.txt","Incorrect Admin logging in attempt|$input{'admin'}|$input{'password'}|$IP|$time");
	if ($status!=1) {
	   
	   Main::printHTML("$fullpath/header.txt");
	   print "<h2>Nome do Admin ou senha incorretas</h2>\n";
       $time=localtime();
	   print "Cuidado: Sua informa��o foi gravada por raz�es de seguran�a.<br>\n";
	   print "Seu endere�o IP: $IP<br>";
	   print "Data: $time<br>\n";
	   Main::printHTML("$fullpath/footer.txt");
	   exit;
	
	}
	
	
}

##error handling subroutine. specifile the lockFile path if the file was locked 
sub error($errorMessage,$lockFile) {
	my ($errorMessage,$lockFile) = @_;	
	#clear the lock file	
	if (defined($lockFile)) {
	   &unFlock($lockFile);
	}

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	         <font color="#ff0000"><b>Mensagem de Erro do SQL:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Raz�o/Debugging Mensagem:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Informa��o Adicional:</b></font><br>
						 Por favor contacte o webmaster ou o adiministrador do servidor.<br>\n
		   		         Se voc� for o webmaster, n�o precisa entrar em p�nico. Este script funiona e voc� pode vero porque desta mensagem. � provavel que a causa do erro seja um motivo bobo. Por exemplo, path do sistema incorreto ou erro de CHMOD.<br>\n
		   	           	 <br><br>
						 Se voc� precisar de qualquer ajuda, por favor visite <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	
	
	
}

