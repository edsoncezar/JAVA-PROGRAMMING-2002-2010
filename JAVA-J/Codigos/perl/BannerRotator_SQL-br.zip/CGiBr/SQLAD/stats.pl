#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################

print "Content-type:text/html\n\n";

$fullpath="./";
push(@INC, $fullpath);

#############################################################################
# read the html form inputs and store the inputs into the $buffer variable  #
#############################################################################
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

##################################################################################
# since each input is separated by a &. We can separate all inputs into a array  #
##################################################################################

@pairs = split(/&/, $buffer);

foreach $pair (@pairs) {

#########################################################################################
# since each input is presented as name=value. We can separate them into two variables  #
#########################################################################################        
		
($name, $value) = split(/=/, $pair);

##################
# URL decoding  #
##################
        
		$name =~ tr/+/ /;
        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		
		$value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $input{$name} = $value;
        
	
}


$software="Banner Rotator 3.0 MySQL";

#encrypt the input password to match the one stored in the database

if ($input{'action'} ne "show_stats") {
###
#print out the login page
####

&admin_header;
print <<EOF;
<form action="stats.pl" method="post">
<font face="Arial"><b>$software Stats Checker</b><br><br>
Nome de Usu�rio: <input name="user" type="text" value=""> Senha: <input name="password" type="password" value="">
<input name="action" type="hidden" value="show_stats">
<input type="submit" value="GO">
</form>
</font>
EOF
&admin_footer;


exit;
}
else {

#else print out the stats
#load in the required settings
$cfg="banner_cfg.pl";
eval {
require "$cfg";
};
if ($@) {
print "unable to load $cfg. $@";
exit;
}



$dsn = "DBI:mysql:database=$database;host=$host;user=$sql_user;password=$sql_pass";

use DBI;

$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);

$sth = $dbh->prepare("Select * from $ad_table where user='$input{'user'}'");
$sth->execute or &sql_error(DBI->errstr,1);

$at_least_one_row=0;

# Retrieve each row
while ((@results=$sth->fetchrow) != NULL) {

$at_least_one_row=1;

#check the password
if ($input{'password'} ne @results[2]) {

print "Nome de Usu�rio ou Senha incorretos";
exit;
}

#some variables need for the stats page

#advertising option
if (@results[11] eq "click") {
$option="Click-throughs";
}
else {
$option="Exposures";
}

#click-throughs ratio
if (@results[12]==0) {
$ratio="0.00";
}
else {
$ratio=sprintf("%.2f",(@results[13]/@results[12])*100);
}
#account created date
($sec,$min,$hour,$mday,$mon,$year,$wday) = (localtime(@results[14]))[0,1,2,3,4,5,6];
$mon+=1;
$mday = sprintf("%.02d",$mday);
$year += 1900;

$date="$mday/$mon/$year";

&admin_header;

#start to print out the stats page
print qq|

<table width="675" cellpadding="0" cellspacing="1" bgcolor="#f0f0f0">
  <tr bgcolor="#0582ff">
    <td width="165"><font color="#ffffff"><b>&nbsp;@results[1]</b></font></td>
    <td align="right"><font color="#ffffff"><b>ID: @results[0]</b></font></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#f9f9f9"><u>Exibir</u></td>
    <td bgcolor="#f9f9f9">@results[4]</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9">URL para Redire��o </td>
    <td bgcolor="#ffffff">@results[3]</td>
  </tr>
  <tr>
    <td bgcolor="#ffffff">&nbsp;</td>
	<td bgcolor="#ffffff">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9"><u>Nome para Contato</u></td>
	<td bgcolor="#f9f9f9">@results[7]</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9">Email </td>
    <td bgcolor="#ffffff">@results[8]</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9">Telefone </td>
    <td bgcolor="#ffffff">@results[9]</td>
  </tr>
  <tr>
    <td bgcolor="#ffffff">&nbsp;</td>
	<td bgcolor="#ffffff">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9"><u>Conta</u></td>
	<td bgcolor="#f9f9f9">@results[10]</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9">Op��o de An�ncio </td>
    <td bgcolor="#ffffff">$option</td>
  </tr>
  <tr>
    <td bgcolor="#f9f9f9">Exposi��es </td>
    <td bgcolor="#ffffff">@results[12]</td>
  </tr>
  
|;

if (@results[11] eq "exp") {
  print qq|

  <tr>
    <td bgcolor="#f9f9f9">Exposi��es Permanentes</td>
    <td bgcolor="#ffffff"><font color="#0582ff">@results[5]</font></td>
  </tr>
  
  |;
}
else {
  print qq| 
  
  <tr>
    <td bgcolor="#f9f9f9">Por-Cliques Permanentes</td>
    <td bgcolor="#ffffff"><font color="#0582ff">@results[6]</font></td>
  </tr>
  
  |;
}

print qq|

  <tr>
    <td bgcolor="#f9f9f9">Por-Cliques </td>
    <td bgcolor="#ffffff">@results[13]</td>
  </tr>

  <tr>
    <td bgcolor="#f9f9f9">Ratio Por-Cliques </td>
    <td bgcolor="#ffffff">$ratio%</td>
  </tr>
  
  <tr>
    <td bgcolor="#f9f9f9">Conta Criada em </td>
    <td bgcolor="#f9f9f9">$date</td>
  </tr>
  
</table>
<br>

|;

&admin_footer;

}

#exit if the member is not found in the database.
if ($at_least_one_row==0) {
&admin_header;
print "Member not found";
&admin_footer;
exit;

}
# Close the sql connection
$sth->finish;
$dbh->disconnect;

exit;
}

#admin header and footer
sub admin_header {
print <<EOF;
<html>
<head>
<title>$software</title>
</head>
<body bgcolor="#ffffff">
<table border="0" bgcolor="#000000" cellspacing="1" cellpadding="0" width="100%">
  <tr bgcolor="#7CA3DE">
    <td>
	  <font size="3" face="arial" color="#ffffff">
        <b>$software</b>
      </font>
    </td>
  </tr>
  <tr bgcolor="#ffffff">
    <td>
	  <font size="1" face="arial" color="#00000f">
		<b>$description &nbsp;</b>
	  </font>
	</td>
  </tr>
  
 <tr bgcolor="#f0f0ff">
    <td><font size="2" face="arial" color="#000000"><ul>
	<br>
EOF
}

sub admin_footer {

print <<EOF;
	  </ul>
     	</td>
	  </tr>
	    <tr bgcolor="#ffffff">
    <td>
	  <font size="2" face="arial" color="#000000">
		<b>$software Copyright 1999-2001 CGI-Factory.com of SiliconSoup.com LLC</b>
	  </font>
	</td>
  </tr>
	  </table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>
</body></html>
EOF
$description="";
}


#sql query error handling
sub sql_error ($errorMessage,$errorType) {

#disconnect from the database



	my ($errorMessage,$errorType) = @_;

	#QUERY error
	if ($errorType==2) {
		$sth->finish;
		$dbh->disconnect;	
	}	

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	         <font color="#ff0000"><b>Mensagem de Erro do SQL:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Raz�o/Debugging Mensagem:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Informa��o Adicional:</b></font><br>
						 Por favor contacte o webmaster ou o adiministrador do servidor.<br>\n
		   		         Se voc� for o webmaster, n�o precisa entrar em p�nico. Este script funiona e voc� pode vero porque desta mensagem. � provavel que a causa do erro seja um motivo bobo. Por exemplo, path do sistema incorreto ou erro de CHMOD.<br>\n
		   	           	 <br><br>
						 Se voc� precisar de qualquer ajuda, por favor visite <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	


}


exit;