#!/usr/local/bin/perl
#################################################################
#             Banner Rotator 3.0 MySQL (beta)
#
# This program is distributed as a beta ware. We are not            	
# responsible for any damages that the program causes	
# to your system or business. You are using this software at your
# own risk. Modifications are not allowed
# without the premissions from SiliconSoup.com LLC.
# If you find any bugs in this software, please report it to us at 
# cgifactory@cgi-factory.com.  
# However, that email address above is only for bugs reporting. 
# We will not  respond to the messages that are sent to that 
# address. If you have any trouble installing this program. 
# Please feel free to post a message on our CGI Support Forum.
# Selling this script is absolutely forbidden and illegal.
##################################################################
#
#               COPYRIGHT NOTICE:
#
#         Copyright 1999-2001 CGI-Factory.com TM 
#		  A subsidiary of SiliconSoup.com LLC
#
#
#      Web site: http://www.cgi-factory.com
#      E-Mail: cgifactory@cgi-factory.com
#      Released Date: August 21, 2001
#	
#   Banner Rotator 3.0 MySQL (beta) is protected by the copyright 
#   laws and international copyright treaties, as well as other 
#   intellectual property laws and treaties.
###################################################################

$fullpath="./";
push(@INC, $fullpath);

#load in the required settings
$cfg="banner_cfg.pl";
eval {
require "$cfg";
};
if ($@) {
print "unable to load $cfg. $@";
exit;
}


$dsn = "DBI:mysql:database=$database;host=$host;user=$sql_user;password=$sql_pass";


##################################################################################
# read the input from query string.
# since each input is separated by a &. We can separate all inputs into a array  #
##################################################################################

        
$ENV{'QUERY_STRING'} =~ tr/+/ /;
$ENV{'QUERY_STRING'} =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

#read the banner id from the query string
$input{'ad'}=$ENV{'QUERY_STRING'};

use DBI;
$dbh=DBI->connect($dsn) or &sql_error(DBI->errstr,1);
$sth = $dbh->prepare("Select forwardURL, click, adverOpt, totalClick from $ad_table where ID='$input{'ad'}'");
$sth->execute or &sql_error($dbh->errstr,2);
@results=$sth->fetchrow;

if (!@results[0]) {
$url="http://www.cgi-factory.com";
print "Location: $url\n\n";
}
else {
#
#update the click-throughs count
#
$click=@results[1]-1;
$totalClick=@results[3]+1;
if (@results[2] eq "click") {
$sth = $dbh->prepare("UPDATE $ad_table SET click=$click, totalClick = $totalClick where ID='$input{'ad'}'");
}
else {
$sth = $dbh->prepare("UPDATE $ad_table SET totalClick = $totalClick where ID='$input{'ad'}'");
}
$sth->execute or &sql_error($dbh->errstr,2);

print "Location: @results[0]\n\n";

}

#close sql connection
$sth->finish;
$dbh->disconnect;


exit;


#sql query error handling
sub sql_error ($errorMessage,$errorType) {

#disconnect from the database



	my ($errorMessage,$errorType) = @_;

	#QUERY error
	if ($errorType==2) {
		$sth->finish;
		$dbh->disconnect;	
	}	

	print qq|
	<table border="0" bgcolor="black" cellspacing="1" cellpadding="0">
		   <tr>
		   	   <td>
			   	   <table bgcolor="white" cellspacing="0" cellpadding="0">
				    <tr bgcolor="#6699FF">
				       <td>
		   	   	         <font size="+2" color="white"><b>An error has occured</b></font>
		   		        </td>
				     </tr> 
				     <tr>
				       <td>
					     <ul>
					     <br><br>
		   	   	        <font color="#ff0000"><b>Mensagem de Erro do SQL:</b></font><br>$errorMessage<br><br>\n
		   		         <font color="#ff0000"><b>Raz�o/Debugging Mensagem:</b></font><br>$!<br><br>\n
		   		         <font color="#ff0000"><b>Informa��o Adicional:</b></font><br>
						 Por favor contacte o webmaster ou o adiministrador do servidor.<br>\n
		   		         Se voc� for o webmaster, n�o precisa entrar em p�nico. Este script funiona e voc� pode vero porque desta mensagem. � provavel que a causa do erro seja um motivo bobo. Por exemplo, path do sistema incorreto ou erro de CHMOD.<br>\n
		   	           	 <br><br>
						 Se voc� precisar de qualquer ajuda, por favor visite <a href="http://www.cgi-factory.com">cgi-factory.com</a>, a subsidiary of SiliconSoup.com (Slicon Soup) LLC.
						 </ul>
					   </td>
				     </tr>
				   </table>
				</td>
		   </tr>
	</table>
	|;
	
	exit;	


}