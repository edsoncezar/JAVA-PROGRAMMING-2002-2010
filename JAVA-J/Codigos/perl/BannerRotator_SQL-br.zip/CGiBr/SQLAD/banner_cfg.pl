$host="mysqlserver.yourname.com";
$database="databaseName";
$sql_user="user";
$sql_pass="pass";
$ad_table="bannersSQL";
$default_banner_image="http://www.yourname.com/banners/banner.gif";
$default_banner_forward="http://www.yourname.com/";
1;
