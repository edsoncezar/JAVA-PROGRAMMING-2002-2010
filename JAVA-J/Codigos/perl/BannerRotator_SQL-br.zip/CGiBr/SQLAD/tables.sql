CREATE TABLE sqlbanners (
id int(10) null PRIMARY KEY AUTO_INCREMENT,
user char(100) null,
pass char(100) null,
forwardURL char(100) null,
display char(255) null,
exp char(255) null,
click char(255) null,
contact char(255) null,
email char(255) null,
phone char(255) null,
status char(255) null,
adverOpt char(255) null,
totalExp char(255) null,
totalClick char(255) null,
createdOn char(255) null
);