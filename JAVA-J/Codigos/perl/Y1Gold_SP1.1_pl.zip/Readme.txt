Welcome to YaBB!
----------------

Navigate to the public_html/YaBBHelp/index.html file of this package.  From there, you will see 
links to the installation, upgrade, and administration manuals for YaBB 1 Gold - Service Pack 1.1.

We hope you enjoy this software, and please visit http://www.yabbforum.com to help the community grow!