#!/usr/local/bin/perl
#
# This package is a provide the spong programs a standard way to daemonize

package Spong::Daemon;

use strict;


use POSIX qw(setsid);
use Carp;


# Daemonize myself

sub Daemonize {
    my($pid, $sid);

   if ( ! defined($pid = fork()) ) {
      croak "ERROR: Could not fork: $!";
   } elsif ( $pid ) {
      # I'm the parent, just exit gracefully
      exit(0);
   } else {
      # I'm the child

      open(STDIN,"</dev/null");
      open(STDOUT,">/dev/null");
      open(STDERR,">/dev/null");

   # Become session group leader
   POSIX::setsid();

   }

}

1;

