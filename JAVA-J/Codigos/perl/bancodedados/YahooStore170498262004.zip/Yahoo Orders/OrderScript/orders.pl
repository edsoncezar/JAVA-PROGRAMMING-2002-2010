#!/usr/bin/perl

#open the files, dump into arrays:
open(ORDERS,"../orders.csv")||die "Couldn't open ORDERS.CSV: $!";
@orders=<ORDERS>;
close(ORDERS);

open(ITEMS,"../items.csv")||die "Couldn't open ITEMS.CSV: $!";
@items=<ITEMS>;
close(ITEMS);

open(REFS,"./Resources/ref.csv")||die "Couldn't open REF.INI: $!";
@refs=<REFS>;
close(ORDERS);


#subs:
sub parseCSV {
	my $str = @_ ? shift : $_;
	my @ret;
	while ($str =~ /\G\s*(?!$)("[^"]*(?:""[^"]*)*"|[^,"]*),?/g) {
 		push @ret, $1;
		$ret[-1] =~ s/\s+$//;
		if ($ret[-1] =~ s/^"//) {
			chop $ret[-1]; $ret[-1] =~ s/""/"/g
		}
	}
	return @ret;
}

open(OUTPUT,">../output.csv")||die "Couldn't make output.csv: $!";

#compile items and orders, append last item as number of items added
foreach $thisorder (@orders) {
	@output=&parseCSV($thisorder);
	foreach $thisitem (@items) {
		@thisitem=parseCSV($thisitem);
		if ($thisitem[0] eq $output[0]) {
			@output = (@output,@thisitem);
		}
	}

	$output[scalar(@output)]=(scalar(@output)-33)/6;

#add the weight:
	foreach $thisref (@refs) {
		@thisref=parseCSV($thisref);
		$arnum=scalar(@output);
		for($i=0;$i<$output[$arnum-1];$i++){
			if ("$thisref[0] " eq $output[(36+6*$i)]){
				$output[$arnum] += ( $thisref[1] ) * ($output[ 37+6*$i ]);
			}
		}
	}

#trim zipcode and telephone
	$output[9] =~ s/\W//g;
	$output[10] =~ s/\W//g;

#output
	@needed = qw{3 4 5 6 7 9 10 19 22 26 33};
	$x=0; foreach $item (@output) { if ($x<100) { print "$x: $item\n"; $x++; } }
	foreach $x (@needed){
		print OUTPUT "\"$output[$x]\"\,";
	}
	print OUTPUT "\"$output[scalar(@output)-1]\"\,\"Prepaid\"\,\"Package\"\n";
}

close(OUTPUT);
