######################## Program Header ########################
##
##  Please leave intact...
##  Script Name: DeadBolt
##  Version: 1
##  This File: DeadBolt.cgi
##  URL: http://poeticpollution.net/services/scripts/DeadBolt.html
##
##################################################################


######################## Poetic Pollution Software License ########################
	Copyright 2002 - poeticpollution.net

	By using this code you agree to the license stated below.

	You May:
	 1. Modify and use the source codes for purposes as you see fit.
	 2. Notify poeticpollution.net you're using the scripts - staff@poeticpollution.net.
	    If you'd like to be listed on our "DeadBolt In Action List" or if you'd to be informed
	    of updates, send an email to staff@poeticpollution.net.
	 3. It'd also be nice if you put a link to http://poeticpollution.net some where on your
	    site but this is entirely up to you.

	You May Not:
 	 1. Sell or redistribute this code without written consent from poeticpollution.net.
	 2. Transfer, share or sub-lease this license agreement with any other party.
	 3. Claim ownership or authorship of the source codes. Any modifications and/or improvements
	    made by you, if submitted to staff@poeticpollution.net and deemed appropriate will be included
            in future versions with full credit to you.
	 4. Hold poeticpollution.net or anyone else responsible for any damage caused by these scripts.
	    Use at your own risk. :]

         - This is a legal agreement between you, the end user, and Poetic Pollution -


######################## Script Information ########################
	This script creates and/or updates the .htaccess and .htpasswd files for securing directories.
	Use it over and over again - Add as many secured areas and/or users as us like.
	For use on a Unix flavor OS running an Apache web server.
	It has not been tested or known to work on anything else, so it probably won't!
	If you don't have Perl5+, complain to your System Admin!


######################## Included Files ########################
	1. ReadMe.txt		- this file.
	2. DeadBolt.cgi	- Perl script that performs the work.


######################## Configuration ########################
	1. None Needed.


######################## Installation ########################
	1. Create a directory in your CGI-BIN or wherever you'll be running DeadBolt from and upload
		the DeadBolt.cgi there in ASCII. Then chmod it 755.


######################## Execution ########################
	1. The script should be ready for use so let's try it out..

	2. Point your browser to http://www.yourdomain.com/yourpath/yourdirectory/DeadBolt.cgi

	3. The first thing to do is secure your directory where you're running DeadBolt from:
		A. "UNIX Path" - change the path to /whatever/yourpath/yourdirectory
		B. "Name for secured area" - anything you'd like, but no spaces!
		C. "Username" - pick one..
		D. "Password" - pick another..

	4. Click "Engage DeadBolt" and the script hopefully will secure this directory.

	5. Now close your browser and point your browser again to:
		http://www.yourdomain.com/yourpath/yourdirectory/DeadBolt.cgi

	6. The "DeadBolt" should now be in place.

	7. Repeat as desired for adding the DeadBolt to different directories. You can also add
		another "User" to the secure directory by running the script again on the directory.
		The original User will remain but the new one will be appended to the .htpasswd file.
		

######################## Trouble Shooting ########################
	1. Re-upload the files in ASCII.

	2. Chmod "DeadBolt.cgi" to 755

	3. Follow the instructions for the given error messages.

	4. Post a message on the Scripts BBS at poeticpollution.net with specific details to your
		problems. If general questions are asked, general answers will be given.

		http://poeticpollution.net/pollute/support/scripts/ScriptsBBS.html

		Please don't contact us by email. We'd rather have questions posted on the
		Scripts BBS. Then others can look there for a possible source of help.

	5. If something goes wrong and you get locked out of your directory, just FTP to the directory
		and delete the .htaccess and .htpasswd files.

######################## Versions and Modifications ########################
	+ V1: Initial release 26/Jun/2002

