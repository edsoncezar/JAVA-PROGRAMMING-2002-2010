#!/usr/bin/perl

##############################################################
#                PhotoShelf Installation Script              #
#                         Version 1.0                        #
#                                                            #
#            Attempts to successfully install PhotoShelf by  #
#    asking the user the right questions and putting the     #
#              right stuff in place.                         #
#
# Steps:
# - Check for required perl modules, and if none exists it
#   installs them as necessary.
# - Connects to the database, creates the database and all
#   necessary tables. Prompts for host/username/password.
# - Reads the web server config file, and determines both
#   the documentroot and the mod_perl execute directory.
#   If none detected, prompts for them and/or aborts.
# - Adds the mime types to the config file.
# - Installs the PhotoShelf.pm module, after modifying the
#   $DefaultDir variable.
# - Sets the correct icon locations in the help files.
# - Creates the directories and copies files into it. Also
#   runs the 'make-dirs.pl' script.
# - Sets correct file permissions.
# - runs the 'adduser.pl' script.
#
##############################################################

@Default_httpd_cfg= qw(/usr/local/apache/conf/httpd.conf
	/etc/httpd/conf/httpd.conf
	/etc/httpd/httpd.conf
	/var/www/conf/httpd.conf
	/etc/apache/conf/httpd.conf
	/usr/local/etc/apache/httpd.conf
	/usr/local/etc/apache/apache.conf);

my $Version = "1.11";

$DefaultPostgresHost="localhost";
$Default_Postgres_Include="/usr/include/pgsql";
$Default_Postgres_Lib="/usr/lib";
$PhotoShelfData = "/photoshelf";
$ApacheName = "localhost";
$ApachePort = 80;
@PerlModules = 
	( 'Compress::Zlib',
	'Archive::Tar',
	'Archive::Zip',
	'CGI::Cookie',
	'DBI',
	'DBD::Pg',
	'Mail::Mailer',
	'Digest::MD5',
	'HTTP::Date',
	'File::MMagic',
	'IO::String',
	'Image::Info',
	'Image::Magick');

$StartTime = time();

if ($< != 0) {
	print "\nMust be root to install perl module!\nBreak out here and re-run as root, or hit enter to skip...";
	$crap = <STDIN>;
}

print <<EOF;


##############################################################
#               PhotoShelf Installation                      #
##############################################################

Thanks for installing PhotoShelf.

This script will attempt to go through all the necessary
actions to get PhotoShelf installed on this system. Please
ensure that you have met the following requirements *before*
continuing:

- perl 5 [hmm this script runs so you've got that :) ]
- Apache web server
- mod_perl
- A postgreSQL database
- jpegtran (from libjpeg)

Hit enter to continue.
EOF

$crap = <STDIN>;

$| = 1;

if (! -f "photoshelf.cfg" || ! -f "photodb.template") {
	die "Can't find essential files! Are you in the PhotoShelf-X.X dir?";
}

$thisdir = `pwd`;
chomp $thisdir;

FindJpegTran ();
CheckPerlModules();
CheckPostgres();
ReadApacheCFG();
EditModule();
MakeHelp();
MakeDirs();
AddUser();
SendReport();

if ($ApachePort != 80) {
	$PortBit = ":$ApachePort";
}
print <<EOF;

__        __          _   _             _
\\ \\      / /__   ___ | | | | ___   ___ | |
 \\ \\ /\\ / / _ \\ / _ \\| |_| |/ _ \\ / _ \\| |
  \\ V  V / (_) | (_) |  _  | (_) | (_) |_|
   \\_/\\_/ \\___/ \\___/|_| |_|\\___/ \\___/(_)

PhotoShelf should now be installed properly!

Now you can connect to the web server at the following URL:

http://$ApacheName$PortBit/$Uri/

Enjoy. :)

EOF

sub FindJpegTran {
	print "Checking for jpegtran...";
	foreach $dir (split(/:/, $ENV{PATH})) {
		if (-x "$dir/jpegtran") {
			$got_jpegtran = 1;
		}
	}
	if (!$got_jpegtran) {
		print "no!\n\n";
		print "Get it at http://www.ijg.org/ and re-run this after installing\n";
		exit(1);
	} else {
		print "ok.\n";
	}

}

# Check for and install required perl modules
sub CheckPerlModules {
	foreach $perl_module (@PerlModules) {
		print "Checking for $perl_module...";
		my $str = "require $perl_module;";
		my $res = eval $str;
		if ($res != 1) {
			print "no.\n";
			InstallPerlModule($perl_module);

			if ($UseCPAN) {
				print "Checking $perl_module was installed...";
				my $str = "require $perl_module;";
				my $res = eval $str;
				if ($res != 1) {
					print "no.\n";
					print <<EOF;
#############################################
#  WARNING: $perl_module did not install!   #
#  Check this manually then re-run me!      #
#############################################
EOF
					exit(1);
				} else {
					print "ok.\n";
					sleep 3;
				}
			}
		} else {
			print "ok.\n";
		}
	}
	
	if ($UseCPAN == 0 && @PerlModulesToInstall > 0) {
		print "\nGo and install the following perl modules on your system and re-run me:\n";
		foreach $mod (@PerlModulesToInstall) {
			print "$mod\n";
		}
		print "\n";
		exit(1);
	}
}

sub InstallPerlModule {
my ($module) = @_;
	if (!defined ($UseCPAN)) {
		print "Use CPAN to install missing modules?";
		$have_cpan = <STDIN>;
		if ($have_cpan =~ /n/i) {
			print "Ok.\n";
			push (@PerlModulesToInstall, $module);
			$UseCPAN = 0;
			return;
		}
	} elsif ($UseCPAN == 0) {
		push (@PerlModulesToInstall, $module);
		return;
	}
	$UseCPAN = 1;
	if ($module =~ /DBD::Pg/) {
		print "If you don't know the answers to the following two questions, try entering the directories for the files pg_lzcompress.h and libpq.o respectively.\n";
		print "Where are your postgres include files? [$Default_Postgres_Include] ";
		$Postgres_Include = <STDIN>;
		chomp $Postgres_Include;
		print "Where are your postgres library files? [$Default_Postgres_Lib] ";
		$Postgres_Lib = <STDIN>;
		chomp $Postgres_Lib;
		$Postgres_Include = $Default_Postgres_Include, unless ($Postgres_Include ne "");
		$Postgres_Lib = $Default_Postgres_Lib, unless ($Postgres_Lib ne "");
		$ENV{POSTGRES_INCLUDE} = $Postgres_Include;
		$ENV{POSTGRES_LIB} = $Postgres_Lib;
	}


	use CPAN;
	CPAN::Shell->install($module);
}

sub CheckPostgres {

	eval "use DBI;";

	print "Enter the host where the PostgreSQL database is [$DefaultPostgresHost]:";
	$PostgresHost = <STDIN>;
	chomp $PostgresHost;
	$PostgresHost = $DefaultPostgresHost, unless ($PostgresHost ne "");

	print "Enter the PostgreSQL username [$ENV{USER}]: ";
	$PostgresUser = <STDIN>;
	chomp $PostgresUser;
	$PostgresUser = $ENV{USER}, unless ($PostgresUser ne "");

	print "Enter the PostgreSQL password for $PostgresUser []: ";
	$PostgresPass = <STDIN>;
	chomp $PostgresPass;

	print "Attempting to connect to $PostgresHost as user $PostgresUser...";
	my $data_source="dbi:Pg:dbname=template1";
	$data_source .= ";host=$PostgresHost" unless $PostgresHost eq 'localhost';
	$Db_Conn = DBI->connect($data_source, $PostgresUser, $PostgresPass, {AutoCommit => 1});

	$Db_Conn->{PrintError} = 1;
	if (!defined ($Db_Conn)) {
		print "\n\nError connecting to database on host $host: $DBI::errstr\n\nCorrect this and re-run me!\n";
		exit(1);
	}
	print "success.\n";
	sleep 1;
	print "Creating database...";
	$Db_Conn->do("CREATE DATABASE photodb");
	print "done. (dont worry if it complained about an existing db).\n";
	$Db_Conn->disconnect;
	chdir $thisdir;
	if (! -f "photodb.template") {
		print "Cannot find photodb.template in current directory!\n";
		exit(1);
	}
	sleep 1;
	print "Now attempting to configure database using psql.\n";
	sleep 2;
	$ENV{PGUSER} = $PostgresUser;
	$ENV{PGPASSWORD} = $PostgresPass;
	$ENV{PGHOST} = $PostgresHost unless $PostgresHost eq 'localhost';;
	system "psql -f photodb.template -d photodb";
#	system "psql -d photodb";
	$ENV{PGPASSWORD} = ""; # clear for security reasons
	print "\nHit enter if all looks ok, or break out and fix...";
	$crap = <STDIN>;
}

sub ReadApacheCFG() {

	foreach $file (@Default_httpd_cfg) {
		if (-f $file) {
			$Default_httpd_cfg = $file;
		}
	}
	print "\nChecking your Apache instllation.\nWhat is the full path of your Apache config? [$Default_httpd_cfg] ";
	$ApacheConfig = <STDIN>;
	chomp $ApacheConfig;
	$ApacheConfig = $Default_httpd_cfg, unless ($ApacheConfig ne "");

	if (! -r $ApacheConfig) {
		print "\n\nError, cannot read $ApacheConfig! Correct this and re-run me.\n";
		exit(1);
	}

	open (CFG, "$ApacheConfig") or die "Cannot read $ApacheConfig: $!";
	while (<CFG>) {
		chomp;
		next, if (/\s*#/);
		if (/PerlSendHeader\s+(.*)$/) {
			if ($1 eq "On" || $1 eq "on") {
				$SendHeaderOK = 1;
			}
		}
		if (/^[^\#]*User\s+([a-zA-Z]*)/) {
			$ApacheUser = $1;
		}
		if (/^[^\#]*Port\s+(.*)/) {
			$ApachePort = $1;
		}
		if (/^[^\#]*ServerName\s+(.*)/) {
			$ApacheName = $1;
		}
		if (/^[^\#]*Alias\s+([^\s]+)\s+([^\s]+)/) {
			$left = $1; $right = $2;
			$left =~ s/\/$//;
			$Aliases{$left} = $right;
		}
		if (/DocumentRoot\s+\"(.*)\"/) {
			$ApacheDocumentRoot = $1;
		}
		next, if ($ApachePerlLoc ne "");
		if (/<Location\s+([^>]+)/) {
			$Loc = $1;
			$Uri = $Loc;
			$Uri =~ s/^\///;
			$Uri =~ s/\/$//;
		}
		if ($Loc ne "") {
			if (/SetHandler\s+perl-script/) {
				$Loc =~ s/\/$//;
				if (exists($Aliases{$Loc})) {
					$Loc = $Aliases{$Loc};
					$AliasedLoc = 1;
				}
				$ApachePerlLoc = $Loc;
			}
			if (/<\/Location/ && ($ApachePerlLoc eq "")) {
				$Loc = "";
			}
		}
	}
	if ($AliasedLoc != 1) {
		$ApachePerlLoc = $ApacheDocumentRoot . "/" . $ApachePerlLoc;
	}
	if ($ApachePerlLoc eq "") {
		print "Cannot find a location with 'SetHandler perl-script' set in $ApacheConfig!\n\nFix this and re-run me.\n";
		exit(1);
	}
	if ($SendHeaderOK != 1) {
		print "Error: PerlSendHeader is not set on in $ApacheConfig! Fix and re-run me.\n";
		exit(1);
	}
	if ($ApacheDocumentRoot eq "") {
		print "Error: Cannot find a DocumentRoot in $ApacheConfig! Fix and re-run me\n";
		exit(1);
	}
	print "The following defaults were obtained from $ApacheConfig.\n";
	print "DocumentRoot [$ApacheDocumentRoot]: ";
	$DocumentRoot = <STDIN>;
	chomp $DocumentRoot;
	$ApacheDocumentRoot = $DocumentRoot, unless ($DocumentRoot eq "");
	print "Warning: DocumentRoot directory $ApacheDocumentRoot not found.",if (! -d $ApacheDocumentRoot);

	print "mod_perl script location [$ApachePerlLoc]: ";
	$PerlLoc = <STDIN>;
	chomp $PerlLoc;
	$ApachePerlLoc = $PerlLoc, unless ($PerlLoc eq "");
	print "Warning: Perl Script directory $ApachePerlLoc not found.\n",if (! -d $ApachePerlLoc);

	$ApacheDocumentRoot =~ s/\/\/+/\//g;
	$ApachePerlLoc =~ s/\/\/+/\//g;
	if ($ApachePerlLoc =~ /$ApacheDocumentRoot\/+photoshelf\/*/) {
		$PhotoShelfData = "/ps-data";
	}
	print "Scripts run as [$ApacheUser]: ";
	$User = <STDIN>;
	chomp $User;
	$ApacheUser = $User, unless ($User eq "");

	print "Directories look sane..\n";

	my $MimeType = 0;

	print "\nChecking MIME config..."; sleep 1;
	open (CFG, "$ApacheConfig") or die "Cannot open $ApacheConfig: $!";
	while (<CFG>) {
		if (/^LoadModule\s+mime_magic/) {
			close CFG;
			goto HERE;
		}
		$MimeType++, if (/^[^\#]*AddType\s+image\/jpeg\s+.img/);
		$MimeType++, if (/^[^\#]*AddType\s+image\/jpeg\s+.100/);
		$MimeType++, if (/^[^\#]*AddType\s+image\/jpeg\s+.640/);
	}
	close CFG;
	if ($MimeType != 3) {
		print <<EOF;

##############
#   ERROR    #
##############
You need to do one of the following in Apache:

Enable the mime_magic module in apache:

LoadModule mime_magic_module libexec/mod_mime_magic.so

OR

Insert the following lines:

AddType image/jpeg .img
AddType image/jpeg .100
AddType image/jpeg .640

This ensures correct mime types for images sent from the server.

Fix this and re-run me.
EOF
		exit(1);
	}
HERE:
	print "ok.\nYou have the correct mime type configuration.\n";
	print "Done with Apache config check. All appears ok.\n\nHit enter to continue...";
	$crap = <STDIN>;
}

sub EditModule {

	print "\n";
	chdir "PhotoShelf" || die "Error, cant chdir to PhotoShelf/ : $!";
	open (MOD, "PhotoShelf.pm") or die "Can't open PhotoShelf.pm: $!";
	open (TMP, ">PhotoShelf.pm.tmp") or die "Can't open tmp file: $!";
	while (<MOD>) {
		chomp;
		if (/WATCHOUT/) {
			print TMP "\$DefaultDir = \"$ApachePerlLoc\"; # ---WATCHOUT---\n";
		} else {
			print TMP "$_\n";
		}
	}
	close MOD;
	close TMP;
	if (!rename("PhotoShelf.pm.tmp", "PhotoShelf.pm")) {
		die "Error renaming temp file PhotoShelf.pm.tmp to PhotoShelf.pm: $!";
	}
	print "Successfully edited \$DefaultDir variable in PhotoShelf.pm\n";
	system "perl Makefile.PL";
	system "make";
	system "make install";
	print "\nModule PhotoShelf.pm should be installed correctly.\nIf no errors appear above, hit enter to continue, or break out and fix...";
	$crap = <STDIN>;
	chdir "$thisdir";
}

sub MakeDirs {

	@Dirs = ("cache", "helpfiles");
	my ($l,$p,$uid,$gid) = getpwnam($ApacheUser)
		or die "Can't find $ApacheUser in passwd file";
	if (! -d "$ApacheDocumentRoot/$PhotoShelfData") {
		if (mkdir ("$ApacheDocumentRoot/$PhotoShelfData/", 0777) == 0) {
			die "Error creating $ApacheDocumentRoot/$PhotoShelfData: $!";
		}
	} else {
		DoUpgrade();
	}
	chdir "scripts";
	system "/bin/cp * $ApachePerlLoc";
	mkdir ("$ApachePerlLoc/tmp",0775) or die "Cannot create $ApachePerlLoc/tmp: $!";
	system "/bin/chown $ApacheUser $ApachePerlLoc/*";
	system "/bin/chmod 755 $ApachePerlLoc/*";
	chdir "$thisdir";
	foreach $dir (@Dirs) {
		$sysdir = $ApachePerlLoc . ($ApachePerlLoc =~ /\/$/ ? "" : "/") . $dir;
		if (! -d $sysdir) {
			if (mkdir ($sysdir, 0777) == 0) {
				die "Error creating $sysdir: $!";
			}
		}
		chown $uid, $gid, $sysdir or die "Can't chown $sysdir to $ApacheUser: $!";
		chdir "$dir" or die "Cannot chdir to $dir: $!";
		system "/bin/cp * $sysdir";
		system "chown $ApacheUser $sysdir/*";
		chdir "$thisdir";
	}
	if (! -d "$ApacheDocumentRoot/$PhotoShelfData/images") {
		if (mkdir ("$ApacheDocumentRoot/$PhotoShelfData/images/", 0777) == 0) {
			die "Error creating $ApacheDocumentRoot/$PhotoShelfData/images/: $!";
		}
	}
	chdir "$thisdir/images" or die "Can't chdir to $thisdir/images: $!";
	system "/bin/cp * $ApacheDocumentRoot/$PhotoShelfData/images";
	system "chown $ApacheUser $ApacheDocumentRoot/$PhotoShelfData/images/*";
	chmod 0644, glob("$ApacheDocumentRoot/$PhotoShelfData/images/*");
	chdir $thisdir;
	system "/bin/cp photoshelf.cfg $ApachePerlLoc";
	chmod 0644, "$ApachePerlLoc/photoshelf.cfg";
	system "/bin/cp functions.js $ApacheDocumentRoot/$PhotoShelfData";
	chmod 0644, "$ApachePerlLoc/photoshelf.cfg";
	open (CFG, "$ApachePerlLoc/photoshelf.cfg")
		or die "Hmm can't open $ApachePerlLoc/photoshelf.cfg: $!";
	open (TMP, ">$ApachePerlLoc/photoshelf.cfg.tmp")
		or die "Can't open $ApachePerlLoc/photoshelf.cfg: $!";
	while (<CFG>) {
		chomp;
		if (/^\$repository/) {
			print TMP "\$repository = \"$ApacheDocumentRoot$PhotoShelfData/\";\n";
		} elsif (/^\$db_user/) {
			print TMP "\$db_user = \"$PostgresUser\";";
		} elsif (/^\$db_host/) {
			print TMP "\$db_host = \"$PostgresHost\";";
		} elsif (/^\$db_pass/) {
			print TMP "\$db_pass = \"$PostgresPass\";";
		} elsif (/^\$Repos_Url/) {
			print TMP "\$Repos_Url = \"$PhotoShelfData/\";";
		} else {
			print TMP "$_\n";
		}
	}
	close CFG; close TMP;
	rename ("$ApachePerlLoc/photoshelf.cfg.tmp", "$ApachePerlLoc/photoshelf.cfg") or die "Error renaming photoshelf.cfg.tmp to photoshelf.cfg in $ApachePerlLoc";
	print "Updated photoshelf.cfg..\n";
	print "Creating repository...\n";
	system "tools/make-dirs.pl";
	system "chown -R $ApacheUser $ApacheDocumentRoot/$PhotoShelfData";
	print "Done. I have also done the 'chown' described above.\nHit enter if all looks ok so far...";
	$crap = <STDIN>;
}

sub AddUser {

	print "\nNow you need to add at least one user.\n";
	system "tools/adduser.pl";
}

sub MakeHelp {
	print "Setting help file icon locations...";
	chdir $thisdir;
	foreach $file (<helpfiles/*>) {
		next, unless (-f $file);
		open (HELP, "$file") or warn "Error opening $file: $!";
		open (TMP, ">$file.tmp") or warn "Error opening $file: $!";
		while (<HELP>) {
			s|/photoshelf/images/|$PhotoShelfData/images/|;
			print TMP "$_";
		}
		close HELP;
		close TMP;
		rename ("$file.tmp", "$file") or warn "Error moving $file.tmp to $file: $!";
	}
	print "done.\n";
	open (JS, "functions.js") or warn "Error opening functions.js: $!";
	open (TMP, ">functions.js~") or warn "Error opening temp file: $!";
	while (<JS>) {
		s|/photoshelf/images|$PhotoShelfData/images|;
		print TMP "$_";
	}
	close JS; close TMP;
	rename ("functions.js~", "functions.js") or warn "Error moving functions.js~ to functions.js: $!";
}

sub SendReport {

	$InstTime = time() - $StartTime;

	print <<EOF;


The author is very curious as to who is using this software. To
facilitate this, at your option, a report will be sent to the
author with the following information:

Operating system
PhotoShelf version
Perl version
Time this script ran for
2 questions about the installation type

This will not be used for any commercial purpose, purely to assist 
the author with enhancements.

If you do _not_ want this information sent, hit 'n' or 'N', else
hit enter.

EOF

$answer = <STDIN>;

chomp $answer;

return, if ($answer =~ /n/i);

print <<EOF;
Great!

Now, enter one line now with any comments you wish to make 
about this installation procedure or anything else, alternatively 
just hit enter.

EOF
print "Comment> ";

$comment = <STDIN>;
chomp $comment;

print <<EOF;

What type of organisation is this installation for?

1) Private/Personal
2) Commercial
3) Educational
4) Other
EOF


print "Enter 1-4> "; $orgtype = <STDIN> ; chomp $orgtype;
$org = "Private", if ($orgtype == 1);
$org = "Commercial", if ($orgtype == 2);
$org = "Educational", if ($orgtype == 3);
$org = "Other", if ($orgtype == 4);

print <<EOF;

How many images do you think you will store here over the next months?

1) 1-99
2) 100-999
3) 1000-9999
4) 10000+

EOF

print "Enter 1-4> "; $numpix = <STDIN> ; chomp $numpix;

$pix = "1-99", if ($numpix == 1);
$pix = "10-999", if ($numpix == 2);
$pix = "100-9999", if ($numpix == 3);
$pix = "10000+", if ($numpix == 4);

print <<EOF;

Thanks for answering! Now sending to the author...
EOF

$mailprog = Mail::Mailer->new('sendmail');

%headers = (
	'To' => "photoshelf\@cactii.net",
	'Subject' => "-- PhotoShelf Install --"
);

$perlv = `perl -v`;
$uname = `uname -a`;
chomp $uname;

$mailprog->open(\%headers);

print $mailprog <<EOF;

photoshelf-version: $Version
install-time: $InstTime seconds
os: $uname
comment: $comment
numpix: $pix
organisation: $org
perl-version: $perlv

EOF

print "Done!\n\n";
sleep 1;

}

sub DoUpgrade {

	print <<EOF;

Aha! It appears that you have an existing version of PhotoShelf
installed! Please ensure that you have read through the ChangeLog
for any further changes which must be made. If you don't make these
changes, then very strange things will happen.

Hit enter to continue...
EOF

my $crap = <STDIN>;

}
