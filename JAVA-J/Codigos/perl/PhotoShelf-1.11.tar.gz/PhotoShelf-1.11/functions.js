function popUp(URL) {
        day = new Date();
        id = day.getTime();
     if (document.all)
         var xMax = screen.width, yMax = screen.height;
     else
         if (document.layers)
             var xMax = window.outerWidth, yMax = window.outerHeight;
         else
             var xMax = 640, yMax=480;

     var xOffset = (xMax - 500)/2, yOffset = (yMax - 540)/2;

     window.open(URL, '', 'width=500,height=540,screenX='+xOffset+',screenY='+yOffset+', top='+yOffset+',left='+xOffset+',toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0');

}

var winUpload=0;
function OnUnload()
 {
  if (winUpload)
   winUpload.close();
 }

function PopupBox(type) {
        day = new Date();
        id = day.getTime();
                page = "popup?type=" + type;
        eval("page" + id + " = window.open(page, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=200');");
}


function SlideBox(url) {
     var xMax = screen.width, yMax = screen.height;
     var xOffset = (xMax - 800)/2, yOffset = (yMax - 600)/2;
     window.open(url, '', 'width=800,height=600,screenX='+xOffset+',screenY='+yOffset+', top='+yOffset+',left='+xOffset+',toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0');
}

function Search() {
        text = prompt("Enter search terms", "");
        if (text.length < 1) {
                return true;
        }
        document.location = "search?terms="+text;
}

function UnLock(name) {
        return confirm("Make this image public?");
}

function ConfirmDel() {
                return confirm("There are no more albums with this image. This photo will be deleted! Continue?");
}

function Border (num) {
	document.bdr0.src="/photoshelf/images" + "/border"+ num + "-0.gif";
	document.bdr1.src="/photoshelf/images" + "/border"+ num + "-1.gif";
	document.bdr2.src="/photoshelf/images" + "/border"+ num + "-2.gif";
	document.bdr3.src="/photoshelf/images" + "/border"+ num + "-3.gif";
	document.bdr4.src="/photoshelf/images" + "/border"+ num + "-4.gif";
	document.bdr5.src="/photoshelf/images" + "/border"+ num + "-5.gif";
	document.bdr6.src="/photoshelf/images" + "/border"+ num + "-6.gif";
	document.bdr7.src="/photoshelf/images" + "/border"+ num + "-7.gif";
}

