#!/usr/bin/perl

#
# create an album
#

use PhotoShelf;

sub Usage {
	print <<EOF
Usage: $0 [-p] [-u owner] [-t type] [-P parent] [-k keywords] [-d descr] name

-p	Make album public
-u	specify owner
-t  Album is <type> (0 = album, 1 = list of albums)
-P  Parent of album is <arg>
-k	Use <arg> as keywords
-d	Use <arg> for dscription
EOF
;
	exit(0);
}

$Owner = $ENV{'USER'};
$Parent = 0;
$Type = 0;


while ($arg = shift (@ARGV)) {
	if ($arg eq "-p") {
		$Public = 1;
	} elsif ($arg eq "-u") {
		$Owner = shift @ARGV;
	} elsif ($arg eq "-k") {
		$Keywords = shift @ARGV;
	} elsif ($arg eq "-d") {
		$Descr = shift @ARGV;
	} elsif ($arg eq '-t') {
		$Type = shift @ARGV;
	} elsif ($arg eq '-P') {
		$Parent = shift @ARGV;
	else {
		$Name = $arg;
	}
}

if ($Name =~ /^$/) {
	Usage();
}
if ($Name !~ /^[0-9A-Z_ \.,]+$/i) {
	print "Not a legal album name: $Name\nUse only alphanumeric\n";
	exit(1);
}

if ($Descr !~ /^[0-9A-Z_,\. ]+$/i && $Descr !~ /^$/) {
	print "Not a legal description: $Descr\nUse only alphanumeric\n";
	exit(1);
}

if ($Keywords !~ /^[0-9A-Z_,\. ]+$/i && $Keywords !~ /^$/) {
	print "Not a legal description: $Descr\nUse only alphanumeric\n";
	exit(1);
}

$con = db_connect();
if ($con == -1) {
		print "Error connecting to database!\n";
		exit(1);
}

if (AlbumExists($Owner, $Name)) {
	print "Error, album already exists!\n";
	exit(0);
}

if(!AlbumExists($Parent)) {
	print "Error - parent must exist!\n";
	exit(0);
}


$res = CreateAlbum($Name, $Owner, $Descr, $Keywords, $Parent, $Type);
if (!$res) {
	print "Error creating album!\n";
	exit(1);
}

print "Album successfully created.\n";

