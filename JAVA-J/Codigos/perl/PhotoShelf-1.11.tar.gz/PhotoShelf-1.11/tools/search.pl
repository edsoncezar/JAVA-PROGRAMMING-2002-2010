#!/usr/bin/perl

use PhotoShelf;

sub Usage {

	print "Usage: $0 <search term>\n";
	exit(0);
}

if ($ARGV[0] =~ /^$/) {
	Usage();
} else {
	$Term = $ARGV[0];
}

@SearchFields = ("keywords", "caption", "comment", "filename");

db_connect || die "Error connecting to db";

printf ("%20s %20s %20s\n\n", "Filename", "Caption", "Keywords");
foreach $field (@SearchFields) {
	$qry = sprintf("SELECT imageid FROM photos WHERE %s ~* '%s'",
		$field, $Term);
	$res = db_query($qry);
	if ($res == -1) {
		print "Error performing search query!\n";
		exit(1);
	}
	while (@row = $res->fetchrow) {
		($id) = @row;
		next, if ($Found{$id});
		$Found{$id}++;
		$file = db_id_to_file($id);
		$qry = "SELECT keywords,caption FROM photos WHERE imageid = $id";
		$rs = db_query($qry);
		if ($rs == -1) {
			print "Error performing query: $qry\n";
			next;
		}
		($keywords, $caption) = $rs->fetchrow;
		printf ("%15s %20s %20s\n", $file, $caption, $keywords);
	}
}
