#!/usr/bin/perl

#
# list-images.pl
#
# List all images in the datbase
#

use PhotoShelf;

$Conn = db_connect();

$Regex = $ARGV[0];

if ($Conn == -1) {
	die "Cannot connect to DB";
}

if ($Regex !~ /^$/) {
	$Regex = "WHERE keywords ~* '$Regex' OR filename ~* '$Regex'";
}

$qry = "SELECT imageid, filename, filesize, caption, keywords FROM photos $Regex";
$res = db_query($qry);

if ($res == -1) {
	die "Error getting photo information";
}

print "Imageid | Filename       |   Size   |        Description            |   Keywords\n";
print "-----------------------------------------------\n";

while (@row = $res->fetchrow()) {
	($id, $file,$size,$caption, $keywords) = @row;
	printf("%7d %-15s  %8ld  %25s %s\n", $id, $file, $size, $caption, $keywords);
}

