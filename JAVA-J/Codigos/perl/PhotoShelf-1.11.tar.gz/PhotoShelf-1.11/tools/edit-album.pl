#!/usr/bin/perl

# edit-album.pl
#
# edit album properties

use PhotoShelf;

sub Usage {
	print <<EOF
Usage: $0 [-/+p] [-d descr] [-k keywords] [-t titleimg] name

	+/-p	Allow/disable public access
	-d		Set description
	-u		Specify username
	-k		Set keywords
	-t		Set title image (use id num)
EOF
;
	exit(0);
}

$Owner = $ENV{'USER'};

while ($arg = shift @ARGV) {
	if ($arg eq "-p") {
		$Public = 0;
		next;
	}  elsif ($arg eq "+p") {
		$Public = 1;
		next;
	} elsif ($arg eq "-u") {
		$Owner = shift @ARGV;
		next;
	} elsif ($arg eq "-d") {
		$Descr = shift @ARGV;
		next;
	} elsif ($arg eq "-k") {
		$Keywords = shift @ARGV;
		next;
	} elsif ($arg eq "-t") {
		$Titlepic = shift @ARGV;
		next;
	}
	$Album = $arg;
}

if ($Album =~ /^$/) {
	Usage();
}

db_connect();

if (!AlbumExists($Owner, $Album)) {
	print "Error, album $Album doesnt exist for user $Owner\n";
	exit(0);
}

$id = AlbumNameId($Owner, $Album);

if (defined($Descr)) {
	$res = AlbumDescr($id, 0, $Descr);
	if ($res == 0) {
		print "Error updating description!\n";
	}
}


if (defined($Keywords)) {
	$res = AlbumKeywords($id, 0, $Keywords);
	if ($res < 1) {
		print "Error updating keywords!\n";
	}
}

if (defined($Titlepic)) {
	if (!AlbumImageIn($id, $Titlepic)) {
		print "Image id $Titlepic not in album!\n";
	}
	$res = AlbumTitlePic($id, $Titlepic);
	if ($res < 1) {
		print "Error updating title pic!\n";
	}
}

if (defined($Public)) {
	$res = AlbumPublic($id, "", $Public);
	if ($res < 1) {
		print "Error updating public status!\n";
	}
}
