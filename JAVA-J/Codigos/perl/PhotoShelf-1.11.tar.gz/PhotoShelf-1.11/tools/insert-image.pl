#!/usr/bin/perl

#
# ?Front end for inserting an image into the DB
#
# Functions necessary:
#
# - Usage
# - Read config??
# - Check if file exists
# - Check if file is in DB already
# - Extract image information
#

use PhotoShelf;
use File::MMagic;
use Archive::Tar;
use Archive::Zip;
use Digest::MD5;

$Prompt = 0;

# settable variables on the command line
# [<flag>, <description>, <db var>, string?, default]

sub Usage {
	print "Usage: $0 [-d] [opts] <files|directory>\n\n";
	print "\t-d\t Prompt for descriptions, etc\n";
	print "\t-u\t PhotoShelf user to install as\n";
	foreach $field (0..$#CmdLine) {
		$flag = $CmdLine[$field][0];
		$var = $CmdLine[$field][1];
		$dbvar = $CmdLine[$field][2];
		print "\t$flag <str>\tUse <str> for $dbvar\n";
	}
	print "If <file>, single file is inserted, if <directory>, whole dir\n";
	print "is inserted into the DB\n";
	exit(0);
}

#
# Give a directory as arg, returns array of full filenames
#
sub recurse_dir {
my ($dir) = @_;
my $wholename;
my (@Files);

	opendir (DIR, "$dir") || die "Cannot open $dir: $!";
	@files = grep { /^[^\. ]/ } readdir(DIR);
	closedir DIR;
	foreach (@files) {
		if (/\.jpg$/i || /\.jpeg$/i || /\.png$/i || /\.tiff$/i) {
			$wholename = $dir . $_;
			push (@Files, $wholename);
		}
	}
	return @Files;
}



$Copyright = "";
$Country = "";
$City = "";

ARGSS:
while ($arg = shift @ARGV) {
	if ($arg =~ /^-d$/) {
		print "Prompting..\n";
		$Prompt = 1;
		next;
	}
	if ($arg eq "-u") {
		$Owner = shift (@ARGV);
		next;
	}
	foreach $field (0..$#CmdLine) {
		$flag = $CmdLine[$field][0];
		$var = $CmdLine[$field][1];
		$dbvar = $CmdLine[$field][2];
		next, unless ($flag =~ /^$arg$/);
		$copy = shift(@ARGV);
		$CmdLine[$field][4] = $copy;
		print "Adding $dbvar: $copy\n";
		next ARGSS;
	}
	push(@Files, $arg);
}

if ($#Files < 0) {
	Usage();
	exit(0);
}


if (-d $Files[0]) {
	print "Recursing..\n";
	@Files = recurse_dir($Files[0]);
}

db_connect();

$tmpdir = "$RealDir/tmp/";

$Owner ||= $ENV{USER};

my ($user) = $Db_Conn->selectrow_array("SELECT name FROM users WHERE name = '$Owner'");
if ($user eq "") {
	die "User $Owner does not exist in this PhotoShelf system!";
}

my $TotalPix = 0; # number of photos successfully added.
my @InsErr = (); # array of error messages for each photo

ProcessFiles();

sub ProcessFiles {
my($first) = "";
my(%lfiles) = ();

	$count = 0;
	foreach $newfile (@Files) {
			$filename = strip_dir ($newfile);
			my $mm = new File::MMagic;
			$res = $mm->checktype_filename("$newfile");
			if ($res =~ /zip/ || $res =~ /tar/) {
				print "Extracting archive $newfile..\n";
				$id = ExtractArchive($newfile);
			} elsif ($res eq "image/jpeg") {
				print "Inserting image $newfile..\n";
				$id = InsertImage($filename, $newfile);
			} else {
				BadType();
			}
			$first = $id, unless($first > 0);
	}
	$albref = AlbumNameId($Owner, "Default"), if ($albref eq "");
	print "Got the following messages:\n";
	foreach $err (@InsErr) {
		print "$err\n";
	}
	exit(0);
}
sub BadType {

	print "Error: $filename is not a jpeg image or tar/zip file!\n";
	exit;
}

sub InsertImage {
my($name,$file) = @_;
my($info,$qry,$res,$id);

	my $md5 = md5_check($file);
	if ($md5 eq "") {
		push (@InsErr, "$name: Already exists.\n");
		return "File already exists (same md5 sum)";
	}
	$info = get_image_info($file);
	$info->{'md5'} = $md5;
	$info->{'filename'} = $name;
        $info->{'keywords'} = $Info{$name}{keywords};
        $info->{'owner'} = $Owner;
        $info->{'description'} = $Info{$name}{description};
        $info->{'caption'} = $Info{$name}{caption};
        $info->{'city'} = $Info{$name}{city};
        $info->{'country'} = $Info{$name}{country};

	$qry = sprintf("SELECT id FROM format WHERE descr = '%s'",
		$info->{'format'});
	($info->{'format'}) = $Db_Conn->selectrow_array($qry);
	$id = database_insert($info);
	if (!$id || $id == -1) {
		push (@InsErr, "$name: Error inserting into db.<br>\n");
		return "Error inserting $file into database!\n";
	}
	db_image_owner($id, $Owner);
	$res = repository_insert($file, $id);
	if (!$res) {
		database_delete($stripped);
		push (@InsErr, "$name: Error inserting into repository.<br>\n");
		return "Error inserting $file into repository!";
	}
	$qry = sprintf("UPDATE photos SET directory = '%s', albumrefcount = 0 WHERE imageid = %d",
				$res, $id);
	$res = $Db_Conn->do($qry);
        $defaultalbum ||= ($albref < 1 ? AlbumNameId($Owner, "Default") : $albref);
        AlbumAdd($defaultalbum, $id);
        if (defined(%NewAlbum)) {
                AlbumTitlePic($defaultalbum, $id), if $name eq $NewAlbum{title};
        }
	$TotalPix++;
	push (@InsErr, "$name: Added successfully\n");
	return $id;
}

sub md5_check {
my($file) = @_;

	open (PIC, "$file") or DoError($Owner, "md5_check: Cannot open $file: $!");
	my $img = "";
	while (<PIC>) {
		$img .= $_;
	}
	close PIC;
	my $sum = Digest::MD5::md5_hex($img);
	my @res = $Db_Conn->selectrow_array("SELECT imageid,md5sum FROM photos WHERE owner = '$Owner' AND md5sum = '$sum'");
	if ($res[0] !~ /^$/) {
		return "";
	} else {
		return $sum;
	}
}

# extract files from an archive

sub ExtractArchive {
my($file) = @_;
my ($ret, $mm, $cwd, $res);

	use File::Find;

	$mm = new File::MMagic;
	$res = $mm->checktype_filename("$file");
	my $tempdir = "$tmpdir/unarchived.$$." . time();
	if (-e "$tempdir") {
		system "/bin/rm -rf $tempdir";
	}
	mkdir ("$tempdir", 0711) or DoError($Owner, "Can't create temp directory: $!");
	chomp($cwd = `pwd`);
	chdir "$tempdir" or warn "ExtractArchive: Can't chdir: $!";
	if ($res =~ /gzip/ || $res =~ /tar/) {
		ExtractTar($file);
	} elsif ($res =~ /x-zip/) {
		ExtractZip($file);
	}
RECURSE:
	find sub {
		my $fname = $_;
		my($file) = $File::Find::name;
		if (-f $file) {
			if ($file =~ /PhotoShelf.dat$/) {
				ProcessMetaData($file);
			} else {
				$res = $mm->checktype_filename("$file");
				if ($res eq "image/jpeg") {
					push (@Files, "$file:$fname");
				}
			}
		}
	}, "$tempdir/";
# if the metadata file existed and contained album information...
# create the album at the top level.

        if (defined(%NewAlbum)) {
                my $toplevel = AlbumTop($Owner);
                $defaultalbum = CreateAlbum($NewAlbum{name}, $Owner,
                                $NewAlbum{description}, $NewAlbum{keywords},
                                $toplevel, 0);
        }
        foreach my $pic (@Files) {
                my ($file,$fname) = split(/:/, $pic);
                $Info{$fname}{keywords} ||= $Keywords;
                $ret = InsertImage($fname, $file);
                unlink $file or warn "Error deleting $file: $!";
        }

	chdir $cwd;
	rmdir  "$tempdir";
	return $ret;
}

sub ExtractTar {
my($file) = @_;

	my $res = Archive::Tar->extract_archive($file);
	if (!defined($res)) {
# TODO: list errors at the end of all page processing
		warn "Error- cannot untar $file: " . Archive::Tar::error;
	}
	return 1;
}

sub ExtractZip {
my($file) = @_;

	my $zip = Archive::Zip->new();
	DoError($Owner, "Error reading zip file!"), if $zip->read($file) != AZ_OK;

	my @members = $zip->memberNames();
	foreach my $name (@members) {
		$res = $zip->extractMember($name);
	}
}

sub InsertError {
my($Error) = @_;

	print <<EOF;
There was an error adding the image to the database: 

$Error

Please rectify this.
EOF
}


sub ProcessMetaData {
my($file) = @_;
my @tmp = ();
my @bits = ();

	open (META, "$file") or warn "Can't open metadata file: $!";
	while (<META>) {
		chomp;
		@bits = split(/\\?:/, $_);
		@tmp = ();
		foreach $bit (@bits) {
			$bit =~ s/\\:/:/g;
			push (@tmp, $bit);
		}
		if (/__ALBUM__/) {
			(undef, $NewAlbum{name},
			$NewAlbum{description},
			$NewAlbum{keywords},
			$NewAlbum{title}) = @tmp;
			next;
		}
		($filename) = @tmp;
		(undef,
		$Info{$filename}{origin},
		$Info{$filename}{createdate},
		$Info{$filename}{subtype},
		$Info{$filename}{status},
		$Info{$filename}{copyright},
		$Info{$filename}{lighting},
		$Info{$filename}{country},
		$Info{$filename}{city},
		$Info{$filename}{keywords},
		$Info{$filename}{comment},
		$Info{$filename}{caption},
		$Info{$filename}{pub},
		$Info{$filename}{rate},
		$Info{$filename}{border}) = @tmp;
	}
	close META;
}

