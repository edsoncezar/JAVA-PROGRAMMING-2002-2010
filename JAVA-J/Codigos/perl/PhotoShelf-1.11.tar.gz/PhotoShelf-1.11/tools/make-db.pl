#!/usr/bin/perl

# Create the database at installation time

# 0. Get config params
# 1. Connect
# 2. Query status of database
# 2a. If it exists, bail
# 3. Create the database
# 4. Create primary table
# 5. Create other tables

#use config;
$db_name = "photodb";
$db_host = ""; # local
$db_user = ""; # default

use PhotoShelf;

# Connect.

$db = db_connect();

if (!defined($db)) {
	print "Hmm already connected???\n";
	exit(1);
} elsif ($db > 0) {
	print "Hmm..database exists! Exiting\n";
	exit(1);
} elsif ($db == -1) {
	print "Good - database doesnt exist so lets create it..\n";
	$db = db_connect("template1");
	if ($db < 1) {
		print "Error connecting to 'template1' database.\n";
		exit(1);
	}
	$res = db_query("CREATE DATABASE photodb");
	if (!$res) {
		die "Error creating database! Bailing...\n";
	}
	print "Successfully created database!\n";

#
# Create tables
#
# read from template, format is:
#
# Table   1stCol  Type   Default  Null?
#
# Each is:
# Table: string
# 1stCol: string
# Type: Any SQL type
# Default: string/int
# Null?: T/F/t/f/y/n/Y/N
#

open(TABS, "table.tmpl") or die "Cannot open table template: $!";

while (<TABS>) {
	chomp;
	($table, $col, $type,$default,$null,$crap) = split(/\s+/);
	if ($crap !~ /^$/) {
		die "Too many elements on line: $!";
	}
	$Tables{$table}->{Col} = $col;
	$Tables{$table}->{Type} = $type;
	$Tables{$table}->{Default} = $default;
	$Tables{$table}->{Null} = $null;
	if ($notnull !~ /^[yYtT]$/ && $notnull !~ /^[nNfF]$/) {
		die "Null field must be one of yYnNtTfF";
	}
}

foreach $table (keys % Tables) {
	$qry = "CREATE TABLE $table ( ";

	$col = $Tables{$table}->{Col};
	$type = $Tables{$table}->{Type};
	$default = $Tables{$table}->{Default};
	$null = $Tables{$table}->{Null};
	$qry .= "$col $type ";
	if ($default != "\"\"") {
		$qry .= "DEFAULT '$default' ";
	}
	$res = db_query($qry);
	if ($res == -1) {
		die "Error on query: $qry ($!)";
	}
}

	if ($notnull =~ /^[yYtT]$/) {
		$qry .= "CONSTRAINT NOT NULL ";
	}
