#!/usr/bin/perl

use PhotoShelf;

sub Usage {
	print "Usage: $0 [-v] -a <album> <fileid ...>\n\n";
	print "\t-v\tVerbose mode.\n";
	exit(0);
}

if ($#ARGV < 0) {
	Usage();
}

while ($arg = shift @ARGV) {
	if ($arg =~ /^-v$/) {
		$verbose = 1;
	} elsif ($arg =~ /^-a$/) {
		$album = shift (@ARGV);
	} else {
		push (@Files, $arg);
	}
}

$Owner = $ENV{USER};

if ($album < 1) {
	Usage();
}

db_connect();

foreach $File (@Files) {

	if (!db_image_exists($File)) {
		warn "Image $File does not exist in database!";
	} else {
		AlbumDelPix($album, $File);
		print "Deleted image $File\n";
	}
}

