#!/usr/bin/perl

use PhotoShelf;

#
# album-insert.pl
#
# insert image[s] into the album

sub Usage {
	print <<EOF
Usage: $0 <album> <images ..>

	<album> is the album numeric id
	Use imageids from database for images.
EOF
;
	exit(0);
}

db_connect();

$Album = shift @ARGV;

if ($Album =~ /^$/) {
	Usage();
}

if (!AlbumExists($Album)) {
	print "Error: Album number $Album does not exist!\n";
	exit(0);
}

while ($imageid = shift(@ARGV)) {
	if ($imageid !~ /^[0-9]+$/) {
		print "Invalid image id: $imageid\n";
		next;
	}
	if (!db_image_exists($imageid)) {
		print "Image not found: $imageid\n";
		next;
	}
	if (AlbumImageIn($Album, $imageid)) {
		print "$imageid already in album..\n";
		next;
	}
	$res = AlbumAdd($Album, $imageid);
	if ($res != 1) {
		print "Error inserting $imageid into album!\n";
		next;
	}
	print "Inserted $imageid into album.\n";
}


