#!/usr/bin/perl

# 
# edit-image.pl
#
# Edit the comments, etc associated with an image in the db
#

use PhotoShelf;

# Fiels here are:
#
# ["<db_field_name>", "<Prompt_query>", extract_id?]
#
# extract_id is 1 or 0..0 means use raw value, 1
# means run through db_id_to_nd()
#

@FieldEdit = (
	["origin", "Origin of Image",1],
	["subtype", "Subject of image",1],
	["status", "Status of this image",1],
	["country", "Country photo was taken in",0],
	["city", "City photo was taken in",0],
	["keywords", "Comma separated list of keywords",0],
	["comment", "Description of photo",0],
	["caption", "Brief image caption",0]);

while ($arg = shift @ARGV) {
	push(@Files, $arg);
}

$Conn = db_connect();
if ($Conn == -1) {
	die "Error connecting to database";
}

foreach $file (@Files) {
	if(!db_image_exists($file)) {
		print STDERR "Cannot find $file in db.\n";
		next;
	}
	$qry = sprintf("SELECT origin,subtype,status,lighting,country,city,".
			"keywords, comment, caption FROM photos WHERE filename = '%s'",
			$file);
	$res = db_query($qry);
	if ($res == -1) {
		print STDERR "Error getting info for $file\n";
		next;
	}
	($origin,$subtype,$status,$lighting,$country,$city,$keywords,
		$comment,$caption) = $res->fetchrow;
	print "Editing info for $file\n";
	foreach $field (0..$#FieldEdit) {
		$dbvar = $FieldEdit[$field][0];
		$desc = $FieldEdit[$field][1];
		$| = 1;
		if ($FieldEdit[$field][2] == 1) {
			(undef,$deflt) = db_id_to_nd($dbvar, ${$dbvar});
		} else {
			$deflt = ${$dbvar};
		}
		print "$desc". "?[" . $deflt . "]:";
		$var = <STDIN>;
		chomp($var);
		next, if ($var =~ /^$/);
		${$dbvar} = $var;
	}
	$qry = sprintf("UPDATE photos SET origin = %d , subtype = %d , ".
			"status = %d, lighting = %d, country = '%s', city = '%s', ".
			"keywords = '%s', comment = '%s', caption = '%s' WHERE ".
			"filename = '%s'", $origin, $subtype, $status, $lighting,
			$country, $city, $keywords, $comment, $caption, $file);
	$res = db_query($qry);
	if ($res == -1) {
		print STDERR "Error updating database!\n";
	}
}
