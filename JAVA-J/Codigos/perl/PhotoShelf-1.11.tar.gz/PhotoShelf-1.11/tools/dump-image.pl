#!/usr/bin/perl

#
# dump-image.pl
#
# dump an image from the database to stdout or a file
#

use PhotoShelf;

sub Usage {
	print "Usage: $0 <imageid> [<outfile>]\n\n";
	print "\tDumps file id <imageid> from database to <outfile>,\n";
	print "\tstdout (-), or db filename if unspecified.\n";
	exit(0);
}

$File = $ARGV[0];

Usage(), if (!$File);

$Outfile = $ARGV[1];

db_connect();

if (!$Outfile) {
	$Outfile = db_id_to_file($File);
}

$id = $File;

if (!db_image_exists($File)) {
	die "Image $File not in database!";
}

$fh = db_get_image_fh($id,2);

if (!$fh) {
	die "Error getting filehandle for $File";
}

open(OUT, ">$Outfile") or die "Cannot open $Outfile: $!";
select OUT;

while (<$fh>) {
	print $_;
}

close $fh;

