#!/usr/bin/perl

#
# info-image.pl
#
# Show information for an image
#

use PhotoShelf;

while ($arg = shift @ARGV) {
	push (@Files, $arg);
}

$Conn = db_connect();
if ($Conn == -1) {
	die "Can't connect to database..\n";
}

foreach $file (@Files) {
	if (!db_image_exists($file)) {
		print STDERR "Cannot find $file in DB.\n";
		next;
	}
	$qry = sprintf("SELECT filesize, width, height, cameramake, cameramodel," .
			"createdate, filmiso, filmexposure, filmaperture, filmmetering," .
			"filmfoclen, flash, comment, copyright FROM photos WHERE filename = '%s'", $file);
	$res = db_query($qry);
	if ($res->ntuples != 1) {
		print STDERR "Error getting info for $file\n";
		next;
	}
	($I_size,$I_width,$I_height,$I_make,$I_model,$I_create,$I_iso,$I_exp,
	$I_fstop,$I_metering,$I_foclen,$I_flash,$I_desc,$I_copy) = $res->fetchrow();
	$I_exp = shutter_str($I_exp);

	print <<EOF;
Information for : $file
--------------------------------
Filesize: $I_size
   Descr: $I_desc
Geometry: $I_width x $I_height

      ISO: $I_iso
  Shutter: $I_exp
   F-Stop: $I_fstop
Focal len: $I_foclen mm
 Metering: $I_metering
    Flash: $I_flash

Copyright: $I_copy
--------------------------------
EOF
}

