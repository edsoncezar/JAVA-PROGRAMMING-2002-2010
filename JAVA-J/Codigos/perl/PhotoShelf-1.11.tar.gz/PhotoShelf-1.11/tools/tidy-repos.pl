#!/usr/bin/perl

use File::Find;
use PhotoShelf;

db_connect();

find sub {
	my $fname = $_;
	my($file) = $File::Find::name;
	if (-f $file) {
		if ($fname =~ /^([0-9]+)\.[it]/) {
			$id = $1;
			if ($NonExistant{$id} || !db_image_exists($id)) {
				print "Image $id found, but not in db ($file)!\n";
				$NonExistant{$id}++;
				unlink $file;
			}
		}
	}
}, $repository;


