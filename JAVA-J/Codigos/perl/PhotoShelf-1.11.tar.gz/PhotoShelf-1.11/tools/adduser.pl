#!/usr/bin/perl

use PhotoShelf;

db_connect();

$| = 1;

$Db_Conn->{RaiseError} = 1;
$Db_Conn->{AutoCommit} = 0;

print "Username of the new user: ";
$name = <>;
chomp $name;
exit(0), unless ($name =~ /^[A-Z0-9_\-\.]+$/i);

@flim = $Db_Conn->selectrow_array("SELECT id FROM users WHERE name = '$name'");

if ($#flim >= 0) {
	die "Error: User $name already exists!";
}

print "Real name: "; $rname = <STDIN>;
chomp $rname;
print "Email address: "; $add = <STDIN>;
chomp $add;
print "Is this user an administrator? [y/n] "; $admin = <STDIN>;
$admin =  ($admin !~ /y/i) ? "u" : "a";

PASS:
print "New password: ";
$pass = <>;
chomp $pass;
goto PASS, if ($pass =~ /^$/);

$Db_Conn->do("INSERT INTO users (name,cryptpw,email,realname,privs,sessionid,sesstime,slideinterval,options) VALUES ('$name', '$pass', '$add', '$rname', '$admin', 0, 0, 10,1)");

$res = CreateAlbum($name,$name,'','',0,1);
if (!$res) {
	print "Error creating top level album for user!\n";
	exit(1);
}

$res = CreateAlbum("Default",$name,'Default Album','',$res,0);
if (!$res) {
	print "Error creating default album for user!\n";
	exit(1);
}



$Db_Conn->commit, unless ($Db_Conn->{AutoCommit} = 0);

print "User '$name' successfully added\n";

exit(0);
