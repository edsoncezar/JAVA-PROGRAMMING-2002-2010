#!/usr/bin/perl

#
# delete an album
#

use PhotoShelf;

sub Usage {
	print <<EOF
Usage: $0 <id>
EOF
;
	exit(0);
}

$Owner = $ENV{'USER'};

$id = $ARGV[0];

$Owner = $ARGV[1], if ($ARGV[1] !~ /^$/);

if ($id !~ /^[0-9]+$/) {
	Usage();
}

if ($id !~ /^[0-9A-Z_-]+$/i) {
	print "Not a legal album id\n";
	exit(1);
}

db_connect();

if (!AlbumExists($Owner, $id)) {
	print "Error, album $id does not exist for user $Owner!\n";
	exit(0);
}

@pics = AlbumListPix($id, 1);
if (@pics > 0) {
	print "\nError: Album not empty - delete images first!";
	exit(0);
}

$res = DeleteAlbum($Owner, $id);
if ($res != 1) {
	print "Error deleting album! ($res)\n";
	exit(1);
}

print "Album successfully deleted.\n";

