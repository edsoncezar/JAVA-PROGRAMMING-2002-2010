#!/usr/bin/perl

use PhotoShelf;

db_connect();

$str = "SELECT imageid, albumrefcount FROM photos where albumrefcount = 0";
$qry = $Db_Conn->prepare($str);
$qry->execute();

while(@ary = $qry->fetchrow_array) {
	($img,$count) = @ary;
	print "Deleting $img\n";
#	db_del_pic($img);
}

