#!/usr/bin/perl

# list-albums.pl
# 
# list all albums, or pictures in an album
#

use PhotoShelf;

if ($ARGV[0] !~ /^$/) {
	$user = $ARGV[0];
} else {
	$user = $ENV{'USER'};
}

if ($ARGV[0] =~ /^[0-9]+$/) {
	$Album = $ARGV[0];
	$user = "";
}

db_connect();

if (defined($Album)) {
	ListAlbum();
	exit(0);
}

@Albums = AlbumList($user, -1);

printf ("%3s %-10s %-20s %-25s %-7s\n", "No.", "Owner", "Album name", "Description", "# Pix");
print "--------------------------------------------------------------------------------\n";
foreach $list (@Albums) {
	($album,$owner,$id) = split(/:/, $list);
	if ($id < 1) {
		print "Error querying album $id!\n";
		next;
	}
	if (AlbumPublic($id, "", undef) || AlbumOwner($id, "") eq $user) {
		$descr = AlbumDescr($id, 0, "");
		$images = AlbumNumPix($id);
		printf ("%3d %-10s %-20s %-25s %-7d\n", $id, $owner, $album, $descr, $images);
	}
}

sub ListAlbum {

	if (!AlbumExists($Album, 0)) {
		print "Album does not exist: $Album\n";
		return 0;
	}
	@list = AlbumListPix($Album);
	while ($id = shift(@list)) {
		$caption = db_img_caption($id);
		$filename = db_id_to_file($id);
		print "$id $filename: $caption\n";
	}
}

