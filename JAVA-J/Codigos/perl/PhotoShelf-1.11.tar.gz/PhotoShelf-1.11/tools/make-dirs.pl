#!/usr/bin/perl

use PhotoShelf;

db_connect();

$basedir = $repository;

for ($fl = 0 ; $fl <= 0xf ; $fl++) {
	$fls = sprintf "%.2x", $fl;
	$dir = "$basedir/$fls";
	if (! -d $dir) {
		print "Creating $dir\n";
		if (mkdir ("$dir", 0777) == 0) {
			die "Error creating $dir: $!";
		}
	}
	for ($sl = 0 ; $sl != 0xf ; $sl++) {
		$sls = sprintf "%.2x", $sl;
		$dir = "$basedir/$fls/$sls";
		push (@Dirs, "$fls/$sls");
		if (! -d $dir) {
			print "Creating $dir\n";
			if (mkdir ("$dir", 0777) == 0) {
				die "Error creating $dir: $!";
			}
		}
	}
}
print "Done creating directories\n";

$|=1;

print "Adding database entries...";

foreach $dirname (@Dirs) {
	my ($dir) = $Db_Conn->selectrow_array("SELECT dir FROM repos_dirs WHERE dir = '$dirname'");
	if ($dir eq "") {
		$Db_Conn->do("INSERT INTO repos_dirs VALUES ('$dirname', 0)");
	}
}

print <<EOF;

--------------------------IMPORTANT-----------------------------
You must now run 'chown -R <userid> $repository', where <userid>
is the user who the web server will run the scripts as. This
ensures that the repository can be written to by the
scripts.
----------------------------------------------------------------
EOF
