package PhotoShelf;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $Db_Conn);

use DBI;
use Image::Magick;
use HTTP::Date;
use Image::Info qw(image_info dim);
require Exporter;

$PhotoShelf::VERSION = '1.11';
$DefaultDir = "/var/www/html/photoshelf"; # ---WATCHOUT---

# Make use of greedy regex match to extract the directory
if ($ENV{'SCRIPT_FILENAME'} =~ /^(.*\/).*$/) {
    $RealDir = $1;
} elsif (-f ($ENV{'HOME'} . "/.photoshelfrc")) {
    eval $ENV{'HOME'} . "/.photoshelfrc";
} elsif (-f "$DefaultDir/photoshelf.cfg") { 
    $RealDir = $DefaultDir;
} else {
    die "Cannot find 'SCRIPT_FILENAME' variable, \$HOME/.photoshelfrc or $DefaultDir/photoshelf.cfg!\n\nEdit PhotoShelf.pm near line 13 and edit the variable \$DefaultDir\n";
}

@ISA = qw(Exporter AutoLoader);
@EXPORT = qw(
db_connect
db_close
db_query
db_add_dir_file
db_del_dir_file
db_image_owner
db_image_exists
db_get_image_fh
db_get_image_file
db_update_img_refcount
db_swap_geometry
db_get_image_size
db_get_image_geom
db_delete_image
db_del_pic
shutter_str
db_img_caption
db_img_descr
db_rate_image
db_get_rating
db_img_viewable
db_id_to_nd
db_name_to_id
strip_dir
db_id_to_file
db_file_to_id
db_newest_images
db_user_email
db_user_name
db_get_insdate
list_types
database_insert
database_delete
CreateAlbum
DeleteAlbum
AlbumNameId
AlbumIdName
AlbumKeywords
AlbumExists
AlbumPublic
AlbumDescr
AlbumTop
AlbumAdd
AlbumTitle
AlbumTitlePic
AlbumNumPix
AlbumNext
AlbumFirstPix
AlbumImageIn
AlbumDelPix
AlbumGetAxs
AlbumListPix
AlbumList
AlbumMove
AlbumAdj
AlbumLastImg
AlbumShowAncestor
AlbumMovePic
AlbumIns
AlbumOwner
AlbumParents
AlbumParent
NextAlbum
ShowImage
QuickSearch
PrintHeader
PrintFooter
UpdateAccess
image_rotate
img_normalize
img_restore_orig
DateCmp
repository_insert
repository_delete
resize_image
Userverify
CheckPw
AskLogin
UserLogout
UserInterval
UserOptions
UserLevel
get_image_info
ImgBorder
ForceUrl
DoError
ImageCacheGetImage
ImageCacheAddImage
ImageCacheDelImage

$AlbToolFG
$AlbToolBG
$Db_Conn
$TableLowBG
$TableMedBG
$TableHighBG
$TextNorm
$LinkText
$VLinkText
$BGNorm
$TextTable
$TextLoTable
$TabsBG
$TabsFG
$RealDir
$Borders
$URI
$IcoUrl
$Repos_Url
$repository
$UseFastLocalImages
@DisplayedInfo
@CmdLine
);

# TODO:
#
# look at doQuery Pg function

@CmdLine = (
    ["-c", "Copyright", "copyright", 1, ""],
    ["-C", "Country", "country", 1, ""],
    ["-s", "Source", "origin", 0, ""],
    ["-l", "Lighting", "lighting", 0, ""],
    ["-k", "Keywords", "keywords", 1, ""],
    ["-S", "Status", "status", 0, 1],
    ["-p", "Caption", "caption", 1, ""],
    ["-P", "Public", "pub", 1, 'f'],
    ["-ct", "City", "city", 1, ""]);

my $NoCommit = 0;

# Connects to the database. This sets the global variable $Db_Conn -
# if it is already defined, no action is taken. The script is passed
# the name of the database to connect to. If the connection cannot
# be established, the script complains and exits.

sub db_connect {
my ($db) = @_;

    return if defined $Db_Conn;
    open(CFG, "$RealDir/photoshelf.cfg") or DoError("", "Can't open: $!\n");
    {
        local $/ = undef;
        eval (<CFG>); #slurp in entire file
    }
    close(CFG);
    $db ||= 'photodb'; #default to photodb
    my $data_source="dbi:Pg:dbname=$db";
    $data_source .= ";host=$db_host" unless $db_host eq 'localhost';
    if (!defined($Db_Conn = DBI->connect($data_source, $db_user, $db_pass,
                                {AutoCommit => 1}))) {
        DoError ("", "Could not connect to PhotoShelf database: $DBI::errstr");
    }
}

# Close the connection to the database

sub db_close {
    $Db_Conn->disconnect;
}

# Query the database, argument is the SQL statement
#
# Returns the number of rows affected by the query,
# or undef on an error.

sub db_query {
my($query) = @_;
my($res,$stat);
my($start, $tot);

    $start = time();
    $res = $Db_Conn->do($query);
    if (!defined($res)) {
        my($err) = $DBI::errstr;
        print "Got error calling $query : Returned $err\n";
        return -1;
    }
    $tot = time - $start;
#   system "echo 'Query $query took $tot sec' >> /tmp/profile.db";
    return $res;
}

# Check the README file for the directory structure. Essentially
# what this funtion does is find the directory in the repository
# that has the fewest entries, increment the entries count for that
# directory, and then return that directory. Essentially an LRU
# (least recently used) algorithm to evenly fill up the repository.
#
# every time an image is added to the db, we call this once with
# no arguments.

sub db_add_dir_file {
my($res);
my($qry);
my($dir);
my($count);

    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        ($count) = $Db_Conn->selectrow_array ("SELECT min(count) FROM repos_dirs");
        
        ($dir,$count) = $Db_Conn->selectrow_array("SELECT dir, count FROM repos_dirs WHERE count = $count");
        $count++;
        $Db_Conn->do("UPDATE repos_dirs SET count = $count WHERE dir = '$dir'");
        $Db_Conn->commit(), unless ($NoCommit);
    };
    if ($@) {
        warn "DB error in db_add_dir_file : $@";
        $Db_Conn->rollback(), unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return $dir;
}

# The opposite to the function above - decrements the directory
# count.
#
# argument is the directory to decrement. We call this function
# when an image in the repository is deleted.

sub db_del_dir_file {
my($res);
my($qry);
my($dir) = @_;
my($count);
    
    $Db_Conn->do("UPDATE repos_dirs SET count = count - 1 WHERE dir = '$dir'");
    if ($@) {
        warn "DB error in db_del_dir_file : $@";
        return -1;
    }
    return 1;
}

# Set/query the owner of an image, as stored in the database

sub db_image_owner {
my($id, $own) = @_;
my($owner,$qry,$res);

    if ($own ne "") {
        $owner = $own;
        $res = $Db_Conn->do("UPDATE photos SET owner = '$own' WHERE imageid = $id");
    } else {
        ($owner) = $Db_Conn->selectrow_array("SELECT owner FROM photos WHERE imageid = $id");
        if ($@) {
            warn "DB error in db_image_owner: $@";
            return 0;
        }
    }
    return $owner;
}

sub db_rate_image {
my($user, $id,$rate) = @_;

	return,  if ($rate > 5 || $rate < 1);
	if ($user eq db_image_owner($id)) {
		$Db_Conn->do("UPDATE photos SET ownerrating = $rate WHERE imageid = $id");
		return;
	}
	my ($tot, $count) = $Db_Conn->selectrow_array("SELECT visitorrating, visitorratecount FROM photos WHERE imageid = $id");
	$tot += $rate;
	$count++;
	$Db_Conn->do("UPDATE photos SET visitorrating = $tot, visitorratecount = $count WHERE imageid = $id");
}

sub db_get_rating {
my($id) = @_;
my($tot,$count);

	($tot,$count) = $Db_Conn->selectrow_array("SELECT visitorrating, visitorratecount FROM photos WHERE imageid = $id");
	return 0, if ($count < 1);
	return (int($tot*10/$count)/10);
}

# Finds if an image is viewable by a user
#
# arguments are the imageid and the user, and returns 1 if the user
# can view the image, or 0 otherwise.

sub db_img_viewable {
my($id,$user) = @_;
my($pub,$qry,$res,$owner);

    return 0, if ($id !~ /^[0-9]+$/);
    ($pub, $owner) = $Db_Conn->selectrow_array("SELECT pub,owner FROM photos WHERE imageid = $id");
    return 1, if ($owner eq $user);
    return ($pub);
}


# Find if an image is in the database
#
# argument is the imageid, and returns one or zero

sub db_image_exists {
my ($file) = @_;
my($term);
my ($res, $qry);

    if ($file =~ /^[0-9]+$/) {
        $term = "imageid";
        return 1, if ($Cache{'image_exists'}{$file});
    } else {
        return 0;
    }
    ($qry) = $Db_Conn->selectrow_array ("SELECT imageid FROM photos WHERE $term = '$file'");
    if ($qry > 0) {
        $Cache{'image_exists'}{$file} = 1;
        return 1;
    }
    return 0;
}

# Updates the album reference count for a photo. If it drops to zero,
# return 0, else return 1;
#
# This album refcount is a field in the photos table, indicating how
# many albums refer to an image.

# Arguments are imageid, and 1 to increment the refcount, or -1 to
# decrement the refcount. Returns one if refcount ends up above zero,
# or zero otherwise (ie if it returns zero, no albums refer to this
# image and it can be deleted).

sub db_update_img_refcount {
my($id, $dir) = @_;
my($ret,$ref);

    $Db_Conn->{'RaiseError'} = 1;
    $Db_Conn->{'AutoCommit'} = 0;
    eval {
        ($ref) = $Db_Conn->selectrow_array("SELECT albumrefcount FROM photos WHERE imageid = $id");
        if ($dir > 0) {
            $Db_Conn->do("UPDATE photos SET albumrefcount = albumrefcount +1 WHERE imageid = $id");
            $ret = 1;
        } elsif ($dir < 0 && $ref > 0) {
            $Db_Conn->do("UPDATE photos SET albumrefcount = albumrefcount -1 WHERE imageid = $id");
            $ret = ($ref > 1);
        } else {
            $ret = 1;
        }
        ImageCacheDelImage($id);
        $Db_Conn->commit(), unless($NoCommit);
    };
    if ($@) {
        warn "Error in db_update_img_refcount: $@";
        $Db_Conn->rollback(), unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return 1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return  $ret;
}

# Returns a number of recent images.
#
# Argument is the number of images to return. The function then
# returns a list of <arg> random images, picked from the 60 last
# entered images.

sub db_newest_images {
my($count) = @_;
my($qry,$res);
my($img,$date);
my(@flim);
my(@pix) = ();

    return, if ($count < 1);
    $qry = $Db_Conn->prepare("SELECT imageid FROM photos WHERE pub = 't' ORDER BY inserttm DESC LIMIT 60");
    $qry->execute;
    while (@flim = $qry->fetchrow_array) {
        ($img) = @flim;
        push(@pix, $img);
    }
    srand(time);
    my(@ret) = ();
    undef %Picked;
    my $found = scalar(@pix);
    my $max = ($found > $count ? $count : $found);
    while (1) {
        $picnum = int(rand(scalar(@pix)));
        push(@ret, $pix[$picnum]) , unless ($Picked{$picnum}++);
        last, if (scalar (@ret) >= $max);
    }
    return @ret;
}

# Return the (relative) filename for an image.
#
# Arguments are the imageid and what size image to return ; 0 for
# small thumbnail, 1 for 640pixel thumbnail, 2 for full size
# image.
# Returns the filename (relative to the repository root) of the
# image filename.

sub db_get_image_file {
my($id,$thumb) = @_;

my($dir,$res,$qry, $ext, $fullname);

    return 0, if ($id < 1);
    ($dir) = $Db_Conn->selectrow_array("SELECT directory FROM photos WHERE imageid = $id");
    if (!defined($dir)) {
        warn "DB error in db_get_image_file: $@";
        return "";
    }
    if ($thumb == 0) {
        $ext = ".thumb.100";
    } elsif ($thumb == 1) {
        $ext = ".thumb.640";
    } else {
        $ext = ".img";
    }
    $fullname = "/" . $dir . "/" . $id . $ext;
    if ($thumb == -1) {
        return $dir;
    }
    return $fullname;
}

# Rotate the width and height of an image
# TODO: "update photos set height, width, as select width , height..."

sub db_swap_geometry {
my($id) = @_;
my($qry,$res);

    return -1, if (!db_image_exists($id));
    $res = $Db_Conn->do( "UPDATE photos SET width = height, height = width, smallwidth = smallheight, smallheight = smallwidth, thumbwidth = thumbheight, thumbheight = thumbwidth WHERE imageid = $id");
    if (!defined($res)) {
        warn "db_swap_geometry: Error calling query";
        return -1;
    }
    return 1;
}

# Get the geometry of an image/thumb
# First arg is for thumb, 1 for medium, 2 for full size image
# returns list of (width, height, relative_filename).

sub db_get_image_geom {
my($id,$thumb) = @_;
my($w,$h,$tw,$th,$sw,$sh,$res,$qry);
my(@ret);

    ($w,$h,$tw,$th,$sw,$sh,$dir) = $Db_Conn->selectrow_array("SELECT width, height, thumbwidth, thumbheight, smallwidth, smallheight,directory FROM photos WHERE imageid = $id");
    if (!defined($w)) {
        warn "Error in db_get_image_geom";
        return -1;
    }
    return ($tw,$th, $dir . "/$id.thumb.100"), if ($thumb == 0);
    return ($w,$h, $dir . "/$id.thumb.640"), if ($thumb == 2);
    return ($sw,$sh, $dir . "/$id.img"), if ($thumb == 1);
    return -1;
}

# Delete an image from the database
# NOTE: Does NOT delete album references, or actual file!

sub db_delete_image {
my($imageid) = @_;
my ($res, $qry);

    if ($imageid !~ /^[0-9]+$/) {
        print "Error: invalid file specified for deletion!\n";
        return 0;
    }
    $res = $Db_Conn->do("DELETE FROM photos WHERE imageid = $imageid");
    if ($res > 1) {
        print "Warning: more than one file deleted!\n";
    }
    $Cache{'image_exists'}{$imageid} = 0;
    return 1;
}

# Delete an image from the repository
#
# this is what you really call from a script to delete an image.
#
# it calls all the necessary functions to fully remove the image from
# the system.
# argument is the imageid.

sub db_del_pic {
my($id) = @_;
my($dir, $file, $ref, $res);

    ($dir,$ref) = $Db_Conn->selectrow_array("SELECT directory,albumrefcount FROM photos WHERE imageid = $id");


    $res = repository_delete($dir, $id);
    if ($res != 1) {
        return -1;
    }

    if (!db_delete_image($id)) {
        return -1;
    }

    return 1;
}


# Convert shutter value to a string

sub shutter_str {
my($exp) = @_;
    if ($exp =~ /^\(([0-9]+),([0-9]+)\)$/) {
        return $1 . "/" . $2 . "s";
    }
}

# Get the caption for an image

sub db_img_caption {
my($id) = @_;
my($caption, $res, $qry);

    ($caption) = $Db_Conn->selectrow_array("SELECT caption FROM photos WHERE imageid = $id");
    $caption =~ s/__APOSTROPHE__/\'/g;
    return -1, unless (defined $caption);
    return $caption;
}

# Get the description for an image

sub db_img_descr {
my($id) = @_;
my($res, $qry, $descr);

    ($comment) = $Db_Conn->selectrow_array("SELECT comment FROM photos WHERE imageid = $id");
    return -1, unless (defined $comment);
    return $comment;
}

# Get the name/description for an image

sub db_id_to_nd {
my($table,$id) = @_;
my ($res, $qry);

    return $Db_Conn->selectrow_array("SELECT name,descr FROM $table WHERE id = $id");
}

# Get the id of an attribute from the name (eg for exposure types)

sub db_name_to_id {
my($table, $name) = @_;
my ($res,$qry);

    return $Db_Conn->selectrow_array("SELECT id FROM $table WHERE name = 'name'");
}

# Remove the directory elements from a full filename
#
# essentially 'basename' in perl.

sub strip_dir {
my($file) = @_;
my(@bits,$name)= ();
    return $file, if ($file !~ /[\/\\]/);
    $file =~ s/^[A-Z]:(.*)/$1/, if ($file =~ /^[A-Z]:/);
    @bits = split(/\//, $file);
    @bits = split(/\\/, $file);
    return pop(@bits);
}

# Gets the email address of the user
#
# argument is the username, returns email address as string

sub db_user_email {
my($user) = @_;
my($email);

    ($email) = $Db_Conn->selectrow_array("SELECT email FROM users WHERE name = '$user'");
    return $email;
}

# Gets the real name of the user
#
# argument is the username, returns real name as string

sub db_user_name {
my($user) = @_;
my($name);

    ($name) = $Db_Conn->selectrow_array("SELECT realname FROM users WHERE name = '$user'");
    return $name;
}


# Get the filename of an image
#
# argument is the imageid, returns the filename as stored in the db

sub db_id_to_file {
my($id) = @_;
my($qry);
my($res);
my($name);

    return -1, if ($id !~ /^[0-9]+$/);
    return $Db_Conn->selectrow_array("SELECT filename FROM photos WHERE imageid = $id");
}

# Get the imageid of a file from the name - opposite from above

sub db_file_to_id {
my($file) = @_;
my($qry);
my($res);
my($id);

    return -1, if ($file !~ /^[0-9a-zA-Z\._]+$/);
    return $Db_Conn->selectrow_array("SELECT imageid FROM photos WHERE filename = '$file'");
}

# Returns the date the image was inserted into the DB
# Argument is the imageid

sub db_get_insdate {
my($id) = @_;
my($res,$qry, $date);
    
    return $Db_Conn->selectrow_array("SELECT insertdate FROM photos WHERE imageid = $id");
}

# List the types in a table of options
#
# argument is the table name, returns a list of : separated rows

sub list_types {
my($table) = @_;
my($qry);
my($res);
my(@ret,@row) = ();

    return undef, if ($table !~ /[a-z]+/);
    $qry = $Db_Conn->prepare("SELECT * from $table");
    $qry->execute;
    while (@row = $qry->fetchrow_array) {
        push(@ret, join(':', @row));
    }
    return @ret;
}

# Insert an image into the database
#
# See add.cgi for full use - this function basically does the
# metadata insertion into the photos table.

sub database_insert {
my($i) = @_;
my($id, $qry, $res, $field,$expbit,$str,$t,$u);
my($CmdStuff,$dbvar,$val,$InsertDate,$Desc,$Owner,$Keywords);
my($idval);

    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    $idval++;
    eval {
        my $tmpval = "tmp.$$.$idval"; # identify unique image
        $qry = sprintf("INSERT INTO photos (filename, filesize, width, height,md5sum,owner) VALUES ('%s', %ld, %d, %d,'%s','%s')", $i->{'filename'}, $i->{'filesize'}, $i->{'width'}, $i->{'height'},$i->{'md5'},$i->{'owner'});
         $Db_Conn->do($qry);
        my $f = $i->{'filename'};
        my $md5 = $i->{'md5'};
        my $owner = $i->{'owner'};
        my $defborder = 1;
        $Keywords = $i->{'keywords'};
	$Descr = $i->{'description'};
	$Caption = $i->{'caption'}, if ($i->{'caption'} ne "");
        $CmdStuff = "";
	$CmdStuff .= "city = '" . $i->{'city'} . "', ";
	$CmdStuff .= "country = '" . $i->{'country'} . "', ";
        ($id) = $Db_Conn->selectrow_array("SELECT imageid FROM photos WHERE md5sum = '$md5' AND owner = '$owner'");
	my $options = UserOptions($owner);
	$defborder = $1, if ($options =~ /B([0-9]+)/);
        foreach $field (0..$#CmdLine) {
            $dbvar = $CmdLine[$field][2];
            $val = $CmdLine[$field][4];
            $str = $CmdLine[$field][3];
            next, if ($val eq "");
            if ($str == 1) {
                $CmdStuff .= "$dbvar = '$val', ";
            } else {
                $CmdStuff .= "$dbvar = $val, ";
            }
        }
       $str = "UPDATE photos SET albumrefcount = 0, format = %d, cameramake = '%s' , " .
            "cameramodel = '%s', createtm = %ld, lighting = '%s', " .
            "filmiso = %d, filmexposure = '%s', filmaperture = %f, " .
            "filmmetering = '%s', filmfoclen = %d, flash = '%s', " .
            "inserttm = %ld, whitebal = %d, " .
            $CmdStuff .
            "comment = '%s', keywords = '%s', border = $defborder WHERE imageid = $id";

        ($t,$u) = split(/\//, $i->{'exp'});
        $expbit = sprintf("(%d,%d)", $t, $u);
        $InsertDate = time();
        $i->{'date'} = $InsertDate, if ($i->{'date'} eq "");
        $i->{'flash'} = 'f', if ($i->{'flash'} eq "");
        $qry = sprintf($str, $i->{'format'}, $i->{'make'}, $i->{'model'},
            $i->{'createtm'}, $i->{'lightning'}, $i->{'iso'}, $expbit,
            $i->{'f'}, $i->{'metering'}, $i->{'fl'}, $i->{'flash'},
            $InsertDate, $i->{'whitebal'}, $Desc, $Keywords, $id);
	warn "datebase_insert: did $qry";
        $res = $Db_Conn->do($qry);
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "database_insert: Error inserting bloody photo! $@";
        $Db_Conn->rollback, unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return $id;
}

# Delete an image from the database, by filename (does not check albums!!)
#
# not really used at the moment - we generally deal with imageid, not filename

sub database_delete {
my ($file) = @_;
my($res,$qry);

    if ($file =~ /^.*\/([^\/]+)$/) {  # full filename specified
        $file = $1;
    }
    $Db_Conn->{AutoCommit} =0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        ($id) = $Db_Conn->selectrow_array("SELECT imageid FROM photos WHERE filename = '$file'");
        if ($id < 1) {
            DoError("", "database_delete: Hmm can't find image!");
        }
        $Db_Conn->do("DELETE FROM photos WHERE filename = '$file'");
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "datebase_delete: Error deleting photo! $@";
        $Db_Conn->rollback, unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return 1;
}

# Standard functions for dealing with albums.

my($TempAlb, $TempTop,$TempId);
my(%TempAlb);

# CreateAlbum()
#
# Create an album in the DB. Args are:
#
# - $name - Name of the album
# - $owner - Owner ofthe album
# - $descr - Textual description
# - $keywords - Search keywords to use
# - $level - master album in this album. 0 indicates a top level
#      album, anything else is the album number it sits in
# - $type - 0 for a regular album, 1 for a sub-album

sub CreateAlbum {
my($name,$owner,$descr, $keywords,$level,$type) = @_;
my($id,$qry,$res,$lastp,$albumname);
my($timenow);

    if ($name !~ /^[0-9A-Z_ +,-\.]+$/i) {
        DoError($owner, "Invalid album name: $name");
        return -1;
    }
    if ($owner !~ /^[0-9A-Z_\-]+$/i) {
        DoError($owner, "Invalid user name: $name");
        return -1;
    }
    if ($level > 0) {
        if (!AlbumExists($level)) {
            DoError($owner, "Cannot put sub-album into non existant album!");
            return -1;
        }
    }
    return -1, if ($type != 0 && $type != 1);
    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        $Db_Conn->do("LOCK TABLE albums IN SHARE ROW EXCLUSIVE MODE");
        $qry = "INSERT INTO albums(name, owner, parent, type) VALUES ('$name', '$owner', $level, $type)";
        $Db_Conn->do($qry);
        $qry = "SELECT id FROM albums WHERE name = '$name' AND owner = '$owner' AND parent = $level";
        ($id) = $Db_Conn->selectrow_array($qry);
        if ($id < 1) {
            DoError("", "Error in CreateAlbum() - id of new album < 1!");
        }
        # get last album at current level
        ($lastp) = $Db_Conn->selectrow_array ("SELECT id FROM albums WHERE next = 0 and owner = '$owner' and parent = $level");
        if ($lastp != 0) { # if there are albums in this level
            $Db_Conn->do("UPDATE albums SET next = $id WHERE id = $lastp");
            $Db_Conn->do("UPDATE albums SET prev = $lastp, next = 0 WHERE id = $id");
        } else { # first album at this level
            $Db_Conn->do("UPDATE albums SET next = 0, prev = 0 WHERE id = $id");
        }
        $albumname = "album_" . $id;
        $qry = <<EOF;
CREATE TABLE $albumname (
type    int2,
id  int4,
title   text,
description text,
created datetime,
accessed    datetime,
updated datetime,
pub bool,
accesses    int4,
keywords    text,
image1  int4,
image2  int4,
createtm int4,
accesstm int4,
updatetm int4);
EOF

        $Db_Conn->do($qry);
        $tm = time();
        $timenow = localtime($tm);
        $qry = "INSERT INTO $albumname VALUES (0, 0, '$name', '$descr', '$timenow', '$timenow', '$timenow', 'f', 0, '$keywords', 0, 0, $tm, $tm, $tm)";
        $Db_Conn->do($qry);
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "CreateAlbum: Error creating album! query was '$qry': $@";
        $Db_Conn->rollback, unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return $id;
}

# Add an album at a certin level
#
# argument is album id (already created with CreateAlbum) and parent album
#
# returns 1 on success, or -1 on failure

sub AlbumAppend {
my($id, $parent) = @_;
my($qry,$res);
my($last);

    return -1, if (!AlbumExists($id));
    $user = AlbumOwner($id);
    ($last) = $Db_Conn->selectrow_array( "SELECT id FROM albums WHERE owner = '$user' AND next = 0 AND parent = $parent");
    if (!defined($last) || AlbumAdj($last, 0, $id)) {
        $last = 0, unless (defined($last));
        return 1, if (AlbumAdj($id, 0, 0) && AlbumAdj($id, 1, $last));
    }
    return -1;
}


# Delete an album from the db
#
# argument is username (must match album owner) and album id
#
# twiddles the double-linked list to cleanly remove the album

sub DeleteAlbum {
my($owner, $album) = @_;
my($id,$prev,$next,$albumname,$qry,$res);

    if (!AlbumExists($owner, $album)) {
        DoError($owner, "No such album $album owned by $owner");
        return -1;
    }
    my ($type) = $Db_Conn->selectrow_array("SELECT type FROM albums WHERE id = $album");
    if ($type == 1) {
        my (@albums) = AlbumList($owner, $album);
        foreach my $alb (@albums) {
            my ($o,$n,$i) = split(/:/, $alb);
            if (DeleteAlbum($owner, $i) != 1) {
                DoError($owner, "Error deleting album tree $album!");
            }
        }
    } else {
        my (@pix) = AlbumListPix($album);
        foreach my $pic (@pix) {
            if (AlbumDelPix($album, $pic) == -1) {
                DoError($User, "Error deleting imageid $pic from album $album! Cannot continue.");
            }
        }
    }
    if ($album !~ /^[0-9]+$/) {
        $id = AlbumNameId($owner, $album);
    } else {
        $id = $album;
    }
    $albumname = "album_" . $id;
    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        $Db_Conn->do("LOCK TABLE albums IN SHARE ROW EXCLUSIVE MODE");
        $Db_Conn->do ("DROP TABLE $albumname");
        ($prev,$next) = $Db_Conn->selectrow_array("SELECT prev, next FROM albums WHERE id = $id");
        if ($next > 0) {
            $Db_Conn->do( "UPDATE albums SET prev = $prev WHERE id = $next");
        }
        if ($prev > 0) {
            $Db_Conn->do("UPDATE albums SET next = $next WHERE id = $prev");
        }
        $Db_Conn->do("DELETE FROM albums WHERE id = $id");
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "DeleteAlbum: Error deleting album! $@";
        $Db_Conn->rollback, unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return 1;
}

# Drop an album from a list of albums - opposite to above.
#
# argument is album id, and returns 1 on success, 0 on failure.
#
# note that if after you call this the album is left floating
# no-where, so this function is called from other functions normally
# which do other things with the dropped album such as deleting
# or moving.

sub AlbumDrop {
my($id) = @_;
my($res,$qry, $next, $prev);
$ret = 0;

    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        ($next,$prev) = $Db_Conn->selectrow_array ("SELECT next,prev FROM albums WHERE id = $id");
        if (AlbumAdj($prev, 0, $next)) {
            if (AlbumAdj($next, 1, $prev)) {
                $ret = 1;
            } else {
                AlbumAdj($prev, 0, $id);
                $ret = 0;
            }
        }
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "AlbumDrop: Error dropping album! $@";
        $Db_Conn->rollback, unless ($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return 0;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return $ret;
}

# Return an html list of album ancestors
#
# arguments are:
# - album id
# - name to show for album
# - whether to show this album
# - make links forced (with a url twiddle to avoid browser caching)

sub AlbumShowAncestor {
my($id,$name,$showit,$new,$Page) = @_;
my($nam,$str);
my(@alb);

    $str = "<h3><a href=${URI}>Top</a>&nbsp;&gt;&nbsp;";
    @alb = AlbumParents($id);
    if ($name eq "") {
        ($name) = AlbumIdName($id);
    }
    while ($nam = pop(@alb)) {
        my($name,$id) = split(/:/, $nam);
        $str .= ($id > 0) ?  "<a href=albumlist?level=$id>$name</a>" :
            "<a href=albumlist>$name</a>";
        $str .= " &gt;&nbsp;";
    }
	$Page = 1, if ($Page == 0);
    $str .= ($showit ? "<a href=" . ($new ? ForceUrl("albumshow?album=$id&page=$Page") : "albumshow?album=$id&page=$Page") . ">$name</a></h3>" : "$name</h3>");
    return $str;
}

# Get album id from album name/owner

sub AlbumNameId {
my ($owner, $album) = @_;
my($id,$qry,$res);

    return $Db_Conn->selectrow_array("SELECT id FROM albums WHERE name = '$album' AND owner = '$owner'");
}

# Get name/owner from album id

sub AlbumIdName {
my($id) = @_;
my($name, $owner, $res, $qry);
my(@bit);

    ($name,$owner) =  $Db_Conn->selectrow_array( "SELECT name, owner FROM albums WHERE id = $id");
	if ($name eq "" && $owner eq "") {
		DoError ("","Error: Album number $id does not exist.");
	}
	return ($name,$owner);
}

# Get the next/prev images in an album
#
# argument is album id and imageid,
# returns a list of (previous,next) imageid

sub AlbumNext {
my($Album, $id, $user) = @_;
my($qry, $res, $prev, $next);

    $name = "album_" . $Album;
    return $Db_Conn->selectrow_array ("SELECT image1, image2 FROM $name WHERE id = $id");
}


# Get a list of album parents to (users) top level
#
# argument is album id
# returns list of (album:id) up to top level.

sub AlbumParents {
my($alb) = @_;
my($qry,$res,$name);
my(@ret) = ();

    return (), if (!AlbumExists($alb));
# this block grabs the info for the current album and ditches it - we
# just want the parents.

    ($id) = $Db_Conn->selectrow_array("SELECT parent FROM albums WHERE id = $alb");
# iterate through the parents until we hit the top of the tree.

    while (1) {
        ($name,$parent) = $Db_Conn->selectrow_array("SELECT name,parent FROM albums WHERE id = $id");
        if ($parent == 0) {
            $id = $alb, if ($id < 1);
            push(@ret, "Albums:$id");
            return @ret;
        }
        push (@ret, "$name:$id");
        $id = $parent;
    }
}

# Get/set the immediate parent
# Argument is albumid, and parent to set (or 0 to retrieve)
# returns 1 on successful set, 0 on failed set, or parent id
# on successful query

sub AlbumParent {
my($id ,$parent) = @_;
my($qry, $res);

    if ($parent == -1) {
        return $Db_Conn->selectrow_array ("SELECT parent FROM albums WHERE id = $id");
    }
    if ($parent > 0) {
        ($qry) = $Db_Conn->selectrow_array ("SELECT type FROM albums WHERE id = $parent");
        if ($qry != 1) { # parent is not a sub-album
            return -1;
        }
    }
    if (AlbumDrop($id)) {
        return -1, if (!AlbumAppend($id, $parent));
        my ($qry) = "UPDATE albums SET parent = $parent WHERE id = $id";
        $Db_Conn->do($qry);
        return 1;
    }
    return -1;
}

# Get/set keywords for an album/image

sub AlbumKeywords {
my($id, $image, $keywords) = @_;
my($name,$kw,$res,$qry);

    $name = "album_" . $id;
    if ($keywords eq "") {
        if ($image > 0) {
            return $Db_Conn->selectrow_array("SELECT keywords FROM $name WHERE id = $image AND type = 1");
        } else {
            return $Db_Conn->selectrow_array("SELECT keywords FROM $name WHERE type = 0 ");
        }
    }
    if ($image > 0) {
        $Db_Conn->do("UPDATE $name SET keywords = '$keywords' WHERE id = $image AND type = 1");
    } else {
        $Db_Conn->do("UPDATE $name SET keywords = '$keywords' WHERE type = 0");
    }
    return 1;
}

# Determine if an album exists in the db
# 
# argument is user and album id
#
# returns 1 if exists, 0 otherwise

sub AlbumExists {
my($owner,$album) = @_;
my($id,$name,$qry,$res);

    if ($owner =~ /^[0-9]+$/) {
        $id = $owner;
    } else {
        if ($album =~ /^[0-9]+$/) {
            $id = $album;
        } else {
            $id = AlbumNameId($owner, $album);
        }
    }
    if ($id < 1) {
        return 0;
    }
    $name = "album_" . $id;
    ($res) = $Db_Conn->selectrow_array("SELECT title FROM $name WHERE type = 0");
    if ($res eq "") {
        return 0;
    }
    return 1;
}

# Set/Query whether an album is public
# 2nd arg is 0 for no, 1 for yes, undef for query only

sub AlbumPublic {
my($id, $public) = @_;
my($status,$name,$qry,$res);

    if ($id < 1) {
        return -1;
    }
    if (defined($public)) {
        $status = $Db_Conn->do("UPDATE albums SET pub = '$public' WHERE id = $id");
    } else {
        ($status) = $Db_Conn->selectrow_array("SELECT pub FROM albums WHERE id = $id");
    }
    return 1, if (defined($public));
    return $status;
}

# Update the number of accesses for album or image
# 3rd arg is null for album, or imageid for image
# 4th is 0 for read, 1 for update

sub UpdateAccess {
my($id,$image, $type) = @_;
my($qry,$res,$name,$thing,$count,$thetime);

    if ($image !~ /^[0-9]+$/) {
        DoError($owner, "UpdateAccess: arg 2 must be 0 or imageid (got $image)");
        return 0;
    }
    $name = "album_" . $id;
    if ($image == 0) {
        ($count) = $Db_Conn->selectrow_array("SELECT accesses FROM $name WHERE type = 0");
    } else {
        ($count) = $Db_Conn->selectrow_array("SELECT accesses FROM $name WHERE id = $image AND type = 1");
    }
    $count++;
    $thetime = time();
    if ($type == 1) {
        $thing = " updatetm = $thetime";
    } else {
        $thing = "accesses = $count";
    }
    if ($image == 0) {
        $Db_Conn->do("UPDATE $name SET $thing WHERE type = 0");
    } else {
        $Db_Conn->do("UPDATE $name SET $thing WHERE id = $image AND type = 1");
    }
    return 1;
}

# Get or set an album/image description
#
# leave $image zero to set album (returns 1 on success)
# leave $descr null to query

sub AlbumDescr {
my($id,$image,$descr) = @_;
my($img,$name,$qry,$res,$album);

    $name = "album_" . $id;
    if ($descr eq "") {
        if ($image == 0) {
            ($descr) = $Db_Conn->selectrow_array("SELECT description FROM $name WHERE type = 0");
        } else {
            ($descr) = $Db_Conn->selectrow_array("SELECT description FROM $name WHERE type = 1 AND id = $image");
        }
        return $descr;
    }
    if ($image == 0) {
        $Db_Conn->do("UPDATE $name SET description = '$descr' WHERE type = 0");
    } else {
        $Db_Conn->do("UPDATE $name SET description = '$descr' WHERE type = 1 AND id = $image");
    }
    return 1;
}

# Insert an image into the album
# puts it at the end
#
# arguments are albumid, imageid.
#
# returns 1 if image successfully added to album, or
# 0 otherwise. Does not allow duplicates.

sub AlbumAdd {
my($id, $image) = @_;
my($caption, $name, $qry, $res,$thetime, $descr, $prev_img);
    if ($id eq "") {
        return 0;
    }
    $name = "album_" . $id;
    if (AlbumImageIn($id, $image)) {
        return 0;
    }
    $caption = db_img_caption($image);
    $descr = db_img_descr($image);
    $thetime = localtime();
    $prev_img = AlbumLastImg($id);
    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;
    eval {
        $NoCommit = 1;
        $Db_Conn->do("INSERT INTO $name VALUES (1, $image, '$caption', '$descr', '$thetime', '$thetime', '$thetime', 'f', 0, '', $prev_img, 0)");
        AlbumIns($id, $prev_img, 1, 1, $image);
        if ($prev_img == 0 || $prev_img eq "0") {
            AlbumTitlePic($id, $image);
        }
        UpdateAccess($id,$image,1);
        UpdateAccess($id,0,1);
        db_update_img_refcount($image, 1);
        $Db_Conn->commit;
        $NoCommit = 0;
    };
    if ($@) {
        warn "Error in AlbumAdd: $@";
        $NoCommit = 1;
        $Db_Conn->rollback;
        $Db_Conn->{AutoCommit} = 1;
        $Db_Conn->{RaiseError} = 0;
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1;
    $Db_Conn->{RaiseError} = 0;
    return 1;
}

# Get or set the title of an image

sub AlbumTitle {
my($id, $image, $title) = @_;

my($tit,$name,$qry,$res);
    if (!AlbumExists($id)) {
        return -1;
    }
    if (!AlbumImageIn($id, $image)) {
        return -1;
    }
    $name = "album_" . $id;
    if ($image == 0) {
        if ($title !~ /^$/) {
            return $Db_Conn->selectrow_array( "UPDATE albums SET name = '$title' WHERE id = $id");
        } else {
            return $Db_Conn->selectrow_array("SELECT name FROM albums WHERE id = $id");
        }
    }
    if ($title eq "") {
        ($tit) = $Db_Conn->selectrow_array( "SELECT title FROM $name WHERE id = $image AND type = 1");
        if ($tit eq "") {
            $tit = db_img_caption($image);
        }
        return $tit;
    } else {
        if ($title !~ /^[0-9A-Z,\. ]+$/i) {
            return -1;
        }
        $res = $Db_Conn->do("UPDATE $name SET title = '$title' WHERE id = $id AND type = 0");
        if (!$res) {
            return -1;
        }
        return 1;
    }
}
        

# Get/set the title image
# $title is 0 for query, or an image id

sub AlbumTitlePic {
my($id, $title) = @_;
my($res,$qry,$tit,$name);

    $name = "album_" . $id;
    ($tit) = $Db_Conn->selectrow_array("SELECT image2 FROM $name WHERE type = 0");
    if ($title > 0) {
        $res = $Db_Conn->do("UPDATE $name SET image2 = $title WHERE type = 0");
        if (!$res) {
            return -1;
        }
        return 1;
    }
    return $tit;
}

# Returns the number of pictures in an album

sub AlbumNumPix {
my($id) = @_;
my($res,$qry,$name);
    $name = "album_" . $id;
    $qry = $Db_Conn->do("SELECT type FROM $name WHERE type = 1");
    return ($qry eq "0E0" ? 0 : $qry); # HMM..DBI returns '0E0' for zero :(
}

# Returns the first image in an album
# arg is album id, returns imageid

sub AlbumFirstPix {
my($id) = @_;
my($name, $qry, $res);

    $name = "album_" . $id;
    return $Db_Conn->selectrow_array("SELECT image1 FROM $name WHERE type = 0");
}

# Query if an image is in an album
# or if an album exists (for image = 0);

sub AlbumImageIn {
my ($id, $image) = @_;
my($name, $res,$qry);

    $name = "album_" . $id;
    $qry = $Db_Conn->do("SELECT type FROM $name WHERE type = 1 AND id = $image");
    if ($image == 0 && defined ($qry)) {
        return 1;
    }
    return $qry ne "0E0";
}

# Delete an image from the album

# args are albumid and imageid.
# returns 1 on success, 0 on failure. Also updates the double
# linked list. 
#
# this fucntion can be directly called from a script

sub AlbumDelPix {
my($id, $image) = @_;
my($name,$res,$qry,$prev,$next,$flim,$flim2,$nym,$nym2);

    $Db_Conn->{AutoCommit} = 0, unless $NoCommit;
    $Db_Conn->{RaiseError} = 1, unless $NoCommit;
    $name = "album_" . $id;
    if ($image == 0 || !AlbumImageIn($id, $image)) {
        return 0;
    }
# get old prev/next images
    $prev = AlbumIns($id, $image, 0, 0, 0);
    $next = AlbumIns($id, $image, 1, 0, 0);

# set the prev/next pix to each other
    eval {
        $Db_Conn->do("LOCK TABLE $name IN SHARE ROW EXCLUSIVE MODE");
        $flim = AlbumIns($id, $prev, 1, 1, $next);
        $flim2 = AlbumIns($id, $next, 0, 1, $prev);

        $Db_Conn->do("DELETE FROM $name WHERE id = $image AND type = 1");
        if (!db_update_img_refcount($image, -1)) {
            db_del_pic($image);
        } else {
            # do nothing
        }
        $Db_Conn->commit, unless ($NoCommit||$Db_Conn->{AutoCommit});
    };
    if ($@) {
        warn "Error in AlbumDelPix: $@";
        $Db_Conn->rollback;
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    UpdateAccess($id, 0, 1);
    return 1;
}

# Get access times
# 3rd arg is 0 for album, or image id
#
# returns array of (created, accessed, updated) times

sub AlbumGetAxs {
my($id, $image) = @_;
my($dt,$dt2,$dt3,$res,$qry,$name);

    $name = "album_" . $id;
    if ($image > 0 && !AlbumImageIn($id, $image)) {
        return 0;
    }
    if ($image == 0) {
        return $Db_Conn->selectrow_array("SELECT createtm, accesses, updatetm FROM $name WHERE type = 0");
    } else {
        return $Db_Conn->selectrow_array( "SELECT createtm, accesses, updatetm FROM $name WHERE type = 1 AND id = $image");
    }
}

# Return a list of pictures in an album
#
# args are album id, and 0 for public pix, 1 for private pix
#
# returns list of imageids

sub AlbumListPix {
my($id, $private) = @_;
my($priv,$name,$im1,$im2,$first,$res,$qry);
my(@pix) = ();
my(@row);
my(%Pix) = ();

    $name = "album_" . $id;
    if ($private) {
        $priv = "AND pub = 'f'";
    } else {
        $priv = "AND pub = 't'";
    }
    $qry = $Db_Conn->prepare("SELECT id, image1, image2 FROM $name WHERE type = 1 ORDER BY image1 ");
    $qry->execute;
    while (@row = $qry->fetchrow_array) {
        ($id, $im1, $im2) = @row;
        if ($im1 == 0) {
            $first = $id;
        }
        $Pix{$id} = $im2;
    }
    $id = $first;
    while ($id != 0) {
        push(@pix, $id);
        $id = $Pix{$id};
    }

    return @pix;
}

# Return list of albums
# $private = 1 to show private albums
# $level = -1 for all albums, -1 for non-lists, 1 for lists

sub AlbumList {
my($owner, $level) = @_;
my($par, $qry, $top, $id, $prev, $next, $name,$own,$type,$pub);
my(@ret,@row) = ();

    if ($owner !~ /^$/) {
        $own = "AND owner = '$owner'";
        $top = AlbumTop($owner);
    } else {
        $own = "";
        $top = 0;
    }
    if ($level > 1) {
        $par = "WHERE parent = $level ";
    } elsif ($level == 1) {
        $par = "WHERE type = 1 AND parent != 0";
        push(@ret, "bb:Top:$top");
    } elsif ($level == -1) {
        $par = "WHERE type = 0";
    } else {
        $par = "WHERE parent = $top";
    }
    undef %TempAlb;
    $qry = $Db_Conn->prepare("SELECT name, owner, id, prev, next, type, pub FROM albums $par $own");
    $qry->execute;
    while (@row = $qry->fetchrow_array() ) {
        ($name, $own,$id, $prev, $next,$type,$pub) = @row;
        if ($owner eq $own || $owner eq "") {
            push (@ret, "$own:$name:$id:$prev:$next:$type");
            $TempId = $id, if ($prev == 0 || $prev == $level);
            $TempAlb{$id} = "$next:$name:$type:$own:$pub";
        }
    }
    return @ret;
}

# Get the top level album for a user
# arg is username
# returns albumid for users top level album

sub AlbumTop {
my($user) = @_;

    return $Db_Conn->selectrow_array("SELECT id FROM albums WHERE parent = 0 AND owner = '$user' AND type = 1");
}

# Returns the next album in the list
#
# use this from scripts for an ordered list of albums.
# 
# args are:
# - album owner
# - 0 to reset pointer for next time we're called or 1 not to
# - album parent (level)

sub NextAlbum {
my($owner,$query,$level) = @_;
my($type,$cur,$name,$own,$pub);

    if (!defined($TempId)) {
        AlbumList($owner,$level);
    }
    if ($query == 1) {
        ($cur,$name,$type,$own,$pub) = split(/:/, $TempAlb{$TempId});
        return $TempId,$name,$type,$own,$pub;
    }
    $cur = $TempId;
    ($TempId,$name,$type,$own,$pub) = split(/:/, $TempAlb{$TempId});
    return $cur,$name,$type,$own,$pub;
}

# Move an album, 2nd arg is 0 for down, 1 for up

sub AlbumMove {
my($id, $dir) = @_;
my($qry, $res,$prev,$next,$nextn,$prevp);

    if (!AlbumExists($id)) {
        return -1;
    }
    $Db_Conn->{AutoCommit} = 0;
    $Db_Conn->{RaiseError} = 1;

    eval {
        $Db_Conn->do("LOCK TABLE albums IN SHARE ROW EXCLUSIVE MODE");
        $prev = AlbumAdj($id, 1, -1);
        $next = AlbumAdj($id, 0, -1);
        AlbumAdj($next, 1, $prev);
        AlbumAdj($prev, 0, $next);
        if ($dir == 0) {
            $nextn = AlbumAdj($next, 0, -1);
            AlbumAdj($id, 0, $nextn);
            AlbumAdj($nextn, 1, $id);
            AlbumAdj($next, 0, $id);
            AlbumAdj($id, 1, $next);
        } else {
            $prevp = AlbumAdj($prev, 1, -1);
            AlbumAdj($id, 0, $prev);
            AlbumAdj($prevp, 0, $id);
            AlbumAdj($prev, 1, $id);
            AlbumAdj($id, 1, $prevp);
        }
        $Db_Conn->commit, unless ($NoCommit);
    };
    if ($@) {
        warn "Error in AlbumMove: $@";
        $Db_Conn->rollback;
        $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless ($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless ($NoCommit);
    return 1;
}

# Query/set album adjacencies ## DOES NOT LOCK TRANSACTION - ASSUMED IN CALLER
# dir = 0 for next, 1 for prev
# new is new album or, undef to query;

sub AlbumAdj {
my($id, $dir, $new) = @_;
my($qry, $res,$where,$ret);

    if ($dir == 0) {
        $where = "next";
    } else {
        $where = "prev";
    }
    if ($id == 0) {
        return 1;
    }

    if ($new < 0) { # querying album list
        ($ret) = $Db_Conn->selectrow_array("SELECT $where FROM albums WHERE id = $id");
        return $ret;
    }
    my $str = "UPDATE albums SET $where = $new WHERE id = $id";
    $Db_Conn->do($str);
}

# Query the id of the last image in the album

sub AlbumLastImg {
my($id) = @_;
my($res,$qry,$img,$name);

    $name = "album_" . $id;
    ($img) = $Db_Conn->selectrow_array("SELECT id FROM $name WHERE type = 1 and image2 = 0");
    if ($img == 0) {
        $img = "0";
    }
    return $img;
}

# Move a pic up or down an album
# 4th arg is 0 for down, 1 for up

sub AlbumMovePic {
my($id, $image, $dir) = @_;
my($first,$last,$prevp,$firstn,$lastp,$prev,$next,$nextn);

    if (!AlbumImageIn($id, $image)) {
        return -1;
    }
    $Db_Conn->{AutoCommit} = 0, unless $NoCommit;
    $Db_Conn->{RaiseError} = 1, unless $NoCommit;
    my $name = "album_" . $id;
    eval {
        $Db_Conn->do("LOCK TABLE $name IN SHARE ROW EXCLUSIVE MODE");
        $prev = AlbumIns($id, $image, 0, 0, 0);
        $next = AlbumIns($id, $image, 1, 0, 0);
        AlbumIns($id, $image, 1, 1, $next);
        AlbumIns($id, $image, 0, 1, $prev);
        if ($dir == 0) { 
            if ($next == 0) { # Move img from bottom to top
                $first = AlbumFirstPix($id);
                $firstn = AlbumIns($id, $first, 1, 0, 0);
                $lastp = AlbumIns($id, $image, 0, 0, 0);
                AlbumIns($id, $image, 0, 1, 0);
                AlbumIns($id, $image, 1, 1, $firstn);
                AlbumIns($id, $first, 0, 1, $lastp);
                AlbumIns($id, $first, 1, 1, 0);
                AlbumIns($id, $prev, 1, 1, $first);
                AlbumIns($id, $firstn, 0, 1, $image);
                AlbumIns($id, 0, 1, 1, $image);
            } else {
                $nextn = AlbumIns($id, $next, 1, 0, 0);
                AlbumIns($id, $image, 1, 1, $nextn);
                AlbumIns($id, $nextn, 0, 1, $image);
                AlbumIns($id, $next, 1, 1, $image);
                AlbumIns($id, $image, 0, 1, $next);
                AlbumIns($id, $prev, 1, 1, $next);
                AlbumIns($id, $next, 0, 1, $prev);
            }
        } else {
            if ($prev == 0) { # move img from top to bottom
                $firstn = AlbumIns($id, $image, 1, 0, 0);
                $last = AlbumLastImg($id);
                $lastp = AlbumIns($id, $last, 0, 0, 0);
                AlbumIns($id, $image, 0, 1, $lastp);
                AlbumIns($id, $image, 1, 1, 0);
                AlbumIns($id, $last, 0, 1, 0);
                AlbumIns($id, $last, 1, 1, $firstn);
                AlbumIns($id, $firstn, 0, 1, $last);
                AlbumIns($id, $lastp, 1, 1, $image);
                AlbumIns($id, 0, 1, 1, $last);
            } else {
                $prevp = AlbumIns($id, $prev, 0, 0, 0);
                AlbumIns($id, $image, 1, 1, $prev);
                AlbumIns($id, $prevp, 1, 1, $image);
                AlbumIns($id, $prev, 0, 1, $image);
                AlbumIns($id, $image, 0, 1, $prevp);
                AlbumIns($id, $prev, 1, 1, $next);
                AlbumIns($id, $next, 0, 1, $prev);
            }
        }
        $Db_Conn->commit, unless($NoCommit);
    };
    if ($@) {
        warn "Error in AlbumMovePic: $@";
        $Db_Conn->rollback, unless($NoCommit);
        $Db_Conn->{AutoCommit} = 1, unless($NoCommit);
        $Db_Conn->{RaiseError} = 0, unless($NoCommit);
        return -1;
    }
    $Db_Conn->{AutoCommit} = 1, unless($NoCommit);
    $Db_Conn->{RaiseError} = 0, unless($NoCommit);
    UpdateAccess($id, $image, 1);
    return 1;
}


# Query or insert the next/previous image in an album
# 2rd arg is image number
# 3rd arg is 0 for prev or 1 for next
# 4th arg is 0 for query and 1 for set
# 5th is new value (if applicable).
#
### DOES NOT LOCK IN TRANSACTION - CALLER IS ASSUMED TO DO TRANSACTION
#
# returns -1 on error, or old value on set or current on query

sub AlbumIns {
my($id, $image, $type, $what, $newval) = @_;
my($res, $qry,$entype,$name,$where,$idbit,$old);

    $name = "album_" . $id;
    $entype = 1;
    $idbit = "id = $image AND ";
    if ($type == 1) {
        $where = "image2";
    } else {
        $where = "image1";
    }
    if ($image == 0) {
        $where = "image1";
        $entype = 0;
        $idbit = "";
    }
    ($old) = $Db_Conn->selectrow_array("SELECT $where FROM $name WHERE $idbit type = $entype");
    if ($what == 0) {
        return $old;
    }
# no response means we're setting an empty albums first image
    if ($image == 0) {
        if ($type == 0) { # cannot set previous image
            return 0;
        }
        $res = $Db_Conn->do("UPDATE $name SET image1 = $newval, image2 = $newval WHERE type = 0");
    } else {
        $res = $Db_Conn->do("UPDATE $name SET $where = $newval WHERE id = $image AND type = 1");
    }
    if ($res eq "0E0") {
        return -1;
    }
    return $old;
}

# Retrieve the album owner

sub AlbumOwner {
my($id) = @_;
my($res,$qry);

    return $Db_Conn->selectrow_array("SELECT owner FROM albums WHERE id = $id");
}

# ListAlbums: Generates an HTML listing of albums
# SettingsTable: Displays a table of photo settings,


#%Colours = {
#    'TableTitleFG' => '#000000',
#    'TableTitleBG' => '#ffffff',
#    'TableEntryNameFG' => '#000000',
#    'TableEntryNameBG' => '#ffffee',
#    'TableEntryVarFG' => '#000000',
#    'TableEntryVarBG' => '#ffffee',
#    'PageDefaultFG' => '#000000',
#    'PageDefaultBG' => '#ffffee',
#    'PageLink' => '#000000',
#    'PageVLink' => '#000000',
#    'NavTabFG' => '#ffffee',
#    'NavTabBG' => '#336666',
#};
    

# Array of what to display from the DB
#
# [db_field, description, convert?, editable?, string?, subject?,type]
#
# type is 0 for raw string/number, 1 for boolean, 2 for date
@DisplayedInfo = (
    ["filename", "Filename", 0, 1, 1, 1, 0],
    ["filesize", "File Size", 0, 0, 0, 0, 0],
    ["width", "Width", 0, 0, 0, 0, 0],
    ["height", "Height", 0, 0, 0, 0, 0],
    ["format", "MimeType", 1, 0, 0, 0, 0],
    ["origin", "Image source", 1, 1, 0, 1, 0],
    ["cameramake", "Cam Make", 0, 1, 1, 0, 0],
    ["cameramodel", "Cam Model", 0, 1, 1, 0, 0],
    ["createtm", "Created", 0, 1, 1, 1, 2],
    ["inserttm", "Inserted on", 0, 0, 1, 0, 2],
    ["subtype", "Subject type", 1, 1, 0, 1, 0],
    ["status", "Image status", 1, 1, 0, 1, 0],
    ["copyright", "Copyright", 0, 1, 1, 1, 0],
    ["lighting", "Lighting", 1, 1, 0, 1, 0],
    ["filmiso", "Film ISO", 0, 1, 0, 0, 0],
    ["filmaperture", "Aperture", 0, 1, 0, 0, 0],
    ["filmexposure", "Shutter", 0, 1, 1, 0, 0],
    ["filmmetering", "Metering", 0, 1, 0, 0, 0],
    ["filmfoclen", "Focal Length", 0, 1, 0, 0, 0],
    ["flash", "Flash used?", 0, 1, 1, 0, 1],
    ["whitebal", "White balance", 0, 1, 0, 0, 0],
    ["expmode", "Exposure mode", 0, 1, 0, 0, 0],
    ["country", "Country", 0, 1, 1, 1, 0],
    ["city", "City", 0, 1, 1, 1, 0],
    ["comment", "Description", 0, 1, 1, 1, 0],
    ["keywords", "Keywords", 0, 1, 1, 1, 0],
    ["ownerrating", "Owners rating", 0, 1, 0, 1, 0],
#   ["pub", "Public", 0, 1, 1, 1],
    ["caption", "Caption", 0, 1, 1, 1, 0]);

# Generates HTML for displaying an image/thumb file

sub ShowImage {
my($image,$thumb, $cap, $selbox, $album, $page) = @_;
my($w,$h,$id,$qry,$res,$file,$caption,$descr,$imgfile);
my($tw,$th,$selstr,$albit,$border);

    if ($image =~ /^[0-9]+$/) {
        $id = $image;
    } else {
        return "<td>&nbsp;</td>";
    }

    ($file,$descr,$caption,$w,$h,$tw,$th,$dir,$b) = $Db_Conn->selectrow_array("SELECT filename,comment,caption,width,height,thumbwidth,thumbheight,directory,border FROM photos WHERE imageid = $id");

    return "<td>&nbsp;</td>", if ($dir eq "");
    $caption ||= $file;
    $caption = $cap, if ($cap !~ /^$/);
    $caption =~ s/__APOSTROPHE__/\'/g;
    $descr ||= $file;
    $selstr = ($selbox == 1) ? "<center><input type=checkbox name=check_$id value=1><br></center>" : "";
    $albit = ($album > 0) ? "&alb=$album" : "";
    $pagebit = ($page > 0) ? "&page=$page" : "";
    if ($thumb) {
    if (($ENV{REMOTE_ADDR} eq $ENV{SERVER_ADDR} 
		|| $ENV{REMOTE_ADDR} eq "127.0.0.1") && $UseFastLocalImages) {
	$imgfile = "file:" . $repository . "$dir/$id.thumb.100";
    } else {
        $imgfile = $Repos_Url . "$dir/$id.thumb.100";
    }
    return <<EOF;
<td align=center>

<table border=0 cellpadding=0 cellspacing=0>
<tr>
    <td><img name=bdr0 src=$IcoUrl/border$b-0.gif height=6 width=6></td>
    <td><img name=bdr1 src=$IcoUrl/border$b-1.gif height=6 width=$tw></td>
    <td><img name=bdr2 src=$IcoUrl/border$b-2.gif height=6 width=6></td>
</tr>
<tr>
    <td><img name=bdr3 src=$IcoUrl/border$b-3.gif border=0 width=6 height=$th></td>
    <td><a href=image?id=$id$albit$pagebit><img border=0 src=$imgfile width=$tw height=$th alt="$caption" ></a></td>
    <td><img name=bdr4 src=$IcoUrl/border$b-4.gif border=0 width=6 height=$th></td>
</tr>
<tr>
    <td><img name=bdr5 src=$IcoUrl/border$b-5.gif width=6 height=6></td>
    <td><img name=bdr6 src=$IcoUrl/border$b-6.gif border=0 width=$tw height=6></td>
    <td><img name=bdr7 src=$IcoUrl/border$b-7.gif width=6 height=6></td>
</tr>
</table>
    $selstr
    $caption
</td>
EOF
    } else {
    if (($ENV{REMOTE_ADDR} eq $ENV{SERVER_ADDR} 
		|| $ENV{REMOTE_ADDR} eq "127.0.0.1") && $UseFastLocalImages) {
	$imgfile = "file:" . $repository . "$dir/$id.img";
    } else {
        $imgfile = $Repos_Url . "$dir/$id.img";
    }
        return <<EOF;
<td>
    <center>
    <img src=$imgfile width=$w height=$h alt="$alt">
    </a><br>
    $descr
    </center>
</td>
EOF
    }
}

# Given an imageid, the width and height, it returns the html for
# a bordered image.

sub ImgBorder {
my($imgfil,$width,$height,$b) = @_;

print <<EOF;
<table border=0 cellpadding=0 cellspacing=0>
<tr>
    <td><img name=bdr0 src=$IcoUrl/border$b-0.gif height=16 width=16></td>
    <td><img name=bdr1 src=$IcoUrl/border$b-1.gif height=16 width=$width></td>
    <td><img name=bdr2 src=$IcoUrl/border$b-2.gif height=16 width=16></td>
</tr>
<tr>
    <td><img name=bdr3 src=$IcoUrl/border$b-3.gif border=0 width=16 height=$height></td>
    <td><img src=$imgfil alt="$caption" width=$width height=$height></td>
    <td><img name=bdr4 src=$IcoUrl/border$b-4.gif border=0 width=16 height=$height></td>
</tr>
<tr>
    <td><img name=bdr5 src=$IcoUrl/border$b-5.gif border=0 width=16 height=16></td>
    <td><img name=bdr6 src=$IcoUrl/border$b-6.gif border=0 width=$width height=16></td>
    <td><img name=bdr7 src=$IcoUrl/border$b-7.gif width=16 height=16></td>
</tr>
</table>
EOF
}

# Display a quick image search box

sub QuickSearch {
my($term) = @_;

return <<EOF;
<table align=center border=0 cellspacing=0 bgcolor=$TableHighBG>
<tr bgcolor=$TableLowBG><th><font color=$TextLoTable>Quick Search</th>
<th align=right><a href=search><small><font color=$TextLoTable>Full Search</a>
</font></small></th></tr>
<td colspan=2><font color=$TextTable>
<form method=get action=search onSubmit="return OnUpload()">
Search for: 
<input type=text name=terms size=15 value="$term">
<input type=submit value="Go">
</td>
</tr></table></form>
EOF
}

# prints the header for most pages.
#
# args are:
# - username
# - page title
# - extra tags for the <body> attribute
# - page section header
# - 0 for full header, 1 for slim header

sub PrintHeader {
my($user,$Title,$body,$section,$slim) = @_;
my($Loggedin, $Settings, $Logout);

    print <<EOF;
Content-type: text/html

<html>
EOF
#open (STYLE, "style.css");
#while (<STYLE>) {
#    print $_;
#}
#close STYLE;
print "<title>$Title</title>\n";

if (0) {
    print <<EOF;

<body text=$TextNorm link=#000000 vlink=#000000 alink=#aaffaa bgcolor=$BGNorm $body>

EOF

return;

}

if ($user ne "nobody") {
    $Loggedin = "<small>Logged in as: <b>$user</b></small>";
    $Settings = "<a href=config><font color=$TextTable face=\"arial,helvetica\"><small>Your settings</font></a>";
    $Settings .= "&nbsp;|&nbsp;<a href=admin><font color=$TextTable size=-2>(Admin)</font></a>", if (UserLevel($user) eq "a");
    $Logout = "<a href=logout><font color=$TextTable face=\"arial,helvetica\">LOGOUT</small></font></a>"
} else {
    $Loggedin = "Not logged in<br><a href=login>(Login)</a>";
    $Settings = "&nbsp;";
    $Logout = "&nbsp;";
}

print <<EOF;

<!-- BEGIN HEADER -->
<body text=$TextNorm link=#000000 vlink=#000000 alink=#aaffaa bgcolor=$BGNorm $body>
EOF

print <<EOF, unless ($slim);
<table align=center bgcolor=$TableHighBG border=0 width=90% cellspacing=0 cellpadding=2>
<tr>
    <td align=left rowspan=2>
        <a href=${URI}>
        <img src=$IcoUrl/photoshelf.gif border=0 width=256 height=36></a>
    </td>
    <td align=left rowspan=2 valign=middle>
        <font color=$TextTable face="times,times new roman">
        <h2>$section</h2>
        </font>
    </td>
    <td align=right valign=bottom>
        <font color=$TextTable face="arial,helvetica" size=-1>
        $Loggedin
    </td>
</tr>
<tr>
    <td align=right>
        $Settings<br>
        $Logout
    </td>
</tr>
</table>
<!-- END HEADER -->
EOF

}

# prints the standard html page footer for the system. Called at
# the end of every script.

sub PrintFooter {
    print <<EOF;

<!-- BEGIN FOOTER -->
<center>
<table bgcolor=$TableHighBG border=0 width=90% cellspacing=0 cellpadding=2>
<tr>
    <td align=left>
        <font color=$TextTable>
        <small>Generated by <a href=http://photoshelf.sourceforge.net/><font color=$$TextTable>PhotoShelf v1.11</font></a></small>
        </font>
    </td>
    <td align=right>
        <font color=$TextTable>
        <small>All image copyrights owned by their respective owners.</small>
        </font>
    </td>
</tr>
</table>
</center>
</html>
<!-- END FOOTER -->

EOF

}

# given an imageid and angle to rotate, physically rotates the
# images in the repository and updates the geomtries in the
# database.
#
# called from a script directly

sub image_rotate {
my($id,$angle) = @_;
my(@files);
my($i,$reposfile,$filen,$tempf);

    return, if ($angle !~ /^[0-9]+$/);
    foreach $i (2) {
        $reposfile = db_get_image_file($id, $i);
        $filen = $repository . $reposfile;
        $tempf = $repository . $reposfile . $$;
        system "/usr/bin/jpegtran -copy all -rotate $angle $filen > $tempf";
        system "/bin/mv -f $tempf $filen";
    }
    $reposfile = db_get_image_file($id, 2);
    $filen = $repository . $reposfile;

# work around for a bug in jpegtran
# jpegtran distorts the image when rotating small images
    my ($sx,$sy,$tx,$ty) = resize_image($filen,$id, 0);
    
    db_swap_geometry($id), unless ($angle == 180);
    $Db_Conn->do("UPDATE photos SET smallwidth = $sx, smallheight=$sy, thumbwidth = $tx, thumbheight = $ty WHERE imageid = $id");
}

# given a date (unix epoch format), returns a string of the
# form '1 day ago', '3 weeks ago', etc compared to the current
# time.

sub DateCmp {
my($date) = @_;
my($y,$m,$w,$d,$h,$min, $dt, $delta, $str);

my($da,$dte,$err);

    $dt =time();
    $diff = $dt - $date;
    if ($diff >= 31536000) {
        $y = int($diff / 31536000);
        $str = "$y year" . ($y > 1 ? "s" : "") . " ago";
    } elsif ($diff >= 2592000) {
        $m = int($diff / 2592000);
        $str = "$m month" . ($m > 1 ? "s" : "") . " ago";
    } elsif ($diff >= 86400) {
        $d = int($diff / 86400);
        $str = "$d day" . ($d > 1 ? "s" : "") .  " ago";
    } elsif ($diff >= 3600) {
        $h = int($diff / 3600);
        $str = "$h hour" . ($h > 1 ? "s" : "") .  " ago";
    } elsif ($diff > 0) {
        $min = int($diff / 60);
        $str = "$min min" . ($min > 1 ? "s" : "") . " ago";
    } else {
        $str = "Now";
    }
    return $str;
}

#BLUMFRUB

$thumbSize = 80;

# insert the file into the repository.
# args are filename, imageid of the image, and optionally the
# imageid to replace in the db
# if $id > 0, then just replace the image for $id

sub repository_insert {
my ($file, $serial,$id) = @_;
my($geom) = "";
my $dir;

    if (! -f $file) {
        print "Error - $file not found for repository insert!\n";
        return 0;
    }
    if ($id > 0) {
        $dir = db_get_image_file($serial, -1);
        my ($w,$h) = get_image_geom($file);
        $geom = ", width = $w, height = $h";
    } else {
        $dir = db_add_dir_file();
    }
    select STDERR;
    if (! -f "$repository/$dir/$serial.img.orig" && -f "$repository/$dir/$serial.img") {
        rename ("$repository/$dir/$serial.img", "$repository/$dir/$serial.img.orig") or warn "Error cannot rename file id $serial: $!";
    }
    system "/bin/cp -f $file $repository/$dir/$serial.img";
    ($thumbBX,$thumbBY,$thumbX,$thumbY) = resize_image("$repository/$dir/$serial.img", $serial);
    chmod 0666, "$repository/$dir/$serial.img" or warn "Cannot chmod $repository/$dir/$serial.img: $!";
    select STDOUT;
    $qry = sprintf("UPDATE photos SET smallwidth = %d, smallheight = %d, ".
                    "thumbwidth = %d, thumbheight = %d $geom ".
                    "WHERE imageid = %d", $thumbBX,$thumbBY,
                        $thumbX, $thumbY, $serial);
    $Db_Conn->do($qry);
    return $dir;
}

# delete an image from the repository.
#
# args are directory in repository (as in the db), and the
# imageid. returns 0 on failure, 1 on success
#
# does not touch the photos table

sub repository_delete {
my($dir, $serial) = @_;
my (@deletees) = ();

    $fullname = $repository . "/" .  $dir . "/" . $serial;

    foreach $ext (".img", ".thumb.640", ".thumb.100") {
        if (! -f $fullname . $ext) {
            warn "repository_delete: Warning: Cannot find $fullname.$ext in repository!\n";
        }
    }
    if (db_del_dir_file($dir) != 1) {
        warn "repository_delete: Error updating database for $dir\n";
        return 0;
    }
    foreach $ext (".img", ".thumb.640", ".thumb.100") {
        push (@deletees, $fullname . $ext);
    }
    $res = unlink @deletees;
    if ($res != 3) {
        warn "repository_delete: Error deleting $fullname!\n";
    }
    return 1;
}

# Resize from original jpeg.
# 1st arg is actual filename
# 2nd is image serial number
# 3rd is 0 for all, 1 for thumb only

sub resize_image {
my($file,$serial, $which) = @_;

    $| = 0;
    my $dir = $1, if ($file =~ /^(.*)\/[^\/]*$/);
    my ($thumb) = Image::Magick->new;
    my ($i) = $thumb->Read($file);
    my($x, $y) = $thumb->Get('width', 'height');

# Write the 640x480(ish) image

    my($scale);
    my($thumbX);
    my($thumbY);
    my($thumbBX);
    my($thumbBY);
    if ($which != 1) {
        if ($x > 640 || $y > 480) {
            if ($x > $y) {
                $scale = 640 / $x;
                $thumbBX = 640;
                $thumbBY = int($y * $scale);
            } else {
                $scale = 480 / $y;
                $thumbBY = 480;
                $thumbBX = int($x * $scale);
            }
            $res = $thumb->Scale(width=>$thumbBX, height=>$thumbBY);
            warn "resize_image: $res" if "$res";
        } else {
            $thumbBX = $x;
            $thumbBY = $y;
        }

        my($thumbFile) = "$dir/$serial.thumb.640";
        open (THUMB, ">$thumbFile") or warn "resize_image: Cannot open $thumbFile: $!";
        $res = $thumb->Write(file=>THUMB, filename=>$thumbFile, magick=>'jpeg');
        close THUMB;
        warn "resize_image: $res" if "$res";
        chmod 0666, $thumbFile or warn "resize_image: cannot chmod $thumbFile: $!";
    }

# Now write the thumbnail image

    if ($x > $y) {
        $scale = $thumbSize / $x;
        $thumbX = $thumbSize;
        $thumbY = int($y * $scale);
    } else {
        $scale = $thumbSize / $y;
        $thumbY = $thumbSize;
        $thumbX = int($x * $scale);
    }

    $res = $thumb->Scale(width=>$thumbX, height=>$thumbY);
    $thumbFile = "$dir/$serial.thumb.100";
    warn "resize_image: $res" if "$res";
    unlink $thumbFile;
    open (THUMB, ">$thumbFile") or warn "resize_image: Cannot open $thumbFile: $!";
    $res = $thumb->Write(file=>THUMB, filename=>$thumbFile, magick=>'jpeg');
    close THUMB;
    warn "resize_image: $res" if "$res";
    chmod 0666, $thumbFile or warn "resize_image: cannot chmod $thumbFile: $!";

    return ($thumbBX,$thumbBY,$thumbX,$thumbY);
}

#
# Restores the original file from a modified one.
#
sub img_restore_orig {
my($id) = @_;
my($file,$file1,$file2,);

    $file = $repository . db_get_image_file($id, 2);
    return, unless (-f "$file.orig");
    $file1 = $repository . db_get_image_file($id, 1);
    $file2 = $repository . db_get_image_file($id, 0);
    unlink("$file1", "$file2", "$file");
    rename ("$file.orig", "$file") or warn "Couldnt rename $file.orig to $file: $!";
    resize_image($file,$id,2);
}


sub img_normalize {
my($id) = @_;
my($thumb,$file,$file1,$file2,$res,$i);

    $thumb = Image::Magick->new;
    $file = $repository . db_get_image_file($id,2);
    $file1 = $repository . db_get_image_file($id,1);
    $file2 = $repository . db_get_image_file($id,0);
    $i = $thumb->Read($file);
    if (! -f $file && ! -f "$file.orig") {
        DoError($User, "Cannot normalize - full size file missing and no backup");
    }
    unlink("$file1", "$file2");
    $res = $thumb->Normalize();
    if (! -f "$file.orig") {
        rename ("$file", "$file.orig") or warn "Couldnt rename $file to $file.orig: $!";
        if (! -f "$file.orig") {
            DoError($User, "Error normalizing image - see server error log");
        }
    } else {
        unlink ("$file");
    }
    open (THUMB, ">$file") or warn "resize_image: Cannot open $thumbFile: $!";
    $res = $thumb->Write(file=>THUMB, filename=>$thumbFile, magick=>'jpeg', quality=>85);
    close THUMB;
    resize_image($file, $id, 2);
}

# Given a fileid, return a filehandle to the repository file
# second arg is 0 for thumb, 1 for 640ish, 2 for full

sub db_get_image_fh {
my($id,$thumb) = @_;
my($dir,$qry,$res,$ext,$fullname);

    ($dir) = $Db_Conn->selectrow_array("SELECT directory FROM photos WHERE imageid = $id");
    if ($thumb == 0) {
        $ext = ".thumb.100";
    } elsif ($thumb == 1) {
        $ext = ".thumb.640";
    } else {
        $ext = ".img";
    }
    $fullname = $repository . "/" . $dir . "/" . $id . $ext;
    open(FILE, "$fullname") or DoError("", "Cannot open repository file $fullname: $!");
    return *FILE;
}

# get the file size for an image.
#
# args are imageid, and 0 for small thumb, 1 for 640pixel thumb, 2
# for full size image.
#
# returns size in bytes

sub db_get_image_size {
# thumb = 0 for thumb, 1 for medium, 2 for full
my($id,$thumb) = @_;
my($res,$qry, $serial,$dir,$ext,$fullname);

    ($serial,$dir) = $Db_Conn->selectrow_array("SELECT directory FROM photos WHERE imageid = $id");
    if ($thumb == 0) {
        $ext = ".thumb.100";
    } elsif ($thumb == 2) {
        $ext = ".img";
    } elsif ($thumb == 1) {
        $ext = ".thumb.640";
    }
    $fullname = $repository . "/" . $dir . "/" . $serial . $ext;
    return (stat($fullname))[7];
}

# Generate an error page, with the correct header and footer.

sub DoError {
my($user,$msg) = @_;
    PrintHeader($user,"Error", "", "Error");
    print "<center><br>$msg<br></center>";
    PrintFooter();
    warn ("PhotoShelf error in $ENV{REQUEST_URI}: $msg");
    exit(0);
}
    
# Authorisation system for photoshelf.
#
# - Request authorisation if user is unknown
# - Set cookies for prefs, auth (optional), etc
# - Fetch cookies for auth, prefs
#
# db auth types are:
# 'a' - admin, access everything
# 'u' - regular user
# ???

# return array of cookies

sub get_cookies {
        map { split /=/, $_, 2 } split /; /, $ENV{'HTTP_COOKIE'} ;
}

# type is 1 for anon ok but login, 0 for login mandatory, and
# -1 for login or anon ok, but no login screen

sub Userverify {
my($q,$type) = @_;
my($tm,$usr,$user,$pass,$host,$server,$realurl,$url);
my($sessid,$sesstime,$sesid);

    $url = $ENV{'REQUEST_URI'};
    $host = $ENV{'HTTP_HOST'};
    $server = $ENV{'SERVER_NAME'};
    ($first,@parts) = split(/\./, $server);
    $domain = join('.', @parts);
#   if ($host ne $server) {
#       print "Location: http://" . $server . $url . "\n\n";
#       exit(0);
#   }
    my %cookies = get_cookies();
    $session = $cookies{'sessid'};
    $usr = $cookies{'usrid'};
    $user = $q->param('user');
    $pass = $q->param('pwd');
    $tm = time();
    return $usr, if ($usr eq "guest"); # unlimited guest logins
    goto FLUM, if ($user ne "");
    if ($user eq "" && $session !~ /^$/ && $usr !~ /^$/) {
        ($sessid,$sesstime) = $Db_Conn->selectrow_array("SELECT sessionid, sesstime FROM users WHERE name = '$usr'");
        if (!defined($sessid)) {
            if ($type == -1) {
                return "nobody";
            } 
            goto FLUM;
        } 
        if ($sessid eq $session && ($tm - $sesstime < 3600) && 
        $sessid > 0 && $sesstime > 0) {
            $Db_Conn->do("UPDATE users SET sesstime = '$tm' WHERE name = '$usr'");
            return $usr;
        }
        if ($type != -1) {
            goto FLUM;
        } else {
            return "nobody";
        }
    }
FLUM:
    if (!CheckPw($user, $pass)) {
        if ($type == -1 || $type == 1) {
            return "nobody";
        }
        AskLogin($url,($user !~ /^$/));
        exit(0);
    }
    srand($tm);
    $sesid = int(rand(10240000));
    $Db_Conn->do("UPDATE users SET sessionid = $sesid, sesstime = $tm WHERE name = '$user'");
    my $album = AlbumTop($user);
    print "Set-Cookie: sessid=$sesid; path=/;\n";
    print "Set-Cookie: usrid=$user; path=/;\n";
    print "Location: " . ForceUrl("albumlist?level=$album") . "\n";
    print "Expires: Wed, 1 Jan 1970 00:00:00 GMT\n";
    print "Content-type: text/html\n\n";
    exit(0);
}

# given username and password, determines whether authorisation
# succeeded.
sub CheckPw {
my($user,$pass) = @_;
my($qry,$res);

    db_connect();
    $qry = $Db_Conn->do("SELECT * FROM users WHERE name = '$user' and cryptpw = '$pass'");
    if ($qry == 1) {
        return 1;
    }
    return 0;
}
# prints the user login page
sub AskLogin {
my($url,$wrong) = @_;

PrintHeader("nobody", "Login", "", "Login");
    print <<EOF;

<title>PhotoShelf: User Login</title>
<body bgcolor=$BGNorm text=$Textnorm>
EOF

if ($wrong) {
    print <<EOF;
<font color=#aa0000>Login incorrect. Try again.</font><br>
EOF

}

print <<EOF;
<center>
<h2>Please Login</h2>
<font size=-1 color=#aa0000>You must have cookies enabled!</font>
<table>
<form method=post action=login>
<tr><td>Username:</td><td><input type=text name=user></td></tr>
<tr><td>Password:</td><td><input type=password name=pwd></td></tr>
<tr><td colspan=2><input type=submit value="Login"></td></tr>
</table>
<input type=hidden name=realurl value="$url">
</form>
</center>
EOF
;
PrintFooter();

}

# logs out the user - removes the session id from the database and
# returns a cookie deleting the users cookie
sub UserLogout {
my($q) = @_;
my($res,$qry);

    $user = Userverify($q,-1);
    my %cookies = get_cookies();
    my $sessid = $cookies{'sessid'};
    $Db_Conn->do("UPDATE users SET sessionid = 0, sesstime = 0 WHERE name = '$user'");
    print "Set-Cookie: sessid=$sessid; expires=Thursday, 01-Jan-70 10:00:00 GMT\n";
    print "Set-Cookie: usrid=$user; expires=Thursday, 01-Jan-70 10:00:00 GMT\n";
    print "Location: ${URI}\n\n";
    exit(0);
}

# returns the users slideshow interval as inthe db

sub UserInterval {
my($user) = @_;

    return 10, if ($user eq "nobody");
    return $Db_Conn->selectrow_array("SELECT slideinterval FROM users WHERE name = '$user'");
}

# returns the users options as in his/her prefs

sub UserOptions {
my($user) = @_;
    return $Db_Conn->selectrow_array("SELECT options FROM users WHERE name = '$user'");
}

# returns the user's admin level

sub UserLevel {
my($user) = @_;
    return $Db_Conn->selectrow_array("SELECT privs FROM users WHERE name = '$user'");
}

#      Query image files for various bits of useful information
#      that we want, such as geometry, comments and things
#      stored in an EXIF file.
#
# 1. Extract image into variable
# 2. Open database, verify file exists.
# 3. Check each value
# 4. If ok, insert into DB (or leave as default)

sub get_image_geom {
my($file) = @_;

    $info = image_info("$file");
    return dim($info);
}

sub get_image_info {
my ($file) = @_;
my($info) = "";
my(%Image) = ();
my ($top, $time);

if (! -f $file) {
    die "Cannot open $file: $!";
}

$info = image_info("$file");

($Image->{'width'}, $Image->{'height'}) = dim($info);

$Image->{'format'} = $info->{'file_media_type'};

$Image->{'filename'} = strip_dir($file);
$Image->{'filesize'} = (stat($file))[7];

# Check ISO

$Image->{'iso'} = $info->{'ISOSpeedRatings'};
if ($Image->{'iso'} < 20) { # 20 minimum iso rating, else its a dodge
    $Image->{'iso'} = 0;
}

$Image->{'make'} = $info->{'Make'};
$Image->{'model'} = $info->{'Model'};

if ($Image->{'make'} eq "") {
    goto PRINT;
}

# Check exposure time

if (defined($info->{'ExposureTime'})) {
    @I_exp = $info->{'ExposureTime'};
    $top = $I_exp[0][1] / $I_exp[0][0], unless ($I_exp[0][1] == 0);
} elsif (defined($info->{'ShutterSpeedValue'})) {
    @frac = $info->{'ShutterSpeedValue'};
    if ($frac[0][1] == 0) {
        $time = $frac[0];
    } else {
        $time = $frac[0][0] / $frac[0][1];
    }
    $top = int (0.5 + exp($time * log(2)));
}

$Image->{'exp'} = "1/" . int($top);

# F-stop

if (defined($info->{'FNumber'})) {
    @fn = $info->{'FNumber'};
} elsif (defined($info->{'ApertureValue'})) {
    @fn = $info->{'ApertureValue'};
}
if ($fn[0][1] == 0) {
    $Image->{'f'} = $fn[0];
} else {
    $Image->{'f'} = $fn[0][0] / $fn[0][1];
}

# Focal length

@fl = $info->{'FocalLength'};
if (defined($info->{'FocalLength'})) {
    if ($fl[0][1] == 0) {
        $Image->{'fl'} = $fl[0] * 5;
    } else {
        $Image->{'fl'} = 5*$fl[0][0] / $fl[0][1], unless ($fl[0][1] == 0);
    }
}

# Metering

$Image->{'metering'} = $info->{'MeteringMode'};
if ($Image->{'metering'} !~ /^[0-9]+/) {
    $met = $Image->{'metering'};
    ($Image->{'metering'}) = $Db_Conn->selectrow_array("SELECT id FROM metering WHERE descr = '$met'");
}

# Exposure mode

$Image->{'expmode'} = $info->{'ExposureProgram'};

# White balance

$Image->{'whitebal'} = $info->{'LightSource'};

$Image->{'flash'} = $info->{'Flash'};
$Image->{'date'} = $info->{'DateTimeOriginal'};
$Image->{'date'} =~ s/(\d\d\d):(\d\d):(\d\d)/$1-$2-$3/;
$Image->{'createtm'} = str2time($Image->{'date'});

PRINT:

return $Image;
}

# Adds a timestamp to a url to force reload
#
# arg is a url, eg http://photos.company.com/photoshelf/add
# returns url   eg http://photos.company.com/photoshelf/add?new=9238474587

sub ForceUrl {
my($url) = @_;

    $url =~ s/[&?]new=[0-9]+//g;
    return $url . (($url =~ /\?/) ? "&":"?") . "new=" . time();
}

#
# Image cache functions - faster than chugging through the DB
#

# get an image from the cache
# if arg is 0, returns hash of all images

sub ImageCacheGetImage {
my ($id) = @_;
my (%db) = ();

    open (CACHE, "$RealDir/cache/image.dat") or warn("Cannot open image cache!");
    while (<CACHE>) {
        chomp;
        my ($img,$pub,$owner,$albref,$rating) = split(/:/);
        if ($img == $id) {
            close CACHE;
            return ($pub, $owner,$albref, $rating);
        } elsif ($id == 0) {
            $db{$img} = "$pub:$owner:$albref:$rating";
        }
    }
    close CACHE;
    return %db, if ($id == 0);
    return -1;
}

# modify or add an image in the cache

sub ImageCacheAddImage {
my ($id,$pub,$owner,$albref,$rating,$del) = @_;

    open (CACHE, "$RealDir/cache/image.dat") or warn ("Cannot open image cache: $!");
    open (TMP, ">$RealDir/cache/image.dat.tmp") or warn ("Cannot open image cache: $!");
    while (<CACHE>) {
        unless (/^$id:/) {
            print  TMP "$_";
        }
    }
    print TMP "$id:$pub:$owner:$albref:$rating\n", unless $del;
    close TMP; close CACHE;
    rename ("$RealDir/cache/image.dat.tmp", "$RealDir/cache/image.dat") or warn "Can't rename image cache temp file: $!";
}

# delete an image from the cache

sub ImageCacheDelImage {
my ($id) = @_;

    ImageCacheAddImage($id,0,0,0,0,1);
}


return 1;

1;
__END__
