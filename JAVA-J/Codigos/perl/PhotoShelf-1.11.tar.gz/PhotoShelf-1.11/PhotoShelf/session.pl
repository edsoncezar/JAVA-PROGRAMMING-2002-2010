# type is 1 for anon ok but login, 0 for login mandatory, and
# -1 for login or anon ok, but no login screen

sub Userverify {
my($q,$type) = @_;
my($tm,$usr,$user,$pass,$host,$server,$realurl,$url);
my($sessid,$sesstime,$sesid);

	$url = $ENV{'REQUEST_URI'};
	$host = $ENV{'HTTP_HOST'};
	$server = $ENV{'SERVER_NAME'};
	if ($host !~ /\.cactii.net$/) {
		print "Location: http://" . $server . $url . "\n\n";
		exit(0);
	}
	$session = $q->cookie(-name=>'sessid');
	$usr = $q->cookie(-name=>'usrid');
	$tm = time();
	if ($session !~ /^$/ && $usr !~ /^$/) {
		$qry = "SELECT sessionid, sesstime FROM users WHERE user = '$usrid'";
		$res = db_query($qry);
		if ($res == -1) {
			if ($type == -1) {
				return "nobody";
			} 
			goto FLUM;
		} 
		($sessid,$sesstime) = $res->fetchrow();
		if ($sessid eq $session && ($tm - $sesstime < 86400)) {
			$qry = "UPDATE users SET sesstime = '$tm' WHERE user = '$usr'";
			$res = db_query($qry);
			return $usr;
		}
		if ($type != -1) {
			goto FLUM;
		} else {
			return "nobody";
		}
	}
FLUM:
	$user = $q->param('user');
	$pass = $q->param('pass');
	if (!CheckPw($user, $pass)) {
		if ($type == -1 || $type == 1) {
			return "nobody";
		}
		AskLogin($url);
		exit(0);
	}
	srand($tm);
	$sesid = rand(10240000);
	$qry = "UPDATE users SET sessionid = $sesid, sesstime = $tm WHERE user = '$user'";
	$res = db_query($qry);
	$cookie = $q->cookie(-name=>'sessid',
		-value=>"$sesid",
		-expires => '+1d',
		-domain => '.cactii.net',
		-path => "$URI");
	$cookie2 = $q->cookie(-name=>'usrid',
		-value=>"$user",
		-expires => '+1d',
		-domain => '.cactii.net',
		-path => $URI);
	print "Set-Cookie: $cookie\n";
	print "Set-Cookie: $cookie2\n";
   	print "Location: $realurl?new=" . $tm . "\n";
   	print "Expires: Wed, 1 Jan 1970 00:00:00 GMT\n";
   	print "Content-type: text/html\n\n";
   	exit(0);
}
