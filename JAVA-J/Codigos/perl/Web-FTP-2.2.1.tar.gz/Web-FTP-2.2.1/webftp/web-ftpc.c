/* Copyright 2002 by Anthony Ball ant@web-ftp.org
 * May be used and redistiributed under the
 * terms and agreements of the Gnu Public License
 * This software comes with absolutely no warranty
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
/*#include <sys/timeb.h>*/

void err(const char *msg) {
    perror(msg);
    printf("Content-Type: text/html\n\n<HTML><HEAD><TITLE><A HREF=\"http://www.web-ftp.org\">Web-FTP</A> Error</TITLE></HEAD><BODY><H3>Web-FTP: There has been an error:<P><BLOCKQUOTE>%s</BLOCKQUOTE></BODY></HTML>",msg);
}

int main(int argc, char **argv, char **env) {
  int         sockfd;
  int         len;
  struct sockaddr_un address;
  int         result;
  int i = 0;
  FILE *      conf;
  int  bytes;  
  char buf[10240];
  char sock[1024];
  char basecgi[1024];
  /*
  struct timeb t;
  struct timeb t2;
  */
  int a,b;

  /*ftime(&t);*/
  sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
  /*  printf("Content-Type: text/plain\n\n");*/
  address.sun_family = AF_UNIX;
  if(!(conf = fopen("webftp/web-ftp.conf","r"))) {
    if(!(conf = fopen("web-ftp.conf","r"))) {
      err("Cound not find web-ftp.conf");
      exit(1);
    }
  } 
  strcpy(basecgi,"web-ftp.cgi");
  sock[0] = '\0';
  while(fgets(buf,1024,conf)) {
    int i = 9;
    int j,k;
    if(!strncasecmp(buf,"SocketDir",9)) {
      i=9;
      while(++i < 1023 && (buf[i] == ' ' || buf[i] == '=') 
	    && buf[i] != '\n' && buf[i] != '\r' && buf[i] != '\0'){}
      k = j = i;
      while(buf[k] != '\n' && ++k < 1023 && buf[k] != '\n') {
	if(buf[k] != ' ')
	  j = k+1;
      } 
      if(j > i) {
	strncpy(sock,buf+i,j-i);
	sock[j-i] = '\0';
      }
    }
    if(!strncasecmp(buf,"BaseCGI",7)) {
      i=6;
      while(++i < 1023 && (buf[i] == ' ' || buf[i] == '=') 
	    && buf[i] != '\n' && buf[i] != '\r' && buf[i] != '\0'){}
      k = j = i;
      while(buf[k] != '\n' && ++k < 1023 && buf[k] != '\n') {
	if(buf[k] != ' ')
	  j = k+1;
      } 
      if(j > i) {
	strncpy(basecgi,buf+i,j-i);
	basecgi[j-i] = '\0';
      }
    }
  }
  fclose(conf);

  if(sock[0] == '\0')
    strncpy(sock,"/tmp/WebFTP",1000);
  strcat(sock,"/");
  if(!getenv("PATH_INFO")) {
    fprintf(stderr, "PATH_INFO not found in environment. May not be running as a cgi\n");
    exit(1); 
  }
  strncat(sock,(char *)getenv("PATH_INFO"),6);

  strncpy(address.sun_path, sock, sizeof(address.sun_path));
  len = sizeof(address);
  
  result = connect(sockfd, (struct sockaddr *)&address, len);
  
  if(result == -1) {
    char *i;
    if(getenv("SCRIPT_NAME")) {
      strncpy(buf,(char *)getenv("SCRIPT_NAME"),1000);
    } else {
      fprintf(stderr, "SCRIPT_NAME not found in environment... may not be running as a cgi");
      exit(1);
    }
    if((i = rindex(buf,'/')) > 0)
      i[1] = '\0';
    strncat(buf,basecgi,1024-strlen(buf));
    perror("Could not connect to socket");
    printf("Content-type: text/html

<HTML><HEAD>
<SCRIPT LANGUAGE=JAVASCRIPT>
function goToLogin() {
  setTimeout(\"open('%s','_top')\",5000);
}
</SCRIPT>
</HEAD>
<BODY ONLOAD=\"goToLogin()\">
<H2>%s</H2>
Sorry, but your session has either timed out, or has aborted due to error, returning you to the <A TARGET=\"_top\" HREF=\"%s\">Login page</A>
</BODY></HTML>",buf,buf,buf);
      exit(1);
  }
  
  while(env[i]) {
    write(sockfd,env[i],strlen(env[i]));
    write(sockfd,"\n",1);
    i++;
  } 
  write(sockfd,"__END_ENV__\n",12);
  while(bytes = read(fileno(stdin),buf,1024)) {
    write(sockfd,buf,bytes);
  }

  write(sockfd,"\n\n",2);

  while((bytes = read(sockfd, &buf, 1024)) > 0) {
    buf[bytes] = '\0';
    fwrite(buf,1,bytes,stdout); /* printf was just plain stupid: \0s */
    /*    printf("%s", buf);*/
  }
  close(sockfd);
  /*
    ftime(&t2);
    a = t2.time - t.time;
    b = t2.millitm - t.millitm ;
    if(b < 0) {
    a--;
    b+=999;
    }
    fprintf(stderr,"C prog took: %d.%03d\n",a,b);
  */
}


