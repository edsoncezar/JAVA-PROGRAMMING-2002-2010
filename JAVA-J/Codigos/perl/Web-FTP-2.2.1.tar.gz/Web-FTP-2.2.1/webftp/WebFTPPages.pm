package WebFTPPages;

use Carp;
use strict;

sub new {
  my $proto = shift;
  my $class = ref($proto) || $proto;

  unless (@_ == 6) { confess "WebFTPPages-: new(version, host, hostname, servername, scriptname, conf)" }
  my $self  = {};
  ($self->{VERSION},
   $self->{HOST},
   $self->{HOSTNAME},
   $self->{SERVERNAME},
   $self->{SCRIPTNAME},
   $self->{conf}) = @_;

#  $self->{SCRIPT} = "$self->{conf}{HTTP}$self->{conf}{SERVERNAME}$self->{conf}{SCRIPT_NAME}";
  $self->{SERVERPORT} = undef;
  $self->{CURRENTDIR} = '/';

  bless ($self, $class);
  return $self;
}

sub updateDir {
  my($self, $dir) = @_;
  $self->{CURRENTDIR} = $dir;
}

sub getDir {
  my($self) = @_;
  $self->{CURRENTDIR};
}

sub setPort {
  my($self, $port) = @_;
  $self->{SERVERPORT} = $port;
}

sub loginScreen {
    my $self = shift;
    my($hostname);
    my @hn = split ',', $self->{conf}{ftphostname};
    my @h = split ',', $self->{conf}{ftphost};
    
    for(my $i=0; $i<=$#h; $i++) { 
	$hn[$i] ||= $h[$i]; 
	$self->{conf}{whathostname}{$h[$i]} = $hn[$i];
    }
    $hostname = $hn[0] unless $#hn;

    my $out;
    $out = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>Web-FTP $self->{VERSION} $hostname $self->{conf}{lang}{login}</TITLE>
  </HEAD>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}" ONLOAD="document.forms[0].elements[0].focus()">
`;
    if(-f qq'$self->{conf}{base}/templates/loginheader') {
	open(D, qq'$self->{conf}{base}/templates/loginheader') or die $!;
	local $/;
	$out .= <D>;
	close D;
    } else {
	$out .= qq`
    <H1><A HREF="http://www.web-ftp.org/">Web-FTP</A> $self->{VERSION} $hostname $self->{conf}{lang}{login}</H1>
`;
    }
    
    $out .= qq`
<SCRIPT LANGUAGE=JAVASCRIPT>
function next() {
  var i,j;
  var e = document.forms[0].elements;
  for(i = 0; i < e.length; i++) {
    if(e[i].type == 'text' || e[i].type == 'password') {
      if(e[i].value == '' && e[i].name != 'host') {
        e[i].focus();
        i = 10;
        j = 1;
      }
    }
  }
  if(!j)
    document.forms[0].submit();
    
}
</SCRIPT>
    <FORM METHOD=POST ACTION="$self->{conf}{SCRIPT}">
      <TABLE BGCOLOR="$self->{conf}{logincolor}" ALIGN=CENTER BORDER=0 CELLSPACING=0 CELLPADDING=5>
`;
    if($self->{conf}{language}) {
	my @lang = split /\s*,\s*/, $self->{conf}{language};
	$out .= "<TR><TD>$self->{conf}{lang}{language}:</TD><TD>";
	if($#lang) {
	    $out .= qq`<SELECT NAME=language>`;
	    for(@lang) {
		(my $l = $_) =~ tr/_/ /;
		$l = ucfirst($l);
		$out .= qq`<OPTION VALUE="$_">$l</OPTION>`;
	    }
	    $out .= "</SELECT>";
	} else {
	    $out .= $self->{conf}{current_lang}
	}
	$out .= "</TD>\n";
    }
    if($#h > 0) {
	my $select = '';
	for(my $i = 0;$i <= $#h;$i++) {
	    $select .= qq`<OPTION VALUE="$h[$i]">$hn[$i]</OPTION>\n`;
	}
        $out .= qq`<TR>
<TD>$self->{conf}{lang}{host}:</TD>
<TD><SELECT ONCHANGE="next()" NAME="host">
$select
</SELECT>
</TD>
</TR>
`;
    } elsif ($#h == -1) {
        $out .= qq`<TR>
<TD>$self->{conf}{lang}{host}:</TD>
<TD><INPUT ONCHANGE="next()" NAME="host"></TD>
</TR>
`;
    }
    $out .= qq`
			<TR>
          <TD>$self->{conf}{lang}{username}:</TD>
          <TD><INPUT ONCHANGE="next()" NAME="username"></TD>
        </TR>
        <TR>
          <TD>$self->{conf}{lang}{password}:</TD>
          <TD><INPUT ONCHANGE="next()" NAME="password" TYPE=PASSWORD></TD>
        </TR>
        <TR>
          <TD COLSPAN=2 ALIGN=RIGHT>
            <INPUT TYPE=SUBMIT VALUE="$self->{conf}{lang}{login}">
          </TD>
        </TR>
      </TABLE>
    </FORM>
  <P>
`;
    if(-f qq'$self->{conf}{base}/templates/loginfooter') {
	open(D, qq'$self->{conf}{base}/templates/loginfooter') or die $!;
	local $/;
	$out .= <D>;
	close D;
    } else {
	$out .= $self->credits();
    }
    $out .= qq`
  </BODY>
</HTML>
`;
    return \$out;
}

sub MESSAGES {
  my $self = shift;

  my $out = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <META HTTP-EQUIV="Refresh" CONTENT="30; URL=$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MESSAGES">
  <HEAD>
    <TITLE>$self->{conf}{lang}{msg_title}</TITLE>
  </HEAD>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
  $self->{conf}{lang}{msg_help}
  <BR><A HREF="javascript:self.close()">$self->{conf}{lang}{close_window}</A><P>
`;
  for(@{$self->{conf}{messages}}) {
      my $d = localtime($_->[0]);
      $d =~ /(\d\d:\d\d:\d\d)/;
      $out .= "<B>$1</B>: $_->[1]<BR>\n";
  }
  $out .= qq`
  <P><A HREF="javascript:self.close()">$self->{conf}{lang}{close_window}</A>
  </BODY>
</HTML>
`;
  \$out;

}

sub ACCT {
    my $self = shift;
  
    my $out;
    $out = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>Web-FTP $self->{VERSION}: $self->{HOSTNAME} $self->{conf}{lang}{login}</TITLE>
  </HEAD>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
`;
    if(-f qq'$self->{conf}{base}/templates/loginheader') {
	open(D, qq'$self->{conf}{base}/templates/loginheader') or die $!;
	local $/;
	$out .= <D>;
	close D;
    } else {
	$out .= qq`
    <H1><A HREF="http://www.web-ftp.org/">Web-FTP</A> $self->{VERSION}: $self->{HOSTNAME} $self->{conf}{lang}{login}</H1>
`;
    }
    
    $out .= qq`
    <FORM METHOD=POST ENCTYPE="multipart/form-data" TARGET="_top"
       ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST">
      <INPUT TYPE=HIDDEN NAME="action" VALUE="crypto">
      <TABLE BGCOLOR="$self->{conf}{logincolor}" ALIGN=CENTER BORDER=0 CELLSPACING=0 CELLPADDING=5>
`;
    
    $out .= qq`		</TR>

			<TR>
          <TD>CRYPTOCard Challenge</TD>
          <TD>$self->{conf}{challenge}</TD>
        </TR>
        <TR>
          <TD>Response:</TD>
          <TD><INPUT NAME="response" TYPE=PASSWORD></TD>
        </TR>
        <TR>
          <TD COLSPAN=2 ALIGN=RIGHT>
            <INPUT TYPE=SUBMIT VALUE="$self->{conf}{lang}{login}">
          </TD>
        </TR>
      </TABLE>
    </FORM>
  <P>
`;
    if(-f qq'$self->{conf}{base}/templates/loginfooter') {
	open(D, qq'$self->{conf}{base}/templates/loginfooter') or die $!;
	local $/;
	$out .= <D>;
	close D;
    } else {
	$out .= $self->credits();
    }
    $out .= qq`
  </BODY>
</HTML>
`;
    return \$out;
}

sub failLogin {
  my $self = shift;

  \qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <META HTTP-EQUIV="Refresh" CONTENT="5; URL=$self->{conf}{SCRIPT}">
  <HEAD>
    <TITLE>$self->{conf}{lang}{login_failed}</TITLE>
  </HEAD>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
    <H1>$self->{conf}{lang}{login_failed}</H1>
    <H3>$self->{conf}{lang}{login_failed_msg}</H3>
<PRE>$_[0]</PRE>
  </BODY>
</HTML>
`;
}

sub permissionFailure {
  my $self = shift;
  my $OUT = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>$self->{conf}{lang}{access_denied}</TITLE>
  </HEAD>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<B><FONT COLOR="$self->{conf}{errorcolor}" SIZE=+1>$self->{conf}{lang}{unauthorized}</FONT></B>
    <P>
    $self->{conf}{lang}{please} <A HREF="$self->{conf}{HTTP}$self->{conf}{SERVERNAME}$self->{conf}{ORIG_SCRIPT_NAME}">$self->{conf}{lang}{login}</A>
    <I>$self->{conf}{lang}{with_cookies}</I>.
  </BODY>
</HTML>
`;
  return \$OUT;
}

sub errorPage {
  my $self = shift;
  my $OUT = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>Error</TITLE>
  </HEAD>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<B><FONT COLOR="$self->{conf}{errorcolor}" SIZE=+1>$self->{conf}{lang}{error}</FONT></B><P>
$_[0]
<P>
<A HREF="$self->{conf}{SCRIPT}">$self->{conf}{lang}{click_here}</A> $self->{conf}{lang}{to_go}
  </BODY>
</HTML>
`;
  return \$OUT;
}

sub uploadScreen {
  my $self = shift;

  \qq`
<HTML>
  <HEAD>
    <TITLE>Web-FTP $self->{VERSION}: $self->{conf}{lang}{file_upload} $self->{HOSTNAME}</TITLE>
  </HEAD>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
    <H3>web-FTP $self->{VERSION}: $self->{conf}{lang}{file_upload}
        $self->{HOSTNAME}:$self->{CURRENTDIR}</H3>
    <FORM ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <B>$self->{conf}{lang}{file}: </B><INPUT TYPE=FILE NAME="uploaded_file" SIZE=50>
      <BR>
      <INPUT TYPE=SUBMIT NAME="action" VALUE="$self->{conf}{lang}{upload}">
      &nbsp;&nbsp;
      <A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MAIN"><FONT SIZE=+2>$self->{conf}{lang}{cancel}</FONT></A>
    </FORM>
  </BODY>
</HTML>
`
}

sub HEAD {
    my $self = shift;
    my $head = qq`
<H2><A TARGET="_top" HREF="http://www.web-ftp.org">Web-FTP</A> $self->{VERSION} - $self->{conf}{lang}{connected_to} <B>$self->{HOSTNAME}</B></H2>
`;    
    if(-f qq'$self->{conf}{base}/templates/header') {
	open(D, qq'$self->{conf}{base}/templates/header') or die $!;
	local $/;
	$head = <D>;
	close D;
	return \$head if $head =~ /<[Hh][Tt][Mm][Ll]\s*>/;
    }
    \qq`<HTML><BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
$head
</BODY></HTML>`;
}

sub FOOT {
    my $self = shift;
    \qq`<HTML><BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">${\($self->credits())}</BODY></HTML>`;
}
sub credits {
    my $self = shift;
    if(-f qq'$self->{conf}{base}/templates/footer') {
	open(D, qq'$self->{conf}{base}/templates/footer') or die $!;
	local $/;
	my $foot = <D>;
	close D;
	return $foot;
    }
    qq`<TABLE CELLPADDING=0 CELLSPACING=0 WIDTH="100%"><TR><TD>$self->{conf}{lang}{maintained_by} <A HREF="http://www.web-ftp.org/contact.html">Anthony Ball</A> </TD><TD ALIGN=RIGHT>&copy; 2002,2003</TD></TR></TABLE>`;
}
sub FILES {
    my $self = shift;
    my $OUT = qq`<HTML>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<BASEFONT SIZE=2>
<FORM TARGET=MAIN ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
<INPUT TYPE=HIDDEN NAME=DirectoriesList VALUE="">
<INPUT TYPE=HIDDEN NAME=action VALUE="">
<INPUT TYPE=HIDDEN NAME=tarname VALUE="">
<SCRIPT LANGUAGE=JAVASCRIPT>
function tag() {
  for(i=0; i<document.forms[0].length;i++) {
    foo = document.forms[0].elements[i];
    if(foo.name == 'Files') {
      if(foo.checked) {
        foo.checked = 0;
      } else {
        foo.checked = 1;
      }
    }
  }
}
</SCRIPT>
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0 WIDTH="100%">
`;
    $OUT .= qq`<TH><A HREF="javascript:tag()">$self->{conf}{lang}{tag_title}</A></TH>` unless $self->{conf}{hidetag};
    $OUT .= qq`<TH>$self->{conf}{lang}{file_title}</TH>`;
    $OUT .= qq`<TH>$self->{conf}{lang}{last_mod_title}</TH>` unless $self->{conf}{hidelastmod};
    $OUT .= qq`<TH>$self->{conf}{lang}{size_title}</TH>` unless $self->{conf}{hidesize};
    $OUT .= qq`<TH>$self->{conf}{lang}{owner_group_title}</TH>` unless $self->{conf}{hideowngrp};
    $OUT .= qq`<TH>$self->{conf}{lang}{permissions_title}</TH>` unless $self->{conf}{hidepermissions};
    $OUT .= qq`
${\(join '', @{$self->{list}{FileEntries}})}
</TABLE>
</FORM>
</BODY></HTML>`;
    return \$OUT;
}
sub DIRS {
    my $self = shift;
    my $OUT = qq`<HTML>
  <BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<BASEFONT SIZE=2>
<FORM TARGET=MAIN ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
<INPUT TYPE=HIDDEN NAME=ACTION VALUE="">
<SCRIPT LANGUAGE=JAVASCRIPT>
function tag() {
  for(i=0; i<document.forms[0].length;i++) {
    foo = document.forms[0].elements[i];
    if(foo.name == 'Directories') {
      if(foo.checked) {
        foo.checked = 0;
      } else {
        foo.checked = 1;
      }
    }
  }
}
</SCRIPT>
<TABLE CELLPADDING=3 CELLSPACING=0 BORDER=0 WIDTH="100%">
`;
    $OUT .= qq`<TH><A HREF="javascript:tag()">$self->{conf}{lang}{tag_title}</A></TH>` unless $self->{conf}{hidetag};
    $OUT .= qq`<TH>$self->{conf}{lang}{dir_title}</TH>`;
    $OUT .= qq`<TH>$self->{conf}{lang}{last_mod_title}</TH>` unless $self->{conf}{hidelastmod};
    $OUT .= qq`<TH>$self->{conf}{lang}{size_title}</TH>` unless $self->{conf}{hidesize};
    $OUT .= qq`<TH>$self->{conf}{lang}{owner_group_title}</TH>` unless $self->{conf}{hideowngrp};
    $OUT .= qq`<TH>$self->{conf}{lang}{permissions_title}</TH>` unless $self->{conf}{hidepermissions};
    $OUT .= qq`
${\(join '', @{$self->{list}{DirEntries}})}
</TABLE>
</FORM>
</BODY></HTML>`;
    return \$OUT;
}

sub MAIN {
    my $self = shift;
    \qq`
<HTML><HEAD>
<FRAMESET COLS="*" ROWS="$self->{conf}{dirsframesize},$self->{conf}{infoframesize},$self->{conf}{fileframesize}">
<FRAME NAME=DIRS SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/DIRS">
<FRAME MARGINHEIGHT=0 MARGINWIDTH=0 NAME=PWD SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/INFO">
<FRAME NAME=FILES SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/FILES">
</FRAMESET>
</HTML>`;
#<FRAME NAME=DIRSINFO SRC="$self->{conf}{SCRIPT}/DIRSINFO">

}

sub DIRSINFO {
    my $self = shift;
    \qq`
<HTML><HEAD>
<FRAMESET COLS="*" ROWS="$self->{conf}{dirsframesize},$self->{conf}{infoframesize}">
<FRAME NAME=DIRS SRC="$self->{conf}{SCRIPT}/DIRS">
<FRAME MARGINHEIGHT=0 MARGINWIDTH=0 NAME=PWD SRC="$self->{conf}{SCRIPT}/INFO">
</FRAMESET>
</HTML>`;
}

sub INFO {
    my $self = shift;
    my($dsf,$link);

    for(split '/', $self->{CURRENTDIR}) {
        $dsf .= "$_/";
        $link .= qq`<A TARGET=MAIN HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/CDTO?$dsf">$_/</A>`;
    }
    $link ||= '/';
    \qq`<HTML>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<TABLE WIDTH="100%"><TR><TD>
$self->{conf}{lang}{index_of} $link
</TD><TD ALIGN=CENTER>
<A TARGET=MAIN HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/CDTO?%2e">$self->{conf}{lang}{refresh}</A>
<A HREF="#chdir">$self->{conf}{lang}{change_dir}</A>
</TD><TD ALIGN=RIGHT>
<A TARGET=MAIN HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/CDTO?%2e%2e">$self->{conf}{lang}{parent_dir}</A>
</TD></TR>
<TR><TD COLSPAN=3 ALIGN=CENTER>
  <P>&nbsp;
  <P>&nbsp;
  <P>&nbsp;
  <FORM TARGET=MAIN ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
    <B>$self->{conf}{lang}{directory}:</B><A NAME="chdir"> <INPUT NAME="Directories" SIZE=40><INPUT TYPE=SUBMIT VALUE="$self->{conf}{lang}{go}"></A>
    <INPUT TYPE=HIDDEN NAME="action" VALUE="chdir">
  </FORM>
</TABLE>
`;

}

sub NAVBAR {
    my $self = $_[0];
    my($OUT);
    $OUT = qq`<HTML>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
<SCRIPT LANGUAGE=JAVASCRIPT>
function dtt(what) {
  var i,dcnt,fcnt,dirs,foo,tarname;
  dirs = '';
  dcnt = fcnt = 0;
  for(i=0; i<parent.MAIN.FILES.document.forms[0].length;i++) {
    foo = parent.MAIN.FILES.document.forms[0].elements[i];
    if(foo.name == 'Files' && foo.checked) {
      fcnt++;
    }
  }
  for(i=0; i<parent.MAIN.DIRS.document.forms[0].length;i++) {
    foo = parent.MAIN.DIRS.document.forms[0].elements[i];
    if(foo.name == 'Directories' && foo.checked) {
      dcnt++;
      if(dirs)
        dirs += "\\n";
      dirs += foo.value;
    }
  }
  if(what == 'download' && (fcnt > 1 || dcnt > 0)) {
    tarname = prompt('$self->{conf}{lang}{download_multiple_help}','$self->{conf}{lang}{download_multiple_default_name}');
  }
  if(what == 'download' && !(fcnt+dcnt)) {
    alert('$self->{conf}{lang}{tag_a_directory}');
    return;
  }
  if(dcnt + fcnt) {
    parent.MAIN.FILES.document.forms[0].DirectoriesList.value = dirs;
    parent.MAIN.FILES.document.forms[0].action.value = what;
    parent.MAIN.FILES.document.forms[0].tarname.value = tarname;
    parent.MAIN.FILES.document.forms[0].submit();
  } else {
    alert('$self->{conf}{lang}{tag_a_file}');
  }
}
function edit(editor) {
  var a,b,i;
  a = parent.MAIN.FILES.document.forms[0];
  if(a.Files.checked) {
    b = a.Files.value;
  }
  for (i = 0; i<a.Files.length; i++) {
     if(a.Files[i].checked) {
       b = a.Files[i].value;
       break;
     }
  }
  if(b) {
    var w = window.open('$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/EDIT?file='+b+'&editor='+editor, 'EDIT', 'toolbar=no,menubar=no,location=no,resizable=yes');
    w.focus();
  } else {
    alert('$self->{conf}{lang}{tag_for_edit}');
  } 
}

function site() {
  var foo,i;
  var list = '';
  for(i=0; i<parent.MAIN.FILES.document.forms[0].length;i++) {
    foo = parent.MAIN.FILES.document.forms[0].elements[i];
    if(foo.name == 'Files' && foo.checked) {
      list += " " + foo.value;
    }
  }
  for(i=0; i<parent.MAIN.DIRS.document.forms[0].length;i++) {
    foo = parent.MAIN.DIRS.document.forms[0].elements[i];
    if(foo.name == 'Directories' && foo.checked) {
      list += " " + foo.value;
    }
  }
    parent.MAIN.FILES.document.forms[0].DirectoriesList.value = prompt('$self->{conf}{lang}{enter_for_site}',unescape(list));
    parent.MAIN.FILES.document.forms[0].action.value = 'site';
    parent.MAIN.FILES.document.forms[0].submit();
}

function messages() {
  window.open('$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MESSAGES','MESSAGES', 'scrollbars=yes,toolbar=no,menubar=no,location=no,resizable=yes,width=400,height=400');
}

function newfile(editor) {
  var a = prompt('$self->{conf}{lang}{new_file_name}', '');
  if(a) 
    window.open('$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/EDIT?file='+a+'&editor='+editor, 'EDIT');
}
</SCRIPT>
<TABLE CELLSPACING=2 CELLPADDING=3 BGCOLOR="$self->{conf}{buttoncolor}">
`;
    $OUT .= qq`<TR><TD><FONT SIZE="-1"><A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MKDIR" TARGET=MAIN>$self->{conf}{lang}{mkdir}</A></TD></TR>` unless $self->{conf}{hidemkdir};
    $OUT .= qq`<TR><TD><FONT SIZE="-1"><A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/PUT"   TARGET=MAIN>$self->{conf}{lang}{upload}</A></TD></TR>` unless $self->{conf}{hideupload};
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:dtt('download')">$self->{conf}{lang}{download}</A>
</TD></TR>` unless $self->{conf}{hidedownload};
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:dtt('permissions')">$self->{conf}{lang}{permissions}</A>
</TD></TR>` unless $self->{conf}{hidepermbutton};
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:dtt('delete')">$self->{conf}{lang}{delete}</A>
</TD></TR>` unless $self->{conf}{hidedelete};
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:dtt('move')">$self->{conf}{lang}{move}</A>
</TD></TR>` unless $self->{conf}{hidemove};

    for(@{$self->{conf}{editors}}) {
	next unless $_->[0];
	if($_->[1]) {
	    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:edit('$_->[0]')">$_->[1]</A>
</TD></TR>`;
	}
	if($_->[2]) {
	    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:newfile('$_->[0]')">$_->[2]</A>
</TD></TR>`;
	}
    }
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:site()">$self->{conf}{lang}{site}</A>
</TD></TR>` unless $self->{conf}{hidesite};
    $OUT .= qq`<TR><TD><FONT SIZE="-1">
<A HREF="javascript:messages()">$self->{conf}{lang}{messages}</A>
</TD></TR>` unless $self->{conf}{hidemessages};
    $OUT .= qq`<TR><TD><FONT SIZE="-1"><A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/QUIT" TARGET="_top"><B>QUIT</B></A></TD></TR>`;
    $OUT .= q`
</TABLE>
</BODY></HTML>`;
    return \$OUT;
}

sub mkdirScreen {
  my $self = shift;

  \qq`
<HTML>
  <HEAD>
    <TITLE>$self->{conf}{lang}{version} $self->{VERSION}: $self->{conf}{lang}{new_directory} $self->{HOSTNAME}</TITLE>
  </HEAD>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
    <H3>$self->{conf}{lang}{version} $self->{VERSION}: $self->{conf}{lang}{new_directory_in} $self->{HOSTNAME}:$self->{CURRENTDIR}</H3>
    <FORM TARGET=MAIN ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
      <B>$self->{conf}{lang}{directory_name}:</B> <INPUT NAME="Directories" SIZE=40>
      <BR>
      <INPUT TYPE=SUBMIT NAME="action" VALUE="$self->{conf}{lang}{make_directory}">
      &nbsp;&nbsp;
      <A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MAIN"><FONT SIZE=+2>$self->{conf}{lang}{cancel}</FONT></A>
    </FORM>
  </BODY>
</HTML>
`;
}

sub moveScreen {
  my $self = shift;

  my $reply = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>$self->{conf}{lang}{version} $self->{VERSION}: $self->{conf}{lang}{moving_files_on} $self->{HOSTNAME}</TITLE>
  </HEAD>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
    <H3>$self->{conf}{lang}{version} $self->{VERSION}: $self->{conf}{lang}{moving_files_within}
        $self->{HOSTNAME}:$self->{CURRENTDIR}</H3>
    <BR NOSHADE>
    <FORM ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
`;

  foreach my $file (@_) {
    $file = $self->unencode($file);
    (my $str = $self->{conf}{lang}{rename_file_to}) =~ s/__file__/$file/g;
    $reply .= "      $str <INPUT NAME=\"Directories\">\n" .
              "      <BR>\n" .
              "      <INPUT TYPE=HIDDEN NAME=\"Files\" VALUE=\"$file\">\n";
  }

  $reply .= qq`
      <INPUT TYPE=SUBMIT NAME="action" VALUE="$self->{conf}{lang}{move_button}">
      &nbsp;&nbsp;
      <A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MAIN"><FONT SIZE=+2>$self->{conf}{lang}{cancel}</FONT></A>
    </form>
  </BODY>
</HTML>
`;

  \$reply;
}

sub permsScreen {
  my $self = shift;
  my @colors = ($self->{conf}{oddcolcolor},$self->{conf}{evencolcolor});
  my $reply = qq`
<HTML>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <HEAD>
    <TITLE>$self->{conf}{lang}{version} $self->{VERSION}: $self->{conf}{lang}{altering_permissions_on} $self->{HOSTNAME}</TITLE>
  </HEAD>
<BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">
    <H3>Web-FTP $self->{VERSION}: $self->{conf}{lang}{altering_permissions_within}
        $self->{HOSTNAME}:$self->{CURRENTDIR}</H3>
    <BR NOSHADE>
    <FORM ENCTYPE="multipart/form-data" ACTION="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/POST" METHOD=POST>
<TABLE>
`;
  my $i = 0;
  foreach my $file (@_) {
      my $f = $self->unencode($file);
      my(%c,@list,$list,$not_simple,$perm);
      $perm = $self->{PERMISSIONS}{$f};
      my @perms = split '', $perm;
      if($perms[0] !~ /[d-]/) {
	  $not_simple = 1;
      }
      for(2,5,8) {
	  my($v);
	  if($perms[$_] !~ /[w-]/) {
	      $not_simple = 1;
	  }
	  $v = 2**(9-$_);
	  $c{$v} = 'CHECKED' if $perms[$_] eq 'w';
      }
      for(3,6,9) {
	  my($v);
	  if($perms[$_] !~ /[x-]/) {
	      $not_simple = 1;
	  }
	  $v = 2**(9-$_);
	  $c{$v} = 'CHECKED' if $perms[$_] eq 'x';
      }
      for(1,4,7) {
	  my($v);
	  if($perms[$_] !~ /[r-]/) {
	      $not_simple = 1;
	  }
	  $v = 2**(9-$_);
	  $c{$v} = 'CHECKED' if $perms[$_] eq 'r';
      }
      $reply .= qq`
<TR><TD>$self->{conf}{lang}{new_permissions_for} <B>$f</B> ($perm):
<INPUT TYPE=HIDDEN NAME="Files" VALUE="$f">
</TD></TR>
`;
      $reply .= qq`
<TR><TD ALIGN=CENTER>
<INPUT NAME="Directories" SIZE=4>\n$self->{conf}{lang}{octal_advanced}
</TD></TR>
` unless $self->{conf}{hideoctalperms};
      $reply .= qq`
<TR><TD>
<TABLE BORDER=1><TR>
<TH BGCOLOR="$colors[0]" COLSPAN=3>$self->{conf}{lang}{owner}</TH>
<TH BGCOLOR="$colors[1]" COLSPAN=3>$self->{conf}{lang}{group}</TH>
<TH BGCOLOR="$colors[0]" COLSPAN=3>$self->{conf}{lang}{world}</TH>
</TR><TR>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{read}</TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{write}</TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{execute}</TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER>$self->{conf}{lang}{read}</TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER>$self->{conf}{lang}{write}</TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER>$self->{conf}{lang}{execute}</TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{read}</TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{write}</TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER>$self->{conf}{lang}{execute}</TD>
</TR>
<TR>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="256" $c{256}></TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="128" $c{128}></TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="64" $c{64}></TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="32" $c{32}></TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="16" $c{16}></TD>
<TD BGCOLOR="$colors[1]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="8" $c{8}></TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="4" $c{4}></TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX ONCLICK="if(this.checked) { return confirm('$self->{conf}{lang}{world_writeable_query}') }" NAME="perm_$i" VALUE="2" $c{2}></TD>
<TD BGCOLOR="$colors[0]" ALIGN=CENTER><INPUT TYPE=CHECKBOX NAME="perm_$i" VALUE="1" $c{1}></TD>
</TABLE>
</TD></TR>
` unless $not_simple;
      $i++;
  }

  $reply .= qq`
      </TABLE>
      <INPUT TYPE=SUBMIT NAME="action" VALUE="$self->{conf}{lang}{change_permissions}">
      &nbsp;&nbsp;
      <A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MAIN"><FONT SIZE=+2>$self->{conf}{lang}{cancel}</FONT></A>
    </FORM>
  </BODY>
</HTML>
`;

  \$reply;
}

sub frameset {
    my $self = shift;
    \qq`
<HTML>
  <HEAD>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <TITLE>Web-FTP $self->{VERSION}: $self->{HOSTNAME}</TITLE>
</HEAD>
<FRAMESET BORDER=0 COLS="*" ROWS="75,*,35">
<FRAME NORESIZE NAME=HEAD SCROLLING="NO" SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/HEAD"></FRAME>
<FRAMESET BORDER=0 COLS="125,*" ROWS"*">
<FRAME NORESIZE NAME=NAVBAR SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/NAVBAR"></FRAME>
<FRAME NORESIZE NAME=MAIN SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/MAIN"></FRAME>
</FRAMESET>
<FRAME NORESIZE NAME=FOOT SCROLLING="NO" SRC="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/FOOT"></FRAME>
</FRAMESET>
</HTML>
`;
}

sub getDirectory {
    my $self = shift;
    my (@DirEntries, @FileEntries);
    %{$self->{PERMISSIONS}} = ();
#    print STDERR "Direntries: @_\n";
    foreach my $Entry (@_) {
	my($pr,$fs,$us,$gr,$sz,$d1,$d2,$d3,$fn);
        # This line is FTPD dependant. I hope that doesn't matter too much.
	if($self->{conf}{servertype} eq 'MS') {
	    ($d1,$d3,$sz,$fn) = split / +/, $Entry, 4;
	} else {
	    if($self->{dircheck} < 2) {
		($pr,$fs,$us,$gr,$sz,$d1,$d2,$d3,$fn) = split / +/, $Entry, 9;
		if(!$self->{dircheck} && ($gr || $sz)) {
		    $self->{dircheck} = ($gr =~ /^\d+$/ && $sz !~ /^\d+$/ ? 2 : 1);
		}
	    }
	    if($self->{dircheck} == 2) {
		($pr,$fs,$us,$sz,$d1,$d2,$d3,$fn) = split / +/, $Entry, 8;
	    }
	}
# Bill Gate's Version 
#	10-23-99  02:41PM       <DIR>          Anwendungsdaten

	$self->{PERMISSIONS}{$fn} = $pr if $pr;
#	print STDERR "$pr,$fs,$us,$gr,$sz,$d1,$d2,$d3,$fn\n";
	my @colors = ($self->{conf}{oddcolcolor},$self->{conf}{evencolcolor});
	if($fn) {
	    my $i = 0;
		my($fnlink,$fnq,@Option);
	    my $type = 'Files';

	    if($pr) {
		my @pr = unpack('a1a3a3a3', $pr);
		$pr = "$pr[0]<B>$pr[1]</B>$pr[2]<B>$pr[3]</B>";
		$type = 'Directories' if $pr[0] eq 'd';
		if($pr[0] eq 'l') {
		    my($foo) = 1 if($fn =~ m|/$|);
		    $fn =~ s/\s+->.*$//;
		    if ($foo) {
			$type = 'Directories';
		    } else {
			$type = 'Directories' unless $self->{conf}{FTP}->size($fn);
		    }
		}
	    } else {
		$type = 'Directories' if $sz eq '<DIR>';
	    }
#	    print STDERR "Type: $type\n";
            $fnq = $self->encode($fn);
	    if($type eq 'Directories') {
		$fnlink = qq`<A TARGET=MAIN HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/CDTO?$fnq">$fn</A>`;
	    } else {
		$fnlink = qq`<A HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/DNLD?$fnq">$fn</A>`;
	    }
	    push @Option, q`<TR>`;
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}" ALIGN=CENTER><FONT SIZE=1><INPUT TYPE=CHECKBOX NAME=$type VALUE="$fnq">&nbsp;&nbsp;</TD>` unless $self->{conf}{hidetag};
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}" ALIGN=RIGHT WIDTH=150><FONT SIZE=2>$fnlink&nbsp;&nbsp;</TD>`;
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}" ALIGN=RIGHT><FONT SIZE=2>$d1 $d2 $d3&nbsp;&nbsp;</TD>` unless $self->{conf}{hidelastmod};
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}" ALIGN=RIGHT><FONT SIZE=2>$sz&nbsp;&nbsp;</TD>` unless $self->{conf}{hidesize};
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}" ALIGN=CENTER><FONT SIZE=2>$us:$gr&nbsp;&nbsp;</TD>` unless $self->{conf}{hideowngrp};

	    my $perm = '';
	    $perm .= qq`<A TARGET=MAIN HREF="$self->{conf}{SCRIPT}$self->{conf}{COOKIE}/PERM?$fnq">` unless $self->{conf}{hidepermbutton};
	    $perm .= $pr;
	    $perm .= q`</A>` unless $self->{conf}{hidepermbutton};	    
            push @Option, qq`<TD BGCOLOR="${\($colors[$i++%2])}"><FONT SIZE=2>$perm</TD>` unless $self->{conf}{hidepermissions};
            push @Option, q`</TR>`;

            if($type eq 'Directories') { push @DirEntries, @Option; }
            else { push @FileEntries, @Option; }
        }
    }
    $self->{list}{DirEntries} = \@DirEntries;
    $self->{list}{FileEntries} = \@FileEntries;
}

sub encode {
    $_ = $_[1];
    s/(\W)/'%'.sprintf("%lx", ord($1))/ge;
    return $_;
}
sub unencode {
    $_ = $_[1];
    s/\%([\da-fA-F][\da-fA-F])/chr(hex($1))/ge;
    return $_;
}

sub html_header {
    my $self = shift;
    qq`<HTML><BODY BGCOLOR="$self->{conf}{backgroundcolor}" TEXT="$self->{conf}{textcolor}" VLINK="$self->{conf}{visitedlinkcolor}" LINK="$self->{conf}{linkcolor}">`;
}

sub html_footer {
    my $self = shift;
    q`
  </BODY>
</HTML>
`;
}
1;
