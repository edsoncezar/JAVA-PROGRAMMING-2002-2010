#!/usr/bin/perl

package editor;

sub new {
    my %self;
    shift;
    %self = @_;
    $_ = bless \%self;
    return $_;
}

sub new_file {
    my $self = shift;
}

sub EDITMAIN {
    my $self = shift;
    my $out = qq`
<HTML>
<FRAMESET ROWS="50,*" NORESIZE BORDER=0 FRAMEBORDER=NO>
<FRAMESET COLS="*,1">
<FRAME NAME=EDITNAV SCROLLING=OFF SRC="$self->{conf}{SCRIPT_NAME}$self->{conf}{COOKIE}/EDITNAV">
<FRAME NAME=SYS MARGINHEIGHT=1 SCROLLING=OFF SRC="$self->{conf}{SCRIPT_NAME}$self->{conf}{COOKIE}/SYS">
<FRAME>
</FRAMESET>
<FRAME NAME=EDITOR SRC="$self->{conf}{SCRIPT_NAME}$self->{conf}{COOKIE}/EDITOR">
</FRAMESET>
</HTML>
`;

    return \$out;
}

sub get_filename {
    my $self = shift;
    return $self->{conf}{CURRENTEDIT};
}

sub get_data {
    my $self = shift;
#    $self->{conf}{EDITDATA} =~ s/\r?\n|\r/$self->{conf}{editcrlf}/g if $self->{conf}{editcrlf};
    return $self->{conf}{EDITDATA};
}

sub edit_update {
    my $self = shift;
    $self->{conf}{EDITDATA} = $_[0]->{data}[0];
    $self->{conf}{OLDEDIT} = '';
    if($_[0]->{op}[0] =~ /\D/) {
	$self->{conf}{OLDEDIT} = $self->{conf}{CURRENTEDIT};
	$self->{conf}{CURRENTEDIT} = $_[0]->{op}[0];
	$_[0]->{op}[0] = 2;
	$self->{conf}{refresh_edit} = 1;
    }
    if($_[0]->{op}[0]) {
	$self->{conf}{state} = "save";
    }
    return 'CLOSE_AND_REFRESH' if($_[0]->{op}[0] < 2);
    return 'SYS';
}

sub SYS {
    my $self = shift;
    my ($out);
    $out = $self->{conf}{CONTENT}->html_header;
    $out .= qq`
<FORM ACTION="$self->{conf}{SCRIPT_NAME}$self->{conf}{COOKIE}/POST" METHOD=POST ENCTYPE="multipart/form-data">
<INPUT TYPE=HIDDEN NAME="action" VALUE="edit">
<INPUT TYPE=HIDDEN NAME="op" VALUE="">
<INPUT TYPE=HIDDEN NAME="data" VALUE="">
</FORM>
`;
    $out .= $self->_save_error() if $self->{conf}{save_error};
    if($self->{conf}{refresh_edit}) {
	$out .= qq`
<SCRIPT LANGUAGE=javascript>
  parent.EDITOR.location.reload()
</SCRIPT>
`; 
	$self->{conf}{refresh_edit} = 0;
    }
    $out .= $self->{conf}{CONTENT}->html_footer;
    return \$out;
}

sub _save_error {
    my $self = shift;
    $_ = $self->{conf}{messages}[0][1];
    s/\n/\\n/g;
    $self->{conf}{CURRENTEDIT} = $self->{conf}{OLDEDIT} if $self->{conf}{OLDEDIT};
    $self->{conf}{save_error} = 0;
    $self->{conf}{OLDEDIT} = '';
    qq`
<SCRIPT LANGUAGE=javascript>
  alert('$_ \\nChange the name or location using save as, or do simply exit to cancel');
</SCRIPT>
`;
}

sub EDITOR {
    my $self = shift;
    my ($data,$out,$i);
    if($self->{conf}{EDITDATA} =~ /[\x80-\xff]/) {
	return $self->BINARY_ERROR();
    }
    $out = $self->{conf}{CONTENT}->html_header;
    ($data = $self->{conf}{EDITDATA}) =~ s/\&/\&amp;/g;
    $out .= qq`
<FORM>
<B>File: </B>$self->{conf}{CURRENTEDIT}<BR> 
<TEXTAREA ROWS=24 COLS=60 NAME=data>$data</TEXTAREA>
</FORM>
`;
    $out .= $self->{conf}{CONTENT}->html_footer;
    return \$out;
}

sub EDITNAV {
    my $self = shift;
    my ($out);
    $out = $self->{conf}{CONTENT}->html_header;
    $out .= qq`
<SCRIPT LANGUAGE=JAVASCRIPT>
parent.focus();
self.focus();
function s(a,b) {
  parent.SYS.document.forms[0].data.value = parent.EDITOR.document.forms[0].data.value;
  parent.SYS.document.forms[0].action.value = a;
  parent.SYS.document.forms[0].op.value = b;
  parent.SYS.document.forms[0].submit();
}
function menus(go,what) {
  if(what.selectedIndex) {
    var cur = what.options[what.selectedIndex].value;
    if(cur == 'prompt') {
      cur = prompt('How much?','');
      if(isNaN(cur) || cur < 1)
        return;
    }
    if(cur == '-prompt') {
      cur = -prompt('How much?','');
      if(isNaN(cur) || cur > -1)
        return;
    }
    if(cur == 0) {
      if(!confirm("Are you sure?")) {
        what.selectedIndex = 0;
        return;
      }
    }
    if(cur == 3)
      cur = prompt("File name to save as?",'');

    s(go,cur);
    what.selectedIndex = 0;
  }
}
</SCRIPT>
<FORM>
<TABLE WIDTH=100% BORDER=2 BGCOLOR="#CCCCCC"><TR><TD>
<SELECT ONCHANGE="menus('edit_update', this)">
<OPTION>File Options</OPTION>
<OPTION VALUE=2>Save</OPTION>
<OPTION VALUE=3>Save As</OPTION>
<OPTION VALUE=1>Save & Exit</OPTION>
<OPTION VALUE=0>Exit Without Saving</OPTION>
</SELECT>
</TD></TR></TABLE>
</FORM>
`;

    $out .= $self->{conf}{CONTENT}->html_footer;
    return \$out;
}

sub BINARY_ERROR {
    my $self = shift;
    my ($out);
    $out = $self->{conf}{CONTENT}->html_header;
    $out .= qq`<SCRIPT LANGUAGE=JAVASCRIPT>
alert("I'm sorry, but $self->{conf}{CURRENTEDIT} doesn't appear to be a text file. You will have to edit it another way.");
parent.close();
</SCRIPT>
`;
    $out .= $self->{conf}{CONTENT}->html_footer;
    return \$out;
}

sub CLOSE_AND_REFRESH {
    my $self = shift;
    my ($out);
    return $self->SYS() if($self->{conf}{save_error});

    $out = $self->{conf}{CONTENT}->html_header;
	
    $out .= qq`
<SCRIPT LANGUAGE=JAVASCRIPT>
//What a mess... anyone know a better way?
//parent.opener.parent.MAIN.location.reload()
parent.opener.parent.MAIN.location = "$self->{conf}{SCRIPT_NAME}$self->{conf}{COOKIE}/MAIN";
parent.close();
</SCRIPT>
`;
    $out .= $self->{conf}{CONTENT}->html_footer;
    return \$out;
}
sub _gen_list {
    my $self = shift;
    my $j = 0;
    my $out .= '';
    for(my $i = 0; $i < $#{$_[0]}; $i+=2) {
	$j = $i+1;
	$out .= '<OPTION';
	$out .= ' SELECTED' if $_[0]->[$j] =~ /^\s*\Q$_[1]\E\s*$/i;
	$out .= qq` VALUE="$_[0]->[$j]">$_[0]->[$i]</OPTION>\n`;
    }
    return $out;
}

sub encode {
    $_ = $_[1];
    s/(\W)/'%'.sprintf("%lx", ord($1))/ge;
    return $_;
}

sub decode {
    $_ = $_[1];
    s/\%([\da-fA-F][\da-fA-F])/chr(hex($1))/ge;
    return $_;
}

1;


