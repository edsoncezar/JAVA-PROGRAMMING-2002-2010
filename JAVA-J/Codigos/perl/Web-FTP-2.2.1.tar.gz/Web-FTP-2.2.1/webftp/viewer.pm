#!/usr/bin/perl

package viewer;

sub new {
    my %self;
    shift;
    %self = @_;
    $_ = bless \%self;
    return $_;
}

sub new_file {
    my $self = shift;
}

sub EDITMAIN {
    my $self = shift;
    $self->{conf}{CURRENTEDIT} =~ /([^\.]+)$/;
    my $ext = $1;
    if($ext && -f $self->{conf}{mimefile}) {
	open(MIME, $self->{conf}{mimefile}) or return;
	while(<MIME>) {
	    next if /^[\#\s]/;
	    next unless /\b\Q$ext\E\b/i;
	    $self->{contenttype} = ((split /\s+/, $_, 2)[0]);
	    $self->{contenttype} =~ s|^text/.*|text/plain|;
	    last;
	}
    }
    unless($self->{contenttype}) {
	if($self->{conf}{EDITDATA} =~ /[\x80-\xff]/) {
	    $self->{contenttype} = "Application/Octet-Stream";
	} else {
	    $self->{contenttype} = 'text/plain';
	}
    }
    $self->{conf}{specialheader} = "Connection: close\n";
    $self->{conf}{specialheader} .= qq`Content-Type: $self->{contenttype};name="$self->{conf}{CURRENTEDIT}"\n`;
    $self->{conf}{specialheader} .= qq`Content-Disposition: attachment;filename="$self->{conf}{CURRENTEDIT}"\n\n`;

    return \$self->{conf}{EDITDATA};
}

1;



