$prntvar = <<'endnote';

-------------------------- Number Converter --------------------------
                    programmed by Jonathan Untalan
 
NOTE: 1. Only digits except commas should be entered and no decimal 
         points are allowed.
      2. Leading zeros are allowed.(e.g. 00000 = 0, 0012,000 = 12,000) 
      3. Only these number formats are allowed:
               a. #000,000,000,... (e.g. 1,234,456,789)
               b. #0000000000...  (e.g. 123456789 - no commas allowed)
      4. Only numbers less than or equal of novemdecillion quantity can 
         be processed.
      5. All spaces entered will be ignored. (1   2  34 = 1,234)
endnote
print "$prntvar";
while (not uc($ans) eq("N"))
{
 #variable to contain answer whether to repeat the whole process again after conversion
  $ans = "";
 #counter used to contain the count of the split function result with comma as delimiter
  $ctr=0;
 #container of final result
  $finalresult="";
  print "\nEnter a number   : ";
  chomp($number=<STDIN>);
 #remove spaces
  $number=~s/\s+//g;
 #checking of null entry
  &Validate($number);
 #clone of user input
  $numberclone = $number;
 #remove leading zeros if there are any
  &removeLeadingZeros($numberclone);
 #temporaray array to contain split function result with comma as delimiter
  @arrdigit = split(/,/,$numberclone);
  
 #filters numbers of format #0000... and then separate them into groups of 3 in an array replacing @arrdigit
  if (($#arrdigit==0) && (length($arrdigit[0])>3)){ 
    @arrdigit = &formatInput(@arrdigit);
  }

 #gets last index of element in array to serve as comma count
  $ctr = $#arrdigit;

 foreach $x(@arrdigit)
 {
   $result="";
   $teen="N";
   $strlen=length($x);
   $num = $x;
   if ((($strlen >=1) && ($strlen <=3) && ($finalresult eq(""))) || (($finalresult ne("")) && ($strlen == 3)) || 
 (($#arrdigit == 0) && ($x eq("0"))) ){
       &interpretValue($strlen,$num,$result,$teen,$number);
     if ($x ne("000")) {
       &assignUnit($result,$ctr);
     }
           $ctr = $ctr - 1;
     if ($finalresult eq("")){
        $finalresult = $finalresult.$result;    
     } elsif (($finalresult ne("")) && ($ctr>=0) && ($result ne(""))){ 
        $finalresult = $finalresult.", ".$result;    
     } elsif (($finalresult ne("")) && ($result ne("")) && ($ctr==-1)){ 
        $finalresult = $finalresult.' & '.$result;    
     }
   } else {
     print "Invalid input: $number\n\n";
     goto ACTION; 
   }
   
 }

  if ($finalresult eq("")){
    print "Invalid input!\n\n";
  } 
  else{
    print "\n\t\tResults\n\n";
    print "\nAMOUNT IN DIGITS : $number\n";
    print "\nAMOUNT IN WORDS  : $finalresult\n\n";
  }

ACTION: print "\nDo you want to try again?[Y|N]: ";
chomp($ans=<STDIN>);
  if ($ans=~m/[^yYnN]/)
  { print "Invalid reply: $ans\n\n";
    goto ACTION;
  } elsif ($ans eq ""){
    print "Null reply!\n\n";
    goto ACTION;
  }
}

#arg0 - @arrdigit
sub formatInput {
 my $numtemp = $number;
 my $numtemp2 = "";
 my @tmpbuffer = $_[0];
 
  until (length($numtemp)<=3)
  {
     if ($numtemp2 ne("")){
       $numtemp2 = substr($numtemp,$#tmpbuffer-3,3)." ".$numtemp2;
     } else{
       $numtemp2 = substr($numtemp,$#tmpbuffer-3,3);
     }
     $numtemp = substr($numtemp,0,length($numtemp) - length(substr($numtemp,$#tmpbuffer-3,3)));
  }
     $numtemp2 = $numtemp." ".$numtemp2;
     return split(/ /,$numtemp2);
}

#arg0 - $numberclone
sub removeLeadingZeros{
 until ((length($_[0])==1) || (substr($_[0],0,1) ne("0")))
 {
   if (substr($_[0],0,1) eq("0")){
     $_[0] = substr($_[0],1);
     if ($_[0] eq("0")){
        print "\n\t\tResults\n\n";
        print "\nAMOUNT IN DIGITS : $number\n";
        print "\nAMOUNT IN WORDS  : zero\n\n";
        goto ACTION;
     }
   }
 }
}

#arg0 - $strlen,arg1 - $num,arg2 - $result,$arg3 - $teen,arg4 - $number
sub interpretValue{
  if ($_[0]==1){
   &ones($_[1],$_[2],$_[3],$_[4]); 
  } elsif ($_[0]==2){
   &tens($_[1],$_[2],$_[3]);
   &ones($_[1],$_[2],$_[3],$_[4]); 
  } elsif ($_[0]==3){
   &hundreds($_[1],$_[2]);
   &tens($_[1],$_[2],$_[3]);
   &ones($_[1],$_[2],$_[3],$_[4]); 
  } 
}

#arg0 - $result, arg1 - $ctr
sub assignUnit{
if ($_[0] ne("")){ 
 SWITCH: {
   ($_[1] == 0) && do {$_[0] = $_[0].""; last SWITCH;};
   ($_[1] == 1) && do {$_[0] = $_[0]." thousand"; last SWITCH;};
   ($_[1] == 2) && do {$_[0] = $_[0]." million"; last SWITCH;};
   ($_[1] == 3) && do {$_[0] = $_[0]." billion"; last SWITCH;};
   ($_[1] == 4) && do {$_[0] = $_[0]." trillion"; last SWITCH;};
   ($_[1] == 5) && do {$_[0] = $_[0]." quadrillion"; last SWITCH;};
   ($_[1] == 6) && do {$_[0] = $_[0]." quintillion"; last SWITCH;};
   ($_[1] == 7) && do {$_[0] = $_[0]." sextillion"; last SWITCH;};
   ($_[1] == 8) && do {$_[0] = $_[0]." septillion"; last SWITCH;};
   ($_[1] == 9) && do {$_[0] = $_[0]." octillion"; last SWITCH;};
   ($_[1] == 10) && do {$_[0] = $_[0]." nonillion"; last SWITCH;};
   ($_[1] == 11) && do {$_[0] = $_[0]." decillion"; last SWITCH;};
   ($_[1] == 12) && do {$_[0] = $_[0]." undecillion"; last SWITCH;};
   ($_[1] == 13) && do {$_[0] = $_[0]." duodecillion"; last SWITCH;};
   ($_[1] == 14) && do {$_[0] = $_[0]." tredecillion"; last SWITCH;};
   ($_[1] == 15) && do {$_[0] = $_[0]." quatuordecillion"; last SWITCH;};
   ($_[1] == 16) && do {$_[0] = $_[0]." quindecillion"; last SWITCH;};
   ($_[1] == 17) && do {$_[0] = $_[0]." sexdecillion"; last SWITCH;};
   ($_[1] == 18) && do {$_[0] = $_[0]." septendecillion"; last SWITCH;};
   ($_[1] == 19) && do {$_[0] = $_[0]." octodecillion"; last SWITCH;};
   ($_[1] == 20) && do {$_[0] = $_[0]." novemdecillion"; last SWITCH;};
   ($_[1] > 20) && do {
	  print "Number entered is more than a novemdecillion quantity! Conversion aborted.\n\n";
          goto ACTION;	
          };  
 }
}
}


#arg0 - $num, arg1 - $result
sub hundreds{
  my $temp=substr($_[0],0,1);

 SWITCH: {
   $temp eq("1") && do {$_[1] = "one hundred "; last SWITCH;};
   $temp eq("2") && do {$_[1] = "two hundred "; last SWITCH;};
   $temp eq("3") && do {$_[1] = "three hundred "; last SWITCH;};
   $temp eq("4") && do {$_[1] = "four hundred "; last SWITCH;};
   $temp eq("5") && do {$_[1] = "five hundred "; last SWITCH;};
   $temp eq("6") && do {$_[1] = "six hundred "; last SWITCH;};
   $temp eq("7") && do {$_[1] = "seven hundred "; last SWITCH;};
   $temp eq("8") && do {$_[1] = "eight hundred "; last SWITCH;};
   $temp eq("9") && do {$_[1] = "nine hundred "; last SWITCH;};
 }
   $_[0] = substr($_[0],1,2);
}

#arg0 - $num, arg1 - $result, arg2 - $teen
sub tens {
  my $temp=substr($_[0],0,1);

 SWITCH: {
   $temp eq("0") && do {$_[1] = $_[1].""; last SWITCH;};
   $temp eq("1") && do {$_[1] = $_[1].""; $_[2] = "Y"; last SWITCH;};
   $temp eq("2") && do {$_[1] = $_[1]."twenty"; last SWITCH;};
   $temp eq("3") && do {$_[1] = $_[1]."thirty"; last SWITCH;};
   $temp eq("4") && do {$_[1] = $_[1]."forty"; last SWITCH;};
   $temp eq("5") && do {$_[1] = $_[1]."fifty"; last SWITCH;};
   $temp eq("6") && do {$_[1] = $_[1]."sixty"; last SWITCH;};
   $temp eq("7") && do {$_[1] = $_[1]."seventy"; last SWITCH;};
   $temp eq("8") && do {$_[1] = $_[1]."eighty"; last SWITCH;};
   $temp eq("9") && do {$_[1] = $_[1]."ninety"; last SWITCH;};
 }
   $_[0] = substr($_[0],1,1);
}


#arg0 - $num, arg1 - $result, arg2 - $teen, arg3 - $number
sub ones {
  
  if ($_[2] eq("Y")){ 
     &special($_[0],$_[1]);
  } 
  else {   
    if ($_[0] eq("0")){
       if (($_[1] eq("")) && (length($_[3]) == 1)){
         $_[1] = "zero";
       }
    } elsif ($_[0] eq("1")){
       if ($_[1] eq("")){
         $_[1] = "one";
       } else{
           $_[1] = $_[1]." one";
       }
    } elsif ($_[0] eq("2")){
       if ($_[1] eq("")){
         $_[1] = "two";
       } else{
           $_[1] = $_[1]." two";
       }
    } elsif ($_[0] eq("3")){
       if ($_[1] eq("")){
         $_[1] = "three";
       } else{
           $_[1] = $_[1]." three";
       }
    } elsif ($_[0] eq("4")){
       if ($_[1] eq("")){
         $_[1] = "four";
       } else{
           $_[1] = $_[1]." four";
       }
    } elsif ($_[0] eq("5")){
       if ($_[1] eq("")){
         $_[1] = "five";
       } else{
           $_[1] = $_[1]." five";
       }
    } elsif ($_[0] eq("6")){
       if ($_[1] eq("")){
         $_[1] = "six";
       } else{
           $_[1] = $_[1]." six";
       }
    } elsif ($_[0] eq("7")){
       if ($_[1] eq("")){
         $_[1] = "seven";
       } else{
          $_[1] = $_[1]." seven";
       }
    } elsif ($_[0] eq("8")){
       if ($_[1] eq("")){
         $_[1] = "eight";
       } else{
           $_[1] = $_[1]." eight";
       }
    } elsif ($_[0] eq("9")){
       if ($_[1] eq("")){
         $_[1] = "nine";
       } else{
           $_[1] = $_[1]." nine";
       }
    }
  }
}

#arg0 - $num, arg1 - $result
sub special {
 SWITCH: {
   $_[0] eq "0" && do {$_[1] = $_[1]."ten"; last SWITCH;};
   $_[0] eq "1" && do {$_[1] = $_[1]."eleven"; last SWITCH;};
   $_[0] eq "2" && do {$_[1] = $_[1]."twelve"; last SWITCH;};
   $_[0] eq "3" && do {$_[1] = $_[1]."thirteen"; last SWITCH;};
   $_[0] eq "4" && do {$_[1] = $_[1]."fourteen"; last SWITCH;};
   $_[0] eq "5" && do {$_[1] = $_[1]."fifteen"; last SWITCH;};
   $_[0] eq "6" && do {$_[1] = $_[1]."sixteen"; last SWITCH;};
   $_[0] eq "7" && do {$_[1] = $_[1]."seventeen"; last SWITCH;};
   $_[0] eq "8" && do {$_[1] = $_[1]."eighteen"; last SWITCH;};
   $_[0] eq "9" && do {$_[1] = $_[1]."nineteen"; last SWITCH;};
 }
}

sub Validate {
  if ($_[0] eq("")) {
    print "Null input!\n\n";
    goto ACTION;
  }

  if (($_[0]=~m/[a-zA-Z]/) || ($_[0]=~m/\$/) || ($_[0]=~m/\#/) || ($_[0]=~m/\^/) || ($_[0]=~m/\+/) || ($_[0]=~m/\*/) || ($_[0]=~m/\?/) || ($_[0]=~m/\./) || ($_[0]=~m/\|/) || ($_[0]=~m/\(/) || ($_[0]=~m/\)/) || ($_[0]=~m/\{/) || ($_[0]=~m/\}/) || ($_[0]=~m/\//) || ($_[0]=~m/\\/) || ($_[0]=~m/\[/) || ($_[0]=~m/\]/) || ($_[0]=~m/\~/) || ($_[0]=~m/\@/) || ($_[0]=~m/\%/) || ($_[0]=~m/\&/) || ($_[0]=~m/\_/) || ($_[0]=~m/\-/) || ($_[0]=~m/\=/) || ($_[0]=~m/\:/) || ($_[0]=~m/\;/) || ($_[0]=~m/\>/) || ($_[0]=~m/\</) || ($_[0]=~m/\"/) || ($_[0]=~m/\`/) || ($_[0]=~m/\'/)){
    print "Invalid entry! Non-numeric characters were found.\n\n";
    goto ACTION;
  }  

}
