#!/usr/bin/perl -w
use strict;
$|++;

$_ = q/
	Base-X to Base-10 Converter
	Copyright 2001 Orhan Ayasli/;
print "$_\n\n";

print "Base: ";
while (<STDIN>) {
 print "Chomping Newline Character..";
 chomp;
 my $base = $_;
 print "Done.\n";
 print "Base-$base Value: ";
 while (<STDIN>) {
  print "Chomping Newline Character..";
  chomp;
  my $value = $_;
  print "Done.\n";
  print "Converting to Base-10..";
  my @value;
  if ($value =~ /\./) {
   @value = split(/\./,$value);
  } else {
   @value = split(//,$value);
  }
  $value = 0;
  for (0..$#value) {
   my $index = ((-$_)-1);
   my $digitvalue = (($base)**($_));
   $value += (($value[$index])*($digitvalue));
  }
  print "Done.\n";
  print "Base-10 Value: $value\n\n";
  last;
 }
 print "Base: ";
}