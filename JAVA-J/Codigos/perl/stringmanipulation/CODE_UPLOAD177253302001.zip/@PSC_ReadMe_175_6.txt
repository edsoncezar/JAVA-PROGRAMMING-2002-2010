Title: Base-X to Base10 Converter
Description: Base-X to Base10 Converter converts any number in any base to its Base10 Value. This includes IP addresses, which are in base 256 and have each "digit" seperated by periods ("."). 
Ex: 123.123.123.123 is an IP address in base 256. Converted to Base 10, that address has a value of 2071690107. The web browser accepts both base 256 and base 10 values of an IP address.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=175&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
