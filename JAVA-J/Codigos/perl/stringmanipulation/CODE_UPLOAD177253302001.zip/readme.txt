README

If I said "Knock on the door 12 times," you would knock on the door like so: "Knock! Knock! Knock! Knock! Knock! Knock! Knock! Knock! Knock! Knock! Knock! Knock!" You interpret the number 12 in base 10, which is what the default human base is. Saying "Knock on the door 12 times" is the same as saying "Knock on the door 12 base 10 times." But what if I said "Knock on the door 12 base 3 times"? "1, 2, 3, 4, 5, 6,..." in base 10 is counted as "1, 2, 10, 11, 12, 20,..." in base 3. That is because there are no digits in base 3 with a value larger than 2, just like there are no digits larger than 9 in base 10. So if you are counting, as soon as you hit three, you put a "1" in the "threes" place, just like you put a "1" in the "tens" place in base 10. The value of any number in any base is calculate by multiplying each digit by the its location. For instance, the value of 5678 in base 10 is 
(5 * (10**3)) +
(6 * (10**2)) +
(7 * (10**1)) +
(8 * (10**1)).
Notice how the "5", which is in the "thousands place", is being multiplied by one-thousand, and the "6", which is in the "hundreds place", is being multiplied by one-hundred, etc. This is equally implemented in other bases. The value of 5678 in base 71 is
(5 * (71**3)) +
(6 * (71**2)) +
(7 * (71**1)) +
(8 * (71**1)).
Base-X to Base10 Converter inputs the base and value, and calculates the value of the input in base 10 using the method showed above.
