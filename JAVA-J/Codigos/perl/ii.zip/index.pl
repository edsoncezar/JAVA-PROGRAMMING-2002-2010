#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
print "Content-type:text/html\n\n";
##################Settings##################
#The following are a list of texts, that are printed
#during the install

#Is printed for each file
#note [FILE] is replaced by the filename or directory
$text[0]="Creating [FILE]... [FILE] Created!<br>";

#Is printed when you first run the install script that is created by this #script
#You must fill out scriptname here
$text[1]= qq~
<html>
	<head>
	<title>[scriptname]:Installer</title>
	</head>
	<body bgcolor=444455>
<center>
	<table border=1 bordercolor=black>
		<tr>
			<td bgcolor="#EEEEEE" align=center>
			Welcome to [scriptname] installer!  Click below to install [scriptname] for the first time.  
			It does everything for you, dont worry!
			<br>
			<form action="[FILE]?install" method=post>
				<input type=submit value="Install">
			</form>
			</td>
		</tr>
	</table>
</center>
</body>
</html>
~; 
#This is printed during install
$text[2]=qq~
<html>
	<head>
	<title>[scriptname]:Installer</title>
	</head>
	<body bgcolor=444455>
<center>
	<table border=1 bordercolor=black>
		<tr>
			<td bgcolor="#EEEEEE" align=center>
			

~;
#this is printed printed after each name
$text[3]=qq~
			</td>
		</tr>
	</table>
</center>
</body>
</html>
~;
print_header();
&parse_form;
checkactions();
print_ender();
sub checkactions{
$action=$FORM{'action'};
&run if ($action eq "");
&level2 if ($action eq "new");
&level3 if ($action eq "level3");
&level4 if ($action eq "level4");
&level5 if ($action eq "level5");
}
sub print_header{
print qq~
<html>
<head>
<title>Echelon: Install Script Maker</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#444455" text="#000000">
<table width=100%><tr><Td valign=top align=center >
<table border=1 bordercolor=blue><tr><Td bgcolor="#EEEEEE">
   <font size="+1"><b> Echelon: Install Script Maker: Making a programmers life easier every day!</b></font></td>
  </tr></table></td></tr><tr><td align=center>
<br>
~;
}
sub run{
print qq~
<table border=1 bordercolor=black><tr><Td bgcolor="#EEEEEE" align=center>
What is the Name of the script your making an installer for?
<br>
<form action=index.pl method=post>
<input name=fname>
<br>
What is the filename of the script you wish to make an install script for?(must end in .pl or .cgi and have no spaces)
<input type=hidden name=action value=new>
<input name=name><br>
How many files will be in this installer?<br>
<input name=files><br>
Will you be making directories?<br>
Yes
<input type=radio name=dir value=yes>
No
<input type=radio name=dir value=no><br>
If so how many directories?<br>
<input name=dirnum><br>
<input type=submit value=Onwards!>
</form>
</td>
</tr>
</table>
~;
}
sub level2{
$file=$FORM{'name'}.".ech";
$fname=$FORM{'fname'};
do {
        open( FILE1, '>' . $file );
        close F;
    } unless -e $file;
print qq~
<table border=1 bordercolor=black><tr><Td bgcolor="#EEEEEE" align=center>
What are the names of the files you will be adding.
<form action=index.pl method=get>
<input type=hidden value=level3 name=action>
<input type=hidden value="$file" name=filename>
<input type=hidden value="$fname" name=fname>
<input type=hidden value="$FORM{'files'}" name=total>
<input type=hidden value="$FORM{'dirnum'}" name=dtotal>
~;
for($x=0; $x<$FORM{'files'}; $x++){
print qq~
<br>
<input name=$x>
~;
}

if($FORM{'dir'} eq "yes"){
print qq~
What are the names of each directory? (note to do subdirectories simple type the name of the original which counts as a spearate and 
must be entered in a separate field) then type '/' then the new directory name.  data/log would only make log, if you had already made data)
<br>~;

for($x=0;$x<$FORM{'dirnum'}; $x++){
$name="dir".$x;
print qq~
<input name=$name>
<br>
~;
}
}
print qq~
<br>
<input type=submit>
</form>
</td></tr></table>
~;
}
sub level5{
$file=$FORM{'filename'};
if($file=~m/\.pl/){
$file =~ s/(.*)\.ech/$1/;
}else{
$file =~ s/(.*)\.ech/$1.pl/;
}
$text[1]=~ s/(.*)\[FILE\](.*)/$1$file$2/g;
open( FILE1, '>' . $file );
print FILE1 q^#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
print "Content-type:text/html\n\n";
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
parse_form();
check_parse();
sub check_parse{
&install       if ($ENV{QUERY_STRING} eq "install");
&home if ($ENV{QUERY_STRING} eq "");
}
sub home{
print qq~^;
print FILE1 qq^$text[1]~;\n}^;
print FILE1 q^sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
    }
}
sub install{
^;
print FILE1 qq~
$text[2]
~;
for($x=0; $x<$FORM{'dtotal'}; $x++){
$dir="dir".$x;
$file=$FORM{$dir};
$mode = "755";
$text[0]=~ s/\[FILE\]/$file/g;
print FILE1 "mkdir ". $FORM{$dir}.", ".$mode .";\nprint\"" .$text[0]."\";\n"; 
$text[0]=~ s/$file/\[FILE\]/g;
}
for($x=0; $x<$FORM{'total'}; $x++){
$name="names".$x;
$path="path".$x;
$file=$FORM{$path}.$FORM{$name};
$text[0]=~ s/\[FILE\]/$file/g;
print FILE1 qq~
print "$text[0]<br>";
open( FILE1, '>>' . "$file2" );
print FILE1 <<END_FILEechelon;
$FORM{$x}
END_FILEechelon

~;
$text[0]=~ s/$file/\[FILE\]/g;
}
print FILE1 qq~
$text[3]
~;
print FILE1 "}";
}
sub level4{
$file=$FORM{'filename'};
if($file=~m/\.pl/){
$file =~ s/(.*)\.ech/$1/;
}else{
$file =~ s/(.*)\.ech/$1.pl/;
}
$text[1]=~ s/\[FILE\]/$file/g;
$text[1]=~ s/\[scriptname\]/$FORM{'fname'}/g;
open( FILE1, '>' . $file );
print FILE1 q^#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
print "Content-type:text/html\n\n";
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
parse_form();
check_parse();
sub check_parse{
&install       if ($ENV{QUERY_STRING} eq "install");
&home if ($ENV{QUERY_STRING} eq "");
}
sub home{
print qq~^;
print FILE1 qq^$text[1]~;\n}^;
print FILE1 q^sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
    }
}
sub install{
^;
$text[2]=~ s/\[scriptname\]/$FORM{'fname'}/g;
print FILE1 qq~

print qq*
$text[2]
*;
~;
if($FORM{'dtotal'} == 0 || $FORM{'dtotal'}==1){

}else{
for($x=0; $x<$FORM{'dtotal'}; $x++){
$dir="dir".$x;
$file=$FORM{$dir};
$mode = "755";
$text[0]=~ s/\[FILE\]/$file/g;
print FILE1 "mkdir ". $FORM{$dir}.", ".$mode .";\nprint\"" .$text[0]."\";\n"; 
$text[0]=~ s/$file/\[FILE\]/g;
}
}
for($x=0; $x<$FORM{'total'}; $x++){
$name="names".$x;
$path="path".$x;
$file=$FORM{$path}.$FORM{$name};
$text[0]=~ s/\[FILE\]/$file/g;
print FILE1 qq~
print "$text[0]<br>";
open( FILE1, '>>' . "$file" );
print FILE1 <<'END_FILEechelon';
$FORM{$x}
END_FILEechelon

~;
$text[0]=~ s/$file/\[FILE\]/g;
}
print FILE1 qq*
print qq&
$text[3]
&;
*;
#for($x=0; $x<$FORM{'total'}; $x++){
#$name="names".$x;
#print FILE1 q~
#$nae~;
#print FILE1 qq~[$x]=~;
#print FILE1 qq~"$FORM{$name}";\n~;
#}
#print FILE1 q~
#$mode="755";
#chmod @nae, $mode;
#~;
for($x=0; $x<$FORM{'total'}; $x++){
$name="names".$x;
print FILE1 q~
$nae[0]=~;
print FILE1 qq~"$FORM{$name}";\n~;
$chmod="chmod".$x;
print FILE1 q~
$mode=~;
print FILE1 qq~$FORM{$chmod};~;
print FILE1 q~
chmod (@nae, $mode);
~;
}

print FILE1 "}";
print qq~
All done!
~;
}

sub level3{
$file=$FORM{'filename'};
open( FILE1, '>' . $file );
print FILE1 <<END_FILE;
$FORM{'dtotal'}| 
END_FILE



for($x=0; $x<$FORM{'dtotal'}; $x++){
$name="dir".$x;
$print=$FORM{$name};
print FILE1 $print."|";
}
print FILE1 $FORM{'type'}."|";
print FILE1 $FORM{'total'}."|";
for($x=0; $x<$FORM{'total'}; $x++){
$name=$x;
print FILE1 $FORM{$x}."|";
}
$total=$FORM{'total'};
$dtotal=$FORM{'dtotal'};
print qq~
<table border=1 bordercolor=black><tr><Td bgcolor="#EEEEEE" align=center>
<form action=index.pl method=post>
<input type=hidden name=action value=level4>
<input type=hidden name=fname value="$FORM{'fname'}">
~;
print qq~
<input type=hidden name=total value="$total">
<input type=hidden name=dtotal value="$dtotal">
<input type=hidden name=filename value="$file">
What is the data for each file?(exactly as it will appear after install)<br>
~;
for($x=0;$x<$total;$x++){
$name="names".$x;
print qq~
<input type=hidden name=$name value=$FORM{$x}>

~;
}
for($x=0;$x<$dtotal;$x++){
$name="dir".$x;

print qq~
<input type=hidden name=$name value=$FORM{$name}>
~;
}
for($x=0;$x<$total;$x++){
print "$FORM{$x}<br>";
$path="path".$x;
$chmod="chmod".$x;
print qq~
The path(if not in base directory):<br>
<input name=$path><br>
What to chmod to?
<br>
<input name=$chmod>
<br>
The data:<br>
<textarea name=$x cols=40 rows=15>
</textarea>
<br>
<br>
<hr width=100%>
~;
}
print "<input type=submit>";
}
sub print_ender{
print "</td></tr></table>";
}
sub open_file {

    local ( $filevar, $filemode, $filename ) = @_;

    open( $filevar, $filemode . $filename );
}

sub read_file {

    local ($filevar) = @_;

    <$filevar>;
}

sub write_file {

    local ( $filevar, $line ) = @_;

    print $filevar ($line);

}
sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
        $name=$value; 
    }
}