### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Search
Version: 1.0

Info:

G.Search is a cool way to let your visitors search over 25 search engines, right 
from your very site. The script grabs the query page and includes a frame, so that 
your visitors never really leave your site.

Copy the code on in the code.html file




G.Scripts @ http://www.grantszone.co.uk/scripts/