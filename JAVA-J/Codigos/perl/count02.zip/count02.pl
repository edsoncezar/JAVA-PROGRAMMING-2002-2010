#!/usr/bin/perl 

$url  = '/fast/perl/count02/digits';
$ext  = 'gif';
$file = 'count.txt';

print "Content-type: text/html\n\n"; 

open( COUNT, $file ); $count = <COUNT>; close( COUNT ); ++$count; 
@nums = split( //, $count ); 

 foreach $num ( @nums ) { $display = "<img src=$url/$num.$ext>"; print $display; }   # image
#foreach $num ( @nums ) { $display = "$num"; print $display; }                       # text

open( NCOUNT, ">$file" ); 
print NCOUNT $count; 