#!/usr/bin/perl 
 
$site="http://www.echelondesign.net/index.cgi";  #Site to get the links from 
$outputfile="Output.ech";  #File that says if file is valid or not 
$outputdir="./Output/";    #were the pages are stored 
@keywords=('404','not found','error');      #Define words that = bad site 
 
########################################################### 
use LWP::Simple; 
my $data=get($site); 
my $fhost=$host; 
my $fsite=$site; 
$fhost=~ s/\///g; 
$fhost=~ s/://g; 
$fsite=~ s/\///g; 
$fsite=~ s/://g; 
if(!-d "$outputdir$fhost/"){ 
  mkdir "$outputdir$fhost/"; 
} 
open(file,">$outputdir$fhost/$fsite.html") || die ("couldnt print to $outputdir$fhost/$fsite $!"); 
print file $data; 
close(file); 
while($data=~ m/<a href=".*?">.*?<\/a>/){ 
  $data=~ s/<a href="(.*?)">.*?<\/a>/$1/; 
  $newhost=$1;  
  my $which=""; 
  $newsite=$newhost; 
  $ubersite=$newsite; 
  my $newdata=get($ubersite); 
  my $good="Good"; 
  my $reason=""; 
  foreach my $word (@keywords){ 
    if($newdata=~ m/$word/i){ 
 $good="Bad"; 
 $reason.=$word; 
    } 
  } 
  my $nsite=$newsite; 
  $newhost=~ s/\///g; 
  $newhost=~ s/://g; 
  $newhost=~ s/\?//g; 
  $newsite=~ s/\///g; 
  $newsite=~ s/://g; 
  $newsite=~ s/\?//g; 
  $newsite=~ s/\&//g; 
  mkdir "$outputdir/$newhost"; 
  open(file,">$outputdir$newhost/$newsite.html") || die ("couldnt print to $outputdir$newhost/$newsite.html $!"); 
    print file $newdata; 
  close(file); 
  open(file,">>$outputfile") || die("$!"); 
    print file "$ubersite | $good ($reason)\n"; 
 
  close(file); 
 
} 
