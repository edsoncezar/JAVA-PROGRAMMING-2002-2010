Welcome to the readme file for Sycro's Instant Messanger.

The script is fairly easy to install. If you use Telnet to upload, I am sorry, I cannot help you. This script has been or is being tested on every free server that offers CGI. Currently it has only been tested on Hypermart. If you are on Tripod, hold tight. I am going to re-write this scripts for ease on Tripod. Updates on compatibility will be added to the Instant Messanger page. If you have any problems, please visit:      http://sycros-scripts.hypermart.net

## Setup ##

1) Open up create.pl.
2) Change the first line to where perl is located on your server (currently #!/usr/local/bin/perl)
3) Change the variables. (they are described in script)
4) Open up im.pl and repeat steps 2 & 3.
5) Open up login.pl and repeat steps 2 & 3.
6) Open your FTP client.
7) Create an instant messanger directory inside of your cgi-bin (no certain name needed)
8) Upload all 4 files (3 ".pl"s and user file) to the above directory
9) Inside instant messanger directory, create a folder that you named in im.pl
10) Go to create.pl on your browser and create your username. 
11) Add links to create.pl and login.pl from your main page.
12) Enjoy!!

