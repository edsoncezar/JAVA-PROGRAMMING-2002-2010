#!/usr/local/bin/perl

#####################################################################
##										##
##	im.pl									##
##	Script Name: Sycro's Instant Messanger						##
##	Author: Sycro								##
##	Version: 1.5								##
##	Created: 12-18-00								##
##	Last Modified: 12-26-00							##
##	Location: http://sycros-scripts.hypermart.net					##
##										##
#####################################################################

## The users file
$userlog = "users.zip";

## The folder where the message data is stored
$data = "messages";

## The relative directory (NOT URL) to where this file is stored
## No end backslash
$dir = "/path/to/where/this/script/is";

## The file extension for your messages
$ext = "sim";

## The URL to your main page
$url = "http://www.yoursite.xxx";

## The title of your main page
$maintitle = "Sycro's Scripts";

## Basic Page Information
$title = "Sycro's Instant Messanger";
$bgcolor = "black";
$text = "white";
$link = "yellow";
$alink = "yellow";
$vlink = "yellow";
$banner = "";  ## Use \" instead of "

####################################################################
##			DO NOT EDIT BELOW HERE!					##
##		UNLESS YOU KNOW WHAT YOU ARE DOING!				##
####################################################################

## Store CGI.pm in $a
use CGI;
$a = new CGI();

## Set some values
$main = $title . ": Your Messages";
$clear = $title . ": Deleted Selected Message";
$send = $title . ": Send A Message";
$send2 = $title . ": Message Sent";
$userlist = $title . ": User List";

## Always check to see if the session has expired.
if ($a->cookie(-name=>'user')) {
	$log = 1;
}
if ($log != 1) {
	&error("your session has ended.");
}
$user = $a->cookie(-name=>'user');
$pass = $a->cookie(-name=>'pass');
$log = 0;
open(CHECK,"$dir/$userlog");
while(<CHECK>) {
	($tuser,$tpass,$email) = split(/\|/,$_);
	if ($user eq $tuser) {
		if ($pass eq $tpass) {
			$log = 1;
		}
	}
}
if ($log != 1) {
	&error("you enter incorrect login information.");
} 

## Name the input (not all are used every time)
$to = $a->param('to');
$message = $a->param('message');
$name = $a->param('name');
$delete = $a->param('num');
$msgtitle = $a->param('msgtitle');

## Redirect to the needed area
$re = $ENV{"QUERY_STRING"};
if ($re eq "main") { 
	&main;
}
if ($re eq "clear") {
	&clear;
}
if ($re eq "send") {
	&send;
}
if ($re eq "send2") {
	&send2;
}
if ($re eq "userlist") {
	&userlist;
}

sub main {
	print $a->header();
	print $a->start_html(-title=>$main, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	&links;
	print "<center><font size=3>Your Messages</font></center><br><br>\n";
	open(MESSAGES,"$data/$user.$ext");
	while(<MESSAGES>) {
		($num,$msgtitle,$from,$message) = split(/\|/,$_);
		print "<table>\n";
		print "<tr><td width=50\%><b><font size=4>$msgtitle</font></b></td><td>\n";
		print $a->startform(-action=>'im.pl?clear');
		print $a->hidden(-name=>'num', -value=>$num);
		print $a->submit(-value=>'Delete');
		print $a->endform();
		print "</td></tr></table>\n";
		print "<b><font size=-1>From: $from</font></b><br>\n";
		print "$message <br><hr>\n";
	}
	close(MESSAGES);
	print $a->end_html();
}

sub clear {
	open(DEL,"$dir/$data/$user.$ext");
	@lines = <DEL>;
	close(DEL);
	open(DEL,">$dir/$data/$user.$ext");
	foreach $line (@lines) {
		($tnum,$tmsgtitle,$tfrom,$tmessage) = split(/\|/,$line);
		if ($delete ne $tnum) {
			$num = $tnum;
			if ($delete lt $tnum) {
				$num = $tnum - 1;
			}
			print DEL "$num|$tmsgtitle|$tfrom|$tmessage\n";
		}
	}
	close(DEL);
	
	print $a->header();
	print $a->start_html(-title=>$clear, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	&links;
	print "<center><font size=3>Message Delete</font></center><br><br>\n";
	print "The message that you selected was deleted.\n";
	print $a->end_html;
}

sub send {
	@sendto = ();
	open(USERS,"$dir/$userlog");
	while(<USERS>) {
		($tuser,$tpass,$temail) = split(/\|/,$_);
		push(@sendto,$tuser);
	}
	close(USERS);

	print $a->header();
	print $a->start_html(-title=>$send, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	&links;
	print "<center><font size=3>Send a Message</font></center><br><br>";
	print $a->startform(-action=>'im.pl?send2');
	print "<table width=50\%>\n";
	print "<tr><td width=50\%>To:</td>\n";
	print "<td width=50\%>";
	print $a->popup_menu(-name=>'to', -values=>\@sendto);
	print "</td></tr>\n";
	print "<tr><td width=50\%>Subject:</td>\n";
	print "<td width=50\%>";
	print $a->textfield(-name=>'msgtitle');
	print "</td></tr>\n";
	print "<tr><td width=50\%>Message:</td>\n";
	print "<td width=50\%>";
	print $a->textarea(-name=>'message', -rows=>'5', -cols=>'30');
	print "</td></tr>\n";
	print "</table>\n";
	print $a->submit(-name=>'submit', -value=>'Send');
	print $a->endform();
	print $a->end_html();
}

sub send2 {
	open(SEND,"$dir/$data/$to.$ext");
	@tsend = <SEND>;
	close(SEND);

	($tnum,$tmsgtitle,$tfrom,$tmessage) = split(/\|/,$tsend[0]);
	$num = $tnum + 1;
	open(SEND,">$dir/$data/$to.$ext");
	print SEND "$num|$msgtitle|$user|$message\n";
	foreach $send (@tsend) {
		print SEND "$send\n";
	}
	close(SEND);

	print $a->header();
	print $a->start_html(-title=>$send2, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	&links;
	print "<center><font size=3>Message Sent</font></center><br><br>\n";
	print "Your message was sent to $to.";
	print $a->end_html();
}

sub userlist {
	print $a->header();
	print $a->start_html(-title=>$userlist, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	&links;
	print "<center><font size=3>User List</font></center>\n";
	print "<ul>\n";
	open(USERS,"$dir/$userlog");
	while(<USERS>) {
		($tuser,$tpass,$temail) = split(/\|/,$_);
		print "<li> $tuser\n";
	}
	print "</ul>\n";
	print $a->end_html();
}

sub links {
	print "<center>";
	print "[ <a href=im.pl?main> View Messages </a> ] ";
	print "[ <a href=im.pl?send> Send a Message </a> ] ";
	print "[ <a href=im.pl?userlist> View User List </a> ] ";
	print "[ <a href=$url> $maintitle </a>] ";
	print "</center><br>\n";
}

sub error {
	($error) = @_;
	print $a->header();
	print $a->start_html(-title=>'Error!', -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "I am sorry, but $error. Go <a href=\"javascript:history.back(2)\">back and correct the error.\n";
	print $a->end_html;
	exit;
}