#!/usr/local/bin/perl

#####################################################################
##										##
##	login.pl									##
##	Script Name: Sycro's Instant Messanger						##
##	Author: Sycro								##
##	Version: 1.5								##
##	Created: 12-18-00								##
##	Last Modified: 12-26-00							##
##	Location: http://sycros-scripts.hypermart.net					##
##										##
#####################################################################


## The relative directory (not URL) to where this script is
## No end backslash
$dir = "/path/to/where/this/script/is";

## User database
$userlog = "users.zip";

## The URL to where this script is located
## No end backslash
$url = "http://www.yoursite.xxx/this/script";

## Basic Page Information
$title = "Sycro's Instant Messanger";
$bgcolor = "black";
$text = "white";
$link = "yellow";
$alink = "yellow";
$vlink = "yellow";
$banner = "";  ## Use \" instead of "

####################################################################
##			DO NOT EDIT BELOW HERE!					##
##		UNLESS YOU KNOW WHAT YOU ARE DOING!				##
####################################################################

## Store CGI.pm into $a
use CGI;
$a = new CGI();

## Set some values
$login = $title . " Login";
$user = $a->param('user');
$pass = $a->param('pass');

## Check subroutines
$re = $ENV{"QUERY_STRING"};
if ($re eq "login") {
	&redirect;
} else {
	&login;
}

## Run login
sub login {
	print $a->header();
	print $a->start_html(-title=>$login, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "If you do not have an account, <a href=create.pl>create</a> one!<br>\n";
	print $a->startform(-action=>'login.pl?login');
	print "Username: ";
	print $a->textfield(-name=>'user');
	print "<br>\n";
	print "Password: ";
	print $a->password_field(-name=>'pass');
	print "<br>\n";
	print $a->submit(-name=>'submit', -value=>'Login');
	print $a->reset(-value=>'Reset');
	print $a->endform();
	print $a->end_html();
}

## Set cookie and redirect
sub redirect {
	open(CHECK,"$userlog");
	while(<CHECK>) {
		($tuser,$tpass,$temail) = split(/\|/,$_);
		if ($user eq $tuser) {
			if ($pass eq $tpass) {
				$log = 1;
			}
		}
	}
	close(CHECK);
	
	if ($log != 1) {
		&error("incorrect information was entered.");
	}
	
	$JSCRIPT = "<SCRIPT LANGUAGE=\"JavaScript\"><!--Begin\n window.location=\"$url/im.pl?main\"\;\n // End --></SCRIPT>";	
	$cookie1 = $a->cookie(-name=>'user', -value=>$user, -expires=>'+1h');
	$cookie2 = $a->cookie(-name=>'pass', -value=>$pass, -expires=>'+1h');
	print $a->header(-cookie=>[$cookie1,$cookie2]);
	print $a->start_html(-title=>'Redirect!', -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "$JSCRIPT\n";
	print "You are being redirected...<br>\n";
	print $a->end_html;
}

sub error {
	($error) = @_;
	print $a->header();
	print $a->start_html(-title=>'Error!', -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "I am sorry, but $error. Go <a href=\"javascript:history.back(1)\">back and correct the error.\n";
	print $a->end_html;
	exit;
}