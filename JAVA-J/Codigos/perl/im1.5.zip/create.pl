#!/usr/local/bin/perl

#####################################################################
##										##
##	create.pl									##
##	Script Name: Sycro's Instant Messanger						##
##	Author: Sycro								##
##	Version: 1.5								##
##	Created: 12-18-00								##
##	Last Modified: 12-26-00							##
##	Location: http://sycros-scripts.hypermart.net					##
##										##
#####################################################################

## The name of your userlog (create a text file and leave blank. rename with any ending to hide it)
$userlog = "users.zip";

## Mail program (check with your host for this)
$mailprog = "/var/qmail/bin/qmail-inject";

## Your email address (sent to new users - use \@ instead of @)
$admin = "name\@yoursite.xxx";

## The URL to where this script is located
## No end backslash
$url = "http://www.yoursite.xxx/this/script";

## Basic Page information 
$imtitle = "Sycro's Instant Messanger";
$bgcolor = "black";
$text = "white";
$link = "yellow";
$alink = "yellow";
$vlink = "yellow";
$banner = "";  ## Use \" instead of "

####################################################################
##			DO NOT EDIT BELOW HERE!					##
##		UNLESS YOU KNOW WHAT YOU ARE DOING!				##
####################################################################

## Set variable for using CGI.pm
use CGI;
$a = new CGI();

## Set some values
$sign = $imtitle . " Sign Up";

## Redirect
$go = $ENV{"QUERY_STRING"};
if ($go eq "new") {
	&new;
} else {
	&create;
}

## Subroutine to write the create page.
sub create {
	print $a->header();
	print $a->start_html(-title=>$sign, -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "<center><font size=5>Sign Up</font></center><br><br>\n";
	print $a->startform(-action=>'create.pl?new');
	print "<table width=50\%>\n";
	print "<tr><td width=25\%>Username:</td>\n";
	print "<td width=25\%>";
	print $a->textfield(-name=>'user', -size=>'20', -maxlength=>'20');
	print "</td></tr>\n";
	print "<tr><td width=25\%>Password:</td>\n";
	print "<td width=25\%>";
	print $a->password_field(-name=>'pass', -size=>'20', -maxlength=>'10');
	print "</td></tr>\n";
	print "<tr><td width=25\%>Email:</td>\n";
	print "<td width=25\%>";
	print $a->textfield(-name=>'email', -size=>'20', -maxlength=>'35');
	print "</td></tr>\n";
	print "<tr><td width=25\%>";
	print $a->submit(-name=>'create', -value=>'Create Account');
	print "</td>\n";
	print "<td width=25\%>";
	print $a->clear(-value=>'Clear Values');
	print "</td></tr>\n";
	print "</table>\n";
	print $a->endform();
	print $a->end_html();
}

## The subroutine to edit, check, add name, and email user
sub new {
	&edit;
	&check;
	&add;
	&mail;
	print $a->header();
	print $a->start_html(-title=>'Congratulations', -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "Congratulations, $user. You have just recieved a $imtitle account. You have been emailed with directions on how to login.\n";
	print $a->end_html;
}

## The subroutine to edit
sub edit {
	$user = $a->param('user');
	$pass = $a->param('pass');
	$email = $a->param('email');
	$user =~ tr/ /_/;
	$newpass = crypt($pass,az);
}

sub check {
	open(CHECK,"$userlog");
	while(<CHECK>) {
		($tuser,$tpass,$temail) = split(/\|/,$_);
		if ($user eq $tuser) {
			&error;
		}
	}
	close(CHECK);
}

sub add {
	open(ADD,">>$userlog");
	print ADD "$user|$pass|$email\n";
	close(ADD);
}

sub mail {
	open(MAIL,"| $mailprog -t");
	print MAIL "To: $email\n";
	print MAIL "From: $admin\n";
	print MAIL "Subject: Welcome to $imtitle\n\n";
	print MAIL "Hello, $user. You have a $imtitle account. Your information is below. Note: your username may have been slightly changed.\n";
	print MAIL "Username: $user\n";
	print MAIL "Password: $pass\n\n";
	print MAIL "To log in, go to $url/login.pl\n\n";
	print MAIL "=================================================================\n";
	print MAIL "This instant messanger is powered by Sycro's Instant Messanger.\n";
	print MAIL "You can get your copy at http://sycros-scripts.hypermart.net\n";
	print MAIL "=================================================================\n";
	close(MAIL);
}

sub error {
	$error = "that username is already taken.";
	print $a->header();
	print $a->start_html(-title=>'Error!', -bgcolor=>$bgcolor, -text=>$text, -link=>$link, -alink=>$alink, -vlink=>$vlink);
	print "$banner <br>\n";
	print "I am sorry, but $error. Go <a href=\"javascript:history.back(1)\">back and correct the error.\n";
	print $a->end_html;
	exit;
}