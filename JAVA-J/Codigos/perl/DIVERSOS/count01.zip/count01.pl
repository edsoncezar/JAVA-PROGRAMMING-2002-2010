#!/usr/bin/perl

############### - CUSTOMIZE - ###############

$visual  = "on";
$image   = "on";
$logdir  = "logs";
$url     = "digits";
$body    = "body bgcolor=#F0F0F0 text=#323232";
$font    = "font size=2 face=Verdana";

################# - DONE! - #################


#========== Script Structure ==========

$opt		= "$ENV{ 'QUERY_STRING' }";
$count_page	= "$ENV{ 'QUERY_STRING' }";

if ( $opt eq "stats" )  { 
	@files = ('logs/*.log');
	&get_files;
	&CalculateStats }
else { 
	&CountLog;
	&PrintCount; 
}

#========== Count Subroutines ==========

#---------- Open log file and print next number ----------
sub CountLog {
	local ($lock_file) = @_;
	local ($endtime);  
	$endtime = 10;
	$endtime = time + $endtime;
	while (-e $lock_file && time < $endtime) { }
    flock(LOCK_FILE, 2);

	open( LOG, "$logdir/$count_page.log" );
	@log_lines = <LOG>;
	close LOG;

	foreach $line( @log_lines ) {
		$next_number = $line +1;
	}
	
	if ($next_number < 1){
		$next_number = 1;
	}

	open( LOG, ">$logdir/$count_page.log" );
	print LOG "$next_number";
	close LOG;

	local ( $lock_file ) = @_;
	flock ( LOCK_FILE, 8 );
}

#---------- Visual ----------
sub PrintCount   {
	print "Content-Type: text/html \n\n";
	if ( $visual eq "on" )  { 
		if ( $image eq "on" ) { 
			&PrintImage; 
		} else { 
			&PrintText;
		}
	} 
	print ""; 
}

#---------- Graphic counter ----------
sub PrintImage {
	open( COUNT, "$logdir/$count_page.log" ); 
	$count = <COUNT>; 
	close(COUNT);  

	@nums = split( //, $count ); 
	foreach $num( @nums ) { 
		$display = "<img src=$url/$num.gif>"; 
		print $display;
	}	
}

#---------- Text Counter ----------
sub PrintText { 
	print "$next_number"; 
}


#========== Stats subroutines ==========

#---------- Get log files ----------
sub get_files  { 
	foreach $file ( @files )	{ 
		$ls = `ls $file`;
		@ls = split( /\s+/, $ls );
		foreach $temp_file( @ls ) {
			if( -d $file ) { 
				$filename = "$file$temp_file";
				if( -T $filename ) {
					push( @FILES, $filename );
				}
			} elsif( -T $temp_file ) {
				push( @FILES, $temp_file );
			}
		}
	}
}

#---------- Calculate and print stats ----------
sub CalculateStats  {
	print "Content-type: text/html\n\n";
	print "<$body>\n";
	print "<table border=0 cellpadding=0 cellspasing=0>\n";
	print "  <tr><td><$font><b>Page ID</b></td>\n";
	print "      <td><$font><b>Stats</b></td></tr>\n";
	$total = 0;
	foreach $FILE ( @FILES ) { 
		open( FILE, "$FILE" );
		@LINES = <FILE>;
		close( FILE );
		$string = join( ' ', @LINES );
		$total += $string;
		$Page = "$FILE";
		$Page =~ s/logs\///g;
		$Page =~ s/\.log//g;

		print "  <tr><td><$font>$Page</a></td>\n";
		print "      <td align=right><$font>$string</td></tr>\n"; 
	} 
	print "  <tr><td colspan=2><hr size=1></td></tr>\n";
	print "  <tr><td><$font>Total for all pages: </td>\n";
	print "      <td align=right><$font><b>$total</b></td></tr>\n"; 
	print "</table>\n"; 
}

exit;