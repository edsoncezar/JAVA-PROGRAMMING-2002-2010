###################################################################################
# Boltsearch v4.4e - Metasearch Engine - English Edition
###################################################################################
# Copyleft@ http://www.nix21.f2s.com - Patrick Hong.
###################################################################################
# v3.0e ->  A scorer had been made.
# v3.2e ->  Parser for Altavista had been modified.
# v3.3e ->  A scorer had been remade.
# v3.4e ->  Data receiving part's method changed lwp parallel useragent
# into socket, fork & (alarm - LWP has the error about timeout.).
# v3.5e -> You can select two "file locking methods" in "Unix's flock" or "file checking".
# v3.6e -> Fixed some errors.
# v3.7e -> Fixed parser for Google.
# v3.8e -> Fixed parser for Alltheweb.
# v3.9e -> Supporting Searchengine module.
# v4.0e -> Strengthened module-support function.
# v4.1e -> Strengthened module-support function & shows url on results page.
# v4.2e -> Added "open a link in new window." function, supports copyright footer function.
# v4.3e -> Fixed some fatal errors.
# v4.4e -> Added a timeout second(s) adjusting select box.
###################################################################################
# >>> Installation of this cgi-file.
###################################################################################
# [Step 1.]
# If you extracted "msrch44e.zip" successfully, maybe can see 4 lower directories which are "cache, modlist, modlist, mods"
# and 2 files which are "readmeen.txt, srchen.cgi, install.sh" when you typed "dir".
#
# >===============================<
# ex) <if you extracted "msrch44e.zip" under "/home/httpd/html/mometa" directory & typed "dir"....>
#
# ----
#
# [root@localhost mometa]# dir
# cache  count  install.sh  modlist  mods  readmeen.txt  srchen.cgi
# [root@localhost mometa]#
# >===============================<
#
# =:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
#
# [Step 2.]
# Just type "sh install.sh".
#
# >===============================<
# ex)
#
# ----
#
# [root@localhost mometa]# sh install.sh
# Install Completed.
# [root@localhost mometa]#
# >===============================<
#
# =:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
#
# [Step 3.]
# Run this cgi-file on web-browser.
# (ex : http://localhost/mometa/srchen.cgi).
###################################################################################




###################################################################################
# >>> Installation of modules.
###################################################################################
# Step 1.
# Download module files from "http://www.nix21.f2s.com/modules.html" & Copy these files to module files'(/home/httpd/html/mometa/mods) directory.
# -----------
# Step 2.
# add downloaded module files' list to modules list files'(/home/httpd/html/mometa/modlist) directory.
# ex) /home/httpd/html/mometa/modlist/web
# ============= [web]'s content
# altavista.mmo
# hotbot.mmo
# yahoo.mmo
# (..?..).mmo
# (..?..).mmo
# =============
# ------------
# Step 3.
# Run this cgi-file on web-browser & check (a) link(s) this cgi file's web path with module files' list file
# (ex : http://localhost/mometa/srchen.cgi).
# ------------
# End.
###################################################################################
# This script requires - Unix, Apache, Perl5 and a powerful web server.
###################################################################################