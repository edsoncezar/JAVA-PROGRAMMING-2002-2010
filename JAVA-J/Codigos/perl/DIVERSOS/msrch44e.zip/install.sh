#!/bin/sh
chmod 755 srchen.cgi
chmod 777 modlist
chmod 777 cache
chmod 777 mods
chmod 777 count
echo "Install Completed.";