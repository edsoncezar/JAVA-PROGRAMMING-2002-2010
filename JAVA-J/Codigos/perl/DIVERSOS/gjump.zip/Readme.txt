### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Jump
Version: 1.0

Info:

G.Jump is a way to let people get to different pages, without a 
list of links.

You use a form jump box that you can put as many links as you like.

Here is an example of the code, to place on your site:

<form action="http://www.yourdomain.co.uk/cgi-bin/gjump.cgi" method="get">
<select size="1" name="url">
<option value="http://www.yourdomain.co.uk/page1.html">Page 1</option>
<option value="http://www.yourdomain.co.uk/page2.html">Page 2</option>
<option value="http://www.yourdomain.co.uk/page3.html">Page 3</option>
<option value="http://www.yourdomain.co.uk/page4.html">Page 4</option>
<option value="http://www.yourdomain.co.uk/page5.html">Page 5</option>
</select>
<p>
<input type="submit" value="Jump">
</form>

The script will then redirect you to that link.


G.Scripts @ http://www.grantszone.co.uk/scripts/