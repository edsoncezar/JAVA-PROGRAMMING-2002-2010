# README FILE 
#
# DCForum2000 Version 1.0 Beta by DCScripts (TM)
# Copyright  �1997-2000 DCScripts All Rights Reserved
#
# As part of the installation process, you will be asked
# to accept the terms of this Agreement. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts and DCForum.
# You should carefully read the following terms and conditions before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of the Software.
#
# VERSIONS OF SOFTWARE
#-----------------------------------------------------------------------
# Only one copy of the registered version of DCForum may used
# on one web site owned by one owner or an entity.
#
# LICENSE TO REDISTRIBUTE
#-----------------------------------------------------------------------
# Distributing the software and/or documentation with other products
# (commercial or otherwise) or by other than electronic means without
# DCScripts's prior written permission is forbidden.
# All rights to the DCForum software and documentation not expressly
# granted under this Agreement are reserved to DCScripts.
#
# DISCLAIMER OR WARRANTY
#-----------------------------------------------------------------------
# THIS SOFTWARE AND ACCOMPANYING DOCUMENTATION ARE PROVIDED "AS IS" AND
# WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER
# WARRANTIES WHETHER EXPRESSED OR IMPLIED.   BECAUSE OF THE VARIOUS HARDWARE
# AND SOFTWARE ENVIRONMENTS INTO WHICH DCFORUM MAY BE USED, NO WARRANTY OF
# FITNESS FOR A PARTICULAR PURPOSE IS OFFERED.  THE USER MUST ASSUME THE
# ENTIRE RISK OF USING THIS PROGRAM.  ANY LIABILITY OF DCSCRIPTS WILL BE
# LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.
# IN NO CASE SHALL DCSCRIPTS BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR
# CONSEQUENTIAL DAMAGES OR LOSS, INCLUDING, WITHOUT LIMITATION, LOST PROFITS
# OR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, WHETHER SUCH DAMAGES ARE
# BASED UPON A BREACH OF EXPRESS OR IMPLIED WARRANTIES, BREACH OF CONTRACT,
# NEGLIGENCE, STRICT TORT, OR ANY OTHER LEGAL THEORY. THIS IS TRUE EVEN IF
# DCSCRIPTS IS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO CASE WILL
# DCSCRIPTS'S LIABILITY EXCEED THE AMOUNT OF THE LICENSE FEE ACTUALLY PAID
# BY LICENSEE TO DCSCRIPTS. 
#
###################################################################################

DCForum Bulletin Board System -- FOR UNIX, Linux, and Windows NT

Introduction
======================================================================

DCForum is a discussion forum program written in Perl.
DCForum supports web servers running on both UNIX (LINUX, 
SOLARIS, FREEBSD, etc) and NT platforms.  The only requirement
for running DCForum is that your web server supports Perl CGI 
applications.  If you're not sure if you can run Perl CGI programs 
on your server, please first ask your ISP before you try to install DCForum.

The main differences between UNIX and NT implementation of DCForum 
are the following:

1) At the time of this release, NT does not support PERL's crypt function
   Hence the passwords are kept as clear text in the user database.

2) File uploading feature does not work under NT.  We are currently in the
   process of determining why our implementation doesn't work.  
   Patch will be available as soon as we get it to work

DCF2000 Overview
========================================================================

Features:
-----------

NEW for DCF2000

- New comprehensive Administrator User's guide
- Support for multiple template files
- Installer help - to determine $cgidir and $maindir
- Modular programming
- Email support for NT without needing blatmail
- Email topic to friend
- Topic to topic navigation feature
- Thread Locking and Unlocking
- Fully Moderated Forums (aka Message Queueing)
- IP logging and blocking
- Forum Subscription - users can subscribe to any one or more forums.
- User activity logging - Keeps track of user activities such as POSTING and LOGIN.
- Multiple Moderators
- Ability to sort topics by any fields
- Email list manager
- Integrated Emailer - which will *hide* user email addresses
- Backup/recover utility for backing important forum files such as forum_info.txt
- Rebuild database utility for rebuilding lost database.txt
- Simple scripted tags - to use HTML tags, use <> brackets.
- Optional records of number of message views
- More emotion icons with help link
- Better URL linker
- New admin interface
- Display all user profiles
- Optional Topic rating system
- Option to archive old posts instead of deleting them
- Announcement Manager
- Forum shutdown/start option
- Better Update Threads
- Better Conference and forum manager
- Password retrieval system
- Optional Expand or Collapse Threading in Main Listing

General Features:

- Conference - Grouping of Forums.
- Printer Friendly Format
- Optional fully threaded main listing
- Topic Autosensing
- Option to use classic text threading in the table of contents
- Added text navigation menu to the top of lobby and main listing
- Supports Multiple Forums
- Efficient implementation, fast performance (99)
- Clean and intuitive user interface (99)
- Ease to customize - all you need to know is HTML
- Fully threaded discussion (with option to set it to Linear)(99)
- Three levels of forum types - public, protected*, and private*
- Three-level navigation - Lobby, Main, and Topic
- Topics stored as both text-delimited database file (99) and html file
- Autopruning of current topics
- Archiving feature 
- Optional Icon Packs - user submitted icons

Bulletin Board Features:

- Easy to navigate
- Option to use icon menu (default) or use hyperlinked text
- Option to indent messages in threads - Some like it, some don't.
  Well, you can indent messages if you like to, or just use 
  the classic DCForum format.
- Caption or Subject listing - Caption displays first 150 characters
  in the main listing.
- Extensive search capability - Keyword search by author, subject, 
  and message. Keyword search one forum or all.  Keyword search archive.
- Option to allow HTML
- Intellink - automatically links URLs
- Option to allow image links
- Bad word filter (99)
- Date format - you can now specify one of four different date formats (99):
  Jan-30-99, 30-Jan-99, 01-30-99, 30-01-99
- 'Team' user group - You can assign certain users to 'Team' user group.
  When they post messages or replies, they will be denoted by an 
  image of little red flag (team.gif).  Great for support staff (99).
- Smiley and sad faces :-) and :-(

Users:

- DCUser user menu* (99) allows users to change their password, account info, and
  their profile.
- User Profile* (99)
- User Signature Block* (99)
- Alert feature*
- Edit capability*
- Reply with quote capability
- EMail notification (99)
- Option to display original message in the post form (99)

Administration features:

- Extensive forum administration capability using only the browser
- Forum security manager - set registration and email options
- Forum attribute manager - set forum colors, font size, etc
- User manager - manage your registered user database
- Forum manager - create, modify, reorder, and remove forums
- Private forum user manager (99) - For admin and moderators for adding
  and removing users from private forum access list
- Board manager - move, remove, and archive 
- Unique to DCForum - InstaManage!  Remove and archive topics or messages
  in topic from that page without starting dcadmin.  Just clicking on an icon!


To learn more about administration and forum setup, refer to admin.html
in the /htdocs/dcforum directory.
----------------------------------------------------------------------

DCForum Files 
========================================================================
DCForum includes following files:

General files
-----------------
- readme.txt - this file
- install_nt.txt - installation file for NT server
- install_unix.txt - installation file for UNIX server
- upgrade_99_00.txt - FOR OWNERS OF DCFORUM99 ONLY!!!

Setup files
-----------------
- dcforum.setup - Setup file for configuring dcforum.  
  This file is used by dcboard.cgi and dcadmin.cgi files

Script files
-----------------
- install_help.cgi - an interactive program to help you find
                     $cgidir and $maindir
- dcadmin.cgi - administration script
- dcboard.cgi - main BBS engine for navigating

Library files
-----------------
- 87 library files included in the distribution

Template file
-----------------
- dcforum.htmlt - template file.  This is just an HTML file with few
    markers.  It is given htmlt extension to remind you that it is
    an html template file.

Image files
-----------------
- Various *.gif image files

Misc files in Utilities/DCF2000
-----------------
  >>> convert_forum_99_00.cgi is needed if you are upgrading
      from dcforum99 ver 1.1 to dcf2000
  >>> convert_database_99_00.cgi is needed if you are upgrading
      from dcforum99 ver 1.1 to dcf2000

Misc files in Utilities/DCF99Utilities
-----------------
  >>> convert_98_99.cgi is needed if you are upgrading
      from dcforum98 to 99
  >>> convert_98_99.cgi is needed if you are upgrading
      from dcforum98 to 99
  >>> conv_database.cgi is needed if you are upgrading
      from Release 1.000 and 1.001
  >>> conv_97N_99.cgi is needed if you are upgrading from
      DCForum97N
  >>> test_nt.cgi is needed to test and see if your NT server
      is configured properly
  >>> test.cgi is a simple diagnostic script


Installing and Setting up DCForum
========================================================================
>>>>>>>>>>>>>>>>>  PLEASE NOTE  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
If you are upgrading from DCForumLite Ver 2.0, do not follow
the instruction in this readme file.  You must follow the instruction
given in upgrade_lite2_99.txt file to upgrade to DCF99, and then use
upgrade_99_00.txt to upgrade from 99 to 2000.

>>>>>>>>>>>>>>>>>  PLEASE NOTE  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
If you are upgrading from DCForum97N, do not follow
the instruction in this readme file.  You must follow the instruction
given in upgrade_97N_99.txt file to upgrade to DCF99, and then use
upgrade_99_00.txt to upgrade from 99 to 2000.

>>>>>>>>>>>>>>>>>  PLEASE NOTE  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
If you are upgrading from DCForum98, do not follow
the instruction in this readme file.  You must follow the instruction
given in upgrade_98.txt file to upgrade to DCF99, and then use
upgrade_99_00.txt to upgrade from 99 to 2000.

>>>>>>>>>>>>>>>>>  PLEASE NOTE  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
If you are upgrading from DCForum99 Ver 1.x, do not follow
the instruction in this readme file.  You must follow the instruction
given in upgrade_99_00.txt file.

For NT installation, see install_nt.txt
All others, see install_unix.txt


Linking DCForum from other pages
========================================================================
Bulletin Board: http://www.yourdomain.com/pathtodcforum/dcboard.cgi
Administraion: http://www.yourdomain.com/pathtodcforum/dcadmin.cgi

For example, our support forum is at
http://www.dcscripts.com/cgi-bin/dcforum/dcboard.cgi

NOTE: When you log on to dcboard.cgi as the admin, the dcadmin 
link will appear in the LOBBY and MAIN as a button icon.  You can
then access admin via this icon.  This icon is invisible to
other users who do not have 'admin' user group.

Contacting DCScripts
========================================================================
Should there be problems during installation please
check out our support forum at

http://www.dcscripts.com/cgi-bin/dcforum/dcboard.cgi

========================================================================
DCForum2000 �1997-2000 DCScripts, All rights Reserved 
