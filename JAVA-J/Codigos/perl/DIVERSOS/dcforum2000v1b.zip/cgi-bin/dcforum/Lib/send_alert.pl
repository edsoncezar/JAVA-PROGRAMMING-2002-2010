# send_alert.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#
# send_alert
# script to handle sending bad posting alert
#======================================================================#

sub send_alert {

   require "$cgilib/dcforumlib2.pl";

   my ($r_in,$r_setup) = @_;
   my $html_output;

   # Will have to fix this one.
   my $moderator_email = $r_setup->{'forum_owner_email'}->{$forum};

   my $username = $r_in->{'userdata'}->{'Username'};

   print_header();
   print_header_end();
   
   my $mail_output .= qq~  
Following Alert message was sent by userID $username:
----------------------------------------------------
$r_in->{'alert_message'}
----------------------------------------------------
$username's Comment/Reason:
----------------------------------------------------
$r_in->{'reason'}
~;

   send_mail($password_file_dir,$r_setup->{'auth_sendmail_path'},
            $r_setup->{'auth_admin_email_address'},
            $r_setup->{'auth_admin_email_address'},
            "BAD MESSAGE ALERT from $username",$mail_output );

   if ($moderator_email) {
      send_mail( $password_file_dir,$r_setup->{'auth_sendmail_path'},
            $r_auth->{'auth_admin_email_address'},
            $moderator_email,
            "BAD MESSAGE ALERT from $username",$mail_output );
   }

   $html_output .= "<h3 align=center>[ <a href=\"$boardurl\">Go Back to Main</a> ]</h3>\n";

   return ($heading, $sub_heading, $html_output,$menu_button);

}

1;