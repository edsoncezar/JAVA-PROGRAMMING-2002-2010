# admin_customize_emails.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#===================================================================
# admin_customize_emails
# admin utility for managing email messages for:
# -- Email notifications
# -- Email registration
# -- Lost password
#===================================================================

sub admin_customize_emails {

	my ($r_in,$r_setup) = @_;
	my $html_output;

	print_header();
	print_header_end();
	
	$html_output = qq~
	   <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
	   <TR>
	      <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="CENTER" COLSPAN="3">
			<font size="$font_size_3" face="$font_face_3" color="$font_color_3">
			<B><font size="3">Email Message Manager</font></b><br>
			</font></TD></TR></table>~;


	if ($r_in->{'command'} eq 'save') {

		my $r_data = [];
		push(@{$r_data},"$r_in->{'subject'}\n");
		$r_in->{'message'} =~ s/\r//g;
		push(@{$r_data},$r_in->{'message'});
		writedata("$password_file_dir/$r_in->{'file'}",$r_data);
		$html_output .= print_status("$r_in->{'file'} has been updated");
	}
	# If $r_in->{'command'} is still not empty, then it is edit
	elsif ($r_in->{'command'} eq 'edit') {

	   my $r_data = readdata("$password_file_dir/$r_in->{'file'}");
		chomp(@{$r_data});
		my $subject = shift(@{$r_data});
		my $message = join("\n",@{$r_data});
		$html_output = qq~
		<FORM ACTION="$adminurl" METHOD=POST>
		<input type="hidden" name="az" value="$r_in->{'az'}">
		<input type="hidden" name="command" value="save">
		<input type="hidden" name="file" value="$r_in->{'file'}">
	   <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
		   <TR>
		      <TH BGCOLOR="$bg_color_0" ALIGN="LEFT" VALIGN="TOP" Colspan="3">
				<font size="$font_size_0" face="$font_face_0" 
					color="$font_color_0">
				Modify $r_in->{'file'}
				</font>
		      </TH>
		   </TR>
		   <TR>
		      <TH BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP" COLSPAN="3">
				<font size="$font_size_3" face="$font_face_3" 
					color="$font_color_3">
				Subject:<br></font>
				<input type="text" name="subject" size="60" value="$subject">
				</TH></TR>
		   <TR>
		      <TH BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP" COLSPAN="3">
				<font size="$font_size_3" face="$font_face_3" color="$font_color_3">
				Message:</font><BR>
				<textarea name="message" rows="20" 
				cols="60" wrap="physical">$message</textarea>
		   </TR>
		   <TR>
		      <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
				&nbsp;
				</td>
		      <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP" COLSPAN="2">
				<input type="submit" value="Submit">
				<input type="reset" value="Reset">
				</td>
		   </TR>
			
			</TABLE>
			</FORM>
			~;


	}			
	else {

		$html_output .= qq~
		<FORM ACTION="$adminurl" METHOD=POST>
		<input type="hidden" name="az" value="$r_in->{'az'}">
		<input type="hidden" name="command" value="edit">
	   <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
		   <TR>
		      <TH BGCOLOR="$bg_color_0" ALIGN="CENTER" VALIGN="TOP">
				<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
				Select
				</font>
		      </TH>
		      <TD BGCOLOR="$bg_color_0" ALIGN="CENTER" VALIGN="TOP">
				<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
				Email message to edit
				</font>
		      </TD>
		   </TR>
			<TR>
			      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
					<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
					<input type="radio" name="file" value="$email_registration_file">
					</font></TD>
			      <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP" width="100%">
					<font size="$font_size_1" face="$font_face_1" color="$font_color_1">
					Email registration message
					</font>
			      </TD>
			   </TR>

			<TR>
			      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
					<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
					<input type="radio" name="file" value="$email_notification_file">
					</font></TD>
			      <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP" width="100%">
					<font size="$font_size_1" face="$font_face_1" color="$font_color_1">
					Email notification message
					</font>
			      </TD>
			   </TR>

			<TR>
			      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
					<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
					<input type="radio" name="file" value="$account_action_file">
					</font></TD>
			      <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP" width="100%">
					<font size="$font_size_1" face="$font_face_1" color="$font_color_1">
					Account status change email message
					</font>
			      </TD>
			   </TR>

			<TR>
			      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
					<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
					<input type="radio" name="file" value="$subscription_message_file">
					</font></TD>
			      <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP" width="100%">
					<font size="$font_size_1" face="$font_face_1" color="$font_color_1">
					Subscription email message
					</font>
			      </TD>
			   </TR>

			<TR>
			      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
					<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
					<input type="radio" name="file" value="$lost_password_file">
					</font></TD>
			      <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP" width="100%">
					<font size="$font_size_1" face="$font_face_1" color="$font_color_1">
					Lost password email message
					</font>
			      </TD>
			   </TR>
			<TR>
		      <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP" colspan="3">
				<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
				<input type="submit" value="Select">
				<input type="reset" value="Reset">
				</font></TD>
			</TR>~;

		$html_output .= "</table></Form>";
		

	}

	$html_output;	

}


1;