# admin_move_threads.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#
#======================================================================#
# admin_move_threads                                                   #
# admin utility for moving threads                                     #
#======================================================================#

sub admin_move_threads {

	my($dummy,$r_in,$r_setup) = @_;
	my(@newrow);

  my $from_file =
		"$maindir/$r_in->{'forum'}/$database";

  my $to_file =
		"$maindir/$r_in->{'forum_to'}/$database";

  my $to_file_counter =
		"$maindir/$r_in->{'forum_to'}/$r_in->{'counter'}";

	my $html_output = "";
	my $maindir = $maindir;
	my $ext = $r_in->{'ext'};
	my $from_forum = $r_in->{'forum'};
	my $to_forum = $r_in->{'forum_to'};
	my $forum_dir = $password_file_dir;
	my $forum_file = $forum_file;
	my $filename;
	my @arc_row;
   my @FILE_MOVED,@NO_FILE,@NOT_MOVED;

	#Read in destination data counter file

   open(NUMBER,"$to_file_counter");
   flock(NUMBER,2);
      $num = <NUMBER>;
   flock(NUMBER,8);
   close(NUMBER);

   $num++;

   if ($num == 999999)  {
      $num = "1";
   }

	my @file_selected = split(/\0/,$r_in->{'selected'});

	# read in from database
	my $r_fromdata = readdata($from_file);
	my $r_todata = readdata($to_file);

	# number of threads which will move
	my $num_threads = @file_selected;
	my $num_posts = 0;
   my $file_num;

	foreach $row (@{$r_fromdata}) {

		 $hit = "no";
		 chomp($row);
		 foreach (@file_selected) {
			  if ($row =~ /^$_$split_delim/) {
           		$file_num = $_;
				   $hit = 'yes';
				   last;
			  }
		 }#End of foreach

		 unless ($hit eq 'yes') {
			  push(@newrow,"$row\n");
		 }
		 else {
		 
			  my @fields = split(/$split_delim/,$row);
			  $num_posts++;
			  $num_posts += $fields[7];
			  $fields[0] = $num;
           $row = join("$join_delim",@fields);
			  unshift(@{$r_todata},"$row\n");
			  $filename = "$maindir/$from_forum/$thread_dir/$file_num\.$thread_ext";
		     if (-e $filename) {
			     rename("$maindir/$from_forum/$thread_dir/$file_num\.$thread_ext",
							"$maindir/$to_forum/$thread_dir/$num\.$thread_ext");
			  	  $forum = $to_forum;
				  $r_in->{'om'} = $num;
				  create_message($r_in,$r_setup);
			     push(@FILE_MOVED,$file_num);
				# Move email notification list
					if (-e "$maindir/$from_forum/$email_dir/$file_num.$email_ext") {
						rename("$maindir/$from_forum/$email_dir/$file_num.$email_ext",
								"$maindir/$to_forum/$email_dir/$num.$email_ext");
					}
		     }
		     else {
			     push(@NO_FILE,$file_num);
            }#end of if -e filename

        $num++;

     }# end of if $hit ne 

	 }#End of foreach rowdata

# First write data

	writedata($from_file,\@newrow);
	writedata($to_file,$r_todata);
	
   open(NUMBER,">$to_file_counter");
   flock(NUMBER,2);
			print NUMBER $num;
   flock(NUMBER,8);
   close(NUMBER);

	unless ($r_in->{'archive'}) {
		$r_setup->{'forum_threads'}->{$from_forum} = 
			$r_setup->{'forum_threads'}->{$from_forum} - $num_threads;
		$r_setup->{'forum_posts'}->{$from_forum} = 
			$r_setup->{'forum_posts'}->{$from_forum} - $num_posts;
		$r_setup->{'forum_threads'}->{$to_forum} = 
			$r_setup->{'forum_threads'}->{$to_forum} + $num_threads;
		$r_setup->{'forum_posts'}->{$to_forum} = 
			$r_setup->{'forum_posts'}->{$to_forum} + $num_posts;
	}
	else {
		$r_setup->{'forum_archive'}->{$from_forum} = 
			$r_setup->{'forum_archive'}->{$from_forum} - $num_threads;
		$r_setup->{'forum_archive'}->{$to_forum} = 
			$r_setup->{'forum_archive'}->{$to_forum} + $num_threads;
	}

   save_forum_info("$forum_dir/$forum_file",$r_setup);

	my $file_selected = join("\, ",@file_selected);
   my $file_moved = join("\, ",@FILE_MOVED);
   my $not_moved = join("\, ",@NOT_MOVED);
   my $no_file = join("\, ",@NO_FILE);

	$html_output .= qq~
   	<table border="0" cellpadding="3" width="100%">
		<tr>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_0">
		  	<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
			Selected Files</font>
			</th>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_0">
						  	<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
			Moved Files</font>
			</th>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_0">
		  	<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
			File Not Moved</font>
			</th>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_0">
		  	<font size="$font_size_0" face="$font_face_0" color="$font_color_0">
			File Not Found</font>
			</th>
		</tr>
		<tr>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_2">
		  	<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
				$file_selected</font>
			</td>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_2">
		  	<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
				$file_moved</font>
			</td>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_2">
		  	<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
				$not_moved</font>
			</td>
		  <Th ALIGN="CENTER" BGCOLOR="$bg_color_2">
		  	<font size="$font_size_2" face="$font_face_2" color="$font_color_2">
				$no_file</font>
			</td>
		</tr>
		<tr>
		  <TD ALIGN="CENTER" BGCOLOR="$bg_color_0" colspan="4">
			&nbsp;
			</td>
		</tr>
	</table>
  <hr size="1">
  </CENTER>
   ~;


	$html_output;
}



1;