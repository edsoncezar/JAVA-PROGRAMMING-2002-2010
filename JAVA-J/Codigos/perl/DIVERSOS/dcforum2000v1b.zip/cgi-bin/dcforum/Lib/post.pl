# post.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#


#======================================================================#
# function post                                                        #
# display post form for the user                                       #
#======================================================================#

sub post {

   my ($r_in,$r_setup) = @_;
   my ($omm,$level,$subject,$name,$email,$ltime,$date,$body);
   my $r_profile ={};
   my $heading = $forum_title;
   my $sub_heading = "Compose your message";
   my $html_output, $menu_button;

   require "$cgilib/dcforumlib2.pl";
#  require "$cgilib/rand_lock.pl";

   $menu_button = create_button('help',$r_in,$r_setup);

   # Check user   
   $r_in->{'userdata'} = check_user($r_in,$r_setup);

   print_header();
   print_header_end();

   # Randong Number lock used for double posting
   # see if this will be a problem
   #  $r_in->{'rand1'} = get_rand_lock();

   # If user profile exists, then go get
   # user's signature block

   if (-e "$profile_dir/$r_in->{'userdata'}->{'Username'}.$profile_ext") {
      $r_profile = 
         get_userdata("$profile_dir/$r_in->{'userdata'}->{'Username'}.$profile_ext");
         $r_profile->{'Signature'} = dcf99_dcf00($r_profile->{'Signature'});
         $r_profile->{'Signature'} = text_to_form($r_profile->{'Signature'});
   }

   # If om is not empty, then this is a reply
   if ($r_in->{'om'}) {
     ($omm,$level,$subject,$name,$email,$ltime,$date,$body) = 
         get_record("$maindir/$forum/$thread_dir/$r_in->{'om'}.$thread_ext",$r_in->{'omm'});
         $subject = dc_decode($subject);
   }

   $ltime = time_format($ltime);
   $date = date_format($date);

   $html_output ="<p>";

   if ($r_setup->{'show_orig_mesg'} eq 'on' && $r_in->{'om'}) {
      # Format message to HTML
      my $temp_body = text_to_html($body);
      $html_output .=qq~
         <TABLE CELLPADDING="3" cellspacing="2" BORDER="0" WIDTH="$table_width">
         <TR BGCOLOR="$bg_color_0">
         <TH ALIGN="LEFT">
         <FONT SIZE="$font_size_0" FACE="$font_face_0" COLOR="$font_color_0">
         Original Message
         </FONT></TH></tr>
         <TR BGCOLOR="$bg_color_2"><Td ALIGN="LEFT">
         <FONT SIZE="$font_size_2" FACE="$font_face_2" COLOR="$font_color_2">
         <b>"$subject"</b><br>Posted by $name on $date at $ltime
         </FONT></Td></tr>
         <TR BGCOLOR="$bg_color_1"><Td ALIGN="LEFT">
         <FONT SIZE="$font_size_1" FACE="$font_face_1" COLOR="$font_color_1">
         <blockquote>
         $temp_body
         </blockquote>
         </FONT></Td></tr><TR BGCOLOR="$bg_color_0">
         <TH ALIGN="LEFT">
         <FONT SIZE="$font_size_0" FACE="$font_face_0" COLOR="$font_color_0">
         &nbsp;
         </FONT></TH></tr>
         </table>~;
   }
   

   if ($r_in->{'az'} eq 'e_mesg') {
      $subject = dc_decode($r_in->{'subject'});
      $body = dcf99_dcf00($r_in->{'body'});
      $body = dc_decode($body);
      $body = text_to_form($body);
   }
   elsif ($r_in->{'quote'}) {
      $body = dcf99_dcf00($body);
      $body = dc_decode($body);
      $body = text_to_form($body);
      $body = format_quote($body);
   }
   else {
      $body = '';
   }


   if ($r_in->{'body'}) {
      # This is for case when the user doesn't
      # complete the form
      $body = dc_decode($r_in->{'body'});
      $body = text_to_form($body);
      $subject = dc_decode($r_in->{'subject'});
   }

#   <input type=hidden name="rand1" value="$r_in->{'rand1'}">

   #Let see if the user's logged on anyway...
   $html_output .=qq~
   <center>
   <form ACTION="$boardurl" method="POST">
   <input type=hidden name="om" value="$r_in->{'om'}">
   <input type=hidden name="forum" value="$forum">
   <input type=hidden name="omm" value="$r_in->{'omm'}">
   ~;
  
   if ($r_in->{'az'} eq 'e_mesg') {
      $html_output .=qq~
         <input type="hidden" name="az" value="$r_in->{'az'}">
      ~;
   }
   else {
      $html_output .=qq~
         <input type="hidden" name="az" value="a_mesg">
      ~; 
   }
  

   $html_output .=qq~
   <TABLE CELLPADDING="3" cellspacing="2" BORDER="0" WIDTH="$table_width">
   <TR><Td ALIGN="LEFT" valign="top" colspan="2">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
   ~;

   if ($r_setup->{'html_allowed'} eq 'on') {
      $html_output .= qq~
      <li><font color="#FF0000">
      HTML Tags Enabled - use [] instead of &lt;>.  Need help?  Check </font>
      <a href="javascript:makeRemote('$boardurl?az=html_reference')"><FONT 
      SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
      HTML Reference</FONT></a>
      ~;
   }

   if ($r_setup->{'image_allowed'} eq 'on') {
      $html_output .= qq~
         <li><font color="#FF0000">
         Image Links Enabled - just type the URL (e.g., http://www.dcscripts.com/image.gif)
         </font>
         ~;
   }

   if ($r_setup->{'file_upload'} eq 'on' 
      and $session
      and $platform ne 'NT') {
      $html_output .= qq~
         <li><font color="#FF0000">
         File Upload Enabled</font>
         <a href="javascript:makeRemote('$boardurl?az=upload_file&forum=$forum')"><FONT 
         SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">Click here to upload your file</FONT></a>
         ~;
   }
   
   $html_output .= qq~
      <li><font color="#FF0000">
      Emotion Icons</font>
      <a href="javascript:makeRemote('$boardurl?az=emotion_icon_short_cuts')"><FONT 
      SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
      Emotion icon short cuts</FONT></a>
   </TD>
   </tr>
   <TR BGCOLOR="$bg_color_0"><TH ALIGN="LEFT" COLSPAN="2">
      <FONT SIZE="$font_size_0" FACE="$font_face_0" COLOR="$font_color_0">
      Your Message
      </FONT></TH></TR>
   <TR BGCOLOR="$bg_color_3">
   <TH ALIGN="RIGHT">
   <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
   Name<font color="$font_color_special">*</font>:
   </FONT>
   </TH>
   <TD>~;

   if ($r_in->{'userdata'}->{'Username'}) {
      $html_output .= qq~
         <input type="hidden" name="name" value="$r_in->{'userdata'}->{'Username'}">
         <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
         $r_in->{'userdata'}->{'Username'}</FONT>~;
   }
   else {
      $html_output .= qq~
         <INPUT TYPE="TEXT" NAME="name" value="$r_in->{'name'}" SIZE=50>~;
   }

   $html_output .= qq~
   </TD></TR>~;
   
   if ($r_setup->{'forum_type'}->{$forum} eq 'Public' and
      $r_in->{'userdata'}->{'EMail'} eq '') {
      $html_output .= qq~
         <TR BGCOLOR="$bg_color_3">
         <TH ALIGN="RIGHT">
         <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
         EMail:
         </FONT></TH>
         <TD BGCOLOR="$bg_color_3">
            <INPUT TYPE="TEXT" NAME="email" value="$r_in->{'email'}" SIZE=50>
         </TD></TR>~;
   }

   $html_output .= qq~
   <TR BGCOLOR="$bg_color_3">
   <TH ALIGN="RIGHT">
   <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
   Subject<font color="$font_color_special">*</font>:
   </FONT></TH>
   <TD BGCOLOR="$bg_color_3">~;

   if ($subject) {
      unless ($r_in->{'az'} eq 'e_mesg' or $r_in->{'preview'}) {
         unless ($subject =~ /^RE:/) {
            $html_output .= qq~
            <INPUT TYPE="text" NAME="subject" VALUE="RE: $subject" SIZE=50>~;
         }
         else {
            $html_output .= qq~
            <INPUT TYPE="text" NAME="subject" VALUE="$subject" SIZE=50>~;
         }
      }
      else {
         $html_output .= qq~
         <INPUT TYPE="text" NAME="subject" VALUE="$subject" SIZE=50>~;
      }
   }
   else {
      $subject = dc_decode($r_in->{'subject'});
      $html_output .= qq~
      <INPUT TYPE="TEXT" NAME="subject" VALUE="$subject" SIZE=50>
      ~;
   }

   $html_output .= qq~
      </TD></TR><TR BGCOLOR="$bg_color_3">
      <TH ALIGN="RIGHT" VALIGN="TOP"><FONT SIZE="$font_size_3" 
         FACE="$font_face_3" COLOR="$font_color_3">
         Message<font color="$font_color_special">*</font>:</FONT>
         </TH><TD>~;

   if ($body) {
      if ($r_in->{'az'} eq 'e_mesg' or 
          $r_in->{'preview'} or 
          $r_in->{'posting_error'} ) {
         $html_output .= qq~
         <TEXTAREA NAME="body" ROWS="15"
            COLS="50" WRAP="virtual">$body</TEXTAREA>~;
     }
     else {
         $html_output .= qq~
         <TEXTAREA NAME="body" ROWS="15"
         COLS="50" WRAP="virtual">$body\n\n$r_profile->{'Signature'}</TEXTAREA>~;
     }
   }
   else {
      $html_output .= qq~
      <TEXTAREA NAME="body" ROWS="12"
        COLS="50" WRAP="virtual">$r_profile->{'Signature'}</TEXTAREA>
    ~;
   }
  
   $html_output .= qq~
   </TD></TR>~;

   if ($r_setup->{'email_notification'} eq 'on' and $session) {
         $html_output .= qq~
         <TR BGCOLOR="$bg_color_3">
         <TH ALIGN="RIGHT" VALIGN="TOP">~;

      if ($r_in->{'email_notification'}) {
         $html_output .= qq~
         <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
            <input type="checkbox" name="email_notification" value='not_empty' checked>
            </FONT>~;
      }
      else {
         $html_output .= qq~
         <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
            <input type="checkbox" name="email_notification" value='not_empty'>
            </FONT>~;
      }
         $html_output .= qq~
         </TH>
         <TH ALIGN="LEFT" VALIGN="TOP">
         <FONT SIZE="$font_size_3" FACE="$font_face_3" COLOR="$font_color_3">
          Check if you want to receive email 
          when a new message is posted to this thread<p>
         </FONT>
         </TH>
         </tr>~;
   }

   if ($r_in->{'az'} eq 'post' or 
      $r_in->{'az'} eq 'a_mesg' or 
      $r_in->{'type'} eq 'a_mesg') {
      $post_option = 'Post Message';
   }
   else {
      $post_option = 'Edit Message';
   }
      
   $html_output .= qq~
   <TR><TH ALIGN="RIGHT" BGCOLOR="$bg_color_3">
   &nbsp;</TH>
   <TD BGCOLOR="$bg_color_3" ALIGN="LEFT">
   <INPUT TYPE="SUBMIT" NAME="preview" VALUE="Preview">
      <INPUT TYPE="SUBMIT" NAME="post" VALUE="$post_option">
   <INPUT TYPE="RESET" VALUE="Reset">
   </TD></TR></TABLE>
   </form>
   </center>
  ~;

   return ($heading, $sub_heading, $html_output,$menu_button);

}

1;