
sub create_button {

   my ($type,$r_in,$r_setup) = @_;
   my $menu_buttons;
   my $l_buttons;
   my @l_buttons;
   my $separator = '|';

   my $bgcolor = $bg_color_5;
   my $f_color = $font_color_5;
   my $f_face = $font_face_5;
   my $f_size = $font_size_5;
   
   my $b_login = qq~ <a href="$boardurl?az=login"><font 
               size="$f_size" face="$f_face" color="$f_color">Login</font></a> ~;

   if ($r_in->{'userdata'}->{'Username'}) {
      $b_login = qq~ <a href="$boardurl?az=login"><font 
               size="$f_size" face="$f_face" color="$f_color">Logout</font></a> ~;
   }

   my $b_back = qq~ <a href="$ENV{'HTTP_REFERER'}"><font 
               size="$f_size" face="$f_face" color="$f_color">Go back</font></a> ~;
   my $b_post = qq~ <a href="$boardurl?az=post&forum=$forum"><font 
               size="$f_size" face="$f_face" color="$f_color">Post New Topic</font></a> ~;
   my $b_mark = qq~ <a href="$boardurl?az=mark&forum=$forum&conf=$r_in->{'conf'}"><font 
               size="$f_size" face="$f_face" color="$f_color">Mark this Forum</font></a> ~;
   my $b_help = qq~ <a href="$boardurl?az=help"><font 
               size="$f_size" face="$f_face" color="$f_color">Help</font></a> ~;
   my $b_search = qq~ <a href="$boardurl?az=search_form"><font 
               size="$f_size" face="$f_face" color="$f_color">Search</font></a> ~;
   my $b_lobby = qq~ <a href="$boardurl?az=lobby"><font 
               size="$f_size" face="$f_face" color="$f_color">Lobby</font></a> ~;
   my $b_topics = qq~ <a href="$boardurl?az=list&forum=$forum"><font 
               size="$f_size" face="$f_face" color="$f_color">Topics</font></a> ~;
   my $b_admin = qq~ <a href="$adminurl"><font 
               size="$f_size" face="$f_face" color="$f_color">Admin</font></a> ~;
   my $b_profile = qq~ <a href="$boardurl?az=user"><font 
               size="$f_size" face="$f_face" color="$f_color">User</font></a> ~;

   # New for DCF2000
   my $b_next = qq~ <a 
   href="$boardurl?forum=$forum&mark=$r_in->{'om'}&az=next_topic&archive=$r_in->{'archive'}"><font 
               size="$f_size" face="$f_face" color="$f_color">Next Topic</font></a> ~;
   my $b_previous = qq~ <a 
   href="$boardurl?forum=$forum&mark=$r_in->{'om'}&az=previous_topic&archive=$r_in->{'archive'}"><font 
               size="$f_size" face="$f_face" color="$f_color">Previous Topic</font></a> ~;


   if ($r_setup->{'use_icons'} eq "on") {

      $b_previous = qq~<a 
         href="$boardurl?forum=$forum&mark=$r_in->{'om'}&az=previous_topic&archive=$r_in->{'archive'}"><IMG 
         SRC="$imgurl/prev_thread.gif" BORDER="0" 
         alt="Click here to read previous thread"></a>~;
   
      $b_next = qq~<a 
         href="$boardurl?forum=$forum&mark=$r_in->{'om'}&az=next_topic&archive=$r_in->{'archive'}"><IMG 
         SRC="$imgurl/next_thread.gif" BORDER="0" 
         alt="Click here to read next thread"></a>~;

         $b_back = "<a href=\"$ENV{'HTTP_REFERER'}\"><img
            src=\"$imgurl/goback.gif\" alt=\"Click here to goback to the previous page\" border=\"0\"></a>";

         $b_lobby = "<a href=\"$boardurl?az=lobby\"><img
            src=\"$imgurl/lobby.gif\" alt=\"Click here to goto the Lobby\" border=\"0\"></a>";
         $b_topics = " <a href=\"$boardurl?az=list&forum=$forum\"><img
            src=\"$imgurl/home.gif\" alt=\"Click here to goto the forum listing\" border=\"0\"></a>";

         $b_login = "<a href=\"$boardurl?az=login\"><img 
            src=\"$imgurl/login.gif\" alt=\"Click here to Login\" border=\"0\"></a>";
         $b_post = "<a href=\"$boardurl?az=post&forum=$forum\"><img 
            src=\"$imgurl/post.gif\" alt=\"Click here to post new thread\" border=\"0\"></a>";
         $b_mark = "<a href=\"$boardurl?az=mark&forum=$forum\"><img 
            src=\"$imgurl/mark.gif\" alt=\"Click here to Mark This Forum as Read\" border=\"0\"></a>";
         $b_help = "<a href=\"$boardurl?az=help\"><img 
            src=\"$imgurl/help.gif\" alt=\"Click here to see help\" border=\"0\"></a>";
         $b_search = "<a href=\"$boardurl?az=search_form\"><img 
            src=\"$imgurl/search.gif\" alt=\"Click here to Search the Forum\" border=\"0\"></a>";
         $b_admin = "<a href=\"$adminurl\"><img 
            src=\"$imgurl/admin.gif\" alt=\"Click here to goto administration page\" border=\"0\"></a>";
         $b_profile = "<a href=\"$boardurl?az=user\"><img 
            src=\"$imgurl/profile.gif\" alt=\"Click here to goto user utility\" border=\"0\"></a>";

         if ($r_in->{'userdata'}->{'Username'}) {
            $b_login = "<a href=\"$boardurl?az=login\"><img 
               src=\"$imgurl/logout.gif\" alt=\"Click here to Logout\" border=\"0\"></a>";
         }

   }

   if ($type eq 'list') {

      push(@l_buttons,$b_login,$b_help,$b_search,$b_post);
      if ($session) {
         push(@l_buttons,$b_mark,$b_profile);
      }     

      if ($r_in->{'userdata'}->{'Group'} eq "admin" or 
         $r_in->{'userdata'}->{'Group'} eq "moderator") {
         push(@l_buttons,$b_admin);
      }

   }
   elsif ($type eq 'admin') {
         push(@l_buttons,$b_login,$b_admin);
   }
   elsif ($type eq 'user_menu') {

      push(@l_buttons,$b_login,$b_help,$b_search,$b_lobby);
      if ($session) {
         push(@l_buttons,$b_profile);
      }
      
      if ($r_in->{'userdata'}->{'Group'} eq "admin" or 
         $r_in->{'userdata'}->{'Group'} eq "moderator") {
         push(@l_buttons,$b_admin);
      }

   }
   elsif ($type eq 'message') {
      push(@l_buttons,$b_help,$b_search);

      if ($r_setup->{'use_icons'} eq "on") {    
         $l_buttons = join("",@l_buttons);
      }
      else {
         $l_buttons = join("$separator",@l_buttons);
      }
      return ($l_buttons);

   }
   elsif ($type eq 'help') {
      push(@l_buttons,$b_search,$b_back,$b_lobby);
   }
   elsif ($type eq 'register') {
      push(@l_buttons,$b_back,$b_lobby);
   }
   elsif ($type eq 'search') {
      push(@l_buttons,$b_help,$b_back,$b_lobby);
   }
   elsif ($type eq 'new_message') {

      my $user;

      push(@l_buttons,$b_login,$b_help,$b_search);

      if ($r_in->{'userdata'}->{'Username'}) {
         $user = $r_in->{'userdata'}->{'Username'};
      }

      $b_mark = qq~ <a href=\"$boardurl?az=mark&forum=all\"><font 
               size="$f_size" face="$f_face" color="$f_color">Mark All Forums</font></a> ~;
      if ($r_setup->{'use_icons'} eq "on") {
         $b_mark = "<a href=\"$boardurl?az=mark&forum=all\"><img src=\"$imgurl/mark.gif\" alt=\"Click here to Mark This Forum as Read\" border=\"0\"></a>";
      }

      if ($user) {
         push(@l_buttons, $b_mark);
      }

      push(@l_buttons, $b_back);

      if ($r_in->{'userdata'}->{'Group'} eq "admin" or 
         $r_in->{'userdata'}->{'Group'} eq "moderator") {
         push(@l_buttons, $b_admin);
      }

   }
   elsif ($type eq 'announcement') {

      push(@l_buttons,$b_help,$b_search,$b_back,$b_lobby);

  }
   elsif ($type eq 'lobby') {

      my $user;

      push(@l_buttons,$b_login,$b_help,$b_search);

      if ($session) {
         $user = $r_in->{'userdata'}->{'Username'};
      }

      if ($user) {
         push(@l_buttons, $b_profile);
      }

      if ($r_in->{'userdata'}->{'Group'} eq "admin" or 
         $r_in->{'userdata'}->{'Group'} eq "moderator") {
         push(@l_buttons, $b_admin);
      }

  }

   if ($r_setup->{'use_icons'} eq "on") {

      $menu_buttons = qq~
         <TABLE BORDER="0" cellspacing="0" cellpadding="0">
         <TR>~;
      foreach ( (@l_buttons,@r_buttons) ) {
         $menu_buttons .= qq~
         <td  BGCOLOR="$bgcolor">$_</td>~;
      }
      
      $menu_buttons .= qq~
         </TR></TABLE>
      ~;

   }
   else {

      $l_buttons = join("$separator",@l_buttons);
      $menu_buttons = qq~  
         <TABLE BORDER="0" cellspacing="0" cellpadding="4" width="100%">
         <TR><TD ALIGN="center" BGCOLOR="$bgcolor"><font 
         size="$f_size" face="$f_face" color="$f_color">
            $l_buttons</font></TD>
         </TR></TABLE>
      ~;
   }

  $menu_buttons;
}

