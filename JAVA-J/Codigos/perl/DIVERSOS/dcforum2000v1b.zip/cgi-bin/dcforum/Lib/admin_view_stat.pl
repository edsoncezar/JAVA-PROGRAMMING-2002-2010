# admin_view_stat.pl
#
# NOT USED FOR DCF2000
#
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#===================================================================
# admin_view_stat
# utility for view forum usage stats
#===================================================================

sub admin_view_stat {

   my ($r_in,$r_setup) = @_;
   my $html_output;
   my $r_data = {};

   print_header();
   print_header_end();

   $html_output = qq~
      <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
      <TR>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="CENTER" COLSPAN="3">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         <B><font size="3">Forum Visitor Stat</font></b><br>
         </font></TD></TR></table>~;


   if ($r_in->{'command'} eq 'post' or
       $r_in->{'command'} eq 'edit') {

      $r_data = readdata("$password_file_dir/$logfile");

      $r_in->{'answer'} = dc_encode($r_in->{'answer'});
      $r_in->{'question'} = dc_encode($r_in->{'question'});

      my $text = join("$join_delim",$r_in->{'date'},$r_in->{'localtime'},
            $r_in->{'question'},$r_in->{'answer'});

      appenddata("$password_file_dir/$faq_list",$text);

      if ($r_in->{'command'} eq 'edit') {    
         remove_faq($r_in);
         $html_output .= print_status("Your faq has been updated");
      }
      else {
         $html_output .= print_status("Your faq has been posted");
      }

   }
   elsif ($r_in->{'command'} eq 'Delete') {
      remove_faq($r_in);
      $html_output = print_status("FAQ list have been updated");
   }
   # If $r_in->{'command'} is still not empty, then it is edit
   elsif ($r_in->{'command'}) {

      $r_in->{'command'} = 'edit';
      my ($ldate,$ltime,$question,$answer) = 
            get_faq($r_in->{'selected'},$r_data);
      $r_in->{'ldata'} = $ldate;
      $r_in->{'ltime'} = $ltime;
      $r_in->{'question'} = dc_decode($question);
      $r_in->{'answer'} = dc_decode($answer);
      $html_output = faq_form($r_in);

   }        
   else {

      $html_output .= qq~
      <FORM ACTION="$adminurl" METHOD=POST>
      <input type="hidden" name="az" value="$r_in->{'az'}">
      <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
         <TR>
            <TH BGCOLOR="$bg_color_0" ALIGN="CENTER" VALIGN="TOP" COLSPAN="2">
            <font size="$font_size_0" face="$font_face_0" color="$font_color_0">
            &nbsp;&nbsp;</font>
            </TH>
         </TR>
         <TR>
            <TD COLSPAN="2" BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
            <font size="$font_size_2" face="$font_face_2" color="$font_color_2">
            <select name="days">
            <option value=''>Select time period
            <option value="1">Last 24 hours
            <option value="7">Last 1 week
            <option value="30">Last month (30 days)
            </select>            
            </font>
            </TD>
         </TR>
         <TR>
            <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
            <input type="radio" name="command" value="view_by_date">
            </TD>
            <TH BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
            <font size="$font_size_2" face="$font_face_2" color="$font_color_2">
            View forum log sorted by date
            </font>
            </TH>
         </TR>
         <TR>
            <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
            <input type="radio" name="command" value="view_by_user">
            </TD>
            <TH BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
            <font size="$font_size_2" face="$font_face_2" color="$font_color_2">
            View forum log sorted by user
            </font>
            </TH>
         </TR>
         <TR>
            <TD BGCOLOR="$bg_color_2" ALIGN="CENTER" VALIGN="TOP" COLSPAN="2">
            <font size="$font_size_2" face="$font_face_2" color="$font_color_2">
            <input type="submit" value="Get stat">
            </font>
            </TD>
         </TR>
         </table>
         </form>
         ~;

   }
   
   $html_output;  

}


1;