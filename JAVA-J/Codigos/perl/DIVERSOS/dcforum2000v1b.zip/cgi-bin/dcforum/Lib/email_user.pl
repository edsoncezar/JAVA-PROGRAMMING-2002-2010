# email_user.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# email_user                                                           #
# utility for users to email each other                                #
#======================================================================#

sub email_user {

   my ($r_in,$r_setup) = @_;
   my $html_output;
   my $r_local = {}; 

   require "$cgilib/dcforumlib2.pl";

   $r_in->{'userdata'} = check_user($r_in,$r_setup);

   print_header();
   print_header_end();

   my $heading = $title;
   my $menu_button = create_button("help",$r_in,$r_setup);

   if ($r_in->{'command'} eq 'send') {

      my $subject = "Email from $r_in->{'userdata'}->{'Username'} at $forum_title\n";
      my $message = qq~Following email was sent from user $r_in->{'userdata'}->{'Username'} at $forum_title.
------------------------------------------------------------------------------
Subject: $r_in->{'subject'}
Message: $r_in->{'message'}
      
To reply to this user, please use the following URL:
$boardurl?az=email_user&userid=$r_in->{'userdata'}->{'Username'}
~;
      
      my $to_user_email = get_user_email($r_in->{'userid'});
      if ($to_user_email) {
         send_mail($password_file_dir, $r_setup->{'auth_sendmail_path'},
               $r_setup->{'auth_admin_email_address'},$to_user_email,
               $subject,$message);
         $html_output = print_status("Your email has been sent");
      }
      else {
         $html_output = print_status("No such user...try again");
      }

   
   }
   else {

   $html_output .= $r_in->{'userdata'}->{'Email'};    

   $html_output = qq~
   <FORM METHOD=POST>
   <input type="hidden" name="az" value="$r_in->{'az'}">
   <input type="hidden" name="command" value="send">
   <input type="hidden" name="userid" value="$r_in->{'userid'}">
   <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
   <TR>
      <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="CENTER" COLSPAN="2">
      <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
      <B><font size="3">Send email to another forum user</font></b><br>
      Complete the form below to send email to $r_in->{'userid'}
      </font></TD></TR>
      <TR>
         <TH BGCOLOR="$bg_color_3" ALIGN="RIGHT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         Subject:
         </font>
         </TH>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <input type="text" name="subject" size="50">
         </TD>
      </TR>
      <TR>
         <TH BGCOLOR="$bg_color_3" ALIGN="RIGHT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         Message:
         </font>
         </TH>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <textarea name="message" rows="10" cols="50"></textarea>
      </TR>
      <TR>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         &nbsp;
         </td>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <input type="submit" value="Send">
         <input type="reset" value="Reset">
         </td>
      </TR>
      
      </TABLE>
      </FORM>
      ~;
   
   }

   return ($heading, $sub_heading, $html_output,$menu_button);
}



1;