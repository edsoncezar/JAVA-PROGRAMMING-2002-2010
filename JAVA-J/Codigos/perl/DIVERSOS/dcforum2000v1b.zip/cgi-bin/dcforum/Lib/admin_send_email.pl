# admin_send_email.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#
#======================================================================#
# admin_send_email.pl                                                  #
# utility for sending emails to forum users                            #
#======================================================================#

sub admin_send_email {

   my ($r_in,$r_setup) = @_;
   my $html_output;
   my $r_data = {};
      
   if ($r_in->{'command'} eq 'send') {

      if ($r_in->{'users'} eq 'all') {
         $r_in->{'users'} = join(",","normal","member","team","moderator");
      }
      else {
         $r_in->{'users'} =~ s/\0/,/g;
      }

      $r_data = readdata("$password_file_dir/$password_file");

      foreach (@$r_data) {
         chomp;
         my @temp = split /$split_delim/;
         if ($r_in->{'users'} =~ /$temp[2]/) {
            $temp[5] = remove_antispam($temp[5]);
            push(@to,$temp[5]);
         }
      }

      foreach (@to) {      
         send_mail($password_file_dir, $r_setup->{'auth_sendmail_path'},
               $r_setup->{'auth_admin_email_address'},$_,
               $r_in->{'subject'},$r_in->{'message'});
      }

      $html_output = print_status("Your email has been sent!");
   
   }
   else {

   $html_output = qq~
   <FORM METHOD=POST>
   <input type="hidden" name="az" value="$r_in->{'az'}">
   <input type="hidden" name="command" value="send">
   <TABLE BORDER="0" CELLPADDING="2" WIDTH="100%" ALIGN="CENTER">
   <TR>
      <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="CENTER" COLSPAN="2">
      <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
      <B><font size="3">EMail List Manager</font></b><br>
      Complete the form below to send email to registered users
      </font></TD></TR>
      <TR>
         <TH BGCOLOR="$bg_color_3" ALIGN="RIGHT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         Recipients:
         </font>
         </TH>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         <input type="checkbox" name="users" value="normal">Normal users<br>
         <input type="checkbox" name="users" value="member">Member users<br>
         <input type="checkbox" name="users" value="team">Team users<br>
         <input type="checkbox" name="users" value="moderator">Moderators<br>
         <input type="checkbox" name="users" value="all" checked>All users
         </font>
         </TD>
      </TR>
      <TR>
         <TH BGCOLOR="$bg_color_3" ALIGN="RIGHT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         Subject:
         </font>
         </TH>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <input type="text" name="subject" size="50">
         </TD>
      </TR>
      <TR>
         <TH BGCOLOR="$bg_color_3" ALIGN="RIGHT" VALIGN="TOP">
         <font size="$font_size_3" face="$font_face_3" color="$font_color_3">
         Message:
         </font>
         </TH>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <textarea name="message" rows="10" cols="50"></textarea>
      </TR>
      <TR>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         &nbsp;
         </td>
         <TD BGCOLOR="$bg_color_3" ALIGN="LEFT" VALIGN="TOP">
         <input type="submit" value="Send">
         <input type="reset" value="Reset">
         </td>
      </TR>
      
      </TABLE>
      ~;
   
   }

   $html_output;  
}

1;