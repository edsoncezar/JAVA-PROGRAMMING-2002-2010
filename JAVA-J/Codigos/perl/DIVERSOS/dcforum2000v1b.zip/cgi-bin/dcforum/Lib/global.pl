# global declaration file
# DO NOT EDIT BELOW THIS LINE

$bg_color_0 = $r_setup->{'bg_color_0'};
$font_face_0 = $r_setup->{'font_face_0'};
$font_size_0 = $r_setup->{'font_size_0'};
$font_color_0 = $r_setup->{'font_color_0'};

$bg_color_1 = $r_setup->{'bg_color_1'};
$font_face_1 = $r_setup->{'font_face_1'};
$font_size_1 = $r_setup->{'font_size_1'};
$font_color_1 = $r_setup->{'font_color_1'};

$bg_color_2 = $r_setup->{'bg_color_2'};
$font_face_2 = $r_setup->{'font_face_2'};
$font_size_2 = $r_setup->{'font_size_2'};
$font_color_2 = $r_setup->{'font_color_2'};

$bg_color_3 = $r_setup->{'bg_color_3'};
$font_face_3 = $r_setup->{'font_face_3'};
$font_size_3 = $r_setup->{'font_size_3'};
$font_color_3 = $r_setup->{'font_color_3'};

$bg_color_4 = $r_setup->{'bg_color_4'};
$font_face_4 = $r_setup->{'font_face_4'};
$font_size_4 = $r_setup->{'font_size_4'};
$font_color_4 = $r_setup->{'font_color_4'};

$bg_color_5 = $r_setup->{'bg_color_5'};
$font_face_5 = $r_setup->{'font_face_5'};
$font_size_5 = $r_setup->{'font_size_5'};
$font_color_5 = $r_setup->{'font_color_5'};

$font_color_special = $r_setup->{'font_color_6'};

$table_width = $r_setup->{'table_width'};
$mesg_max = $r_setup->{'mesg_max'};
$subject_length_max = $r_setup->{'subject_length_max'};
$word_length_max = $r_setup->{'word_length_max'};
$max_threads_allowed = $r_setup->{'max_threads_allowed'};
$level_max = $r_setup->{'level_max'};
$level_spacing = $r_setup->{'level_spacing'};
$expires = "Tue, 31-Dec-2002 12:00:00 GMT";
$forum = $r_in->{'forum'};

$time_offset = $r_setup->{'time_offset'};
$time_zone = $r_setup->{'time_zone'};
$date_format = $r_setup->{'date_format'};
$smtp_server = $r_setup->{'auth_smtp_server'};

$forum_title = $r_setup->{'forum_title'};

$thread_style_cookie = 'DCForumStyle';
$sort_by_field_cookie = 'DCForumSortField';

# Sort index is actually 1 greater
# this is need for cookie file

$id_index = 1;
$subject_index = 5;
$author_index = 4;
$date_index = '';
$replies_index = 10;
$view_index = 8;
$rating_index = 9;

# Follow are some form parameters
# that must be passed to user authentication

@group = qw(normal member team moderator admin);
@in_param = qw(
   orig_url
   az
   thread_select
   forum
   now_what
   selected
   om
   omm
   user
   user_id
   user_email
   quote
   alert_message
   fields
   days
   keywords
   s_forum
   arc_database
   check_private
   email_notification
   command
);

$r_in->{'in_param'} = \@in_param;

1;