# pview.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# function pview
# For previewing message
#======================================================================#

sub pview {

   my ($r_in,$r_setup) = @_;

   require "$cgilib/dcforumlib2.pl";
   require "$cgilib/post.pl";
   
   my $menu_button = create_button('help',$r_in,$r_setup);

   my $heading = $forum_title;
   my $sub_heading = "Previewing your message";

   print_header();
   print_header_end();

   get_form_variables($r_in,$r_setup);

   $r_in->{'body'} = text_to_html($r_in->{'body'});
   $r_in->{'subject'} = dc_decode($r_in->{'subject'});

   my $html_output = qq~
      <TABLE BORDER="0" WIDTH="$table_width" 
      CELLPADDING="4" Cellspacing="0">
      <TR BGCOLOR="$bg_color_1"><td width="100%">
         <FONT SIZE="$font_size_1" FACE="$font_face_1" COLOR="$font_color_1">
         Review your message below.  Make any necessary changes using the
         post form below the message.
         </FONT></TD></TR>
      <TR BGCOLOR="$bg_color_2"><TH width="100%" ALIGN="LEFT">
         <FONT SIZE="$font_size_2" FACE="$font_face_2" COLOR="$font_color_2">
         Subject: "$r_in->{'subject'}"
         </FONT></TH></TR>
      <TR BGCOLOR="$bg_color_2">
         <TD align="Left">
         &nbsp;
         </td></tr>
      <TR BGCOLOR="$bg_color_1"><td width="100%">
         <FONT SIZE="$font_size_1" FACE="$font_face_1" COLOR="$font_color_1">
         <blockquote>
         $r_in->{'body'}
         </blockquote></FONT></TD></TR>
      <TR BGCOLOR="$bg_color_2">
         <TD align="right" valign="top">
         &nbsp;
         </td></tr>
      </TABLE>
    ~;

   $r_in->{'body'} = text_to_form($r_in->{'orig_body'});
   $r_in->{'subject'} = text_to_form($r_in->{'subject'});
   
   ($dum, $dum, $temp,$dum) = post($r_in,$r_setup);
   $html_output .= $temp;
   return ($heading, $sub_heading, $html_output,$menu_button);
   
}

1;