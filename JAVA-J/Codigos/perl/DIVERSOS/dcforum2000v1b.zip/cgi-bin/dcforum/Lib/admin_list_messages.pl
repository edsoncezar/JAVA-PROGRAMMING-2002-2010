# admin_list_messages.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#
#======================================================================#
# admin_list_messages                                                  #
# listing utilty for listing messages                                  #
#======================================================================#

sub admin_list_messages {

	my ($datafile,$r_in) = @_;
	my ($html_output) = "";
	my $r_rowdata = &readdata("$datafile");
	my $file_num = shift @{$r_rowdata};
	my $first_line = shift @{$r_rowdata};

	$html_output .=qq~
	<FORM METHOD="POST">~;

	foreach (@$r_rowdata) {
			my ($omm,$level,$subject,$name,$email,$ltime,$date,$body) = split /$split_delim/;
         $body = dcf99_dcf00($body);
			$body = dc_decode($body);
			$body = text_to_html($body);
			$subject = dc_decode($subject);
	      $r_in->{'omm'} = $omm;
	      $r_in->{'level'} = $level;
	      $r_in->{'subject'} = $subject;
	      $r_in->{'name'} = $name;
	      $r_in->{'email'} = $email;
	      $r_in->{'ltime'} = $ltime;
	      $r_in->{'date'} = $date;
	      $r_in->{'body'} = $body;
			$html_main_body = html_main_body($r_in,$r_setup);
			$html_output .= qq~
				<table border="0" width="$table_width">
				<tr><th bgcolor="$bg_color_4">
				<font size="$font_size_4" face="$font_face_4" color="$font_color_4">
		 		<INPUT TYPE="checkbox" NAME="selected" value="$omm">
         	Select to Remove The Following Message
				</font></th>
				</tr>
				</table>
				$html_main_body
				~;			
   }


   $html_output .=qq~
   <INPUT TYPE="HIDDEN" NAME="forum" VALUE="$r_in->{'forum'}">
   <INPUT TYPE="HIDDEN" NAME="thread_select" VALUE="$r_in->{'thread_select'}">
   <INPUT TYPE="HIDDEN" NAME="az" VALUE="$r_in->{'az'}">
   <INPUT TYPE="HIDDEN" NAME="command" VALUE="admin_remove_messages">
	<table border="0" width="$table_width">
	<tr><td bgcolor="$bg_color_4" align="left">
	<font size="$font_size_4" face="$font_face_4" color="$font_color_4">
   <INPUT TYPE="SUBMIT" VALUE="Submit Form">
   <INPUT TYPE="RESET" VALUE="Reset Form">
	</font></td>
	</tr>
	</table>
   </FORM>
   ~;

}

1;