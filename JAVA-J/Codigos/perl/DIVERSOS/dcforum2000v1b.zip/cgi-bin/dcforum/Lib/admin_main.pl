# admin_main.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#===================================================================
# admin_main
# main administration page
#===================================================================

sub admin_main {

	my ($r_in,$r_setup) = @_;

	my $html_output .= qq~
		<TABLE BORDER="0" cellpadding="2" align="left" width="400">
			<TR>
			<TD ALIGN="left" bgcolor="$bg_color_1">
			<font size="$font_size_1" face="$font_face_1" 
			color="$font_color_1">
			<b>If this is your firsttime using DCF Admin, please
			read <a 
			href="$mainurl/admin.html" target="_blank">Administration 
			User's Guide</a></b>.
			
			<p>
			
			DCForum administration utility is a 
			browser-based program that will
			help you setup and maintain your 
			discussion forum. .
			It includes
			the following functions:
		
		<ul>
		<li>Menu
			<ul>
		   <li>Logout - logout
			<li>Admin - back to admin's main page
			<li>Lobby - forum's lobby page</li>    
			</ul>
		<li>General Administration
			<ul>
		   <li>Shutdown DCForum
		   <li>Forum Settings</li> 
			</ul>
		<li>User Administration
			<ul>
			<li>Create New Account
			<li>User Manager</li> 
			</ul>
		<li>Conference Manager
			<ul>
		   <li>Create New Conference
		   <li>Modify Existing Conference
		   <li>Reorder Conference Listing
		   <li>Remove Existing Conference</li>  
			</ul>
		<li>Forum Manager
			<ul>
		   <li>Create New Forum
		   <li>Modify Existing Forum
		   <li>Reorder Forum Listing
		   <li>Remove Existing Forum</li>  
			</ul>
		<li>Private Forum User Manager
			<ul>
			<li>User Manager</li> 
			</ul>
		<li>Board Manager
			<ul>
			<li>Unqueue Messages
			<li>Lock Threads
			<li>Unlock Threads
			<li>Archive Threads
			<li>Move Threads
			<li>Remove Threads
			<li>Remove Messages</li> 
			</ul>
		<li>Admin Functions
			<ul>
		   <li>Announcement Manager
			<li>Customize Email
			<li>Send EMail - Email list manager
			<li>Send Subscription</li> 
			</ul>
		<li>Data utilities
			<ul>
		   <li>Rebuild Database
			<li>Backup Forum Files
			<li>Recover Forum Files</li>  
			</ul>
		<li>Misc Utilities
			<ul>
		   <li>Update Threads
			<li>Remove Session Files
			<li>Remove All Session Files
			<li>Remove Temp Files</li>  
			</ul></li>
		</ul>
		</font>
		</td>
		</tr></table>~;


}

1;