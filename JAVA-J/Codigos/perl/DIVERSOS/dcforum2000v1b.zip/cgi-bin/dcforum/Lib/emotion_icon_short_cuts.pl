# emotion_icon_shortcuts.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# function emotion_icon_shortcuts.pl                                   #
# displays emotion icon shotcuts                                       #
#======================================================================#

sub emotion_icon_short_cuts {

   my ($r_in,$r_setup) = @_;
   local $html_output;
   local $heading = $forum_title;
   local $sub_heading = 'Emotion Icon Shortcuts';

   print_header();
   print_header_end();

   $html_output = qq~

      <table border="0" cellpadding="2" WIDTH="$table_width">
      <tr><th bgcolor="$bg_color_0" colspan="3" align="left">
      <FONT SIZE="$font_size_0" FACE="$font_face_0" color="$font_color_0">
      Emotion Icon Short Cuts</font>
      </th></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Emotions
      </FONT>
      </th>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Short Cuts
      </FONT>
      </th>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Icons
      </FONT>
      </th></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Happy
      </FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :-)
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/happy.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Angry
      </FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :-(
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl/angry.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Sad</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :-(
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/sad.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Wink</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      ;-)
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/wink.gif">
      </td></tr>


      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Shocked</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :o (Letter o)
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/shocked.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Big Smile</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :D
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/bigsmile.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Devil</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      }&gt;
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/devil.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Cry</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :'(
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/cry.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Tongue</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :P
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/tongue.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Yum</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :9
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/yum.gif">
      </td></tr>


      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Kiss</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :*
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/kiss.gif">
      </td></tr>

      <tr>
      <th bgcolor="$bg_color_3" align="left">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      Love it</FONT>
      </th>
      <td bgcolor="$bg_color_3">
      <FONT SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">
      :7
      </FONT>
      </td>
      <td bgcolor="$bg_color_3">
      <img src="$imgurl\/loveit.gif">
      </td></tr>

      <tr>
      <td bgcolor="$bg_color_3">
      &nbsp;
      </td>
      <td bgcolor="$bg_color_3" align="right">
      <A HREF = "javascript:window.close();"><FONT 
      SIZE="$font_size_3" FACE="$font_face_3" color="$font_color_3">Close 
      this Window</font></A></td>
      <td bgcolor="$bg_color_3">
      &nbsp;
      </td>
      </tr></TABLE>
      </FORM>~;   

      require "$cgilib/blank_template.pl";

      exit;
}

1;
