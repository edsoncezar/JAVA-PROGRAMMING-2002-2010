# next_topic.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# next_topic.pl                                                        #
# display next oldest topic     `                                       #
#======================================================================#

sub next_topic {
   my ($r_in,$r_setup) = @_;
   my $index, $redirect;
   my $current = $r_in->{'mark'};
   my $r_data = readdata("$maindir/$forum/$database");

   foreach (@{$r_data}) {
      my @temp = split /$split_delim/;
      push(@threads,$temp[0]);
   }

   # There should be more efficient way to do this loop
   # oh, well...
   
   $index = -1;
   foreach (@threads) {
      $index++;
      if ($_ == $current) {
         last;
      }
   }

   if ($index == $#threads) {
      $redirect = $threads[$index];
   }
   else {
      $redirect = $threads[$index + 1];
   }

   if ($r_setup->{'read_count'} eq 'on') {

      $r_in->{'om'} = $redirect;
      require "$cgilib/read_count.pl";
      my ($heading,$sub_heading,$html_output,$menu_button) = read_count($r_in,$r_setup);
      return ($heading,$sub_heading,$html_output,$menu_button);

   }
   else {

      if ($r_setup->{'threaded_main_listing'} eq 'on') {

         print_header();
         print_header_end();
         require "$cgilib/show_thread.pl";
         $r_in->{'om'} = $redirect;
         $r_in->{'omm'} = 0;
         my ($heading,$sub_heading,$html_output,$menu_button) = show_thread($r_in,$r_setup);
         return ($heading,$sub_heading,$html_output,$menu_button);
#        print "Location: $boardurl?az=show_thread&forum=$forum&om=$redirect&omm=0\n\n";
      }
      elsif ($r_setup->{'forum_type'}->{$forum} eq 'Private') {

         print_header();
         print_header_end();
         require "$cgilib/show_thread.pl";
         $r_in->{'om'} = $redirect;
         my ($heading,$sub_heading,$html_output,$menu_button) = show_thread($r_in,$r_setup);
         return ($heading,$sub_heading,$html_output,$menu_button);

#        print "Location: $boardurl?az=show_thread&forum=$forum&om=$redirect\n\n";
      }
      else {
         print "Location: $mainurl/$forum/$redirect.$ext\n\n";
      }
   }

   exit;

}

1;