# login.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# login                                                                #
# user login script                                                    #
#======================================================================#

sub login {

   # Check and see if the user has
   # expired session id
   # If so, delete it

   my $session = get_cookie($cookie_name);

   if ($session and -e "$sessiondir/$session.session") {
      send_cookie($cookie_name,'','Thur, 31-Dec-98 12:00:00 GMT','/');
      unlink("$sessiondir/$session.session");
      $session = '';
   }

   print_header();
   require "$cgilib/auth_login.pl";
   $r_in->{'userdata'} = auth_login($r_in,$r_setup);

   # Need orig_url to refresh back to the main page

   # End HTTP HEADER
   print_header_end();

   print qq~
   <html>
   <head>
   <META HTTP-EQUIV="Refresh" CONTENT="0; URL=$boardurl">
   </head>
   <body bgolor="#FFFFFF">
   <font size="4" face="verdana" color="#000099"><b>Loading Page, Please Wait...</b></font>
   </body>
   </html>
   ~;
   exit;
}

1;