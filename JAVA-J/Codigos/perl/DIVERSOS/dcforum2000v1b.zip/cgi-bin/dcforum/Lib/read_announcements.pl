# read_announcements.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#


#======================================================================#
# read_announcements                                                   #
# script to allow users to view announcements                          #
#======================================================================#

sub read_announcements {

   my ($r_in,$r_setup) = @_;
   my $menu_button = create_button('announcement',$r_in,$r_setup);
   my $heading = $forum_title;
   my $sub_heading = "General Announcements";
   my $r_data = readdata("$password_file_dir/$announcement");
   my $html_output;
   my $questions, $answers;
   my $j = 0;

   require "$cgilib/dcforumlib2.pl";
      
   print_header();
   print_header_end();

   my $num = @{$r_data};
   
   foreach (reverse @{$r_data}) {
      $j++;
      chomp;
      my ($ldate,$ltime,$subject,$message) = split /$split_delim/;
      $ldate = date_format($ldate);
      $ltime = time_format($ltime);
      $subject = dc_decode($subject);
      $message = text_to_html($message);

      if ($num > 5) {
         $questions .= qq~
         <li><a href="#$j">$subject</a>,  <font size="1">$ldate $ltime</font>
         ~;
      }
      
      $answers .= qq~
      <TABLE BORDER="0" WIDTH="$table_width" CELLPADDING="3" CELLSPACING="1">
         <TR>
         <TD BGCOLOR="$bg_color_2" ALIGN="LEFT" VALIGN="TOP">
         <font size="$font_size_2" face="$font_face_2" color="$font_color_2">
         <a name="$j"><b>$j. $subject</b></a> <font size="1">$ldate $ltime</font>
         </font></TD></tr><tr>
         <TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP">
         <font size="$font_size_1" face="$font_face_1" color="$font_color_1">
         <blockquote>
         $message
         </blockquote>
         <p align="right">
         [ <a href="#0">TOP</a> ]
         </p>
         </font>
         </TD>
      </TR>
      </table>~;
   }

   $html_output .= qq~
      <TABLE BORDER="0" WIDTH="$table_width" CELLPADDING="3" CELLSPACING="1">
         <TD BGCOLOR="$bg_color_0" ALIGN="LEFT" VALIGN="TOP">
         <font size="2" face="$font_face_0" color="$font_color_0">
         <a name="0"><b>General Announcements</b></a>
         </font></TD></tr><tr>
         <TR><TD BGCOLOR="$bg_color_1" ALIGN="LEFT" VALIGN="TOP">
         <font size="$font_size_1" face="$font_face_1" color="$font_color_1">
         <ol>
         $questions
         </ol>
         </font>
         </TD>
      </TR>
      </table>
   $answers
   ~;

   
   return ($heading, $sub_heading, $html_output,$menu_button);

}

1;