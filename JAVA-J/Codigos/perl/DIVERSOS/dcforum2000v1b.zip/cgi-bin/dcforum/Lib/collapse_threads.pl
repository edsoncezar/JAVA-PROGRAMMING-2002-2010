# collapse_threads.pl
#
# Part of DCForum2000 by DCScripts
# DCForum2000 Version 1.000
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# By using this script, you agree to the bind by the
# terms of agreement outlined in readme.txt distributed
# with DCForum package.
#===================================================================

#===================================================================
# function collapse_threads
# sets a cookie that collapses the threads in the main listing
#===================================================================

sub collapse_threads {
   my ($r_in,$r_setup) = @_;

   send_cookie($thread_style_cookie,'',
                  $expires,"/");
   
   print_header();
   print_header_end;
   print qq~
   <html>
   <head>
   <META HTTP-EQUIV="Refresh" CONTENT="0; URL=$ENV{'HTTP_REFERER'}">
   </head>
   <body bgolor="#FFFFFF">
   <font size="4" face="verdana" color="#000099">
      <b>Setting your option, please wait...</b></font>
   </body>
   </html>
   ~;

   exit;
}

1;