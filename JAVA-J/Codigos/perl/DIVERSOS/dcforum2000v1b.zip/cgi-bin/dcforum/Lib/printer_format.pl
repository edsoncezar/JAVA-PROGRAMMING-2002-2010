# printer_format.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#======================================================================#
# function print_format
# printer friendly format page generator
#======================================================================#

sub printer_format {

   require "$cgilib/print_topic.pl";

   my ($r_in,$r_setup) = @_;
   my $mesg;
   
   print_header();
   print_header_end();

   print "<html><head></head><body color=\"#FFFFFF\">\n";
   print qq~
   <font face="$font_face_2" size="2" color="#000099">
   <b>
   URL: $boardurl<br>
   Forum: $forum<br>
   Thread Number: $r_in->{'om'}<br>
   [ <a href="$ENV{'HTTP_REFERER'}">Go back to previous page</a> ]
   </b><hr>
   ~;

   my $str = print_topic($r_in,$r_setup);
   print $str;
   print "</font></body></html>\n";
   exit(0);

}


1;