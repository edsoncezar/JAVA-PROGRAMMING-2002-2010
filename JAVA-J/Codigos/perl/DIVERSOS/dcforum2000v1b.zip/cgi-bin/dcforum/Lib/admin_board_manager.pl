# admin_board_manager.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#===================================================================
# admin_board_manager
# admin utility for board manager
#===================================================================

sub admin_board_manager {

   my ($r_in,$r_setup) = @_;

	if ($r_in->{"command"} eq "admin_list_threads") {
		$r_in->{command} = $r_in->{'remove_type'};
		require "$cgilib/admin_list_threads.pl";
		my $thisfile = "$maindir/$forum/$database";
		$html_output = admin_list_threads($thisfile,$r_in,$r_setup);
	}
	elsif ($r_in->{"command"} eq "admin_rebuild_database") {
		require "$cgilib/admin_rebuild_database.pl";
	   $html_output = admin_rebuild_database($r_in,$r_setup);
	}
	elsif ($r_in->{"command"} eq "admin_list_messages") {
		require "$cgilib/admin_list_messages.pl";
		my $thisfile =
			"$maindir/$forum/$thread_dir/$thread_select.$thread_ext";
	   $html_output = admin_list_messages($thisfile,$r_in);
	}
	elsif ($r_in->{"command"} eq "admin_remove_messages") {
		require "$cgilib/admin_remove_messages.pl";
	   if ($r_in->{"thread_select"}) {
	      $thread_select = $r_in->{"thread_select"};
	   }
		my $thisfile =
			"$maindir/$r_in->{'forum'}/$thread_dir/$thread_select\.$thread_ext";
	   $html_output = admin_remove_messages($thisfile,$r_in,$r_setup);
	}
	elsif ($r_in->{"command"} eq "admin_queue") {
		require "$cgilib/admin_queue.pl";
	   $html_output = admin_queue($r_in,$r_setup);
	}
	elsif ($r_in->{'command'} eq '') {
		require "$cgilib/admin_list_forums.pl";
	   $html_output = admin_list_forums($r_in,$r_setup); 
	}
	else {
		require "$cgilib/$r_in->{'command'}.pl";
		my $thisfile = "$maindir/$forum/$database";
		my $command = '$html_output = ' 
						. $r_in->{'command'} . '($thisfile,$r_in,$r_setup)';
		eval($command);
	}
	
}

1;