# admin_start.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#
#======================================================================#
# admin_start                                                          #
# script for putting forum on line                                     #
#======================================================================#
sub admin_start {

   my ($r_in,$r_setup) = @_;
   my $html_output;

   if (-e "$password_file_dir/forumlock.lock") {
      unlink("$password_file_dir/forumlock.lock");
   }
      
   $html_output = print_status("Your forum is now online!");   
   
}

1;