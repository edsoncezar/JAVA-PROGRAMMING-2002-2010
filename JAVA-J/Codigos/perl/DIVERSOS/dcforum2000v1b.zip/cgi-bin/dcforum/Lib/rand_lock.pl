# rand_lock.pl
# DCForum2000 Version 1.0
# Part of DCForum by DCScripts
# Copyright  �1997-2000 DCScripts All Rights Reserved
# 
# As part of the installation process, you will be asked
# to accept the terms of Agreement outlined in the readme.txt
# included with this distribution. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts.
# You should carefully read this terms agreement before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of this software
#
#======================================================================#

#####
# function get_rand_lock
#####

sub get_rand_lock {

   my $num;
   srand;
   $num = int(rand 1000000) + 1;
   open(DUMMYFILE,">$password_file_dir/$num.dat") or 
      my_die("ERROR in get_rand_lock...Can't Create $password_file_dir/$num.dat",$!);
   close(DUMMYFILE);

   return $num;

}

#####
# function check_rand_lock
#
#####

sub check_rand_lock {

   my $num = shift;
   if (-e "$password_file_dir/$num.dat") {
      unlink("$password_file_dir/$num.dat") or 
         my_die("ERROR in check_rand_lock...Can't delete $password_file_dir/$num.dat",$!);
      return 1;
   }
   else {
      return 0;
   }
}

1;