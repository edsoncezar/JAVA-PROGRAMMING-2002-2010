### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Redirect
Version: 1.0

Info:

G.Redirect will take your visitors to a goodbye page before redirecting them 
to another site.

Here is the code:

http://www.yourdomain.com/cgi-bin/gredirect.cgi?url=http://www.yahoo.com




G.Scripts @ http://www.grantszone.co.uk/scripts/