###############################################################################
# xYsyD2QRDvks.pl                                                             #
###############################################################################
# GTChat (http://www.gtchat.de)                                               #
# GTChat 0.93 Copyright (c) 2001 by Wladimir Palant                           #
# Changes on this file are not permitted!                                     #
###############################################################################
$xku8Rf1mY5es='0727f66696c656f5269627478646164756f597561627s878414f69675c4177434e494uc537a2s87257716b635a6878647b6u72d7d372s87a4e4649627864413258763uf65747f536861647s87033793e425179416a49454u826236f60797b392c79a0223030313s875763a6253516a7445337u96e66796475646s877794a534268394d677d437u96e666f6f5s873754d613733735e436a563u02c3160286275666d322a6166716373627960747a316c65627478272s8735f4a44555c4b4a6447495uf2c6163747f536c65616e65646e2478747s87569355164344c4f64476u34f6e64756e647d245970756a30247568747f28647d6c6a0s87e694239695d457b4a7c477u777777e2s87969734757503374784d4ue276966622027796464786d322s876727439577c634379656d4u0447d607d304s8753335495c67566c4863454u72b3a0s87036354030797e64537d436ub7542525f425d7s8755c4b646a5e453476715u36f657c646e6f647f60756e6s87759407e4a43666a5568776u7627f65707s872686566527554666a436u32s87e4a5540313432765b63515ue21757565756s8705a797f4a7153373d43576uf2175756374796f6e6e276966622027796464786d322s879475c69395263586837677u02d30282s8725c424935797c415937415ue3e3s870587c42724771364935654uc396e60757470247970756d34756874702e616d656d3461697023796a756d34302d61687c656e6764786d323026716c65756d322s8757b6e674639617152335f6ua0s8737d6f465746435652783ua3s87857523039454c617466595u6216364796f6e6d3c6963656e63756s87034535c6a6d64374253736ub2c3s875325d6545473d426671714u27f6f6d6368616e6765646s87e6038617278793a783f494u42s8703a56775439664d6432323ue2c6e676s872635f68613465366d44795u1555542595f535452594e474s87331634a5a75625e4459755us8707f487d4d407230393d663uf28734566477552433a6679363e207c6s87c42776473676a7c64543b6ud372s87d6f4d615f605b4a45583d4u72c2s8717f4b4230356c465851394u2683s8764a68325b4264456056376ub772s8707c69607d66716762527d4u744534861647s8744a7462746c4e4a683b6ub79444d7s87b68444e6b41766d40386d4ub3a0s87856363141526b4959623f6ub3s875503843786655605274336ud6f646562716475646s87f4443345a41674e4978495u220226f627465627d3030216c647d322s87033543254463c4377517f6ue33556474796e67637e2461647s879737768374361786959415u5247d607d352s87a543343433b68553758594ua0a0s87c6769403f6b633a636f4d4u220226f627465627d30322e3c3f216e3s87b675651367a403075576u0727f66696c656f5269627478646164756f5d6f6e64786s872576a5452687c405148336u36f6d6d616e646s875483861736173337a523u729222e3c396d67602372736d322s8784e44597d6a4473755d455ud6563737167656s8707653474134714f6e48776u27f6f6d637f5d6f6465627164756s877795e45317e44695739637uc396d67602372736d322s873354e425767434f4138695u86474707a3f2f2s87f42484840795436425c6d4ub2e3s8755055386a4e4972493d4uc7s87d4d657e464860354247336u764736861647s87c69595d67317a426742377uf247271666669636e2478747s87c4978494239314e683f6b6u54870796275637a302e6f677a0a0s872456659714b66493d66336ue69636b6s8784944576031746b45577u22e3a0c33756c656364702e616d656d3d6f6e64786e3a0c3f6074796f6e6026716c65756d303e3s8725647444631456e6443355u0727f66696c656f5269627478646164756f5461697s87972594b677843774a757d4ud3s87033456b617f6f413f694u72s87f4476676636657172545f6uc4f636164796f6e6a302s8757c637b44784d4c6769715u3556474796e67637e2461647s8775e614a63503348373443713u175756374796f6e6s8784248395e425a4157423uc3f23756c6563647e3a0c396e60757470247970756d34756874702e616d656d397561627023796a756d34302d61687c656e6764786d343026716c65756d322s873325362315539556749677u7627f65707f547167637s8745a69605e4348446734363u47568747s8743649544545325e444d4ud6f6e6478637f5e616d65637s87178505747595562373d6f6u02s87361344578323c6c4d4c4u03s87f434244563f62674436515u562727f627s87f483f6456417f666160577u04s87f4a7170565279426a614u16364796f6e6s87267723e46683c4a5853395u17579647s870763452553e66465054663u22e3s87b6866755e61424b615f423u26a2s87e477655687775517a4e477ue2s8776249483d424e44767b6ue3s874433255313b64466b63454ue28647d6c6s8753d4a65535173636d4a576u7627f65707f5e616d65637s87f63654d4465485148494u0727966716475627f6f6d637s8776142427242675f4c61723ue2461647s8794e40526362476a496a523uf2d656d6265627c6963747e2478747s8774632467559363178736b6ue207960756s874676339316039466d663uf227f6f6d6c6963747e2478747s8796945554453767476615u562727f627f5s8703b4072745377507472415u27f6f6d6s875744776724c6b4a5f49663u16s877633e4244617572486d4uf2s871617b42733b42507974523u92b3a0s872367a644937386774483d4uf3s878635467693c426748576u22e3a0s87a447c4a5662664854577uf5s8757c486a543e4a6655603u05271676d616a302e6f6d23616368656a0s8795758737574563647767d4u34f4e44554e445f5c454e4744584s876496a7a683078693c6f454ue616d656s87276794b434a6376753341423u2653s8795554594464616467487b6uf2c6f676e2478747s874354c4543735b636d48377uf2f6e6c696e656e2s87236654a465969453e695u075627d616e656e647s873426142623874584a64714uc3f6074796f6e6026716c65756d3s872575765414372477734337uf677e65627s87c6d4334414f463d644f6u4247d607d342s87949597c4b6246383476536u36c6f6375646s8754659413057773764353u2202865696768647d322s87b4830335c6539727030795u13b3a0s874515142477d416e4366323u';$xFwQGmiWF8bk='666f72656163682873706c6974282f752f2c24786b75385266316d5935657329297b28247863305355434a596d6957362c24784b774239514a76445377293d73706c6974282f732f2c245f293b247863305355434a596d6957363d7061636b2827682a272c247863305355434a596d695736293b24784b774239514a764453773d7061636b2827682a272c24784b774239514a76445377293b6576616c20225c2424784b774239514a764453773d5c247863305355434a596d6957362269662824784b774239514a76445377206e65202222293b7d';eval pack('H*',$xFwQGmiWF8bk);$x0ireIpXNwc=0;require $sourcedir.$xLrgtcgzlT4k;sub xfSWX32A3yII{my $xqXlN1Cu6NaY=$xpOxMMp209m6;if(exists($ENV{$xFizj8ph9lOE})){read(STDIN,$xqXlN1Cu6NaY,$ENV{$xFizj8ph9lOE});}
foreach my $xl68PUPd2vRw(split(/&/,$xqXlN1Cu6NaY)){my($xqIeG0ByxeYk,$xfjDC527yPVw)=split(/=/,$xl68PUPd2vRw);$xqIeG0ByxeYk=~tr/+/ /;$xqIeG0ByxeYk=~s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;$xfjDC527yPVw=~tr/+/ /;$xfjDC527yPVw=~s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;$FORM{$xqIeG0ByxeYk}=$xfjDC527yPVw;}
foreach my $xl68PUPd2vRw(split(/&/,$ENV{$x3aCZzeRNTyU})){my($xqIeG0ByxeYk,$xfjDC527yPVw)=split(/=/,$xl68PUPd2vRw);$xqIeG0ByxeYk=~tr/+/ /;$xqIeG0ByxeYk=~s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;$xfjDC527yPVw=~tr/+/ /;$xfjDC527yPVw=~s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;$xOQDvGhWeId6{$xqIeG0ByxeYk}=$xfjDC527yPVw;}
$xD05zlY5ZzAE=$xu6jRSazD5s;$xAJuSEBXaieg=$xOQDvGhWeId6{$xbw2Nf8LZX3Y};if(defined($FORM{$xbw2Nf8LZX3Y})){$xAJuSEBXaieg=$FORM{$xbw2Nf8LZX3Y};}
}
sub xzjYW5VOv4Zo{my($xygim7DzhPlw)=@_;if($xSNHFGzSPWTo){flock($xygim7DzhPlw,$xv2QUPX1znxM);}
}
sub xdUYUhmAbJF{my($xygim7DzhPlw)=@_;if($xSNHFGzSPWTo){flock($xygim7DzhPlw,$xXvcnGDJBQ2o);}
}
sub xpeFJer25Gq2{my($xygim7DzhPlw)=@_;if($xSNHFGzSPWTo){flock($xygim7DzhPlw,$xTiVJwaR92kY);}
}
sub xFJpjUZYMRAQ{my($xCXPFhnmfQZc)=@_;open(FILE,$vardir.$x2fEJViI5nY.$xCXPFhnmfQZc)||return $xpOxMMp209m6;xzjYW5VOv4Zo(FILE);my $xqIeG0ByxeYk= <FILE>;xpeFJer25Gq2(FILE);close(FILE);return $xqIeG0ByxeYk;}
sub xN99wAdDgI3s{my($xqIeG0ByxeYk)=@_;my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);return-e$vardir.$x2fEJViI5nY.$xOyNORZAzvFA;}
sub xDUrH77sawno{my($xqIeG0ByxeYk,$x4OX8eK7yrDg)=@_;my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);if($x4OX8eK7yrDg){open(FILE,$x5RmEE7MbvqA.$vardir.$x2fEJViI5nY.$xOyNORZAzvFA)||return;xdUYUhmAbJF(FILE);}
else{open(FILE,$vardir.$x2fEJViI5nY.$xOyNORZAzvFA)||return;xzjYW5VOv4Zo(FILE);}
my @xI2SfLBsCuDI=split(/\|/, <FILE>);if($x4OX8eK7yrDg){$xI2SfLBsCuDI[5]=time;seek(FILE,0,0);truncate(FILE,0);print FILE join($xMmuNFh0EB7c,@xI2SfLBsCuDI);}
xpeFJer25Gq2(FILE);close(FILE);return @xI2SfLBsCuDI;}
sub xvvtnsV4JuQ{my @xI2SfLBsCuDI=@_;my $xqIeG0ByxeYk=$xI2SfLBsCuDI[0];my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);open(FILE,$x5RmEE7MbvqA.$vardir.$x2fEJViI5nY.$xOyNORZAzvFA)||return 0;xdUYUhmAbJF(FILE);truncate(FILE,0);print FILE join($xMmuNFh0EB7c,@xI2SfLBsCuDI);xpeFJer25Gq2(FILE);close(FILE);return 1;}
sub x5GkmgJjHbbU{my @xI2SfLBsCuDI=@_;my $xqIeG0ByxeYk=$xI2SfLBsCuDI[0];my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);my $xCXPFhnmfQZc=$xI2SfLBsCuDI[1];open(FILE,$xD3R51kDfkCE.$vardir.$x2fEJViI5nY.$xOyNORZAzvFA)||return 0;xdUYUhmAbJF(FILE);print FILE join($xMmuNFh0EB7c,@xI2SfLBsCuDI);xpeFJer25Gq2(FILE);close(FILE);open(FILE,$xD3R51kDfkCE.$vardir.$x2fEJViI5nY.$xCXPFhnmfQZc)||return 0;xdUYUhmAbJF(FILE);print FILE $xqIeG0ByxeYk;xpeFJer25Gq2(FILE);close(FILE);}
sub x9Bs9cdstn{my($xqIeG0ByxeYk,$xCXPFhnmfQZc)=@_;my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);open(FILE,$vardir.$x2fEJViI5nY.$xOyNORZAzvFA)||return;xdUYUhmAbJF(FILE);my @xI2SfLBsCuDI=split(/\|/, <FILE>);xpeFJer25Gq2(FILE);close(FILE);if($xCXPFhnmfQZc eq $xpOxMMp209m6){$xCXPFhnmfQZc=$xI2SfLBsCuDI[1];}
unlink($vardir.$x2fEJViI5nY.$xCXPFhnmfQZc);if($xI2SfLBsCuDI[1]eq $xCXPFhnmfQZc){my $text=xxIqC8u2aGCE($xE8hqcq3sZ2=>$xp6TR5nFVPd6);xc6oTTU4neoQ($text,$xqIeG0ByxeYk);unlink($vardir.$x2fEJViI5nY.$xOyNORZAzvFA);unlink($memberdir.$xaqKr3KRpyT2.$xOyNORZAzvFA.$xdg39a0Ifm6);unlink($memberdir.$xaqKr3KRpyT2.$xOyNORZAzvFA.$xPzyOzQ37MSg);my %x5cgUuJt9zc=xOcTa0KVV0vs($xqIeG0ByxeYk);if($x5cgUuJt9zc{$xrvIKCjsv5CA2}ne $xpOxMMp209m6&&$x5cgUuJt9zc{$xbheVrUdfJc}== -1){xCgtRhj9dsgs($x5cgUuJt9zc{$xrvIKCjsv5CA2});unlink($memberdir.$xaqKr3KRpyT2.$xOyNORZAzvFA.$xINPbcBgJiZ2);}
x300wp9yCfvU($x5cgUuJt9zc{$xuDwvBlKZOi6});$text=xxIqC8u2aGCE($xE8hqcq3sZ2=>$xp6TR5nFVPd6,$xrvIKCjsv5CA2=>$xqIeG0ByxeYk,$x4FYDE5RNDM=>x0an1r8i6yRQ($x0s9NRqIaJIE,$x5cgUuJt9zc{$xHITg0qdKUw},$chatname),$xuDwvBlKZOi6=>$x5cgUuJt9zc{$xuDwvBlKZOi6});xc6oTTU4neoQ($text);}
}
sub xOcTa0KVV0vs{my($xqIeG0ByxeYk)=@_;my $xOyNORZAzvFA=xykYDEOyWEzA($xqIeG0ByxeYk);open(FILE,$memberdir.$xaqKr3KRpyT2.$xOyNORZAzvFA.$xINPbcBgJiZ2)||return;xzjYW5VOv4Zo(FILE);my @xM4q9BznKQS6= <FILE>;xpeFJer25Gq2(FILE);close(FILE);my %xkdZSnpb3lRs=($xrvIKCjsv5CA2=>xx1IxDjaQYdo($xqIeG0ByxeYk));$xS5YGHQqs6UA=0;foreach my $xQR2wZgkKvF(split(/\|/,$xCemDF4eJzQQ)){$xM4q9BznKQS6[$xS5YGHQqs6UA]=~s/[\n\r]//g;$xkdZSnpb3lRs{$xQR2wZgkKvF}=$xM4q9BznKQS6[$xS5YGHQqs6UA];$xS5YGHQqs6UA++;}
return %xkdZSnpb3lRs;}
sub x1kUrDaEzCNA{my(%xkdZSnpb3lRs)=@_;my $xOyNORZAzvFA=xykYDEOyWEzA($xkdZSnpb3lRs{$xrvIKCjsv5CA2});open(FILE,$xD3R51kDfkCE.$memberdir.$xaqKr3KRpyT2.$xOyNORZAzvFA.$xINPbcBgJiZ2)||return;xdUYUhmAbJF(FILE);foreach my $xQR2wZgkKvF(split(/\|/,$xCemDF4eJzQQ)){$xkdZSnpb3lRs{$xQR2wZgkKvF}=$xpOxMMp209m6 if(!exists($xkdZSnpb3lRs{$xQR2wZgkKvF}));print FILE $xkdZSnpb3lRs{$xQR2wZgkKvF}.$xsmOVGFSVr8;}
xpeFJer25Gq2(FILE);close(FILE);}
sub xVOZKuRfVaJA{my($xqIeG0ByxeYk)=@_;open(FILE,$roomdir.$xaqKr3KRpyT2.xykYDEOyWEzA($xqIeG0ByxeYk).$xINPbcBgJiZ2)||return;xzjYW5VOv4Zo(FILE);my @xM4q9BznKQS6= <FILE>;xpeFJer25Gq2(FILE);close(FILE);my %xAxScyOKfdg=($xrvIKCjsv5CA2=>$xqIeG0ByxeYk);$xS5YGHQqs6UA=0;foreach my $xQR2wZgkKvF(split(/\|/,$xLU7064SLP9Y)){$xM4q9BznKQS6[$xS5YGHQqs6UA]=~s/[\n\r]//g;$xAxScyOKfdg{$xQR2wZgkKvF}=$xM4q9BznKQS6[$xS5YGHQqs6UA];$xS5YGHQqs6UA++;}
return %xAxScyOKfdg;}
sub x0V7DuLVZHHc{my(%xAxScyOKfdg)=@_;open(FILE,$xD3R51kDfkCE.$roomdir.$xaqKr3KRpyT2.xykYDEOyWEzA($xAxScyOKfdg{$xrvIKCjsv5CA2}).$xINPbcBgJiZ2)||return;xdUYUhmAbJF(FILE);foreach my $xQR2wZgkKvF(split(/\|/,$xLU7064SLP9Y)){$xAxScyOKfdg{$xQR2wZgkKvF}=$xpOxMMp209m6 if(!exists($xAxScyOKfdg{$xQR2wZgkKvF}));print FILE $xAxScyOKfdg{$xQR2wZgkKvF}.$xsmOVGFSVr8;}
xpeFJer25Gq2(FILE);close(FILE);}
sub xfcaNiIQWQ7M{my($xNDdprFV7S,$xhOuwji2zJY,%x2loKbvanXk)=@_;$xhOuwji2zJY=$xpOxMMp209m6 if(!defined($xhOuwji2zJY));my $x34TYv80bHBE=exists($x2loKbvanXk{$xkHDnKqfM0hM});my $xmrrVWfKWi6g;my $xeNAtukhExck=$xpOxMMp209m6;my $xIiVJiGRqXqM=$xDzdrdLNj8k.$xRwakSjxhtk.$xjNfck1c5I.$xRwakSjxhtk.$xD05zlY5ZzAE.$xRwakSjxhtk.$xyeQh5RSDWzE;my $xbeanYNloTEo=0;open(FILE,$templdir.$xaqKr3KRpyT2.$xNDdprFV7S.$x5MjUSqccMZg);xzjYW5VOv4Zo(FILE);my @xOjtr2zNIffg= <FILE>;xpeFJer25Gq2(FILE);close(FILE);foreach my $x73ca2h11Qs(@xOjtr2zNIffg){$x73ca2h11Qs=~s/[\n\r]//g;if($xhOuwji2zJY ne $xpOxMMp209m6&&$x73ca2h11Qs eq $xhOuwji2zJY){last;}
if(exists($x2loKbvanXk{$x73ca2h11Qs})){$xeNAtukhExck.=$x2loKbvanXk{$x73ca2h11Qs}.$xsmOVGFSVr8;}
else{if($x34TYv80bHBE){$xmrrVWfKWi6g=$x73ca2h11Qs;$xmrrVWfKWi6g=~s/\<[^\>]*\>//g;}
$x73ca2h11Qs=~s/\{CHATNAME\}/$chatname/g;$x73ca2h11Qs=~s/\{CGI\}/$xnXzppkBV5vU/g;$x73ca2h11Qs=~s/\{HTMLURL\}/$htmlurl\//g;$x73ca2h11Qs=~s/\{PULLMODE\}/$xkdZSnpb3lRs{pull}/g;$xbeanYNloTEo=1 if($x34TYv80bHBE&&$xmrrVWfKWi6g=~/$xIiVJiGRqXqM/i);$xeNAtukhExck.=$x73ca2h11Qs.$xsmOVGFSVr8;}
}
if($x34TYv80bHBE&& !$xbeanYNloTEo){my $xuL39SkePc=$xOBHHpY4FRlM.$xiyCWW0stHM.$xlYYm7qJbG2w.$xkp5WHFREMBY.$xFlzgcI3PV8o.$xhSdg9LbGXg.xMYOHFXvCsSo($xnXzppkBV5vU.$x0TSljm4GRsc);print $xulsKtHMlgyQ.$xuL39SkePc.$xlgI0ok3jcOM;xSruDmO5C7bM();}
else{print $xnI2iYMuKzLw;print $xYWxsuT6FwvM;print $xBeVyAkF9m6c;xyNq7W3qJM2($xeNAtukhExck);}
}
sub x7kCr55zf0eU{my($xNDdprFV7S,$xhOuwji2zJY,%x2loKbvanXk)=@_;$xhOuwji2zJY=$xpOxMMp209m6 if(!defined($xhOuwji2zJY));open(FILE,$templdir.$xaqKr3KRpyT2.$xNDdprFV7S.$x5MjUSqccMZg);xzjYW5VOv4Zo(FILE);my @xOjtr2zNIffg= <FILE>;xpeFJer25Gq2(FILE);close(FILE);my $xtZgZliJsE=0;foreach my $x73ca2h11Qs(@xOjtr2zNIffg){$x73ca2h11Qs=~s/[\n\r]//g;if($xtZgZliJsE==1){if(exists($x2loKbvanXk{$x73ca2h11Qs})){xyNq7W3qJM2($x2loKbvanXk{$x73ca2h11Qs}.$xsmOVGFSVr8);}
else{$x73ca2h11Qs=~s/\{CHATNAME\}/$chatname/g;$x73ca2h11Qs=~s/\{CGI\}/$xnXzppkBV5vU/g;$x73ca2h11Qs=~s/\{HTMLURL\}/$htmlurl\//g;xyNq7W3qJM2($x73ca2h11Qs.$xsmOVGFSVr8);}
}
if($xhOuwji2zJY ne $xpOxMMp209m6&&$x73ca2h11Qs eq $xhOuwji2zJY){$xtZgZliJsE=1;}
}
}
sub xOy95R0gSUWY{my $xyFF36pLnIFo=shift(@_);xfcaNiIQWQ7M($xO8oTFqofaPw,$xpOxMMp209m6,($xULkdZN5tvQ=>x0an1r8i6yRQ($x0KprTsWptBQ.$xyFF36pLnIFo,@_)));xSruDmO5C7bM();}
sub xpqh37zcXpI{my($xnfWF4tac6Ps)=@_;$xnfWF4tac6Ps=lc($xnfWF4tac6Ps);$xnfWF4tac6Ps=~tr/���/���/;return $xnfWF4tac6Ps;}
sub xx1IxDjaQYdo{$_[0]=xpqh37zcXpI($_[0]);}
sub x1yofEWiDRao{my($xqXZ09cow)=@_;xx1IxDjaQYdo($xqXZ09cow);$xqXZ09cow=~s/^#//;if(exists($color{$xqXZ09cow})){return $color{$xqXZ09cow};}
elsif($xqXZ09cow=~/^[0-9a-f]{1,6}$/){return $xNZE014rVkSQ.$xqXZ09cow;}
else{return $xpOxMMp209m6;}
}
sub xQUFbt7qJ8no{my($xTDATeZDBgoM)=@_;$xTDATeZDBgoM=~s/[\n\r]//g;my @xM4q9BznKQS6=split(/\|/,$xTDATeZDBgoM);if(!exists($xRuZn1teEGCs{$xM4q9BznKQS6[0]})){return($xE8hqcq3sZ2=>$xpOxMMp209m6);}
my %xSaQZAFlSh3k=($xE8hqcq3sZ2=>$xM4q9BznKQS6[0]);my $xS5YGHQqs6UA=1;foreach my $xQR2wZgkKvF(split(/\|/,$xRuZn1teEGCs{$xM4q9BznKQS6[0]})){$xSaQZAFlSh3k{$xQR2wZgkKvF}=$xM4q9BznKQS6[$xS5YGHQqs6UA];$xS5YGHQqs6UA++;}
return %xSaQZAFlSh3k;}
sub xxIqC8u2aGCE{my %xSaQZAFlSh3k=@_;if(!exists($xRuZn1teEGCs{$xSaQZAFlSh3k{$xE8hqcq3sZ2}})){return $xpOxMMp209m6;}
my $xTDATeZDBgoM=$xSaQZAFlSh3k{$xE8hqcq3sZ2};foreach my $xQR2wZgkKvF(split(/\|/,$xRuZn1teEGCs{$xSaQZAFlSh3k{$xE8hqcq3sZ2}})){$xTDATeZDBgoM.=$xMmuNFh0EB7c.$xSaQZAFlSh3k{$xQR2wZgkKvF};}
return $xTDATeZDBgoM;}
sub xEljKFIXzV2U{my $xyFF36pLnIFo=shift(@_);return xxIqC8u2aGCE($xE8hqcq3sZ2=>$xO8oTFqofaPw,$x4FYDE5RNDM=>x0an1r8i6yRQ($x0KprTsWptBQ.$xyFF36pLnIFo,@_));}
sub x3m4MMSYZjk{my $x37RsFXw7m32=shift(@_);return xxIqC8u2aGCE($xE8hqcq3sZ2=>$xO8oTFqofaPw,$x4FYDE5RNDM=>x0an1r8i6yRQ($xsEm17sSNcZ6.$x37RsFXw7m32,@_));}
sub xNfLGEa4Vfe2{$_[0]=~s/\&/\&amp\&/g;$_[0]=~s/;/\&#59;/g;$_[0]=~s/\&amp\&/\&amp;/g;$_[0]=~s/\"/\&quot;/g;$_[0]=~s/  / \&nbsp;/g;$_[0]=~s/</\&lt;/g;$_[0]=~s/>/\&gt;/g;$_[0]=~s/\|/\&#124;/g;$_[0]=~s/\t/ \&nbsp; \&nbsp; \&nbsp;/g;$_[0]=~s/\n/<br>/g;return $_[0];}
sub xduycyiEAak{my($xGFcYDxRuir,$xAxScyOKfdg)=@_;$xAxScyOKfdg=$xpOxMMp209m6 if(!defined($xAxScyOKfdg));my @xnfWF4tac6Ps=();opendir(DIR,$vardir);for(readdir(DIR)){if(/^online\._/){open(FILE,$vardir.$xaqKr3KRpyT2.$_);xzjYW5VOv4Zo(FILE);my @xI2SfLBsCuDI=split(/\|/, <FILE>);xpeFJer25Gq2(FILE);close(FILE);if(xY8IFTcRpRlA($xI2SfLBsCuDI[2],$xGFcYDxRuir)&&($xAxScyOKfdg eq $xpOxMMp209m6||$xAxScyOKfdg eq $xI2SfLBsCuDI[3])){closedir(DIR);return($xI2SfLBsCuDI[0],$xI2SfLBsCuDI[2]);}
elsif(xY8IFTcRpRlA(substr($xI2SfLBsCuDI[2],0,length($xGFcYDxRuir)),$xGFcYDxRuir)&&($xAxScyOKfdg eq $xpOxMMp209m6||$xAxScyOKfdg eq $xI2SfLBsCuDI[3])){push(@xnfWF4tac6Ps,$xI2SfLBsCuDI[0]);push(@xnfWF4tac6Ps,$xI2SfLBsCuDI[2]);}
}
}
closedir(DIR);return @xnfWF4tac6Ps;}
sub xJmmvFPnL5w2{my($xGFcYDxRuir)=@_;open(FILE,$memberdir.$xG6BvU96qxck);xzjYW5VOv4Zo(FILE);my @xM4q9BznKQS6= <FILE>;xpeFJer25Gq2(FILE);close(FILE);my @xnfWF4tac6Ps=();foreach my $xZAJEtGg65Q(@xM4q9BznKQS6){$xZAJEtGg65Q=~s/[\n\r]//g;my @xI2SfLBsCuDI=split(/\|/,$xZAJEtGg65Q);if($xI2SfLBsCuDI[0]eq $xGFcYDxRuir){return($xI2SfLBsCuDI[1],$xI2SfLBsCuDI[0]);}
elsif($xI2SfLBsCuDI[0]=~/^\Q$xGFcYDxRuir\E/i){push(@xnfWF4tac6Ps,$xI2SfLBsCuDI[1]);push(@xnfWF4tac6Ps,$xI2SfLBsCuDI[0]);}
}
return @xnfWF4tac6Ps;}
sub xCgtRhj9dsgs{my($xqIeG0ByxeYk,$xGFcYDxRuir)=@_;xx1IxDjaQYdo($xqIeG0ByxeYk);my $xBV2Mmak3e22=$xGFcYDxRuir;xx1IxDjaQYdo($xBV2Mmak3e22);open(FILE,$x5RmEE7MbvqA.$memberdir.$xG6BvU96qxck);xdUYUhmAbJF(FILE);@xAroxv4TIyc= <FILE>;my $xWkeyI1mCdTk=1;if($xGFcYDxRuir ne $xpOxMMp209m6){foreach my $xFZF595BEvxU(@xAroxv4TIyc){$xFZF595BEvxU=~s/[\n\r]//g;my($x6VeOI56IXQ,$xJsHpODWNVLQ)=split(/\|/,$xFZF595BEvxU);xx1IxDjaQYdo($x6VeOI56IXQ);if($xJsHpODWNVLQ ne $xqIeG0ByxeYk&&$x6VeOI56IXQ eq $xBV2Mmak3e22){return 0;}
}
$xWkeyI1mCdTk=0;}
seek(FILE,0,0);foreach my $xFZF595BEvxU(@xAroxv4TIyc){$xFZF595BEvxU=~s/[\n\r]//g;my($x6VeOI56IXQ,$xJsHpODWNVLQ)=split(/\|/,$xFZF595BEvxU);xx1IxDjaQYdo($x6VeOI56IXQ);if($xWkeyI1mCdTk==0&&$x6VeOI56IXQ gt $xBV2Mmak3e22){print FILE $xGFcYDxRuir.$xMmuNFh0EB7c.$xqIeG0ByxeYk.$xsmOVGFSVr8;$xWkeyI1mCdTk=1;}
if($xJsHpODWNVLQ ne $xqIeG0ByxeYk){print FILE $xFZF595BEvxU.$xsmOVGFSVr8;}
}
if($xWkeyI1mCdTk==0){print FILE $xGFcYDxRuir.$xMmuNFh0EB7c.$xqIeG0ByxeYk.$xsmOVGFSVr8;}
truncate(FILE,tell(FILE));xpeFJer25Gq2(FILE);close(FILE);return 1;}
sub xc6oTTU4neoQ{my($xSaQZAFlSh3k,$xg1HJCQu22Ek,$x8lET9vkKsWQ)=@_;my $x4POXlw59V46=time;my @xSYkooU2agQ=();if($xg1HJCQu22Ek ne $xpOxMMp209m6&&$x8lET9vkKsWQ eq $xpOxMMp209m6){my @xzk4JSeGb7Fk=xDUrH77sawno($xg1HJCQu22Ek);if($xzk4JSeGb7Fk[0]ne $xpOxMMp209m6){@xSYkooU2agQ=(xykYDEOyWEzA($xg1HJCQu22Ek).$xc1Du82lLML.$xzk4JSeGb7Fk[4]);}
}
else{opendir(DIR,$vardir);for(readdir(DIR)){if(/^online\._/){open(FILE,$vardir.$xaqKr3KRpyT2.$_);xzjYW5VOv4Zo(FILE);my($xqIeG0ByxeYk,$xCXPFhnmfQZc,$xGFcYDxRuir,$xAxScyOKfdg,$x1xxj02jmxJs,$xZXV1d7Dywg)=split(/\|/, <FILE>);xpeFJer25Gq2(FILE);close(FILE);if($x4POXlw59V46-$xZXV1d7Dywg>($x1xxj02jmxJs?$alive_test_rate_pull:$alive_test_rate)){x9Bs9cdstn($xqIeG0ByxeYk);}
elsif(($xg1HJCQu22Ek ne $xpOxMMp209m6&&$xg1HJCQu22Ek eq $xqIeG0ByxeYk)||($x8lET9vkKsWQ ne $xpOxMMp209m6&&$x8lET9vkKsWQ eq $xAxScyOKfdg)||($xg1HJCQu22Ek eq $xpOxMMp209m6&&$x8lET9vkKsWQ eq $xpOxMMp209m6)){push(@xSYkooU2agQ,xykYDEOyWEzA($xqIeG0ByxeYk).$xc1Du82lLML.$x1xxj02jmxJs);}
}
}
closedir(DIR);}
foreach my $xkdZSnpb3lRs(@xSYkooU2agQ){my($xqIeG0ByxeYk,$x1xxj02jmxJs)=split(/\s/,$xkdZSnpb3lRs);if($x1xxj02jmxJs){open(OUTPUT,$xPxLrBw1F9eE.$memberdir.$xaqKr3KRpyT2.$xqIeG0ByxeYk.$xPzyOzQ37MSg);xdUYUhmAbJF(OUTPUT);print OUTPUT $xSaQZAFlSh3k.$xsmOVGFSVr8;xpeFJer25Gq2(OUTPUT);close(OUTPUT);}
elsif(-p$memberdir.$xaqKr3KRpyT2.$xqIeG0ByxeYk.$xdg39a0Ifm6){open(OUTPUT,$xUP5hJNyB9M.$memberdir.$xaqKr3KRpyT2.$xqIeG0ByxeYk.$xdg39a0Ifm6);xdUYUhmAbJF(OUTPUT);print OUTPUT $xSaQZAFlSh3k.$xsmOVGFSVr8;xpeFJer25Gq2(OUTPUT);close(OUTPUT);}
}
if($log_clean_rate>0&&($x8lET9vkKsWQ ne $xpOxMMp209m6||$xg1HJCQu22Ek eq $xpOxMMp209m6||($xSaQZAFlSh3k=~/^msg\|/&&$log_private_msgs))){x3LRhbBvSnYw($xSaQZAFlSh3k,$xg1HJCQu22Ek,$x8lET9vkKsWQ);}
}
sub x3LRhbBvSnYw{my($xSaQZAFlSh3k,$xg1HJCQu22Ek,$x8lET9vkKsWQ)=@_;$x8lET9vkKsWQ=$xpOxMMp209m6 if(!defined($x8lET9vkKsWQ));my $xqSEGL3r0ank=time();open(LOG,$xPxLrBw1F9eE.$vardir.$x4ELEsSkcM8w);xdUYUhmAbJF(LOG);print LOG $xqSEGL3r0ank.$xMmuNFh0EB7c.$xg1HJCQu22Ek.$xMmuNFh0EB7c.$x8lET9vkKsWQ.$xMmuNFh0EB7c.$xSaQZAFlSh3k.$xsmOVGFSVr8;xpeFJer25Gq2(LOG);close(LOG);my $xxTdM91d0IU=0;open(FILE,$x5RmEE7MbvqA.$vardir.$xe9Ua4DLoDg);xdUYUhmAbJF(FILE);my $xqAfdx44pOPw= <FILE>;if($xqSEGL3r0ank-$xqAfdx44pOPw>$log_clean_rate){$xxTdM91d0IU=1;seek(FILE,0,0);print FILE $xqSEGL3r0ank;truncate(FILE,tell(FILE));}
xpeFJer25Gq2(FILE);close(FILE);if($xxTdM91d0IU==1){open(LOG,$x5RmEE7MbvqA.$vardir.$x4ELEsSkcM8w);xdUYUhmAbJF(LOG);@xM4q9BznKQS6= <LOG>;seek(LOG,0,0);foreach $xgWsEacGxL2(@xM4q9BznKQS6){if($xqSEGL3r0ank-$xgWsEacGxL2<=$log_length){print LOG $xgWsEacGxL2;}
}
truncate(LOG,tell(LOG));xpeFJer25Gq2(LOG);close(LOG);}
}
sub xjAeNiulrAs{my($xqSEGL3r0ank)=@_;my($xh2lLBgIWwx,$x3OXsIDQLVs,$xHDdkGsMvQ,$x4daoHRfApn6,$xixXINxHlpg,$xl0hfrccSf1c,$xbIqQur6lUvY,$xplNawXhCOw,$xtMM7PVP98qg)=localtime($xqSEGL3r0ank+$time_distance*3600);$xixXINxHlpg++;$xHDdkGsMvQ=$xOCBT6obG4VQ.$xHDdkGsMvQ if($xHDdkGsMvQ<10);$x3OXsIDQLVs=$xOCBT6obG4VQ.$x3OXsIDQLVs if($x3OXsIDQLVs<10);$xh2lLBgIWwx=$xOCBT6obG4VQ.$xh2lLBgIWwx if($xh2lLBgIWwx<10);$xl0hfrccSf1c=1900+$xl0hfrccSf1c;$xixXINxHlpg=$xOCBT6obG4VQ.$xixXINxHlpg if($xixXINxHlpg<10);$x4daoHRfApn6=$xOCBT6obG4VQ.$x4daoHRfApn6 if($x4daoHRfApn6<10);return $x4daoHRfApn6.$xgBI8MBNtvk.$xixXINxHlpg.$xgBI8MBNtvk.$xl0hfrccSf1c.$xc1Du82lLML.$xHDdkGsMvQ.$xXW20IElqdVY.$x3OXsIDQLVs.$xXW20IElqdVY.$xh2lLBgIWwx;}
sub xyNq7W3qJM2{my($x73ca2h11Qs)=@_;my $xnfWF4tac6Ps=print($x73ca2h11Qs);$x0ireIpXNwc+=length($x73ca2h11Qs);return $xnfWF4tac6Ps;}
sub xSruDmO5C7bM{xhsc20OXoUVk($x0ireIpXNwc);exit;}
sub xhsc20OXoUVk{if($enable_traffic_stat==0){return;}
my($xopryCSHoxE)=@_;my($xh2lLBgIWwx,$x3OXsIDQLVs,$xHDdkGsMvQ,$x4daoHRfApn6,$xixXINxHlpg,$xl0hfrccSf1c,$xbIqQur6lUvY,$xplNawXhCOw,$xtMM7PVP98qg)=localtime(time+$time_distance*3600);$xixXINxHlpg++;$xl0hfrccSf1c=1900+$xl0hfrccSf1c;$xixXINxHlpg=$xOCBT6obG4VQ.$xixXINxHlpg if($xixXINxHlpg<10);$x4daoHRfApn6=$xOCBT6obG4VQ.$x4daoHRfApn6 if($x4daoHRfApn6<10);my $xCTr5q4c7V6=$x4daoHRfApn6.$xgBI8MBNtvk.$xixXINxHlpg.$xgBI8MBNtvk.$xl0hfrccSf1c;my $xbeanYNloTEo=0;open(FILE,$x5RmEE7MbvqA.$vardir.$xLyHI29An8ok);xdUYUhmAbJF(FILE);@xM4q9BznKQS6= <FILE>;seek(FILE,0,0);foreach $xgWsEacGxL2(@xM4q9BznKQS6){$xgWsEacGxL2=~s/[\n\r]//g;my($xPGANIrRYGps,$x0ireIpXNwc)=split(/\|/,$xgWsEacGxL2);if($xCTr5q4c7V6 eq $xPGANIrRYGps){$xbeanYNloTEo=1;$x0ireIpXNwc+=$xopryCSHoxE;}
print FILE $xPGANIrRYGps.$xMmuNFh0EB7c.$x0ireIpXNwc.$xsmOVGFSVr8;}
if($xbeanYNloTEo==0){print FILE $xCTr5q4c7V6.$xMmuNFh0EB7c.$xopryCSHoxE.$xsmOVGFSVr8;}
truncate(FILE,tell(FILE));xpeFJer25Gq2(FILE);close(FILE);}
sub x300wp9yCfvU{my($xAxScyOKfdg)=@_;my %xLU7064SLP9Y=xVOZKuRfVaJA($xAxScyOKfdg);if($xLU7064SLP9Y{$xrvIKCjsv5CA2}ne $xpOxMMp209m6&&$xLU7064SLP9Y{$xrvIKCjsv5CA2}ne $defaultroom&&$xLU7064SLP9Y{$xCbAb2xTHjtA}==0){opendir(DIR,$vardir);for(readdir(DIR)){if(/^online\._/){open(FILE,$vardir.$xaqKr3KRpyT2.$_);xzjYW5VOv4Zo(FILE);my($xqIeG0ByxeYk,$xCXPFhnmfQZc,$xGFcYDxRuir,$xAxScyOKfdg,$x1xxj02jmxJs,$xZXV1d7Dywg)=split(/\|/, <FILE>);xpeFJer25Gq2(FILE);close(FILE);if($xLU7064SLP9Y{$xrvIKCjsv5CA2}eq $xAxScyOKfdg){closedir(DIR);return;}
}
}
closedir(DIR);unlink($roomdir.$xaqKr3KRpyT2.xykYDEOyWEzA($xLU7064SLP9Y{$xrvIKCjsv5CA2}).$xINPbcBgJiZ2);xVjHns7jBXOQ($xpOxMMp209m6,$xLU7064SLP9Y{$xrvIKCjsv5CA2});my $text=xxIqC8u2aGCE($xE8hqcq3sZ2=>$xn0hqrx9z8OI,$xuDwvBlKZOi6=>$xLU7064SLP9Y{$xrvIKCjsv5CA2});xc6oTTU4neoQ($text);}
}
sub x0z0CgcYHGA{my(%xAxScyOKfdg)=@_;return 0 if(!defined($xAxScyOKfdg{$xrvIKCjsv5CA2}));return 1 if($xAxScyOKfdg{$xEVI1Pw7g45}==0||xT7aPEPBsYrk($xgABrBbWOlq2)||$xkdZSnpb3lRs{$xrvIKCjsv5CA2}eq $xAxScyOKfdg{$xlM3DAO6mDo});foreach my $xgWsEacGxL2(split(/\s/,$xAxScyOKfdg{$xwIZCb8ImwMs})){if($xgWsEacGxL2 eq $xkdZSnpb3lRs{$xrvIKCjsv5CA2}){return 1;}
}
return 0;}
sub xArCqo7Sm2Zc{$_[0]=~s/^(\s|&nbsp;)*//g;$_[0]=~s/(\s|&nbsp;)*$//g;return $_[0];}
sub x0an1r8i6yRQ{my $xqIeG0ByxeYk=shift(@_);my $x5Zeg22jcQtg=0;if($xqIeG0ByxeYk=~/\!$/){$xqIeG0ByxeYk=~s/\!$//;$x5Zeg22jcQtg=1;}
my @xehhgKDYJ32A=split(/\n/,$message{$xqIeG0ByxeYk});my $x37RsFXw7m32=$xehhgKDYJ32A[rand @xehhgKDYJ32A];if($x5Zeg22jcQtg!=0){xNfLGEa4Vfe2($x37RsFXw7m32);$x37RsFXw7m32=sprintf($x37RsFXw7m32,@_);}
else{$x37RsFXw7m32=sprintf($x37RsFXw7m32,@_);xNfLGEa4Vfe2($x37RsFXw7m32);}
return $x37RsFXw7m32;}
sub xdWxbnIFvug{my($xqIeG0ByxeYk)=@_;my $tmp;eval $xIYyLkB68tVc.$xqIeG0ByxeYk.$xU0HshVePr4c;$tmp=~s/\r//g;$tmp=~s/\\/\\\\/g;$tmp=~s/\'/\\\'/g;print FILE $x0ZvW4iFm422.$xqIeG0ByxeYk.$xmOmQoPKJU8M.$tmp.$x06E0pynTsMc;}
sub x80nwhVEWhRk{my($xqIeG0ByxeYk)=@_;my $tmp;eval $xIYyLkB68tVc.$xqIeG0ByxeYk.$xU0HshVePr4c;$tmp+=0;print FILE $x0ZvW4iFm422.$xqIeG0ByxeYk.$x0CekqoO1oI.$tmp.$xX66AQbKYi2o;}
sub xZZ4O4LRJD8c{my($xqIeG0ByxeYk)=@_;my @tmp;eval $x53EYlWfLhCE.$xqIeG0ByxeYk.$xU0HshVePr4c;my $xTDATeZDBgoM=$xOzqPVrIbjA.$xqIeG0ByxeYk.$xRLB9uyLQ9GQ;foreach my $xgWsEacGxL2(@tmp){$xgWsEacGxL2=~s/\r//g;$xgWsEacGxL2=~s/\\/\\\\/g;$xgWsEacGxL2=~s/\'/\\\'/g;$xTDATeZDBgoM.=$xOtfg6fuqRTo.$xgWsEacGxL2.$xqOK20eLVX1I;}
$xTDATeZDBgoM=~s/\,$//g;print FILE $xTDATeZDBgoM.$x2vjD97hwD8M;}
sub xZoUvdbalLuc{my($xqIeG0ByxeYk)=@_;my %tmp;eval $xZ4CC3kX5WXI.$xqIeG0ByxeYk.$xU0HshVePr4c;foreach my $xyQdEN1R0lv6(sort keys %tmp){my $xTDATeZDBgoM=$tmp{$xyQdEN1R0lv6};$xTDATeZDBgoM=~s/\r//g;$xTDATeZDBgoM=~s/\\/\\\\/g;$xTDATeZDBgoM=~s/\'/\\\'/g;print FILE $x0ZvW4iFm422.$xqIeG0ByxeYk.$xplipmvagRrM.$xyQdEN1R0lv6.$xJNFirhD1Rx6.$xTDATeZDBgoM.$x06E0pynTsMc;}
}
sub x1gnnJc12gQ{open(FILE,$xD3R51kDfkCE.$language.$xbSoh1d5fMtY)||xOy95R0gSUWY($xWIpNJcfZexg,$language.$xbSoh1d5fMtY);xdUYUhmAbJF(FILE);xZZ4O4LRJD8c($xocEMdEXAHI);xZZ4O4LRJD8c($xTjiPNCHd746);xZZ4O4LRJD8c($xqXPGWYe27mo);xZoUvdbalLuc($xpVCG1tAoNxg);xZoUvdbalLuc($x4FYDE5RNDM);print FILE $xTQABwMaNc62;xpeFJer25Gq2(FILE);close(FILE);}
sub xykYDEOyWEzA{my($x4eZJrDcWbk)=@_;xx1IxDjaQYdo($x4eZJrDcWbk);my $x1eWxnlbQCU=unpack($xNwVexwUqJNw,$x4eZJrDcWbk);my $xnfWF4tac6Ps=$xuLhZ4NjVe0;for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<length($x1eWxnlbQCU);$xS5YGHQqs6UA+=5){my $xuHX71a6lJJE=substr($x1eWxnlbQCU,$xS5YGHQqs6UA,5);my $xRsbwmR4S342=ord(pack($xFj8RKbDeP6g,$xuHX71a6lJJE));if($xRsbwmR4S342<26){$xRsbwmR4S342+=ord($xg3NBdquBhM);}
else{$xRsbwmR4S342+=ord($xOCBT6obG4VQ)-26;}
$xnfWF4tac6Ps.=chr($xRsbwmR4S342);}
return $xnfWF4tac6Ps;}
sub xj633LuX3Js{my($xOyNORZAzvFA)=@_;xx1IxDjaQYdo($xOyNORZAzvFA);return $xpOxMMp209m6 if($xOyNORZAzvFA!~/^_/);$xOyNORZAzvFA=substr($xOyNORZAzvFA,1);my $x1eWxnlbQCU=$xpOxMMp209m6;for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<length($xOyNORZAzvFA);$xS5YGHQqs6UA++){my $xRsbwmR4S342=ord(substr($xOyNORZAzvFA,$xS5YGHQqs6UA,1));if($xRsbwmR4S342>=ord($xg3NBdquBhM)){$xRsbwmR4S342-=ord($xg3NBdquBhM);}
else{$xRsbwmR4S342-=ord($xOCBT6obG4VQ)-26;}
$x1eWxnlbQCU.=unpack($xYUTIddadGxk,chr($xRsbwmR4S342));}
my $xnfWF4tac6Ps=$xpOxMMp209m6;for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<length($x1eWxnlbQCU);$xS5YGHQqs6UA+=8){my $xuHX71a6lJJE=substr($x1eWxnlbQCU,$xS5YGHQqs6UA,8);if(length($xuHX71a6lJJE)==8){$xnfWF4tac6Ps.=pack($xFj8RKbDeP6g,$xuHX71a6lJJE);}
}
return $xnfWF4tac6Ps;}
sub xtRZhgIrGkJo{my($x4eZJrDcWbk)=@_;$x4eZJrDcWbk=xykYDEOyWEzA($x4eZJrDcWbk);if(-e$memberdir.$xaqKr3KRpyT2.$x4eZJrDcWbk.$xINPbcBgJiZ2){return 1;}
else{return 0;}
}
sub xprGwZ1RX5{$_[0]=~s/[=;\<\>\:\@\|\'\"\n\r]//g;xArCqo7Sm2Zc($_[0]);$_[0]=~s/\s/_/g;}
sub x1xsi9vdzkA6{$_[0]=~s/[\<\>\:\@\|\'\"\n\r]//g;xArCqo7Sm2Zc($_[0]);}
sub xVjHns7jBXOQ{my($xAxScyOKfdg,$xtZxrlbXFbbU)=@_;my $xmmmqH2dkhU=$xAxScyOKfdg;xx1IxDjaQYdo($xmmmqH2dkhU);xx1IxDjaQYdo($xtZxrlbXFbbU);open(FILE,$x5RmEE7MbvqA.$roomdir.$xiIUETsvtfQ);xdUYUhmAbJF(FILE);@xpOjZlydPRtQ= <FILE>;my $xWkeyI1mCdTk=0;seek(FILE,0,0);foreach my $xgWsEacGxL2(@xpOjZlydPRtQ){$xgWsEacGxL2=~s/[\n\r]//g;my $xU7j4qHSgnaQ=$xgWsEacGxL2;xx1IxDjaQYdo($xU7j4qHSgnaQ);if($xWkeyI1mCdTk==0&&$xAxScyOKfdg ne $xpOxMMp209m6&&$xU7j4qHSgnaQ gt $xmmmqH2dkhU){print FILE $xAxScyOKfdg.$xsmOVGFSVr8;$xWkeyI1mCdTk=1;}
if($xU7j4qHSgnaQ ne $xtZxrlbXFbbU){print FILE $xgWsEacGxL2.$xsmOVGFSVr8;}
}
if($xWkeyI1mCdTk==0&&$xAxScyOKfdg ne $xpOxMMp209m6){print FILE $xAxScyOKfdg.$xsmOVGFSVr8;}
truncate(FILE,tell(FILE));xpeFJer25Gq2(FILE);close(FILE);}
sub xY8IFTcRpRlA{my($a,$b)=@_;xx1IxDjaQYdo($a);xx1IxDjaQYdo($b);return($a eq $b);}
sub xMYOHFXvCsSo{my($xTDATeZDBgoM)=@_;$xTDATeZDBgoM=~s/(.)/"%".unpack("H2",$1)/eg;return $xTDATeZDBgoM;}
sub xdSUm5e4pZuQ{my $xnfWF4tac6Ps=$xuknG6iqQ2So.$text{$xyRIkwHsGzuM}.$xRFGD6AenD3U.$text{$xRgZTbxLPA8c}.$xsmOVGFSVr8;for(my $xS5YGHQqs6UA=1;$xS5YGHQqs6UA<=@months_names;$xS5YGHQqs6UA++){$xnfWF4tac6Ps.=$xRWgEAsBw74s.$xS5YGHQqs6UA.$xD3R51kDfkCE.$months_names[$xS5YGHQqs6UA-1];}
$xnfWF4tac6Ps.=$x3Rc2Q5YeGiw.$text{$xHAoiWLqGCNI}.$xJtLZfbFXTw;return $xnfWF4tac6Ps;}
sub xKPYVa1dBCQY{my($xqIeG0ByxeYk)=@_;if(exists($descr{$xqIeG0ByxeYk})){xNfLGEa4Vfe2($descr{$xqIeG0ByxeYk});my($xs4rLu9YkdXI,$xwx1tPMNsNg)=split(/,/,$image{$xHB8YNRJQG2});$descr{$xqIeG0ByxeYk}=~s/\'/\\\'/g;return $xSOJTULKjDGY.$descr{$xqIeG0ByxeYk}.$xHNTymJtsUMU.$imagesurl.$xIWl9YbSh8gw.$xs4rLu9YkdXI.$xK80Sl5yr0pY.$xwx1tPMNsNg.$xkWV1vJ0pUg;}
return $xpOxMMp209m6;}
sub xN5nSt3BUz1o{open(FILE,$xysg8GcqhYIQ)||xOy95R0gSUWY($xWIpNJcfZexg,$xWnAjS0C87Ds1);xdUYUhmAbJF(FILE);foreach my $x1ZCu39KwYNI(split(/\|/,$xSFJMXlGSj1Y)){if($x1ZCu39KwYNI=~/^\$/){$x1ZCu39KwYNI=~s/^\$//;xdWxbnIFvug($x1ZCu39KwYNI);}
elsif($x1ZCu39KwYNI=~/^\#/){$x1ZCu39KwYNI=~s/^\#//;x80nwhVEWhRk($x1ZCu39KwYNI);}
elsif($x1ZCu39KwYNI=~/^\@/){$x1ZCu39KwYNI=~s/^\@//;xZZ4O4LRJD8c($x1ZCu39KwYNI);}
elsif($x1ZCu39KwYNI=~/^\%/){$x1ZCu39KwYNI=~s/^\%//;xZoUvdbalLuc($x1ZCu39KwYNI);}
}
print FILE $xTQABwMaNc62;xpeFJer25Gq2(FILE);close(FILE);}
sub xT7aPEPBsYrk{my($xqIeG0ByxeYk)=@_;if(exists($permission{$xqIeG0ByxeYk})&&$xkdZSnpb3lRs{$xbheVrUdfJc}>=$permission{$xqIeG0ByxeYk}){return 1;}
else{return 0;}
}
sub xrdwdbBDmkE{my($xqIeG0ByxeYk,$xcm0ZahuaB5U,%xAxScyOKfdg)=@_;if($xAxScyOKfdg{$xOD3TJaGNyHY}==0||xY8IFTcRpRlA($xAxScyOKfdg{$xlM3DAO6mDo},$xqIeG0ByxeYk)||$xcm0ZahuaB5U>=$permission{$xwYN5qNdY7is}){return 1;}
else{return 0;}
}
sub xfHwJyKKclf6{my($text,@xE0WAuDzHZNM)=@_;for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<@xE0WAuDzHZNM;$xS5YGHQqs6UA++){if($xE0WAuDzHZNM[$xS5YGHQqs6UA]eq $text){return $xS5YGHQqs6UA;}
}
return-1;}
sub xbc6fIeEUsCY{my($xqIeG0ByxeYk,$xKYdsGoZucyk)=@_;my($xs4rLu9YkdXI,$xwx1tPMNsNg)=split(/,/,$image{$xqIeG0ByxeYk});return $x3ENRgGCO1hY.$imagesurl.$xaqKr3KRpyT2.$xqIeG0ByxeYk.$xvr4YwlCsieM.$xs4rLu9YkdXI.$xK80Sl5yr0pY.$xwx1tPMNsNg.$x0S4RD6LsWqo.$xKYdsGoZucyk.$xkhvUnABkQO2;}
1;