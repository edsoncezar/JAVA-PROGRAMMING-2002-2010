###############################################################################
# xK1wPVZS8UIM.pl                                                             #
###############################################################################
# GTChat (http://www.gtchat.de)                                               #
# GTChat 0.93 Copyright (c) 2001 by Wladimir Palant                           #
# Changes on this file are not permitted!                                     #
###############################################################################
$xBVOMKfCQCg='c202q87547705a4743303d4475494y96d676q87c4d61523e4d6f6d4d61354ye69636b6q87661364a646e4377563y1646d696e6q87c6b63405d61714d4672323y27f6f6d696e6q87547673e497f60513f4f6ye616d656q87557713e42693834713a794yd63776q8764a693178573d447746415y220226f627465627d303e3q87258365a6763536f4a57494y96e666f6f56796071646465646q87d673945324543647c4f613y96e666f6f596d676f507279667164756q87f424865334c623e42397y36f6d6d616e646q876305e433c663a6948534f6ye276966622027796464786d322q8725332365a7935717a405y47f6q87a656742785b64426b437f6y57e69676e6f62756q8753036466643647979415ya3c3f226e302c366f6e6470236f6c6f627d322q872523462594340574147613y92a3c3f226e302q873476534355c4c605951737y22e3q87d4f48405844327173623yc33656e6475627e3c396d67602372736d322q873626d4c4577796c40514yd6f646562716475646368616e6765646q8745e465674414462794d414yf2d656373716765637e28647d6c6q87733415569787147397d4y22e3c326e3q878794136625c40776761495y5737562737f5471676d6f64656271647f627q878757d4c4870705c6865777yc3f266f6e647e302d5c32627e3a0q8776b425835693b6562714y679607q8786141503e476a7a79714yc3373627960747e3570746164756f4074796f6e6378292b3c3f2373627960747e3a0q87571667c40533845734a6y0282q87167675a726957464b6e494y0757c6c6q87a7b465741686d675457676yc32627e3c32627e3a0q8716145354a4f6f60734433623yq87a4c62574b6658574448654yc32627e3c32627e3c32627e3a0q8776d43675f654f4d467e614ya302q87f467f6d644270796148423y679607368616e6765646q8747d6855445446734976537y96e666f6f557e696e66796475646q87c6834576d66397374645d4yc3f226e3c32627e3a0q875555f416443317547555yd656q87642423f6f445452395a594ya0q872446442473b4a464834715y27f6f6d6368616e6765646q8747e62416262497866536yc2q8765658344850594a7a614y762756564796e676f547f6079636q8717d64335833517758315y96e666f6f516771697f6e6q873386c473664473059755yc326e3q8783658463c43766b43714d413yc32627e3q8716145354a4f6f60734433613yc3f266f6e647e3c32627e3a0q8705d6a64713167666d437y47568747f547167647f616c6c6q87c4f666846465760377559433yf2q871617b42733b4250797452313y96e636f6d656q873376d463059454a6268454y02d5c32627e3a0q87371745163443872593a7d4y47568747q87c4f666846465760377559413y96e666f6f59676e6f62756375736365637376657c6q8775a676d635d49764250537yc3373627960747e357074616475655375627c49637478292b3c3f2373627960747e3a0q879385c4b603539453934537y47568747f65747q87a7c6875533c6a4547654yc396d67602372736d322q872324b487e403245694a436y562727f627q875466b6b46657b456953336y22e3c396e362c647b3q87e4476493667664a4673523y47568747f54716760727966716475647f6q874407971487467377230323y02q87361344578323c6c4d4c413y2627f6164636163747q875487b417d6a577464744y96e666f6f516771697f66666q87557627a7330367d666a737yf677e65627368616e6765646q87a536f63326f487e47423yc32627e3a0q8776e487c457a79716d4a494y37d696c6569737q87373636a6535627a51747yc366f6e6470236f6c6f627d322q874797131617269677544363yb502c326e3q87d47696a75507439737b4b6yb7d454353514745435d7q8746267377861635547447f613y6627f6d6q875437f4030726837557c414y5727c6q876393364676444657177563y4756874796e6q8775753677071305253435f6y36f6c6f627q8795c4b654372503a4656636y96e666f6f537d696c6569737375736365637376657c6f5f6e6q87d405e45796874596b65676y92q87b4945514951476949416f6y22e3c3f23656e6475627e3c32627e3a0q87d403161317033643669523y9676e6f62756q87f617376684142466a68576y47f6079636q87b49534437366a694367714yc3373627960747e357074616475694e60757478292b3c3f2373627960747e3a0q87e4965595874705a745a7f6y47568747f547167607279667164756q87d6d4f447368505355423yc6f67696e6q8754939727960523951513y762756564796e676f57756c636f6d656q87369353839344d47336d4y96e666f6f557e69676e6f62756375736365637376657c6q87c694f437172474d6b41437y96e666f6f596e66796475646q87d673945324543647c4f6yd6f646562716475646q876746764525739745a5d4y47f6e69636b6q8754d44603362544f4c67414y96e69647q8747f645948637c6e67414y627647b3c3f296e3c3f266f6e647e3c32627e3a0q8734172383a436a4550714y27f6f6d6f65747q8747155687650727642683b6y2202865696768647d322q87754393154407e62723y220216c647d322q876535245787d67305762623y16771697q87932564757455e433731723y47568747f547167647f6q87c4f666846465760377559423y96e666f6f537d696c6569737375736365637376657c6f5f66666q8786c4736465532666d494y96e666f6f596d676q875673a775550363448777y17579647q8765b627556603732773y96e666f6f56796072756d6f6675646q8786c4736465532666d49413y27f6f6d6q8793860565f4855584d42714y96e666f6f536f6c6f627375736365637376657c6q87c476350785a753a4635754y96e667964756q8766e665f6775796a4166437y7627f65707q8714c4834366073457a47576yc3373627960747e357074616475625f6f6d6c49637478292b3c3f2373627960747e3a0q871743634485a756342354yf6574736f6d656q8714f67694a7132764a4b495ya3c3f226e302q878747839666a54353c4a4f6y';$xkNJz3Yw4G4k='666f72656163682873706c6974282f792f2c247842564f4d4b664351436729297b28247845785978475771317844362c24784d686d50583069397563293d73706c6974282f712f2c245f293b247845785978475771317844363d7061636b2827682a272c24784578597847577131784436293b24784d686d505830693975633d7061636b2827682a272c24784d686d50583069397563293b6576616c20225c2424784d686d505830693975633d5c247845785978475771317844362269662824784d686d50583069397563206e65202222293b7d';eval pack('H*',$xkNJz3Yw4G4k);sub x3uYtitJiak{my %xAxScyOKfdg=xVOZKuRfVaJA($xkdZSnpb3lRs{$x9hPVOXUHMrA});my %xAah8anZwInE=xQUFbt7qJ8no($_[0]);if($xAah8anZwInE{$x6PN3l6jIXCo}eq $xLofHFVg0wUI1){if(xnexithue9U($xAah8anZwInE{$xUw1Nb98t1zI})!=0){return $xJlRGkVXGDhE;}
if($xAah8anZwInE{$xvdgTR7yTZM}!=0&&$xAah8anZwInE{$xUw1Nb98t1zI}ne $xkdZSnpb3lRs{$xUw1Nb98t1zI}&& !xrdwdbBDmkE($xkdZSnpb3lRs{$xUw1Nb98t1zI},$xkdZSnpb3lRs{$xAL84fpCuJWg},%xAxScyOKfdg)){return $xJlRGkVXGDhE;}
x0SdfMrMkhgk($xAah8anZwInE{$xLofHFVg0wUI1},1);my $xTzH5v13Xxf6=$xJlRGkVXGDhE;if($xAah8anZwInE{$xvdgTR7yTZM}!=0){$xAah8anZwInE{$xEMd0cRDOlGA}=$text{$xxuMLxpPlhuw};}
if($xAah8anZwInE{$xEMd0cRDOlGA}ne $xJlRGkVXGDhE){$xTzH5v13Xxf6=$xJlRGkVXGDhE;foreach my $xGFcYDxRuir(split(/\s/,$xAah8anZwInE{$xEMd0cRDOlGA})){$xTzH5v13Xxf6.=$xGFcYDxRuir.$xEwPJG30MtEI;}
$xTzH5v13Xxf6=~s/,\s$//;$xTzH5v13Xxf6=$xagWzbYGFkNI.sprintf($text{$xLofHFVg0wUI2},$xTzH5v13Xxf6).$xKIUAYAgIIao;}
return $xty1aqbiwE46.$xAah8anZwInE{$xYLkEsR0JVfc}.$xxI1fRLpggAY.$xAah8anZwInE{$xf1FjdNsW6}.$xTzH5v13Xxf6.$xxt8ifZ45LJo.$xAah8anZwInE{$xLofHFVg0wUI1}.$xPmjt1agfMs;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xFj9qX7MtGFQ){x0SdfMrMkhgk($xAah8anZwInE{$xLofHFVg0wUI1},1);if(xnexithue9U($xAah8anZwInE{$xEsO0pb8WuLA})!=0){return $xJlRGkVXGDhE;}
if($xAah8anZwInE{$xEsO0pb8WuLA}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){return $xty1aqbiwE46.$xAah8anZwInE{$xYLkEsR0JVfc}.$xxI1fRLpggAY.$xAah8anZwInE{$xf1FjdNsW6}.$xagWzbYGFkNI.sprintf($text{$xDpyAxd7w202},$xAah8anZwInE{$xEMd0cRDOlGA}).$xCg54ULlPYqs.$xAah8anZwInE{$xLofHFVg0wUI1}.$xPmjt1agfMs;}
if($xAah8anZwInE{$xjeGrXkDbKso}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){return $xty1aqbiwE46.$xAah8anZwInE{$xYLkEsR0JVfc}.$xxI1fRLpggAY.$xAah8anZwInE{$xf1FjdNsW6}.$xagWzbYGFkNI.$text{$xmMOtcXPSE2}.$xCg54ULlPYqs.$xAah8anZwInE{$xLofHFVg0wUI1}.$xPmjt1agfMs;}
}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xFB2oOTT2YZI){if(xnexithue9U($xAah8anZwInE{$xUw1Nb98t1zI})!=0){return $xJlRGkVXGDhE;}
x0SdfMrMkhgk($xAah8anZwInE{$xLofHFVg0wUI1},0);return $xty1aqbiwE46.$xAah8anZwInE{$xYLkEsR0JVfc}.$xNtF9fgFJvS2.$xAah8anZwInE{$xf1FjdNsW6}.$xc1Du82lLML1.$xAah8anZwInE{$xLofHFVg0wUI1}.$xCq28JcJUpA;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xLmQ2NmoMm1E){$xAah8anZwInE{$x69cdgDduqW6}=~s/\"//g;if($xAah8anZwInE{$xEMd0cRDOlGA}eq $xJlRGkVXGDhE){return $xcbMLuwiLPA.$xAah8anZwInE{$x69cdgDduqW6}.$xVSBuxm7Pgb2.x0an1r8i6yRQ($xe7zWU06Dxw,$xAah8anZwInE{$xf1FjdNsW6}).$xM0a1q0c4fY2;}
else{return $xcbMLuwiLPA.$xAah8anZwInE{$x69cdgDduqW6}.$xVSBuxm7Pgb2.x0an1r8i6yRQ($xOBh5Cl2N2y,$xAah8anZwInE{$xEMd0cRDOlGA},$xAah8anZwInE{$xf1FjdNsW6}).$xM0a1q0c4fY2;}
}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xExKqmZwdtD){x0SdfMrMkhgk($xAah8anZwInE{$xLofHFVg0wUI1},1);return $xty1aqbiwE46.$xAah8anZwInE{$xYLkEsR0JVfc}.$xxI1fRLpggAY.$xAah8anZwInE{$xf1FjdNsW6}.$xagWzbYGFkNI.$text{$xLofHFVg0wUI3}.$xCg54ULlPYqs.$xAah8anZwInE{$xLofHFVg0wUI1}.$xPmjt1agfMs;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xlkCPmqAMv22){return $x8VH6LsfKsAM1.$xAah8anZwInE{$xLofHFVg0wUI1}.$xUUOaD3qEWU;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $x9RFWGUN37q2){if($xAah8anZwInE{$xUw1Nb98t1zI}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){$xkdZSnpb3lRs{$x9RFWGUN37q2}=$xAah8anZwInE{$x9RFWGUN37q2};}
my $text=$x9XLk05I59Ts;if($xAxScyOKfdg{$xvdgTR7yTZM}==0){if($xAah8anZwInE{$x9RFWGUN37q2}!=0){if($xAah8anZwInE{$xLofHFVg0wUI1}ne $xJlRGkVXGDhE){$xAah8anZwInE{$xLofHFVg0wUI1}=$xOvomDrpiAH2.$xAah8anZwInE{$xLofHFVg0wUI1};}
$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($x3hL7fD7PyU,$xAah8anZwInE{$xf1FjdNsW6}).$xAah8anZwInE{$xLofHFVg0wUI1}.$xsqTaC4xR9zM;}
else{$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xUgrz30vmfzs,$xAah8anZwInE{$xf1FjdNsW6}).$xsqTaC4xR9zM;}
}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xEfkKfuKeY3c){return $xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xLofHFVg0wUI1}.$xsqTaC4xR9zM;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xYLkEsR0JVfc){$xkdZSnpb3lRs{$xYLkEsR0JVfc}=$xAah8anZwInE{$xYLkEsR0JVfc};return $xMgizUp4ysKk.$chatname.$xR2dRICPGAg1.$xAah8anZwInE{$xYLkEsR0JVfc}.$xMOHPH4rqc2.x0an1r8i6yRQ($xLgSpXz5J6uE,$xAah8anZwInE{$xf1FjdNsW6}).$xgKR8e9kerA;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xsccj5erZqt){$xkdZSnpb3lRs{$xsccj5erZqt}=$xAah8anZwInE{$xsccj5erZqt};my $text=$xNiUYxtPzTzo;if($xkdZSnpb3lRs{$xsccj5erZqt}!=0){return $text.$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xMPNuixTikeg,$xAah8anZwInE{$xf1FjdNsW6}).$xsqTaC4xR9zM;}
else{return $text.$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xhL7FV5bfMI,$xAah8anZwInE{$xf1FjdNsW6}).$xsqTaC4xR9zM;}
}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xf1FjdNsW6){if($xAah8anZwInE{$xUw1Nb98t1zI}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){$xkdZSnpb3lRs{$xf1FjdNsW6}=$xAah8anZwInE{$xEMd0cRDOlGA};}
my $text=$x9XLk05I59Ts;if($xAxScyOKfdg{$xvdgTR7yTZM}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xLofHFVg0wUI1}.$xsqTaC4xR9zM;}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $x9hPVOXUHMrA){my $text=$xJlRGkVXGDhE;if($xAah8anZwInE{$xUw1Nb98t1zI}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){my %xUK683ZKWBU=%xAxScyOKfdg;if($xkdZSnpb3lRs{$x9hPVOXUHMrA}eq $xAah8anZwInE{$xEg7NyoP1Oo}){%xUK683ZKWBU=xVOZKuRfVaJA($xAah8anZwInE{$xtQexVprFb8k});}
else{$xkdZSnpb3lRs{$x9hPVOXUHMrA}=$xAah8anZwInE{$xEg7NyoP1Oo};%xAxScyOKfdg=xVOZKuRfVaJA($xkdZSnpb3lRs{$x9hPVOXUHMrA});}
$text.=$x9XLk05I59Ts;$text.=$xq46DXzeC2E;$text.=$xaA5EJoopC4c1.xC6nyJeQFXA($xUK683ZKWBU{$xAogIz1rFJKY}).$xgMcWoEOMvnA;$text.=xC6nyJeQFXA($xAxScyOKfdg{$x3gM6PIEjbHE}).$xgNxLuzyaMJI;$text.=x0an1r8i6yRQ($xc9589DM7cM,$xAxScyOKfdg{$xUw1Nb98t1zI}).$xgNxLuzyaMJI;$text.=x0an1r8i6yRQ($xqm4S8SqW8Q,$xAxScyOKfdg{$xKYC47fjIcwA}).$xaA5EJoopC4c2;}
else{if($xAah8anZwInE{$xtQexVprFb8k}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}){$text.=$x9XLk05I59Ts;if($xAxScyOKfdg{$xvdgTR7yTZM}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xzlxU3lJEgE}.$xsqTaC4xR9zM;}
}
if($xAah8anZwInE{$xEg7NyoP1Oo}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}){$text.=$x9XLk05I59Ts;if($xAxScyOKfdg{$xvdgTR7yTZM}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xWWcwp1PRCSo}.$xsqTaC4xR9zM;}
}
}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xoqsfHABfjXg){if(!$xkdZSnpb3lRs{$xzKVGahmWTgg}){my @xs27rVSQvZ6=split(/\s/,$xkdZSnpb3lRs{$xoqsfHABfjXg});push(@xs27rVSQvZ6,$xAah8anZwInE{$xUw1Nb98t1zI});$xkdZSnpb3lRs{$xoqsfHABfjXg}=join($xc1Du82lLML1,@xs27rVSQvZ6);}
return $xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xWjgmSMyFRPs,$xAah8anZwInE{$xf1FjdNsW6}).$xsqTaC4xR9zM;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $x50FfFctyIQ){if(!$xkdZSnpb3lRs{$xzKVGahmWTgg}){my @xs27rVSQvZ6=split(/\s/,$xkdZSnpb3lRs{$xoqsfHABfjXg});for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<@xs27rVSQvZ6;$xS5YGHQqs6UA++){if($xs27rVSQvZ6[$xS5YGHQqs6UA]eq $xAah8anZwInE{$xUw1Nb98t1zI}){splice(@xs27rVSQvZ6,$xS5YGHQqs6UA,1);last;}
}
$xkdZSnpb3lRs{$xoqsfHABfjXg}=join($xc1Du82lLML1,@xs27rVSQvZ6);}
return $xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xlIOsqBGmKAs,$xAah8anZwInE{$xf1FjdNsW6}).$xsqTaC4xR9zM;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xfnVowuiJaFs){my $text=$xq46DXzeC2E;if($xAah8anZwInE{$xfnVowuiJaFs}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xl8Tgm6ysdTM,$xAah8anZwInE{$x9hPVOXUHMrA}).$xsqTaC4xR9zM;}
else{$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xm7I5BEctLo,$xAah8anZwInE{$x9hPVOXUHMrA}).$xsqTaC4xR9zM;}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xhAQ0NgzzyA){my $text=$xJlRGkVXGDhE;if($xAah8anZwInE{$xhAQ0NgzzyA}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xhL7FV5bfMI1,$xAah8anZwInE{$x9hPVOXUHMrA}).$xsqTaC4xR9zM;}
else{$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.x0an1r8i6yRQ($xm7I5BEctLo1,$xAah8anZwInE{$x9hPVOXUHMrA}).$xsqTaC4xR9zM;}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xtmXETDvCyVs){return $x9XLk05I59Ts;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xAL84fpCuJWg){my $text=$x9XLk05I59Ts;if($xAah8anZwInE{$xUw1Nb98t1zI}eq $xkdZSnpb3lRs{$xUw1Nb98t1zI}){$xkdZSnpb3lRs{$xAL84fpCuJWg}=$xAah8anZwInE{$xAL84fpCuJWg};$text.=$xq46DXzeC2E;$text.=$xuavLP3HuCj;}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xtnBabByhVc){return $xq46DXzeC2E;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xZco3bOxNG2&&$xAah8anZwInE{$x9hPVOXUHMrA}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}){return $x9XLk05I59Ts;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xTNVvDAdrIMA&&$xAah8anZwInE{$x9hPVOXUHMrA}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}){return $x9XLk05I59Ts;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xVkrUf07r7){my $text=$xJlRGkVXGDhE;if($xAah8anZwInE{$x9hPVOXUHMrA}eq $xJlRGkVXGDhE){$text.=$xaA5EJoopC4c1.xC6nyJeQFXA($xAxScyOKfdg{$xAogIz1rFJKY}).$xgMcWoEOMvnA;$xCSboz2RU66=1;}
else{if($xAah8anZwInE{$x9hPVOXUHMrA}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}&&$xAxScyOKfdg{$xvdgTR7yTZM}==0){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xLofHFVg0wUI1}.$xsqTaC4xR9zM;}
$text.=$x9XLk05I59Ts;}
return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xE9yriP2YQ1){my $text=$xJlRGkVXGDhE;if($xAah8anZwInE{$xUw1Nb98t1zI}ne $xkdZSnpb3lRs{$xUw1Nb98t1zI}&&$xAah8anZwInE{$x9hPVOXUHMrA}eq $xkdZSnpb3lRs{$x9hPVOXUHMrA}&& !$xAxScyOKfdg{$xvdgTR7yTZM}){$text.=$xMgizUp4ysKk.$chatname.$xxt8ifZ45LJo.$xAah8anZwInE{$xLofHFVg0wUI1}.$xsqTaC4xR9zM;}
$text.=$x9XLk05I59Ts;return $text;}
elsif($xAah8anZwInE{$x6PN3l6jIXCo}eq $xtoTIhslnGA){open(FILE,$templdir.$x7CQeyxA7yM);xzjYW5VOv4Zo(FILE);my @xOjtr2zNIffg= <FILE>;xpeFJer25Gq2(FILE);close(FILE);my $text=$xJlRGkVXGDhE;foreach my $x73ca2h11Qs(@xOjtr2zNIffg){$x73ca2h11Qs=~s/[\n\r]//g;if($x73ca2h11Qs eq $xdb7whaSEGto1){last;}
$x73ca2h11Qs=~s/\{CHATNAME\}/$chatname/g;$x73ca2h11Qs=~s/\{CGI\}/$xnXzppkBV5vU/g;$x73ca2h11Qs=~s/\{HTMLURL\}/$htmlurl\//g;$x73ca2h11Qs=~s/\{PULLMODE\}/$xkdZSnpb3lRs{pull}/g;$text.=$x73ca2h11Qs.$xBdDB7KJF8tQ;}
my $xwp6aCTvqUs=xC6nyJeQFXA($xAxScyOKfdg{$x3gM6PIEjbHE}).$xgNxLuzyaMJI;$xwp6aCTvqUs.=x0an1r8i6yRQ($xc9589DM7cM,$xAxScyOKfdg{$xUw1Nb98t1zI}).$xgNxLuzyaMJI;$xwp6aCTvqUs.=x0an1r8i6yRQ($xqm4S8SqW8Q,$xAxScyOKfdg{$xKYC47fjIcwA}).$xgNxLuzyaMJI;$text.=$xwp6aCTvqUs.$xaA5EJoopC4c1;return $text;}
return $xJlRGkVXGDhE;}
sub x0SdfMrMkhgk{if($_[1]!=0){$_[0]=~s/\*\*/&#42;/sg;$_[0]=~s/\_\_/&#95;/sg;$_[0]=~s/\*([^\*]+)\*/<i>$1<\/i>/sg;$_[0]=~s/\_([^\_]+)\_/<b>$1<\/b>/sg;}
$_[0]=~s/(\w+:\/\/[^<>\*\s\n\"\]\[\(\),]+)/<a href="$1" target="_blank" id=\"stdlink\">$1<\/a>/isg;$_[0]=~s/\s(www\.[^<>\*\s\n\]\[\(\),]+)/ <a href="http:\/\/$1" target="_blank" id=\"stdlink\">http:\/\/$1<\/a>/isg;$_[0]=~s/^(www\.[^<>\*\s\n\]\[\(\),]+)/<a href="http:\/\/$1" target="_blank" id=\"stdlink\">http:\/\/$1<\/a>/isg;$_[0]=~s/([\w\.\-]+\@[\w\-]+\.[\w\.\-]+)/<a href=\"mailto:$1\" id=\"stdlink\"\>$1<\/a>/isg;if($xkdZSnpb3lRs{$xsccj5erZqt}!=0&&$enable_smileys!=0){my @xMNRx5OJ9pt6=split(/\|/,$smileys_defs);for(my $xS5YGHQqs6UA=0;$xS5YGHQqs6UA<@xMNRx5OJ9pt6;$xS5YGHQqs6UA+=2){$xMNRx5OJ9pt6[$xS5YGHQqs6UA]=~s/^#//;xArCqo7Sm2Zc($xMNRx5OJ9pt6[$xS5YGHQqs6UA+1]);$xMNRx5OJ9pt6[$xS5YGHQqs6UA+1]=~s/(\s)+/ /g;xNfLGEa4Vfe2($xMNRx5OJ9pt6[$xS5YGHQqs6UA+1]);my @xos1XZdPCnE=split(/\s/,$xMNRx5OJ9pt6[$xS5YGHQqs6UA+1]);my($xs4rLu9YkdXI,$xwx1tPMNsNg)=split(/,/,$image{$xMNRx5OJ9pt6[$xS5YGHQqs6UA]});my $xsvGs2WLgeaQ=$x2BKxN0BeIJc.$imagesurl.$xaqKr3KRpyT21.$xMNRx5OJ9pt6[$xS5YGHQqs6UA].$xR32Vz9uqJP.$xs4rLu9YkdXI.$xW49QDpnr2.$xwx1tPMNsNg.$xR8VjgScOZGI;foreach my $xTW14N7ufI6w(@xos1XZdPCnE){$_[0]=~s/^\Q$xTW14N7ufI6w\E/ $xsvGs2WLgeaQ /g;$_[0]=~s/\s\Q$xTW14N7ufI6w\E/ $xsvGs2WLgeaQ /g;}
}
}
}
sub xC6nyJeQFXA{my($xTDATeZDBgoM)=@_;if($xTDATeZDBgoM=~/\S/){xNfLGEa4Vfe2($xTDATeZDBgoM);if($xTDATeZDBgoM!~/[\.\!\?]$/){if($xTDATeZDBgoM!~/[\,]$/){$xTDATeZDBgoM.=$xVV8DXPIzjA;}
$xTDATeZDBgoM.=$xc1Du82lLML1.$xkdZSnpb3lRs{$xf1FjdNsW6}.$xBdDB7KJF8tQ;}
return $xTDATeZDBgoM;}
else{return $xJlRGkVXGDhE;}
}
sub xnexithue9U{my($xqIeG0ByxeYk)=@_;foreach my $xgWsEacGxL2(split(/\s/,$xkdZSnpb3lRs{$xoqsfHABfjXg})){if($xgWsEacGxL2 eq $xqIeG0ByxeYk){return 1;}
}
return 0;}
1;