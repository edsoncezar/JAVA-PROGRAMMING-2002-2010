### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Refer
Version: 1.0

Info:

G.Refer is a tell-a-friend script, where by people who visits your site 
can fill in they details and their friends details and a email will be 
sent to their friends, asking them to check out your site.



Here is the code:

<form action="http://www.yourdomain.com/cgi-bin/grefer.cgi" method="post">

Your Name:<br>
<input type="text" name="your_name" size="30"><p>

Your Email:<br>
<input type="text" name="your_email" size="30"><p>

Friends Name:<br>
<input type="text" name="friends_name" size="30"><p>

Friends Email:<br>
<input type="text" name="friends_email" size="30"><p>

<input type="submit" value="Tell-a-Friend">

</form>





G.Scripts @ http://www.grantszone.co.uk/scripts/