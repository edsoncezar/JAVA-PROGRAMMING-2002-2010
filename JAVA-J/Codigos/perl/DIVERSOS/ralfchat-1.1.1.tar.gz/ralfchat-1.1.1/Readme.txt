RALF'S CHAT V1.1 (2002-08-01)

http://www.ralfchat.com


COPYRIGHT

Copyright 1998-2002 Ralf Gueldemeister <ralf@ralfchat.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


SECURITY

Please read the following points carefully:
- If you use the flat file version secure your data directory: 
  Either put it out of the www root
        /home/user/www/chat/
        /home/user/data/
  and set $data_dir in config.cgi accordingly. 
  Or use a .htaccess file to protect the data directory. 
  If you don't take care of this it could be possible that everyone may 
  read the data files!
- Change the master password:
  It is really important to change the master password, otherwise everyone 
  may execute the master commands like /kick, /ban, /userlevel..
  Change $masterpassword in config.cgi!
- Try to chmod 700 (only owner may read, write and execute) all files and 
  directories, especially if you are on a virtual server. If this doesn't 
  work use the given permissions (755/777).


INSTALLATION

- read the security section
- change $masterpassword in config.cgi
DBI:
  - edit config.cgi and set the DBI user, password and database in lines 95-100
- upload *.cgi, html/* and messages/* (all in ASCII mode!)
  somewhere on your server where cgi-scripts are allowed
- chmod 755 *.cgi (owner all, group and others read and execute)
Flat File:
  - make the data directory "data" (read the security section)
  - chmod 777 data (all read, execute and write)
DBI:
  - run the DBI script with http://yourserver/path/dbi.cgi
  - If you want to update a running Ralf's Chat choose "update from file to DBI"
  - Else "Create DBI tables"
- if you want logs: mkdir logs; chmod 777 logs
- run the chat script with http://yourserver/path/chat.cgi
- register your nick, login and get admin rights with 
  "/userlevel nick 2 mpw". 
- then type "/help" to get an overview of the commands


DBI VERSUS FLAT FILE

Ralf's Chat can use two different methods for saving the chat data: DBI and
Flat File. You can either use the Data Base Interface for MySQL to save all
data in a MySQL data base or the Flat File version saving the data in simple 
text files.
Generally the standard package contains both methods but you may remove
the unneeded part using the remove.pl script ("perl remove.pl DBI" or 
"perl remove.pl NODBI").
I recommend the DBI version as it is more stable and it supports streaming.
Of course the DBI version requires a MySQL data base.


CONFIGURATION

You can configure the chat script in the config.cgi file.
You should at least change $masterpassword.

All the HTML files are inside the cgi files in the html sub directory. 
You should only edit these files if you are familiar with Perl.


UPDATE FROM 1.0 TO 1.1

- delete stillalive and messages files/tables
DBI: 
  - create new stillalive and messages table with dbi.cgi
- execute via shell (telnet/ssh) "cd scripts; perl update_1.1.pl"


FAQ

Q: How do I change the Perl path?
A: Just edit the first line (#!/usr/bin/perl) of all cgi-files in the main 
    directory (chat*.cgi and dbi.cgi). Typical values are: "#!/usr/bin/perl5" 
    or "#!perl.exe".
Q: Can I use this script with Windows?
A: For using the chat under Windows you have to try the following hints. 
   - set $flocking to 0 (in config.cgi)
   - Set the Perl path to "#!c:\path\perl".
     When testing the script with Windows 98, Apache and Active Perl, it
     worked after doing these two steps.
   - in config.cgi change $data_dir to 
     "/your_absolute_www_path/path_to_chat/data"
   - rename *.cgi to *.pl and change $script*_name accordingly 
   Good luck!
Q: I always get the error "creating data/nicks failed", what is wrong?
A: You forgot to create the data-directory "data" and/or to chmod 777 (all 
   all) it.
Q: What is the masterpassword or how do I login as administrator?
A: There is no special account for administration. You can set the admin 
   rights with /userlevel.
Q: How can I view the number of users online?
A: SSI (SHTML): "<!--#include virtual="/path/chatsu.cgi?action=show_users"-->"
     or "<!--#include virtual="http://www.your-server.com/path/chatsu.cgi?
     action=show_users"-->"
   PHP: "<? readfile("http://www.your-server.com/path/chatsu.cgi?action=
     show_users") ?>"
Q: How can I view the names of the users online?
A: SSI (SHTML): "<!--#include virtual="/path/chatsu.cgi?
     action=show_usernames"-->" or "<!--#include virtual="http://www.your-
     server.com/path/chatsu.cgi?action=show_usernames"-->"
   PHP: "<? readfile("http://www.your-server.com/path/chatsu.cgi?action=
     show_usernames") ?>"
Q: I get lots of errors running the script, what is wrong?
A: You probably have Perl 4 installed. But Ralfs Chat requires Perl 5.
   Try to set the path in the first line to #!/usr/bin/perl5. Else update your
   Perl version.
Q: How can I add super users?
A: Just enter "/userlevel nick 1" if you are an admin.
Q: What does chmod mean?
A: Chmod (change mode) is the command to set permissions on UNIX systems. 
   You can chmod files either via Telnet (enter chmod 777/755 file) or 
   in your FTP-Programme (try right click on the file, check your FTP-manual).
Q: How do I enable multiple rooms?
A: Just set $room = 1 and adapt %rooms and %welcome_msgs to your needs.


CHANGES

- Version 1.1
New features:
  session IDs
  support for real multiple rooms
  time difference between server and local time
  view time and date of posting
  language files
  $days_del_old_users - automated deletion of old users (removed /clean_old_nicks)
  admins can enter full rooms
  improved /help: show help messages according to userlevel, show help message for given command
  ban ip classes
  new License: GNU GPL
  including pro features: Data Base Interface for MySQL and streaming (requires MySQL)
Bug fixes
  fixed MSIE 6 flash
  fixed url linking
Cosmetic changes
  email for administration changable in options
  /ip returns domain name
  /userlevel checks username
  /ban (without arguments) replaces /banned_list
  renamed /list_nicks to /users
  renamed /remove_nick to /deluser
  renamed /userinfo to /whois
  improved login and register
Technical changes 
  improved file access


TODO

/userlevel - display your current userlevel
/userlevel nick - display userlevel of nick
user color in online list
$image_dir, $css_dir
Log failed logons
/memo_admins, memo all administrators
better css support (classes) css file
private rooms (negative room numbers)
/ignore
/seen
/kick_all
/clear
admin: shortcuts in user online list for ban/kick..
/html (post html message)
auto kick 
userlist in new window


THANKS

- all developers, the beta testers, the translators and donators
- to my brother who supports me whenever possible
- Markus and The X-Files World Order for inspiring me
- to everyone else using my script for help me keeping the script alive 
