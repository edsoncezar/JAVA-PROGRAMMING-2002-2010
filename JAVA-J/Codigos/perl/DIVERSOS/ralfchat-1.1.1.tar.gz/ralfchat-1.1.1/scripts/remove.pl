#!/usr/bin/perl
# Ralf's Chat - a Perl webchat script
# Copyright 1998-2002 Ralf Gueldemeister <ralf@ralfchat.com>
#
# This file is part of Ralf's Chat.
#
# Ralf's Chat is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Ralf's Chat is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ralf's Chat; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# Main Part
#
###############################################

my @remove = @ARGV;
my @files = (glob("../*.cgi"), glob("../html/*"), glob("../lang/*"), glob("../scripts/*"), '../readme.txt');

for (@files) {
    rename("$_", "$_.bak");
    open(ORIGINAL, "<$_.bak");
    open(REMOVE, ">$_");
    my $print = 1;
    my $oldremove = "";
    while (<ORIGINAL>) {
	foreach $remove (@remove) {
	    if (/^[ \t]*\# ?<($remove)>/) {
		$oldremove = $1;
		$print = 0;
	    }
	}
	print REMOVE if ($print and not /^[ \t]*\# ?<\/?[A-Z]+>/);
	$print = 1 if (/^[ \t]*\# ?<\/$oldremove>/);
    }
    close ORIGINAL;
    close REMOVE;
}
