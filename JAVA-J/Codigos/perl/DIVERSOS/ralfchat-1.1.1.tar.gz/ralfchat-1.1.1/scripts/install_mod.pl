#!/usr/bin/perl
# Ralf's Chat - a Perl webchat script
# Copyright 1998-2002 Ralf Gueldemeister <ralf@ralfchat.com>
#
# This file is part of Ralf's Chat.
#
# Ralf's Chat is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Ralf's Chat is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ralf's Chat; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# 2002-03-13 / 2002-07-11
#
# install_mod.pl is a small Perl script that can install and uninstall modifications for Ralf's Chat.
# This Script expects to be located in a sub directory of the directory containing chat.cgi.
# If it's not there, create a sub directory called "scripts" and put it there!
# To check the installation information of a mod use "perl install_mod.pl -ci modfile".
# To install a mod use "perl install_mod.pl -i modfile".
# To uninstall a mod use "perl install_mod.pl -u modfile".
#
# Don't forget to backup your files!
#
###############################################################################

$usage = << "[END]";
usage: perl install_mod.pl -ciu modfile
    -i install modfile
    -u uninstall modfile
    -c check install/uninstall modfile

install_mod.pl 1.2 - created by Ralf Gueldemeister
[END]

use Getopt::Std;

if (not getopts('i:u:c') or (not $opt_i and not $opt_u) or ($opt_i and $opt_u)) {
    print $usage;
    exit;
}

$modfile = $opt_i if ($opt_i);
$modfile = $opt_u if ($opt_u);

$error = 0;
open(MODFILE, "<$modfile") or $error = 1;
if ($error) { 
    print "File not found\n";
    exit;
}

$editfile = "none";

while (<MODFILE>) {
    if (/^<(id|author|version|mod info|homepage)>/i) {
	print "[$1]\n";
	while (<MODFILE>) {
	    if (/^<\/$1>/i) { 
		last;
	    }
	    print "$_";
        }
    }

    if (/^<edit file>/i) {
	# write old file
	if ($editfile ne "none" and not $opt_c) {
    	    open(EDITFILE, ">../$editfile");
	    print EDITFILE $editfile_content;
	    close EDITFILE;
	}

	# read new file
	$editfile = <MODFILE>;
	print "[edit file]\n$editfile";
	open(EDITFILE, "<../$editfile");
	$editfile_content = join('', <EDITFILE>);
	close EDITFILE;
    }

    if (/^<search for>/i) {
	$search_for = '';
	while (<MODFILE>) {
	    if (/^<\/search for>/i) { 
		chomp($search_for);
		while (<MODFILE>) {
		    if (/^<replace>/i) { 
			$replace = '';
			while (<MODFILE>) {
			    if (/^<\/replace>/i) { 
				chomp($replace);
				if ($opt_u) {
				    $temp = $search_for;
				    $search_for = $replace;
				    $replace = $temp;
				}
				print "\t[search for]\n${search_for}";
				if ($editfile_content =~ /^\Q$search_for\E/m) {
				    print "\t[->succeeded]\n";
				}
				print "\t[replace]\n$replace\n";
				if (not $opt_c) {
				    $editfile_content =~ s/^\Q$search_for\E/$replace/gm;
 				}
				last;
			    }
			    $replace .= $_;
			}
			last;
		    }

		    if (/^<add before>/i) {
			$add_before = '';
			while (<MODFILE>) {
			    if (/^<\/add before>/i) {
				chomp($add_before);
				print "\t[search for]\n${search_for}";
				if ($editfile_content =~ /^\Q$search_for\E/m) {
				    print "\t[->succeeded]\n";
				}
				print "\t[add before]\n${add_before}";
				if (not $opt_c) {
				    if ($opt_i) {
					$editfile_content =~ s/^\Q$search_for\E/$add_before$search_for/gm;
				    } elsif ($opt_u) {
					$editfile_content =~ s/^\Q$add_before$search_for\E/$search_for/gm;
				    }
				}
				last;
			    }
			    $add_before .= $_;
			}
			last;
		    }

		    if (/^<add after>/i) {
			$add_after = '';
			while (<MODFILE>) {
			    if (/^<\/add after>/i) {
				chomp($add_after);
				print "\t[search for]\n${search_for}";
				if ($editfile_content =~ /^\Q$search_for\E/m) {
				    print "\t[->succeeded]\n";
				}
				print "\t[add after]\n${add_after}";
				if (not $opt_c) {
				    if ($opt_i) {
					$editfile_content =~ s/^\Q$search_for\E/$search_for$add_after/gm;
				    } elsif ($opt_u) {
					$editfile_content =~ s/^\Q$search_for$add_after\E/$search_for/gm;
				    }
				}
				last;
			    }
			    $add_after .= $_;
			}
			last;
		    }

		}
		last;
	    }
	    $search_for .= $_;
        }
    }
    
} 

# write file
if ($editfile ne "none" and not $opt_c) {
    open(EDITFILE, ">../$editfile");
    print EDITFILE $editfile_content;
    close EDITFILE;
}

close MODFILE;
