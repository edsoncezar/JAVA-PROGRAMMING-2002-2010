#!/usr/bin/perl
# Ralf's Chat - a Perl webchat script
# Copyright 1998-2002 Ralf Gueldemeister <ralf@ralfchat.com>
#
# This file is part of Ralf's Chat.
#
# Ralf's Chat is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Ralf's Chat is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ralf's Chat; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


$query{'noheader'} = 1;

require "../config.cgi";
require "../shared.cgi";

$data_dir = "../data";
use Time::Local;

%month = ( 
'Jan' => 0,
'Feb' => 1,
'Mar' => 2,
'Apr' => 3,
'May' => 4,
'Jun' => 5,
'Jul' => 6,
'Aug' => 7,
'Sep' => 8,
'Oct' => 9,
'Nov' => 10,
'Dec' => 11
);

if ($use_dbi) { 
# <DBI>
#    replace localtime with timestamp
    $sth = $dbh->prepare("SELECT name, doc FROM $data{'nicks'}");
    $sth->execute;
    while ($row = $sth->fetchrow_arrayref) {
        if (not $$row[1] > 0) {
            ($wday, $mon, $mday, $time, $year) = split(/ +/, $$row[1]);
            ($hour, $min, $sec) = split(/:/, $time);
            $year -= 1900;
    
	    print "$$row[0]: $$row[1] changed to timestamp ";
            $$row[1] = timelocal($sec, $min, $hour, $mday, $month{$mon}, $year);
	    print "$$row[1]\n";
	    $dbh->do("UPDATE $data{'nicks'} SET doc = '$$row[1]' WHERE name = '$$row[0]'");
        }
    }

# alter doc field
    $dbh->do("ALTER TABLE $data{'nicks'} CHANGE doc doc INT(11)");
# </DBI>
} else {
# <NODBI>
    &file_open("nicks", ">");
    while (<READFILENICKS>) {
        @row = split(/;;/);   
        if (not $row[3] > 0) {
            ($wday, $mon, $mday, $time, $year) = split(/ +/, $row[3]);
            ($hour, $min, $sec) = split(/:/, $time);
            $year -= 1900;
    
	    print "$row[0]: $row[3] changed to timestamp ";
            $row[3] = timelocal($sec, $min, $hour, $mday, $month{$mon}, $year);
	    print "$row[3]\n";
	    print WRITEFILENICKS join(";;", @row);
        } else {
	    print WRITEFILENICKS;
	}
    }
    &file_close("nicks", ">");
# </NODBI>
}

