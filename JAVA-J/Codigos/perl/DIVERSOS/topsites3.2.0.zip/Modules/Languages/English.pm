package tmpl;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: English Language Module                                   #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-10                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
# Global
$tmpl::lng{'g_form_submit_short'} = "Go";
$tmpl::lng{'g_form_submit_long'} = "Submit";
$tmpl::lng{'g_form_submit_reset'} = "Reset";
$tmpl::lng{'g_id'} = "ID";
$tmpl::lng{'g_url'} = "URL";
$tmpl::lng{'g_title'} = "Title";
$tmpl::lng{'g_description'} = "Description";
$tmpl::lng{'g_email'} = "Email";
$tmpl::lng{'g_bannerurl'} = "Banner URL";
$tmpl::lng{'g_password'} = "Password";
$tmpl::lng{'g_average'} = "Average";
$tmpl::lng{'g_today'} = "Today";
$tmpl::lng{'g_yesterday'} = "Yesterday";
$tmpl::lng{'g_2days'} = "2 Days Ago";
$tmpl::lng{'g_3days'} = "3 Days Ago";
$tmpl::lng{'g_unq_pv'} = "Unique Pageviews";
$tmpl::lng{'g_tot_pv'} = "Total Pageviews";
$tmpl::lng{'g_unq_in'} = "Unique Hits In";
$tmpl::lng{'g_tot_in'} = "Total Hits In";
$tmpl::lng{'g_unq_out'} = "Unique Hits Out";
$tmpl::lng{'g_tot_out'} = "Total Hits Out";

# Edit Member Info
$tmpl::lng{'edit_header'} = "Edit Member Info";
$tmpl::lng{'edit_error_id_password'} = "Please check your ID number and password, then try again!";
$tmpl::lng{'edit_error'} = "Error";
$tmpl::lng{'edit_error_forgot'} = "You forgot to:";
$tmpl::lng{'edit_error_url'} = "Enter a valid url.";
$tmpl::lng{'edit_error_email'} = "Enter a valid email address.";
$tmpl::lng{'edit_error_title'} = "Enter a title for your web site.";
$tmpl::lng{'edit_error_password'} = "Enter a password.";
$tmpl::lng{'edit_error_back'} = "Please go back and fix those errors.";
$tmpl::lng{'edit_success'} = "Success!";
$tmpl::lng{'edit_info_edited'} = "Your information has been successfully edited.";

# Gateway Page
$tmpl::lng{'gateway_header'} = "Topsites Gateway Page";
$tmpl::lng{'gateway_text'} = "To deter cheating, a gateway page has been put up.  Click the link below to enter the topsites list.";
$tmpl::lng{'gateway_vote'} = "Enter and vote.";
$tmpl::lng{'gateway_novote'} = "Tricked into coming here?  Enter without voting.";
$tmpl::lng{'gateway_cheating'} = "The site you are coming from is cheating.  This vote will not be recorded.";
$tmpl::lng{'gateway_enter'} = "Enter";

# Graph
$tmpl::lng{'graph_header'} = "Graph";

# Join
$tmpl::lng{'join_header'} = "Join";
$tmpl::lng{'join_error'} = "Error";
$tmpl::lng{'join_error_forgot'} = "You forgot to:";
$tmpl::lng{'join_error_url'} = "Enter a valid url.";
$tmpl::lng{'join_error_email'} = "Enter a valid email address.";
$tmpl::lng{'join_error_title'} = "Enter a title for your web site.";
$tmpl::lng{'join_error_password'} = "Enter a password.";
$tmpl::lng{'join_error_back'} = "Please go back and fix those errors.";
$tmpl::lng{'join_success'} = "Success!";
$tmpl::lng{'join_thanks'} = "Thank you!  Put this code into your site to be ranked.";
$tmpl::lng{'join_changewarning'} = "If you change the code, it might not work.";
$tmpl::lng{'join_welcome'} = "Welcome to the topsites list!";
$tmpl::lng{'join_welcome_look'} = "If that doesn't look right, use this code:";

# Lost Code
$tmpl::lng{'lostcode_header'} = "Lost Code";

# Lost Password
$tmpl::lng{'lostpw_header'} = "Lost Password";
$tmpl::lng{'lostpw_emailed'} = "Your password has been emailed to you.";
$tmpl::lng{'lostpw_error'} = "Please make sure you have the right ID number and try again.";

# Main Template
$tmpl::lng{'main_method'} = "Ranking method";
$tmpl::lng{'main_members'} = "Members";
$tmpl::lng{'main_menu_main'} = "Main Page";
$tmpl::lng{'main_menu_join'} = "Join";
$tmpl::lng{'main_menu_random'} = "Random Member";
$tmpl::lng{'main_menu_search'} = "Search";
$tmpl::lng{'main_menu_lostcode'} = "Lost Code";
$tmpl::lng{'main_menu_lostpw'} = "Lost Password";
$tmpl::lng{'main_menu_edit'} = "Edit Member Info";
$tmpl::lng{'main_generated'} = "This page was generated in";
$tmpl::lng{'main_powered'} = "Powered By";

# Ranking Table
$tmpl::lng{'table_stats'} = "Stats";
$tmpl::lng{'table_unique'} = "Unique";
$tmpl::lng{'table_total'} = "Total";
$tmpl::lng{'table_today'} = "Today";
$tmpl::lng{'table_average'} = "Average";

# Rate and Review
$tmpl::lng{'rate_header'} = "Rate and Review";
$tmpl::lng{'rate_rating'} = "Rating";
$tmpl::lng{'rate_review'} = "Review";
$tmpl::lng{'rate_thanks'} = "Thanks for rating and reviewing this site!";
$tmpl::lng{'rate_error'} = "You have already rated or reviewed this site.";
$tmpl::lng{'rate_back'} = "Back To Stats";

# Search
$tmpl::lng{'search_header'} = "Search";
$tmpl::lng{'search_off'} = "The search feature has been turned off for this topsites list.";
$tmpl::lng{'search_rank'} = "Rank";
$tmpl::lng{'search_search'} = "Search";
$tmpl::lng{'search_for'} = "You searched for";
$tmpl::lng{'search_string'} = "Search as a string?";
$tmpl::lng{'search_nosites'} = "Sorry, no sites matching your criteria were found.";

# Stats
$tmpl::lng{'stats_header'} = "Stats";
$tmpl::lng{'stats_rating_avg'} = "Average Rating";
$tmpl::lng{'stats_rating_num'} = "Number of Ratings";
$tmpl::lng{'stats_rate'} = "Rate And Review This Site";
$tmpl::lng{'stats_reviews'} = "Reviews";

# Top X
$tmpl::lng{'top_top'} = "Top"; #Top X Sites
$tmpl::lng{'top_sites'} = "Sites"; #Top X Sites
$tmpl::lng{'top_join'} = "Join";
$tmpl::lng{'top_all'} = "All Sites";

# Admin > Delete
$tmpl::lng{'a_del_mems'} = "The member has been successfully deleted.";
$tmpl::lng{'a_del_mem'} = "Delete One Member";

# Admin > Edit Member Info
$tmpl::lng{'a_edit_error_id'} = "Invalid ID.";
$tmpl::lng{'a_edit_error'} = "Error";
$tmpl::lng{'a_edit_error_forgot'} = "You forgot to:";
$tmpl::lng{'a_edit_error_url'} = "Enter a valid url.";
$tmpl::lng{'a_edit_error_email'} = "Enter a valid email address.";
$tmpl::lng{'a_edit_error_title'} = "Enter a title for your web site.";
$tmpl::lng{'a_edit_error_password'} = "Enter a password.";
$tmpl::lng{'a_edit_error_back'} = "Please go back and fix those errors.";
$tmpl::lng{'a_edit_success'} = "Success!";
$tmpl::lng{'a_edit_info_edited'} = "The member's information has been successfully edited.";

# Admin > Email Members
$tmpl::lng{'a_email_addresses'} = "These are the email addresses of all members.";

# Admin > Find ID
$tmpl::lng{'a_find_find'} = "To find a site's ID number, just use the normal search feature of your topsites list.  <a href=\"topsites.cgi?action=search\">Click here</a>.";

# Admin > Login/Logout/Main
$tmpl::lng{'a_login'} = "You are logged in.  A temporary cookie has been set.  To delete the cookie and logout, click logout or exit your browser.";
$tmpl::lng{'a_login_enter'} = "Enter";
$tmpl::lng{'a_login_invalidpw'} = "Invalid password!";
$tmpl::lng{'a_login_when'} = "When you login, a tempoary cookie will be created.  Because of that, you need to turn cookies on in your browser before you login.  Don't worry, all the major browsers have cookies turned on by default.  If your browser is ancient and doesn't support cookies, I suggest you upgrade to a recent version of Mozilla, Opera, or Internet Explorer.";

# Admin > Logout
$tmpl::lng{'a_logout'} = "You are logged out.";

# Admin > Main
$tmpl::lng{'a_main'} = "Use the links at the left to go to the different areas of the admin.";

# Admin > Menu
$tmpl::lng{'a_menu'} = "Menu";
$tmpl::lng{'a_menu_main'} = "Main Page";
$tmpl::lng{'a_menu_delete'} = "Delete Member";
$tmpl::lng{'a_menu_edit'} = "Edit Member";
$tmpl::lng{'a_menu_email'} = "Email Members";
$tmpl::lng{'a_menu_find'} = "Find ID";
$tmpl::lng{'a_menu_logout'} = "Logout";
$tmpl::lng{'a_menu_settings'} = "Settings";
$tmpl::lng{'a_menu_version'} = "Version Check";

# Admin > Settings
$tmpl::lng{'a_s_general'} = "General Settings";
$tmpl::lng{'a_s_list_name'} = "Name of your topsites list";
$tmpl::lng{'a_s_deflanguage'} = "Default language";
$tmpl::lng{'a_s_dir'} = "The full path to the directory topsites.cgi is in";
$tmpl::lng{'a_s_list_url'} = "URL to the directory topsites.cgi is in";
$tmpl::lng{'a_s_templates_dir'} = "URL to the directory the template is in";
$tmpl::lng{'a_s_templates_url'} = "The full path to the directory the template is in";
$tmpl::lng{'a_s_youremail'} = "Your email address";

$tmpl::lng{'a_s_ranking'} = "Ranking Settings";
$tmpl::lng{'a_s_numlist'} = "Number of members to list per page";
$tmpl::lng{'a_s_rankings_dir'} = "The full path to the directory the HTML ranks will be generated";
$tmpl::lng{'a_s_rankings_dir_warning'} = "This directory must be outside of your CGI-BIN.";
$tmpl::lng{'a_s_rankings_dir_chmod'} = "You must CHMOD 777 this directory";
$tmpl::lng{'a_s_rankings_url'} = "URL to the directory the HTML ranks will be generated";
$tmpl::lng{'a_s_rankings_filename'} = "Name of the HTML ranks";
$tmpl::lng{'a_s_rankings_ext'} = "Extension of the HTML ranks";
$tmpl::lng{'a_s_refresh'} = "The number of seconds between reranking members";
$tmpl::lng{'a_s_defbanner'} = "Default banner to give members if they don't supply one when they join";
$tmpl::lng{'a_s_uniquetotal'} = "Ranking method";
$tmpl::lng{'a_s_top'} = "Number of members to use the special top templates for";
$tmpl::lng{'a_s_adbreak'} = "Show an ad break after these ranks (separate with commas)";

$tmpl::lng{'a_s_button'} = "Button Settings";
$tmpl::lng{'a_s_button_url'} = "URL to the directory the buttons are in";
$tmpl::lng{'a_s_button_ext'} = "Extension of the buttons (gif, png, jpg, etc.)";
$tmpl::lng{'a_s_button_num'} = "Number of buttons you have made";

$tmpl::lng{'a_s_other'} = "Other Settings";
$tmpl::lng{'a_s_mail'} = "Path to sendmail (leave blank if you're using SMTP or you don't want emails to be sent)";
$tmpl::lng{'a_s_smtpserver'} = "SMTP server (leave blank if you're using sendmail or you don't want emails to be sent)";
$tmpl::lng{'a_s_timeoffset'} = "Time offset from your server";
$tmpl::lng{'a_s_gateway'} = "Gateway page to deter cheating for hits in";
$tmpl::lng{'a_s_search'} = "The search feature";

$tmpl::lng{'a_s_on'} = "On";
$tmpl::lng{'a_s_off'} = "Off";

$tmpl::lng{'a_s_updated'} = "Your settings have been updated.  Hopefully everything will work how you want it to.";

# Admin > Version Check
$tmpl::lng{'a_version_using'} = "You are using the latest version of this script.";
$tmpl::lng{'a_version_your'} = "Your version";
$tmpl::lng{'a_version_latest'} = "Latest version";
$tmpl::lng{'a_version_new'} = "New version available: <a href=\"http://www.aardvarkind.com/?a=cgi\&amp\;b=topsites\&amp\;c=index\">Click here</a>.";
1;