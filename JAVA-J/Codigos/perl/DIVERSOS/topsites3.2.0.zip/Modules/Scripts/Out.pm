package Scripts::Out;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Hit Out                                                   #
# Module Desc: Counts hits out.                                          #
# Module Group: Standard                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-30                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
my $url;
if ($AT::form{id}) {
  sysopen(HITS, "$AT::config{dir}/Data/Members/$AT::form{id}.txt", AT::O_RDWR) || die "$!, stopped";
  flock(HITS, 2);
  my @hits = <HITS>;
  truncate(HITS, 0);
  seek(HITS, 0, 0);
  my($hits_today_r5, $hits_1_r5, $hits_2_r5, $hits_3_r5) = split(/\|/, $hits[5]);
  $hits_today_r5++;
  $hits[5] = join('|', $hits_today_r5, $hits_1_r5, $hits_2_r5, $hits_3_r5);
  my $cookiename = "aardvark_out_$AT::form{id}_$AT::config{list_url}";
  if (!$AT::cgi->cookie($cookiename)) {
    my $cookie = $AT::cgi->cookie(	-name=>$cookiename,
			     		-value=>'1',
			    		-expires=>'+10h');
    print "Set-Cookie: $cookie\n";
    my($hits_today_r4, $hits_1_r4, $hits_2_r4, $hits_3_r4) = split(/\|/, $hits[4]);
    $hits_today_r4++;
    $hits[4] = join('|', $hits_today_r4, $hits_1_r4, $hits_2_r4, $hits_3_r4);
  }
  print HITS @hits;
  close(HITS);
  sysopen(INFO, "$AT::config{dir}/Data/info.cgi", AT::O_RDONLY) || die "$!, stopped";
  flock(INFO, 2);
  my @info = <INFO>;
  close(INFO);
  foreach (@info) {
    ($tmpl::var{id}, $Scripts::Out::url, $tmpl::var{title}, $tmpl::var{description}, $tmpl::var{email}, $Scripts::Out::password, $tmpl::var{urlbanner}) = split(/\|/);
    if ($tmpl::var{id} == $AT::form{id}) {
      $url = $Scripts::Out::url;
      last;
    }
  }
}
if ($url) { print "Location: $url\n\n"; }
else { print "Location: $AT::config{list_url}/$AT::config{rankings_filename}.$AT::config{rankings_ext}\n\n"; }
1;