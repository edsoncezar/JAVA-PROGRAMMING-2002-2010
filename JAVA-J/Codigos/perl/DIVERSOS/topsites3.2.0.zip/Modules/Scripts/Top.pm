package Scripts::Top;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Top X                                                     #
# Module Desc: Displays the top X sites.                                 #
# Module Group: Standard                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-30                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
$tmpl::var{num} = $AT::form{num} || 5;
sysopen(RANKS, "$AT::config{dir}/Data/ranks.txt", AT::O_RDONLY) || die "$!, stopped";
flock(RANKS, 2);
my @ranks = <RANKS>;
close(RANKS);
sysopen(INFO, "$AT::config{dir}/Data/info.cgi", AT::O_RDONLY) || die "$!, stopped";
flock(INFO, 2);
my @info = <INFO>;
close(INFO);
my @ranks2;
my $rnum = 0;
while ($rnum < $tmpl::var{num}) {
  push(@ranks2, $ranks[$rnum]);
  $rnum++;
}
foreach my $line(@ranks2) {
  ($tmpl::var{rank}, $Scripts::Top::rankid, $tmpl::var{oldrank}) = split(/\|/, $line);
  foreach (@info) {
    ($tmpl::var{id}, $Scripts::Top::url, $tmpl::var{title}, $tmpl::var{description}, $tmpl::var{email}, $Scripts::Top::password, $tmpl::var{urlbanner}) = split(/\|/);
    if ($tmpl::var{id} == $Scripts::Top::rankid) {
      $tmpl::var{url} = "topsites.cgi?action=out\&amp\;id=$tmpl::var{id}";
      $tmpl::var{sites} .= "$tmpl::var{rank}. <a href=\"$tmpl::var{url}\" target=\"_blank\">$tmpl::var{title}</a><br />\n";
    }
  }
}
sysopen(TOP, "$AT::config{templates_dir}/top.html", AT::O_RDONLY) || die "$!, stopped";
flock(TOP, 2);
print "Content-type: text/html\n\n" . &subs::regexvars(join('', <TOP>));
close(TOP);
1;