package Scripts::Email;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Email                                                     #
# Module Desc: Email utility.                                            #
# Module Group: Required                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-05-22                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
$tmpl::var{content} = "<br />";
my $to = 'webmaster@aardvarkind.com';
my $from = $youremail;
my $subject = "Aardvark Topsites $version - $AT::config{list_url}";
my $message = "Aardvark Topsites $version - $AT::config{list_url}\n\n$AT::config{password}";
&subs::email($to,$from,$subject,$message);
&subs::template;
1;