package Scripts::LostCode;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Lost Code                                                 #
# Module Desc: Gives members an easy way to retrieve their HTML code.    #
# Module Group: Standard                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-30                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
$tmpl::var{header} = $tmpl::lng{'lostcode_header'};
$tmpl::var{id} = $AT::form{id};
if (!$tmpl::var{id}) {
  sysopen(LOSTCODE_FORM, "$AT::config{templates_dir}/lostcode_form.html", AT::O_RDONLY) || die "$!, stopped";
  flock(LOSTCODE_FORM, 2);
  $tmpl::var{content} .= &subs::regexvars(join('', <LOSTCODE_FORM>));
  close(LOSTCODE_FORM);
}
else {
  sysopen(LOSTCODE_FINISH, "$AT::config{templates_dir}/lostcode_finish.html", AT::O_RDONLY) || die "$!, stopped";
  flock(LOSTCODE_FINISH, 2);
  $tmpl::var{content} .= &subs::regexvars(join('', <LOSTCODE_FINISH>));
  close(LOSTCODE_FINISH);
}
&subs::template;
1;