package Scripts::LostPW;
##########################################################################
# Aardvark Topsites SQL 3.2.0                                            #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Lost Password                                             #
# Module Desc: Gives members an easy way to retrieve their password.     #
# Module Group: Standard                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-30                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
$tmpl::var{header} = $tmpl::lng{'lostpw_header'};
$tmpl::var{id} = $AT::form{id};
if (!$tmpl::var{id}) {
  sysopen(LOSTPW_FORM, "$AT::config{templates_dir}/lostpw_form.html", AT::O_RDONLY) || die "$!, stopped";
  flock(LOSTPW_FORM, 2);
  $tmpl::var{content} .= &subs::regexvars(join('', <LOSTPW_FORM>));
  close(LOSTPW_FORM);
}
else {
  my $done = 0;
  sysopen(INFO, "$AT::config{dir}/Data/info.cgi", AT::O_RDONLY) || die "$!, stopped";
  flock(INFO, 2);
  my @info = <INFO>;
  close(INFO);
  foreach (@info) {
    ($tmpl::var{id2}, $tmpl::var{url}, $tmpl::var{title}, $tmpl::var{description}, $tmpl::var{email}, $tmpl::var{password}, $tmpl::var{urlbanner}) = split(/\|/);
    if ($tmpl::var{id} == $tmpl::var{id2}) {
      sysopen(LOSTPW_MAIL,"$AT::config{templates_dir}/lostpw_mail.html", AT::O_RDONLY) || die "$!, stopped";
      flock(LOSTPW_MAIL, 2);
      my @lostpw_mails = <LOSTPW_MAIL>;
      close(LOSTPW_MAIL);
      my $subject = shift(@lostpw_mails);
      $subject =~ s/Subject\: //i;
      $subject = &subs::regexvars($subject);
      my $lostpw_mail = &subs::regexvars(join('', @lostpw_mails));
      &subs::email($tmpl::var{email}, $AT::config{youremail}, $subject, $lostpw_mail);
      sysopen(LOSTPW_FINISH,"$AT::config{templates_dir}/lostpw_finish.html", AT::O_RDONLY) || die "$!, stopped";
      flock(LOSTPW_FINISH, 2);
      $tmpl::var{content} = &subs::regexvars(join('', <LOSTPW_FINISH>));
      close(LOSTPW_FINISH);
      $done = 1;
    }
  }
  if (!$done) { $tmpl::var{content} .= "$tmpl::lng{'lostpw_error'}<br /><br />\n"; }
}
&subs::template;
1;