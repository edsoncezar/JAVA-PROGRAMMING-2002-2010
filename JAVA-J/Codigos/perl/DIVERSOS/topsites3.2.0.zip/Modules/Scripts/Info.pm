package Scripts::Info;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Info                                                      #
# Module Desc: Displays the version number and build number.             #
# Module Group: Required                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-07-04                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
print "Content-type: text/html\n\n";
print <<EndHTML;
<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Aardvark Topsites</title>
<style type="text/css">
.code, .code TD       {font-family: courier new; font-size: 10pt; color: #009;}
.header, .header TD   {font-size: 30pt; font-weight: bold; color: #009;}
.header2, .header2 TD {font-size: 18pt; font-weight: bold; color: #009;}
.header3, .header3 TD {font-size: 12pt; font-weight: bold; color: #009;}
.main, .main TD       {font-size: 11pt; color: #009;}
A:link                {color: blue;}
A:visited             {color: #00a;}
A:active              {text-decoration: none; color: red;}
A:hover               {text-decoration: none; color: red;}
</style>
</head>
<body>
<table width="100%"><tr><td width="200" align="center">
<img src="$tmpl::var{templates_url}/logo.gif" alt="Aardvark Topsites" height="80" width="300" />
</td><td align="center">
<span class="header"><a href="http://www.aardvarkind.com/?a=cgi&amp;b=topsites&amp;c=index" target="_blank">Aardvark Topsites</a></span><br />
<span class="header3">Version: $tmpl::var{version} - Date: 2002-07-04</span>
</td></tr></table>
<hr />
<div class="main">
<span class="header2">Copyright</span><br /><br />
� 2000-2002 <a href="http://www.aardvarkind.com/" target="_blank">Aardvark Industries</a>.  All Rights Reserved.<br /><br />
This program is free software; you can redistribute it and/or modify 
it under the terms of the <a href="http://www.gnu.org/copyleft/gpl.html" target="_blank">GNU General Public License</a> as published by 
the Free Software Foundation; either version 2 of the License, or (at 
your option) any later version.<br /><br />
This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.<br /><br />
You should have received a copy of the <a href="http://www.gnu.org/copyleft/gpl.html" target="_blank">GNU General Public License</a> 
with this program; if not, write to the Free Software Foundation, 
Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
<hr />
<br />
<span class="header2">Environmental Variables</span><br /><br />
<span class="code">
EndHTML
foreach (keys(%ENV)){
  print "<b>$_</b> = $ENV{$_}<br />\n";
}
print <<EndHTML;
</span>
</div>
</body>
</html>
EndHTML
1;