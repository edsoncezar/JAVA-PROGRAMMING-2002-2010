package Scripts::In2;
##########################################################################
# Aardvark Topsites 3.2.0                                                #
# Copyright (c) 2000-2002 Aardvark Industries                            #
#                         http://www.aardvarkind.com/                    #
#                                                                        #
# Module Name: Hit In                                                    #
# Module Desc: Counts hits in.                                           #
# Module Group: Standard                                                 #
# Module Author: Jeremy Scheff - webmaster@aardvarkind.com               #
# Module Version: 3.2.0                                                  #
# Last Modified: 2002-06-29                                              #
#                                                                        #
# You can redistribute and/or modify this script under the terms of the  #
# Aardvark Industries License, either version 1.0 or (at your option)    #
# any later version published by Aardvark Industries.                    #
#                                                                        #
# This program is distributed in the hope that it will be useful, but    #
# WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the Aardvark #
# Industries License for more details.                                   #
##########################################################################
if ($ENV{'HTTP_REFERER'} =~ /$AT::config{list_url}/ || $AT::form{action} eq "in") {
  if ($AT::form{id}) {
    sysopen(HITS, "$AT::config{dir}/Data/Members/$AT::form{id}.txt", AT::O_RDWR) || die "$!, stopped";
    flock(HITS, 2);
    my @hits = <HITS>;
    truncate(HITS, 0);
    seek(HITS, 0, 0);
    my($hits_today_r3, $hits_1_r3, $hits_2_r3, $hits_3_r3) = split(/\|/, $hits[3]);
    $hits_today_r3++;
    $hits[3] = join('|', $hits_today_r3, $hits_1_r3, $hits_2_r3, $hits_3_r3);
    my $cookiename = "aardvark_in_$AT::form{id}_$AT::config{list_url}";
    if (!$AT::cgi->cookie($cookiename)) {
      my $cookie = $AT::cgi->cookie(	-name=>$cookiename,
  			     		-value=>'1',
  			    		-expires=>'+10h');
      print "Set-Cookie: $cookie\n";
      my($hits_today_r2, $hits_1_r2, $hits_2_r2, $hits_3_r2) = split(/\|/, $hits[2]);
      $hits_today_r2++;
      $hits[2] = join('|', $hits_today_r2, $hits_1_r2, $hits_2_r2, $hits_3_r2);
    }
    print HITS @hits;
    close(HITS);
  }
  print "Location: $AT::config{rankings_url}/$AT::config{rankings_filename}.$AT::config{rankings_ext}\n\n";
}
elsif ($AT::config{gateway}) {
  $tmpl::var{content} = "$tmpl::lng{'gateway_cheating'}<br /><br /><a href=\"$AT::config{list_url}/$AT::config{rankings_filename}.$AT::config{rankings_ext}\">$tmpl::lng{'gateway_enter'}</a><br /><br />";
  &subs::template;
}
else { print "Location: $AT::config{rankings_url}/$AT::config{rankings_filename}.$AT::config{rankings_ext}\n\n"; }
1;