Aardvark Topsites 3.2.0 - http://www.aardvarkind.com/?a=cgi&b=topsites&c=index
� 2000-2002 Aardvark Industries - http://www.aardvarkind.com/
Written by Jeremy Scheff - webmaster@aardvarkind.com

/~~~~~~~~~~~~~~~~~~~~~~~~~\
|        _.---._    /\\   |
|     ./'       '--`\//   |
|   ./              o \   |
|  /./\  )______   \__ \  |
| |/  / /\ \   | \ \  \ \ |
|    / /  \ \  | |\ \  \0 |
|     "     "    "  "     |
|~~~~~~~~~~~~~~~~~~~~~~~~~|
|   AARDVARK INDUSTRIES   |
\~~~~~~~~~~~~~~~~~~~~~~~~~/



Go to http://www.aardvarkind.com/cgi/topsites/Manual/ in a browser for the 
instructions.