#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$encline=crypt($data{name},$data{name}).":".crypt($data{password},$data{password});
$destination=$data{method};

#aUTH0RiSATiON
open (F, "<$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
@pass=<F>;
flock(F,$LOCK_UN);
close (F);
chop($admpass=shift(@pass));
&$destination if ($admpass eq $encline);
open (F,"<$pwpath/template/errautha.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;

######################################################################
#sUBR0TiNES sECTi0N                                                  #
######################################################################
sub genset
{
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">GENERAL SETTINGS</font>
<form action="$cgi/pwadmin.pl" method="post">
<input type="hidden" name="name" value="$data{name}"><input type="hidden" name="password" value="$data{password}"><input type="hidden" name="method" value="general">
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b>Poll system title</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="owntitle" value="$owntitle"></font></td></tr>
<tr><td width="40%"><font size=1><b>SystemID</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="sysid" value="$sysid"></font></td></tr>
<tr><td width="40%"><font size=1><b>Path to PollWorld directory</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="pwpath" value="$pwpath"></font></td></tr>
<tr><td width="40%"><font size=1><b>Path to databases directory</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="basepath" value="$basepath"></font></td></tr>
<tr><td width="40%"><font size=1><b>URL to PollWorld directory</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="pollworld" value="$pollworld"></font></td></tr>
<tr><td width="40%"><font size=1><b>URL to CGI-BIN directory</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="cgi" value="$cgi"></font></td></tr>
<tr><td width="40%"><font size=1><b>Path to sendmail</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="progmail" value="$progmail"></font></td></tr>
<tr><td width="40%"><font size=1><b>Admin e-mail</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="email" value="$email"></font></td></tr>
<tr><td width="40%"><font size=1><b>URL to your site</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="furl" value="$furl"></font></td></tr>
<tr><td width="40%"><font size=1><b>Ignore IP delay</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="delay" value="$delay"></font></td></tr>
<tr><td colspan=2 align="right"><input type="submit" value="Change general settings"></td></tr>
</table></form>
</td></tr>
<tr><td width="450">
<font size=5 color="#00B0B0">CHANGE ADMIN LOGIN/PASSWORD</font>
<form action="$cgi/pwadmin.pl" method="post">
<input type="hidden" name="name" value="$data{name}"><input type="hidden" name="password" value="$data{password}"><input type="hidden" name="method" value="admdata">
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b>New login</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="alogin"></font></td></tr>
<tr><td width="40%"><font size=1><b>New password</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="apassword"></font></td></tr>
<tr><td colspan=2 align="right"><input type="submit" value="Change data"></td></tr>
</table></form>
</td></tr>
~;
open (F,"<$pwpath/template/adm.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub maillist
{
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">MAILING LIST</font>
<form method="post" action="$cgi/pwadmin.pl">
<input type="hidden" name="name" value="$data{name}"><input type="hidden" name="password" value="$data{password}"><input type="hidden" name="method" value="maillist">
<table bgcolor="#00B0B0" border="0" width="100%" cellspacing="0" cellpadding="0" style="border: 0px none rgb(0,0,0)">
<tr><td width="25%"><font size="2"><b>&nbsp;&nbsp;&nbsp;&nbsp;Subject</b></font></td>
<td width="75%"><input type="text" name="subject" size="44" value="$owntitle Newsletter"></td></tr>
<tr><td colspan=2 align="center"><textarea name="body" cols=50 rows=5></textarea></td></tr>
<tr><td colspan=2 align="center"><input type="submit" value="Send newsletter"></td></tr>
</table></form></td></tr>
~;
open (F,"<$pwpath/template/adm.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
