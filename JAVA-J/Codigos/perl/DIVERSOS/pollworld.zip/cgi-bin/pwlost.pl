#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
sysread (STDIN,$query,$ENV{CONTENT_LENGTH});
@query=split("&",$query);
foreach (@query)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9A-Fa-f]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}.=",$value";}
		else {$data{$field}=$value;}
	}
}
if (!$data{EMail})
{
	push (@errors,"Please enter your email<br>\n");
	open (F,"<$pwpath/template/error.tpl");
	@htmlpage=<F>;
	close (F);
	$htmlpage=join("\n",@htmlpage);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $htmlpage;
	exit;
}
open (F,"<$basepath/pollworld.bup");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close (F);
foreach (@users)
{
	($emls,$user,$password)=split("\t",$_);
	if ($data{EMail} eq $emls)
	{
		open (MAIL,"|$progmail");
		print MAIL "To: $data{EMail}\n";
		print MAIL "From: $email ($owntitle)\n";
		print MAIL "Subject: Password request\n\n";
		print MAIL "Login: $user\nPassword: $password\n\n";
		close (MAIL);
		$ff=1;
        }
}
if ($ff)
{
	open (F,"<$pwpath/template/pass.tpl");
	@htmlpage=<F>;
	close (F);
	$htmlpage=join("\n",@htmlpage);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $htmlpage;
	exit;
}
push (@errors,"Your email is not exist in our database<br>\n");
open (F,"<$pwpath/template/error.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
