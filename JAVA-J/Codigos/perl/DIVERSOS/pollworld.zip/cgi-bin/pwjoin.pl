#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
sysread (STDIN,$query,$ENV{CONTENT_LENGTH});
@query=split("&",$query);
foreach (@query)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9A-Fa-f]{2})/pack('C',hex($1))/eg;
		$data{$field}=$value;
	}
}
open (F,"<$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close (F);
$data{Username}=~tr/A-Z/a-z/;

#vALiDATi0N
unless ($data{EMail}=~/.+\@.+/)
{
	push (@errors,"Incorrect <b>e-mail</b>, you must put your e-mail address<br>\n");
	$flag=1;
}
foreach (@users)
{
	($user,$password)=split(":",$_);
	if (crypt($data{Username},$data{Username}) eq $user)
	{
		push (@errors,"Username $data{Username} is <b>already exist</b>, please choose different<br>\n");
		$flag=1;
        }
}
if ($data{Username}=~/\W+/ || $data{Username} eq "")
{
	push (@errors,"Incorrect <b>username</b>, must be one word<br>\n");
	$flag=1;
}
if ($data{Password}=~/\W+/ || $data{Password} eq "")
{
	push (@errors,"Incorrect <b>password</b>, must be one word<br>\n");
	$flag=1;
}
&error(@errors) if ($flag);
#pRiNT cONFIRMATION pAGE
open (F,"<$pwpath/template/confirm.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;

######################################################################
#sUBROTiNES sECTiON                                                  #
######################################################################
sub error
{
@errors=@_;
open (F,"<$pwpath/template/error.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
