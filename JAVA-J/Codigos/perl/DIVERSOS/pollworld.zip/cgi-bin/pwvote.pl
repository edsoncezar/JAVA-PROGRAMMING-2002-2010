#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#rEAD dATABASE aND gET bANNER
$returnlink=$ENV{HTTP_REFERER};
#print "content-type: text/html\n\n";
#print $returnlink;
#exit;
sysread (STDIN,$query,$ENV{CONTENT_LENGTH});
@query=split("&",$query);
foreach (@query)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9A-Fa-f]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}.=",$value";}
		else {$data{$field}=$value;}
	}
}

open (F,">>$basepath/$data{name}/$data{variant}");
flock(F,$LOCK_EX);
print F "A";
flock(F,$LOCK_UN);
close (F);
open (F,"<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
($cook)=split("\t",<F>);;
flock(F,$LOCK_UN);
close (F);
open (F,">$basepath/$data{name}/iptmp/$ENV{REMOTE_ADDR}");
flock(F,$LOCK_EX);
flock(F,$LOCK_UN);
close (F);
print "HTTP/1.0 302 Found\n" if ($sysid eq "Windows");
print "set-cookie: pollworld=$cook; \n";
print "Location: $returnlink\n\n";
