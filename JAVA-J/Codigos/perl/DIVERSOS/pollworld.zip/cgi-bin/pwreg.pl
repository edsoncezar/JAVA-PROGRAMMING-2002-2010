#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
sysread (STDIN,$query,$ENV{CONTENT_LENGTH});
@query=split("&",$query);
foreach (@query)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9A-Fa-f]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}.=",$value";}
		else {$data{$field}=$value;}
	}
}
if (!$data{Username})
{
	push (@errors,"Illegal script using<br>\n");
	open (F,"<$pwpath/template/error.tpl");
	@htmlpage=<F>;
	close (F);
	$htmlpage=join("\n",@htmlpage);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $htmlpage;
	exit;
}
open (F,"<$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
@users=<F>;
flock(F,$LOCK_UN);
close (F);
foreach (@users)
{
	($user,$password)=split(":",$_);
	if (crypt($data{Username},$data{Username}) eq $user)
	{
		push (@errors,"Username $data{Username} is <b>already exist</b>, please choose different<br>\n");
		open (F,"<$pwpath/template/error.tpl");
		@htmlpage=<F>;
		close (F);
		$htmlpage=join("\n",@htmlpage);
		print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
		print "content-type: text/html\n\n";
		eval $htmlpage;
		exit;
        }
}

#p0ST dATA
open (F,">>$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
print F crypt($data{Username},$data{Username}).":".crypt($data{Password},$data{Password})."\n";
flock(F,$LOCK_UN);
close (F);
unless (-e "$basepath/maillist")
{
open (F,">$basepath/maillist");
flock(F,$LOCK_EX);
flock(F,$LOCK_UN);
close(F);
}
open (F,"+<$basepath/maillist");
flock(F,$LOCK_EX);
@maillist=<F>;
foreach(@maillist)
{
	$ffl=1 if ($_ eq "$data{EMail}\n");
}
push(@maillist,"$data{EMail}\n");
truncate(F,0);
seek(F,0,0);
print F @maillist;
flock(F,$LOCK_UN);
close (F);
mkdir "$basepath/$data{Username}",0777;
chmod 0777,"$basepath/$data{Username}/";
mkdir "$basepath/$data{Username}/iptmp",0777;
chmod 0777,"$basepath/$data{Username}/iptmp/";
open (F,">>$basepath/pollworld.bup");
flock(F,$LOCK_EX);
print F "$data{EMail}\t$data{Username}\t$data{Password}\n";
flock(F,$LOCK_UN);
close (F);
open (F,">$basepath/$data{Username}/settings");
flock(F,$LOCK_EX);
print F "nocookies\t$delay";
flock(F,$LOCK_UN);
close (F);
#sEND e-MAiL
open (MAIL,"|$progmail");
print MAIL "To: $email\n";
print MAIL "From: $data{EMail} ($data{Name})\n";
print MAIL "Subject: New User Information\n\n";
$ltime=scalar localtime; 
print MAIL "E-mail: $data{EMail}\n";
print MAIL "Username: $data{Username}\n";
print MAIL "Password: $data{Password}\n";
close (MAIL);
open (MAIL,"|$progmail");
print MAIL "To: $data{EMail}\n";
print MAIL "From: $email ($owntitle)\n";
print MAIL "Subject: Welcome to our voting system\n\n";
$ltime=scalar localtime; 
print MAIL "Please login to members section and create voting form:\n\n";
print MAIL "URL: $pollworld/members.html\n";
print MAIL "Your login: $data{Username}\n";
print MAIL "Your password: $data{Password}\n\n";
close (MAIL);

#pRiNT sUCCESS
open (F,"<$pwpath/template/success.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;

######################################################################
#sUBROTiNES sECTiON                                                  #
######################################################################
sub error
{
@errors=@_;
open (F,"<$pwpath/template/error.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
