#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}
print "HTTP/1.0 200 OK\n";
print "content-type: text/html\n\n";

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
@data=split("; ",$ENV{HTTP_COOKIE});
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex ($1))/eg;
		$cookie{$field}=$value;
	}
}
open (F,"<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
($cook,$tlim)=split("\t",<F>);
flock(F,$LOCK_UN);
close(F);
&result if ($cookie{pollworld}==$cook);
unless (-d "$basepath/$data{name}/iptmp/")
{
	mkdir "$basepath/$data{name}/iptmp",0777;
	chmod 0777,"$basepath/$data{name}/iptmp";
}
&result if (-e "$basepath/$data{name}/iptmp/$ENV{REMOTE_ADDR}" && -M "$basepath/$data{name}/iptmp/$ENV{REMOTE_ADDR}"<$tlim*1440);
open (F,"<$basepath/$data{name}/question");
flock(F,$LOCK_EX);
$data{question}=<F>;
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
foreach(@answers)
{
	chop;
	if (!$checked)
	{
		$menu.=qq~<tr><td><font size=1><input type=radio checked name=variant value=$i> $_</font></td></tr>~;
		$checked=1;
	}
	else {$menu.=qq~<tr><td><font size=1><input type=radio name=variant value=$i> $_</font></td></tr>~;}
	$i++;
}
print qq~
document.write('<form action="$cgi/pwvote.pl" method="post">');
document.write('<input type=hidden name=name value="$data{name}">');
document.write('<table width=200 border=1 bordercolor="#7A0000" cellpadding=0>');
document.write('<tr><td><a href="$furl"><img src="$pollworld/images/network.gif" width=200 height=40 border=0 alt="GET YOUR FREE VOTING SYSTEM"></a></td></tr>');
document.write('<tr><td bgcolor="#7A0000"><font color=white size=2><b>$data{question}</b></font></td></tr>');
document.write('$menu');
document.write('<tr><td align=center><input type=image src="$pollworld/images/vote.gif"></td></tr>');
document.write('</table></form>');
~;

sub result
{
open (F,"<$basepath/$data{name}/question");
flock(F,$LOCK_EX);
$question=<F>;
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
flock(F,$LOCK_UN);
close(F);
$quantity=@answers;
$i=0;
while($i<$quantity)
{
	$results[$i]=-s "$basepath/$data{name}/$i";
	$results[$i]=0 if (!$results[$i]);
	$i++;
}
foreach(@results){$sum+=$_;}
$suma=$sum;
$sum=1 if ($sum==0);
foreach(@results)
{
	$temp=int($_/$sum*100);
	$temp++ if ($_/$sum*100-int($_/$sum*100)>0.5);
	push(@procentes,$temp);
}
print qq~document.write('<table width=200 border=1 bordercolor="#7A0000" cellpadding=0>');
document.write('<tr><td><a href="$furl"><img src="$pollworld/images/network.gif" width=200 height=40 border=0 alt="GET YOUR FREE VOTING SYSTEM"></a></td></tr>');
document.write('<tr><td bgcolor="#7A0000"><font color=white size=2><b>$question</b></font></td></tr>');
~;
$i=0;
while($i<$quantity)
{
	chop($answers[$i]);
	$width=$procentes[$i];
	$width=1 if ($width==0);
	$xwidth=100-$width;
	$xwidth=1 if ($xwidth==0);
	print qq~document.write('<tr><td><font size=1><b>$answers[$i]</b></font><br><img src="$pollworld/images/chartbar.gif" width="$width" height="10"><img src="$pollworld/images/blankbar.gif" width="$xwidth" height="10"><font size=2 color="#7A0000"><b> $results[$i] ($procentes[$i] %)</b></font></td></tr>');\n~;
	$i++;
}
$sum=$suma;
print qq~document.write('<tr><td bgcolor="#7A0000" align=center><font size=2 color=white><b>Total votes: $sum</b></td></tr></table>');
~;
exit;
}
