#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		$data{$field}=$value;
	}
}
if ($data{method} eq "maillist")
{
	open (F,"<$basepath/maillist");
	flock(F,$LOCK_EX);
	@emails=<F>;
	flock(F,$LOCK_UN);
	close (F);
	$count=0;
	if (@emails>0)
	{
	foreach(@emails)
	{
	chop;
	$count++;
	open (MAIL,"|$progmail");
	print MAIL "To: $_\n";
	print MAIL "From: $email ($owntitle)\n";
	print MAIL "Subject: $data{subject}\n\n";
	print MAIL "$data{body}\n\n";
	close (MAIL);
	}
	}
	$result=qq~
	<tr><td width="450">
	<font size=5 color="#00B0B0">MAILLIST STATUS</font>
	<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
	<tr><td><font size=2>Newsletter was sent to $count users</font></td></tr>
	</table>
	</td></tr>
	~;
	open (F,"<$pwpath/template/adm.tpl");
	@htmlpage=<F>;
	close (F);
	$htmlpage=join("\n",@htmlpage);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n\n";
	eval $htmlpage;
	exit;
}
if ($data{method} eq "general")
{
open(F,">pw.cfg");
flock(F,$LOCK_EX);
print F qq~######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx\@trxx.co.uk                                                    #
######################################################################
\$pwpath="$data{pwpath}";
\$basepath="$data{basepath}";
\$cgi="$data{cgi}";
\$pollworld="$data{pollworld}";
\$sysid="$data{sysid}";
\$progmail="$data{progmail}";
\$email='$data{email}';
\$furl="$data{furl}";
\$delay=$data{delay};
\$LOCK_SH=1;
\$LOCK_EX=2;
\$LOCK_NB=4;
\$LOCK_UN=8;
~;
flock(F,$LOCK_UN);
close(F);
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">CONFIG STATUS</font><br><br><font size=2>General settings were changed succesfully</font></td></tr>
~;
open (F,"<$pwpath/template/adm.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
if ($data{method} eq "admdata")
{
$data{name}=$data{alogin};
$data{password}=$data{apassword};
$data{alogin}=crypt($data{alogin},$data{alogin});
$data{apassword}=crypt($data{apassword},$data{apassword});
open (F,"+<$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
@passdata=<F>;
truncate(F,0);
seek(F,0,0);
$passdata[0]="$data{alogin}:$data{apassword}\n";
print F @passdata;
flock(F,$LOCK_UN);
close(F);
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">CHANGING LOGIN/PASS STATUS</font><br><br><font size=2>Your login and password were changed succesfully</font></td></tr>
~;
open (F,"<$pwpath/template/adm.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
