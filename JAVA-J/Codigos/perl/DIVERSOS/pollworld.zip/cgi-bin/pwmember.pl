#!/bin/perl
######################################################################
# PollWorld v1.1                            		             #
#--------------------------------------------------------------------#
# Programming and design by Michael "TRXX" Sissine                   #
# Copyright 1999 TRXX Programming Group (TPG)                        #
# All Rights Reserved                                                #
# http://www.trxx.co.uk                                              #
# trxx@trxx.co.uk                                                    #
######################################################################
open (F, "<pw.cfg");
@commands=<F>;
close (F);
foreach (@commands)
{
	eval $_;
}

######################################################################
#mAiN sECTi0N                                                        #
######################################################################
#gET dATA
if ($ENV{CONTENT_LENGTH}>0){sysread(STDIN,$data,$ENV{CONTENT_LENGTH});}
else {($data=$ENV{QUERY_STRING});}
@data=split("&",$data);
foreach (@data)
{
	/([^=]+)=(.*)/ && do
	{
		($field,$value)=($1,$2);
		$value=~s/\+/ /g;
		$value=~s/%([0-9a-fA-F]{2})/pack('C',hex($1))/eg;
		if ($data{$field}){$data{$field}="$data{$field},$value";}
		else {$data{$field}=$value;}
	}
}
$encline=crypt($data{name},$data{name}).":".crypt($data{password},$data{password});
$destination=$data{method};

#aUTH0RiSATiON
open (F, "<$basepath/pollworld.pwd");
flock(F,$LOCK_EX);
@pass=<F>;
flock(F,$LOCK_UN);
close (F);
shift(@pass);
foreach (@pass)
{
	chop;
	&$destination if ($_ eq $encline);
}
open (F,"<$pwpath/template/errauth.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;

######################################################################
#sUBR0TiNES sECTi0N                                                  #
######################################################################
sub stats
{
if (-e "$basepath/$data{name}/question")
{
open (F,"<$basepath/$data{name}/question");
flock(F,$LOCK_EX);
$question=<F>;
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
flock(F,$LOCK_UN);
close(F);
$quantity=@answers;
$i=0;
while($i<$quantity)
{
	$results[$i]=-s "$basepath/$data{name}/$i";
	$results[$i]=0 if (!$results[$i]);
	$i++;
}
foreach(@results){$sum+=$_;}
$suma=$sum;
$sum=1 if ($sum==0);
foreach(@results)
{
	$temp=int($_/$sum*100);
	$temp++ if ($_/$sum*100-int($_/$sum*100)>0.5);
	push(@procentes,$temp);
}
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">STATISTICS</font>
<table border="0" width="100%" cellpadding="0" bgcolor="#E0E0E0">
<tr><td valign="top" colspan=2><font size=2><b>$question</b></font></td></tr>
~;
$i=0;
while($i<$quantity){$result.=qq~<tr><td width="60%" bgcolor="#C0C0C0" valign="top"><font size=2><b>$answers[$i]</b></font></td><td width="40%" align="right" bgcolor="#C0C0C0"><font size=2>$procentes[$i] %<br>($results[$i] votes)</font></td></tr>\n~;$i++;}
$sum=$suma;
$result.=qq~
<tr><td width="80%" valign="top"><font size=2 color=red><b>Total votes</b></font></td><td width="20%" align="right"><font size=2 color=red>$sum</font></td></tr>
</table>
</td></tr>
~;
}
else 
{
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">STATISTICS</font>
<table border="0" width="100%" cellpadding="0" bgcolor="#E0E0E0">
<tr><td valign="top" colspan=2><font size=2><b>Please create new voting form first</b></font></td></tr>
</table>
</td></tr>
~;
}
open (F,"<$pwpath/template/stat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub code
{
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">HTML CODE</font>
<table border="0" width="100%" cellpadding="0" bgcolor="#E0E0E0">
<tr><td valign="top"><font size=2><form><textarea cols=47 rows=6>&lt;script&gt;
document.write('&lt;script src="$cgi/nph-pwnet.pl?name=$data{name}&session='+Math.random()+'"&gt;&lt;\\/script&gt;');
&lt;/script&gt;
</textarea></form></font></td></tr>
</table>
</td></tr>
~;
open (F,"<$pwpath/template/stat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub create
{
$result=qq~
<tr><td width="450"><form method="post" action="$cgi/pwmember.pl"><input type="hidden" name="name" value="$data{name}"><input type="hidden" name="password" value="$data{password}"><input type="hidden" name="method" value="new">
<font size=5 color="#00B0B0">CREATE NEW VOTING FORM</font>
<table border="0" width="100%" bgcolor="#00B0B0" cellspacing="0" cellpadding="0">
<tr><td width="50%"><font size="2">&nbsp;Question</font></td>
<td width="50%"><input type="text" name="question" size="48"></td></tr>
<tr><td width="50%"><font size="2">&nbsp;Answers<br>&nbsp;variants<br>&nbsp;(breakline<br>&nbsp;delimeted)</font></td>
<td width="50%"><textarea name="answers" cols="41" rows=6></textarea></td></tr>
<tr><td colspan=2 align="right"><input type="submit" value="Create">
</td></tr>
</table></form></td></tr>
~;
open (F,"<$pwpath/template/stat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub new
{
opendir(Dir,"$basepath/$data{name}");
@files=readdir(Dir);
closedir(Dir);
shift(@files);
shift(@files);
foreach(@files)
{
	unlink("$basepath/$data{name}/$_") if ($_ ne "settings");
}
opendir(Dir,"$basepath/$data{name}/iptmp");
@files=readdir(Dir);
closedir(Dir);
shift(@files);
shift(@files);
foreach(@files)
{
	unlink("$basepath/$data{name}/iptmp/$_");
}
open (F,">$basepath/$data{name}/question");
flock(F,$LOCK_EX);
print F $data{question};
flock(F,$LOCK_UN);
close(F);
srand;
$rdig=rand(99999999);
open (F,"+<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
$settings=<F>;
truncate(F,0);
seek(F,0,0);
($cook,$dely)=split("\t",$settings);
print F "$rdig\t$dely";
flock(F,$LOCK_UN);
close(F);
@answers=split("\r\n",$data{answers});
open (F,">$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
foreach(@answers)
{
	print F "$_\n";
}
flock(F,$LOCK_UN);
close(F);
$i=0;
foreach(@answers)
{
	if (!$checked)
	{
		push(@menu,qq~<tr><td><font size=1><input type=radio checked name=variant value=$i> $_</font></td></tr>\n~);
		$checked=1;
	}
	else {push(@menu,qq~<tr><td><font size=1><input type=radio name=variant value=$i> $_</font></td></tr>\n~);}
	$i++;
}
$forma=qq~
<!--Begin $owntitle code-->
<form action="$cgi/pwvote.pl" method="post" target="_blank">
<input type=hidden name=name value="$data{name}">
<table width=200 border=1 bordercolor="#7A0000" cellpadding=0>
<tr><td colspan=2><a href="$furl"><img src="$pollworld/images/network.gif" width=200 height=40 border=0 alt="GET YOUR FREE VOTING SYSTEM"></a></td></tr>
<tr><td colspan=2 bgcolor="#7A0000"><font color=white size=2><b>$data{question}</b></font></td></tr>
@menu
<tr><td align=center><input type=image src="$pollworld/images/vote.gif"></td></tr>
</table></form>
<!--End $owntitle code-->
~;
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">FORM CREATED</font><br>
<font size=2><br>It will looks like:</font><br><br>
<center>
$forma
</center>
</font></td></tr>
~;
open (F,"<$pwpath/template/stat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub modify
{
open (F,"<$basepath/$data{name}/question");
flock(F,$LOCK_EX);
$question=<F>;
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
($cook,$dely)=split("\t",<F>);
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
foreach(@answers)
{
	chop;
	$menu.=qq~<option value=$i> $_</option>\n~;
	$i++;
}
$result=qq~
<tr><td width="450">
<font size=5 color="#00B0B0">IP RESTRICTION</font>
<form action="$cgi/pwmember.pl" method=get>
<input type=hidden name=name value=$data{name}><input type=hidden name=password value=$data{password}><input type=hidden name=method value=chset>
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b>Ignore IP delay (in min)</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="dely" value="$dely"></font></td></tr>
<tr><td colspan=2 align=right><font size=1><input type=submit value=Change></font></td></tr>
</table></form></td></tr>
<tr><td width="450">
<font size=5 color="#00B0B0">CHANGE QUESTION</font>
<form action="$cgi/pwmember.pl" method=post>
<input type=hidden name=name value=$data{name}><input type=hidden name=password value=$data{password}><input type=hidden name=method value=chquest>
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b>Question</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="question" value="$question"></font></td></tr>
<tr><td colspan=2 align=right><font size=1><input type=submit value=Change></font></td></tr>
</table></form></td></tr>
<tr><td width="450">
<font size=5 color="#00B0B0">ADD ANSWER</font>
<form action="$cgi/pwmember.pl" method=post>
<input type=hidden name=name value=$data{name}><input type=hidden name=password value=$data{password}><input type=hidden name=method value=addans>
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b>Answer</b></font></td><td width="60%" align="right"><font size=2><input type="text" size=48 name="ans"></font></td></tr>
<tr><td colspan=2 align=right><font size=1><input type=submit value=Add></font></td></tr>
</table></form></td></tr>
<tr><td width="450">
<font size=5 color="#00B0B0">CHANGE ANSWER</font>
<form action="$cgi/pwmember.pl" method=post>
<input type=hidden name=name value=$data{name}><input type=hidden name=password value=$data{password}><input type=hidden name=method value=chans>
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td width="40%"><font size=1><b><select name="ans">$menu</select></b></font></td><td width="60%" align="right"><font size=2><input type="text" size=28 name="answ"></font></td></tr>
<tr><td colspan=2 align=right><font size=1><input type=submit value="Change"></font></td></tr>
</table></form></td></tr>
<tr><td width="450">
<font size=5 color="#00B0B0">STATISTICS</font>
<form action="$cgi/pwmember.pl" method=post>
<input type=hidden name=name value=$data{name}><input type=hidden name=password value=$data{password}><input type=hidden name=method value=rstat>
<table border="0" width="100%" cellpadding="0" bgcolor="#00B0B0">
<tr><td colspan=2 align=right><font size=1><input type=submit value="Reset stats"></font></td></tr>
</table></form></td></tr>
~;
open (F,"<$pwpath/template/stat.tpl");
@htmlpage=<F>;
close (F);
$htmlpage=join("\n",@htmlpage);
print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
print "content-type: text/html\n\n";
eval $htmlpage;
exit;
}
sub chset
{
open (F,"+<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
($cook,$dely)=split("\t",<F>);
truncate(F,0);
seek(F,0,0);
print F "$cook\t$data{dely}";
flock(F,$LOCK_UN);
close(F);
&modify;
}
sub chquest
{
open (F,">$basepath/$data{name}/question");
flock(F,$LOCK_EX);
print F "$data{question}";
flock(F,$LOCK_UN);
close(F);
&modify;
}
sub addans
{
open (F,">>$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
print F "$data{ans}\n";
flock(F,$LOCK_UN);
close(F);
&modify;
}
sub chans
{
open (F,"+<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
truncate(F,0);
seek(F,0,0);
$answers[$data{ans}]="$data{answ}\n";
print F @answers;
flock(F,$LOCK_UN);
close(F);
&modify;
}
sub rstat
{
srand;
$rndm=rand(99999999);
open (F,"+<$basepath/$data{name}/settings");
flock(F,$LOCK_EX);
($cook,$dely)=split("\t",<F>);
truncate(F,0);
seek(F,0,0);
print F "$rndm\t$dely";
flock(F,$LOCK_UN);
close(F);
open (F,"<$basepath/$data{name}/answers");
flock(F,$LOCK_EX);
@answers=<F>;
flock(F,$LOCK_UN);
close(F);
$i=0;
while ($i<@answers)
{
	unlink ("$basepath/$data{name}/$i");
	$i++;
}
opendir(Dir,"$basepath/$data{name}/iptmp");
@files=readdir(Dir);
closedir(Dir);
shift(@files);
shift(@files);
foreach(@files)
{
	unlink("$basepath/$data{name}/iptmp/$_");
}
&modify;
}
