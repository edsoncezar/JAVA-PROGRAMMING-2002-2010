IndiqueSite Script v1.0p - Vers�o p�blica
Escrito por Celso Endo
http://www.foxworld.com.bi		
ICQ: 6433316

Esse script � Freeware, pode ser distribuido livremente, mantendo os
coment�rios que se encontram no arquivo indique.cgi

Por favor, envie a url da p�gina onde voc� est� rodando o IndiqueSite
Script v1.0p para que um link seja colocado na futura p�gina:
The f0x{XF} Perl Collection - http://www.foxcollection.cjb.net

CONTE�DO DESSE README:
1. Configurando o script
2. Instalando o script
3. Usando o script
4. Cr�ditos

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
1. CONFIGURANDO O SCRIPT
. Antes de mais nada, abra o arquivo indique.cgi no seu editor preferido (como notepad)
e mude a primeira linha para o path do PERL 5+ em seu servidor. Caso voc� esteja rodando
na Hypermart ou Virtualave, o path j� est� certo.

. Agora edite essas vari�veis no arquivo indique.cgi :

$sendmail = "/path/para/sendmail";
# PATH completo para o Sendmail, ou outro programa para envio de e-mails em seu servidor

$seumail = "meu\@email.com.br";
# Seu e-mail (n�o esque�a da \ antes da @)

$titulohp = 'Minha hp';
# T�tulo da sua home page

$urlhp = 'http://www.endereco.da.minha.hp';
# Endere�o da sua home page

$descricaohp = 'Descri��o da hp';
# Descri��o da sua home page

$meunome = 'lalala';
# Seu nome ou apelido

$urlvolta = 'http://url.para.voltar';
# URL que ser� link na p�gina de confirma��o de envio para voltar

. E por �ltimo abra o arquivo indique.htm em seu editor preferido
e ache a linha:
<form action=URL_PARA_indique.cgi METHOD=POST>
Substitua URL_PARA_indique.cgi para a URL completa at� o arquivo indique.cgi

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
2. INSTALANDO O SCRIPT
Basta enviar o seguinte arquivo para seu servidor (em modo ASCII) e atribuir
o seguinte CHMOD:

indique.cgi - ASCII - CHMOD 755

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
3. USANDO O SCRIPT
. Coloque o arquivo indique.htm em seu servidor de p�gina e fa�a um link em seu menu
linkando para esse arquivo e pronto!

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
4. CR�DITOS
IndiqueSite Script v1.0p foi escrito por Celso Endo, f0x{XF}.
Voc� pode me encontrar no IRC, nos canais: #sti, #cgi, #perl, #web2000 e #webmasters com
o nick f0x{XF}, no ICQ: 6433316 e por email: foxworld@sti.com.br

Agrade�o a voc�s por estarem usando esse script!
Obrigado!
Para obter mais scripts de minha autoria, visitem:
http://www.foxcollection.cjb.net
E d�em uma olhada na minha p�gina pessoal, em:
http://www.foxworld.com.bi

Mais uma vez, obrigado a todos!!!

Celso Endo - f0x{XF}
