#!/usr/bin/perl

open(MYSQL,"mysql -u mymp3 -e 'show tables' mymp3 -pSuperIO|");
while (<MYSQL>)
{
  chomp;
  next if (/^Tables in /);
  push @tables,$_;
}
close MYSQL;

foreach $table (@tables) 
{
  open(TABLE,">sql/$table.sql");
  print TABLE "drop table $table;\n";
  open(MYSQL,"mysqldump -u mymp3 mymp3 $table -pSuperIO|");
  while (<MYSQL>) {print TABLE $_};
  close MYSQL;
  close TABLE;
}
$stamp=sprintf("%02d-%02d-%02d",(localtime(time))[4],(localtime(time))[3],(localtime(time))[5]+1900);
print "stamp = $stamp\n";
opendir(DIR,".");
@files=grep { !/^\./ && !/^backups/} readdir(DIR);
closedir DIR;
system "tar -zcf backups/mymp3_$stamp.tar.gz ".join(" ",@files);
