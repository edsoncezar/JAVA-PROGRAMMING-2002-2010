#!/usr/bin/perl

use DBI;
use FindBin;
use lib "$FindBin::Bin/../lib";
use MP3::Info;
use Digest::MD5;
require 'config.pl';

print "Running through virtual paths...\n";
$sth=&sqlSelectMany($DBH,
                      "path,id", # select ...
                      "virt_path", # from ...
                      );
while (($path,$id) = $sth->fetchrow_array) 
{
  if (-d $path) 
  {
    push @virt_paths,$path;
    $virt_paths{$path}=$id;
    print "added path $path, $id\n";
  }
  else
  { print "BAD PATH $path\n"; }
}

foreach $virt_path (@virt_paths) 
{ &recurse($virt_path,$virt_path); }

##
## done
##


sub recurse 
{
  my (@dirs,@files,$dir,$file,$junk);
  my ($start_dir,$virt_path)=@_;
  while ($start_dir =~ m!.+/$!) { chop $start_dir}
  opendir (DIR,$start_dir);
  @dirs = grep { !/^\./ && -d "$start_dir/$_" && (! -l "$start_dir/$_") } readdir(DIR);
  rewinddir DIR;
  @files= grep { /\.*mp(3|2|4){1}$/i && (! -d "$start_dir/$_") && (! -l "$start_dir/$_") } readdir(DIR);
  closedir DIR;
  foreach $filename (@files) 
  {
    $full_path=$start_dir."/".$filename;
    $rel_path=$full_path;
    $rel_path=~s/$virt_path//;
    $rel_path=~s/$filename//;
    &check_file($virt_path,$rel_path,$filename);
  }
  foreach $dir (@dirs)
  { &recurse("$start_dir/$dir",$virt_path); }
}

sub check_file 
{
  my ($virt_path,$rel_path,$filename) = @_;
  $full_path=join("",$virt_path,$rel_path,$filename);
  print "file found: $filename ($virt_path)->$rel_path\n";
  %info = %{get_mp3info($full_path)};
  %tag  = %{get_mp3tag($full_path)};
  ($id)=&sqlSelect($DBH,"count(id)","song","filename='$filename' AND path='$rel_path' AND virt_path='$virt_paths{$virt_path}'");
  if ($id == 0)
  {
    # file does not appear to be in database
    open (FILE,"<$full_path");
    $hexdigest=scalar ((Digest::MD5->new)->addfile(*FILE))->hexdigest;
    close FILE;
    $id = &sqlInsert($DBH,"song",(
			    virt_path	=>	$virt_paths{$virt_path},
			    path	=>	$rel_path,
			    filename	=>	$filename,
			    album	=>	$tag{ALBUM} || "-",
			    artist	=>	$tag{ARTIST} || "-",
			    title	=>	$tag{TITLE} || "-",
			    comment	=>	$tag{COMMENT} || "-",
			    genre	=>	0,
			    style	=>	0,
			    layer	=>	$info{LAYER},
			    bitrate	=>	$info{BITRATE},
			    rate	=>	$info{FREQUENCY},
			    mode	=>	$info{MODE},
			    channels	=>	($info{STEREO}+1), # returns 0 if mono, 1 if stereo.
			    size	=>	(stat($full_path))[7],
			    hash	=>	$hexdigest,
			    seconds	=>	(($info{MM}*60)+$info{SS})
			   ) # end of hash
		    ) or print "insert error $!";
  }
  else
  { print STDERR "** file is already in database!\n"; }
}
