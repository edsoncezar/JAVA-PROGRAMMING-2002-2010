require 'getcwd.pl';
$wrap=&getcwd."/";
$appname=$0;
if ($appname =~ /(.+)/) {
  $appname = $1;
}

$appname =~ s|.*/(.+)$|$1|;
$wrap.="$appname.wrapped";
@vars=(sort keys(%ENV));
       
  foreach $var (@vars) {
    $out.='$ENV{'."$var}=".qq{"$ENV{$var}";\n};
  }
  $out.="\n1;\n";
  $out =~ s/\@/\\@/g;
  open (WRAPPED,">$wrap") || die("Could not write to wrap file $wrap! $!");
  print WRAPPED $out;
  close WRAPPED;

1;

