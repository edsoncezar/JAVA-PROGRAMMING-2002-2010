sub filedisp {
  my ($file) = @_;
  my ($a);
  local *IN;
  open (IN, "$HTML_PATH/$file") ||
  open (IN, "$file") ||
  open (IN, "html/$file") ||
  die "Could not fine $file anywhere!";
  while (<IN>) {
    while (/<!-- PERL:\s*(.*)\s*-->/) {
      $a=eval "$1";
      if ($a eq "1") { $a = ''; }
      s/<!-- PERL:\s*.*\s*-->/$a/;
    }
    while (/(&\w+\s?\(.*\);)/) {
      $a=eval "$1";
      if ($a eq "1") { $a = ''; }
       if ($@) { $a = $@; }
      s/(&\w+\s?\(.*\);)/$a/;
    }
    while (/(\$\w+\{\w+\})/) {
      $a=eval "$1";
      s/\$\w+\{\w+\}/$a/ if $1;
    }
    while (/(\$\w+)\b/) {
      $a=eval "$1";
      s/\$\w+\b/$a/ if $1;
    }
    print;
  }
  close IN;
}


1;

