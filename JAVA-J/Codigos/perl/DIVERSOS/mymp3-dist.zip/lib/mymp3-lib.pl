sub login {
  my ($uid,$pass)=@_;
  if (!$uid || !$pass) { return };
  ($uid,$pass)=($DBH->quote($uid),$DBH->quote($pass));
  (&sqlSelect($DBH,"count(*)","users","uid=$uid and pass=$pass"))[0];
}

sub cookie_time {
    my($time) = @_;

    my(@MON)=qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
    my(@WDAY) = qw/Sun Mon Tue Wed Thu Fri Sat/;

    # pass through preformatted dates for the sake of expire_calc()
    return $time unless $time =~ /^\d+$/;

    $sc = '-';
    my($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime($time);
    $year += 1900;
    return sprintf("%s, %02d$sc%s$sc%04d %02d:%02d:%02d GMT",
                   $WDAY[$wday],$mday,$MON[$mon],$year,$hour,$min,$sec);
}

sub create_session
{
  my ($uid) = @_;

  UNIQUE_SESSION: foreach (1..3)  # try only 3 times to get a unique key so we don't loop infinite
  {
    $session_id=&rand_string(10);
    if ( !(
           &sqlSelect($DBH,"count(*)",
                           "session", 
                           "uid=".$DBH->quote($input{uid})." and session_id='$session_id'")
          )[0] 
       )
    {
      # our session id is unique for this user.
      my $session_expire_utime=&CGI::expire_calc($COOKIE_EXPIRE);
      my $session_expire_ctime=&cookie_time($session_expire_utime);
      $session_cookie=new CGI::Cookie( -name=>'session_id',
                                       -value=>$session_id,
                                       -expires=>$session_expire_ctime);

      &sqlInsert($DBH,"session",( uid=>$input{uid},
                                  session_id=>$session_id,
                                  -expire=>"FROM_UNIXTIME($session_expire_utime)")
                );
      last UNIQUE_SESSION;
    }
    else
    { undef $session_id; }
  }
  $session_cookie;
}

sub update_session 
{
  my ($session) = @_;
  my $session_expire_utime=&CGI::expire_calc($COOKIE_EXPIRE);
  my $session_expire_ctime=&cookie_time($session_expire_utime);
  $session_cookie=new CGI::Cookie( -name=>'session_id',
                                   -value=>$session_id,
                                   -expires=>$session_expire_ctime);

  &sqlInsert($DBH,"session","session_id='$session'",(
                              -expire=>"FROM_UNIXTIME($session_expire_utime)")
            );
  $session_cookie;
}

sub session_not_expired
{
  my ($uid,$session_id) = @_;
  my $expire=(&sqlSelect($DBH,"UNIX_TIMESTAMP(expire)",
                              "session",
                              "uid='$uid' and session_id='$session_id'"))[0];
  if (time ge $expire)
  {
    $DBH->do(qq|DELETE FROM session WHERE uid='$uid' AND session_id="$session_id";|);
    return 0;
  }
  else
  { return 1; }
}

sub current_time { return scalar localtime(time); }  
sub expire_time
{
  return scalar localtime (
                           (&sqlSelect($DBH,
                                       "UNIX_TIMESTAMP(expire)",
                                       "session",
                                       "uid='$uid' and session_id='$session_id'")
                           )[0]
                          )
}


1;
