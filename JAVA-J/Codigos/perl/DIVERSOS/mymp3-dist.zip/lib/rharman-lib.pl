sub debuglog {
  my ($msg) = @_;
  my($now);
  if (!$LOGFILE) {$LOGFILE="$0.log"};
  open (LOG, ">>$LOGFILE") || print "$!\n";
  $now = localtime;
  print LOG "$now  ($user) $0: $msg\n";
  close LOG;
}

sub commify {
  local $_  = shift;
  1 while s/^(-?\d+)(\d{3})/$1,$2/;
  return $_;
}

sub rand_string {
  my ($length)=@_;
  my (@chars,$out);
  @chars=('A'..'Z');
  push @chars,('a'..'z');
  push @chars,('0'..'9');
#  push @chars,(split //,q/`~!@#$%^&*()_+-=[]\{}|;':",.\/<>?/);
  foreach (1..$length) {
    $out.=@chars[rand($#chars)];
  }  
 $out;
}

sub uriescape {
  my ($foo) = @_;
  my ($out);
  foreach (split //,$foo)
  {
    if ( $_ eq " ") {$out.="+";next};
    if(ord($_) < 0x41 || ord($_) > 0x7a)
    { $out.=sprintf("%%%02x",ord($_)) }
    else
    { $out.=$_ }
  } 
  $out;
}

sub unuriescape 
{
    # Note from RFC1630:  "Sequences which start with a percent sign
    # but are not followed by two hexadecimal characters are reserved
    # for future extension"
    my $str = shift;
    if (@_ && wantarray) {
        # not executed for the common case of a single argument
        my @str = @_;  # need to copy
        return map { s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg } $str, @str;
    }
    $str =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;
    $str;
}

sub parse_html {
  my ($file) = @_;
  my ($a,$out);
  local *IN;
  open (IN, "$HTML_PATH/$file") ||
  open (IN, "$file") ||
  open (IN, "html/$file") ||
  die "Could not fine $file anywhere!";
  while (<IN>) {
    while (/<!-- PERL:\s*(.*)\s*-->/) {
      $a=eval "$1";
      if ($a eq "1") { $a = ''; }
      s/<!-- PERL:\s*.*\s*-->/$a/;
    }
    while (/(&\w+\s?\(.*\);)/) {
      $a=eval "$1";
      if ($a eq "1") { $a = ''; }
       if ($@) { $a = $@; }
      s/(&\w+\s?\(.*\);)/$a/;
    }
    while (/(\$\w+\{\w+\})/) {
      $a=eval "$1";
      s/\$\w+\{\w+\}/$a/ if $1;
    }
    while (/(\$\w+)\b/) {
      $a=eval "$1";
      s/\$\w+\b/$a/ if $1;
    }
    $out.=$_;
  }
  close IN;

  if (defined wantarray) { 
    # you may think the above line is freaky,
    # but when you do 'print &subroutine', it
    # acctually would prefer an array. :)
    return $out;
  } else {
    print $out; 
  }
}



1;

