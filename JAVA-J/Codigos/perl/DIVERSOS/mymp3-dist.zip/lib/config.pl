$HTML_PATH="$FindBin::Bin/../html";
$WEB_HTML_PATH="/mymp3";
$WEB_CGI_PATH="/mymp3-bin";

use DBI;
use CGI::Cookie;
use CGI::Carp "fatalsToBrowser";
#use CGI;
require 'sql-lib.pl';
require 'amccoy-lib.pl';
require 'rharman-lib.pl';
require 'cgi-lib.pl';
require 'mymp3-lib.pl';
require 'html-funcs.pl';
$DBH=&sqlconnect((
                user=>"mymp3",
                database=>"mymp3",
                pass=>"SuperIO"));

$COOKIE_EXPIRE="+4h";


1;


