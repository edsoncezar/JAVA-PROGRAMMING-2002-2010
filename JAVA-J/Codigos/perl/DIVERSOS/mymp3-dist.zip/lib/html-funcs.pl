sub content_block {
  local ($title,$content,$width) = @_;
  print &parse_html("content_block.html");
}

1;
