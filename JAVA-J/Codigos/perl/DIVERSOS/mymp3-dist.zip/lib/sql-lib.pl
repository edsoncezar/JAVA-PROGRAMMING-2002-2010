#$sqldebug=1;
use DBI;
#
# $dbh=&sqlconnect();
# 
# easy way to connect to sql and get the db handle

sub sqlconnect {
  my (%hash)=@_;
  my ($dsn);
  $dsn = "DBI:mysql:database=";
  $dsn ||= "DBI:$hash{driver}:database=" if $hash{driver};
  $dsn .= $hash{database};
  if ($hash{server})
  { $dsn .=":server=$hash{server}" }
  $dsn ||= $hash{dsn};
  $dbh = DBI->connect($dsn,$hash{user},$hash{pass});
  if (!$dbh) 
  { die "Could not connect to server '$DB_ENT,$DB_USER': " . $DBI::errstr; }
  return $dbh;
}

#
# $sth=sqlSelectMany($dbh,'site_key,seats','downlink_sites','seats > 50','order 
#
# returns the statement handle after preparing and executing the sql statement.

sub sqlSelectMany
{
        my($dbh,$select,$from,$where,$other)=@_;

        my $sql="SELECT $select ";
        $sql.="FROM $from " if $from;
        $sql.="WHERE $where " if $where;
        $sql.="$other" if $other;
        print "<!-- sqlselectmany = \"$sql\" -->\n" if ($sqldebug);   
        my $c=$dbh->prepare($sql);
        if($c->execute()) {
                return $c;
        } else {
                die "\n<P><B>sqlSelectMany Error<BR><PRE>'$sql'\nsql reports:\n'".$dbh->errstr."'</PRE>";
                $c->finish(); 
                return undef;
        }
}
#
# ($f_name,$lname,

sub sqlSelect
{
        my ($dbh,$select, $from, $where, $other)=@_;
        my $sql="SELECT $select ";
        $sql.="FROM $from " if $from;
        $sql.="WHERE $where " if $where;
        $sql.="$other" if $other;
        my $c=$dbh->prepare($sql) or die "Sql has gone away\n";
        if(not $c->execute()) {
                print "\n<P><B>SQL Error</B><BR>".$dbh->errstr;
                return undef;
        }
        my @r=$c->fetchrow();
        print "<!-- sqlselect = \"$sql\", \n",join(':',@r)," -->\n" if ($sqldebug);     
        $c->finish();
        return @r;
} 

sub sqlUpdate
{
        my($dbh,$table,$where,%data)=@_;
        my $sql="UPDATE $table SET";
        foreach (keys %data) {
                if (/^-/) {
                        s/^-//;
                        $sql.="\n  $_ = $data{-$_} ";
                } else {
                        $sql.="\n  $_ = ".$dbh->quote($data{$_}).",";
                }

        }
        chop($sql);
        $sql.="\nWHERE $where\n";
        print "<!-- sql = \"$sql\" -->\n" if ($sqldebug);
        $dbh->do($sql);
}

sub sqlInsert
{
        my($dbh,$table,%data)=@_;
        my($names,$values);
        
        foreach (keys %data) {
                if (/^-/) {$values.="\n  ".$data{$_}.","; s/^-//;}
                else { $values.="\n  ".$dbh->quote($data{$_}).","; }
                $names.="$_,";
        }
        chop($names);
        chop($values);
        my $sql="INSERT INTO $table ($names) VALUES($values)\n";
        print "<!-- sqlInsert = '$sql' -->\n" if ($sqldebug); 
        $dbh->do($sql);
}

sub PrintHash {
  (%HASH) = @_;
  print "<TABLE>\n";
  foreach $key (keys %HASH) {
    $a = $HASH{$key};
    $a =~ s/\000/--/g;
    print "<TR><TD>$key</TD> <TD WIDTH=10></TD> <TD>'$HASH{$key}'</TD></TR>\n";
  }
  print "</TABLE>\n";
}

1;

