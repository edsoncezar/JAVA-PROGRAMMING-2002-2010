drop table lists;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'lists'
#
CREATE TABLE lists (
  id mediumint(3) DEFAULT '0' NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  songs text,
  PRIMARY KEY (id)
);

#
# Dumping data for table 'lists'
#

INSERT INTO lists VALUES (1,'Clubbers Guide To Trance Disk 1','1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012');

