drop table session;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'session'
#
CREATE TABLE session (
  uid varchar(8) DEFAULT '' NOT NULL,
  session_id varchar(10) DEFAULT '' NOT NULL,
  expire timestamp(14)
);

#
# Dumping data for table 'session'
#

INSERT INTO session VALUES ('warewolf','yFcXJbz8JG',20000504202546);
INSERT INTO session VALUES ('warewolf','jqO4Ip5YBI',20000529063658);
INSERT INTO session VALUES ('warewolf','h7XbC3PVz3',20000702054811);

