drop table rights;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'rights'
#
CREATE TABLE rights (
  right varchar(19),
  right_desc varchar(90)
);

#
# Dumping data for table 'rights'
#

INSERT INTO rights VALUES ('search','Allow this user to perform a search against the database');
INSERT INTO rights VALUES ('stream','Allow this user to stream a mp3');
INSERT INTO rights VALUES ('download','Allow this user to download a mp3');
INSERT INTO rights VALUES ('edit','Allow this user to edit the ID3 tags of a mp3');
INSERT INTO rights VALUES ('upload','Allow this user to upload mp3\'s');
INSERT INTO rights VALUES ('move','Allow this user to move mp3\'s around on disk');
INSERT INTO rights VALUES ('delete','Allow this user to delete ia mp3 from disk');
INSERT INTO rights VALUES ('upload_mgr','Allow this user to add mp3\'s that have been uploaded');

