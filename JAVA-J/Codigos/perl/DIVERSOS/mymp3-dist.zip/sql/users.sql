drop table users;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'users'
#
CREATE TABLE users (
  uid varchar(8),
  pass varchar(8)
);

#
# Dumping data for table 'users'
#

INSERT INTO users VALUES ('warewolf','SuperIO');
INSERT INTO users VALUES ('garetj','garet80g');
INSERT INTO users VALUES ('iriantuu','iri');

