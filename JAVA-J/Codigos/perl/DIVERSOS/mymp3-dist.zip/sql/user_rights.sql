drop table user_rights;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'user_rights'
#
CREATE TABLE user_rights (
  uid varchar(8),
  right varchar(19)
);

#
# Dumping data for table 'user_rights'
#

INSERT INTO user_rights VALUES ('warewolf','search');
INSERT INTO user_rights VALUES ('warewolf','stream');
INSERT INTO user_rights VALUES ('warewolf','download');
INSERT INTO user_rights VALUES ('warewolf','edit');
INSERT INTO user_rights VALUES ('warewolf','upload');
INSERT INTO user_rights VALUES ('warewolf','move');
INSERT INTO user_rights VALUES ('warewolf','delete');
INSERT INTO user_rights VALUES ('warewolf','upload_mgr');

