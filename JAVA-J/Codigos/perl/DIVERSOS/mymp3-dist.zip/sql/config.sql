drop table config;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'config'
#
CREATE TABLE config (
  name varchar(40) DEFAULT '' NOT NULL,
  value varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (name,value)
);

#
# Dumping data for table 'config'
#


