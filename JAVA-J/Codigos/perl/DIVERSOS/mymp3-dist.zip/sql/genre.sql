drop table genre;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'genre'
#
CREATE TABLE genre (
  id smallint(2) DEFAULT '0' NOT NULL,
  genre varchar(30) DEFAULT '' NOT NULL,
  PRIMARY KEY (id,genre)
);

#
# Dumping data for table 'genre'
#

INSERT INTO genre VALUES (0,'Blues');
INSERT INTO genre VALUES (1,'Classic');
INSERT INTO genre VALUES (2,'Country');
INSERT INTO genre VALUES (3,'Dance');
INSERT INTO genre VALUES (4,'Disco');
INSERT INTO genre VALUES (5,'Funk');
INSERT INTO genre VALUES (6,'Grunge');
INSERT INTO genre VALUES (7,'Hip-Hop');
INSERT INTO genre VALUES (8,'Jazz');
INSERT INTO genre VALUES (9,'Metal');
INSERT INTO genre VALUES (10,'New');
INSERT INTO genre VALUES (11,'Oldies');
INSERT INTO genre VALUES (12,'Other');
INSERT INTO genre VALUES (13,'Pop');
INSERT INTO genre VALUES (14,'R&B');
INSERT INTO genre VALUES (15,'Rap');
INSERT INTO genre VALUES (16,'Reggae');
INSERT INTO genre VALUES (17,'Rock');
INSERT INTO genre VALUES (18,'Techno');
INSERT INTO genre VALUES (19,'Industrial');
INSERT INTO genre VALUES (20,'Alternative');
INSERT INTO genre VALUES (21,'Ska');
INSERT INTO genre VALUES (22,'Death');
INSERT INTO genre VALUES (23,'Pranks');
INSERT INTO genre VALUES (24,'Soundtrack');
INSERT INTO genre VALUES (25,'Euro-Techno');
INSERT INTO genre VALUES (26,'Ambient');
INSERT INTO genre VALUES (27,'Trip-Hop');
INSERT INTO genre VALUES (28,'Vocal');
INSERT INTO genre VALUES (29,'Jazz+Funk');
INSERT INTO genre VALUES (30,'Fusion');
INSERT INTO genre VALUES (31,'Trance');
INSERT INTO genre VALUES (32,'Classical');
INSERT INTO genre VALUES (33,'Instrumental');
INSERT INTO genre VALUES (34,'Acid');
INSERT INTO genre VALUES (35,'House');
INSERT INTO genre VALUES (36,'Game');
INSERT INTO genre VALUES (37,'Sound');
INSERT INTO genre VALUES (38,'Gospel');
INSERT INTO genre VALUES (39,'Noise');
INSERT INTO genre VALUES (40,'AlternRock');
INSERT INTO genre VALUES (41,'Bass');
INSERT INTO genre VALUES (42,'Soul');
INSERT INTO genre VALUES (43,'Punk');
INSERT INTO genre VALUES (44,'Space');
INSERT INTO genre VALUES (45,'Meditative');
INSERT INTO genre VALUES (46,'Instrumental');
INSERT INTO genre VALUES (47,'Instrumental');
INSERT INTO genre VALUES (48,'Ethnic');
INSERT INTO genre VALUES (49,'Gothic');
INSERT INTO genre VALUES (50,'Darkwave');
INSERT INTO genre VALUES (51,'Techno-Industrial');
INSERT INTO genre VALUES (52,'Electronic');
INSERT INTO genre VALUES (53,'Pop-Folk');
INSERT INTO genre VALUES (54,'Eurodance');
INSERT INTO genre VALUES (55,'Dream');
INSERT INTO genre VALUES (56,'Southern');
INSERT INTO genre VALUES (57,'Comedy');
INSERT INTO genre VALUES (58,'Cult');
INSERT INTO genre VALUES (59,'Gangsta');
INSERT INTO genre VALUES (60,'Top');
INSERT INTO genre VALUES (61,'Christian');
INSERT INTO genre VALUES (62,'Pop/Funk');
INSERT INTO genre VALUES (63,'Jungle');
INSERT INTO genre VALUES (64,'Native');
INSERT INTO genre VALUES (65,'Cabaret');
INSERT INTO genre VALUES (66,'New');
INSERT INTO genre VALUES (67,'Psychadelic');
INSERT INTO genre VALUES (68,'Rave');
INSERT INTO genre VALUES (69,'Showtunes');
INSERT INTO genre VALUES (70,'Trailer');
INSERT INTO genre VALUES (71,'Lo-Fi');
INSERT INTO genre VALUES (72,'Tribal');
INSERT INTO genre VALUES (73,'Acid');
INSERT INTO genre VALUES (74,'Acid');
INSERT INTO genre VALUES (75,'Polka');
INSERT INTO genre VALUES (76,'Retro');
INSERT INTO genre VALUES (77,'Musical');
INSERT INTO genre VALUES (78,'Rock');
INSERT INTO genre VALUES (79,'Hard');
INSERT INTO genre VALUES (80,'Unknown');

