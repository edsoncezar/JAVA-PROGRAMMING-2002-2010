drop table style;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'style'
#
CREATE TABLE style (
  id smallint(2),
  name varchar(30)
);

#
# Dumping data for table 'style'
#


