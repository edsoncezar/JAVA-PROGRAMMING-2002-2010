drop table user_lists;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'user_lists'
#
CREATE TABLE user_lists (
  id mediumint(3) DEFAULT '0' NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  owner varchar(8) DEFAULT '' NOT NULL,
  songs text,
  PRIMARY KEY (id)
);

#
# Dumping data for table 'user_lists'
#


