drop table virt_path;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'virt_path'
#
CREATE TABLE virt_path (
  id smallint(5) DEFAULT '0' NOT NULL auto_increment,
  path varchar(120) DEFAULT '' NOT NULL,
  PRIMARY KEY (id,path)
);

#
# Dumping data for table 'virt_path'
#

INSERT INTO virt_path VALUES (1,'/mnt/big1/mp3/genre/classical');
INSERT INTO virt_path VALUES (2,'/mnt/big1/mp3/genre/country');
INSERT INTO virt_path VALUES (3,'/mnt/big1/mp3/genre/effects');
INSERT INTO virt_path VALUES (4,'/mnt/big1/mp3/genre/handbell');
INSERT INTO virt_path VALUES (5,'/mnt/big1/mp3/genre/heavy_rock');
INSERT INTO virt_path VALUES (6,'/mnt/big1/mp3/genre/humor');
INSERT INTO virt_path VALUES (7,'/mnt/big1/mp3/genre/irish');
INSERT INTO virt_path VALUES (8,'/mnt/big1/mp3/genre/musicals');
INSERT INTO virt_path VALUES (9,'/mnt/big1/mp3/genre/oldies');
INSERT INTO virt_path VALUES (10,'/mnt/big1/mp3/genre/rap');
INSERT INTO virt_path VALUES (11,'/mnt/big1/mp3/genre/recent');
INSERT INTO virt_path VALUES (12,'/mnt/big2/mp3/full_albums');
INSERT INTO virt_path VALUES (13,'/mnt/big2/mp3/soundtracks');

