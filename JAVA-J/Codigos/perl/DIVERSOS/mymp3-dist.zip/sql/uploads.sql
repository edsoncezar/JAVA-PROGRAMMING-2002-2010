drop table uploads;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'uploads'
#
CREATE TABLE uploads (
  id mediumint(5) DEFAULT '0' NOT NULL auto_increment,
  filename varchar(100) DEFAULT '' NOT NULL,
  album varchar(60) DEFAULT '' NOT NULL,
  artist varchar(60) DEFAULT 'UNKNOWN' NOT NULL,
  title varchar(60) DEFAULT '' NOT NULL,
  PRIMARY KEY (id,filename,title,artist)
);

#
# Dumping data for table 'uploads'
#


