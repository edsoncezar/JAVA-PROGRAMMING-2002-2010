drop table blocks;
# MySQL dump 6.0
#
# Host: localhost    Database: mymp3
#--------------------------------------------------------
# Server version	3.22.23b

#
# Table structure for table 'blocks'
#
CREATE TABLE blocks (
  id mediumint(3) DEFAULT '0' NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  category varchar(40) DEFAULT '' NOT NULL,
  type varchar(40) DEFAULT '' NOT NULL,
  content text,
  PRIMARY KEY (id,name,category,type)
);

#
# Dumping data for table 'blocks'
#

INSERT INTO blocks VALUES (1,'style 1','row_styles','token','<TD>#ID#</TD><TD>#ARTIST#-#TITLE# [#ALBUM#]');

