#!/usr/bin/perl
use DBI;
use FindBin;
use lib "$FindBin::Bin/../lib";
use MP3::Info;
use Digest::MD5;
require 'config.pl';

if (-f $ARGV[0])
{
  %info = %{get_mp3info($ARGV[0])};
  %tag  = %{get_mp3tag($ARGV[0])};
  print '%info = ('."\n";
  foreach $key (keys %info)
  { print "$key=>'$info{$key}',\n"; }
  print ");\n";
  print '%tag = ('."\n";
  foreach $key (keys %tag)
  { print "$key=>'$tag{$key}',\n"; }
  print ");\n";

} 
