$dir="database/";
## Diret�rio onde ser�o gravados os dados das enquetes
## recomenda-se usar path, sempre termine com uma /

$http="http://www.seusite.com/cgi-bin/enquete/enquete.cgi";
## URL para o enquete.cgi

$bgr="fnd.gif";
## Url completa para o arquivo de textura para os resultados da enquete

$tpo="database/enq.tipo";
## Arquivo de configura��o da enquete
## Recomendamos usar path

$sadm="senha";
## senha administrativa, use-a para entrar no admin.cgi

$arq="database/inflogin.temp";
## arquivo tempor�rio da administra��o, n�o est� inicialmente criado

$ext="inf";
## extens�o para o arquivo de informa��o para as enquetes criadas

$extip="iplist";
## extens�o para a lista de ips, que gravar� os ips das pessoas que j� votar�o na enquete

################### Formul�rio, n�o mexa

   read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
   if (length($buffer) < 5) {
         $buffer = $ENV{QUERY_STRING};
    }
 
  @pairs = split(/&/, $buffer);
   foreach $pair (@pairs) {
      ($name, $value) = split(/=/, $pair);

      $value =~ tr/+/ /;
      $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

      $FORM{$name} = $value;
      $form{$name} = $value;
      $in{$name} = $value;
   }

1;