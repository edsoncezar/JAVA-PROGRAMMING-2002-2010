                                  Enquetes - Iron Scripts

Todos os direitos reservados a Iron Scripts, www.ironscripts.tk
Para obter qualquer tipo de ajuda sobre esse script, utilize nosso forum, em nosso website

Instala��o: Passe todos os arquivos para um diret�rio �nico, d� chmod 755 nos .cgi e .pl, e 777 
            nos diret�rios. Depois de feito isso, voc� dever� configurar o config.pl, de acordo
            com as intru��es nesse arquivo.

Administra��o: Para entrar na administra��o, basta acessar esse arquivo pelo seu navegador,
               usando a senha escolhida no config.pl

Outros: Para mudar a textura dos resultados da enquete, basta substituir o fnd.gif pela imagem
        desejada


Todos os direitos reservados a Iron Scripts, www.ironscripts.tk