-- This script will DESTROY your installation of cascade, deleting all your data. Use with caution.
drop table if exists cas_category;
drop table if exists cas_item;
drop table if exists cas_item_suggested_updates;
drop table if exists cas_category_item_map;
drop table if exists cas_zipcodes;
drop table if exists cas_country_codes;
drop table if exists cas_state_codes;
drop table if exists cas_link;
drop table if exists cas_related_category;
drop table if exists cas_users;
drop table if exists cas_users_preferences;
drop table if exists cas_user_item_map;
drop table if exists cas_category_editor_map;
drop table if exists cas_user_session;
