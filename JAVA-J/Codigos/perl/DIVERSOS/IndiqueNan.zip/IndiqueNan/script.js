var url
function Indicar(url)
{
window.open(url,"resp","resizable=no,toolbar=no,status=no,menubar=no,scrollbars=no,width=290,height=260");
}