#!/usr/bin/perl
################################################################################
# WWWAdverts                                   Version 1.5                     #
# Copyright 1999 Frederic TYNDIUK (FTLS)       All Rights Reserved.            #
# E-Mail: tyndiuk@ftls.org                     Script License: GPL             #
# Created  05/30/98                            Last Modified 05/30/00          #
# Scripts Archive at:                          http://www.ftls.org/cgi/        #
################################################################################
# Function : Lib for WWWAdverts                                                #
# Display a rotating banner ads from on a file in the Visitor Lang             #
# Use as a SSI <!--#include virtual="/cgi-bin/WWWAdvertsSSI.cgi"-->            #
# or include on a CGI Script                                                   #
# require "WWWAdvertsLib.pl";                                                  #
# print &Adverts(time, "In this Language", "keywords");                        #
################################################################################
########################## license & copyright header ##########################
#                                                                              #
#                     Copyright (c) 1999 by TYNDIUK Frederic                   #
#                                                                              #
#       This program is free software; you can redistribute it and/or          #
#       modify it under the terms of the GNU General Public License as         #
#       published by the Free Software Foundation; either version 2 of         #
#       the License, or (at your option) any later version.                    #
#                                                                              #
#       This program is distributed in the hope that it will be useful,        #
#       but WITHOUT ANY WARRANTY; without even the implied warranty of         #
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          #
#       GNU General Public License for more details.                           #
#                                                                              #
#       You should have received a copy of the GNU General Public License      #
#       along with this program in the file 'COPYING'; if not, write to        #
#       the Free Software Foundation, Inc., 59 Temple Place - Suite 330,       #
#       Boston, MA 02111-1307, USA, or contact the author:                     #
#                                                                              #
#                                   TYNDIUK Frederic <tyndiuk@ftls.org>        #
#                                            <http://www.ftls.org/>            #
#                                                                              #
######################## end license & copyright header ########################
################################################################################
# Necessary Variables:                                                         #
# The following variables should be set to define the locations                #
# and URLs of various files, as explained in the documentation.                #

my ($datadir) = "/Absolute/path/to/data/";
$AdvertDataFile = $datadir."Adverts.txt";
$AdvertExLogFile = $datadir."AdvEx_Log.txt";
$AdvertClLogFile = $datadir."AdvCl_Log.txt";

# En : Configur Administrative 
# Fr : Configuartion Administration

$DISPLAY_LANG = 'En'; #Fr
$EXIT_URL = '/';
$WEBMASTER_EMAIL = 'webmaster@yourdom.dom';

# En: Protect this page with a Password (password file use WAccess Format).
# Fr: Protection par mot de passe (fichier password au Format WAccess).
$PASSWORD_FILE = "/Absolute/path/to/password.txt";
$UNIV_LOGIN = '';    # En: If you want add a universal login / password...
$UNIV_PASSWORD = ''; # Fr: Si vous desirez ajouter un login / password universel...

# Nothing Below this line needs to be altered!                                 #
################################################################################
#    DO NOT EDIT ANYTHING BELOW THIS LINE UNLESS YOU KNOW WHAT YOU'RE DOING    #
################################################################################

@date = localtime(time); $date[4]++; $date[5] += 1900;
$JToday = &jday($date[4], $date[3], $date[5]);
if ($date[3] < 10) { $date[3] = "0$date[3]"; }
if ($date[4] < 10) { $date[4] = "0$date[4]"; }
$DateTodays = "$date[3]/$date[4]/$date[5]";

# Dispaly a Random Adverts
sub Adverts {
	my($time, $QueryLang, $QueryKeyword) = @_;
	if (! $time) { $time = time }
	my($Host, $ScriptName, $LangVisitor, $cnt, $NoLine, $AdvertLine,
		$AdvertTxt, $Random1000, $Random100, $Random10, $No, $Name, $Comment, $GestLogin, $GuestPassord, $States, $Ratio, %in,
		$DataBegin, $DateEnd, $MaxHits, $MaxClicks, $NbClicks, $Lang, $LgAndKw, $Keyword, $AdvertTxt, $name, $value,
		$GoodAdvert, $GoodAdvertKey, @FileAdvert, @GoodAdvert, @GoodAdvertKey, @FileLogClicks, $OSVisitor, $OS);

	if ($ENV{'HTTP_USER_AGENT'} =~ /scooter|robot|ultraseek|spider|wget/i) {
		return;
		# En: Don't Display Adverts for robots.
		# Fr: N'affiche pas la pub pour les robots.
	}

	if ($ENV{'HTTP_USER_AGENT'} =~ /Win/i) { $OSVisitor = "1" }
	elsif ($ENV{'HTTP_USER_AGENT'} =~ /Macintosh/i) { $OSVisitor = "2" }
	elsif ($ENV{'HTTP_USER_AGENT'} =~ /Linux/i) { $OSVisitor = "3" }
	elsif ($ENV{'HTTP_USER_AGENT'} =~ /X11/i) { $OSVisitor = "4" }
	elsif ($ENV{'HTTP_USER_AGENT'} =~ /scooter|robot|ultraseek|spider|wget/i) { $OSVisitor = "5" }
	else  { $OSVisitor = "6" }
	
	$Host = $ENV{REMOTE_HOST};
	$Host =~ s/.*\.//;
	$Lang = $ENV{HTTP_ACCEPT_LANGUAGE};
	$ScriptName = $ENV{SCRIPT_NAME};
	
	if (&TestLang("Fr",$QueryLang, $Host, $Lang, $ScriptName)) {
		$LangVisitor = "Fr";
	} elsif (&TestLang("De",$QueryLang, $Host, $Lang, $ScriptName)) {
		$LangVisitor = "De";
	} elsif (&TestLang("Es",$QueryLang, $Host, $Lang, $ScriptName)) {
		$LangVisitor = "Es";
	} else {
		$LangVisitor = "En";

	}
	open(COM,"<$AdvertExLogFile") || ! -e $LogFile || &InitLogFileExit($AdvertLogFile,1);
	flock(COM, 2);
	@FileAdvertExLog = <COM>;
	flock(COM, 8);

	open(COM,"<$AdvertClLogFile");
	flock(COM, 2);
	@FileAdvertClLog = <COM>;
	flock(COM, 8);

	open(FILE,"$AdvertDataFile") ||  die "Cannot Open Data Advert File: $AdvertDataFile, Error: $!\n";
	@FileAdvert = <FILE>;
	close(FILE);
	$i = 1;
	foreach  $AdvertLine (@FileAdvert) {
		($Name, $Comment, $GuestLogin, $GuestPassword, $States, $Ratio, $DateBegin, $DateEnd, $MaxHits, $MaxClicks, $Lang, $LgAndKw, $Keyword, $OS, $AdvertTxt) = split (/ *\t *|\n/, $AdvertLine);
		($NbExpose) = split(/\t|\n/, $FileAdvertExLog[$i]);
		($NbClicks) = split(/\t|\n/, $FileAdvertClLog[$i]);
		if ($States && ($NbExpose <= $MaxHits) && ($NbClicks <= $MaxClicks) && ($JToday <= &Str2Jday($DateEnd)) && &GoodOS($OS, $OSVisitor) && (($Lang =~ /$LangVisitor/i) || ($Lang =~ /All/i))) {
			if (! $LgAndKw) { $GoodAdvert .= "$i\n" x $Ratio ;}
			if (&GoodKeyword($Keyword, $QueryKeyword)) {
				$GoodAdvertKey .= "$i\n" x $Ratio;
			}
		}
		$i++;
	}
	$cnt = @GoodAdvert = split(/\n/, $GoodAdvert);
	$cntK = @GoodAdvertKey = split(/\n/,$GoodAdvertKey);

	if ($cntK > 0) {
		@GoodAdvert = @GoodAdvertKey;
		$cnt = $cntK;
	}
	srand($time);
	$No = $GoodAdvert[int rand $cnt];

	$AdvertLine = $FileAdvert[$No -1];
	($Name, $Comment, $GuestLogin, $GuestPassword, $States, $Ratio, $DataBegin, $DateEnd, $MaxHits, $MaxClicks, $Lang, $LgAndKw, $Keyword, $OS, $AdvertTxt) = split (/ *\t *|\n/, $AdvertLine);
	$AdvertTxt =~ s/\\n/\n/g;
	$AdvertTxt =~ s/Value_Adverts/$No/g;
	$Random1000 = int rand 1000;
	$Random100 = int rand 100;
	$Random10 = int rand 10;
	$AdvertTxt =~ s/Value_1000Random/$Random1000/g;
	$AdvertTxt =~ s/Value_100Random/$Random100/g;
	$AdvertTxt =~ s/Value_10Random/$Random10/g;
	
	if ($AdvertTxt =~ /%%Other%%/i) {
		$cnt = @adv = split(/%%Other%%/i, $AdvertTxt);
		$AdvertTxt = $adv[int rand $cnt];
	}

	&IncLog($AdvertExLogFile, $No);
	$AdvertTxt =~ s/\n+//g;
	return $AdvertTxt;
}

sub TestLang {
	my($Lg,$QueryLang, $Host, $Lang, $ScriptName) = @_;
		return (($QueryLang =~ /$Lg/i) || ($Host =~ /$Lg/i) || ($Lang =~ /$Lg/i) || ($ScriptName =~ /-$Lg/i));
}
#Test keywords args
sub GoodKeyword {
	my($Keyword, $QueryKeyword) = @_;
	my($key, @TabKeyword);
	$Keyword =~ s/[^\w\d]+/ /g;
	@TabKeyword = split(/ /, $Keyword);
	foreach $key (@TabKeyword) {
		if (($key =~ /^\d\d*$/) && ($key eq $QueryKeyword)) {
			return 1;
		}
		if (($key !~ /^\d\d*$/) && ($key =~ /$QueryKeyword/i)) {
			return 1;
		}
	}
	return 0;
}

sub GoodOS {
	my($OS, $OSVisitor) = @_;
	if ((! $OS) || ($OS eq $OSVisitor)) { return 1; }
	return 0;
}

#Add 1 to a the Log File of Adverts ($NoLine)
sub IncLog {
	my($AdvertLogFile, $NoLine) = @_;
	my($UseLog, $line, $CntTotal, $CntDay, @FileLog);

	open(COM,"+<$AdvertLogFile") || ! -e $LogFile || &InitLogFileExit($AdvertLogFile,1);
	flock(COM, 2);
	@FileLog = <COM>;
	seek(COM,0,0);
	$line = $FileLog[0];
	$line =~ s/\t(\d+)\n//;
	$today = $1;
	if ($JToday ne $today) {
		$FileLog[0] = "WWWAdverts\t$JToday\n";
		foreach (@FileLog) {
			$_ =~ s/(\d+)\t\d+/$1\t0/;
		}
	}
	$line = $FileLog[$NoLine];
	if ($line eq "\n") { $line = "1\t1" }
	$line =~ s/\n//;
	($CntTotal, $CntDay) = split(/\t/, $line);
	$CntTotal++;
	$CntDay++;
	$FileLog[$NoLine] = "$CntTotal\t$CntDay\n";
	print COM @FileLog;
	close(COM);
	flock(COM, 8);
}

sub InitLogFileExit {
	($LogFile, $exit) = @_;
	open(COM, ">$LogFile") || print "Cannot Write Log File: $LogFile, Error: $!\n";
	flock(COM, 2);
	print COM ("WWWAdverts\t$JToday\n", "0\t0\n" x 25);
	close(COM);
	flock(COM, 8);
	if ($exit) { exit; }
}

# Julian day sub runtine
sub Str2Jday {
	my($m,$d,$y);
	($d, $m, $y) = split (/[^\d]/, $_[0]);
	return &jday($m, $d, $y);
}

sub jday
# Usage:  $julian_day = &jday($month,$day,$year)
{
	my($m,$d,$y) = @_;
	my($ya,$c,$brit_jd);
	$brit_jd = 2361222;

	$y = (localtime(time))[5] + 1900  if ($y eq '');

	if ($m > 2) { $m -= 3; } else { $m += 9; --$y; }
	$c = int($y/100);
	$ya = $y - (100 * $c);
	return  int((146097 * $c) / 4) + int((1461 * $ya) / 4) + int((153 * $m + 2) / 5) + $d + 1721119;
}

1;