#!/usr/local/bin/perl
#-----------------------------------------------------------------------

use CGI/standard/;
require "confstats.pl";
require "sportstats.pl";

$q = new CGI;
print "Content-type: text/html\n\n";

$frame  = 1;

   $ShowTeams = 1;
   $ShowScore = 1;
   $ShowScoreRange = 1;
   $ShowTotalScore = 1;
   $ShowPlace = 1;
   $ShowOdds = 1;

if (
      $ShowLeague || $ShowLeague2 || $ShowTeams ||
      $ShowWon || $ShowLost || $ShowTie || $ShowFavorite ||
      $ShowUnderdog || $ShowLine || $ShowLineRange ||
      $ShowScore || $ShowScoreRange || $ShowTeamPitcher ||
      $ShowHand
   )
{ $ShowTeamSpecific = 1; }

if (
      $ShowPitcher || $ShowWeekDays || $ShowDayTime ||
      $ShowGameDate || $ShowGameTime || $ShowTotalScore ||
      $ShowTotal
   )
{ $ShowGameSpecific = 1; }


if ($frame) 
{
print <<START_HTML;
<html>
  <head>
     <title>Power MLB Search</title>
     <link rel="stylesheet" type="text/css" href="${htm_dir}ssstats.css">
  </head>
<body>
START_HTML
}
if ($fragmented)
{
   # BeforeFragment();
}
if ($header)
{
   # ShowHeader();
}

$dim = scalar(@MLBListOfYears);

print <<BODY_START;
<script>
   function RecalcSeasons()
   {
      frm = document.gamesearch;
      ind = false;
      for (i=0;i<${dim};i++)
      {
         if (frm.elements["Year"+i].checked)
         {
            ind = true;
         }
      }
      if (ind)
      {
         frm.elements["AllYears"].checked = false;
      }
      else
      {
         frm.elements["AllYears"].checked = true;
      }
   }
</script>
<div align="$Alignment">
<form method="GET" action="superstats.pl" name="gamesearch">
<input type="hidden" name="Sport" value="mlb">
<table $TableWidth cellspacing="$CellSpacing" class="ResultTable">
  <col width="25%">
  <col width="25%">
  <col width="25%">
  <col width="25%">
  <tr>
    <td colspan="4" class="SubHead">
      <input type="image" src="${htm_dir}images/go.gif"
        ALT="GO!" BORDER="0" width="26" height="15"> 
      <font size="2">
        <strong>
          Click GO to start search
        </strong>
      </font>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Max games to show&nbsp;&nbsp;&nbsp;
      <select name="MaxGames" size="1" style="font-family: arial, tahoma, verdana, sans-serif, helvetica; font-size: 8pt">
        <option value="100" selected>100</option>
        <option value="500">500</option>
        <option value="1000">1000</option>
        <option value="5000">5000</option>
      </select> 
    </td>
  </tr>
  <tr>
    <td  colspan="4" class="Title"><font color=red>ENTER SEARCH CRITERIA</font></td>
  </tr>
BODY_START
print <<SHOW_SEASONS_1;
  <tr>
    <td  colspan="4" class="ResultBottomCell">Seasons</td>
  </tr>
  <tr>
    <td  class="Element" colspan="4">
      <input type="checkbox" name="AllYears" value="1" onClick="RecalcSeasons();" checked> All Seasons 
SHOW_SEASONS_1
print "<img border=\"0\" src=\"${htm_dir}images/wpe7.jpg\">";

for($i=0;$i<@MLBListOfYears;$i++)
{
   print "<input type=\"checkbox\" name=\"Year$i\" value=\"1\" onClick=\"RecalcSeasons();\">".$MLBListOfYears[$i];
   print "<img border=\"0\" src=\"${htm_dir}images/wpe7.jpg\">\n";
}

print <<SHOW_SEASONS_2;
    </td>
  </tr>
SHOW_SEASONS_2

if ($ShowTeamSpecific)
{
print <<BODY22;
  <tr>
    <td  colspan="4" class="ResultBottomCell">Team specific data</td>
  </tr>
BODY22
}

if ($ShowTeamSpecific)
{
print <<BODY_AH;
  <tr>
    <td  colspan="2" class="Title">Away</td>
    <td  colspan="2" class="Title">Home</td>
  </tr>
BODY_AH
}

if ($ShowTeams)
{
   print <<BODY_TEAM_1;
  <tr>
    <td  colspan="2" class="Element">
      <select name="VisitorTeamID" size="5" multiple>
          <option value="0" selected>Any Team
BODY_TEAM_1
   $team_select = get_teams_select("${basedir}mlb_teams.txt");
   print $team_select;
   print <<BODY_TEAM_2;
        </select>&nbsp;&nbsp;
            <input type="checkbox" name="HomeOrAway" value="1">
             &nbsp;<b>& vice versa</b>
    </td>
    <td  colspan="2" class="Element">
      <select name="HomeTeamID" size="5" multiple>
          <option value="0" selected>Any Team
BODY_TEAM_2
   print $team_select;
   print <<BODY_TEAM_3;
        </select>
    </td>
  </tr>
BODY_TEAM_3
}
if ($ShowScore) { show_score("Title","Element"); }
if ($ShowScoreRange) { show_score_range("Title","Element"); }
if ($ShowGameSpecific)
{
print <<BODY31;
  <tr>
    <td  colspan="4" class="ResultBottomCell">Game specific data</td>
  </tr>
</table>
BODY31
}
print <<BODY32;
<table $TableWidth cellspacing="$CellSpacing" class="ResultTable">
  <col width="12%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
  <col width="11%">
BODY32
print <<BODY4;
</table>
<table $TableWidth cellspacing="$CellSpacing" class="ResultTable">
  <col width="25%">
  <col width="20%">
  <col width="65%">
  <tr>
    <td  colspan="3" class="SubHead">SELECT STATS TO SHOW</td>
  </tr>
  <tr>
    <td  class="Element">Games
       <input type="checkbox" name="StatsGames" value="1" checked>
    </td>
    <td  class="Element">Teams Stats
       <input type="checkbox" name="StatsTeams" value="1" checked>
    </td>
    <td  class="Element">Pitcher Stats
       <input type="checkbox" name="StatsPitchers" value="1">
    </td>
  </tr>
  <tr>
    <td  colspan="3" class="Title"><font color=red>DEFINE STATS TITLE ROWS,COLUMNS AND DATA</font></td>
  </tr>
  <tr>
    <td  colspan="3" class="ResultBottomCell">Stats Title Columns and SubColumns</td>
  </tr>
BODY4
my ($Select0,$Select1,$Select2,$Select3);
$level = 1;
if ($ShowPlace)
{
   set_selected($level);
   $level++;
   print <<SHOW_PLACE;
  <tr>
    <td  class="Title">Away-Home</td>
    <td  class="Element">title row&nbsp;&nbsp;
      <select name="place" size="1" style="font-family: arial, tahoma, verdana, sans-serif, helvetica; font-size: 8pt">
        <option value="0" $Selected0>None</option>
        <option value="1" $Selected1>1</option>
        <option value="2" $Selected2>2</option>
        <option value="3" $Selected3>3</option>
      </select>
    </td>
    <td>
      <input type="checkbox" name="place_a" value="1" checked>Away
      <input type="checkbox" name="place_h" value="1" checked>Home
      <input type="checkbox" name="place_c" value="1" checked>Combined
    </td>
  </tr>
SHOW_PLACE
}
if ($ShowOdds)
{
   set_selected($level);
   $level++;
   print <<SHOW_ODDS;
  <tr>
    <td  class="Title">Favorite - Underdog</td>
    <td  class="Element2">title row&nbsp;&nbsp;
      <select name="odds" size="1" style="font-family: arial, tahoma, verdana, sans-serif, helvetica; font-size: 8pt">
        <option value="0" $Selected0>None</option>
        <option value="1" $Selected1>1</option>
        <option value="2" $Selected2>2</option>
        <option value="3" $Selected3>3</option>
      </select>
    </td>
    <td>
      <input type="checkbox" name="odds_f" value="1" checked>Favorite
      <input type="checkbox" name="odds_d" value="1" checked>Underdog
      <input type="checkbox" name="odds_c" value="1" checked>Combined
    </td>
  </tr>
SHOW_ODDS
}
print <<STATS_DATA;
  <tr>
    <td  colspan="3" class="ResultBottomCell">Stats Data (if Teams or Pitcher Stats)</td>
  </tr>
  <tr>
    <td  class="Title">Show</td>
    <td  colspan="2" class="Element2">
      in <input type="radio" name="Show" value="R">Rows
      <input type="radio" name="Show" value="C" checked>Columns
    </td>
  </tr>
STATS_DATA
$i = 1;
show_data($i,"Element","WLT"); $i++;
show_data($i,"Element","PCT"); $i++;

print <<BODY5;
</table>
<table $TableWidth cellspacing="$CellSpacing" class="ResultTable">
  <col width="25%">
  <col width="25%">
  <col width="25%">
  <col width="25%">
  <tr>
    <td colspan="3" class="SubHead">
      <input type="submit" value="Show me data"></td>
    <td class="SubHead"><input type="reset" value="Reset"></td>
  </tr>
</table>
<input type="hidden" name="Sport" value="1">
</form>
</div>
BODY5
# ShowFooter();
if ($frame)
{
   print <<END_HTML;
</body>
</html>
END_HTML
}
if ($fragmented)
{
   # AfterFragment();
}

#-----------------------------------------------------------------------
# EOF
