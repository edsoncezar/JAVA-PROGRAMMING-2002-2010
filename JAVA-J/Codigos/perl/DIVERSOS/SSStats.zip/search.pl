#!/usr/local/bin/perl
#-----------------------------------------------------------------------

#-----------------------------------------------------------------------
sub teams_are_in_selection
{
   my ($away_id,$home_id) = @_;
   my $tmp;
   $away_in_selection = 0;
   if ($NotVisitorTeamID1) { $away_in_selection = 1; }
   else
   {
      foreach $tmp (@SearchVisitorID1)
      {
         if ($away_id == $tmp) { $away_in_selection = 1; last; }
      }
   }
   $home_in_selection = 0;
   if ($NotHomeTeamID1) { $home_in_selection = 1; }
   else
   {
      foreach $tmp (@SearchHomeID1)
      {
         if ($home_id == $tmp) { $home_in_selection = 1; last; }
      }
   }
   if ($away_in_selection && $home_in_selection) { return(1); }

   $away_in_selection = 0;
   if ($NotVisitorTeamID2) 
   { 
      $away_in_selection = 1; 
   }
   else
   {
      foreach $tmp (@SearchVisitorID2)
      {
         if ($away_id == $tmp) { $away_in_selection = 1; last; }
      }
   }
   $home_in_selection = 0;
   if ($NotHomeTeamID2) { $home_in_selection = 1; }
   else
   {
      foreach $tmp (@SearchHomeID2)
      {
         if ($home_id == $tmp) { $home_in_selection = 1; last; }
      }
   }
   if ($away_in_selection && $home_in_selection) { return(1); }
   return(0);
}

1;

#-----------------------------------------------------------------------
#   EOF
