#!/usr/local/bin/perl
#-----------------------------------------------------------------------

$cgi_dir = "/cgi-mimtech/sport/free/";
$htm_dir = "/sport/";
$img_dir = "/sport/images/";
$basedir = "/home/mimtech/cgi-mimtech/sport/";

$Alignment   = "center";
$TableWidth  = "width=\"570\"";
$CellSpacing = 1;

@MLBListOfYears = (2001);
@MLBEDate  = ("9/30/2001");
@MLBSDate  = ("4/1/2001");

$name_width = 200;
$cell_width = 70;

#-----------------------------------------------------------------------
# EOF
