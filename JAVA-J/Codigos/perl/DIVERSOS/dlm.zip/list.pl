#!/usr/bin/perl
require "echelon.pl";
print "<html><heaD><title>Echelon Download Manager V.5</title></head><body>";
if(!-d "Data/"){
mkdir "Data/";
}
if($file){
$nfile="Data/".$file.".ech";
open(file,$nfile);
$dls=<file>;
close(file);
$dls++;
open(file,">$nfile");
print file $dls;
close(file);
$nnfile=$nfile.".log";
open(file,">>$nnfile");
print file $ENV{REMOTE_ADDR}."|".time."\n";
close(file);
print qq~<meta http-equiv="refresh" content="3 url=$file"><font color=green>Download will begin shortly, or click <a href="$file"><font color=black>Here</font></a>~;
}

@files=od(".");
$count=1;
print "<table>";
$sn=0;
$ns=0;
$sdl=0;
$cn=0;
if($sort eq "name" && $down != 1){
$ns=1;
}elsif(!$sort && $down != 1){
$cn=1;
}elsif($sort eq "size" && $down != 1){
$sn=1;
}elsif($sort eq "dl" && $down != 1){
$sdl=1;
}
print "<Tr>
<Td>
<a href=\"list.pl?down=$cn\">
<font color=black>#</font>
</a>
</td>
<Td>
<b>
<a href=\"list.pl?sort=name&down=$ns\">
<font color=black>Name</font>
</b>
</td>
<td>
<i>
<a href=\"list.pl?sort=name&down=$ns\">
<font color=black>Filename</font>
</a>
</i>
</td>
<TD>
<a href=\"list.pl?sort=size&down=$sn\"><font color=black>Size</font>
</td><td><a href=\"list.pl?sort=dl&down=$sdl\"><font color=black>Downloads</font></td></tR>";
foreach(@files){
if($_ ne "." && $_ ne ".." && $_ ne "list.pl" && $_ ne "echelon.pl" && -f $_){

($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
       $atime,$mtime,$ctime,$blksize,$blocks)
           = stat($_);  
$osize=$size;

$file="Data/"."$_".".ech";
open(file,$file);
$dls=<file>;
close(file);
$er=$_;
$er=~s/(.*)\..*/$1/;
if($sort eq "name"){
$addinto="$er|$count|$_|$osize|$dls";
}elsif(!$sort){
$addinto="$count|$er|$_|$osize|$dls";
}elsif($sort eq "size"){
$addinto="$osize|$er|$_|$count|$dls";
}elsif($sort eq "dl"){
$addinto="$dls|$er|$_|$osize|$count";
}
push(@all,$addinto);

#print "<Tr><td>$count</td><Td><b>$er</b></td><td><a href=\"list.pl?file=$_\"><font color=black><i>$_</i></font></a></td><td>$size $format</td><td>$dls</td></tR>";
$count++;
}
}

if($down != 1){
if($sort eq "size" || $sort eq "dl" || !$sort){
@list=sort{$a <=> $b} @all;
}else{
@list=sort{lc($a) cmp lc($b)}@all;
}
}else{
if($sort eq "size" || $sort eq "dl" || !$sort){
@list=sort{$b <=> $a} @all;
}else{
@list=sort{lc($b) cmp lc($a)}@all;
}
}
foreach(@list){
if($sort eq "name"){
($er,$count,$fn,$size,$dls)=split(/\|/,$_);
}elsif(!$sort){
($count,$er,$fn,$size,$dls)=split(/\|/,$_);
}elsif($sort eq "size"){
($size,$er,$fn,$count,$dls)=split(/\|/,$_);
}elsif($sort eq "dl"){
($dls,$er,$fn,$size,$count)=split(/\|/,$_);
}
$size=$size/1024;
if($size > 1000){
$size=$size/1024;
$format="Mb";
$size=~ s/(\d*\.\d\d)\d*/$1/;
}else{
$format="Kb";
$size=~ s/(\d*)\.\d*/$1/;
}
print "<Tr><td>$count</td><Td><b>$er</b></td><td><a href=\"list.pl?file=$fn\"><font color=black><i>$fn</i></font></a></td><td>$size $format</td><td>$dls</td></tR>";

}
