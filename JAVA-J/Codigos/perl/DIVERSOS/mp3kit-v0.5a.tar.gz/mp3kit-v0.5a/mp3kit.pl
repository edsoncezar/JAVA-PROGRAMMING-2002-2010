#!/usr/bin/perl -w
#--MP3Kit 0.5a >> ViVa LiNuX!!!
#----------------------------------------
# Copyright (C) 2001 Ryan Mackay
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#-----------------------------------------
use MP3::Info;		# Reads MP3 information
use File::Recurse;		# Recursive directories
use File::Basename;	# OS specific file handling
use strict;


#-------------------------------------
# You will need to configure this area.
#-------------------------------------
my $VERSION = "0.5a";		# Version number
my $SAYING  = "ViVa LiNuX!!!";	# Smart ass saying
my $MP3DIR  = "/path/to/mp3s";	# Base of MP3 directory
my $QUIET   = 0;		# Turn off/on text
my $SPACE   = "\t";		# Plain text field seperator
my %HTMLOPT = (			# HTML output options
	"BACKGROUND" => "#666666",			# Background color
	"TITLE"      => "MP3 Listing of [$MP3DIR]",	# Page title
	"FONTFACE"   => "Verdana,Arial",		# Font to use
	"FONTCOLOR"  => "#FFFFFF",			# Main font color
	"FONTCOLOR2" => "#FF9900",			# Directory font color
	"FONTSIZE"   => "2",				# Main font size
	"TBLCOLOR1"  => "#FF9900",			# Header table cell color
	"TBLCOLOR2"  => "#666666",			# Odd table cell color
	"TBLCOLOR3"  => "#585858");			# Even table cell color
#-------------------------------------
# Finished with configuration.
#-------------------------------------

$QUIET = 1 if (defined $ARGV[0] && $ARGV[0] =~ /q/);	# Check for quiet
&norm_print("MP3Kit $VERSION >> $SAYING\n");
&norm_print("=============================\n");	

my $result = &do_checks;				# Check stuff needed by the program
&stat_print("Running misc checks",$result);

my %output;
($output{SORT},$output{TYPE},$result) = &parse_args;	# Get the user arguments
&stat_print("Parsing arguments",$result);

my @mp3_files = &recurse($MP3DIR);			# Recurse for MP3 files
errmssg("0 MP3 files were found.") if ($#mp3_files <= 0);
&stat_print("Recursing MP3 dir",$#mp3_files);

@mp3_files = sort by_name @mp3_files if ($output{SORT} == 1);	# Sort the list if needed
@mp3_files = reverse sort by_name @mp3_files if ($output{SORT} == 2);
&stat_print("Sorting MP3 list",1) if ($output{SORT});

my %group_info = &group_info(@mp3_files);		# Get group information
&stat_print("Group information",1);

$_      = $group_info{TOTAL};				# Now, make the type of output
my $bad = $group_info{BAD};
%group_info = &convert_hms($group_info{MINS},$group_info{SECS},$group_info{SIZE});
$group_info{TOTAL} = $_;
$group_info{BAD}   = $bad;
&stat_print("Converting times",1);


&mp32html if ($output{TYPE} eq "m");		# MP32HTML
&plain_text if ($output{TYPE} eq "p");		# Plain text file output
&make_html if ($output{TYPE} eq "h");		# HTML output
&to_stdout if ($output{TYPE} eq "Q");		# Stats to STDOUT

#-------------------------------------
# The following few subroutines are the ones
# that generate the output, after that the rest
# are just general shit.
#-------------------------------------

#-------------------------------------
# MP32HTML output sub, see the README file
# included in the package for more information
#-------------------------------------
sub mp32html {
	chomp(my $date = `date +%d/%m/%y`);
	chomp(my $date2 = `date +%d%m%y`);
	open(OUT,">$date2.dat") || errmssg("Couldnt write $date.dat, $!");
	print OUT "$date|$group_info{TOTAL}|$group_info{SIZE}|$group_info{LENGTH}\n";
	foreach (@mp3_files) {
		next if (!defined $_);		  # Skip if bad MP3--#
		my $info = get_mp3info($_);
		$_ = basename($_);		  # Remove the path
		$_ =~ s/,/-/g; 			  # Remove comma's
		print OUT "$_,$info->{TIME},$info->{BITRATE},$info->{SIZE}\n";
	}
	close(OUT);
}

#-------------------------------------
# Plain text file output
#-------------------------------------
sub plain_text {
	open(OUT,">mp3_listing.txt") || errmssg("Couldnt write mp3_listing.txt, $!");
	print OUT "$group_info{TOTAL} MP3's totaling $group_info{HOURS} hours $group_info{MINS} minites and $group_info{SECS} seconds.\n";
	print OUT "$group_info{SIZE} MB total size\n";
	print OUT "$group_info{BAD} files(s) were unscanned.\n" if ($group_info{BAD} > 0);
	print OUT "Format is <TITLE> <LENGTH> <BITRATE> <SIZE>\n";
	print OUT "\n";
	foreach (@mp3_files) {
		next if (!defined $_);		# Skip if bad MP3
		my $info = get_mp3info($_);
		$_ = basename($_);		# Remove the path
		print OUT "$_${SPACE}$info->{TIME}${SPACE}$info->{BITRATE}${SPACE}$info->{SIZE}\n";
	}
	close(OUT);
}

#-------------------------------------
# Output to STDOUT, works with $QUIET on
#-------------------------------------
sub to_stdout {
	print "\n[$MP3DIR] || MP3 Statistics\n";
	print "$group_info{TOTAL} MP3's totaling $group_info{SIZE} Megabytes,\n";
	print "$group_info{HOURS} hours $group_info{MINS} minutes $group_info{SECS} seconds total playtime.\n";
	print "\n$group_info{BAD} file(s) were unscanned.\n" if ($group_info{BAD} > 0);
}


#-------------------------------------
# HTML Output, the big boys toys
#-------------------------------------
sub make_html {
	my $font = "<font face=\"$HTMLOPT{FONTFACE}\" size=\"$HTMLOPT{FONTSIZE}\" color=\"$HTMLOPT{FONTCOLOR}\">";
	open(OUT,">my_mp3s.html") || errmssg("Couldnt write my_mp3s.html, $!");
	print OUT <<END;
	<html>
	<title>$HTMLOPT{TITLE}</title>
	<body bgcolor="$HTMLOPT{BACKGROUND}" text="$HTMLOPT{FONTCOLOR}">
	<h2><b><font face="$HTMLOPT{FONTFACE}">MP3 Listing of <font color="$HTMLOPT{FONTCOLOR2}">$MP3DIR</b></h2>
	$font<p><b>Total MP3's: $group_info{TOTAL}<br>Total Length: $group_info{LENGTH}<br>
	Total Size: $group_info{SIZE} MB</p>
END
	print OUT "<p><b>$font $group_info{BAD} File(s) of unknown length</p>\n" if ($group_info{BAD} > 0);
	print OUT <<END;
	<table border="0" width="100%">
	<tr>
	<td width="73%" bgcolor="$HTMLOPT{TBLCOLOR1}">$font<b>&nbsp;Filename</b></td>
	<td width="8%" bgcolor="$HTMLOPT{TBLCOLOR1}">$font<b>&nbsp;Length</b></td>
	<td width="6%" bgcolor="$HTMLOPT{TBLCOLOR1}">$font<b>&nbsp;KBPS</b></td>
	<td width="13%" bgcolor="$HTMLOPT{TBLCOLOR1}">$font<b>&nbsp;Size</b></td>
	</tr>
END
	my $cell_color = 1;			  # Makes the cells "multi-colored"
	foreach (@mp3_files) {
		next if (!defined $_);		  # Skip if bad MP3
		my $info = get_mp3info($_);
		$_ = basename($_);		  # Remove the path
		if ($cell_color == 1) {
			$cell_color = 0;
			print OUT <<END;
	<tr>
	<td width="73%" bgcolor="$HTMLOPT{TBLCOLOR2}">$font$_</td>
	<td width="8%" bgcolor="$HTMLOPT{TBLCOLOR2}">$font$info->{TIME}</td>
	<td width="6%" bgcolor="$HTMLOPT{TBLCOLOR2}">$font$info->{BITRATE}</td>
	<td width="13%" bgcolor="$HTMLOPT{TBLCOLOR2}">$font$info->{SIZE}</td>
	</tr>
END
		} else {
			$cell_color = 1;
			print OUT <<END;
	<tr>
	<td width="73%" bgcolor="$HTMLOPT{TBLCOLOR3}">$font$_</td>
	<td width="8%" bgcolor="$HTMLOPT{TBLCOLOR3}">$font$info->{TIME}</td>
	<td width="6%" bgcolor="$HTMLOPT{TBLCOLOR3}">$font$info->{BITRATE}</td>
	<td width="13%" bgcolor="$HTMLOPT{TBLCOLOR3}">$font$info->{SIZE}</td>
	</tr>
END
		}
	}
	print OUT "</table></body>\n</html>";
	close(OUT);
}

#-------------------------------------
# End of output subroutines, what follows
# is like the fuel thhat powers the subs
# that you see above.
#-------------------------------------


#-------------------------------------
# Converts HMS to H:M:S (badly put)
#-------------------------------------
sub convert_hms {
	my %group_info;
	my $secs = $_[1] % 60;				# Remaining S
	my $sec_min = int($_[1] / 60);			# Total M from S
	my $min_hrs = $_[0] + $sec_min;			# Total M from S+M
	my $mins = $min_hrs % 60;			# Remaining M from H/60
	my $hours = int($min_hrs / 60);			# Total M from H/60
	$group_info{SIZE} = sprintf("%.2f",$_[2]);	# Bytes to 2 decimal places
	$group_info{HOURS} = $hours;
	$group_info{MINS}  = $mins;
	$group_info{SECS}  = $secs;
	$group_info{LENGTH} = "$hours:$mins:$secs";	# Total length as a string
	return(%group_info);
}

#-------------------------------------
# Gets total information on MP3's combined
#-------------------------------------
sub group_info {
	my %group_info;
	$group_info{BAD} = 0;						# Define it early
	$group_info{TOTAL} = 0;
	$_ = 0;
	foreach (@mp3_files) {
		my $info = get_mp3info($_);
		if (defined $info->{SS} && defined $info->{MM}) {	# If the MP3 is in good condition
			$group_info{MINS} += $info->{MM};		# Count total minutes
			$group_info{SECS} += $info->{SS};		# Count total seconds
			$group_info{SIZE} += ($info->{SIZE} / 1048576);	# Count total size
			$group_info{TOTAL}++;				# Count total goood MP3's
		} else {
			$group_info{BAD}++;
			undef($_);					# Remove MP3 from future scans
		}
	}
	$group_info{BAD}--;
	return(%group_info);
}

#-------------------------------------
# Sort the list alphabeticaly
#-------------------------------------
sub by_name {
	$a =~ /.*\/(.*)\.mp3/i; my $mp3_1 = $1;	# Removes path
	$b =~ /.*\/(.*)\.mp3/i; my $mp3_2 = $1;	# "          "
	"\L$mp3_1" cmp "\L$mp3_2";
}


#-------------------------------------
# Get the MP3 files past $MP3DIR
#-------------------------------------
sub recurse {
	my $MP3DIR = shift;
	my %files = Recurse([$MP3DIR], {match => '\.mp3$'});
	my @files;
	my $current_dir;
	foreach (sort keys %files) {
		$current_dir = $_;
		push(@files,"$current_dir/$_") foreach (@{ $files{$_} });
	}
	@files >= 0 ? push(@files,1) : push(@files,0);
	return(@files);
}


#-------------------------------------
# Parse the arguments given
#-------------------------------------
sub parse_args {
	my(@options,@output);
	@options = split(//,$ARGV[0]);	# Seperate each character
	shift @options;			# Removes the "-" at the start
	$output[0] = 0;			# Sort is OFF
	foreach (@options) {
		$output[0] = 1 if ($_ eq "a");		# Normal sort
		$output[0] = 2 if ($_ eq "A");		# Reverse sort
		$output[1] = $_ if ($_ =~ /[pmhQ]/);	# Output type
	}
	$output[2] = 1;
	$output[2] = 0 if (defined $output[1] && $output[1] !~ /[pmhQ]/);
	return(@output);
}

#-------------------------------------
# Perform these checks before starting
#-------------------------------------
sub do_checks {
	if (@ARGV <= 0 || $ARGV[0] !~ /^-\w+$/) {
		&errmssg("MP3Kit requires atleast one argument");
	}
	if ($ARGV[0] !~ /^-[AVQapmhq]+$/) {
		&errmssg("$ARGV[0] is not a valid argument");
	}
	if ($ARGV[0] =~ /V/) {		# Does version information
		&version_info;
	}
	if (defined $ARGV[1]) {		# If directory specified as argument
		$MP3DIR = $ARGV[1];
	}	
	if (!defined $MP3DIR || $MP3DIR eq "") {
		&errmssg("MP3 Directory was not defined in config");
	}
	if (!-d $MP3DIR) {
		&errmssg("$MP3DIR does not exist or is not a directory");
	}
	return 1;	# All is good
}

#------------------------------------
# Version/program information
#------------------------------------
sub version_info {
print "MP3Kit $VERSION >> $SAYING\n" if ($QUIET);
print "=============================\n" if ($QUIET);
print <<END;
This program is released under the terms of the GNU General Public License.
see COPYING for more information.

Written by rinmak, please report bugs to <slickster_42\@hotmail.com>
HTTP: http://home.iprimus.com.au/rinmak

MP3Kit $VERSION is a suite of utilities for making reports on a
group of MP3 files, formats include HTML, MP32HTML & plain text.
END
exit;
}

#-------------------------------------
# Print a status message for each stage
#-------------------------------------
sub stat_print {
	exit if (!$_[1] && $QUIET);	# Exit if failed, no messages
	print "$_[0]..." if (!$QUIET);
	if ($_[1] && !$QUIET) {
		print "ok\n";		# If the subroutine worked
	} elsif (!$_[1] && !$QUIET) {
		print "FAILED\n";
		exit;
	}
}

#-------------------------------------
# Used to print only if not quiet
#-------------------------------------
sub norm_print {
	print "$_[0]" if (!$QUIET);
}


#-------------------------------------
# Prints a fatal error & exits
#
# I know i could have just use die each time
# but i only found out about using \n with
# die to not get the other part after i had
# used errmssg in the program (very lazy)
#-------------------------------------
sub errmssg {
	die "\nERROR> $_[0]\n";
}
