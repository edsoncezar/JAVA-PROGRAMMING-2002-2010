#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_cow.pl";

umask (0111);

print "Content-type: text/html\n\n";

open(tfile, "<$server_path$c_cowtemplate");
@cowtemplate =<tfile>;
close(tfile);

&parse_query;
if ($QUERY{'week'}) {
	$curweek=$QUERY{'week'};
	$specified=1;
}

&get_date;
$curtimecode = &calculatetimecode($y,$m,$month_day);

$archivelinks = "";

&read_data_file;

$maxweek = 0;
for ($count=0;$count<=($c_weeks_total-1);$count++) {
	if ($c_weeks[$count][0] <= $curtimecode) {
		$maxweek = $maxweek + 1;
		$maxhowmany = $c_weeks[$count][4];
		if ($archivelinks) {
			$archivelinks.= " - ";
		}
		$archivelinks.="<a href=\"$server_url$c_script_url?week=".($count+1)."\">Week&nbsp;".($count+1)."</a>";
	}
}

if ($specified ne "1") {
	$curweek=$maxweek;
}

&ext_header;

if (($curweek>0) && ($curweek<=$maxweek)) {
	print "<p align=center><font face=\"$font_type\" size=\"2\"><b>Week: ".$curweek."/".$maxweek."</b></font></p>";
	print "<table width=\"100%\" border=0><tr>\n";
	print "<td width=\"50%\"><font face=\"$font_type\" size=\"2\">\n";
	if ($curweek > 1) {
		print "<a href=\"$server_url$c_script_url?week=".($curweek-1)."\"><< Previous Week</a>\n";
	}
	print "</font></td>\n";
	print "<td width=\"50%\" align=\"right\"><font face=\"$font_type\" size=\"2\">\n";
	if ($curweek < $maxweek) {
		print "<a href=\"$server_url$c_script_url?week=".($curweek+1)."\">Next Week >></a>\n";
	}
	print "</font></td>\n";
	print "</tr></table>\n";
	print "<p align=center>\n";
} else {
	print "<font face=\"$font_type\" size=\"2\"><b>Sorry, this week can not be displayed.</b></font>";
	&ext_footer;
	exit;
}

for ($buildcomic=1;$buildcomic<=$c_weeks[$curweek-1][4];$buildcomic++) {
	$curfilename=$c_files.$curweek."-".$buildcomic.".".$c_extension;
	print "<img src=\"$c_cow_url$curfilename\" alt=\"Comic $curweek, Picture $buildcomic\"> ";
}

# Ok.. so you got this script for free. Can you imagine
# how long it took me to code all that? About 350 kB of
# pure Perl-Code? And you can't say that this script is
# bad. You get all my work completely free,so is it too
# much if I ask you to leave this link in? Please don't
# remove it, so that others can also find out where the
# script is from and help spreading the script. Because
# you know:  The more people use Schlabo's Scripts, the
# more am I motivated to improve it! Thanks!
print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's COW v$c_version</font></a></p>\n";


&ext_footer;


sub parse_query {
	@pairs = split(/&/, $ENV{'QUERY_STRING'});
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$QUERY{$name} = $value;
	}
}

sub read_data_file {
	if (-e "$server_datapath$c_data_file") {
		open(data,"<$server_datapath$c_data_file");
		@tempdata = <data>;
		close(data);
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_timecode,$temp_year,$temp_month,$temp_day,$temp_howmany) = split(/\|/,$temp_data);
			$c_weeks[$count][0] = $temp_timecode;
			$c_weeks[$count][1] = $temp_year;
			$c_weeks[$count][2] = $temp_month;
			$c_weeks[$count][3] = $temp_day;
			$c_weeks[$count][4] = $temp_howmany;
		}
		$c_weeks_total=$max_num;
	} else {
		open(data,">$server_datapath$c_data_file");
		$c_weeks_total = 0;
		$c_weeks[0][0]=0;
		close(data);
	}
}

sub calculatetimecode {
	$ctc = (($_[0] - 2000) * 365) + $_[2];
	if ($_[1]>1) {
		for ($ctc_count=0;$ctc_count<($_[1]-1);$ctc_count++) {
			$ctc = $ctc + $months_days[$ctc_count];
		}
	}
	return($ctc);
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}

sub ext_header {
	# Print the beginning of the document

	foreach $line (@cowtemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		$line =~ s/\[\!curweek\]/$curweek/g;
		$line =~ s/\[\!maxweek\]/$maxweek/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		$line =~ s/\[\!archivelinks\]/$archivelinks/g;
		print "$line";
	}

}

sub ext_footer {
	# Print the footer of the document
	
	$flag = 0;
	foreach $line (@cowtemplate) {
		if($flag) {
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			$line =~ s/\[\!curweek\]/$curweek/g;
			$line =~ s/\[\!maxweek\]/$maxweek/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			$line =~ s/\[\!archivelinks\]/$archivelinks/g;
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
			$flag = 1;
		}
		

	}
}
