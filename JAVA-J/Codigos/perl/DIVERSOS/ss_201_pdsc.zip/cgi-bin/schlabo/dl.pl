#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01b            ##
##         last modified: 10/04/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}
require "config.pl";
require "config_dl.pl";

umask (0111);

$scriptname="dl";

if ($d_check_referer == 0) { $referer_ok = 1; }

if (($d_antileech eq "on") || ($d_check_referer != 0)) {
	$referer_ok = 0;
	if ($ENV{'HTTP_REFERER'}) {
		foreach $referer(@referers) {
    			if ($ENV{'HTTP_REFERER'} =~ m|http://([^/]*)$referer|i) {
				$referer_ok = 1; last;
			}
		}
	} else {
		if ($d_check_referer == 1) { $referer_ok = 1; }
	}
}


if ($referer_ok != 1) {
	open(tfile, "<$server_path$d_dltemplate");
	@dltemplate =<tfile>;
	close(tfile);
	if ($d_antileech eq "on") {	# Log Access
		($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) = (localtime);
		#Y2k fix
		$y = $Year + 1900;
		$m = $Month + 1;
		open(FILE, ">>$server_datapath$d_leech_file");
		print FILE $m."-".$month_day."-".$y." - ".$Hour.":".$Minute.":".$Second." - ".$ENV{'HTTP_REFERER'}."\n";
		close(FILE);
		&ext_header;
		print "<b>The file you want to download doesn't belong to the site you came from! $ENV{'QUERY_STRING'}</b><br><br>\n";
		print "Please email the webmaster of $ENV{'HTTP_REFERER'} and tell him/her not to leech files!<br><br>\n";
		if (($d_leech_alert eq "on") and ($mailprog ne "")) {
			$email_address =~ s/\\\@/\@/g;
			if (($email_address eq "") or ($email_address eq "yourname\@yoursite.com")) {
				print "<i>[Unable to send a mail to the webmaster as no valid email-address has been specified in the general configuration.]</i><br><br>\n";
			} else {
				open (MAIL, "|$mailprog -t") || { print "[Unable to send a mail to the webmaster - Can't open $mailprog!]" };
				print MAIL "From: $email_address\n";
				print MAIL "To: $email_address\n";
				print MAIL "Subject: Schlabo's Scripts - Leech-Alert\n\n";
print MAIL <<EOF;
A user just tried to download a file on your server by following a link from another site. More information:

Query String: $ENV{'QUERY_STRING'}
Referring Page: $ENV{'HTTP_REFERER'}
Date: ${m}-${month_day}-$y
Time: ${Hour}:${Minute}:${Second}

This email was generated automatically by Schlabo's Download.
EOF
				close (MAIL);
			}
		} else {
			print "We would also appreciate it if you send us a mail and inform us about the site that steals our links. Thanks!<br><br>\n";
		}
		print "This file belongs to <a href=\"$siteurl\">$sitetitle</a>, visit them instead.</p><p>&nbsp;</p>\n";
		print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";
		&ext_footer;
		exit;
	}
	&showerror("You are trying to download a file on the $sitetitle-Server from another site. We do not want other sites to steal our bandwidth, so if you want to help us please send a mail to <a href=\"mailto:$email_address\">$email_address</a> and tell us the URL of the site you came from. Thanks!\n");
}

$whichmirror = param('mirror');
if (($whichmirror == 0) || (!param('mirror'))) { $whichmirror = 1 }
$curmirror = 1;

if ($uselocking) { &masterlockopen; }

if (param('get') == 1) {
	$real_alias = param('file');
	if ($d_autoreplace eq "on") {
		$real_alias =~ s/_/\ /g;
	}
	&lockopen (data,"$server_datapath$d_data_file","input");
	@data = <data>;
	&lockclose (data,"$server_datapath$d_data_file");
	if ($uselocking) { &masterlockclose; }
	
	foreach $line (@data) {
		chomp($line);
		($ali,$url,$num) = split(/\|/,$line);
		if ($ali eq $real_alias) {
			if ($curmirror == $whichmirror) {
				print "Location: $url\n\n";
				exit;
			} else {
				$curmirror += 1;
			}
		}
	}
	open(tfile, "<$server_path$d_dltemplate");
	@dltemplate =<tfile>;
	close(tfile);
	&ext_header;
	print "A problem occured - $real_alias was not found in the database. Please try again.</font></p>\n";
	print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";
	&ext_footer;
	exit;
}





open(tfile, "<$server_path$d_dltemplate");
@dltemplate =<tfile>;
close(tfile);
$query=$ENV{'QUERY_STRING'};
if (index($query, "\&") > (-1)) {
	$query_part2 = $query;
	$query_part2 =~ s!^.*(\&)!!;
	$query_part2_length = length($query_part2);
	$query = substr($query,0,length($query)-$query_part2_length-1);
}
if (index($query, "---") > (-1)) {
	($filename, $extension) = split(/---/, $query);
	chomp($filename);
	chomp($extension);
	$fullname = $filename.".".$extension;
} else {
	$fullname = $query;
}

$fullname =~ s/file=//g;

# If no http:// is found, the parameter is an Alias and no URL,
# so replace the "_" with " " if specified in the config-file.
if ((index($fullname, "http://") == (-1)) && (index($fullname, "/") ne "0") && ($d_autoreplace eq "on")) {
	$fullname =~ s/_/\ /g;
}

if (($fullname eq "")) {   # No valid query
	&showerror("Invalid query. If you got to this page from a link of $sitetitle, please contact <a href=\"mailto:$email_address\">$email_address</a> and report which page you came from, on which file you clicked and what URL of this file is. Thanks!\n");
}


if (-e "$server_datapath$d_data_file") {                # Counter

	&lockopen (data,"$server_datapath$d_data_file","input");
	@alldata = <data>;
	&lockclose (data,"$server_datapath$d_data_file");
	
	$found=0;
	$tempcount = 0;
	&lockopen (data,"$server_datapath$d_data_file","output");
	foreach $line (@alldata) {
		chomp($line);
		($ali,$url,$num) = split(/\|/,$line);
		if ((($url eq $fullname) || ($ali eq $fullname)) && ($real_url eq "")) {
			if ($curmirror == $whichmirror) {
				$num += 1;
				$real_url = $url;      # In case an alias was specified, put the real URL into $fullname
				$real_alias = $ali;
				$found = 1;
			} else {
				$curmirror += 1;
			}
			$tempcount += $num;
			print data "$ali|$url|$num\n";
		} else {
			print data "$line\n";
		}
	}
	if (($d_autoadd eq "on") && ($found eq "0")) {
		if (lc($d_autoalias) eq "auto") {
			$d_autoalias = $fullname;
			$d_autoalias =~ s!^.*(\\|\/)!!;
			$d_autoalias = substr($d_autoalias,0,length($d_autoalias) - 4);
			$d_autoalias =~ s/\|//g;
			$d_autoalias =~ s/\+//g;
			$d_autoalias =~ s/\_//g;
			$d_autoalias =~ s/\"//g;
			$d_autoalias =~ s/<([^>]|\n)*>//g;
		}
		print data "$d_autoalias|$fullname|1\n";
		$found = 1;
		$real_alias = $d_autoalias;
		$tempcount = 1;
	}
	&lockclose (data,"$server_datapath$d_data_file");
} else {
	# File doesn't exist, create a new one
	open(data,">$server_datapath$d_data_file") || &showerror("Error creating the Counter-File. Please contact <a href=\"mailto:$email_address\">$email_address</a>! Thanks!");
	if ($d_autoadd eq "on") {
		print data "$d_autoalias|$fullname|1\n";
		$found = 1;
		$real_alias = $d_autoalias;
	}
	close(data);
	$tempcount = 1;
}


if ($d_countaliastofile eq "on") {
	$filename = $real_alias;
	$filename =~ s/(\W)//g;
	$tempcount = 0;
	if (-e $d_countaliaspath.${filename}.".txt") {
		open(data,"<${d_countaliaspath}${filename}.txt");
		@atempcount = <data>;
		close(data);
		$tempcount = @atempcount[0];
	}
	$tempcount = $tempcount + 1;
	open(data,">${d_countaliaspath}${filename}.txt");
	print data "$tempcount";
	close(data);
}

if ($uselocking) { &masterlockclose; }

if ($found eq "1") {
	&success;
} else {
	&nofileerror;
}

sub success {
	if ($real_url ne "") {
		$filename = $real_url;
	} else {
		$filename = $fullname;
	}
	$filename =~ s!^.*(\\|\/)!!;
	&ext_header;
	if ($real_url ne "") {
		$fullname = $real_url;
	}
	$real_alias2 = $real_alias;
	if ($d_autoreplace eq "on") {
		$real_alias2 =~ s/\ /_/g;
	}
	unless ($d_antileech eq "on") {
		print "<META HTTP-EQUIV=\"refresh\" CONTENT=\"5; URL=$fullname\">\n";
	} else {
		print "<META HTTP-EQUIV=\"refresh\" CONTENT=\"5; URL=$server_url$d_script_url\?file=$real_alias2&get=1";
		if ($whichmirror != 1) {
			print "&mirror=$whichmirror";
		}
		print "\">\n";
	}
	print "<div align=\"center\"><b>The download will automatically start in five seconds.</b></div></p>\n";
	unless ($d_antileech eq "on") {
		print "<p>If it doesn't start, click <a href=\"$fullname\">here</a> to begin downloading!<p>\n";
	}
	print "<i>$real_alias</i> has already been downloaded $tempcount time(s).<p>\n";
	print "</p><p>&nbsp;</p><p>\n";
	
	if ($ENV{'HTTP_REFERER'}) {
		print "<< Click <a href=\"$ENV{'HTTP_REFERER'}\">here</a> to get back to the page you came from!\n";
	} else {
		print "<< Click <a href=\"$siteurl\">here</a> to get back to $sitetitle!\n";
	}
	# Ok.. so you got this script for free. Can you imagine
	# how long it took me to code all that? About 350 kB of
	# pure Perl-Code? And you can't say that this script is
	# bad. You get all my work completely free,so is it too
	# much if I ask you to leave this link in? Please don't
	# remove it, so that others can also find out where the
	# script is from and help spreading the script. Because
	# you know:  The more people use Schlabo's Scripts, the
	# more am I motivated to improve it! Thanks!
	print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";

	&ext_footer;
	exit;
}

sub nofileerror {
	&ext_header;
	
	print "The URL / Alias that was given to this script does not exist in our database.<br>";
	if ($d_notifymissing eq "on") {
		print "The webmaster of $sitetitle has been automatically notified by the script, the problem will be fixed as soon as possible.";
	} else {
		print qq|
		If you got to this page through a link on $sitetitle, 
		please send a mail to <a href="mailto:$email_address">$email_address</a> including the following information:<p>
		<b>Specified File:</b> $fullname<br>
		<b>Referring Page:</b> $ENV{'HTTP_REFERER'}<p>
		Thanks for your support!
		|;
	}
	print "</p><p>&nbsp;</p><p>\n";
	
	if ($ENV{'HTTP_REFERER'}) {
		print "<< Click <a href=\"$ENV{'HTTP_REFERER'}\">here</a> to get back to the page you came from!\n";
	} else {
		print "<< Click <a href=\"$siteurl\">here</a> to get back to $sitetitle!\n";
	}
	
	$email_address =~ s/\\\@/\@/g;
	if ($d_notifymissing eq "on") {
		if (($email_address eq "") || ($email_address eq "yourname\@yoursite.com")) {
			print "<i>[Unable to send a mail to the webmaster as no valid email-address has been specified in the general configuration.]</i><br><br>\n";
		} else {							# Email-Address
			if ($mailprog ne "") {
				&get_date;
				open (MAIL, "|$mailprog -t") || &showerror("[Unable to send a mail to the webmaster - Can't open $mailprog!]");
				print MAIL "From: $email_address\n";
				print MAIL "To: $email_address\n";
				print MAIL "Subject: Schlabo's Scripts - Missing Download in Database\n\n";
print MAIL <<EOF;
A user just tried to download a file from your site that doesn't exist in your database as it has not been added yet.
However it's also possible that the visitor just changed the URL himself to see what happens, so take a look at the URL before taking action.
Click here to login to the DL-Script: $server_url$d_admin_url

Specified File: $fullname
Referring Page: $ENV{'HTTP_REFERER'}
Date: ${m}-${month_day}-$y
Time: ${Hour}:${Minute}:${Second}

This email was generated automatically by Schlabo's Download. You can deactivate this feature in the Download-Configuration.
EOF
				close (MAIL);
			}
		}
	}
	print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";
	
	&ext_footer;
	exit;
}

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	} else {	# Input
		open (FILE,"<$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			&showerror("The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}dl_masterlock.lok")
	  && ((stat("${server_datapath}dl_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}dl_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}dl_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access dl_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}dl_masterlock.lok") {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
}

sub showerror {
	if ($uselocking) { &masterlockclose; }
	&ext_header;
	print "@_";
	print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";
	&ext_footer;
	exit;
}

sub ext_header {
	# Print the beginning of the document

	print "Content-type: text/html\n\n";
	
	foreach $line (@dltemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		$line =~ s/\[\!fullname\]/$fullname/g;
		$line =~ s/\[\!filename\]/$filename/g;
		$line =~ s/\[\!alias\]/$real_alias/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		print "$line";
	}

}

sub ext_footer {
	# Print the footer of the document
	
	$flag = 0;
	foreach $line (@dltemplate) {
		if($flag) {
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			$line =~ s/\[\!fullname\]/$fullname/g;
			$line =~ s/\[\!filename\]/$filename/g;
			$line =~ s/\[\!alias\]/$real_alias/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
			$flag = 1;
		}
		

	}
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}