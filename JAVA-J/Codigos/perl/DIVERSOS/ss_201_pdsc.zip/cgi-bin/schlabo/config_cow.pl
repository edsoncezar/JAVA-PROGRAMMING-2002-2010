#!/usr/bin/perl

use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# -------------------------------------------------------------------------------------
# COW-Specific

# Filename of the Cow-Display-Script
$c_script_url = "cow.pl";

# Filename of the Data-File
$c_data_file = "cow_data.txt";

# Location of the Comic-Picture-Files
$c_cow_url = "http://127.0.0.1/images/cow/";

# General Comic-Filenames
# The name will be created like that: $c_files$curweek-$comicpicture.$c_extension
# So the default for the individual comic-pics of for example week 2 is: "cow2-1.jpg", "cow2-2.jpg",...
$c_files = "cow";

# Filename-Extension of the Comic-Picture-Files (jpg/gif), without a .
$c_extension = "jpg";

# The tag at the beginning of the thumbnail-picture that is different to the high quality-pic.
# Example: If the thumbtag is set to "t_" and you want to name the thumbnail for week 2,
# the comic-pictures have to be "cow2-1.jpg", "cow2-2.jpg",... the thumbnail just: "t_cow2.jpg"
$c_thumbtag = "t_";

# Filename of the Template-File for the COW-Pages
$c_cowtemplate = "template_cow.txt";

# Version of this script, do not alter the variable
$c_version = "2.01";

1;
