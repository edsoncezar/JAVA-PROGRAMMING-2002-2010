#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_sp.pl";

umask (0111);

print "Content-Type: text/html\n\n";

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

if ($uselocking) { &masterlockopen; }

if (-e "$server_datapath$s_data_file") {
	&lockopen(data,"$server_datapath$s_data_file","input");
	@tempdata = <data>;
	&lockclose(data,"$server_datapath$s_data_file");
	
	$countup = 0;
	$spcount = 0;
	
	$max_num = @tempdata;
	for ($count=0;$count<$max_num;$count++) {
		$temp_data = @tempdata[$count];
		chomp($temp_data);
		($temp_count,$temp_url) = split(/\|/,$temp_data);
		$spcount += $temp_count;
		$totalcount = $totalcount + 1;				
	}
		
	print "$s_showtotalscmessagebefore$spcount\n";
	print "$s_showtotalscmessagemiddle$totalcount\n";
	print "$s_showtotalscmessageafter\n";
	
} else {
	print "[Error: Data-File not found]";
}

if ($uselocking) { &masterlockclose; }

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || print "[Error: There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	} else {	# Input
		open (FILE,"<$lockfilename") || print "[Error: There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			print "[Error: The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}sp_masterlock.lok")
	  && ((stat("${server_datapath}sp_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}sp_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}sp_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		print "[Error: The server was unable to access sp_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	}
}

sub masterlockclose {
	if (-e "${server_datapath}sp_masterlock.lok") {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
}
