#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_sp.pl";

umask (0111);

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

print "Content-type: text/html\n\n";

open(tfile, "<$server_path$s_sptemplate");
@sptemplate =<tfile>;
close(tfile);


$referer_ok = 0;
if ($ENV{'HTTP_REFERER'}) {
	foreach $referer(@referers) {
    		if ($ENV{'HTTP_REFERER'} =~ m|http://([^/]*)$referer|i) {
			$referer_ok = 1; last;
		}
	}
} else {
	$referer_ok = 1;
}

if ($referer_ok != 1) {
	&ext_header;
	print "You are trying to view a picture on the ${sitetitle}-Server from another site.";
	print "We do not want other sites to steal our bandwidth, so if you want to help us please send a mail to <a href=\"mailto:$email_address\">$email_address</a> and tell us the URL of the site you came from. Thanks!</p><p>&nbsp;</p>\n";
	&ext_footer;
	exit;
}

if (param('info')) {$info = param('info')}
if (param('src')) {$pic_url = param('src')}
if (param('width')) {$width = param('width')}
if (param('height')) {$height = param('height')}
if (param('from')) {$from = param('from')}
$pic_count = 1;

if (!$pic_url) {
	$query=$ENV{'QUERY_STRING'};
	$query =~ s/\&.*$//g;
	$pic_url = $query;
	$pic_url =~ s/\?//g;
}

if ($s_autoreplace eq "on") {
	$info =~ s/_/\ /g;
}

if (($s_counting eq "on") && ($pic_url ne "")) {
	if ($uselocking) { &masterlockopen; }
	$found = 0;
	if (-e $server_datapath.$s_data_file) {
		
		&lockopen(data,"${server_datapath}${s_data_file}","input");
		@tempdata = <data>;
		&lockclose(data,"${server_datapath}${s_data_file}");
		
		&lockopen(data,"${server_datapath}${s_data_file}","output");
		foreach $line (@tempdata) {
			chomp($line);
			($temp_count,$temp_url) = split(/\|/,$line);
			if ($temp_url eq $pic_url) {
				$temp_count += 1;
				if ($temp_count > $pic_count) {
					$pic_count = $temp_count;
				}
				$found = 1;
			}
			print data "$temp_count|$temp_url\n";
		}
		if (($s_autoadd eq "on") && ($found == 0)) {
			print data "1|$pic_url\n";
			$found = 1;
		}
		&lockclose(data,"${server_datapath}${s_data_file}");
	} else {
		open(data,">${server_datapath}${s_data_file}");
		if ($s_autoadd eq "on") {
			print data "1|$pic_url\n";
			$found = 1;
		}
		close(data);
		print "<p><font face=\"$font_type\" size=\"2\">[The Database was created]</font></p>\n";
	}
	if ($uselocking) { &masterlockclose; }
}

if ($found == 0) {
	&nofileerror;
}


# Print link back to the previous page
if ($from) {
} elsif ($ENV{'HTTP_REFERER'}) {
	$from = $ENV{'HTTP_REFERER'};
} else {
	$from = $s_backlinkurl;
}

# The pic itself
if(!$pic_url) { 
	$pic_code = "[Error: No image specified]";
} else {
	$pic_code = "<img src=\"";
	$pic_code = $pic_code."$pic_url\"";
	if ($width) {
		$pic_code = $pic_code." width=\"$width\"";
	}
	if ($height) {
		$pic_code = $pic_code." height=\"$height\"";
	}
	$alttext = $pic_url; $alttext =~ s/.*\///g;
	$pic_code = $pic_code." alt=\"$alttext\">";
}

# Ok.. so you got this script for free. Can you imagine
# how long it took me to code all that? About 350 kB of
# pure Perl-Code? And you can't say that this script is
# bad. You get all my work completely free,so is it too
# much if I ask you to leave this link in? Please don't
# remove it, so that others can also find out where the
# script is from and help spreading the script. Because
# you know:  The more people use Schlabo's Scripts, the
# more am I motivated to improve it! Thanks!
$pic_code = $pic_code."</p><p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's SP v$s_version</font></a>";

&ext_header;
&ext_footer;


sub parse_query {
	@pairs = split(/&/, $ENV{'QUERY_STRING'});
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$QUERY{$name} = $value;
	}
}

sub nofileerror {
	&ext_header;
	print "<p><font face=\"$font_type\" size=\"2\">";
	print "The picture that was given to this script does not exist in our database.<br>";
	if ($s_notifymissing eq "on") {
		print "The webmaster of $sitetitle has been automatically notified by the script, the problem will be fixed as soon as possible.";
	} else {
		print qq|
		If you got to this page through a link on $sitetitle, 
		please send a mail to <a href="mailto:$email_address">$email_address</a> including the following information:<p>
		<b>Specified File:</b> $pic_url<br>
		<b>Referring Page:</b> $ENV{'HTTP_REFERER'}<p>
		Thanks for your support!
		|;
	}
	print "</p><p>&nbsp;</p><p>\n";
	
	if ($ENV{'HTTP_REFERER'}) {
		print "<< Click <a href=\"$ENV{'HTTP_REFERER'}\">here</a> to get back to the page you came from!\n";
	} else {
		print "<< Click <a href=\"$s_backlinkurl\">here</a> to get back to $sitetitle!\n";
	}
	
	$email_address =~ s/\\\@/\@/g;
	if ($s_notifymissing eq "on") {
		if (($email_address eq "") || ($email_address eq "yourname\@yoursite.com")) {
			print "<i>[Unable to send a mail to the webmaster as no valid email-address has been specified in the general configuration.]</i><br><br>\n";
		} else {							# Email-Address
			if ($mailprog ne "") {
				&get_date;
				open (MAIL, "|$mailprog -t") || &showerror("[Unable to send a mail to the webmaster - Can't open $mailprog!]");
				print MAIL "From: $email_address\n";
				print MAIL "To: $email_address\n";
				print MAIL "Subject: Schlabo's Scripts - Missing Download in Database\n\n";
print MAIL <<EOF;
A user just tried to view a picture from your site that doesn't exist in your database as it has not been added yet.
However it's also possible that the visitor just changed the URL himself to see what happens, so take a look at the URL before taking action.
Click here to login to the SP-Script: $server_url$s_admin_url

Specified Picture: $pic_name
Referring Page: $ENV{'HTTP_REFERER'}
Date: ${m}-${month_day}-$y
Time: ${Hour}:${Minute}:${Second}

This email was generated automatically by Schlabo's ShowPicture. You can deactivate this feature in the SP-Configuration.
EOF
				close (MAIL);
			}
		}
	}
	print "</font></p>";
	print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's SP v$s_version</font></a></p>\n";
	
	&ext_footer;
	exit;
}


sub ext_header {
	# Print the beginning of the document

	foreach $line (@sptemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		$line =~ s/\[\!description\]/$info/g;
		$line =~ s/\[\!backlink\]/$from/g;
		$line =~ s/\[\!picture\]/$pic_code/g;
		$line =~ s/\[\!pic_filename\]/$alttext/g;
		$line =~ s/\[\!width\]/$width/g;
		$line =~ s/\[\!height\]/$height/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		$line =~ s/\[\!pic_count\]/$pic_count/g;
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		print "$line";
	}

}

sub ext_footer {
	# Print the footer of the document
	
	$flag = 0;
	foreach $line (@sptemplate) {
		if($flag) {
			$line =~ s/\[\!description\]/$info/g;
			$line =~ s/\[\!backlink\]/$from/g;
			$line =~ s/\[\!picture\]/$pic_code/g;
			$line =~ s/\[\!pic_filename\]/$alttext/g;
			$line =~ s/\[\!width\]/$width/g;
			$line =~ s/\[\!height\]/$height/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			$line =~ s/\[\!pic_count\]/$pic_count/g;
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
			$flag = 1;
		}
		

	}
}

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	} else {	# Input
		open (FILE,"<$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			&showerror("The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}sp_masterlock.lok")
	  && ((stat("${server_datapath}sp_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}sp_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}sp_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access sp_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}sp_masterlock.lok") {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
}
