#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_potd.pl";

umask (0111);

print "Content-type: text/html\n\n";

open(tfile, "<$server_path$p_potdgallerytemplate");
@potdtemplate =<tfile>;
close(tfile);

if ($p_galleryon ne "on") {
	&showerror("<font face=\"$font_type\" size=\"2\"><b>Access denied</b><br><br>The Visitor-Gallery has not been activated by the webmaster.<br><br>&nbsp;</font>");
}

&get_date;

if (param('to_day')) {
	$to_day=param('to_day');
	$to_month=param('to_month');
	$to_year=param('to_year');
} else {
	$to_day=$month_day;
	$to_month=$m;
	$to_year=$y;
}
if (param('dir') eq "up") {
	$searchdir = 1;
} else {
	$searchdir = 0;
}

# Check if specified date is not in the future..
$m2=$m;
if (length($m2) eq "1") {
	$m2 = "0".$m;
}
$month_day2=$month_day;
if (length($month_day2) eq "1") {
	$month_day2="0".$month_day;
}
$testnow = $y.$m2.$month_day2;
$to_day2=$to_day;
if (length($to_day2) eq "1") {
	$to_day2="0".$to_day2;
}
if (length($to_month) eq "1") {
	$testnew = $to_year."0".$to_month.$to_day2;
} else {
	$testnew = $to_year.$to_month.$to_day2;
}
if ($testnow < $testnew) {
	$to_day=$month_day;
	$to_month=$m;
	$to_year=$y;
	if ($searchdir == 1) {
		$searchdir = 0;
	}
}


if ($uselocking) { &masterlockopen; }
$act_day=$to_day;
$act_month=$to_month;
$act_year=$to_year;
&read_c_archives;

if ($searchdir == 0) {
	&build_frombehind;
} else {
	&build_fromfront;
}
if ($uselocking) { &masterlockclose; }

if ($searchdir == 0) {
	if ($searchedmonths ne "999") {
		$act_day=$act_day-1;
		if ($act_day==0) {
			$act_month=$act_month-1;
			if ($act_month==0) {
				$act_month=12;
				$act_year=$act_year-1;
			}
			$act_day=$months_days[$act_month-1];
		}
		$back_link = "<td align=\"left\"><font face=\"$font_type\" size=2><a href=\"$ENV{'SCRIPT_NAME'}?to_day=$act_day&to_month=$act_month&to_year=$act_year\">&lt;&lt; Previous Page</a></font></td>";
	}
	$to_day=$to_day+1;
	if ($to_day==($months_days[$to_month-1]+1)) {
		$to_month=$to_month+1;
		if ($to_month==13) {
			$to_month=1;
			$to_year=$to_year+1;
		}
		$to_day=1;
	}
	if ($to_day>$month_day) {
		$to_day2=$to_day;
		if (length($to_day2) eq "1") {
			$to_day2="0".$to_day2;
		}
		if (length($to_month) eq "1") {
			$testnew = $to_year."0".$to_month.$to_day2;
		} else {
			$testnew = $to_year.$to_month.$to_day2;
		}
		if ($testnow < $testnew) {
			$searchedmonths = 998;
		}
	}
	if ($searchedmonths ne "998") { 
		$next_link = "<td align=\"right\"><font face=\"$font_type\" size=2><a href=\"$ENV{'SCRIPT_NAME'}?to_day=$to_day&to_month=$to_month&to_year=$to_year&dir=up\">Next Page &gt;&gt;</a></font></td>";
	}
} else {
	$to_day=$to_day-1;
	if ($to_day==0) {
		$to_month=$to_month-1;
		if ($to_month==0) {
			$to_month=12;
			$to_year=$to_year-1;
		}
		$to_day=$months_days[$to_month-1];
	}
	$back_link = "<td align=\"left\"><font face=\"$font_type\" size=2><a href=\"$ENV{'SCRIPT_NAME'}?to_day=$to_day&to_month=$to_month&to_year=$to_year\">&lt;&lt; Previous Page</a></font></td>";
	if ($searchedmonths ne "999") {
		$act_day=$act_day+1;
		if ($act_day==($months_days[$act_month-1]+1)) {
			$act_month=$act_month+1;
			if ($act_month==13) {
				$act_month=1;
				$act_year=$act_year+1;
			}
			$act_day=1;
		}
		if ($act_day>$month_day) {
			$act_day2=$act_day;
			if (length($act_day2) eq "1") {
				$act_day2="0".$act_day2;
			}
			if (length($act_month) eq "1") {
				$testnew = $act_year."0".$act_month.$act_day2;
			} else {
					$testnew = $act_year.$act_month.$act_day2;
			}
			if ($testnow < $testnew) {
				$searchedmonths = 999;
			}
		}
		if ($searchedmonths ne "999") { 
			$next_link = "<td align=\"right\"><font face=\"$font_type\" size=2><a href=\"$ENV{'SCRIPT_NAME'}?to_day=$act_day&to_month=$act_month&to_year=$act_year&dir=up\">Next Page &gt;&gt;</a></font></td>";
		}
	}
}

&ext_header;

$searchedmonths = 1001;
print "<table border=0>";
for ($build_y=1;$build_y<($p_galleryrows+1);$build_y++) {
	print "<tr>";
	for ($build_x=1;$build_x<($p_gallerycolumns+1);$build_x++) {
		print "<td align=\"center\" valign=\"top\"";
		if ($p_thumbw) { print " width=\"".($p_thumbw+60)."\"" }
		print ">";
		if ($gallery[$build_y][$build_x][0]) {
			print "<font face=\"$font_type\" size=1>";
			if ($p_gallerydesc eq "on") { print "<font color=\"#FFCC00\">" }
			print "$gallery[$build_y][$build_x][3]/$gallery[$build_y][$build_x][4]/$gallery[$build_y][$build_x][5]";
			if ($p_gallerydesc eq "on") { print "</font>" }
			print "<br><a href=\"$server_url$p_script_url?day=$gallery[$build_y][$build_x][3]\&month=$gallery[$build_y][$build_x][4]\&year=$gallery[$build_y][$build_x][5]\">";
			print "<img src=\"$gallery[$build_y][$build_x][1]$p_thumbtag$gallery[$build_y][$build_x][0]\"";
			if ($p_thumbw) { print " width=$p_thumbw" }
			if ($p_thumbh) { print " height=$p_thumbh" }
			print " alt=\"$gallery[$build_y][$build_x][2]\"";
			print " border=0></a><br>";
			if ($p_gallerydesc eq "on") {
				print $gallery[$build_y][$build_x][2]."<br>";
			}
			print "&nbsp;</font>";
			$searchedmonths=1000;
		}
		print "</td>\n";
	}
	print "</tr>";
}
print "</table>";
if ($searchedmonths==1001) {
	print "<p align=\"center\"><font face=\"$font_type\" size=2>No pictures found for this period of time.</font></p>\n";
}
print "<br><br>\n";

if ($p_newwindow eq "on") {
	print "<script language='JavaScript'>\n";
	print "function closeIt() {\n";
	print "  close();\n";
	print "}\n";
	print "</script>\n";
	print "<p align=\"center\"><form><input type=button value='Close' onClick='closeIt()' style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\"></form></p>\n";
}

&ext_footer;

sub clear_cal {
	for ($count=1;($count<32);$count++) {
		$calendar[$count][0]="";
	}
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}

	
sub read_c_archives {	
	$month_notfound=0;
	$filename="potd_".$act_month."-".$act_year.".txt";
	if (-e "$server_datapath$filename") {
		# If a file for this month is already here, read it and store contents in an array
		open(data,"<$server_datapath$filename");
		@all_data = <data>;
		close(data);
		
		$max_num = @all_data;
		
		for ($count=0;$count<$max_num;$count++) {
			$temp_pic_data = @all_data[$count];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($c_month,$c_day,$c_year) = split(/-/,$temp_pic_date);
			$calendar[$c_day][0]=$temp_pic_filename;
			$calendar[$c_day][1]=$temp_pic_url;
			$calendar[$c_day][2]=$temp_pic_info;
		}	
	} else {
		$month_notfound=1;
	}
}

sub build_frombehind {
$searchedmonths = 0;
$act_day=$act_day+1;
for ($build_y=$p_galleryrows;$build_y>0;$build_y--) {
	for ($build_x=$p_gallerycolumns;$build_x>0;$build_x--) {
		while (true) {
		$act_day=$act_day-1;
		if ($act_day==0) {
			$act_month=$act_month-1;
			if ($act_month==0) {
				$act_month=12;
				$act_year=$act_year-1;
			}
			$act_day=$months_days[$act_month-1];
			&clear_cal;
			&read_c_archives;
			if ($month_notfound==1) {
				$searchedmonths=$searchedmonths+1;
				if ($searchedmonths == $p_goback) {
					# Give up trying to find previous picture
					$searchedmonths=999;
				}
			} else {
				$searchedmonths=0;
			}
		}
		if ($calendar[$act_day][0]) {		# Pic available for that day
			$gallery[$build_y][$build_x][0]=$calendar[$act_day][0];
			$gallery[$build_y][$build_x][1]=$calendar[$act_day][1];
			$gallery[$build_y][$build_x][2]=$calendar[$act_day][2];
			$gallery[$build_y][$build_x][3]=$act_day;
			$gallery[$build_y][$build_x][4]=$act_month;
			$gallery[$build_y][$build_x][5]=$act_year;
			last;
		}
		if ($searchedmonths == 999) { last }
		}
		if ($searchedmonths == 999) { last }
	}
	if ($searchedmonths == 999) { last }
}
}

sub build_fromfront {
$searchedmonths=0;
$act_day=$act_day-1;
for ($build_y=1;$build_y<($p_galleryrows+1);$build_y++) {
	for ($build_x=1;$build_x<($p_gallerycolumns+1);$build_x++) {
		while (true) {
		$act_day=$act_day+1;
		if ($act_day==($months_days[$act_month-1]+1)) {
			$act_month=$act_month+1;
			if ($act_month==13) {
				$act_month=1;
				$act_year=$act_year+1;
			}
			$act_day=1;
			&clear_cal;
			&read_c_archives;
			if ($month_notfound==1) {
				$searchedmonths=$searchedmonths+1;
				if ($searchedmonths == $p_maxgoforward) {
					# Give up trying to find previous picture
					$searchedmonths=999;
				}
			} else {
				$searchedmonths=0;
			}
		}
		# Check if not already in the future
		if ($act_day>$month_day) {
			$act_day2=$act_day;
			if (length($act_day2) eq "1") {
				$act_day2="0".$act_day2;
			}
			if (length($act_month) eq "1") {
				$testnew = $act_year."0".$act_month.$act_day2;
			} else {
				$testnew = $act_year.$act_month.$act_day2;
			}
			if ($testnow < $testnew) {
				$searchedmonths = 999;
			}
		}
		if (($calendar[$act_day][0]) and ($searchedmonths < 999)) {		# Pic available for that day
			$gallery[$build_y][$build_x][0]=$calendar[$act_day][0];
			$gallery[$build_y][$build_x][1]=$calendar[$act_day][1];
			$gallery[$build_y][$build_x][2]=$calendar[$act_day][2];
			$gallery[$build_y][$build_x][3]=$act_day;
			$gallery[$build_y][$build_x][4]=$act_month;
			$gallery[$build_y][$build_x][5]=$act_year;
			last;
		}
		if ($searchedmonths == 999) { last }
		}
		if ($searchedmonths == 999) { last }
	}
	if ($searchedmonths == 999) { last }
}
}

sub ext_header {
	# Print the beginning of the document

	foreach $line (@potdtemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		$line =~ s/\[\!next_link\]/$next_link/g;
		$line =~ s/\[\!back_link\]/$back_link/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		print "$line";
	}

}

sub ext_footer {
	# Print the footer of the document

# Ok.. so you got this script for free. Can you imagine
# how long it took me to code all that? About 350 kB of
# pure Perl-Code? And you can't say that this script is
# bad. You get all my work completely free,so is it too
# much if I ask you to leave this link in? Please don't
# remove it, so that others can also find out where the
# script is from and help spreading the script. Because
# you know:  The more people use Schlabo's Scripts, the
# more am I motivated to improve it! Thanks!
print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's POTD v$p_version</font></a></p>\n";

	$flag = 0;
	foreach $line (@potdtemplate) {
		if($flag) {
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			$line =~ s/\[\!next_link\]/$next_link/g;
			$line =~ s/\[\!back_link\]/$back_link/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
			$flag = 1;
		}
		

	}
}

sub showerror {
	if ($uselocking) { &masterlockclose; }
	&ext_header;
	print "@_";
	&ext_footer;
	exit;
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}potd_masterlock.lok")
	  && ((stat("${server_datapath}potd_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}potd_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}potd_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access potd_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}potd_masterlock.lok") {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
}
