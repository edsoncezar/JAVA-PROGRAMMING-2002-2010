#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01a            ##
##         last modified: 14/02/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_dl.pl";
require "common.pl";

umask (0111);

$scriptname="dl";

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

&check_referer;
&parse_query;
&get_date;
if ($uselocking && ($QUERY{'action'} ne 'login') && ($QUERY{'action'} ne '') && ($QUERY{'action'} ne 'guest')) { &masterlockopen; }
eval { &get_script_actions; };
if ($uselocking) { &masterlockclose; }
if ($@) {
	&showerror("An error occured: $@");
}
exit;

sub get_script_actions {
	# Query and Form Actions
	$dowhat = $QUERY{'action'};
	if ($dowhat eq "showadmin") {
		$dowhat = "showlogs";
	}
	
	if (($dowhat ne 'login') && ($dowhat ne '') && ($dowhat ne 'guest')) {
		&get_password;
	}
	if ($dowhat eq 'login') { &showlogin; } 
	elsif ($dowhat eq 'showlogs') { &showlogs; }
	elsif ($dowhat eq 'editentry') { &edit_entry; } 
	elsif ($dowhat eq 'removeoredit') { &re_entry; }
	elsif ($dowhat eq 'addfile') { &add_entry; }
	elsif ($dowhat eq 'calculatealias') { &calculatealias; }
	elsif ($dowhat eq 'guest') { &guest_stats; }
	elsif ($dowhat eq 'viewleechlog') { &viewleechlog; }
	elsif ($dowhat eq 'reset_log_query') { &reset_log_query; }
	elsif ($dowhat eq 'reset_log') { &reset_log; }
	elsif ($dowhat eq '') { &showlogin; }
	else { &novalidquery;
	}
}


sub showlogs {
	
	if (-e "$server_datapath$d_data_file") {
		$foundfile = 1;
	}
	$sort_alias = 1;
	
	if (param('r_showmethod') eq "sm_urls") {
		$sort_alias = 0;
	} elsif (param('r_showmethod') eq "sm_alias") {
		$sort_alias = 1;
	}
	$searchactive = 0;
	if (param('search') ne "") {
		$searchactive = 1;
		$searchstring = param('search');
	}
	if ($foundfile == 1) {
		&lockopen(data,"$server_datapath$d_data_file","input");
		@tempdata = <data>;
		&lockclose(data,"$server_datapath$d_data_file");
	}
	
	&html_header;
	
	$totalcount=0;
	$countup = 0;
	$optimized = 1;
	
	if ($foundfile == 1) {
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
			if (($searchactive eq "0") || (($searchactive eq "1") && (index($temp_file,$searchstring) >= 0)) || (($searchactive eq "1") && (index($temp_alias,$searchstring) >= 0))) {
				$data[$countup][0]=$temp_num;
				$data[$countup][1]=$temp_file;
				$data[$countup][2]=$temp_alias;
				$totalcount=$totalcount + $temp_num;
				if (($countup > 0) && ($temp_num > $data[$countup-1][0])) { 
					# Log-file is not optimized
					$optimized = 0;
				}
				$countup = $countup + 1;			
			}
		}
		$max_num = $countup;
		
		
		$a_number = "0";       # Total number of Aliases
		
		if ($sort_alias eq "1") {
			for ($count=0;$count<$max_num;$count++) {
				$found=0;
				for ($count2=0;$count2<$a_number;$count2++) {
					if ($a_data[$count2][2] eq $data[$count][2]) {   # Alias already found
						$a_data[$count2][0] = $a_data[$count2][0] + $data[$count][0];
						$found=1;
					}
				}
				if ($found eq "0") {      # Alias not yet in a_data, so add it!
					$a_data[$a_number][2] = $data[$count][2];   # Store new alias
					$a_data[$a_number][1] = $data[$count][1];   # Store new URL (needed for editing)
					$a_data[$a_number][0] = $data[$count][0];   # Store number for alias
					$a_number = $a_number + 1;
				}
			}
			# Ok, now we have all the combined aliases in a new array, so let's sort it!
			&bubblesort_a;
			$max_num = $a_number;
			
		}
	
		
		if (($sort_alias eq "0") && ($optimized eq "0")) {
			&bubblesort;
			&optimize_silent;
		}
	}
	
	print qq^
	<p><font face="Verdana, Arial, Helvetica" size="2">This is the log-file of the Download-Script. To edit the URL of an entry or to remove it (for example if the file is no longer available), select the file and click on "Edit Selected Entry".</font><p>
	^;
	

	# CountAlias To File Integrity-Check
	if (($d_countaliastofile eq "on") && ($sort_alias == 1)) {
		$afilemissing = 0;
		$afileintegrity = 0;
		for ($count=0;$count<$max_num;$count++) {
			$filename = $a_data[$count][2];
			$filename =~ s/(\W)//g;
			if (-e $d_countaliaspath.${filename}.".txt") {
				$filename = $a_data[$count][2];
				$filename =~ s/(\W)//g;
				open(data,"<${d_countaliaspath}${filename}.txt");
				@atempcount = <data>;
				close(data);
				$tempcount = @atempcount[0];
				if ($a_data[$count][0] ne $tempcount) {
					$afileintegrity = 1;
				}
			} else {
				$afilemissing = 1;
			}
			if (($afileintegrity == 1) or ($afilemissing == 1)) {
				last;
			}
		}
		if ($afileintegrity == 1) {
			print qq^
			<p><font face="Verdana, Arial, Helvetica" size="2">
			<form action="$server_url$d_admin_url?action=calculatealias" method="post">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			^;
			print "<br>The values stored in the Alias Count-Files do not match the database. It is recommended that you rebuild them by clicking <input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">.\n";
			print qq^
			</form>
			</font></p>
			^;
		} elsif ($afilemissing == 1) {
			print qq^
			<p><font face="Verdana, Arial, Helvetica" size="2">
			<form action="$server_url$d_admin_url?action=calculatealias" method="post">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			^;
			print "<br>At least one Alias Count-File is missing. It is recommended that you rebuild them by clicking <input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">.\n";
			print qq^
			</form>
			</font></p>
			^;
		}	
	}
	
	print qq^
	<p><font face="Verdana, Arial, Helvetica" size="2">
	<form action="$server_url$d_admin_url?action=addfile" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	^;
	print "<br>Click <input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\"> to add a new file.\n";
	print qq^
	</form>
	</font></p>
	
	<p><font face="Verdana, Arial, Helvetica" size="2">
	<form action="$server_url$d_admin_url?action=showlogs" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<font color="#FFCC00">Display-Mode</font><br><hr noshade>
	^;
	if ($sort_alias eq "0") {
		print "<input type=\"radio\" name=\"r_showmethod\" value=\"sm_alias\"> Display Aliases<br>\n";
		print "<input type=\"radio\" name=\"r_showmethod\" value=\"sm_urls\" checked> Display URLs<br><br>\n";
	} elsif ($sort_alias eq "1") {
		print "<input type=\"radio\" name=\"r_showmethod\" value=\"sm_alias\" checked> Display Aliases<br>\n";
		print "<input type=\"radio\" name=\"r_showmethod\" value=\"sm_urls\"> Display URLs<br><br>\n";
	}
	print qq^
	<input type="text" size="15" name="search" value="$searchstring" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
	<input type="submit" name="submit" value="OK / Search" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</form>
	
	^;
	if ($foundfile == 1) {
		print qq^
		<p><font face="Verdana, Arial, Helvetica" size="2"><br><font color="#FFCC00">Stats</font><br><hr noshade>
		Total number downloaded files: <b>$max_num</b><br>
		Total number of downloads: <b>$totalcount</b><br>
		^;
		if ($d_countguests ne "") {   # Count how many guests access this page
			if (-e "$server_datapath$d_countfile") {
				open(cfile,"<$server_datapath$d_countfile");
				$count = <cfile>;
				close(cfile);
				print "Guest-Logs have been accessed: <b>$count</b> times";
			} else {    # File not here, create a new one
				print "Guest-Counting is activated, but no counter-file has been created yet. It will automatically be created when the first visitor checks out the guest-stats.";
			}
		}
		print qq^
		<p>
		R = Rank<br>
		DC = Download Count<br>
		File = Alias / URL of the File</p>
		<br><font color="#FFCC00">Logs</font><br><hr noshade>
		^;
		if ($sort_alias eq "0") {
			print qq^
			<form action="$server_url$d_admin_url?url=$data[$count][1]&action=editentry" method="post">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			<p align="center"><input type="submit" name="edit" value="Edit Selected Entry" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
			^;
		}
		print qq^
		<table border="0" width="392">
		<tr>
		<td width="30" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>R</b></font></td>
		<td width="20" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>DC</b></font></td>
		<td width="100%" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>File</b></font></td>
		</tr>
		^;
		for ($count=0;$count<$max_num;$count++) {
			if (($count % 2)==0) {
				print "<tr bgcolor=#276B2E>";
			} else {
				print "<tr>";
			}
			print "<td width=\"30\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\" color=\"#FFCC00\"><b>".($count+1)."</b></font></td>\n";
			print "<td width=\"20\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">";
			if ($sort_alias eq "0") {
				print $data[$count][0];
				print "</font></td>\n";
				print "<td width=\"100%\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">$data[$count][1]</font></td>\n";		
				print "<td width=\"50\" valign=\"top\">";
				print "<input type=\"radio\" name=\"eurl\" value=\"$data[$count][1]\">\n";
				print "</td>\n";
			} elsif ($sort_alias eq "1") {
				print $a_data[$count][0];
				print "</font></td>\n";
				print "<td width=\"100%\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">$a_data[$count][2]</font></td>\n";
			}
			print "</tr>\n";
		}
	
		print "</table>\n";
		if ($sort_alias eq "0") {
			print "<p align=\"center\"><input type=\"submit\" name=\"edit\" value=\"Edit Selected Entry\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\"></p>";
		}
		print "</form>\n";
	} else {
		print "<p><font face=\"Verdana, Arial, Helvetica\" size=\"2\">No Log-File has been created yet.\n";
	}
	&html_footer;
}

sub guest_stats {
	print "Location:$server_url$d_gueststatsscript\n\n";
}

sub optimize_silent {
	&lockopen(data,"$server_datapath$d_data_file","input");
	@tempdata = <data>;
	&lockclose(data,"$server_datapath$d_data_file");
	
	$max_num2 = @tempdata;
	
	# Read data-file
	for ($count=0;$count<$max_num;$count++) {
		$temp_data = @tempdata[$count];
		chomp($temp_data);
		($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
		$data2[$count][0] = $temp_num;
		$data2[$count][1] = $temp_file;
		$data2[$count][2] = $temp_alias;
	}
	
	
	# Sort database
	&bubblesort2;
	
	
	# Write optimized file
	
	# Write edited contents to file
	&lockopen(data,"$server_datapath$d_data_file","output");
	for ($count=0;$count<$max_num2;$count++) {
		if ($data2[$count][1]) {
			print data "$data2[$count][2]|$data2[$count][1]|$data2[$count][0]\n";
		}
	}
	&lockclose(data,"$server_datapath$d_data_file");
	print "Logs optimized...\n";
}

sub edit_entry {
	&html_header;
	$editurl = param("eurl");
	if (-e "$server_datapath$d_data_file") {
		&lockopen(data,"$server_datapath$d_data_file","input");
		@tempdata = <data>;
		&lockclose(data,"$server_datapath$d_data_file");
		
		$max_num = @tempdata;
		
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
			if ($temp_file eq $editurl) {
				$old_url = $temp_file;
				$old_num = $temp_num;
				$old_alias = $temp_alias;
				$old_dc = $temp_num;
				last;
			}
					
		}
		
		if ($old_url) {
			print qq|
			<form method="POST" action="$server_url$d_admin_url?action=removeoredit">
			<input type="hidden" name="oldurl" value="$old_url">
			<input type="hidden" name="oldalias" value="$old_alias">
			<input type="hidden" name="olddc" value="$old_dc">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			<p><input type="radio" value="removeentry" name="whattodo"><font face="Verdana, Arial, Helvetica" size="2">&nbsp;<b>Remove Entry</b></p>
			<p><input type="radio" name="whattodo" checked value="editentry">&nbsp;<b>Edit Entry:</b><br>
			Enter new URL: </font><input type="text" value="$old_url" name="newurl" size="20" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
			<font face="Verdana, Arial, Helvetica" size="2">Enter new Alias: </font><input type="text" value="$old_alias" name="newalias" size="20" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"></p>
			<font face="Verdana, Arial, Helvetica" size="2">Enter new DC: </font><input type="text" value="$old_dc" name="newdc" size="20" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"></p>
			<p><input type="submit" value="Set" name="set" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
			</form>
			<form method="POST" action="$server_url$d_admin_url?action=showlogs">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			<p><input type="submit" value="Cancel" name="cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
			</form>
			|;
			
		} else {
			if ($editurl) {
				print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
				print "The entry you wanted to edit/remove does no longer exist in the log-file.\n";		
				print "<br><br>Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			} else {
				print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
				print "You didn't select an entry to edit.\n";		
				print "<br><br>Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			}
		}
		&html_footer;
	} else {

		print "<br><font size=3 color=#FFCC00><b>No Log-File</b></font><br><br>\n";
		print "The log-file has not been created yet. Start downloading a file tracked by the script and the log-file will automatically be created!<br><br>\n";		
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}	
	
}

sub add_entry {       # Adds a new entry to the log-file
	&html_header;
	print qq|
	<script language="JavaScript">
	<!--
	function openWin (page) {
		myWin= open("http://www.schlabo.com/help/dl/$d_version/"+page+".shtml", "displayWindow", "width=530,height=300,status=yes,toolbar=no,menubar=no,scrollbars=yes,resizable=yes,titlebar=no");
	}
	// -->
	</script>
	<br><font size=3 color="#FFCC00"><b>Add Entry</b></font><br><br>
	To allow a new file to be downloaded you have to add it first. Use the form below to do that.<br>
	<img src="${images_url}arrow.gif" width="4" height="7" align="middle">&nbsp;<a href="javascript:openWin('d_upload_instructions')">Instructions</a><br>
	<form method="POST" action="$server_url$d_admin_url?action=removeoredit" enctype="multipart/form-data" name="add_form">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="hidden" name="whattodo" value="addentry">
	<font face="Verdana, Arial, Helvetica" size="2">
	Enter Alias:<br>
	<input type="text" value="" name="newalias" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"></p>
	Enter DC:<br>
	<input type="text" value="0" name="newdc" size="5" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"></p>
	<br><font color="#FFCC00">File</font><br><hr noshade>
	<input type="radio" name="exists_upload" value="exists" checked>&nbsp;<b>File is already on the server:</b><br>
	Enter URL + Filename:<br><input onClick="document.add_form.exists_upload[0].checked=true;" type="text" value="" name="newurl" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	<br><input type="radio" name="exists_upload" value="upload"|;
	if ($server_security eq "on") {
		print " disabled";
		$d_defaultupload_path = "";
	}
	print qq|>&nbsp;<b>Upload:</b> <small>(Upload bigger files using FTP)</small><br>
	File:<br>
	<input onChange="document.add_form.exists_upload[1].checked=true;" type="file" name="upload_file" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"|;
	if ($server_security eq "on") { print " disabled" }
	print qq|><br>
	Upload-Path:<br>
	<input onClick="document.add_form.exists_upload[1].checked=true;" type="text" name="upload_path" value="$d_defaultupload_path" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"|;
	if ($server_security eq "on") { print " disabled" }
	print qq|><br>
	URL to this path:<br>
	<input onClick="document.add_form.exists_upload[1].checked=true;" type="text" name="upload_url" value="$d_defaultupload_url" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"|;
	if ($server_security eq "on") { print " disabled" }
	print qq|><br>

	<br><br><font color="#FFCC00">Submit</font><br><hr noshade>
	<table border="0"><tr><td><input type="submit" value="Add" name="set" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
	</form></td><td>
	<form method="POST" action="$server_url$d_admin_url?action=showlogs">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="submit" value="Cancel" name="cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
	</form></td></tr></table>
	|;
	&html_footer;
}

sub re_entry {
	$whattodo = param('whattodo');
	$old_url = param('oldurl');
	$new_url = param('newurl');
	$old_alias = param('oldalias');
	$new_alias = param('newalias');
	$old_dc = param('olddc');
	$new_dc = param('newdc');
	$upload_path = param('upload_path');
	$upload_url = param('upload_url');
	$upload_file = param('upload_file');
	$exists_upload = param('exists_upload');
	
	if (($exists_upload eq "upload") && ($server_security eq "on")) {		# Illegal upload - user tricked disabled upload-form
		&showerror("You attempted to upload a file, however uploading has been disabled and is not allowed.");
		exit;
	}
	
	&html_header;
	$message = "<b>Warning:</b> ";
	
	if ($new_dc eq "") { $new_dc=0 }
	
	if (($new_alias eq "") && ($whattodo ne "removeentry")) {
		print "<br><font size=3 color=#FFCC00><b>Missing Data</b></font><br><br>\n";
		print "<p>You didn't specify an Alias for this file. To prevent problems with viewing and editing logs pleace give each file an Alias.<p>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}
	if ((($whattodo eq "addentry") && ($exists_upload eq "exists") && (!$new_url)) || (($whattodo eq "editentry") && (!$new_url))) {
		print "<br><font size=3 color=#FFCC00><b>Missing Data</b></font><br><br>\n";
		print "<p>You didn't specify the URL of this file.<p>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}
	
	if ($whattodo ne "removeentry") {
		# Check Alias for illegal signs
		$new_alias2 = $new_alias;
		$new_alias =~ s/\|//g;
		$new_alias =~ s/\+//g;
		$new_alias =~ s/\"//g;
		$new_alias =~ s/<!--([^>]|\n)*-->//g;
		$new_alias =~ s/<([^>]|\n)*>//g;
		if ($new_alias ne $new_alias2) {
			$message.="The Alias you specified contained some illegal characters that could cause problems. They have been removed and the alias has been changed to: \"<i>$new_alias</i>\".<p>\n";
		}
	}
	
	if (-e "$server_datapath$d_data_file") {
		if (($whattodo eq "addentry") && ($exists_upload eq "upload")) {   # Upload File
			if ($upload_path && $upload_url && $upload_file) {
				$upload_file_only = $upload_file;
				$upload_file_only =~ s!^.*(\\|\/)!!;
				$upload_filenamelength = length($upload_file_only);
				if ((lc(substr($upload_path,length($upload_path)-$upload_filenamelength,$upload_filenamelength))) eq $upload_file_only) {
					$message.="Don't add the filename to the upload-path. The path has been corrected automatically.<p>\n";
					$upload_path = lc(substr($upload_path,0,length($upload_path)-$upload_filenamelength));
				}
				if ((lc(substr($upload_url,length($upload_url)-$upload_filenamelength,$upload_filenamelength))) eq $upload_file_only) {
					$message.="Don't add the filename to the upload-URL. The URL has been corrected automatically.<p>\n";
					$upload_url = lc(substr($upload_url,0,length($upload_url)-$upload_filenamelength));
				}
				if (((lc(substr($upload_path,length($upload_path)-1,1))) ne "\\") || ((lc(substr($upload_path,length($upload_path)-1,1))) ne "/")) {
					# Check if NT or Linux-path
					if (index($upload_path,"/") == (-1)) {
						$upload_path.="\\";
					} else {
						$upload_path.="/";
					}
				}
				if ((lc(substr($upload_url,length($upload_url)-1,1))) ne "/") {
					$upload_url.="/";
				}
				my $req = new CGI; 
				my $file = $req->param('upload_file');
				if ($file ne "") {
					open (OUTFILE, ">$upload_path$upload_file_only") or ( print "<b>Critical Error:</b> Unable to save the uploaded file to the server. Check if the script has permission to write in the specified directory ($upload_path) and if it's CHMODed to 777 or 755.<br><br>\n" );
					binmode(OUTFILE);			# Required for NT-servers
					while (my $bytesread = read($file, my $buffer, 1024)) { 
						print OUTFILE $buffer; 
					} 
					close (OUTFILE); 
				}
				$new_url = $upload_url.$upload_file_only;
			} else {
				print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
				print "Form incomplete. For uploading a file you have to specify three things: The location of the file on your own computer, ";
				print "the absolute server-path where the script is supposed to upload the file (for example the server-path to Schlabo's Scripts is ";
				print "<i>$server_path</i>) and the URL of this path so that the browser will be able to find the file after it's uploaded. ";
				print "The server-path has to lead to the same place as the URL you specified.";
				print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
				&html_footer;
				if ($uselocking) { &masterlockclose; }
				return;
			}
		}

	
		$foundfile = 1;
		&lockopen(data,"$server_datapath$d_data_file","input");
		@tempdata = <data>;
		&lockclose(data,"$server_datapath$d_data_file");
		
		$max_num = @tempdata;
		
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
			$data[$count][0]=$temp_num;
			$data[$count][1]=$temp_file;
			$data[$count][2]=$temp_alias;
			
			if ($data[$count][1] eq $old_url) {
				if ($whattodo eq "removeentry") {
					$data[$count][0]="";
					$data[$count][1]="";
					$data[$count][2]="";
				} elsif ($whattodo eq "editentry") {
					$data[$count][0]=$new_dc;
					$data[$count][1]=$new_url;
					$data[$count][2]=$new_alias;
				}
			}

		}
	}
		
	# Write edited contents to file
		
	&lockopen(data,"$server_datapath$d_data_file","output");

	
	if ($foundfile == 1) {
		for ($count=0;$count<$max_num;$count++) {
			if ($data[$count][1]) {
				print data "$data[$count][2]|$data[$count][1]|$data[$count][0]\n";
			}
		}
	}
		
	if ($whattodo eq "addentry") {   # add the new file at the end of the file
		print data "$new_alias|$new_url|$new_dc\n";
	}
	
	&lockclose(data,"$server_datapath$d_data_file");
	
	if ($d_countaliastofile eq "on") {
		$calalias_silent = 1;
		&calculatealias;
	}
	$new_url_only = $new_url;
	$new_url_only =~ s!^.*(\\|\/)!!;
	$old_url_only = $old_url;
	$old_url_only =~ s!^.*(\\|\/)!!;
	
	
	print "<br><font size=3 color=#FFCC00><b>Success</b></font><br><br>\n";
	if ($message ne "<b>Warning:</b> ") {print $message }
	if ($whattodo eq "removeentry") {print "The file $old_url_only has been removed from the database. Please note that the file has not been deleted from the server.\n" }
	if ($whattodo eq "addentry") {
		print "The file $new_url_only has been ";
		if ($exists_upload eq "upload") { print "uploaded and " }
		print "added to the database.<p>\n";
		print "<br>Here are samples of how to link to the file<br>\n";
		print "<img src=\"${images_url}arrow.gif\" width=\"4\" height=\"7\" align=\"middle\">&nbsp;<a href=\"http://www.schlabo.com/install/dl/\" target=\"blank\">More Information</a><br><br>";
		if ($d_antileech eq "on") {
			print "As Leech-Protection is activated, only the Alias-method (3) is useful.<br><br>\n";
		}
		print "<b>1. Linking to the modified URL:</b><br>\n";
		$filename_part1 = substr($new_url,0,(length($new_url)-length($new_url_only)));
		$filename_part3 = $new_url_only;
		$filename_part3 =~ s!^.*(\.)!!;
		$filename_part2 = substr($new_url_only,0,(length($new_url_only)-length($filename_part3)-1));
		$new_alias2 = $new_alias;
		if ($d_autoreplace eq "on") {
			$new_alias2 =~ s/\ /_/g;
		}
		print "<small>\n&lt;a href=\"$server_url$d_script_url?$filename_part1$filename_part2---$filename_part3\"&gt;$new_alias&lt;/a&gt;\n</small><p>\n";
		print "<b>2. Linking to the real URL:</b><br>\n";
		print "<small>\n&lt;a href=\"$server_url$d_script_url?$new_url\"&gt;$new_alias&lt;/a&gt;\n</small><p>\n";
		print "<b>3. Linking to the Alias:</b><br>\n";
		print "<small>\n&lt;a href=\"$server_url$d_script_url?$new_alias2\"&gt;$new_alias&lt;/a&gt;\n</small><br>\n";
	}
	print "<form action=\"$server_url$d_admin_url?action=showlogs\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<input type=\"hidden\" name=\"r_showmethod\" value=\"sm_urls\">\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to view the updated log.<p>\n";
	print "</form><br>\n";
	&html_footer;
	if ($uselocking) { &masterlockclose; }
	return;
}

sub calculatealias {
	if (-e "$server_datapath$d_data_file") {
		&lockopen(data,"$server_datapath$d_data_file","input");
		@tempdata = <data>;
		&lockclose(data,"$server_datapath$d_data_file");
		
		$aliascount=0;
		
		$totalcount=0;
		$countup = 0;
		
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
			
			$found=0;
			for ($count2=0;$count2<$countup;$count2++) {
				if ($temp_alias eq $data[$count2][2]) {   # Alias already found
					$data[$count2][0] = $data[$count2][0] + $temp_num;
					$found=1;
				}
			}
			if ($found==0) {
				$data[$countup][0]=$temp_num;
				$data[$countup][1]=$temp_file;
				$data[$countup][2]=$temp_alias;
				$countup = $countup + 1;			
			}
		}
		$max_num = $countup;
			
		for ($count=0;$count<$max_num;$count++) {
			$filename = $data[$count][2];
			$filename =~ s/(\W)//g;
			open(aliasfile,">${d_countaliaspath}${filename}.txt") || &showerror("Unable to create Alias-Count-File. Make sure the directory you specified in the configuration ( <i>${d_countaliaspath}</i> ) exists and is CHModed to 777.");
			print aliasfile "$data[$count][0]";
			close(aliasfile);
		}
		
		if (!$calalias_silent) {
			&html_header;
			print "<br><font size=3 color=#FFCC00><b>Success</b></font><br><br>\n";
			print "You have successfully created the Alias-Files.\n";
		}
		
	} else {
		if (!$calalias_silent) {
			&html_header;
			print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
			print "Data-File not found. You can only create Alias-Files when you have a database.\n";
		}
	}
	if (!$calalias_silent) {
		print "<form action=\"$server_url$d_admin_url?action=showlogs\" method=\"post\">\n";
		print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
		print "<input type=\"hidden\" name=\"r_showmethod\" value=\"sm_alias\">\n";
		print "Click ";
		print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
		print " to return to the logs.<p>\n";
		print "</form>\n";
		print "<br><br><br><br>\n";
		&html_footer;
	}
}

sub viewleechlog {
	$viewlatest = $QUERY{'viewlatest'};
	&html_header;
	if ($d_antileech ne "on") {
		print "<br><font size=3 color=#FFCC00><b>Leech-Protection not Activated</b></font><br><br>\n";
		print "<p>You did not activate the Leech-Protection, therefore forbidden accesses to files on your server are not logged. If you want to do that, please activate it in the DL-Configuration!<p>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}
	if (-e "$server_datapath$d_leech_file") {
		open(leechfile,"<$server_datapath$d_leech_file");
		@all_data = <leechfile>;
		close(leechfile);
		$max_num = @all_data;
	} else {
		print "<br><font size=3 color=#FFCC00><b>Leech-Tracking-File not Found</b></font><br><br>\n";
		print "<p>The Leech-Tracking-file (\"<i>$d_leech_file</i>\") wasn't found. If you just activated Leech-Protection it might not have been created yet, it will be automatically created when the first unauthorized access is logged.<p>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}
	print qq|
	<br><font size=3 color="#FFCC00"><b>Leech-Tracking</b></font><br><br>
	Schlabo's Scripts track each unauthorized attempt from other sites to steal your files. Below you can see the exact date, time and source of each access that was blocked by the scripts.<p>|;
	if (($max_num > $viewlatest) && ($viewlatest ne "") && ($viewlatest ne "0")) {
		print qq|
		<form action="$server_url$d_admin_url?action=viewleechlog&viewlatest=0" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		On this page you can see the latest $viewlatest entries, to view the full logs click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here">.
		<p>
		|;
	}
	if ($all_data) {
		print qq|
		<br><form action="$server_url$d_admin_url?action=reset_log_query" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> to reset the logs.</form><p>
		<br><font color="#FFCC00">Logs</font><br><hr noshade>
		</font></p><table><tr>
		<td><font face="Verdana, Arial, Helvetica" size="2"><b>Date</b></font></td>
		<td><font face="Verdana, Arial, Helvetica" size="2"><b>Time</b></font></td>
		<td><font face="Verdana, Arial, Helvetica" size="2"><b>Site</b></font></td>
		</tr>
		|;
		$td_open = "<td><font face=\"Verdana, Arial, Helvetica\" size=\"1\">";
		$td_close = "</font></td>\n";
		if ($viewlatest == 0) {
			$countto=0;
		} else {
			$countto = $max_num-$viewlatest;
			if ($countto < 0) {$countto=0}
		}
		for ($count=($max_num-1);$count>=$countto;$count--) {
			if (($count % 2)==0) {
				print "<tr bgcolor=#276B2E>";
			} else {
				print "<tr>";
			}
			$curline = @all_data[$count];
			($leech_date, $leech_time, $leech_site) = split (/ - /, $curline);
			print $td_open.$leech_date.$td_close.$td_open.$leech_time.$td_close.$td_open.$leech_site.$td_close;
			print "</tr>";
		}
		print "</table>";
	} else {
		print "<p><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>Logs empty.</b></font></p>\n";
	}
	&html_footer;
		
	
}

sub reset_log_query {
	&html_header;
	print qq|
	<br><font size=3 color="#FFCC00"><b>Reset Leech-Logs</b></font><br><br>
	<form action="$server_url$d_admin_url?action=reset_log" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<p>Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> if you really want to reset the leech logs. This can not be undone.</form></p>
	Press the Back-button of your browser or <a href="javascript: history.back()">click here</a> if you do not want to reset the logs.<p>
	|;
	&html_footer;
}

sub reset_log {
	unless (open(leechfile,">$server_datapath$d_leech_file")) {
		print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
		print "<p>Unable to open the Antileech-file at <i>$server_datapath$d_leech_file</i>!<p>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		if ($uselocking) { &masterlockclose; }
		return;
	}		
	close(leechfile);
	&html_header;
	print qq|
	<br><font size=3 color="#FFCC00"><b>Reset Leech-Logs</b></font><br><br>
	<form action="$server_url$d_admin_url?action=viewleechlog" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<p>The Leech-Logs were reset. Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> to return to the DL Admin-script.<p>
	|;
	&html_footer;
}
	

sub bubblesort {
	$resorted = 0;
	for ($i=$max_num;$i>=0;$i--) {
		for ($j=0;$j<=$i;$j++) {
			if ($data[$j][0] < $data[$j+1][0]) {
				$temp0 = $data[$j][0];
				$temp1 = $data[$j][1];
				$temp2 = $data[$j][2];
				$data[$j][0] = $data[$j+1][0];
				$data[$j][1] = $data[$j+1][1];
				$data[$j][2] = $data[$j+1][2];
				$data[$j+1][0] = $temp0;
				$data[$j+1][1] = $temp1;
				$data[$j+1][2] = $temp2;
				$resorted = 1;
			}
		} 
	}
}

sub bubblesort2 {
	$resorted = 0;
	for ($i=$max_num2;$i>=0;$i--) {
		for ($j=0;$j<=$i;$j++) {
			if ($data2[$j][0] < $data2[$j+1][0]) {
				$temp0 = $data2[$j][0];
				$temp1 = $data2[$j][1];
				$temp2 = $data2[$j][2];
				$data2[$j][0] = $data2[$j+1][0];
				$data2[$j][1] = $data2[$j+1][1];
				$data2[$j][2] = $data2[$j+1][2];
				$data2[$j+1][0] = $temp0;
				$data2[$j+1][1] = $temp1;
				$data2[$j+1][2] = $temp2;
				$resorted = 1;
			}
		} 
	}
}

sub bubblesort_a {
	$resorted = 0;
	for ($i=$a_number;$i>=0;$i--) {
		for ($j=0;$j<=$i;$j++) {
			if ($a_data[$j][0] < $a_data[$j+1][0]) {
				$temp0 = $a_data[$j][0];
				$temp1 = $a_data[$j][1];
				$temp2 = $a_data[$j][2];
				$a_data[$j][0] = $a_data[$j+1][0];
				$a_data[$j][1] = $a_data[$j+1][1];
				$a_data[$j][2] = $a_data[$j+1][2];
				$a_data[$j+1][0] = $temp0;
				$a_data[$j+1][1] = $temp1;
				$a_data[$j+1][2] = $temp2;
				$resorted = 1;
			}
		} 
	}
}

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	} else {	# Input
		open (FILE,"<$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			&showerror("The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}dl_masterlock.lok")
	  && ((stat("${server_datapath}dl_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}dl_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}dl_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access dl_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}dl_masterlock.lok") {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
}

sub showerror {
	if ($uselocking) { &masterlockclose; }
	&html_header;
	print "@_";
	&html_footer;
	exit;
}

sub init_questions {
	
	$question[0] = "What's the use of the database?";
	$question[1] = "How do I add files to the database?";
	$question[2] = "How does file-uploading work?";
	$question[3] = "How can I track a file with the DL-Script?";
	$question[4] = "What does the Anti-Leech-Feature do?";
	$question[5] = "How can I display how often a file has already been downloaded?";
	$question[6] = "How do the Alias-Count Datafiles work? ";
	$question[7] = "Is it possible to display the total amount of downloads and files?";
	$question[8] = "What if I want to edit or remove an entry?";
	$question[9] = "How do I use the Guest-Stats?";
	$question[10] = "Is it possible to include a Top xx-list in my site?";
	$question[11] = "How can I use multiple mirrors for one file?";
	
}
