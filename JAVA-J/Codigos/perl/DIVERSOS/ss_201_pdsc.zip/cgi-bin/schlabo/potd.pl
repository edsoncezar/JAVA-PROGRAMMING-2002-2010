#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_potd.pl";

umask (0111);

print "Content-type: text/html\n\n";

&parse_query;
&get_date;

if ($QUERY{'day'}) {
	$cal_day=$QUERY{'day'};
	$cal_month=$QUERY{'month'};
	$cal_year=$QUERY{'year'};
	if (($cal_day == $month_day) && ($cal_month == $m) && ($cal_year == $y)) { $searchdir = 0 } else { $searchdir = 1 }
} else {
	$cal_day=$month_day;
	$cal_month=$m;
	$cal_year=$y;
}

$cur_date=$cal_month."-".$cal_day."-".$cal_year;
$filename="potd_".$cal_month."-".$cal_year.".txt";
# Check if specified date is not in the future..
$m2=$m;
if (length($m2) eq "1") {
	$m2 = "0".$m;
}
$month_day2=$month_day;
if (length($month_day2) eq "1") {
	$month_day2="0".$month_day;
}
$testnow = $y.$m2.$month_day2;
$cal_day2=$cal_day;
if (length($cal_day2) eq "1") {
	$cal_day2="0".$cal_day2;
}
if (length($cal_month) eq "1") {
	$testnew = $cal_year."0".$cal_month.$cal_day2;
} else {
	$testnew = $cal_year.$cal_month.$cal_day2;
}
$dontallow = "0";
if ($testnow < $testnew) {      # Next picture is from the future, so don't display a link to it
	$dontallow = "1";
}

if ($uselocking) { &masterlockopen; }

open(data,"<$server_datapath$filename");
@all_data = <data>;
close(data);

$max_num = @all_data;

for ($count=0;$count<$max_num;$count++) {
	$pic_data = @all_data[$count];
	($pic_date,$pic_url,$pic_filename,$pic_info,$pic_source_email,$pic_source) = split(/::/,$pic_data);
	($c_month,$c_day,$c_year) = split(/-/,$pic_date);
	$cur_month[$c_day][0]=$pic_filename;
	$cur_month[$c_day][1]=$pic_url;
	$cur_month[$c_day][2]=$pic_info;
	$cur_month[$c_day][3]=$pic_date;
	$cur_month[$c_day][4]=$pic_source_email;
	$cur_month[$c_day][5]=$pic_source;
}

if ($cur_month[$cal_day][0] eq "") {
	#check if a pic is set for this day!
	$dontallow = "1";
}

open(tfile, "<$server_path$p_potdtemplate");
@potdtemplate =<tfile>;
close(tfile);

&back_next;

if ($uselocking) { &masterlockclose; }

&ext_header;


if ($dontallow eq "0") {
	print "<table width=\"10\" border=0><tr><td align=\"center\">";
	print "<font face=\"$font_type\" size=\"2\">$cur_month[$cal_day][2]<br><br></font>\n";
	print "</td></tr><tr><td align=\"center\">";
	print "<img src=\"$cur_month[$cal_day][1]$cur_month[$cal_day][0]\" alt=\"$cur_month[$cal_day][2]\"><br><br>\n";
	print "<font face=\"$font_type\" size=\"1\"><i>\n";
	if (($cur_month[$cal_day][4] ne "") && ($cur_month[$cal_day][5] ne "")) {
		if (index($cur_month[$cal_day][4], "@") == (-1)) {			# URL
			if (index($cur_month[$cal_day][4], "http://") == (-1)) {	# User forgot to add http://
				$cur_month[$cal_day][4] = "http://".$cur_month[$cal_day][4];
			}
			print "Submitted by: <a href=\"".$cur_month[$cal_day][4]."\">$cur_month[$cal_day][5]</a><br>\n";
		} else {								# Email-Address
			print "Submitted by: <a href=\"mailto:".$cur_month[$cal_day][4]."\">$cur_month[$cal_day][5]</a><br>\n";
		}
	} elsif (($cur_month[$cal_day][4] eq "") && ($cur_month[$cal_day][5] ne "")) {
		print "Submitted by: $cur_month[$cal_day][5]<br>\n";
	}
	print "</i></font></tr></table>";
} else {
	print "<p align=\"center\"><font face=\"$font_type\" size=\"2\">Sorry, there is no picture for this day.</font></p>\n";
}

if ($p_newwindow eq "on") {
	print "<script language='JavaScript'>\n";
	print "function closeIt() {\n";
	print "  close();\n";
	print "}\n";
	print "</script>\n";
	print "<p align=\"center\"><form><input type=button value='Close' onClick='closeIt()' style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\"></form></p>\n";
}

# Ok.. so you got this script for free. Can you imagine
# how long it took me to code all that? About 350 kB of
# pure Perl-Code? And you can't say that this script is
# bad. You get all my work completely free,so is it too
# much if I ask you to leave this link in? Please don't
# remove it, so that others can also find out where the
# script is from and help spreading the script. Because
# you know:  The more people use Schlabo's Scripts, the
# more am I motivated to improve it! Thanks!
print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's POTD v$p_version</font></a></p>\n";
&ext_footer;





sub back_next {
	&find_previous;
	if ($found eq "1") {
		$back_link = "<a href=\"$server_url$p_script_url?day=$prev_day&month=$prev_month&year=$prev_year\"><< Previous Picture</a>\n";
	}
	&find_next;
	if ($found eq "1") {
		$next_link = "<a href=\"$server_url$p_script_url?day=$next_day&month=$next_month&year=$next_year\">Next Picture >></a>\n";
	}
	if ($p_galleryon eq "on") {
		$gallery_link = "<a href=\"$server_url$p_galleryscript?to_day=$cal_day&to_month=$cal_month&to_year=$cal_year";
		if ($searchdir == 1) { $gallery_link.="&dir=up" }
		$gallery_link.="\">Gallery</a>\n";
	}
}

sub parse_query {
	@pairs = split(/&/, $ENV{'QUERY_STRING'});
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$QUERY{$name} = $value;
	}
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}

sub find_previous {
	$found="0";
	$filename="potd_".$cal_month."-".$cal_year.".txt";
	&clear_tempcal;
	if (-e "$server_datapath$filename") {
		open(data,"<$server_datapath$filename");      # Put contents of file into an array
		@all_data = <data>;
		close(data);
		$max_num = @all_data;
		# The above array was sorted by entries, now put it into another one sorted by days ($tempcal[])
		for ($count_d=$max_num;$count_d>(-1);$count_d--) {
			$temp_pic_data = @all_data[$count_d];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
			if (($temp_day ne "") && ($temp_day < $cal_day)) {
				$prev_day=$temp_day;
				$prev_month=$temp_month;
				$prev_year=$temp_year;
				$found="1";
				last;
			}
		}
	}
	if ($found eq "0") {        # If no free space in the current month, search months of the rest of the year
		$t_month=$cal_month;
		$t_year=$cal_year;
		for ($countup=0;$countup<$p_goback;$countup++) {
			$t_month=$t_month-1;
			if ($t_month eq "0") {
				$t_month=12;
				$t_year=$t_year-1;
			}
			&clear_tempcal;
			$filename="potd_".$t_month."-".$t_year.".txt";
			if (-e "$server_datapath$filename") {
				open(data,"<$server_datapath$filename");      # Put contents of file into an array
				@all_data = <data>;
				close(data);
				$max_num = @all_data;
				for ($count_d=$max_num;$count_d>(-1);$count_d--) {
					$temp_pic_data = @all_data[$count_d];
					($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
					($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
					if ($temp_pic_date ne "") {
						$prev_day=$temp_day;
						$prev_month=$temp_month;
						$prev_year=$temp_year;
						$found="1";
						last;
					}
				}
			}
			if ($found eq "1") {
				last;
			}
		}
	}
	# Check if specified date is not in the future..
	if ($found eq "1") {
		$testnow = $y.$m2.$month_day2;
		$prev_day2=$prev_day;
		if (length($prev_day2) eq "1") {
			$prev_day2="0".$prev_day;
		}
		if (length($prev_month) eq "1") {
			$testnew = $prev_year."0".$prev_month.$prev_day2;
		} else {
			$testnew = $prev_year.$prev_month.$prev_day2;
		}
		if ($testnow < $testnew) {      # Next picture is from the future, so don't display a link to it
			$found = "0";
		}
	}
}

sub find_next {
	$found=0;
	$filename="potd_".$cal_month."-".$cal_year.".txt";
	&clear_tempcal;
	if (-e "$server_datapath$filename") {
		open(data,"<$server_datapath$filename");      # Put contents of file into an array
		@all_data = <data>;
		close(data);
		$max_num = @all_data;
		# The above array was sorted by entries, now put it into another one sorted by days ($tempcal[])
		for ($count_d=0;$count_d<$max_num;$count_d++) {
			$temp_pic_data = @all_data[$count_d];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
			if (($temp_day ne "") && ($temp_day > $cal_day)) {
				$next_day=$temp_day;
				$next_month=$temp_month;
				$next_year=$temp_year;
				$found="1";
				last;
			}
		}
	}
	if (($found eq "0") && !(($cal_month eq $m) && ($cal_year eq $y))) {        # If no free space in the current month, search months of the rest of the year
		$t_month=$cal_month;
		$t_year=$cal_year;
		for ($countup=0;$countup<$p_maxgoforward;$countup++) {
			$t_month=$t_month+1;
			if ($t_month eq "13") {
				$t_month=1;
				$t_year=$t_year+1;
			}
			
			&clear_tempcal;
			$filename="potd_".$t_month."-".$t_year.".txt";
			if (-e "$server_datapath$filename") {
				open(data,"<$server_datapath$filename");      # Put contents of file into an array
				@all_data = <data>;
				close(data);
				$max_num = @all_data;
				for ($count_d=0;$count_d<$max_num;$count_d++) {
					$temp_pic_data = @all_data[$count_d];
					($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
					($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
					if ($temp_pic_date ne "") {
						$next_day=$temp_day;
						$next_month=$temp_month;
						$next_year=$temp_year;
						$found="1";
						last;
					}
				}
			}
			if ($found eq "1") {
				last;
			}
		}
	}
	# Check if specified date is not in the future..
	if ($found eq "1") {
		$testnow = $y.$m2.$month_day2;
		$next_day2=$next_day;
		if (length($next_day2) eq "1") {
			$next_day2="0".$next_day;
		}
		if (length($next_month) eq "1") {
			$testnew = $next_year."0".$next_month.$next_day2;
		} else {
			$testnew = $next_year.$next_month.$next_day2;
		}
		if ($testnow < $testnew) {      # Next picture is from the future, so don't display a link to it
			$found = "0";
		}
	}
}

sub clear_tempcal {
	for ($count=1;($count<32);$count++) {
		$tempcal[$count]="";
	}
}

sub ext_header {
	# Print the beginning of the document

	foreach $line (@potdtemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		$line =~ s/\[\!cur_date\]/$cur_date/g;
		$line =~ s/\[\!next_link\]/$next_link/g;
		$line =~ s/\[\!back_link\]/$back_link/g;
		$line =~ s/\[\!gallery_link\]/$gallery_link/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		print "$line";
	}

}

sub ext_footer {
	# Print the footer of the document
	
	$flag = 0;
	foreach $line (@potdtemplate) {
		if($flag) {
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			$line =~ s/\[\!cur_date\]/$cur_date/g;
			$line =~ s/\[\!next_link\]/$next_link/g;
			$line =~ s/\[\!back_link\]/$back_link/g;
			$line =~ s/\[\!gallery_link\]/$gallery_link/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
			$flag = 1;
		}
		

	}
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}potd_masterlock.lok")
	  && ((stat("${server_datapath}potd_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}potd_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}potd_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access potd_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}potd_masterlock.lok") {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
}
