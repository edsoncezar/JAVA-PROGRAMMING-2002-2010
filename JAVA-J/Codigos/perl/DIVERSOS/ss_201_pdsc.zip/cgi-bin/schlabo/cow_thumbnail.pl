#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_cow.pl";

umask (0111);

print "Content-type: text/html\n\n";

&get_date;
$curtimecode = &calculatetimecode($y,$m,$month_day);

&read_data_file;

$maxweek = 0;
for ($count=0;$count<=($c_weeks_total-1);$count++) {
	if ($c_weeks[$count][0] <= $curtimecode) {
		$maxweek = $maxweek + 1;
		$maxhowmany = $c_weeks[$count][4];
	}
}

if ($maxweek>0) {
	$curcowline = "<font face=\"$font_type\" size=\"1\"><a href=\"$server_url$c_script_url\"><img src=\"".$c_cow_url.$c_thumbtag.$c_files.$maxweek.".".$c_extension."\" ";
	$curcowline = $curcowline."alt=\"Current Week: ".$maxweek."\" border=0></a><br>Week: $maxweek</font>";
	print $curcowline;
} else {
	print "<font face=\"$font_type\" size=\"1\"><b>Sorry, no comic to display.</b></font>";
}

sub read_data_file {
	if (-e "$server_datapath$c_data_file") {
		open(data,"<$server_datapath$c_data_file");
		@tempdata = <data>;
		close(data);
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_timecode,$temp_year,$temp_month,$temp_day,$temp_howmany) = split(/\|/,$temp_data);
			$c_weeks[$count][0] = $temp_timecode;
			$c_weeks[$count][1] = $temp_year;
			$c_weeks[$count][2] = $temp_month;
			$c_weeks[$count][3] = $temp_day;
			$c_weeks[$count][4] = $temp_howmany;
		}
		$c_weeks_total=$max_num;
	} else {
		open(data,">$server_datapath$c_data_file");
		$c_weeks_total = 0;
		$c_weeks[0][0]=0;
		close(data);
	}
}

sub calculatetimecode {
	$ctc = (($_[0] - 2000) * 365) + $_[2];
	if ($_[1]>1) {
		for ($ctc_count=0;$ctc_count<($_[1]-1);$ctc_count++) {
			$ctc = $ctc + $months_days[$ctc_count];
		}
	}
	return($ctc);
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}
