#!/usr/bin/perl

use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# -------------------------------------------------------------------------------------
# SP-Specific

# Filename of the SP-Script
$s_script_url = "sp.pl";

# Link used if no other URL is specified in the parameters when you call the SP-script and
# if the script is unable to determine the page the visitor came from.
$s_backlinkurl = "http://localhost/";

# Automatically replace "_" with " " in the Picture-descriptions
$s_autoreplace = "on";

# Pictures-URL (use this only if all/most of them are stored in the same dir)
$s_pic_url = "http://www.yoursite.com/images/";

# Picture-Serverpath (same direcory as above, only this time not the URL but the absolute server-path)
$s_pic_path = "/usr/home/yoursite/htdocs/images/";

# Activate Picture-Counting
$s_counting = "on";

# If a picture is not found in the database, add it (on) or don't allow displaying the picture
# (off, you have to add new pictures manually using the Admin-script then, but it prevents people
# from entering wrong URLs and creating useless entries in the log-files.
$s_autoadd = "on";

# Notify you per email when someone tries to download a file that's not in the Database
# (Only if autoadd = "on")
$s_notifymissing = "on";

# Database-file (only needed if Picture-Counting is activated)
$s_data_file = "sp_data.txt";

# Filename of the Template-File for the DL-Pages
$s_sptemplate = "template_sp.txt";

# Guest-Stats-Status (0=Show All; 1,2,3,...=Show only Top xx;-=Deny)
$s_gueststatus = "0";

# Filename of the Guest-Stats-Script (if in use)
$s_gueststatsscript = "sp_gueststats.pl";

# Message to display in front of the SP (for sp_showsc.pl)
$s_showscmessagebefore = "<br><font face=\"Verdana, Arial, Helvetica\" size=\"1\"><i>(Has already been shown ";
# 2nd Part of Message (after the number)
$s_showscmessageafter = " times. <a href=\"http://www.yoursite.com/cgi-bin/schlabo/sp_gueststats.pl\">View full logs</a>)</i></font>";

# Message to display in front of the Total SP (for sp_showtotalsc.pl)
$s_showtotalscmessagebefore = "<b>Total number of shown pictures:</b> ";
$s_showtotalscmessagemiddle = "<br><b>Number of available pictures:</b> ";
$s_showtotalscmessageafter = "<br>(<a href=\"http://www.yoursite.com/cgi-bin/schlabo/sp_gueststats.pl\">View full logs</a>)";

# Filename of the Template-File for the Gueststats
$s_statstemplate = "template_sp_gueststats.txt";

# Version of this script, do not alter the variable
$s_version = "2.01";

1;
