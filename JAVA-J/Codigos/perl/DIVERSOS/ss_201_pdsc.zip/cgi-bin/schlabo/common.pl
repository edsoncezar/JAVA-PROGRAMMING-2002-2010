#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01a            ##
##         last modified: 14/02/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# These are subroutines used by many of the scripts

sub check_referer {
	if ($referers) {
		local($check_referer) = 0;
		if ($ENV{'HTTP_REFERER'}) {
			foreach $referer (@referers) {
				if ($ENV{'HTTP_REFERER'} =~ m|https?://([^/]*)$referer|i) {
					$check_referer = 1;
					last;
				}
			}
		}
		else {
			$check_referer = 0;
		}
		if ($check_referer != 1) {
			$hidemenu = 1;
			&html_header;
			print "<br><font size=3 color=#FFCC00><b>Bad Referer</b></font><br><br>\n";
			print "You are not allowed to use this script from another server.<br>\n";
			print "<br><br><br><br>\n";
			&html_footer;
			exit;
		}
	}
}

sub parse_query {
	@pairs = split(/&/, $ENV{'QUERY_STRING'});
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$QUERY{$name} = $value;
	}
}

sub showlogin {
	$hidemenu = 1;
	&get_password;
	if ($pw_crypted) {	# Cookies found, user automatically logged in
		if ($trackip eq "on") {
			open(FILE, ">>$server_datapath$trackfile");
			print FILE $m."-".$month_day."-".$y." - ".$Hour.":".$Minute.":".$Second." - ".$ENV{'REMOTE_ADDR'}." - ".$hostname." - User $user_names[$cur_user_number] Logged in to $scriptname (cookies).\n";
			close(FILE);
		}
		print "Location: $server_url";
		if ($scriptname eq "admin") {
			print $g_admin_url;
		} elsif ($scriptname eq "potd") {
			print $p_admin_url;
		} elsif ($scriptname eq "dl") {
			print $d_admin_url;
		} elsif ($scriptname eq "sp") {
			print $s_admin_url;
		} elsif ($scriptname eq "cow") {
			print $c_admin_url;
		}
		print "?action=showadmin\n\n";
		exit;
	}
	&html_header;
	print qq|
		<br><font size=3 color="#FFCC00"><b>Login</b></font><br><br>
		This script is password-protected. Please enter your username and password to verify your identity:<p>
		<form action="$server_url|;
		if ($scriptname eq "admin") {
			print $g_admin_url;
		} elsif ($scriptname eq "potd") {
			print $p_admin_url;
		} elsif ($scriptname eq "dl") {
			print $d_admin_url;
		} elsif ($scriptname eq "sp") {
			print $s_admin_url;
		} elsif ($scriptname eq "cow") {
			print $c_admin_url;
		}
	print qq|?action=showadmin" method="post">
		<input type="hidden" name="comingfromlogin" value="1">
		<b>Username:</b><br>
		<input type="username" size="35" name="username" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		<b>Password:</b><br>
		<input type="password" size="35" name="pw" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		<input type="checkbox" name="savecookie" checked>&nbsp;Remember me (requires activated cookies)<br><br>
		<input type="submit" name="submit" value="Login" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
		</form>
	|;
	&html_footer;
	exit;
}

sub get_password {
	if($trackip ne "") {
		&iptrack;
	}
	&GetCookies;
	
	if ($cookies{'schlabo_user'}) {
		$use_cookies = 1;
	}
			
	if (($hidemenu ne "1") || (($hidemenu == 1) && ($use_cookies == 1))) {
		if ($use_cookies == 1) {
			$param_pw = $cookies{'schlabo_pass'};
			$param_username = $cookies{'schlabo_user'};
		} else {
			$param_pw = param('pw');
			$param_username = param('username');
		}
		# Search specified user
		$user_number = @user_names;
		$cur_user_number = (-1);
		for ($user_count=0;$user_count<($user_number);$user_count++) {
			if ($user_names[$user_count] eq $param_username) {
				$cur_user_number = $user_count;
				last;
			}
		}
		if ($use_cookies == 1) {
			$pw_crypted = $param_pw;
		} else {
			if ($crypted_passwords eq "on") {		# Crypted Passwords
				if ($cookies{'schlabo_pass'}) { 
					$pw_crypted = crypt($param_pw,$cookies{'schlabo_pass'});
				} else {
					$pw_crypted = crypt($param_pw,$user_passwords[$cur_user_number]);
				}
			} else {								# Plain Passwords - no encryption necessary
				$pw_crypted = $param_pw;
			}	
		}
		if (($pw_crypted ne $user_passwords[$cur_user_number]) || ($cur_user_number == (-1))) {
			if (($trackip ne "") && (param('comingfromlogin') eq "1")) {
				open(FILE, ">>$server_datapath$trackfile");
				print FILE $m."-".$month_day."-".$y." - ".$Hour.":".$Minute.":".$Second." - ".$ENV{'REMOTE_ADDR'}." - ".$hostname." - User tried to log in to $scriptname with this password: \"".param('pw')."\"\n";
		 		close(FILE);
		   	}
		   	$hidemenu = 1;
		   	&ClearCookies;
			&html_header;
			print "<br><font size=3 color=#FFCC00><b>Wrong Password</b></font><br><br>\n";
			print "The password you entered was not correct.<br>\n";
			print "Click <a href=\"?action=login\">here</a> to try again.<br>\n";
			print "<br><br><br><br>\n";
			&html_footer;
			exit;
		}
		if (($trackip ne "") && (param('comingfromlogin') eq "1")) {
			open(FILE, ">>$server_datapath$trackfile");
			print FILE $m."-".$month_day."-".$y." - ".$Hour.":".$Minute.":".$Second." - ".$ENV{'REMOTE_ADDR'}." - ".$hostname." - User $user_names[$cur_user_number] Logged in to $scriptname.\n";
			close(FILE);
		}
	}

	if ((param('comingfromlogin') == 1) && (param('savecookie') eq "on")) {
		# Set Cookies
		&SetCookies('schlabo_user',$param_username,'schlabo_pass',$pw_crypted);
	}
}

sub logout {
	&GetCookies;
	if (($cookies{'schlabo_pass'}) || ($cookies{'schlabo_user'})) {
		&ClearCookies;
		$cookies_cleared = 1;
	}
	if ($trackip eq "on") {
		&iptrack;
		open(FILE, ">>$server_datapath$trackfile");
		print FILE $m."-".$month_day."-".$y." - ".$Hour.":".$Minute.":".$Second." - ".$ENV{'REMOTE_ADDR'}." - ".$hostname." - User $user_names[$cur_user_number] Logged out.\n";
		close(FILE);
	}
	$hidemenu = 1;
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>Logged Out</b></font><br><br>\n";
	print "You have been logged out.<br>\n";
	if ($cookies_cleared == 1) {
		print "The cookies have been deleted, you will have to log in again next time you'll use Schlabo's Scripts.<br>\n";
	}	
	print "<br>";
	print "Click <a href=\"$server_url$g_admin_url?action=login\">here</a> to log in again.<br><br>\n";
	&html_footer;
	exit;
}
		

sub GetCookies {
	# Load Encode/Decode Data
	@Cookie_Encode_Chars = ('\%', '\+', '\;', '\,', '\=', '\&', '\:\:', '\s');
	
	%Cookie_Encode_Chars = ('\%',   '%25',
	                        '\+',   '%2B',
	                        '\;',   '%3B',
	                        '\,',   '%2C',
	                        '\=',   '%3D',
	                        '\&',   '%26',
	                        '\:\:', '%3A%3A',
	                        '\s',   '+');
	
	@Cookie_Decode_Chars = ('\+', '\%3A\%3A', '\%26', '\%3D', '\%2C', '\%3B', '\%2B', '\%25');
	
	%Cookie_Decode_Chars = ('\+',       ' ',
	                        '\%3A\%3A', '::',
	                        '\%26',     '&',
	                        '\%3D',     '=',
	                        '\%2C',     ',',
	                        '\%3B',     ';',
	                        '\%2B',     '+',
	                        '\%25',     '%');
	local($cookie,$value);
	if ($ENV{'HTTP_COOKIE'}) {
		foreach (split(/; /,$ENV{'HTTP_COOKIE'})) {
			($cookie,$value) = split(/=/);
			foreach $char (@Cookie_Decode_Chars) {
				$cookie =~ s/$char/$Cookie_Decode_Chars{$char}/g;
				$value =~ s/$char/$Cookie_Decode_Chars{$char}/g;
			}
			$cookies{$cookie} = $value;
		}
	}
}

sub SetCookies {
	@Abbrev_Week_Days = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
	@Abbrev_Months = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	$cookieexp = 5184000;			# In seconds, 5184000 = 60 days
	local(@cookies) = @_;
	local($cookie,$value,$char);
	print "Content-type: text/html\n";
	while (($cookie,$value) = @cookies) {
		foreach $char (@Cookie_Encode_Chars) {
			$cookie =~ s/$char/$Cookie_Encode_Chars{$char}/g;
			$value =~ s/$char/$Cookie_Encode_Chars{$char}/g;
		}

		print 'Set-Cookie: ' . $cookie . '=' . $value . ';';
		$exptime = time + $cookieexp;		
		my ($c_Second,$c_Minute,$c_Hour,$c_Month_Day,$c_Month,$c_Year,$c_Week_Day,$c_IsDST) = (localtime($exptime))[0,1,2,3,4,5,6,8];
		if ($c_Month_Day < 10) {
			$c_Month_Day = "0$Month_Day";
		}
		$c_Year = $c_Year + 1900;
		$cookieexpires = "$Abbrev_Week_Days[$c_Week_Day], $c_Month_Day-$Abbrev_Months[$c_Month]-$c_Year 00:00:00 GMT";
		print ' expires=' . $cookieexpires . ';';
		print "\n";
		shift(@cookies); shift(@cookies);
	}
	print "\n";
	$headers_printed = 1;
}

sub ClearCookies {
	print "Content-type: text/html\n";
	print "Set-Cookie: schlabo_user=x; expires=Fri, 01-Dec-2000 00:00:00 GMT;\n";
	print "Set-Cookie: schlabo_pass=x; expires=Fri, 01-Dec-2000 00:00:00 GMT;\n\n";
	$headers_printed = 1;
}

sub iptrack {
	local($flag) = @_;
	$hostname = $ENV{'REMOTE_HOST'};
	if ($ENV{'REMOTE_HOST'} && ($ENV{'REMOTE_HOST'} !~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/)) {
		$hostname = $ENV{'REMOTE_HOST'};
	} else {
		&address_to_name ($ENV{'REMOTE_ADDR'});
	}
}

sub address_to_name {
    local ($address) = shift(@_);
    local (@octets);
    local ($name, $aliases, $type, $len, $addr);
    local ($ip_number);
    @octets = split ('\.', $address);
    $ip_number = pack ("CCCC", @octets[0..3]);
    ($name, $aliases, $type, $len, $addr) = gethostbyaddr ($ip_number, 2);
    if ($name) {
        $hostname = $name;
    }
    else {
        $hostname = $ENV{'REMOTE_ADDR'};
    }
}

sub showerror {
	# Close masterlock
	if (-e "${server_datapath}${scriptname}_masterlock.lok") {
		unlink ("${server_datapath}${scriptname}_masterlock.lok");
	}
	$hidemenu = 1;
	&html_header;
	print "@_";
	&html_footer;
	exit;
}

sub novalidquery {
	# Close masterlock
	if (-e "${server_datapath}$scriptname_masterlock.lok") {
		unlink ("${server_datapath}$scriptname_masterlock.lok");
	}
	$hidemenu = 1;    # Don't display Nav-menu
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>No Valid Query</b></font><br><br>\n";
	print "The parameter you tried to use was not recognized by the script.\n";		
	print "<br><br><br><br>\n";
	&html_footer;
	exit;
}

sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) = (localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}

sub html_header {
	if ($headers_printed ne "1") { print "Content-type: text/html\n\n" }
	print "<html><head><title>";
	if ($scriptname eq "admin") {
		print "Schlabo's Scripts - Admin";
	} elsif ($scriptname eq "potd") {
		print "Schlabo's Picture of the Day - Admin";
	} elsif ($scriptname eq "dl") {
		print "Schlabo's Download - Admin";
	} elsif ($scriptname eq "sp") {
		print "Schlabo's Show Picture - Admin";
	} elsif ($scriptname eq "cow") {
		print "Schlabo's Comic of the Week - Admin";
	}
	print qq|
	</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<style>
	<!--
	A:hover {color:#80FF80; text-decoration: underline}
	-->
	</style>
	<script language="javascript">
	<!--
	function MissingPic() {
		missingWindow = window.open("", "missingWindow", "toolbar=no,location=no,resizable=no,width=300,height=200");
		missingWindow.document.writeln("<html><head><title>Missing Images<\/title>");
		missingWindow.document.writeln("<script>");
		missingWindow.document.writeln("function doStuff() {");
		missingWindow.document.writeln("opener.location='$server_url$g_admin_url?action=conf_general&highlight=images_url&username=$param_username&pw=$param_pw#images_url';");
		missingWindow.document.writeln("close();");
		missingWindow.document.writeln("}");
		missingWindow.document.writeln("<\/script>");
		missingWindow.document.writeln("<\/head>");
		
		missingWindow.document.writeln("<body bgcolor='#274D2E' text='#FFFFFF' link='#00FF00' vlink='#33CC00' alink='#66FF66'>");
		missingWindow.document.writeln("<p align='center'><font face='Verdana, Arial, Helvetica' size='3' color='#FFCC00'><b>Images not found</b></font><br><br>");
		missingWindow.document.write("<font face='Verdana, Arial, Helvetica' size='2'>The URL to the images needed by the admin-scripts isn't set correctly. Please click on the button and ");
		missingWindow.document.writeln("specify the URL where you uploaded the images that came with the scripts.</font><br><br>");
		missingWindow.document.writeln("<input type='button' value='Set Images Path' onClick='javascript:doStuff()' style='font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)'><\/p>");
		missingWindow.document.writeln("<\/body><\/html>");
		missingWindow.document.close();
		missingWindow.focus();
	}
	// -->
	</script>
	</head>
	
	<body bgcolor="#000000" text="#FFFFFF" link="#00FF00" vlink="#33CC00" alink="#66FF66">
	<div align="center">
	
	<table width="100%" height="100%" border="0"><tr><td align="center">
	  <table width="500" border="0" bgcolor="#274D2E" cellspacing="2" cellpadding="2">
	    <tr>
	      <td width="108">
	      |;
	      print "<img src=\"${images_url}";
	      if ($scriptname eq "admin") {
	      	print "g_logo.gif";
	      } else {
		print "${scriptname}_logo.gif";
	      }
	      print "\" width=\"108\" height=\"67\" alt=\"Schlabo's Scripts - Admin\"";
	     
	      if (($scriptname eq "admin") && ($dowhat eq "showadmin")) {
	      	print " onError=\"javascript:MissingPic();\"";
	      }
	      print ">";
	      print qq|
	      </td>
	      <td width="392" valign="top">
	        <div align="center"> 
	          <p><font face="Verdana, Arial, Helvetica"><b><font size="1"><i>Schlabo's</i></font><br>
	            <font size="3" color="#FFCC00">
	            |;
	            if ($scriptname eq "admin") {
	            	print "Scripts";
	            } elsif ($scriptname eq "potd") {
	            	print "Picture of the Day";
	            } elsif ($scriptname eq "dl") {
	            	print "Download";
	            } elsif ($scriptname eq "sp") {
	            	print "Show Picture";
	            } elsif ($scriptname eq "cow") {
	            	print "Comic of the Week";
	            }
	            print qq|
	            </font><br>
	            <font size="2" color="#FFCC00">- admin -</font> </b></font></p>
	        </div>
	      </td>
	    </tr>
	    <tr>
	|;
	print "<td width=\"108\" valign=\"top\">";
	if ($hidemenu ne "1") {
		print qq|
		<font face="Verdana, Arial, Helvetica" size="1">
	      
	      User: $user_names[$cur_user_number].<br><a href="$server_url$g_admin_url?action=logout">Log Out</a><br><br></font>
	      
                    <table width="108" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="8"><img src="${images_url}arrow.gif" width="4" height="7"></td>
                        <td width="100"><font face="Verdana, Arial, Helvetica" size="1"><b>Scripts</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object|;
                        if (($p_installed ne "") or ($d_installed ne "") or ($s_installed ne "") or ($c_installed ne "")) { print "1" } else { print "2" }
                        print qq|.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=showadmin" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="schlabosscripts" src="${images_url}n_admin.gif" width=45 height=14 alt="Admin"></td></form>
                      </tr>
		|;
		if ($p_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object|;
                        if (($d_installed ne "") or ($c_installed ne "") or ($s_installed ne "")) { print "1" } else { print "2" }
                        print qq|.gif" width="8" height="16"></td>
                        <form action="$server_url$p_admin_url?action=calendar" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="potdadmin" src="${images_url}n_potd.gif" width=41 height=14 alt="POTD"></td></form>
                      </tr>
		|;
		}
		if ($d_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object|;
                        if (($c_installed ne "") or ($s_installed ne "")) { print "1" } else { print "2" }
                        print qq|.gif" width="8" height="16"></td>
                        <form action="$server_url$d_admin_url?action=showlogs" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="dladmin" src="${images_url}n_dl.gif" width=23 height=14 alt="DL"></td></form>
                      </tr>
		|;
		}
		if ($s_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object|;
                        if ($c_installed ne "") { print "1" } else { print "2" }
                        print qq|.gif" width="8" height="16"></td>
                        <form action="$server_url$s_admin_url?action=showadmin" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="spadmin" src="${images_url}n_sp.gif" width=23 height=14 alt="SP"></td></form>
                      </tr>
		|;
		}
		if ($c_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$c_admin_url?action=overview" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="cowadmin" src="${images_url}n_cow.gif" width=39 height=14 alt="COW"></td></form>
                      </tr>
		|;
		}
		print qq|
                    </table>
                    <br>
                    <table width="108" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="8"><img src="${images_url}arrow.gif" width="4" height="7"></td>
                        <td width="100"><font face="Verdana, Arial, Helvetica" size="1"><b>Help</b></font></td>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <td width="100"><a href="http://www.schlabo.com/" target="_blank"><img src="${images_url}n_homepage.gif" width=75 height=14 alt="Homepage" border=0></a></td>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=updates" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="checkupdates" src="${images_url}n_updates.gif" width=60 height=14 alt="Check for Updates"></td></form>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <td width="100"><a href="http://www.schlabo.com/install/" target="_blank"><img src="${images_url}n_docs.gif" width=37 height=14 alt="Docs" border=0></a></td>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <td width="100"><a href="http://www.schlabo.com/support/forums.shtml" target="_blank"><img src="${images_url}n_forum.gif" width=46 height=14 alt="Forum" border=0></a></td>
                      </tr></table>
                      <br>
                      <table width="108" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="8"><img src="${images_url}arrow.gif" width="4" height="7"></td>
                        <td width="100"><font face="Verdana, Arial, Helvetica" size="1"><b>
		|;
		if ($scriptname eq "admin") {
			print qq|
			Admin-Script</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=conf_general" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confgeneral" src="${images_url}n_general.gif" width=56 height=14 alt="General Configuration"></td></form>
                      </tr>
		|;
		if ($p_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=conf_potd" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confpotd" src="${images_url}n_confpotd.gif" width=78 height=14 alt="Configure POTD-Script"></td></form>
                      </tr>
		|;
		}
		if ($d_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=conf_dl" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confdl" src="${images_url}n_confdl.gif" width=60 height=14 alt="Configure DL-Script"></td></form>
                      </tr>
		|;
		}
		if ($s_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=conf_sp" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confdl" src="${images_url}n_confsp.gif" width=60 height=14 alt="Configure SP-Script"></td></form>
                      </tr>
		|;
		}
		if ($c_installed ne "") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=conf_cow" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confcow" src="${images_url}n_confcow.gif" width=76 height=14 alt="Configure COW-Script"></td></form>
		      </tr>
                      |;
                }
                if (-e "${server_path}admin_forum.pl") {
			print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="${server_url}admin_forum.pl?action=conf_xcc" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="confxcc" src="${images_url}n_confforum.gif" width=83 height=14 alt="Configure XCC Forum-Script"></td></form>
		      </tr>
                      |;
                }
                if ($trackip eq "on") {
               	print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_url?action=viewiplog&viewlatest=50" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="viewiplog" src="${images_url}n_iplogs.gif" width=55 height=14 alt="View IP-Logs"></td></form>
		      </tr>
                      |;
		}
               	print qq|
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$g_admin_users_url?action=user_manage" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="manage_users" src="${images_url}n_manage_users.gif" width=99 height=14 alt="Manage Users"></td></form>
		      </tr>
                      |;
		} elsif ($scriptname eq "potd") {
			print qq|
			POTD-Script</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$p_admin_url?action=calendar" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="potd_calendar" src="${images_url}n_calendar.gif" width=64 height=14 alt="Show Calendar"></td></form>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$p_admin_url?action=showform" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="potd_addpicture" src="${images_url}n_addpicture.gif" width=78 height=14 alt="Add Picture"></td></form>
		      </tr>
                      |;
		} elsif ($scriptname eq "dl") {
			print qq|
			DL-Script</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$d_admin_url?action=showlogs" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
                        <input type="hidden" name="r_showmethod" value="sm_alias">
		<input type="image" name="dl_logsa" src="${images_url}n_logsalias.gif" width=80 height=14 alt="Show Logs (Aliases)"></td></form>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$d_admin_url?action=showlogs" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
                        <input type="hidden" name="r_showmethod" value="sm_urls">
		<input type="image" name="dl_logsu" src="${images_url}n_logsurl.gif" width=75 height=14 alt="Show Logs (URLs)"></td></form>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$d_admin_url?action=addfile" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="dl_addfile" src="${images_url}n_addfile.gif" width=56 height=14 alt="Add File to Database"></td></form>
		      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$d_admin_url?action=viewleechlog" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="dl_leechlog" src="${images_url}n_leechlogs.gif" width=79 height=14 alt="View Leech Logs"></td></form>
		      </tr>
                      |;
		} elsif ($scriptname eq "sp") {
			print qq|
			SP-Script</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$s_admin_url?action=showadmin" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="sp_logs" src="${images_url}n_logs.gif" width=37 height=14 alt="Show Logs"></td></form>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$s_admin_url?action=upload_pic_form" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="sp_upload_add" src="${images_url}n_upload_add.gif" width=92 height=14 alt="Upload and Add"></td></form>
                      </tr>
                      |;
		} elsif ($scriptname eq "cow") {
			print qq|
			COW-Script</b></font></td>
                      </tr>
                      <tr>
                        <td height="16" valign="top"><img src="${images_url}menu_object1.gif" width="8" height="16"></td>
                        <form action="$server_url$c_admin_url?action=overview" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="cow_logs" src="${images_url}n_logs.gif" width=37 height=14 alt="Show Logs"></td></form>
                      </tr>
                      <tr> 
                        <td height="16" valign="top"><img src="${images_url}menu_object2.gif" width="8" height="16"></td>
                        <form action="$server_url$c_admin_url?action=showform" method="post"><td width="100"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="image" name="cow_addcomic" src="${images_url}n_addcomic.gif" width=72 height=14 alt="Add Comic"></td></form>
		      </tr>
                      |;
		}
		print "</table><br><br>\n";
	}
	print "&nbsp;</td>";
	print qq|
	      <td valign="top"><br><font face="Verdana, Arial, Helvetica" size="2">
	|;
	if (($hidemenu ne "1") && ((($scriptname eq "admin") && ($user_access_g[$cur_user_number] ne "on")) || (($scriptname eq "potd") && ($user_access_p[$cur_user_number] ne "on")) || (($scriptname eq "dl") && ($user_access_d[$cur_user_number] ne "on")) || (($scriptname eq "sp") && ($user_access_s[$cur_user_number] ne "on")) || (($scriptname eq "cow") && ($user_access_c[$cur_user_number] ne "on")))) {
		print "<br><font size=3 color=#FFCC00><b>Access Denied</b></font><br><br>";
		print "You (User: \"<i>$user_names[$cur_user_number]</i>\") don't have permission to access the ";
		print $scriptname;
		print "-script. Please contact the <a href=\"mailto:$email_address\">owner of this site</a> if you have questions about this.<br>";
		&html_footer;
		exit;
	}

}

sub html_footer {
	if (($enable_questions eq "on") and ($hidemenu ne "1")) {
		print "<p>&nbsp;</p><font face=\"Verdana, Arial, Helvetica\" size=2 color=\"#FFCC00\">Frequently Asked Question</font><br><hr noshade>\n";
		&init_questions;
		$question_nums = @question;
		print "<table width=\"100%\" border=\"0\"><tr><td width=\"32\" valign=\"top\"><img src=\"${images_url}question.gif\" width=32 height=32 alt=\"Freqently Asked Question\"></td><td bgcolor=#276B2E>";
		print "<font face=\"Verdana, Arial, Helvetica\" size=2>&nbsp;<a href=\"http://www.schlabo.com/install/$scriptname/\" target=\"_blank\">$question[int(rand($question_nums))]</a></font></td></tr></table>\n";

	}
	print "<br><br></font></p><p align=\"right\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\"><a href=\"http://www.schlabo.com\" target=\"blank\">";
	if ($scriptname eq "admin") {
		print "Schlabo's Scripts v$g_version";
	} elsif ($scriptname eq "potd") {
		print "Schlabo's POTD v$p_version";
	} elsif ($scriptname eq "dl") {
		print "Schlabo's DL v$d_version";
	} elsif ($scriptname eq "sp") {
		print "Schlabo's SP v$s_version";
	} elsif ($scriptname eq "cow") {
		print "Schlabo's COW v$c_version";
	}
	print qq|</a></font></p></td>
	    </tr>
	  </table>
	</td></tr></table>
	</div>
	</body>
	</html>
	|;
}

return true;