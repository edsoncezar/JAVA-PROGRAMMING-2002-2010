#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_dl.pl";

umask (0111);

$scriptname="dl";

print "Content-Type: text/html\n\n";

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

if ($uselocking) { &masterlockopen; }

if (-e "$server_datapath$d_data_file") {
	&lockopen(data,"$server_datapath$d_data_file","input");
	@tempdata = <data>;
	&lockclose(data,"$server_datapath$d_data_file");
	
	$totalcount=0;
	$countup = 0;
	
	$max_num = @tempdata;
	for ($count=0;$count<$max_num;$count++) {
		$temp_data = @tempdata[$count];
		chomp($temp_data);
		($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
		$data[$countup][0]=$temp_num;
		$data[$countup][1]=$temp_file;
		$data[$countup][2]=$temp_alias;
		$totalcount += $temp_num;
		$countup += 1;				
	}
	$max_num = $countup;
		
		
	$a_number = "0";       # Total number of Aliases
	
	for ($count=0;$count<$max_num;$count++) {
		$found=0;
		for ($count2=0;$count2<$a_number;$count2++) {
			if ($a_data[$count2][2] eq $data[$count][2]) {   # Alias already found
				$a_data[$count2][0] = $a_data[$count2][0] + $data[$count][0];
				$found = 1;
			}
		}
		if ($found eq "0") {      # Alias not yet in a_data, so add it!
			$a_data[$a_number][2] = $data[$count][2];   # Store new alias
			$a_data[$a_number][1] = $data[$count][1];   # Store new URL (needed for editing)
			$a_data[$a_number][0] = $data[$count][0];   # Store number for alias
			$a_number += 1;
		}
	}
	$max_num = $a_number;
	

	print "$d_showtotaldcmessagebefore$totalcount\n";
	print "$d_showtotaldcmessagemiddle$max_num\n";
	print "$d_showtotaldcmessageafter\n";
	
} else {
	print "[Error: Data-File not found]";
}

if ($uselocking) { &masterlockclose; }

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || print "[Error: There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	} else {	# Input
		open (FILE,"<$lockfilename") || print "[Error: There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			print "[Error: The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}dl_masterlock.lok")
	  && ((stat("${server_datapath}dl_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}dl_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}dl_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		print "[Error: The server was unable to access dl_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks]";
	}
}

sub masterlockclose {
	if (-e "${server_datapath}dl_masterlock.lok") {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
}
