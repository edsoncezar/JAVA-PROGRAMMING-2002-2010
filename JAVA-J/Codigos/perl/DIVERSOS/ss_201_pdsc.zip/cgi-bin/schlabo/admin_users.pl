#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "common.pl";

umask (0111);

$scriptname="admin";

&check_referer;
&parse_query;
&get_date;
eval { &get_script_actions; };
if ($@) {
	&showerror("An error occured: $@");
}
exit;

sub get_script_actions {
	# Query and Form Actions
	$dowhat=$QUERY{'action'};
	
	if ($dowhat eq 'showadmin') { $dowhat = "user_manage" }
	
	if (($dowhat ne 'login') && ($dowhat ne '') && ($dowhat ne 'logout')) {
		&get_password;
	}
	if (($dowhat eq 'login') || ($dowhat eq '')) { &showlogin; }
	elsif ($dowhat eq 'logout') { &logout; }
	elsif ($dowhat eq 'user_manage') { &user_manage; }
	elsif ($dowhat eq 'user_create_form') { &user_create_form; }
	elsif ($dowhat eq 'user_create') { &user_create; }
	elsif ($dowhat eq 'user_edit_form') { &user_edit_form; }
	elsif ($dowhat eq 'user_edit') { &user_edit; } 
	elsif ($dowhat eq 'user_remove') { &user_remove; } 
	else { &novalidquery; }
}


sub user_manage {
	&html_header;
	print "<font size=\"3\" color=\"#FFCC00\"><b>User Management</b></font><br><br>Here you can see all existing Schlabo's Scripts-users and their permissions. You can also delete them or create new users and give them access to the scripts you want.<br><br>\n";
	print "<form action=\"$server_url$g_admin_users_url?action=user_edit_form\" method=\"post\">";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<font color=\"#FFCC00\">User Listing</font><br><hr noshade>\n";
	print "<table border=0>";
	print "<tr><td>&nbsp;</td><td width=200><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>User</b></font></td>";
	print "<td width=20 align=\"center\"><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>G</b></font></td>";
	if ($p_installed eq "on") { print "<td width=20 align=\"center\"><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>P</b></font></td>" }
	if ($d_installed eq "on") { print "<td width=20 align=\"center\"><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>D</b></font></td>" }
	if ($s_installed eq "on") { print "<td width=20 align=\"center\"><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>S</b></font></td>" }
	if ($c_installed eq "on") { print "<td width=20 align=\"center\"><font face=\"Verdana, Arial, Helvetica\" size=\"2\"><b>C</b></font></td>" }
	$user_number = @user_names;
	for ($user_count=0;$user_count<($user_number);$user_count++) {
		if (($user_count % 2)==0) {
			print "<tr bgcolor=#276B2E>";
		} else {
			print "<tr>";
		}
		print "<td><input type=\"radio\" name=\"user_which\" value=\"$user_count\"";
		if ($user_count == $cur_user_number) { print " checked" }
		print "></td>";
		# Username
		$entry_selected = "<img src=\"".$images_url."entry_selected.gif\" width=\"15\" height=\"15\" alt=\"X\" border=\"0\">";
		print "<td><font face=\"Verdana, Arial, Helvetica\" size=\"2\">";
		if ($user_count == $cur_user_number) { print "<i>" }
		print "$user_names[$user_count]</font></td>";
		if ($user_count == $cur_user_number) { print "</i>" }
		print "<td align=\"center\">";
		if ($user_access_g[$user_count] eq "on") { print $entry_selected } else { print "&nbsp;" }
		print "</td>";
		if ($p_installed eq "on") {
			print "<td align=\"center\">";
			if ($user_access_p[$user_count] eq "on") { print $entry_selected } else { print "&nbsp;" }
			print "</td>";
		}
		if ($d_installed eq "on") {
			print "<td align=\"center\">";
			if ($user_access_d[$user_count] eq "on") { print $entry_selected } else { print "&nbsp;" }
			print "</td>";
		}
		if ($s_installed eq "on") {
			print "<td align=\"center\">";
			if ($user_access_s[$user_count] eq "on") { print $entry_selected } else { print "&nbsp;" }
			print "</td>";
		}
		if ($c_installed eq "on") {
			print "<td align=\"center\">";
			if ($user_access_c[$user_count] eq "on") { print $entry_selected } else { print "&nbsp;" }
			print "</td>";
		}
		print "</tr>\n";
	}	
	print "</table>";
	print "<br>";
	print "<table><tr><td>";
	print "<input type=\"submit\" name=\"submit\" value=\"Edit Selected User\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\">\n";
	print "</form>";
	print "</td><td><form action=\"$server_url$g_admin_users_url?action=user_create_form\" method=\"post\">";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "&nbsp;<input type=\"submit\" name=\"submit\" value=\"Create New User\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\">\n";
	print "</form></td></tr></table>";
	print "<p><font face=\"Verdana, Arial, Helvetica\" size=\"2\">";
	print "G = General Admin Script + User Management<br>";
	if ($p_installed eq "on") { print "P = Picture of the Day<br>" }
	if ($d_installed eq "on") { print "D = Download<br>" }
	if ($s_installed eq "on") { print "S = ShowPicture<br>" }
	if ($c_installed eq "on") { print "C = Comic of the Week<br>" }
	print "<br>";
	&html_footer;
}

sub user_create_form {
	&html_header;
	print qq|
	<font size="3" color="#FFCC00"><b>Create User</b></font><br><br>
	Enter username and password for the new user and choose which scripts this user will be able to access.<br><br>
	<form action="$server_url$g_admin_users_url?action=user_create" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<br><font color="#FFCC00">User Information</font><br><hr noshade>
	Username:<br>
	<input type="text" size="40" value="" name="new_username" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	Password:<br>
	<input type="text" size="40" value="" name="new_password" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>

	<br><font color="#FFCC00">Access</font><br><hr noshade>
	<input type="checkbox" name="new_access_g" checked>&nbsp;General Admin<br>
	|;
	if ($p_installed eq "on") { print "<input type=\"checkbox\" name=\"new_access_p\" checked>&nbsp;Pic of the Day<br>\n" }
	if ($d_installed eq "on") { print "<input type=\"checkbox\" name=\"new_access_d\" checked>&nbsp;Download<br>\n" }
	if ($s_installed eq "on") { print "<input type=\"checkbox\" name=\"new_access_s\" checked>&nbsp;Show Picture<br>\n" }
	if ($c_installed eq "on") { print "<input type=\"checkbox\" name=\"new_access_c\" checked>&nbsp;Comic of the Week<br>\n" }
	print qq|
	<br><br><font color="#FFCC00">Submit</font><br><hr noshade>
	<table border="0"><tr><td><input type="submit" value="Add" name="Add" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></form></td>
	<td><form action="$server_url$g_admin_users_url?action=user_manage" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="submit" value="Cancel" name="Cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></form></td></tr></table>
	|;
	&html_footer;
}

sub user_edit_form {
	$edit_user_number = param('user_which');
	if ($edit_user_number == $cur_user_number) { $edit_curuser = 1 }
	&html_header;
	print qq|
	<font size="3" color="#FFCC00"><b>Edit User</b></font><br><br>
	Change the permissions of this user below. |;
	if ($edit_curuser == 1) {
		print "You can only remove access to the General Admin-script if you're not logged in as this user.";
	} else {
		print "You can only change the password if you're currently logged in as this user.";
	}
	print qq|<br><br>
	<form action="$server_url$g_admin_users_url?action=user_edit" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="hidden" name="edit_user_number" value=$edit_user_number>
	<br><font color="#FFCC00">User Information</font><br><hr noshade>
	Username:<br>
	<input type="text" size="40" value="$user_names[$edit_user_number]" name="new_username" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	|;
	if ($edit_curuser == 1) {
		print "<input type=\"hidden\" name=\"edit_curuser\" value=\"1\">";
		unless (($param_pw eq "") && (param('firsttime') == 1) && ($user_names[$edit_user_number] eq "") && ($edit_user_number == 0)) {
			print qq|
			Current Password:<br>
			<input type="text" size="40" value="" name="old_password" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
			|;
		}
		print qq|
		New Password:<br>
		<input type="text" size="40" value="" name="new_password" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		|;
	}
	print "<br><font color=\"#FFCC00\">Access</font><br><hr noshade>";
	print "<input type=\"checkbox\" name=\"new_access_g\"";
	if ($user_access_g[$edit_user_number] eq "on") { print " checked" }
	if ($edit_curuser == 1) { print " disabled" }
	print ">&nbsp;General Admin<br>\n";
	if ($p_installed eq "on") {
		print "<input type=\"checkbox\" name=\"new_access_p\"";
		if ($user_access_p[$edit_user_number] eq "on") { print " checked" }
		print ">&nbsp;Pic of the Day<br>\n";
	}
	if ($d_installed eq "on") {
		print "<input type=\"checkbox\" name=\"new_access_d\"";
		if ($user_access_d[$edit_user_number] eq "on") { print " checked" }
		print ">&nbsp;Download<br>\n";
	}
	if ($s_installed eq "on") {
		print "<input type=\"checkbox\" name=\"new_access_s\"";
		if ($user_access_s[$edit_user_number] eq "on") { print " checked" }
		print ">&nbsp;Show Picture<br>\n";
	}
	if ($c_installed eq "on") {
		print "<input type=\"checkbox\" name=\"new_access_c\"";
		if ($user_access_c[$edit_user_number] eq "on") { print " checked" }
		print ">&nbsp;Comic of the Week<br>\n";
	}
	print qq|
	<br><br><font color="#FFCC00">Submit</font><br><hr noshade>
	<table border="0"><tr><td><input type="submit" value="Save Changes" name="save_changes" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></form></td>
	|;
	if ($edit_curuser ne "1") {
		print qq|
		<td><form action="$server_url$g_admin_users_url?action=user_remove" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<input type="hidden" name="remove_user_number" value=$edit_user_number>
		<input type="submit" value="Remove User" name="Remove" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></form></td>
		|;
	}
	print qq|
	<td><form action="$server_url$g_admin_users_url?action=user_manage" method="post"><input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="submit" value="Cancel" name="Cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></form></td>
	</tr></table>
	|;
	&html_footer;
}

sub user_edit {
	$edit_curuser = param('edit_curuser');
	if ($edit_curuser == 1) {
		$old_password = param('old_password');
		$new_password = param('new_password');
	}
	$edit_user_number = param('edit_user_number');
	if (($edit_curuser == 1) && (($old_password ne "") || ($new_password ne "")) && ($old_password ne $new_password)) {
		# Change password - check old pw first
		if ($crypted_passwords eq "on") {
			$old_pw_crypted = crypt($old_password,$user_passwords[$cur_user_number]);
		} else {
			$old_pw_crypted = $old_password;
		}
		if ($old_pw_crypted ne $user_passwords[$cur_user_number]) {
			&html_header;
			print "<br><font size=3 color=#FFCC00><b>Wrong Password</b></font><br><br>\n";
			print "If you want to change the password for the current user please enter the correct current password.<br><br>";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			&html_footer;
			return;
		}
		# Crypt new password
		if ($crypted_passwords eq "on") {
			$user_passwords[$edit_user_number] = crypt($new_password, join ('', ('.', '/', 0..9, 'A'..'Z', 'a'..'z')[rand 64, rand 64]));
		} else {
			$user_passwords[$edit_user_number] = $new_password;
		}
		&ClearCookies;
		$hidemenu = 1;
	}
	
	$user_names[$edit_user_number] = param('new_username');
	if ($edit_curuser ne "1") { $user_access_g[$edit_user_number] = param('new_access_g') }
	$user_access_p[$edit_user_number] = param('new_access_p');
	$user_access_d[$edit_user_number] = param('new_access_d');
	$user_access_s[$edit_user_number] = param('new_access_s');
	$user_access_c[$edit_user_number] = param('new_access_c');
	&user_savesettings;
	
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>Settings Saved</b></font><br><br>";
	if ($hidemenu == 1) {
		print "The password has been changed. This requires you to log in again with the new password.<br><br>Click <a href=\"$server_url$g_admin_url?action=login\">here</a> to log in</a>.<br>\n";
	} else {
		print "<form action=\"$server_url$g_admin_users_url?action=user_manage\" method=\"post\">\n";
		print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
		print "Click ";
		print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
		print " to get back to the user management.<br>\n";
	}

	
	&html_footer;
	
}	

sub user_remove {
	$remove_user = 1;
	$remove_user_number = param('remove_user_number');
	&user_savesettings;
	
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>User Removed</b></font><br><br>";
	print "<form action=\"$server_url$g_admin_users_url?action=user_manage\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "The user \"<i>$user_names[$remove_user_number]</i>\" has been removed.<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to get back to the user management.<br>\n";
	&html_footer;
}

sub user_create {
	$new_username = param('new_username');
	$new_password = param('new_password');
		
	# Check username
	if (length($new_username) <= 2) {
		print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
		print "The username (\"<i>$new_username</i>\") is too short, please use at least 2 chars.<br><br>";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
		&html_footer;
		return;
	}
	$user_number = @user_names;
	for ($user_count=0;$user_count<($user_number);$user_count++) {
		if ($new_username eq $user_names[$user_count]) {
			print "<br><font size=3 color=#FFCC00><b>Error</b></font><br><br>\n";
			print "The username (\"<i>$new_username</i>\") does already exist, please choose a different one or delete/edit the existing user.<br><br>";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			&html_footer;
			return;
		}
	}
	if ($crypted_passwords eq "on") {
		$user_passwords[$user_number] = crypt($new_password, join ('', ('.', '/', 0..9, 'A'..'Z', 'a'..'z')[rand 64, rand 64]));
	} else {
		$user_passwords[$user_number] = $new_password;
	}
	$user_names[$user_number] = $new_username;
	$user_access_g[$user_number] = param('new_access_g');
	$user_access_p[$user_number] = param('new_access_p');
	$user_access_d[$user_number] = param('new_access_d');
	$user_access_s[$user_number] = param('new_access_s');
	$user_access_c[$user_number] = param('new_access_c');
	$user_number = $user_number + 1;
	&user_savesettings;
	
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>User Created</b></font><br><br>";
	print "<form action=\"$server_url$g_admin_users_url?action=user_manage\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "The user \"<i>$new_username</i>\" has been created.<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to get back to the user management.<br>\n";
	&html_footer;
}

sub user_savesettings {
	$filename = "config.pl";
	if (-e "$server_path$filename") {
		open(data,"<$server_path$filename");      # Put contents of file into an array
		@all_data = <data>;
		close(data);
		$max_num = @all_data;
		
		open(newconfig,">$server_path$filename") || &showerror("An error occured when trying to save the changes. Please make sure the script-permissions are set correctly on the server and you CHMODed the Schlabo's Scripts-directory to either 777 or 755 (depending on your server).");
		
		for ($count=0;$count<($max_num);$count++) {
			$curline = @all_data[$count];
			$flag = 0;
			if (index($curline,"user_names")==1) { &user_savesettings_write("user_names"); }
			if (index($curline,"user_passwords")==1) { &user_savesettings_write("user_passwords"); }
			if (index($curline,"user_access_g")==1) { &user_savesettings_write("user_access_g"); }
			if (index($curline,"user_access_p")==1) { &user_savesettings_write("user_access_p"); }
			if (index($curline,"user_access_d")==1) { &user_savesettings_write("user_access_d"); }
			if (index($curline,"user_access_s")==1) { &user_savesettings_write("user_access_s"); }
			if (index($curline,"user_access_c")==1) { &user_savesettings_write("user_access_c"); }
			if ($flag == 0) {
				print newconfig "$curline";
			}
		}
		
		close(newconfig);
	}
}

sub user_savesettings_write {
	$curvar = @_[0];
	if (index($curline,"@_")==1) {
		print newconfig "\@$curvar = (";
		$firstuser = 1;
		for ($keycount=0;$keycount<($user_number);$keycount++) {
			if (($remove_user == 1) && ($remove_user_number == $keycount)) {
				# Don't write this user
			} else {
				if ($firstuser ne "1") { print newconfig "," }
				$firstuser = 0;
				print newconfig "\"".${$curvar}[$keycount]."\"";
			}
		}			
		print newconfig ");\n";
		$flag = 1;
	}
}

sub init_questions {
	
	$question[0] = "How to I login to the scripts?";
	$question[1] = "How do the templates work?";
	$question[2] = "Is there a way to see if I'm using the latest version?";
	$question[3] = "What's the use of File-Locking?";
	$question[4] = "Why would I want to track IPs?";
	$question[5] = "Why does the script need to know my email-address?";
	$question[6] = "How do I configure the script for sending emails?";
	$question[7] = "Aren't Cookies a Security-Risk?";
	$question[8] = "Are the scripts compatible to PHP?";
	$question[9] = "Where can I get support?";
	
}
