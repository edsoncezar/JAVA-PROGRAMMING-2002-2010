#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_cow.pl";
require "common.pl";

umask (0111);

$scriptname="cow";

&check_referer;
&parse_query;
&get_date;
eval { &get_script_actions; };
if ($@) {
	&showerror("An error occured: $@");
}
exit;

sub get_script_actions {
	# Query and Form Actions
	$dowhat = $QUERY{'action'};
	if ($dowhat eq "showadmin") {
		$dowhat = "overview";
	}
	
	if (($dowhat ne 'login') && ($dowhat ne '')) {
		&get_password;
	}
	if ($dowhat eq 'login') { &showlogin; }
	elsif ($dowhat eq 'overview') { &overview; }
	elsif ($dowhat eq 'showform') { &showform; }
	elsif ($dowhat eq 'add') { &edit_entry; }
	elsif ($dowhat eq '') { &showlogin; }
	else { &novalidquery; }
}

sub overview {
	&html_header;
	&read_data_file;
	($Second,$Minute,$Hour,$Month_day,$Month,$Year,$Week_Day,$IsDST) = (localtime);
	$Month=$Month+1;
	$Year=$Year+1900;
	
	# Determine next free week
	if ($c_weeks_total eq "0") {
		$nextyear = $Year;
		$nextmonth = $Month;
		$nextday = $Month_day;
	} else {
		$nextyear = $c_weeks[$c_weeks_total-1][1];
		$nextmonth = $c_weeks[$c_weeks_total-1][2];
		$nextday = $c_weeks[$c_weeks_total-1][3];
		$nextday = $nextday + 7;
	}
	if ($nextday > $months_days[$nextmonth-1]) {
		$nextday = $nextday - $months_days[$nextmonth-1];
		$nextmonth = $nextmonth + 1;
		if ($nextmonth > 12) {
			$nextmonth = 1;
			$nextyear = $nextyear + 1;
		}
	}
	$nexttimecode=&calculatetimecode($nextyear,$nextmonth,$nextday);
	#print "Timecode: $nexttimecode\n<br>\n";
	print "Number of comics stored in the database: <b>$c_weeks_total</b>\n";
	print "<br>\n";
	print "Next free week: $nextday.$months[$nextmonth-1] $nextyear";
	print "<form action=\"$server_url$c_admin_url?action=showform\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<input type=\"hidden\" name=\"nfy\" value=$nextyear>\n";
	print "<input type=\"hidden\" name=\"nfm\" value=$nextmonth>\n";
	print "<input type=\"hidden\" name=\"nfd\" value=$nextday>\n";
	print "Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to add a comic at the next free week.<p>\n";
	print "</form><p>\n";
	if ($c_weeks_total > 0) {
		print "<table width=390 border=0><tr>";
		print "<td>&nbsp;</td>\n";
		print "<td><font face=\"Verana, Arial, Helvetica\" size=2><b>Date</b></font></td>\n";
		print "<td><font face=\"Verana, Arial, Helvetica\" size=2><b>Pictures</b></font></td></tr>\n";
		for ($count=0;$count<$c_weeks_total;$count++) {
			if (($count % 2)==0) {
				print "<tr bgcolor=#276B2E>";
			} else {
				print "<tr>";
			}
			print "<form action=\"$server_url$c_admin_url?action=showform\" method=\"post\">";
			print "<td width=15 valign=top>";
			print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>";
			print "<input type=\"hidden\" name=\"nfy\" value=$c_weeks[$count][1]>";
			print "<input type=\"hidden\" name=\"nfm\" value=$c_weeks[$count][2]>";
			print "<input type=\"hidden\" name=\"nfd\" value=$c_weeks[$count][3]>";
			print "<input type=\"image\" name=\"Edit\" src=\"".$images_url."entry_edit.gif\" width=15 height=15 alt=\"Edit / Remove Entry\">";
			print "</td></form>";
			print "<td valign=top><font face=\"Verana, Arial, Helvetica\" size=2>${c_weeks[$count][3]}-${c_weeks[$count][2]}-${c_weeks[$count][1]}</font></td>\n";
			print "<td valign=top><font face=\"Verana, Arial, Helvetica\" size=2>$c_weeks[$count][4]</font></td>\n";
			print "</tr>\n";
		}
		print "</table>";
	}
	&html_footer;
}

sub calculatetimecode {
	$ctc = (($_[0] - 2000) * 365) + $_[2];
	if ($_[1]>1) {
		for ($ctc_count=0;$ctc_count<($_[1]-1);$ctc_count++) {
			$ctc = $ctc + $months_days[$ctc_count];
		}
	}
	return($ctc);
}

sub showform {
	&read_data_file;
	&html_header;
	print "<br><font size=3 color=#FFCC00><b>";
	$add_or_edit=0;
	
	$newmonth=param('nfm');
	$newyear=param('nfy');
	$newday=param('nfd');
	$newtimecode=&calculatetimecode($newyear,$newmonth,$newday);
	$newhowmany=0;
	$newweek=$c_weeks_total+1;
	for ($count=0;$count<$c_weeks_total;$count++) {      # Check if an entry is to be edited
		if ($c_weeks[$count][0] eq $newtimecode) {
			$newhowmany=$c_weeks[$count][4];
			$newweek=$count+1;
			$add_or_edit=1;
		}
	}
	if ($add_or_edit eq "0") {
		print "Add entry";
	} else {
		print "Edit entry";
	}
	print "</b></font><br><br></font>\n";
	print qq|
	<form action="$server_url$c_admin_url?action=add" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<font face="Verdana, Arial, Helvetica" size="2">Week: <input type="text" size="3" value="$newweek" name="new_week" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	Day: <input type="text" value="$newday" maxlength="2" size="2" name="nfd" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
	Month: <input type="text" value="$newmonth" size="2" maxlength="2" name="nfm" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
	Year: <input type="text" value="$newyear" size="4" maxlength="4" name="nfy" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	How many pictures does this comic have? <input type="text" size="3" value="$newhowmany" name="new_howmany" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	<input type="checkbox" name="delete">&nbsp;Check this only if you want to delete this comic!</input><br><br><br>
	|;
	if ($add_or_edit eq "0") {
		print "<input type=\"submit\" name=\"submit\" value=\"Add Entry\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\">";
	} else {
		print "<input type=\"submit\" name=\"submit\" value=\"Edit Entry\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\">";
	}
	print qq|
	&nbsp;<input type="reset" name="reset" value="Reset" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</form>
	|;
	&html_footer;
}

sub edit_entry {
	&read_data_file;
	&html_header;
	$add_or_edit=0;
	$newmonth=param('nfm');
	$newyear=param('nfy');
	$newday=param('nfd');
	$newtimecode=&calculatetimecode($newyear,$newmonth,$newday);
	$newhowmany=param('new_howmany');
	$newweek=$c_weeks_total;
	for ($count=0;$count<$c_weeks_total;$count++) {      # Check if an entry is to be edited
		if ($c_weeks[$count][0] eq $newtimecode) {
			#$newhowmany=$c_weeks[$count][4];
			$newweek=$count;
			$add_or_edit=1;
		}
	}
	if ($add_or_edit eq "0") {
		$c_weeks_total = $c_weeks_total + 1;
	}
	if (param('delete')) {
		$c_weeks[$newweek][0]="xx";
	} else {
		$c_weeks[$newweek][0]=$newtimecode;
		$c_weeks[$newweek][1]=$newyear;
		$c_weeks[$newweek][2]=$newmonth;
		$c_weeks[$newweek][3]=$newday;
		$c_weeks[$newweek][4]=$newhowmany;
	}
	&bubblesort;
	open(data,">$server_datapath$c_data_file") or &showerror("Error creating the Data-File. Try it again, check if the directory and the database-file are CHModed to 777 and take a look at the configuration.");
	for ($count=0;$count<$c_weeks_total;$count++) {
		if ($c_weeks[$count][0] ne "xx") {
			print data "$c_weeks[$count][0]|$c_weeks[$count][1]|$c_weeks[$count][2]|$c_weeks[$count][3]|$c_weeks[$count][4]\n";
		}
	}
	close(data);
	print "<br><font size=3 color=#FFCC00><b>Success</b></font><br><br>\n";
	print "You have successfully modified the data-file.\n";
	print "<form action=\"$server_url$c_admin_url?action=overview\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to view the updated data-file.<p>\n";
	print "</form>\n";	
	print "<br><br><br><br>\n";
	&html_footer;
	
}

sub bubblesort {
	for ($i=0;$i<=($c_weeks_total-2);$i++) {
		for ($j=$i;$j>=0;$j--) {
			if ($c_weeks[$j][0] > $c_weeks[$j+1][0]) {
				$temp0 = $c_weeks[$j][0];
				$temp1 = $c_weeks[$j][1];
				$temp2 = $c_weeks[$j][2];
				$temp3 = $c_weeks[$j][3];
				$temp4 = $c_weeks[$j][4];
				$c_weeks[$j][0] = $c_weeks[$j+1][0];
				$c_weeks[$j][1] = $c_weeks[$j+1][1];
				$c_weeks[$j][2] = $c_weeks[$j+1][2];
				$c_weeks[$j][3] = $c_weeks[$j+1][3];
				$c_weeks[$j][4] = $c_weeks[$j+1][4];
				$c_weeks[$j+1][0] = $temp0;
				$c_weeks[$j+1][1] = $temp1;
				$c_weeks[$j+1][2] = $temp2;
				$c_weeks[$j+1][3] = $temp3;
				$c_weeks[$j+1][4] = $temp4;
			}
		} 
	}
}

sub read_data_file {
	if (-e "$server_datapath$c_data_file") {
		open(data,"<$server_datapath$c_data_file") or &showerror("Error reading the Data-File. Try it again, check if the directory and the database-file are CHModed to 777 and take a look at the configuration.");
		@tempdata = <data>;
		close(data);
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_timecode,$temp_year,$temp_month,$temp_day,$temp_howmany) = split(/\|/,$temp_data);
			$c_weeks[$count][0] = $temp_timecode;
			$c_weeks[$count][1] = $temp_year;
			$c_weeks[$count][2] = $temp_month;
			$c_weeks[$count][3] = $temp_day;
			$c_weeks[$count][4] = $temp_howmany;
		}
		$c_weeks_total=$max_num;
	} else {
		open(data,">$server_datapath$c_data_file") or &showerror("Error creating the Data-File. Try it again, check if the directory and the database-file are CHModed to 777 and take a look at the configuration.");
		$c_weeks_total = 0;
		$c_weeks[0][0]=0;
		close(data);
	}
}

sub init_questions {
	
	$question[0] = "How can I add a new comic?";
	$question[1] = "How can I edit/delete a COW? ";
	$question[2] = "Can I also assign comics of the day?";
	$question[3] = "How does the COW-Thumbnail work?";
	$question[4] = "How do I have to name the COW-picture-files?";
	
}