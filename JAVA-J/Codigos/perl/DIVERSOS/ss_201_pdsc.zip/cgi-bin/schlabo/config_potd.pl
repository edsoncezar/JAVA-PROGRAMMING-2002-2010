#!/usr/bin/perl

use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# -------------------------------------------------------------------------------------
# POTD-Specific

# Filename of the POTD-script
$p_script_url = "potd.pl";

# Picture of the Day-URL (use this only if all/most of them are stored in the same dir)
$p_potd_url = "http://localhost/images/potd/";

# Picture of the Day-Serverpath (same direcory as above, only this time not the URL but the absolute server-path)
$p_potd_path = "c:/dokumente und einstellungen/a/festplatte/webs/scripts/images/potd/";

# Notify visitor who submitted the POTD when you add it to the calendar so that he gets
# a mail with the day it wills how up. This will remind him to check it out, therefore to come back to your site.
$p_notifyvisitor = "on";

# Open POTD in a new window
$p_newwindow = "on";

# New Window Properties
$p_newwindow = "on";
$p_newwindow = "on";
$p_newwindow_properties = "width=640, height=480, status=yes, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, titlebar=no";

# The tag at the beginning of the thumbnail-picture that is different to the high quality-pic
$p_thumbtag = "t_";

# How many thumbnails in a row in the calendar-script (depends on the width of the thumbnails...)
$p_thumbrow = "3";

# It's recommended that all of your thumbnails have the same size so that the thumbnail-script can specify width and height.
# If you want to specify a size for them, enter values. If your thumbnails have different sizes, comment the
# following two lines out by adding a # at the beginning of the lines.
$p_thumbw = "110";
$p_thumbh = "83";

# If no thumbnail is available for a day, specify which image should be displayed instead (should have the same width
# and height as the thumbnail-pics). Full URL.
$p_thumbno = "http://localhost/images/layout/potd_na_160x120.gif";

# Display previous POTD instead of the N/A-image if none was assigned for the current day
$p_showprevious = "on";

# Visitor Gallery activated
$p_galleryon = "on";

# Filename of the Gallery-Script
$p_galleryscript = "potd_gallery.pl";

# Show descriptions below the pictures
$p_gallerydesc = "on";

# Thumbnail-Columns per Gallery-Page
$p_gallerycolumns = "3";

# Thumbnail-Rows per Gallery-Page
$p_galleryrows = "3";

# How many months back the POTD-script should go for finding a previous pic (has to be less than 12)
$p_goback = "2";

# How many months forward the POTD-script should go for finding the next pic
$p_maxgoforward = "2";

# Filename of the Template-File for the POTD-Pages
$p_potdtemplate = "template_potd.txt";

# Filename of the Template-File for the POTD-Gallery
$p_potdgallerytemplate = "template_potd_gallery.txt";

# Version of this script, do not alter the variable
$p_version = "2.01";

1;
