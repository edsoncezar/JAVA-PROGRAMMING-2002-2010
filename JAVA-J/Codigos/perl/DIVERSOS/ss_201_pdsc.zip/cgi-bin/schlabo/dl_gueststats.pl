#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_dl.pl";

$scriptname="dl";

umask (0111);

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

$simplelayout = param('simple');

open(tfile, "<$server_path$d_statstemplate");
@dltemplate =<tfile>;
close(tfile);

&parse_query;
if ($uselocking) { &masterlockopen; }
&guest_stats;
if ($uselocking) { &masterlockclose; }

sub guest_stats {
	if ($d_gueststatus eq "-") {
		&ext_header;
		print "<br><font size=3 color=#FFCC00><b>Access Denied</b></font><br><br>\n";
		print "Guest-Stats have been deactivated.\n";
		print "<br><br><br><br>\n";
		&ext_footer;
		exit;
	}
	if (-e "$server_datapath$d_data_file") {
		$searchactive = 0;
		if (param('search') ne "") {
			$searchactive = 1;
			$searchstring = param('search');
		}
		&lockopen(data,"$server_datapath$d_data_file","input");
		@tempdata = <data>;
		&lockclose(data,"$server_datapath$d_data_file");
		
		&ext_header;
		
		if ($d_countguests ne "") {   # Count how many guests access this page
			if (-e "$server_datapath$d_countfile") {
				&lockopen(cfile,"$server_datapath$d_countfile","input");
				$count = <cfile>;
				&lockclose(cfile,"$server_datapath$d_countfile");
				$count = $count + 1;
				&lockopen(cfile,"$server_datapath$d_countfile","output");
				print cfile "$count";
				&lockclose(cfile,"$server_datapath$d_countfile");
			} else {    # File not here, create a new one
				open(cfile,">$server_datapath$d_countfile");
				print cfile "1";
				close(cfile);
			}
		}
		
		$totalcount=0;
		$countup = 0;
		
		$max_num = @tempdata;
		for ($count=0;$count<$max_num;$count++) {
			$temp_data = @tempdata[$count];
			chomp($temp_data);
			($temp_alias,$temp_file,$temp_num) = split(/\|/,$temp_data);
			if (($searchactive eq "0") || (($searchactive eq "1") && (index($temp_file,$searchstring) >= 0)) || (($searchactive eq "1") && (index($temp_alias,$searchstring) >= 0))) {
				$data[$countup][0]=$temp_num;
				$data[$countup][1]=$temp_file;
				$data[$countup][2]=$temp_alias;
				$totalcount=$totalcount + $temp_num;
				$countup = $countup + 1;				
			}
		}
		$max_num = $countup;
		
		
		$a_number = "0";       # Total number of Aliases
		
		for ($count=0;$count<$max_num;$count++) {
			$found=0;
			for ($count2=0;$count2<$a_number;$count2++) {
				if ($a_data[$count2][2] eq $data[$count][2]) {   # Alias already found
					$a_data[$count2][0] = $a_data[$count2][0] + $data[$count][0];
					$found=1;
				}
			}
			if ($found eq "0") {      # Alias not yet in a_data, so add it!
				$a_data[$a_number][2] = $data[$count][2];   # Store new alias
				$a_data[$a_number][1] = $data[$count][1];   # Store new URL (needed for editing)
				$a_data[$a_number][0] = $data[$count][0];   # Store number for alias
				$a_number = $a_number + 1;
			}
		}
		# Ok, now we have all the combined aliases in a new array, so let's sort it!
		&bubblesort_a;
		$max_num = $a_number;
		
		unless ($simplelayout == 1) {
		print qq^
		<p><font face="Verdana, Arial, Helvetica" size="2">This is the log-file of the Download-Script.</font><p>
		
		<p><font face="Verdana, Arial, Helvetica" size="2">
		^;
		if ($d_gueststatus==0) {
			print qq^
			<form action="$server_url$d_gueststatsscript" method="post">
			<input type="text" size="15" name="search" value="$searchstring" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
			<input type="submit" name="submit" value="Search" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"><br>
			<small><i>The search-string is case-sensitive!</i></small>
			</form>
			</font></p>
			^;
		}
		print qq^
		<p><font face="Verdana, Arial, Helvetica" size="2">Available Files: <b>$max_num</b><br>
		Total number downloaded files: <b>$totalcount</b><p>
		R = Rank<br>
		DC = Download Count<br>
		File = Downloaded File</p>
		^;
		}
		print qq^
		<table border="0" width="392">
		<tr>
		<td width="30" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>R</b></font></td>
		<td width="20" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>DC</b></font></td>
		<td width="100%" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>File</b></font></td>
		</tr>
		^;
		
		if (($d_gueststatus==0) && (param('top'))) {
			if (param('top')<$max_num) {
				$max_num = param('top');
			}
		}
		if (($d_gueststatus ne "0") && ($d_gueststatus < $max_num)) {
			$max_num = $d_gueststatus;
		}
		
		for ($count=0;$count<$max_num;$count++) {
			if ((($count % 2)==0) && ($simplelayout != 1)) {
				print "<tr bgcolor=#276B2E>";
			} else {
				print "<tr>";
			}
			print "<td width=\"30\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\" color=\"#FFCC00\"><b>".($count+1)."</b></font></td>\n";
			print "<td width=\"20\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">";
			print $a_data[$count][0];
			print "</font></td>\n";
			print "<td width=\"100%\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">";
			if ($d_guestlinks eq "on") { print "<a href=\"".$server_url."dl.pl\?".$a_data[$count][1]."\">" }
			print $a_data[$count][2]."</a></font></td>\n";
			print "</tr>\n";
		}
	
		print "</table>\n";
		&ext_footer;
	} else {
		&ext_header;
		print "<br><font size=3 color=#FFCC00><b>No Log-File</b></font><br><br>\n";
		print "The log-file has not been created yet, therefore it's not possible to show the logs.\n";		
		print "<br><br><br><br>\n";
		&ext_footer;
	}	
}



sub bubblesort_a {
	$resorted = 0;
	for ($i=$a_number;$i>=0;$i--) {
		for ($j=0;$j<=$i;$j++) {
			if ($a_data[$j][0] < $a_data[$j+1][0]) {
				$temp0 = $a_data[$j][0];
				$temp1 = $a_data[$j][1];
				$temp2 = $a_data[$j][2];
				$a_data[$j][0] = $a_data[$j+1][0];
				$a_data[$j][1] = $a_data[$j+1][1];
				$a_data[$j][2] = $a_data[$j+1][2];
				$a_data[$j+1][0] = $temp0;
				$a_data[$j+1][1] = $temp1;
				$a_data[$j+1][2] = $temp2;
				$resorted = 1;
			}
		} 
	}
}

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	} else {	# Input
		open (FILE,"<$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			&showerror("The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}dl_masterlock.lok")
	  && ((stat("${server_datapath}dl_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}dl_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}dl_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access dl_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}dl_masterlock.lok") {
		unlink ("${server_datapath}dl_masterlock.lok");
	}
}

sub showerror {
	&html_header;
	print "@_";
	&html_footer;
	exit;
}

sub parse_query {
	@pairs = split(/&/, $ENV{'QUERY_STRING'});
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$QUERY{$name} = $value;
	}
}

sub ext_header {
	# Print the beginning of the document

	print "Content-type: text/html\n\n";
	
	unless ($simplelayout == 1) {
	foreach $line (@dltemplate) {
		if($line =~ /\[\!body\]/i) {
			last;
		}
		if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
			$SSIFile = $2;
			open (SSIFILE,"<$SSIFile");
			while (<SSIFILE>) { print "$_"; }
			close (SSIFILE);
		}
		$line =~ s/\[\!fullname\]/$fullname/g;
		$line =~ s/\[\!images_url\]/$images_url/g;
		print "$line";
	}
	}

}

sub ext_footer {
	# Print the footer of the document
	
	unless ($simplelayout == 1) {
	$flag = 0;
	foreach $line (@dltemplate) {
		if($flag) {
			if ($line =~ /<!--#include\s+(virtual|file)\s*=\s*"*([^"\s]*)"*\s*-->/i) {
				$SSIFile = $2;
				open (SSIFILE,"<$SSIFile");
				while (<SSIFILE>) { print "$_"; }
				close (SSIFILE);
			}
			$line =~ s/\[\!fullname\]/$fullname/g;
			$line =~ s/\[\!images_url\]/$images_url/g;
			print "$line";
		}
		
		if($line =~ /\[\!body\]/i) {
# Ok.. so you got this script for free. Can you imagine
# how long it took me to code all that? About 350 kB of
# pure Perl-Code? And you can't say that this script is
# bad. You get all my work completely free,so is it too
# much if I ask you to leave this link in? Please don't
# remove it, so that others can also find out where the
# script is from and help spreading the script. Because
# you know:  The more people use Schlabo's Scripts, the
# more am I motivated to improve it! Thanks!
print "<p align=\"right\"><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";

			$flag = 1;
		}
		

	}
	} else {
		print "<p><a href=\"http://www.schlabo.com/\" target=\"_blank\"><font face=\"$font_type\" size=\"1\">Schlabo's DL v$d_version</font></a></p>\n";
	}
	
}
