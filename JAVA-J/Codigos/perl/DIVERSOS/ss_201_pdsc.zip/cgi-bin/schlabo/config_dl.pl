#!/usr/bin/perl

use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# -------------------------------------------------------------------------------------
# DL-Specific

# Filename of the Database-File
$d_data_file = "dl_data.txt";

# Filename of the DL-script
$d_script_url = "dl.pl";

# Leech-Protection: Hide real URL and track illegal downloads
$d_antileech = "on";

# Log-File for Leech-Tracking
$d_leech_file = "leech.log";

# Send Leech-Alert Mails to you
$d_leech_alert = "";

# Allow downloading your files: 0 = From every site (don't check)
# 1 = Only from your site or if not set
# 2 = Only from your site
$d_check_referer = "1";

# If a file is not found in the database, add it (on) or don't allow the download (off, you have to add
# new files manually using the Admin-script then, but it prevents people from entering wrong
# URLs and creating useless entries in the log-files.
$d_autoadd = "";

# Notify you per email when someone tries to download a file that's not in the Database
# (Only if autoadd = "on")
$d_notifymissing = "";

# Alias for files automatically added (only important if autoadd = "1";)
$d_autoalias = "auto";

# Automatically replace "_" with " " in the Aliases when you use them to call the DL-Script
$d_autoreplace = "on";

# Write Alias-Counts to files which can be included via SSI so that the dl_showdc.pl-script doesn't
# have to be executed that often on high-traffic-sites, therefore reducing the server-load
$d_countaliastofile = "";

# The path where the Alias-Count-Files are stored (CHMod it to 755)
# Some servers don't support it if you put this into the cgi-bin directory
$d_countaliaspath = "c:/dokumente und einstellungen/a/festplatte/webs/scripts/download/dl_data/";

# Message to display in front of the DC (for dl_showdc.pl)
$d_showdcmessagebefore = "<br><font face=\"Verdana, Arial, Helvetica\" size=\"1\"><i>(Has already been downloaded ";
# 2nd Part of Message (after the number)
$d_showdcmessageafter = " times. <a href=\"http://localhost/cgi-bin/schlabo/dl_gueststats.pl\">View full logs</a>)</i></font>";

# Message to display in front of the Total DC (for dl_showtotaldc.pl)
$d_showtotaldcmessagebefore = "<b>Total number of downloads:</b> ";
$d_showtotaldcmessagemiddle = "<br><b>Number of available files:</b> ";
$d_showtotaldcmessageafter = "<br>(<a href=\"http://localhost/cgi-bin/schlabo/dl_gueststats.pl\">View full logs</a>)";

# Guest-Stats-Status (0=Show All; 1,2,3,...=Show only Top xx;-=Deny)
$d_gueststatus = "0";

# Filename of the Guest-Stats-Script (if in use)
$d_gueststatsscript = "dl_gueststats.pl";

# Link to the files from the guest-stats so that they can be downloaded directly
$d_guestlinks = "on";

# Count how often the Guest-stats have been accessed
$d_countguests = "on";

# If $d_countguests is activated (on), specify the counter-filename here
$d_countfile = "dl_guest.counter";

# Default Upload-URL (specify this only if you use the upload-feature and put most of the files in the same directory)
$d_defaultupload_url = "http://localhost/files/";

# Default Upload-Path (Absolute Server-Path to the same place the Upload-URL points to)
$d_defaultupload_path = "c:/dokumente und einstellungen/a/festplatte/webs/scripts/files/";

# Filename of the Template-File for the DL-Pages
$d_dltemplate = "template_dl.txt";

# Filename of the Template-File for the Gueststats
$d_statstemplate = "template_dl_gueststats.txt";

# Version of this script, do not alter the variable
$d_version = "2.01";

1;
