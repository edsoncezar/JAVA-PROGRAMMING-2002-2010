#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01a            ##
##         last modified: 14/02/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_sp.pl";
require "common.pl";

$scriptname="sp";

umask (0111);

if ($uselocking eq "on") {
	use Fcntl ':flock';  # LOCK_* const
}

&check_referer;
&parse_query;
&get_date;
eval { &get_script_actions; };
if ($@) {
	&showerror("An error occured: $@");
}
exit;

sub get_script_actions {
	# Query and Form Actions
	$dowhat = $QUERY{'action'};
	
	if (($dowhat ne 'login') && ($dowhat ne '')) {
		&get_password;
	}
	if ($uselocking && ($dowhat ne 'login') && ($dowhat ne '')) { &masterlockopen; }
	if ($dowhat eq 'login') { &showlogin; }
	elsif ($dowhat eq 'showadmin') { &showdatafile; }
	elsif ($dowhat eq 'edit') { &showform; }
	elsif ($dowhat eq 'editentry') { &edit_entry; }
	elsif ($dowhat eq 'removeentry') { &remove_entry; }
	elsif ($dowhat eq 'upload_pic_form') { &upload_pic_form; }
	elsif ($dowhat eq 'upload_pic') { &upload_pic; }
	elsif ($dowhat eq '') { &showlogin; }
	else { &novalidquery; }
	if ($uselocking) { &masterlockclose; }
	&html_footer;
}

sub showdatafile {
	if ($s_counting ne "on") {
		&html_header;
		print qq^
		<form action="$server_url$g_admin_url?action=conf_sp" method="post">
		<p><font face="Verdana, Arial, Helvetica" size="2">
		<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<br>Picture-Counting is not activated. If you want to use this feature, please activate it in the SP-Configuration, accessible through the General Admin-Script. 
		Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> to get there.
		</font></p></form>
		^;
		return;
	}
	if (-e $server_datapath.$s_data_file) {
		&read_data_file;
		&html_header;
		if ($data[0][0] eq "") {
			print qq^
			<form action="$server_url$s_admin_url?action=upload_pic_form" method="post">
			<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
			<p><font face="Verdana, Arial, Helvetica" size="2">The data-file is currently empty. The SP-Display-Script will automatically add URLs when pictures are displayed. 
			After URLs are recorded in the database you will be able to use this admin-script to modify or delete data.
			<br><br>Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> to upload and add a new picture.
			</font></p></form>
			^;
			return;
		}
		&bubblesort;
		if ($resorted == 1) { &writedatafile; }
		
		print qq^
		<form action="$server_url$s_admin_url?action=upload_pic_form" method="post">
		<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<p><font face="Verdana, Arial, Helvetica" size="2">This is the log-file of the SP-Script. To edit the URL or Show-Count click on the pencil next to the entry, to remove it (for example if the picture is no longer available), click on the remove-symbol.<br>
		<br>Click <input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here"> to upload and add a new picture.
		</font></p></form>
		<br><font color="#FFCC00">Stats</font><br><hr noshade>
		^;
		print "Total number tracked pictures: <b>".($max_num+1)."</b><br>\n";
		print qq^
		Total number of shown pictures: <b>$totalcount</b><p>
		R = Rank<br>
		SC = Show-Count<br>
		File = URL of the Picture</p>
		<br><font color="#FFCC00">Logs</font><br><hr noshade>
		<table border="0" width="392">
		<tr>
		<td width="30" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>R</b></font></td>
		<td width="20" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>SC</b></font></td>
		<td width="100%" valign="top"><font face="Verdana, Arial, Helvetica" size="2"><b>File</b></font></td>
		<td width="15"></td>
		<td width="15"></td>
		</tr>
		^;
		for ($count=0;$count<=$max_num;$count++) {
			if (($count % 2)==0) {
				print "<tr bgcolor=#276B2E>";
			} else {
				print "<tr>";
			}
			print "<td width=\"30\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\" color=\"#FFCC00\"><b>".($count+1)."</b></font></td>\n";
			print "<td width=\"20\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">";
			print $data[$count][1];
			print "</font></td>\n";
			print "<td width=\"100%\" valign=\"top\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">$data[$count][0]</font></td>\n";

			print "<form action=\"$server_url$s_admin_url?action=edit\" method=\"post\">\n";
			print "<td width=\"15\" valign=\"top\">";
			print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
			print "<input type=\"hidden\" name=\"url\" value=$data[$count][0]>\n";
			print "<input type=\"image\" name=\"Edit\" src=\"".$images_url."entry_edit.gif\" width=15 height=15 alt=\"Edit Entry\">\n";
			print "</td></form>";
			print "<form action=\"$server_url$s_admin_url?action=removeentry\" method=\"post\">\n";
			print "<td width=\"15\" valign=\"top\">";
			print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
			print "<input type=\"hidden\" name=\"url\" value=$data[$count][0]>\n";
			print "<input type=\"image\" name=\"Remove\" src=\"".$images_url."entry_remove.gif\" width=15 height=15 alt=\"Remove Entry\">\n";
			print "</td></form>\n";
			print "</tr>\n";
		}
	
		print "</table>\n";
	} else {
		&html_header;
		print "<br>The database has not been created yet. The SP-Display-Script will automatically create it when the first picture is displayed and it will also automatically add pictures to the database. After this database is created you will be able to use this admin-script to modify or delete data.";
	}
}

sub showform {
	$cururl = param('url');
	&read_data_file;
	$found = 0;
	for ($count=0;$count<=$max_num;$count++) {
		if ($cururl eq $data[$count][0]) {
			$found = 1;
			$curcount = $data[$count][1];
		}
	}
	if ($found == 0) {
		&showerror("The entry you wanted to edit was not found in the database. Please go back to the Logs, reload the page and try it again.");
	}
	
	&html_header;
	
	print "<br><font size=3 color=#FFCC00><b>Edit Entry";
	print "</b></font><br><br></font>\n";
	print qq|
	<form action="$server_url$s_admin_url?action=editentry" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="hidden" name="cur_url" value="$cururl">
	<font face="Verdana, Arial, Helvetica" size="2">Picture URL: <input type="text" size="30" value="$cururl" name="new_url" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	Show-Count: <input type="text" value="$curcount" size="3" name="new_count" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
	<br><br><br></font>
	<table><tr><td>
	<input type="submit" name="submit" value="Edit Entry" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</td>
	</form>
	<form action="$server_url$s_admin_url?action=removeentry" method="post">
	<td>
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="hidden" name="url" value="$cururl">
	<input type="submit" name="submit" value="Remove Entry" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</td>
	</form>
	<form action="$server_url$s_admin_url?action=showadmin" method="post">
	<td>
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="submit" value="Cancel" name="cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</td></tr></table>
	</form>
	|;
}

sub edit_entry {
	$cururl = param('cur_url');
	$newurl = param('new_url');
	$newcount = param('new_count');
	&read_data_file;
	$found = 0;
	
	# Write edited contents to file
	&lockopen(data3,"${server_datapath}${s_data_file}","output");
	for ($count=0;$count<=$max_num;$count++) {
		if ($cururl eq $data[$count][0]) {
			$found = 1;
			print data3 "$newcount|$newurl\n";
		} else {
			print data3 "$data[$count][1]|$data[$count][0]\n";
		}
	}
	&lockclose(data3,"${server_datapath}${s_data_file}");
		
	if ($found == 0) {
		&showerror("The entry you wanted to edit was not found in the database. Please go back to the Logs, reload the page and try it again.");
	}
	
	&html_header;
	
	print "<br><font size=3 color=#FFCC00><b>Success</b></font><br><br>\n";
	print "You have successfully modified the data-file.\n";
	print "<form action=\"$server_url$s_admin_url?action=showadmin\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to view the updated data-file.<p>\n";
	print "</form>\n";	
	print "<br><br><br><br>\n";
}

sub remove_entry {
	$cururl = param('url');
	&read_data_file;
	$found = 0;
	&lockopen(data3,"${server_datapath}${s_data_file}","output");
	for ($count=0;$count<=$max_num;$count++) {
		if ($cururl eq $data[$count][0]) {
			$found = 1;
		} else {
			print data3 "$data[$count][1]|$data[$count][0]\n";
		}
	}
	&lockclose(data3,"${server_datapath}${s_data_file}");
	if ($found == 0) {
		&showerror("The entry you wanted to remove was not found in the database. Please go back to the Logs, reload the page and try it again.");
	}
	
	&html_header;
	
	print "<br><font size=3 color=#FFCC00><b>Success</b></font><br><br>\n";
	print "You have successfully modified the data-file, the URL \"$cururl\" has been removed.\n";
	print "<form action=\"$server_url$s_admin_url?action=showadmin\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to view the updated data-file.<p>\n";
	print "</form>\n";	
	print "<br><br><br><br>\n";
}

sub upload_pic_form {
	&html_header;
	print qq|
	<script language="JavaScript">
	<!--
	function openWin (page) {
		myWin= open("http://www.schlabo.com/help/sp/$s_version/"+page+".shtml", "displayWindow", "width=530,height=300,status=yes,toolbar=no,menubar=no,scrollbars=yes,resizable=yes,titlebar=no");
	}
	// -->
	</script>
	<br><font size=3 color="#FFCC00"><b>Upload and Add a Picture</b></font><br><br>
	Use this to upload the full picture (if you want also a thumbnail) and create the HTML-code for it which you can copy&paste to the HTML-page where you want to link to the picture. If the picture is already on the server you can let the script generate the HTML-code for you.<br>
	<img src="${images_url}arrow.gif" width="4" height="7" align="middle">&nbsp;<a href="javascript:openWin('s_upload_instructions')">Instructions</a><br>
	<form method="POST" action="$server_url$s_admin_url?action=upload_pic" ENCTYPE="multipart/form-data" name="add_form">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<font face="Verdana, Arial, Helvetica" size="2">
	
	
	<br><font color="#FFCC00">Full Picture</font><br><hr noshade>
	<input type="radio" name="exists_upload" value="upload" |;
	if ($server_security eq "on") {
		print " disabled";
		$s_pic_path = "";
	} else {
		print " checked"
	}
	print ">&nbsp;<b>Upload (Picture not on server yet):</b><br>\n";
	print "Picture:<br>\n";
	print "<input onChange=\"document.add_form.exists_upload[0].checked=true;\" type=\"file\" name=\"upload_fullpic\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
	if ($server_security eq "on") { print " disabled" }
	print "><br>Upload-Path:<br>\n";
	print "<input onClick=\"document.add_form.exists_upload[0].checked=true;\" type=\"text\" name=\"upload_path\" value=\"$s_pic_path\" size=\"35\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
	if ($server_security eq "on") { print " disabled" }
	print "><br>URL to this path:<br>\n";
	print "<input onClick=\"document.add_form.exists_upload[0].checked=true;\" type=\"text\" name=\"upload_url\" value=\"$s_pic_url\" size=\"35\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
	if ($server_security eq "on") { print " disabled" }
	print "><br><br><input type=\"radio\" name=\"exists_upload\" value=\"exists\"";
	if ($server_security eq "on") { print " checked" }
	print qq| >&nbsp;<b>Picture is already on the server:</b><br>
	URL+Filename:<br><input onClick="document.add_form.exists_upload[1].checked=true;" type="text" size="35" value="" name="exists_fullpic" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>


	<br><br><font color="#FFCC00">Link-Method</font><br><hr noshade>
	<input type="radio" name="linktype" value="upload" |;
	unless ($server_security eq "on") {
		print " checked"
	} else {
		print " disabled";
	}
	print ">&nbsp;<b>Upload (Thumbnail not on server yet):</b><br>\n";
	print "(Path and URL same as above)<br>\n";
	print "<input onChange=\"document.add_form.linktype[0].checked=true;\" type=\"file\" name=\"upload_thumb\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
	if ($server_security eq "on") { print " disabled" }
	print "><br><br><input type=\"radio\" name=\"linktype\" value=\"exists\">";
	print qq|&nbsp;<b>Thumbnail is already on the server:</b><br>
	URL+Filename:<br>
	<input type="text" value="" name="exists_thumbnail" onClick="document.add_form.linktype[1].checked=true;" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>
	<br><input type="radio" name="linktype" value="text"|;
	if ($server_security eq "on") { print " checked" }
	print qq|>&nbsp;<b>Linktext (Instead of Thumbnail):</b><br>
	<input onClick="document.add_form.linktype[2].checked=true;" type="text" name="link_text" value="" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
	
	
	<br><font color="#FFCC00">Additional Picture-Information (optional)</font><br><hr noshade>
	Description:<br>
	<input type="text" value="" name="description" size="35" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>
	Width of the Thumbnail:<br>
	<input type="text" value="" name="thumb_width" size="5" maxlength="4" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>
	Height of the Thumbnail:<br>
	<input type="text" value="" name="thumb_height" size="5" maxlength="4" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>
	<br><br><font color="#FFCC00">Submit</font><br><hr noshade>
	<table border="0"><tr><td><input type="submit" value="Upload" name="set" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
	</form></td><td>
	<form method="POST" action="$server_url$s_admin_url?action=showadmin">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<input type="submit" value="Cancel" name="cancel" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)"></p>
	</form></td></tr></table>
	|;
}

sub upload_pic {
	# User clicked on back-link from preview
	if (!param('linktype')) {
		&showdatafile;
		exit;
	}
	
	&html_header;
	# Full pic
	$exists_upload = param('exists_upload');
	$pic_upload_fullpic = param('upload_fullpic');
	$pic_path = param('upload_path');
	$pic_url = param('upload_url');
	$pic_exists_fullpic = param('exists_fullpic');
	# Linktype
	$linktype = param('linktype');
	$pic_upload_thumbnail = param('upload_thumb');
	$pic_exists_thumbnail = param('exists_thumbnail');
	$link_text = param('link_text');
	
	$link_text =~ s/\r|\n/ /g;
	$link_text =~ s/\r|\"/&quot;/g;
	$link_text =~ s/</\&lt\;/g;
	$link_text =~ s/>/\&gt\;/g;
	$description = param('description');
	$description =~ s/\r|\n/ /g;
	$description =~ s/\r|\"/&quot;/g;
	$thumb_width = param('thumb_width');
	$thumb_width =~ s/A-Za-z//g;
	$thumb_height = param('thumb_height');
	$thumb_height =~ s/A-Za-z//g;
	
	if ((($exists_upload eq "upload") || ($linktype eq "upload")) && ($server_security eq "on")) {		# Illegal upload - user tricked disabled upload-form
		&showerror("You attempted to upload a file, however uploading has been disabled and is not allowed.");
		exit;
	}
	
	# Check filenames
	if ($exists_upload eq "upload") {
		$pic_fullpic = $pic_upload_fullpic;
	} else {
		$pic_fullpic = $pic_exists_fullpic;
	}
	$pic_fullpic_only = $pic_fullpic;
	$pic_fullpic_only =~ s!^.*(\\|\/)!!;
	
	if ($linktype eq "upload") {
		$pic_thumbnail = $pic_upload_thumbnail;
	} elsif ($linktype eq "exists") {
		$pic_thumbnail = $pic_exists_thumbnail;
	}
	if ($pic_thumbnail ne "") {
		$pic_thumbnail_only = $pic_thumbnail;
		$pic_thumbnail_only =~ s!^.*(\\|\/)!!;
	}
	
	$message = "<b>Warning:</b> ";
	
	if (($pic_fullpic ne "") && ($pic_fullpic_only eq $pic_fullpic) && ($exists_upload eq "exists"))  {
			$message.= "You did only specify a filename for the full picture, not also the URL of it. Most likely the picture will not be found that way.<p>\n";
	}
	if (($pic_thumbnail ne "") && ($pic_thumbnail_only eq $pic_thumbnail) && ($linktype eq "exists")) {
			$message.= "You did only specify a filename for the thumbnail, not also the URL of it. Most likely the picture will not be found that way.<p>\n";
	}
	
	# Upload at least one pic - Check path and URL
	if (($exists_upload eq "upload") || ($linktype eq "upload")) {		
		if (!$pic_path || !$pic_url) {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>The form is not complete. You didn't specify a path and an URL.<br>Please click on the Instructions-Link on the previous page to get detailled instructions on how to use this feature.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		if (((lc(substr($pic_path,length($pic_path)-1,1))) ne "\\") || ((lc(substr($pic_path,length($pic_path)-1,1))) ne "/")) {
		# Check if NT or Linux-path
		if (index($pic_path,"/") == (-1)) {
			$pic_path.="\\";
		} else {
			$pic_path.="/";
		}
		}
		if ((lc(substr($pic_url,length($pic_url)-1,1))) ne "/") {
			$pic_url.="/";
		}
	}
	
	$ext_full = lc(substr($pic_fullpic_only,length($pic_fullpic_only) - 4,4));
	if (($ext_full ne ".jpg") && ($ext_full ne ".gif") && ($ext_full ne "jpeg") && ($ext_full ne ".png")) {
		$message.= "The full picture is not one of the standard picture-formats supported by all web-browsers (.jpg, .gif, .png). It's possible that the browser will not be albe to display the file you uploaded.<p>\n";
	}
		
	# Upload full pic
	if ($exists_upload eq "upload") {
		if ((!$pic_fullpic) || (!$pic_fullpic_only)) {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>You chose to use a picture, however you didn't specify a picture to be uploaded or there is a problem with it.<br>Please click on the Instructions-Link on the previous page to get detailled instructions on how to use this feature.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
	}
	
	# Picture already exists
	if ($exists_upload eq "exists") {
		if ($pic_fullpic eq "") {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>You chose to use a picture that's already on the server, however you did not specify one.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		$picture_url = $pic_fullpic;
	}
	
	# Upload thumbnail
	if ($linktype eq "upload") {
		if (($pic_thumbnail eq "") || ($pic_thumbnail_only eq "")) {
			print "<br><font size=3 color=#FFCC00><b>Thumbnail-Error</b></font><br><br>\n";
			print "<p>You chose to use a thumbnail for the link, however you didn't specify a thumbnail to be uploaded or there is a problem with it.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		if ($pic_fullpic eq $pic_thumbnail) {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>You specified the same file for the full picture and the thumbnail. That's not possible, the thumbnail has to be a different file with its own filename as both files are put in the same directory ";
			print "and the thumbnail should be a small preview-version of the full picture.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		if ($pic_fullpic_only eq $pic_thumbnail_only) {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>The thumbnail and the full picture have the same filename. That's not possible as both files are put in the same directory. Please rename the thumbnail or the full picture and try again.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
	}
	
	# Thumbnail already exists
	if ($linktype eq "exists")  {
		if ($pic_thumbnail eq "") {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>You chose to use a thumbnail that's already on the server, however you did not specify one.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		$thumbnail_url = $pic_thumbnail;
	}
	
	# Linktext
	if ($linktype eq "text") {
		if ($link_text eq "") {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>You chose to use a link-text, however you did not enter a text.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
	} else {
		$ext_thumb = lc(substr($pic_thumbnail_only,length($pic_thumbnail_only) - 4,4));
		if (($ext_thumb ne ".jpg") && ($ext_thumb ne ".gif") && ($ext_thumb ne "jpeg") && ($ext_thumb ne ".png")) {
			$message.= "The thumbnail is not one of the standard picture-formats supported by all web-browsers (.jpg, .gif, .png). It's possible that the browser will not be albe to display the file you uploaded.<p>\n";
		}
	}	

	if ($message ne "<b>Warning:</b> ") {print $message }

	if ($exists_upload eq "upload") {
		# Upload full pic
		my $req = new CGI; 
		my $file = $req->param('upload_fullpic');
		if ($file ne "") {
			open (OUTFILE, ">$pic_path$pic_fullpic_only") or ( print "<b>Critical Error:</b> Unable to save the uploaded file (full picture) to the server. Check if the script has permission to write in the specified directory ($pic_path) and if it's CHMODed to 777 or 755.<br><br>\n" );
			binmode(OUTFILE);			# Required for NT-servers
			while (my $bytesread = read($file, my $buffer, 1024)) { 
				print OUTFILE $buffer; 
			} 
			close (OUTFILE); 
		}
		$picture_url = $pic_url.$pic_fullpic_only;
	}
	
	if ($linktype eq "upload") {
		# Upload Thumbnail
		my $req = new CGI; 
		my $file = $req->param('upload_thumb'); 
		if ($file ne "") {
			open (OUTFILE, ">$pic_path$pic_thumbnail_only") or ( print "<b>Critical Error:</b> Unable to save the uploaded file (thumbnail) to the server. Check if the script has permission to write in the specified directory ($pic_path) and if it's CHMODed to 777 or 755.<br><br>\n" );
			binmode(OUTFILE);
			while (my $bytesread = read($file, my $buffer, 1024)) { 
				print OUTFILE $buffer; 
			} 
			close (OUTFILE); 
		}
		$thumbnail_url = $pic_url.$pic_thumbnail_only;
	}
	
	
	# Add to database if it's activated
	if ($s_counting eq "on") {
		if (-e $server_datapath.$s_data_file) {
			&lockopen(data,"${server_datapath}${s_data_file}","input");
			@tempdata = <data>;
			&lockclose(data);
			
			$found = 0;
			
			&lockopen(data,"${server_datapath}${s_data_file}","output");
			foreach $line (@tempdata) {
				chomp($line);
				($temp_count,$temp_url) = split(/\|/,$line);
				if ($temp_url eq $picture_url) {
					$temp_count += 1;
					$found = 1;
				}
				print data "$temp_count|$temp_url\n";
			}
			if ($found == 0) {
				print data "1|$picture_url\n";
			}
			&lockclose(data,"${server_datapath}${s_data_file}");
		} else {
			open(data,">${server_datapath}${s_data_file}");
			print data "1|$picture_url\n";
			close(data);
			print "<p><font face=\"$font_type\" size=\"2\">[The Database was created]</font></p>\n";
		}
	}
	
	# Replace " " with "_" if activated
	$description_link = $description;
	if (($description_link) && ($s_autoreplace eq "on")) {
		$description_link =~ s/\ /_/g;
	}
	
	# Print Success-Message plus HTML-codes
	print "<br><font size=3 color=\"#FFCC00\"><b>Success</b></font><br><br>";
	print "<font face=\"$font_type\" size=\"2\">";
	if (($exists_upload eq "upload") || ($linktype eq "upload")) {
		print "Uploading was successful.<br>";
	} else {
		if ($s_counting eq "on") {
			print "Adding the picture to the database was successful.<br>";
		}
	}
	print "Copy the HTML-Code below and paste it to the HTML-page where you want the ";
	if (($linktype eq "upload") || ($linktype eq "exists")) {
		print "thumbnail with the link to the full picture to be.<p>";
	} else {
		print "text-link with the link to the full picture to be.<p>";
	}
	$linkcode = "&lt;a href=\"$server_url$s_script_url?";
	if ($description) { $linkcode.= "info=${description_link}&" }
	$linkcode.= "src=${picture_url}\"&gt;";
	if (($linktype eq "upload") || ($linktype eq "exists")) {
		$linkcode.= "&lt;img src=\"$thumbnail_url\" border=\"0\"";
		if ($thumb_width) { $linkcode.= " width=\"$thumb_width\"" }
		if ($thumb_height) { $linkcode.= " height=\"$thumb_height\"" }
		if ($description) { $linkcode.= " alt=\"$description\"" }
		$linkcode.= "&gt;";
	} else {
		$linkcode.= $link_text;
	}
	$linkcode.= "&lt;/a&gt;";
	print "<small>".$linkcode."</small>";
	print "<p>This is the HTML-Code in action:<br>";
	$linkcode =~ s/\&lt\;/</g;
	$linkcode =~ s/\&gt\;/>/g;
	print $linkcode;
	
	# SP_showsp
	$linkcode = "&lt;!-- #include virtual=\"${server_path}sp_showsc.pl?${picture_url}\" --&gt;";
	print "<p><br>To display how often the picture has already been shown, copy and paste the following HTML-code:<p>";
	print "<small>$linkcode</small>";
	
	print "<form action=\"$server_url$s_admin_url?action=showadmin\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to view the updated log.<p>\n";
	print "</form>\n";
	print "<form action=\"$server_url$s_admin_url?action=upload_pic_form\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to upload and add another picture.<p>\n";
	print "</form>\n";
}

sub read_data_file {
	&lockopen(data2,"${server_datapath}${s_data_file}","input") or &showerror("Error reading the database. Try it again, check if the directory and the database-file are CHModed to 777 and take a look at the configuration.");
	@tempdata = <data2>;
	&lockclose(data2,"${server_datapath}${s_data_file}");
	$countup = -1;
	$totalcount = 0;
	foreach $line (@tempdata) {
		chomp($line);
		($temp_count,$temp_url) = split(/\|/,$line);
		$countup += 1;
		$data[$countup][0]=$temp_url;
		$data[$countup][1]=$temp_count;
		$totalcount = $totalcount + $temp_count;
	}
	$max_num = $countup;
}

sub writedatafile {
	&lockopen(data3,"${server_datapath}${s_data_file}","output");
	for ($writecount=0;$writecount<=$max_num;$writecount++) {
		print data3 "$data[$writecount][1]|$data[$writecount][0]\n";
	}
	&lockclose(data3);
}

sub bubblesort {
	$resorted = 0;
	for ($i=$max_num;$i>=0;$i--) {
		for ($j=0;$j<=$i;$j++) {
			if ($data[$j][1] < $data[$j+1][1]) {
				$temp0 = $data[$j][0];
				$temp1 = $data[$j][1];
				$data[$j][0] = $data[$j+1][0];
				$data[$j][1] = $data[$j+1][1];
				$data[$j+1][0] = $temp0;
				$data[$j+1][1] = $temp1;
				$resorted = 1;
			}
		} 
	}
}

sub lockopen {
	local(*FILE,$lockfilename,$inputoutput) = @_;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($inputoutput eq "output") { # Output
		open (FILE,">$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	} else {	# Input
		open (FILE,"<$lockfilename") || &showerror("There has been a problem with opening $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
	if ($uselocking) {
		local($TrysLeft) = 3000;
		while ($TrysLeft--) {
			select(undef,undef,undef,0.01);
			(flock(FILE,6)) || next;
			last;
		}
		unless ($TrysLeft >= 0) {
			&showerror("The server was unable to access $lockfilename. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
		}
	}
}

sub lockclose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}sp_masterlock.lok")
	  && ((stat("${server_datapath}sp_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}sp_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}sp_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access sp_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}sp_masterlock.lok") {
		unlink ("${server_datapath}sp_masterlock.lok");
	}
}

sub init_questions {
	
	$question[0] = "How do I use the SP-Script?";
	$question[1] = "How does the Picture-Counting work?";
	$question[2] = "How does uploading files work?";
	$question[3] = "How can I display how often a picture has already been shown?";
	$question[4] = "Is it possible to display the total amount of shown and available pictures?";
	$question[5] = "How do I use the Guest-Stats?";
	
}