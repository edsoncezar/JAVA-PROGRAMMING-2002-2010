#!/usr/bin/perl

use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01a            ##
##         last modified: 14/02/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# -------------------------------------------------------------------------------------
# General

# Filename of the General Admin-Script
$g_admin_url = "admin.pl";

# Filename of the Users-Admin-Script
$g_admin_users_url = "admin_users.pl";

# Domains that can access this script
@referers = ("yoursite.com");

# Name of the site. Is only used if it's not possible to determine the page the user came from.
$sitetitle = "Sitename";

# URL of the site. Is only used if it's not possible to determine the page the user came from.
$siteurl = "http://www.yoursite.com/";

# Your email-address (Used mainly in the Download-Script so that users can contact you if there's a problem)
# Please note: Write \@ instead of @
$email_address = "you\@yoursite.com";

# The full URL of the Schlabo's Scripts-directory where all data-files and templates and scripts are stored.
$server_url = "http://www.yoursite.com/cgi-bin/schlabo/";

# The full server-path to the Schlabo's Scripts-directory where all the script-files and templates are stored.
$server_path = "/usr/home/yoursite/htdocs/cgi-bin/schlabo/";

# Full server-path for the data-files (can be the same as the server-path to the scripts unless it doesn't work on your server).
$server_datapath = "/usr/home/yoursite/htdocs/cgi-bin/schlabo/";

# Font used by Schlabo's Scripts (not admin-scripts)
$font_type = "Verdana, Arial, Helvetica";

# If you want to track the IPs of the persons who try to access the admin-script,
# set this value to "on", otherwise to ""
$trackip = "on";

# The filename where the IPs should be logged if the above value is set to "on", with the server-path to it.
$trackfile = "ip.log";

# Use File-Locking (if your server supports it you should set this to "on", otherwise change this variable to ""
$uselocking = "on";

# URL of the graphic-files (used by the admin-scripts)
$images_url = "http://www.yoursite.com/images/schlabo/";

# The full path to sendmail or a similar program (for example qmail). Don't include any parameters (for example do NOT include a -t).
# Some NT-Servers don't support this.
$mailprog = "/usr/sbin/sendmail";

# Enable Frequently Asked Questions
$enable_questions = "on";

# Names of the months
@months=("January","February","March","April","May","June","July","August","September","October","November","December");

# Days of each month
@months_days=("31","28","31","30","31","30","31","31","30","31","30","31");

# Update Reminder - When was the last check for an update?
$g_updatecheck = "";

# Enforce Server-Security (No upload, server-paths hidden, no CountAlias-Files)
$server_security = "";

# Version of this script, do not alter the variable
$g_version = "2.01";

# --------------------------------
# Schlabo's Scripts - General Info

# Is the POTD-script installed?
$p_installed = "on";

# Filename of the POTD Admin-Script
$p_admin_url = "potd_admin.pl";

# Is the DL-script installed?
$d_installed = "on";

# Filename of the DL Admin-Script
$d_admin_url = "dl_admin.pl";

# Is the SP-script installed?
$s_installed = "on";

# Filename of the SP Admin-Script
$s_admin_url = "sp_admin.pl";

# Is the COW-script installed?
$c_installed = "on";

# Filename of the COW Admin-Script
$c_admin_url = "cow_admin.pl";

# --------------------------------
# User Information

$crypted_passwords = "on";
@user_names = ("");
@user_passwords = ("");
@user_access_g = ("on");
@user_access_p = ("on");
@user_access_d = ("on");
@user_access_s = ("on");
@user_access_c = ("on");

1;