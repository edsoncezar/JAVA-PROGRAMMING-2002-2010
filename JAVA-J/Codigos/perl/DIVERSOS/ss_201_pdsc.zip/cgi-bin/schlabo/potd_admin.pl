#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01a            ##
##         last modified: 14/02/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1999-2001 Andreas Jakl.  All Rights Reserved.
#
# This program is being distributed as freeware.  It may be used and
# modified by anyone, as long as this copyright notice and the header
# above remain intact Selling the code for this program without prior
# written consent is expressly forbidden.  Obtain permission before
# redistributing this program over the Internet or in any other medium.
# In all cases copyright and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the author of this script, Andreas Jakl, be liable for any damages or
# losses. You use this script on your own risk.


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_potd.pl";
require "common.pl";

$scriptname="potd";

umask (0111);

&check_referer;
&parse_query;
&get_date;
eval { &get_script_actions; };
if ($@) {
	&showerror("An error occured: $@");
}
exit;

sub get_script_actions {
	# Query and Form Actions
	$dowhat = $QUERY{'action'};
	if ($dowhat eq "showadmin") {
		$dowhat = "calendar";
	}
	
	if (($dowhat ne 'login') && ($dowhat ne '')) {
		&get_password;
	}
	if ($uselocking && ($dowhat ne 'login') && ($dowhat ne '')) { &masterlockopen; }
	if ($dowhat eq 'login') { &showlogin; }
	elsif ($dowhat eq 'add') { &add_potd; }
	elsif ($dowhat eq 'showform') { &showform; }
	elsif ($dowhat eq 'calendar') { &showcalendar; }
	elsif ($dowhat eq 'recreatecache') { &recreatecache; }
	elsif ($dowhat eq '') { &showlogin; }
	else { &novalidquery; }
	if ($uselocking) { &masterlockclose; }
	&html_footer;

}

sub showform {
	&read_f_archives;
	&html_header;
	print qq|
	<script language="JavaScript">
	<!--
	function openWin (page) {
		myWin= open("http://www.schlabo.com/help/potd/$p_version/"+page+".shtml", "displayWindow", "width=530,height=300,status=yes,toolbar=no,menubar=no,scrollbars=yes,resizable=yes,titlebar=no");
	}
	// -->
	</script>
	<form action="$server_url$p_admin_url?action=calendar" method="post">
	<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
	<br>Click 
	<input type="image" name="here" src="${images_url}b_here.gif" width=35 height=16 alt="here">
	to get to the calendar.<br>
	<p>With this form you can add a picture to the POTD-Calendar, if it's not on the server yet you can also let the script upload it.<br>
	<img src="${images_url}arrow.gif" width="4" height="7" align="middle">&nbsp;<a href="javascript:openWin('p_upload_instructions')">Instructions</a><br>
	|;
	if ($potd_filename) {
		print "<p>Click <a href=\"".$p_potd_url.$potd_filename."\"><img src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\" border=\"0\"></a> to view the full picture.</p>\n";
	}
	print "</form>\n";
	print qq|
		<form action="$server_url$p_admin_url?action=add" method="post" ENCTYPE="multipart/form-data" name="add_form">
		<input type="hidden" name="pw" value=$param_pw><input type="hidden" name="username" value=$param_username>
		<font color="#FFCC00">Picture-Information</font><br><hr noshade>
		Day: <input type="text" value="$cal_day" maxlength="2" size="2" name="pic_day" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
	        Month: <input type="text" value="$cal_month" size="2" maxlength="2" name="pic_month" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"> 
		Year: <input type="text" value="$cal_year" size="4" maxlength="4" name="pic_year" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		Description:<br><textarea cols=30 rows=5 name="pic_info" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)">$potd_info</textarea><br><br>
		URL:<br><input type="text" size="35" value="$p_potd_url" name="pic_url" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		Submitted by:<br><input type="text" value="$potd_source" size="35" name="pic_source" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		Email/URL:<br><input type="text" value="$potd_source_email" size="35" name="pic_source_email" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br><br>
		<br>
		<font color="#FFCC00">Files</font><br><hr noshade>
		<input type="radio" name="exists_upload" value="upload" |;
		unless (($potd_filename) && ($server_security ne "on")) { print " checked" }
		if ($server_security eq "on") {
			print " disabled";
			$p_potd_path = "";
		}
		print ">&nbsp;<b>Upload (Pics not on server yet):</b><br>\n";
		print "Full Picture:<br>\n";
		print "<input onChange=\"document.add_form.exists_upload[0].checked=true;\" type=\"file\" name=\"upload_fullpic\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
		if ($server_security eq "on") { print " disabled" }
		print "><br>Thumbnail:<br>\n";
		print "<input onChange=\"document.add_form.exists_upload[0].checked=true;\" type=\"file\" name=\"upload_thumbnail\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
		if ($server_security eq "on") { print " disabled" }
		print "><br>Upload-Path (Server-Path to the URL above):<br>\n";
		print "<input onClick=\"document.add_form.exists_upload[0].checked=true;\" type=\"text\" name=\"upload_path\" value=\"$p_potd_path\" size=\"35\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\"";
		if ($server_security eq "on") { print " disabled" }
		print "><br><br><br><input type=\"radio\" name=\"exists_upload\" value=\"exists\"";
		if (($potd_filename) || ($server_security eq "on")) { print " checked" }
		print qq|
		>&nbsp;<b>Both pics are already on the server:</b><br>
		Filename:<br><input onClick="document.add_form.exists_upload[1].checked=true;" type="text" size="35" value="$potd_filename" name="pic_filename" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)"><br>
		<br><br>
		<font color="#FFCC00">Deleting</font><br><hr noshade>
		<input type="checkbox" name="delete">&nbsp;Check this only if you want to delete this POTD!<br><small>(doesn't delete the files from the server)</small></input><br><br><br>
		<font color="#FFCC00">Submit</font><br><hr noshade>
		<input type="submit" name="submit" value="Add Picture" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">&nbsp;
		<input type="reset" name="reset" value="Reset" style="font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)">
		</form>

	|;
	
}



sub read_f_archives {               # Search next free space
	
	if ($QUERY{'month'}) {
		$cal_day=$QUERY{'day'};
		$cal_month=$QUERY{'month'};
		$cal_year=$QUERY{'year'};
	} else {
		$cal_day=$month_day;
		$cal_month=$m;
		$cal_year=$y;
	}
	$act_day=$cal_day;
	$act_month=$cal_month;
	$act_year=$cal_year;
	
	$cur_date=$cal_month."-".$cal_day."-".$cal_year;
	
	&clear_cal;
	&read_c_archives;
	
	if ($QUERY{'day'} eq "") {		# No day specified, find next free day
		while (true) {
			if ($act_day==($months_days[$act_month-1]+1)) {
				$act_month=$act_month+1;
				if ($act_month==13) {
					$act_month=1;
					$act_year=$act_year+1;
				}
				$act_day=1;
				&clear_cal;
				&read_c_archives;
				if ($month_notfound==1) {
					$searchedmonths=$searchedmonths+1;
					if ($searchedmonths == $p_maxgoforward) {
						# Give up trying to find next free position
						$searchedmonths=999;
					}
				} else {
					$searchedmonths=0;
				}
			}
			if ((!$calendar[$act_day][0]) and ($searchedmonths < 999)) {		# Pic available for that day
				$cal_day=$act_day;
				$cal_month=$act_month;
				$cal_year=$act_year;
				last;
			}
			if ($searchedmonths == 999) { last }
			$act_day=$act_day+1;
		}
	} else {						# Read Infos for specified day
		if (-e "$server_datapath$filename") {
			# If a file for this month is already here, read it and store contents in an array
			open(data,"<$server_datapath$filename");
			@all_data = <data>;
			close(data);
			
			$max_num = @all_data;
			
			for ($count=0;$count<$max_num;$count++) {
				$temp_pic_data = @all_data[$count];
				($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
				($c_month,$c_day,$c_year) = split(/-/,$temp_pic_date);
				if ($temp_pic_date eq $cur_date) {
					$p_potd_url = $temp_pic_url;
					$potd_filename = $temp_pic_filename;
					$potd_info = $temp_pic_info;
					$potd_source_email = $temp_source_email;
					$potd_source = $temp_source;
				}
			}	
		}
	}
}

sub clear_cal {
	for ($count=1;($count<32);$count++) {
		$calendar[$count][0]="";
	}
}

sub clear_tempcal {
	for ($count=1;($count<32);$count++) {
		$tempcal[$count]="";
	}
}

sub showcalendar {
	
	if (param('c_month')) {
		$cal_month=param('c_month');
	} elsif ($QUERY{'month'}) {
		$cal_month=$QUERY{'month'};
	} else {
		$cal_month=$m;
	}
	if (param('c_year')) {
		$cal_year=param('c_year');
	} elsif ($QUERY{'year'}) {
		$cal_year=$QUERY{'year'};
	} else {
		$cal_year=$y;
	}
	
	$act_month = $cal_month;
	$act_year = $cal_year;
	&read_c_archives;
	&html_header;
	$p_thumbheight=$p_thumbh + 20;
	
	print "<form action=\"$server_url$p_admin_url?action=showform\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br>Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to add a picture at the next free day.<p>\n";
	print "</form>\n";
	
	print "<form method=\"post\" action=\"$server_url$p_admin_url?action=calendar\">";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<br><font color=\"#FFCC00\">Month to display</font><br><hr noshade>\n";
	print "<select name=\"c_month\" size=\"1\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\">\n";
	for ($count=1;$count<13;$count++) {
		if ($count eq $cal_month) {
			print "<option selected value=\"$count\">$months[$count-1]</option>\n";
		} else {
			print "<option value=\"$count\">$months[$count-1]</option>\n";
		}
	}
	print "</select> \n";
	print "<select name=\"c_year\" size=\"1\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 1px solid rgb(255,204,0)\">\n";
		for ($count=($cal_year-1);$count<($cal_year+10);$count++) {
		if ($count eq $cal_year) {
			print "<option selected value=\"$count\">$count</option>\n";
		} else {
			print "<option value=\"$count\">$count</option>\n";
		}
	}
	print "</select>\n";
	print " <input type=\"submit\" value=\"Change\" name=\"change\" style=\"font-family: Verdana,Arial,Helvetica; font-size: 13; background-color: rgb(0,0,0); color: rgb(255,255,255); border: 2px solid rgb(255,204,0)\">\n";
	print "</form>\n";
	
	&next_prev_month;
	
	print "<font face=\"Verdana, Arial, Helvetica\" size=2 color=\"#FFCC00\"><br>Current Month</font><br><hr noshade>\n";

	print "<br><table width=390 border=0>\n";
	$newline="0";
	print "<tr>";
	
	for ($count=1;$count<($months_days[$cal_month-1]+1);$count++) {
		print "<td height=$p_thumbheight align=\"center\" valign=\"top\">";
		print "<font face=\"Verana, Arial, Helvetica\" size=1>";
		if ($calendar[$count][0]) {
			print "<form action=\"$server_url$p_admin_url?action=showform&day=$count&month=$cal_month&year=$cal_year\" method=\"post\">\n";
			print "<b>Day:</b> $count<br>";
			print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
			print "<input type=\"image\" name=\"set\" src=\"".$calendar[$count][1].$p_thumbtag.$calendar[$count][0]."\" alt=\"$calendar[$count][2]\">\n";
			print "</form>\n";
		} else {
			print "<form action=\"$server_url$p_admin_url?action=showform&day=$count&month=$cal_month&year=$cal_year\" method=\"post\">\n";
			print "<b>Day:</b> $count<br>";
			print "No Pic assigned for this day<br>\n";
			print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
			print "<input type=\"image\" name=\"set\" src=\"".$images_url."b_set.gif\" width=20 height=13 alt=\"Set\">\n";
			print "</form>\n";
		}
		print "</font>";
		print "</td>";
		$newline=$newline + 1;
		if ($newline eq $p_thumbrow) {
			$newline = "0";
			print "</tr><tr>\n";
		}
	
	}
	
	print "</tr></table>";
	
	&next_prev_month;
}

sub next_prev_month {
	print "<table width=390 border=0><tr>\n";
	print "<td width=\"50%\">";
	if ($cal_month eq "1") {
		print "<form action=\"$server_url$p_admin_url?action=calendar&month=12&year=".($cal_year-1)."\" method=\"post\">\n";
	} else {
		print "<form action=\"$server_url$p_admin_url?action=calendar&month=".($cal_month-1)."&year=".($cal_year)."\" method=\"post\">\n";
	}
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<input type=\"image\" name=\"set\" src=\"".$images_url."b_previous.gif\" width=167 height=17 alt=\"<< Previous Month\">\n";
	print "</form>\n";
	print "</td><td width=\"50%\" align=\"right\">";
	if ($cal_month eq "12") {
		print "<form action=\"$server_url$p_admin_url?action=calendar&month=1&year=".($cal_year+1)."\" method=\"post\">\n";
	} else {
		print "<form action=\"$server_url$p_admin_url?action=calendar&month=".($cal_month+1)."&year=".($cal_year)."\" method=\"post\">\n";
	}
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "<input type=\"image\" name=\"set\" src=\"".$images_url."b_next.gif\" width=135 height=17 alt=\"Next Month >>\">\n";
	print "</form>\n";
	print "</td></tr></table>\n";
}

sub read_c_archives {
	
	$filename="potd_".$act_month."-".$act_year.".txt";
	if (-e "$server_datapath$filename") {
		# If a file for this month is already here, read it and store contents in an array
		open(data,"<$server_datapath$filename");
		@all_data = <data>;
		close(data);
		
		$max_num = @all_data;
		
		for ($count=0;$count<$max_num;$count++) {
			$temp_pic_data = @all_data[$count];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($c_month,$c_day,$c_year) = split(/-/,$temp_pic_date);
			$calendar[$c_day][0]=$temp_pic_filename;
			$calendar[$c_day][1]=$temp_pic_url;
			$calendar[$c_day][2]=$temp_pic_info;
			#$calendar[$c_day][3]=$temp_pic_date;
			#$calendar[$c_day][4]=$temp_source_email;
			#$calendar[$c_day][5]=$temp_source;
		}	
	} else {
		$month_notfound=1;
	}
}

sub delete_potd {
	$pic_day=param('pic_day');
	$pic_month=param('pic_month');
	$pic_year=param('pic_year');
	
	&html_header;
	
	$filename="potd_".$pic_month."-".$pic_year.".txt";
	if (-e "$server_datapath$filename") {
		open(data,"<$server_datapath$filename");      # Put contents of file into an array
		@all_data = <data>;
		close(data);
		$max_num = @all_data;
		for ($count=0;$count<$max_num;$count++) {
			$temp_pic_data = @all_data[$count];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($c_month,$c_day,$c_year) = split(/-/,$temp_pic_date);
			$month_data[$c_day][0]=$temp_pic_filename;
			$month_data[$c_day][1]=$temp_pic_url;
			$month_data[$c_day][2]=$temp_pic_info;
			$month_data[$c_day][3]=$temp_pic_date;
			$month_data[$c_day][4]=$temp_source_email;
			$month_data[$c_day][5]=$temp_source;
		}	
		$month_data[$pic_day][0]="";
		$month_data[$pic_day][1]="";
		$month_data[$pic_day][2]="";
		$month_data[$pic_day][3]="";
		$month_data[$pic_day][4]="";
		$month_data[$pic_day][5]="";
		open(data,">$server_datapath$filename") || &showerror("An error occured when trying to save the changes. Please make sure the script-permissions are set correctly on the server and you CHMODed the Schlabo's Scripts-directory to either 777 or 755 (depending on your server).");
		for ($count=1;$count<($months_days[$pic_month-1]+1);$count++) {
			if ($month_data[$count][0]) {
				print data $month_data[$count][3]."::".$month_data[$count][1]."::".$month_data[$count][0]."::".$month_data[$count][2]."::".$month_data[$count][4]."::".$month_data[$count][5]."::\n";
			}
		}
		close(data);
		
		# Check if deleted picture = pic currently displayed by thumbnail-script
		open(curpotd_f,"<${server_datapath}potd_current.txt") || ($curpotd_found=3);
		@curpotd = <curpotd_f>;
		close(curpotd_f);
		$prev_date=@curpotd[0];
		$prev_date=~ s/\<\!--//g;
		$prev_date=~ s/\/\/--\>//g;
		$prev_date =~ s/\r|\n//g;
		$cur_date = $pic_month."-".$pic_day."-".$pic_year;
		#($prev_month,$prev_day,$prev_year) = split(/-/,$prev_date);
		if (($cur_date eq $prev_date) || ($curpotd_found==3)) {
			# curpotd-file has to be updated/created
			$includecurrentday = 0;
			&find_previous;
			if ($found eq "1") {				
				$curpotdline = "<a href=\"";
				if ($p_newwindow eq "on") { $curpotdline.= "javascript:openWin('" }
				$curpotdline.= "$server_url$p_script_url\?day=${prev_day}\&month=$prev_month\&year=$prev_year";
				if ($p_newwindow eq "on") { $curpotdline.= "');" }
				$curpotdline .= "\"><img src=\"".$temp_pic_url.$p_thumbtag.$temp_pic_filename."\" ";
				if ($p_thumbw) { $curpotdline = $curpotdline."width=$p_thumbw " }
				if ($p_thumbh) { $curpotdline = $curpotdline."width=$p_thumbh " }
				$curpotdline = $curpotdline."alt=\"".$temp_pic_info."\" border=0></a><br>$temp_pic_info";
				open(curpotd_f,">${server_datapath}potd_current.txt") || (&showerror("The script was unable to create the potd_current.txt-file in the Schlabo's Scripts-directory. Please check if the permissions are set correctly and you didn't forget to CHMOD the Schlabo's Scripts-directory to either 777 or 755 (depending on your server, try both)."));
				print curpotd_f "<!--".$prev_month."-".$prev_day."-".$prev_year."//-->\n";
				print curpotd_f $curpotdline;
				close(curpotd_f);
				$curpotd_found=4;
			} else {
				open(curpotd_f,">${server_datapath}potd_current.txt") || (&showerror("The script was unable to create the potd_current.txt-file in the Schlabo's Scripts-directory. Please check if the permissions are set correctly and you didn't forget to CHMOD the Schlabo's Scripts-directory to either 777 or 755 (depending on your server, try both)."));
				close(curpotd_f);
				$curpotd_found=5;
			}
		}
		
		print "<br><font size=3 color=#FFCC00><b>POTD Deleted</b></font><br><br>\n";
		print "The picture from ".$pic_month."-".$pic_day."-".$pic_year." has been successfully deleted.<br><br>\n";
		if ($curpotd_found==4) {
			print "As the POTD you just deleted was the one currently displayed by the Thumbnail-script, the thumbnail was automatically changend ";
			print "to the previous one found in the databases:<br>\n";
			print $prev_month."-".$prev_day."-".$prev_year."<br>\n";
			print "<a href=\"$temp_pic_url$temp_pic_filename\"><img src=\"".$temp_pic_url.$p_thumbtag.$temp_pic_filename."\"></a><br><br>\n";
		}
		if ($curpotd_found==5) {
			print "The POTD you just deleted was the one currently displayed by the Thumbnail-script, ";
			if ($p_showprevious eq "on") { print "no previous picture was found to be displayed instead, " }
			print "so the script will now display the N/A-picture until you assign a new picture to a day.<br><br>\n";
		}
		
		print "<form action=\"$server_url$p_admin_url?action=showform\" method=\"post\">\n";
		print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
		print "Click ";
		print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
		print " to add a new picture.<p></form>\n";
		
		print "<form action=\"$server_url$p_admin_url?action=calendar&month=".$pic_month."&year=".$pic_year."\" method=\"post\">\n";
		print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
		print "Click ";
		print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
		print " to get to the calendar.<p></form>\n";		
		print "<br><br><br><br>\n";

	} else {
		print "<br><b>Error:</b> Data-file not found.<br>Filename: ".$filename;
		print "<br><br><br><br>\n";
	}
		
}

sub find_previous {
	$found="0";
	$cal_month = $m;
	$cal_year = $y;
	$cal_day = $month_day;
	if ($includecurrentday == 1) {
		$cal_day += 1;
	}
	$filename="potd_".$cal_month."-".$cal_year.".txt";
	&clear_tempcal;
	if (-e "$server_datapath$filename") {
		open(data,"<$server_datapath$filename");      # Put contents of file into an array
		@all_data = <data>;
		close(data);
		$max_num = @all_data;
		# The above array was sorted by entries, now put it into another one sorted by days ($tempcal[])
		for ($count_d=$max_num;$count_d>(-1);$count_d--) {
			$temp_pic_data = @all_data[$count_d];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
			if (($temp_day ne "") && ($temp_day < $cal_day)) {
				$prev_day=$temp_day;
				$prev_month=$temp_month;
				$prev_year=$temp_year;
				$found="1";
				last;
			}
		}
	}
	if ($found eq "0") {        # If no free space in the current month, search months of the rest of the year
		$t_month=$cal_month;
		$t_year=$cal_year;
		for ($countup=0;$countup<$p_goback;$countup++) {
			$t_month=$t_month-1;
			if ($t_month eq "0") {
				$t_month=12;
				$t_year=$t_year-1;
			}
			&clear_tempcal;
			$filename="potd_".$t_month."-".$t_year.".txt";
			if (-e "$server_datapath$filename") {
				open(data,"<$server_datapath$filename");      # Put contents of file into an array
				@all_data = <data>;
				close(data);
				$max_num = @all_data;
				for ($count_d=$max_num;$count_d>(-1);$count_d--) {
					$temp_pic_data = @all_data[$count_d];
					($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
					($temp_month,$temp_day,$temp_year) = split(/-/,$temp_pic_date);
					if ($temp_pic_date ne "") {
						$prev_day=$temp_day;
						$prev_month=$temp_month;
						$prev_year=$temp_year;
						$found="1";
						last;
					}
				}
			}
			if ($found eq "1") {
				last;
			}
		}
	}
	# Check if specified date is not in the future..
	if ($found eq "1") {
		$m2=$m;
		if (length($m2) eq "1") {
			$m2 = "0".$m;
		}
		$month_day2=$month_day;
		if (length($month_day2) eq "1") {
			$month_day2="0".$month_day;
		}
		$testnow = $y.$m2.$month_day2;
		$prev_day2=$prev_day;
		if (length($prev_day2) eq "1") {
			$prev_day2="0".$prev_day;
		}
		if (length($prev_month) eq "1") {
			$testnew = $prev_year."0".$prev_month.$prev_day2;
		} else {
			$testnew = $prev_year.$prev_month.$prev_day2;
		}
		if ($testnow < $testnew) {      # Next picture is from the future, so don't display a link to it
			$found = "0";
		}
	}
}


sub add_potd {
	
	if (param('delete')) {
		&delete_potd;
		return;
	}
	
	$pic_filename = param('pic_filename');
	$pic_url = param('pic_url');
	$pic_day = param('pic_day');
	$pic_month = param('pic_month');
	$pic_year = param('pic_year');
	$pic_date = $pic_month."-".$pic_day."-".$pic_year;
	$pic_info = param('pic_info');
	$pic_info =~ s/\r|\n/ /g;
	$pic_info =~ s/\r|\"/&quot;/g;
	$pic_source_email = param('pic_source_email');
	$pic_source = param('pic_source');
	$pic_upload_fullpic = param('upload_fullpic');
	$pic_upload_thumbnail = param('upload_thumbnail');
	$pic_path = param('upload_path');
	$pic_exists_upload = param('exists_upload');
	
	chomp($pic_info);
	
	if (($pic_exists_upload eq "upload") && ($server_security eq "on")) {		# Illegal upload - user tricked disabled upload-form
		&showerror("You attempted to upload a file, however uploading has been disabled and is not allowed.");
		exit;
	}
	
	&html_header;
	
	
	if ($pic_upload_fullpic && $pic_upload_thumbnail && $pic_url && ($pic_exists_upload eq "upload")) {	# Upload pictures
		# Check Directories
		unless (((lc(substr($pic_path,length($pic_path)-1,1))) eq "\\") || ((lc(substr($pic_path,length($pic_path)-1,1))) eq "/")) {
			# Check if NT or Linux-path
			if (index($pic_path,"/") == (-1)) {
				$pic_path.="\\";
			} else {
				$pic_path.="/";
			}
		}
		if ((lc(substr($pic_url,length($pic_url)-1,1))) ne "/") {
			$pic_url.="/";
		}
		# Check filenames
		$pic_upload_fullpic_only = $pic_upload_fullpic;
		$pic_upload_fullpic_only =~ s!^.*(\\|\/)!!;
		$pic_upload_thumbnail_only = $pic_upload_thumbnail;
		$pic_upload_thumbnail_only =~ s!^.*(\\|\/)!!;
		$ext_full = lc(substr($pic_upload_fullpic_only,length($pic_upload_fullpic_only) - 4,4));
		$ext_thumb = lc(substr($pic_upload_thumbnail_only,length($pic_upload_thumbnail_only) - 4,4));
		if ($ext_full ne $ext_thumb) {		
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>The full picture (now: \"<i>$ext_full</i>\") has to have the same extension, therefore the same picture-type as the thumbnail (now: \"<i>$ext_thumb</i>\"). Please fix that and try again, the picture has <b>NOT</b> been uploaded and added.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
		$message = "<b>Warning:</b> ";
		if (($ext_full ne ".jpg") && ($ext_full ne ".gif") && ($ext_full ne "jpeg") && ($ext_full ne ".png")) {
			$message.= "The uploaded files are not one of the standard picture-formats supported by all web-browsers (.jpg, .gif, .png). It's possible that the browser will not be albe to display the file you uploaded.<p>\n";
		}
		if ($pic_upload_fullpic eq $pic_upload_thumbnail) {
			$change_t = 1;
			$message.= "You specified the same file for the thumbnail and the full picture. That isn't recommended, you should resize the thumbnail to make it smaller (current configuration: ${p_thumbw}x${p_thumbh}), therefore reducing the loading-time and making the small picture smoother. The file will be uploaded anyway, the thumbnail will be renamed to the correct filename.<p>\n";
		} else {
			if ((lc(substr($pic_upload_thumbnail_only,0,length($p_thumbtag)))) ne $p_thumbtag) {
				$change_t = 1;
				$message.= "The thumbnail-file doesn't have the correct filename, it has to have the thumbnail-tag you specified in the POTD-configuration (\"$p_thumbtag\") at the beginning of it. It will be corrected automatically.<p>\n";
			}
			if ((lc(substr($pic_upload_thumbnail_only,length($p_thumbtag),length($pic_upload_thumbnail_only)-length($p_thumbtag)))) ne $pic_upload_fullpic_only) {
				$change_t = 1;
				$message.= "The thumbnail-filename isn't the same as the full picture-filename. It will be changed automatically.<p>\n";
			}
		}
		if ($message ne "<b>Warning:</b> ") {print $message }
		if ($change_t == 1) {
			# Correct thumbnail filename
			$pic_upload_thumbnail_only = $p_thumbtag.$pic_upload_fullpic_only;
			print "The thumbnail-filename has been changed to: <i>$pic_upload_thumbnail_only</i><p>\n";
		}
		
			
		# Upload full pic
		my $req = new CGI; 
		my $file = $req->param('upload_fullpic');
		if ($file ne "") {
			open (OUTFILE, ">$pic_path$pic_upload_fullpic_only") or ( print "<b>Critical Error:</b> Unable to save the uploaded file (full picture) to the server. Check if the script has permission to write in the specified directory ($pic_path) and if it's CHMODed to 777 or 755.<br><br>\n" );
			binmode(OUTFILE);			# Required for NT-servers
			while (my $bytesread = read($file, my $buffer, 1024)) { 
				print OUTFILE $buffer; 
			} 
			close (OUTFILE); 
		}
		
		# Upload Thumbnail
		my $req = new CGI; 
		my $file = $req->param('upload_thumbnail'); 
		if ($file ne "") {
			open (OUTFILE, ">$pic_path$pic_upload_thumbnail_only") or ( print "<b>Critical Error:</b> Unable to save the uploaded file (thumbnail) to the server. Check if the script has permission to write in the specified directory ($pic_path) and if it's CHMODed to 777 or 755.<br><br>\n" );
			binmode(OUTFILE);
			while (my $bytesread = read($file, my $buffer, 1024)) { 
				print OUTFILE $buffer; 
			} 
			close (OUTFILE); 
		}
		
		$pic_filename = $pic_upload_fullpic_only;
	} else {
		if (!$pic_filename or !$pic_url) {
			print "<br><font size=3 color=#FFCC00><b>Critical Error</b></font><br><br>\n";
			print "<p>The form is not complete.<br><br>\n";
			print "If you want to upload the pictures specify both of them (full picture and thumbnail) and not just one file.";
			if (!$pic_url) { print " Also don't remove the URL of the directory where the images will be uploaded to (check the configuration on that)." }
			print "<br><br>\n";
			print "If both files (full picture and thumbnail) are already on the server in the correct directory, please specify the filename of the full picture and the URL of it.<br><br>\n";
			print "Here again how it works: Open your big, high quality-picture (for example mypic.jpg) in your favourite graphics-program, resize it to ${p_thumbw}x${p_thumbh} and save the thumbnail as ${p_thumbtag}mypic.jpg.<br>\n";
			print "Then either upload both files using the Add-Picture-form or upload them yourself using FTP and specify the filename of the full picture.<p>\n";
			print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
			return;
		}
	}
	

	
	$filename="potd_".$pic_month."-".$pic_year.".txt";
	if (-e "$server_datapath$filename") {
		# If a file for this month is alread here, read it and store contents in an array
		open(data,"<$server_datapath$filename");
		@all_data = <data>;
		close(data);
		
		$max_num = @all_data;
		
		for ($count=0;$count<$max_num;$count++) {
			$temp_pic_data = @all_data[$count];
			($temp_pic_date,$temp_pic_url,$temp_pic_filename,$temp_pic_info,$temp_source_email,$temp_source) = split(/::/,$temp_pic_data);
			($c_month,$c_day,$c_year) = split(/-/,$temp_pic_date);
			$month_data[$c_day][0]=$temp_pic_filename;
			$month_data[$c_day][1]=$temp_pic_url;
			$month_data[$c_day][2]=$temp_pic_info;
			$month_data[$c_day][3]=$temp_pic_date;
			$month_data[$c_day][4]=$temp_source_email;
			$month_data[$c_day][5]=$temp_source;
		}	
	}
	
	$month_data[$pic_day][0]=$pic_filename;
	$month_data[$pic_day][1]=$pic_url;
	$month_data[$pic_day][2]=$pic_info;
	$month_data[$pic_day][3]=$pic_date;
	$month_data[$pic_day][4]=$pic_source_email;
	$month_data[$pic_day][5]=$pic_source;
	
	open(data,">$server_datapath$filename") or &showerror("An error occured when trying to save the changes. Please make sure the script-permissions are set correctly on the server and you CHMODed the Schlabo's Scripts-directory to either 777 or 755 (depending on your server).");
	for ($count=1;$count<($months_days[$pic_month-1]+1);$count++) {
		if ($month_data[$count][0]) {
			print data $month_data[$count][3]."::".$month_data[$count][1]."::".$month_data[$count][0]."::".$month_data[$count][2]."::".$month_data[$count][4]."::".$month_data[$count][5]."::\n";
		}
	}
	close(data);
	

	# Check if added pic is from the future
	$m2=$m;
	if (length($m2) eq "1") {
		$m2 = "0".$m;
	}
	$month_day2=$month_day;
	if (length($month_day2) eq "1") {
		$month_day2="0".$month_day;
	}
	$testnow = $y.$m2.$month_day2;
	$pic_day2=$pic_day;
	if (length($pic_day2) eq "1") {
		$pic_day2="0".$pic_day;
	}
	if (length($pic_month) eq "1") {
		$testnew = $pic_year."0".$pic_month.$pic_day2;
	} else {
		$testnew = $pic_year.$pic_month.$pic_day2;
	}
	if ($testnew <= $testnow) {      # Next picture is from the future, so don't change the current thumbnail
		# Check if potd_current.txt has to be updated
		open(curpotd_f,"<${server_datapath}potd_current.txt") || ($curpotd_found=3);
		@curpotd = <curpotd_f>;
		close(curpotd_f);
		$prev_date=@curpotd[0];
		$prev_date =~ s/\r|\n//g;
		$pic_year =~ s/\r|\n//g;
		($prev_month,$prev_day,$prev_year) = split(/-/,$prev_date);
		if (($pic_year>$prev_year) || (($pic_month>$prev_month) && ($pic_year==$prev_year)) || (($pic_day>$prev_day) && ($pic_month==$prev_month) && ($pic_year==$prev_year)) || (($pic_day==$prev_day) && ($pic_month==$prev_month) && ($pic_year==$prev_year)) || ($curpotd_found==3)) {
			# curpotd-file has to be updated/created
			$curpotdline = "<a href=\"";
			if ($p_newwindow eq "on") { $curpotdline.= "javascript:openWin('" }
			$curpotdline.= "$server_url$p_script_url\?day=${pic_day}\&month=$pic_month\&year=$pic_year";
			if ($p_newwindow eq "on") { $curpotdline.= "');" }
			$curpotdline .= "\"><img src=\"".$pic_url.$p_thumbtag.$pic_filename."\" ";
			if ($p_thumbw) { $curpotdline = $curpotdline."width=$p_thumbw " }
			if ($p_thumbh) { $curpotdline = $curpotdline."height=$p_thumbh " }
			$curpotdline = $curpotdline."alt=\"".$pic_info."\" border=0></a><br>$pic_info";
			open(curpotd_f,">${server_datapath}potd_current.txt") || (&showerror("The script was unable to create the potd_current.txt-file in the Schlabo's Scripts-directory. Please check if the permissions are set correctly and you didn't forget to CHMOD the Schlabo's Scripts-directory to either 777 or 755 (depending on your server, try both)."));
			print curpotd_f "<!--".$pic_month."-".$pic_day."-".$pic_year."//-->\n";
			print curpotd_f $curpotdline;
			close(curpotd_f);
			$curpotd_found=4;
		}
	}
	
	print "<br><font size=3 color=#FFCC00><b>Done Updating</b></font><br><br>\n";
	print "<b>Picture added for $pic_date:</b><br>\n";
	print "<a href=\"$pic_url$pic_filename\" target=\"_blank\"><img src=\"".$pic_url.$p_thumbtag.$pic_filename."\"></a><br><br>\n";
	
	if ($curpotd_found==4) {
		print "The thumbnail that will be displayed by the Thumbnail-script has been updated.<br><br>\n";
	}
	
	if (($p_notifyvisitor eq "on") && ($pic_source_email ne "") && ($mailprog ne "") && ($pic_source_email ne $email_address) && (param('pic_filename') eq "")) {
		$email_address =~ s/\\\@/\@/g;
		if (index($pic_source_email, "@") == (-1)) {			# URL
			print "The script can't send a mail to the visitor who sent the POTD in as the specified source is a URL and no email-address.<br><br>\n";
		} elsif (($email_address eq "") or ($email_address eq "yourname\@yoursite.com")) {
			print "The script was unable to send out an email to the visitor as you didn't specify your own email-address in the general configuration.<br><br>\n";
		} else {							# Email-Address
			open (MAIL, "|$mailprog -t") || &showerror("The POTD was added to the database but the script wasn't able to send the mail to the visitor - Can't open $mailprog!");
			print MAIL "From: $email_address\n";
			print MAIL "To: $pic_source_email\n";
			print MAIL "Subject: Schlabo's Scripts - Your Picture of the Day\n\n";
print MAIL <<EOF;
Hello!

The Picture of the Day you submitted to $sitetitle with the filename "$pic_filename" will be used on ${pic_month}-${pic_day}-${pic_year} and you've of course been credited for sending it in.
If you're interested in seeing your picture online that day, please visit $siteurl

Thanks for sending us your POTD!

Generated by Schlabo's Picture of the Day v${p_version} - Get it for free from http://www.schlabo.com/
EOF
			close (MAIL);
			print "The script sent a notification-email to <i>$pic_source_email</i> about the day the POTD will be used.<br><br>\n";
		}
	}
	if (($p_notifyvisitor eq "on") && ($pic_source_email eq "")) {
		print "The script wasn't able to send a mail to the visitor who sent the POTD in as no email-address was specified.<br><br>\n";
	}
	if (($p_notifyvisitor eq "on") && ($pic_source_email ne "") && ($pic_source_email eq $email_address)) {
		print "The script didn't send out a notification-email as the email-address for this picture is the same as the admin-email-address.<br><br>\n";
	}
	
	
	print "<form action=\"$server_url$p_admin_url?action=showform\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to add another picture.<p></form>\n";
	
	print "<form action=\"$server_url$p_admin_url?action=calendar&month=".$pic_month."&year=".$pic_year."\" method=\"post\">\n";
	print "<input type=\"hidden\" name=\"pw\" value=$param_pw><input type=\"hidden\" name=\"username\" value=$param_username>\n";
	print "Click ";
	print "<input type=\"image\" name=\"here\" src=\"".$images_url."b_here.gif\" width=35 height=16 alt=\"here\">";
	print " to get to the calendar.<p></form>\n";	
	
}

sub recreatecache {
	$includecurrentday = 1;
	&find_previous;
	&html_header;
	if ($found eq "1") {
		$curpotdline = "<a href=\"";
		if ($p_newwindow eq "on") { $curpotdline.= "javascript:openWin('" }
		$curpotdline.= "$server_url$p_script_url\?day=${prev_day}\&month=$prev_month\&year=$prev_year";
		if ($p_newwindow eq "on") { $curpotdline.= "');" }
		$curpotdline .= "\"><img src=\"".$temp_pic_url.$p_thumbtag.$temp_pic_filename."\" ";
		if ($p_thumbw) { $curpotdline = $curpotdline."width=$p_thumbw " }
		if ($p_thumbh) { $curpotdline = $curpotdline."width=$p_thumbh " }
		$curpotdline = $curpotdline."alt=\"".$temp_pic_info."\" border=0></a><br>$temp_pic_info";
		open(curpotd_f,">${server_datapath}potd_current.txt") || (&showerror("The script was unable to create the potd_current.txt-file in the Schlabo's Scripts-directory. Please check if the permissions are set correctly and you didn't forget to CHMOD the Schlabo's Scripts-directory to either 777 or 755 (depending on your server, try both)."));
		print curpotd_f "<!--".$prev_month."-".$prev_day."-".$prev_year."//-->\n";
		print curpotd_f $curpotdline;
		close(curpotd_f);
		print "<br><font size=3 color=#FFCC00><b>Cache Recreated</b></font><br><br>\n";
		print "The picture which the POTD Thumbnail-Script displays has now been updated, using the current POTD-configuration.<br>\n";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
	} else {
		print "<br><font size=3 color=#FFCC00><b>No Picture found</b></font><br><br>\n";
		print "The script didn't find a picture which can be displayed by the POTD-thumbnail-script.<br><br>\n";
		print "If no picture has been added yet, the cache will be automatically updated when you add the first picture.<br><br>\n";
		print "If the previous picture more than $p_goback months old, try increasing the Backward-Search Range in the POTD-Configuration.<br><br><br>";
		print "Press the Back-button of your browser or <a href=\"javascript: history.back()\">click here</a> to get back to the previous page.<p>";
	}
}

sub masterlockopen {
	local($TrysLeft) = 6000;
	$time = time;
	if ((-e "${server_datapath}potd_masterlock.lok")
	  && ((stat("${server_datapath}potd_masterlock.lok"))[9]+15<$time)) {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
	while ($TrysLeft--) {
		if (-e "${server_datapath}potd_masterlock.lok") {
			select(undef,undef,undef,0.01);
		}
		else {
			open (MASTERLOCKFILE,">${server_datapath}potd_masterlock.lok");
			print MASTERLOCKFILE "\n";
			close (MASTERLOCKFILE);
			last;
		}
	}
	unless ($TrysLeft >= 0) {
		$uselocking = 0;
		&showerror("The server was unable to access potd_masterlock.lok. Please try again later, if it still doesn't work please contact <a href=\"mailto:$email_address\">$email_address</a>. Thanks");
	}
}

sub masterlockclose {
	if (-e "${server_datapath}potd_masterlock.lok") {
		unlink ("${server_datapath}potd_masterlock.lok");
	}
}


sub init_questions {
	
	$question[0] = "How do I add a picture? ";
	$question[1] = "How can I delete a POTD?";
	$question[2] = "What's the Visitor-Gallery?";
	$question[3] = "How can I include the thumbnail in the newspage?";
	$question[4] = "How does opening a POTD in a new window work?";
	
}