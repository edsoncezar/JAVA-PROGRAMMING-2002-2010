#!/usr/bin/perl
   
use CGI qw(:standard) ;

############################################
##                                        ##
##            Schlabo's Scripts           ##
##             by Andreas Jakl            ##
##      (e-mail andreas@schlabo.com)      ##
##                                        ##
##             version:  2.01             ##
##         last modified: 09/01/02        ##
##         copyright (c) 1999-2002        ##
##                                        ##
##    latest version is available from    ##
##         http://www.schlabo.com/        ##
##                                        ##
############################################


# Find an explanation of $require_path in admin.pl
$require_path = substr($ENV{'SCRIPT_FILENAME'},0,rindex($ENV{'SCRIPT_FILENAME'},"/"));
$IIS = 0;

# You don't have to modify anything below here.
if ($IIS != 2) {
	if ($IIS == 0) {
		if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) {
			$IIS = 1 
		}
	}
	if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) {
		chdir($1);
	}
	if ($IIS == 1) {
		print "HTTP/1.0 200 OK\n";
	}
}

if ($require_path) {
	push(@INC, $require_path);
}

require "config.pl";
require "config_potd.pl";

umask (0111);

print "Content-type: text/html\n\n";

&get_date;
$cur_date=$m."-".$month_day."-".$y;

open(curpotd_f,"<${server_datapath}potd_current.txt") || ($curpotd_found=3);
@curpotd = <curpotd_f>;
close(curpotd_f);

if ($curpotd_found ne "3") {
	$prev_date=@curpotd[0];
	$prev_date=~ s/\<\!--//g;
	$prev_date=~ s/\/\/--\>//g;
	$curpotdline = @curpotd[1];
	$prev_date =~ s/\r|\n//g;
	if ($prev_date eq $cur_date) {
		$curpotd_found=1;	# 3=file not found, 2=pic old, 1=found
	} else {
		$curpotd_found=2;
	}
}

if (param('updatepic') eq "1") {
	$curpotd_found=2;
	$updatepiconly=1;
}

if ($curpotd_found ne "1") {	# The POTD specified in the potd_current.txt-file isn't from today, look if there's a new one.
	$filename="potd_".$m."-".$y.".txt";
	open(data,"<${server_datapath}$filename");
	@all_data = <data>;
	close(data);
	$max_num = @all_data;
	
	for ($count_d=0;$count_d<$max_num;$count_d++) {
		$pic_data = @all_data[$count_d];
		($pic_date,$pic_url,$pic_filename,$pic_info,$pic_source_email,$pic_source) = split(/::/,$pic_data);
		if ($pic_date eq $cur_date) {     # Picture found for today
			$curpotdline = "<a href=\"";
			if ($p_newwindow eq "on") { $curpotdline.= "javascript:openWin('" }
			$curpotdline.= "$server_url$p_script_url\?day=${month_day}\&month=$m\&year=$y";
			if ($p_newwindow eq "on") { $curpotdline.= "');" }
			$curpotdline .= "\"><img src=\"".$pic_url.$p_thumbtag.$pic_filename."\" ";
			if ($p_thumbw) { $curpotdline.= "width=$p_thumbw " }
			if ($p_thumbh) { $curpotdline.= "height=$p_thumbh " }
			$curpotdline.= "alt=\"".$pic_info."\" border=0></a>";
			$curpotdline.= "<br>$pic_info";
			$curpotd_found = 1;
			last;
		}
	}
	if ($curpotd_found == 1) {	# New picture found for today
		open(curpotd_f,">${server_datapath}potd_current.txt") || (print "[potd_thumbnail: Unable to create Current Potd-file in Schlabo's Scripts-directory]");
		print curpotd_f "<!--".$cur_date."//-->\n";
		print curpotd_f $curpotdline;
		close(curpotd_f);
	}
}

if ($updatepiconly == 1) {
	exit;
}

if (($curpotd_found == 1) || (($curpotd_found == 2) && ($p_showprevious eq "on") && $curpotdline)) {	# script has a pic to display
	if ($p_newwindow eq "on") {
		print "<script language=\"Javascript\">\n";
		print "<!--\n";
		print "function openWin(schlabourl) {\n";
		print "  picwin = open(\"\", \"displayWindow\", \"$p_newwindow_properties\");\n";
		print "  picwin.document.open();\n";
		print "  picwin.document.write(\"<html><head><meta http-equiv='REFRESH' content='0; url=\"+schlabourl+\"'></head></body></html>\");\n";
		print "  picwin.document.close();\n";
		print "}\n";
		print "// -->\n";
		print "</script>\n";
	}
	unless (param('display')) {
		print "<table width=$thumbw cellpadding=0 cellspacing=0 border=0><tr><td align=\"center\">";
		print "<font face=\"$font_type\" size=1><i>";
		print $curpotdline;
		print "</i></font></td></tr></table>\n";
	} else {
		if (param('display') eq "text") {
			$curpotdline =~ s!^.*(\<br\>)!!;
			print $curpotdline;
		} else {
			$curpotdline =~ s!(\<br\>).*$!!;
			print $curpotdline;
		}
	}

} else {	# display N/A-pic
	unless (param('display')) {
		print "<table width=$thumbw cellpadding=0 cellspacing=0 border=0><tr><td align=\"center\">";
		print "<a href=\"$server_url$p_script_url\"><img src=\"".$p_thumbno."\" ";
		if ($p_thumbw) { print "width=$p_thumbw " }
		if ($p_thumbh) { print "height=$p_thumbh " }
		print "alt=\"No picture is available for today.\" border=0></a>\n";
		print "</td></tr></table>\n";
	} else {
		unless (param('display') eq "text") {
			print "<a href=\"$server_url$p_script_url\"><img src=\"".$p_thumbno."\" ";
			if ($p_thumbw) { print "width=$p_thumbw " }
			if ($p_thumbh) { print "height=$p_thumbh " }
			print "alt=\"No picture is available for today.\" border=0></a>\n";
		}
	}
					
}



sub get_date {
	($Second,$Minute,$Hour,$month_day,$Month,$Year,$Week_Day,$IsDST) =
	(localtime);
	#Y2k fix
	$y = $Year + 1900;
	$m = $Month + 1;
}