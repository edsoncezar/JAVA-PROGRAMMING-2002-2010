Multicounter script readme file:
--------------------------------

This package contains the following files
- multicounter.cgi (the script)
- Readme (this file)
- multicounter.txt (example)

Installation:

Copy the multicounter.cgi to your cgi-bin directory
correct the variable's to your own value's

There are two options in the script:
Option 1:
To turn on logging correct variable
$log = 1, create your log file and make
it writeable for the script.
Correct the path to your log file.
If you don't want to log $log = 0.

Option 2:
If you want to print out the value of the
counter on your page, correct variable
$scrprint = 1, if you don't want the output
of the counter on your page, $scrprint = 0

Copy and modify the multicounter.txt file and
correct the path in the multicounter script.
Make this file readable and writeable to the
script.



To activate the counter, put the follwing ssi
(server side includes) into your page:
<!--#set var="id" value="yourpagename"-->
<!--#exec cgi="/path/to/multicounter/script"-->
an ssi html file must end with extention .shtml


Following the example of the multicounter.txt file:
your page name = 0 = 192.168.1.2
---------------------------------------------------
your page name (must be the same as the value in the ssi
command above)
0 = the counter value
192.168.1.2 is the starting ip address

Happy logging

If you have any questions or suggestions mail webmaster@sylconia.com

more scripts are available at:
http://www.sylconia.com/scripts/index.shtml





