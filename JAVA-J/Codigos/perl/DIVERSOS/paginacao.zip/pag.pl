#!/usr/local/bin/perl
############################################################
#Para usu�rios novatos irei explicar parte por parte       #
#desse script, coisa que muitas pessoas deviam fazer para  #
#n�o s� usurfruir do script, mas tamb�m aprender a fazer   #
#o seu pr�prio sem copiar!                                 #
#Obs: Lembrando que o script pode ser usado livremente para#
#a c�pia total ou parcial                                  #
#   C�DIGO POR: Thadeu Soares                              #
#   URL: http://www.cgiclube.net                           #            
#   EMAIL: webmasters@webmastercorp.net                    #
############################################################
#                                                          #
#Bem aqui come�a o script.                                 #
#Coloca todo o conteudo da query(tudo depois do pag.pl? na #
# url) na variavel $content                                #
#Ex: http://www.tal.com/cgi-bin/pag.pl?1 < Isso � a Query  #
############################################################
$content = $ENV{'QUERY_STRING'};


############################################################
#                                                          #
#Imprime o content-type (obrigat�rio) para todos os scripts#
############################################################
print "Content-type: text/html\n\n";


############################################################
#Aqui no &header se situa a primeira parte que ser�        #
#mostrado no script.                                       #
#Obs: pequena explica��o sobre a vari�vel "&", essa        #
#variavel � uma subcategoria, por isso sempre se define    #
#assim sub nome_da_var {comandos} depois se quizer que seja#
#mostrado s� colocar na parte do script que deseja assim   #
# &nome_da_var;                                            #
############################################################
&header;

############################################################
#se a variavel $content existir...                         #
############################################################
if ($content) {

############################################################
#                                                          #
#e se a sub com o nome da variavel $content existir...     #
############################################################
	if (defined(&$content)) {


############################################################
#                                                          #
#executa a sub com o nome da variavel $content             #
############################################################
		&$content;

############################################################
#                                                          #
#se nao...                                                 #
############################################################
	} else {

############################################################
#                                                          #
#executa sub para pagina nao encontrada, q seria o mesmo   #
#que 'sub nao existe'                                      #
############################################################
		&nao_encontrei;
#fecha o else
	}

############################################################
#                                                          #
#e se a variavel $content nao existir..  .                 #
############################################################
} else {
	&nao_permitido_acesso;
#fecha o else
}
############################################################
#                                                          #
#Imprime a parte de baixo do script                        #
############################################################
&footer;

##########################################################################
# Aqui voc� coloca as sub rotinas que voc� quer chamar.                  #
# a sintese � simples:                                                   #
# sub NOME_DA_SUB_ROTINA {                                               #
# print <<EOF;                                                           #
# oie! aqui fica os comandos html que voc� quer escrever! legal n�o? :)  #
# EOF                                                                    #
# }                                                                      #
# Sempre use a sintese acima e nunca ter� problemas. o script pode ter   #
# quantas sub rotinas voc� quiser.                                       #
# voc� pode fazer uma para imprimir o index, outra para imprimir a se��o #
# contato, outra para imprimir a se��o tutoriais, etc... bah, voc�       #
# entendeu n�? :)                                                        #
# Obs: Mas nunca chame o script somente pelo nome, sempre tem que vir o  #
# nome da subcategoria Ex: pag.pl?index                                  #
# Obs2: Sempre que colocar um email dentro das subcategorias coloque     #
#  \ antes da @                                                          #
#Ex: home@home.com  <- Errado       Certo -> home\@home.com              #
##########################################################################
sub index {
print <<EOF;
OI
EOF
}

##########################################################################
#Aqui � a parte de CIMA                                                  #
#                                                                        #
##########################################################################
sub header {
print <<EOF;
<html><body>
EOF
}

##########################################################################
#Aqui � a parte de baixo                                                 #
#                                                                        #
##########################################################################
sub footer {
print <<EOF;
</html></body>
EOF
}
############################################################
#                                                          #
# Aqui voc� define a p�gina de 404(P�gina n�o encontrada)  #
############################################################
sub nao_encontrei {
print <<EOF;
404 - not found!
EOF
}


############################################################
#                                                          #
# Aqui voc� define a p�gina de 403(Acesso Negado)          #
############################################################
sub nao_permitido_acesso {
print <<EOF;
403 - forbidden!
EOF
}