#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
require Tk;
use Tk;
print "Content-type:text/html\n\n";
  
$version="1.0";
#create the window
my $main=MainWindow->new();
#my $main2=SecondWindow->new();

$main->minsize( qw(880 595));
$main->maxsize( qw(880 595));
$main->title("Echelon Line Counter Version $version");
$main->configure(-background => '#D6D6Ce');
$main->geometry('+0+0');
$main -> Photo('imggif', 
               -file => "linecounter.gif");
   my $l = $main->Label('-image' => 'imggif')->pack;

#menubar
my $menu_bar=$main->Frame(-relief => 'groove', 
	-borderwidth => 3,
	-background=> '#444455',
	)->pack('-side'=>'top',-fill=>'x');
my $file_mb = $menu_bar->Menubutton(-text=>'File',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-activeforeground=>'white',
	-foreground=>'black',
	)->pack(-side=>'left');
$file_mb->command(-label =>'Save Results',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-command => \&save);
$file_mb->command(-label =>'Save Results As',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-command => \&saveas);
$file_mb->command(-label =>'Open',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-command => \&open);
$file_mb->command(-label =>'Exit',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-command => sub {$main -> destroy});
my $edit_mb=$menu_bar->Menubutton(-text=> 'Edit',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-foreground =>'black',
	-activeforeground=>'white',
	)->pack(-side=>'left');
$edit_mb->command(-label=>'Colors',
	-activebackground=>'#666666',
	-background =>'#D6D6CE',
	-command=> \&editcolors);
my $help_mb=$menu_bar->Menubutton(-text=> 'Help',
	-background =>'#D6D6CE',
	-activebackground => '#666666',
	-foreground =>'black',
	-activeforeground=>'white',
	)->pack(-side=>'left');
$help_mb->command(-label=>'About',
	-activebackground=>'#666666',
	-background =>'#D6D6CE',
	-command=> \&about);
$help_mb->command(-label=>'Help',
	-activebackground=>'#666666',
	-background =>'#D6D6CE',
	-command=> \&help);
#endmenubar

#Start the body frames

my $top= $main->Frame(-background=>'#D6D6CE',
 )->pack(-side=>'top',-fill=>'x');
my $left1 = $top->Frame(-background=>'#D6D6CE',
 )->pack(-side=>'right',-pady=>9,-padx=>8);

#add some text


my $t1=$left1->Label(-text=>'Total Lines',
	-background=>'#D6D6CE')->pack();
my $t1=$left1->Label(-text=>'Total Filesize',
	-background=>'#D6D6CE')->pack();

#add some 'fields'
my $left2=$top->Frame(-background=>'#D6D6CE',
)->pack(-side=>'right',-pady=>2,-padx=>15);


$pre1=$left2->Label(
	-background=>'#A9A99D',
	-width=>25,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
$pre2=$left2->Label(
	-background=>'#A9A99D',
	-width=>25,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
my $left3=$top->Frame(
	-background=>'#D6D6CE',
	)->pack(-side=>'left');
my $des1 =$left3->Label(-text=>'Starting Directory',
	-background=>'#D6D6CE',-pady=>3)->pack();

my $des2= $left3->Label(-text=>'Extentions, separated by comma',
	-background=>'#D6D6CE',-pady=>3)->pack();
my $left4=$top->Frame(
	-background=>'#D6D6CE',
	)->pack(-side=>'left');
my $starting = $left4->Entry(
	-width=>15,
	-background=>'white')->pack(pady=>2);
$starting->insert('end',".");
my $exts= $left4->Entry(
	-width=>15,
	-background=>'white')->pack(pady=>2);
$exts->insert('end',"pl,php,cgi");
#the status/spaceholding bar
my $lin = $main->Frame(
	-borderwidth=>3,
	-background=>'#444455')->pack(-side=>'top');
my $stat = $lin->Label(width=>150, height=>0,
	-foreground=>'white',
	-background=>'#444455')->pack();
my $options=$main->Frame(-background=>'#D6D6CE')->pack(-side=>'top',-fill=>'x');
my $options2=$main->Frame(-background=>'#D6D6CE')->pack(-side=>'top',-fill=>'x');
#my $options3=$main->Frame(-background=>'#D6D6CE')->pack(-side=>'top',-fill=>'x');
my $right1= $options->Frame(
	-background=>'#D6D6CE')-> pack(-side=>'left',padx=>17);
my $right45=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align2=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align3=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',padx=>1);
my $align3b=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align4=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align4b=$options->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align5=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align6=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align6b=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',padx=>6);
my $align7=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');
my $align7b=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left');

my $align8=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',pady=>2,padx=>2);
my $align8b=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',pady=>2,padx=>2);

my $align9=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',pady=>2,padx=>2);
my $align9b=$options2->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',pady=>2,padx=>2);

#my $des3= $right1->Label(-text=>'Display The Following',
#	-background=>'#D6D6CE',-pady=>5)->pack();
#my $des5= $right1->Label(-text=>'',
#	-background=>'#D6D6CE',-pady=>4)->pack();
my $des4= $right1->Label(-text=>'File Size',
	-background=>'#D6D6CE',-pady=>5)->pack();

my $aent0 = $right45->Checkbutton(-variable=> \$filesize,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();

my $des5= $align->Label(-text=>'Last Access Time',
	-background=>'#D6D6CE')->pack();
my $ent1 = $align2->Checkbutton(-variable=> \$lat,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();
my $des5= $align3->Label(-text=>'Last Modify Time                           ',
	-background=>'#D6D6CE',-pady=>5)->pack();
my $ent2 = $align3b->Checkbutton(-variable=> \$lmt,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();
my $des5= $align4->Label(-text=>"Number Of Alocated Blocks(Unix Only)",
	-background=>'#D6D6CE',-pady=>5)->pack(
#-fill=>'x'
);
my $allocatied = $align4b->Checkbutton(-variable=>\$allocated,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();


#my $des5= $align5->Label(-text=>'(Unix Only)',
#	-background=>'#D6D6CE',-pady=>5)->pack();
my $des5= $align6->Label(-text=>'Inode Number',
	-background=>'#D6D6CE',-pady=>5)->pack();
my $ent4 = $align6b->Checkbutton(-variable=> \$inode,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();
my $des7= $align7->Label(-text=>'File Permissions ',
	-background=>'#D6D6CE',-pady=>5)->pack();
my $ent6 = $align7b->Checkbutton(-variable=> \$fperm,
	-background=>'#D6D6CE',
	-activebackground=>'#D6D6CE',
	)->pack();
#my $des6= $align8->Label(-text=>'Popup(check) or inside(nocheck)',
#	-background=>'#D6D6CE',-pady=>5)->pack();
#my $ent5 = $align8b->Checkbutton(-variable=> \$pop,
#	-background=>'#D6D6CE',
#	-activebackground=>'#D6D6CE',
#	)->pack();
$pop=1;
my $checkall= $align9->Button(
                  -text => "Check All",
			-background=>'#A9A99D',
			-activebackground=>'#444455',
                  -command => [sub{
$filesize=1;
$lat=1;
$lmt=1;
$allocated=1;
$inode=1;
$fperm=1;
$pop=1;},$box], 
                                  )->pack;
my $uncheckall= $align9b->Button(
                  -text => "UnCheck All",
			-background=>'#A9A99D',
			-activebackground=>'#444455',
                  -command => [sub{
$filesize=0;
$lat=0;
$lmt=0;
$allocated=0;
$inode=0;
$fperm=0;
$pop=0;},$box], 
                                  )->pack;



my $options4=$main->Frame(-background=>'#444455',-borderwidth=>3)->pack(-side=>'top',-fill=>'x');
my $stat2 = $options4->Label(width=>150, height=>0,
	-foreground=>'white',
	-background=>'#444455')->pack();


my $mid=$main->Frame(
	-background=>'#D6D6CE',
	)->pack(-side=>'top',-fill=>'x',
	#-expand=>'y'
);
my $right3=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');

my $end = $right3->Button(
	-text=>'Quit',
	-background=>'#A9A99D',
	-activebackground=>'#444455',
	-command=>sub {exit(0)})->pack(-side=>'bottom');
my $right4=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');
my $totalfiles= $right4->Label(-text=>'',
	-background=>'#D6D6CE')->pack();
my $Maintext=$mid->Frame(-background=>'#D6D6CE')->pack(-side=>'left',
	-padx=>10,-fill=>'y');
my $right5=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');

$box = $right4->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 50, 
        -height => 20,
 -exportselection => 0
	);

my $go = $right3->Button(
	-text=>'Count',
	-background=>'#A9A99D',
	-activebackground=>'#444455',
	-command=> \&startcount)->pack(-side=>'top');
my $getinfo = $right3->Button(-text=>'Get Info',
	-background=>'#A9A99D',
	-activebackground=>'#444455',
	 -command =>\&getnshowinfo
		)->pack(-side=>'top');

my $del_button = $right3->Button(
                  -text => "Delete List",
			-background=>'#A9A99D',
			-activebackground=>'#444455',
                  -command => [sub{shift->SetList(());
$total="";
$toalsize="";
@files="";
$box1->delete(0,"end"); 
$box2->delete(0,"end"); 
$box3->delete(0,"end"); 
$box4->delete(0,"end"); 
$box5->delete(0,"end"); 
$box6->delete(0,"end"); 
$dir="";
@dirs="";
$asd="";},$box], 
                                  )->pack;
my $totalfiles55432= $right3->Label(-text=>'',
	-background=>'#D6D6CE')->pack(-side=>'top');

 my $scroll3 = $right4->Scrollbar(-command => ['xview', $box],-orient=>'horizontal');
      $box->configure(-xscrollcommand => ['set', $scroll3]);
     $scroll3->pack(-side => 'bottom',-fill => 'both',-expand => 'yes');


 my $scroll = $right4->Scrollbar(-command => ['yview', $box]);
       $box->configure(-yscrollcommand => ['set', $scroll]);
       $box->pack(-side => 'left', -fill => 'both', -expand => 'yes');
       $scroll->pack(-side => 'right', -fill => 'y');




my $right6=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');

my $right7=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');

my $right8=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');
my $right9=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');
my $right10=$mid->Frame(
	-background=>'#D6D6CE')->pack(-side=>'left',-fill=>'y');
my $totalfiles2= $right5->Label(-text=>'File Size',
	-background=>'#D6D6CE')->pack();
my $totalfiles3= $right6->Label(-text=>'Access Time',
	-background=>'#D6D6CE')->pack();
my $totalfiles4= $right7->Label(-text=>'Modify Time',
	-background=>'#D6D6CE')->pack();
my $totalfiles5= $right8->Label(-text=>'Blocks',
	-background=>'#D6D6CE')->pack();
my $totalfiles5= $right9->Label(-text=>'Inode Num',
	-background=>'#D6D6CE')->pack();
my $totalfiles5= $right10->Label(-text=>'File Permissions',
	-background=>'#D6D6CE')->pack();
 $box1 = $right5->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 10, 
        -height => 20,
 -exportselection => 1
	)->pack(-side => 'right', -fill => 'y');

 $box2 = $right6->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 13, 
        -height => 20,
	)->pack(-side => 'right', -fill => 'y');
 $box3 = $right7->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 13, 
        -height => 20,
	)->pack(-side => 'right', -fill => 'y');
 $box4 = $right8->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 10, 
        -height => 20,
	)->pack(-side => 'right', -fill => 'y');
 $box5 = $right9->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 10, 
        -height => 20,
	)->pack(-side => 'right', -fill => 'y');
 $box6 = $right10->Listbox(
	-background=>'#D6D6CE',
	-relief => 'sunken', 
        -width => 10, 
        -height => 20,
	)->pack(-side => 'right', -fill => 'y');
 #my $scroll2 = $right5->Scrollbar(
#	-command => ['yview', $box2]);
 #      $box2->configure(-yscrollcommand => ['set', $scroll2]);
  #     $box2->pack(-side => 'left', -fill => 'both', -expand => 'yes');
   #    
sub getallsettings{
$extentions=$exts->get;
$startingplace=$starting->get;
$settings=qq~$extentions|$startingplace|$filesize|$lat|$lmt|$allocated|$inode|$fperm~;
}
sub save{
getallsettings();
$dir="./Saves/";
opendir("DIR", $dir);
@items="";
@items= readdir(DIR);
$newnum=0;
foreach(@items){
print "\n";
print $_;
}
@saveditems = grep(/\.asave\.ech$/, @items);

print @saveditems;
print "\n";
foreach(@saveditems){
$_=~ s/(.*)\.asave\.ech/$1/;
print $_;
print $newnum;
if($_>$newnum){
$newnum=$_;
}
}
$newnum++;

$savefile="./Saves/".$newnum.".asave.ech";
open("Save",'>',"$savefile");
print Save $settings;
close("Save");
my $saved=$main->DialogBox(-title=>"Save Complete",
 -buttons=>["OK"],);
 $saved->add("Label", -text=>"Save Completed with Filename $savefile")->pack;
 $saved->Show;
}
sub saveas{
getallsettings();
}
sub open{
}
sub editcolors{
}
sub help{
$top3 = $main->Toplevel;
$top3->configure(-background => '#D6D6Ce');
$top3->grab;
$top3->focus;
$top3->Popup();
$top3->title("Help with Line Counter");
$top3->minsize( qw(550 350));
my $peewee= $top3->Frame(-background=>'#D6D6CE'
 )->pack(-side=>'left',-fill=>'both'
);
$helpstuff=$peewee->Label(-text=>"Whats this thing do?\n1) This program has the ability to do alot of things.  It will find all files with the extention you specify.\n2) With these files it can get their,Filesize,Last Access and Modification Dates, Inode Numbers and Allocated Blocks.
3) It can spit this information in two ways, either in the colums on screen with abreviations, or In a nice neat popup.
4) Once inside the popup,  Delete/rename/copy the selected file. \n Usage Instructions:\n1) In the Upper left, specify the starting directory.  a \".\" Is the current directory.  \"./\" Is also the current directory\n  \"../\" is back one directory.  \"../../\" Is back 2 directories.  \"Echelon/\" is up one directory to Echelon. 
2) Specify the file Extentions you wish to look for seperated by a comma.  The default is pl,php,cgi.
The script will go fetch information for all files it finds with the extentions, \"Pl\",\"Php\",\"Cgi\".
3) Put a \"*\" In the Extentions box to list all files
4) Select the information you want, and whether you want popup a popup.
5) Hit Count
6) If you want to view a popup, then select the file, and hit \"Get Info\".
7) Hitting Delete List just deletes the list, it doesnt remove or delete the files in any way.
8) The popup box has the ability to Delete/rename/copy files.",
	-background=>'#D6D6CE')->pack(-fill=>'x');
 my $enderhelp = $peewee->Button(
	-text=>'Close',
	-background=>'#A9A99D',
	-activebackground=>'#444455',
	-command=>sub {$top3->destroy})->pack(-side=>'bottom');
}
sub about{
my $popup=$main->DialogBox(-title=>"About Line Counter",
 -buttons=>["OK"],);
 $popup->add("Label", -text=>"Echelon Line Counter Created Souly By WebRecka\nVersion 1.0\nThe Ultimate In Line Counting\nWritten in the Perl Language\nThanks to Tk::Gui, Perl2exe and Notepad")->pack;
 $popup->Show;
}
sub getnshowinfo{
if($pop){
my $top1 = $main->Toplevel;
$top1->grab;
$top1->focus;
$top1->Popup();
$currentfile=$box->get('active');
$currentfile2=$currentfile;
$currentfile2=~ s/(.*) Lines (.*)/\2/;
#$linecount=$currentfile;
$linecount = $1;
$top1->title("Extra File Info For $currentfile2");
$top1->minsize( qw(550 150));
$top1->configure(-background => '#D6D6CE');
my $major= $top1->Frame(-background=>'#D6D6CE'
 )->pack(-side=>'left',-fill=>'both'
);
my $topframe=$major->Frame()->pack(-side=>'top',-fill=>'both');
my $tops= $major->Frame(-background=>'#D6D6CE'
 )->pack(-side=>'left',-fill=>'both'
);

($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($currentfile2); 
#my $topframe=$top1->Frame()->pack(-side=>'top',-fill=>'both');
my $middle=$tops->Frame(-background=>'#D6D6CE',
)->pack(-side=>'left',-fill=>'y');
$filenameprint=$topframe->Label(-text=>"Info For $currentfile2 Which has $linecount Lines",
	-background=>'#D6D6CE')->pack(-fill=>'x');
if($filesize){
$filesizee=$middle->Label(-text=>' Filesize',
	-background=>'#D6D6CE')->pack();
$filesizefield=$middle->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
$kils=$size/1000;
$megs=$kils/1000;
$filesizefield->configure(-text=>"$kils Kb($megs Megs)");

}

if($lat){

$lats=$middle->Label(-text=>'Last Access Time',
	-background=>'#D6D6CE')->pack();
$latfield=$middle->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($atime);
get_time();
$latfield->configure(-text=>"$day, $mday of $month, $year at $hour:$min:$sec  ");
}

if($lmt){

$lmts=$middle->Label(-text=>'Last Modify Time',
	-background=>'#D6D6CE')->pack();
$lmtfield=$middle->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($mtime);
get_time();
$lmtfield->configure(-text=>"$day, $mday of $month, $year at $hour:$min:$sec  ");

}
my $toss= $tops->Frame(-background=>'#D6D6CE',
 )->pack(-side=>'right',-fill=>'y');
#$alloc=$toss->Label(-text=>'',
#	-background=>'#D6D6CE')->pack();
if($allocated){
$alloc=$toss->Label(-text=>'Number Of Allocated Blocks(unix only)',
	-background=>'#D6D6CE')->pack();
$allocfield=$toss->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
if(!$blocks){
$blocks=" Unknown Number of";
}
$allocfield->configure(-text=>"$blocks Blocks ");


}

if($inode){
$inod=$toss->Label(-text=>'Inode Number',
	-background=>'#D6D6CE')->pack();
$inodfield=$toss->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
$inodfield->configure(-text=>"$ino");


}

if($fperm){

$filepermis=$toss->Label(-text=>'File Permissions',
	-background=>'#D6D6CE')->pack();
$filepermisfield=$toss->Label(
	-background=>'#A9A99D',
	-width=>40,
	-borderwidth=>2,
	-relief=>'sunken')->pack();
$permissions=sprintf "%04o", $mode & 07777;
$filepermisfield->configure(-text=>"$permissions");
#$filepermisfield->configure(-text=>"$mode&07777");


}
 my $ender = $tops->Button(
	-text=>'Quit',
	-background=>'#A9A99D',
	-activebackground=>'#444455',
	-command=>sub {$top1->destroy})->pack(-side=>'bottom');
}else{
}
}
$stat->configure(-text=>" ");
$stat2 ->configure(-text=>" ");

sub startcount{
#$box->erase;
#box.delete(0,END);
#shift->SetList(()),$box;
$total="0";
$toalsize="";
@files="";
$dir="";
$directories="";
@dirs="";
$asd="0";
$stat ->configure(-text=>"Working...");
$box->delete(0,"end"); 
$box1->delete(0,"end"); 
$box2->delete(0,"end"); 
$box3->delete(0,"end"); 
$box4->delete(0,"end"); 
$box5->delete(0,"end"); 
$box6->delete(0,"end"); 

$FORM{len}="long";
$pre2->configure(-text=>"$version");
$pre1->configure(-text=>"$version");
$extentions=$exts->get;
$startingplace=$starting->get;

#$stat->configure(-text=>"$extentions,$startingplace");

$dirs[0]=$startingplace;
$num=1;
getDirList($startingplace);
$ext=$extentions;
if($ext eq "*"){
$stat->configure(-text=>"There are $asd files with any extention");
}else{ 
if($asd==1){
$stat->configure(-text=>"There is $asd file with the extention(s) $ext");
}else{
$stat->configure(-text=>"There are $asd files with the extention(s) $ext");
}
}
for($x=0;$x<$asd;$x++){
$lines=0;
open("FILE1",$files[$x]);
&count;
close("FILE1");
$intobox="$lines Lines $files[$x]   ";
$box->insert("end","$intobox");
($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($files[$x]);  
$toalsize+=$size;
if($filesize){
$kils=$size/1000;
$megs=$kils/1000;
$box1->insert("end","$kils Kb");
}
if($lat){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($atime);
get_time();
$mon++;
$box2->insert("end","$mday of $mon, $year");
}

if($lmt){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($mtime);
get_time();
$mon++;
$box3->insert("end","$mday of $mon, $year");
}
if($allocated){
if(!$blocks){
$blocks=" Unknown";
}
$box4->insert("end","$blocks");
}

if($inode){
$box5->insert("end","$ino");
}
if($fperm){
$permissions=sprintf "%04o", $mode & 07777;
$box6->insert("end","$permissions");
}
}

$pre1 ->configure(-text=>"$total");
$tttt= $toalsize/1000;
$megs= $tttt/1000;
$pre2->configure(-text=>"$tttt Kb($megs Megs)");
#print "<td colspan=3>Total Size $tttt Kb($megs Megs)</td>";

#print "</tr>";

}
sub getDirList { 
$Death=0;
($dir) = @_;
$dir.="/";
opendir("DIR", $dir);
@items="";
@items= readdir(DIR);
closedir(DIR);
foreach(@items){
$thisdir=$_;
if(-d "$dir$thisdir" && $thisdir !~ /\.$/){
$dirs[$num]="$dir$thisdir";
$directories++;
$num++;
$todo{$dir}.="getDirList(\"$dir$thisdir\");\n";
}elsif(-f "$dir$thisdir"){
if($ext eq "*"){
$files[$asd]="$dir$thisdir";
$asd++;
}else{
@exts=split(/,/,$extentions);
$ext="";
foreach $extention (@exts){
if($thisdir=~ m/$extention$/){
$files[$asd]="$dir$thisdir";
$asd++;
}
}
}
}
}
eval $todo{$dir};
}
sub count{
  while ( ( $line = read_file("FILE1") ) ) {
$lines++;
$total++;
}
}
sub read_file {
    local ($filevar) = @_;
    <$filevar>;
}
#my time reformatter...
sub get_time{
if($wday == 1){
$day="Monday";
}
if($wday eq 2){
$day="Tuesday";
}
if($wday == 3){
$day="Wednesday";
}
if($wday == 4){
$day="Thursday";
}
if($wday == 5){
$day="Friday";
}

if($wday ==6){
$day="Saturday";
}
if($wday == 0 || $wday==7){
$day="Sunday";
}
if($mon == 0 || $mon==13 || $mon==1){
$month="January";
}
if($mon == 2){
$month="February";
}
if($mon == 3){
$month="March";
}
if($mon == 4){
$month="April";
}
if($mon == 5){
$month="May";
}
if($mon == 6){
$month="June";
}
if($mon == 7){
$month="July";
}
if($mon == 8){
$month="August";
}
if($mon == 9){
$month="September";
}
if($mon == 10){
$month="October";
}
if($mon == 11){
$month="November";
}
if($mon == 12){
$month="December";
}
$year += 1900;  
}

#this is the short mode...were we display info about 1 file
MainLoop();