CREATE TABLE login ( 
id int(5) NOT NULL auto_increment,
usuario text NOT NULL,
senha text NOT NULL,
email text NOT NULL,
nome text NOT NULL,
titulo text NOT NULL,
url text NOT NULL,
time int(15) NOT NULL, 
ip varchar(15) NOT NULL, 
PRIMARY KEY  (id),
UNIQUE KEY id (id)
) TYPE=MyISAM;