# Database setup file for Feline Linx v0.5a
# Please read the notice located in the readme.txt
# file included along with the original distribution
# of this program.
# ---------------------------------------------------
#
# Table structure for table 'category'
#
DROP TABLE IF EXISTS category;
CREATE TABLE category (
  id int(5) unsigned DEFAULT '' NOT NULL auto_increment,
  name varchar(50)  DEFAULT '' NOT NULL ,
  parent int(5) unsigned   ,
  PRIMARY KEY (id),
  KEY name (name)
);
INSERT INTO category SET id=1, name='Misc.', parent=null;
#
# Table structure for table 'link'
#
DROP TABLE IF EXISTS link;
CREATE TABLE link (
  id int(5) unsigned DEFAULT '' NOT NULL auto_increment,
  title varchar(50)  DEFAULT '' NOT NULL ,
  description text  DEFAULT '' NOT NULL ,
  url varchar(255)    ,
  category_id int(5) unsigned DEFAULT '0' NOT NULL ,
  created date    ,
  email varchar(100)    ,
  user varchar(15)    ,
  hits int(5)    ,
  PRIMARY KEY (id),
  KEY category_id (category_id)
);
INSERT INTO link SET id=1, title='WeekendClimber.Com', description='WeekendClimber.Com -- Local information for hiking, backpacking, climbing, and mountaineering in Washington State. Learn everything from the basics to those long elusive experienced tips that will help make your next trip in to the outdoors the best yet.', url='http://www.weekendclimber.com', category_id='1', created='20020704', user='Scott Anderson', hits=null;