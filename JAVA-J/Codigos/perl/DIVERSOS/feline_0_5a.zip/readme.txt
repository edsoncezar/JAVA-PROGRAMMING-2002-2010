7/4/2002 -- Better setup instructions are coming soon.
##########################################################################
# Feline Linx Version: 0.5a
##########################################################################
#
# Copyright 2002 WeekendClimber.Com�
# Author: Scott Anderson
# All Rights Reserved.  
#
# The original developer of this software module and his/her company, the subsequent
# editors and their companies, have no liability for use of this
# software module or modifications thereof in an implementation.
#
# Permission to use, copy, and modify this software and its documentation on
# the server of the customer is hereby granted, provided that the above copyright
# notice and preceding paragraph, this paragraph and the following two paragraphs
# appear in all copies.
#
# This software program and documentation are copyrighted by WeekendClimber.Com.
# The software program and documentation are supplied "as is", without any 
# accompanying services. WeekendClimber.Com does not warrant that the
# operation of the program will be uninterrupted or error-free.
#
# IN NO EVENT SHALL WEEKENDCLIMBER.COM BE LIABLE TO ANY PARTY FOR
# DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
# LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION.
#
###########################################################################
Documentation about installation of Feline Links Version 0.5a can be found at:
http://www.weekendclimber.com/tutorials/
