function openXCodes(url, width, height) {
        var Win = window.open(url,"openWindow",'width=' + width + ',height=' + height + ',resizable=0,scrollbars=yes,menubar=no,status=no' );
}

function openSmilies(url, width, height) {
        var Win = window.open(url,"openWindow",'width=' + width + ',height=' + height + ',resizable=0,scrollbars=yes,menubar=no,status=no' );
}

function AddText(NewCode) {
document.GuestbookPost.comment.value+=NewCode
}

function mail() {
	txt2=prompt("Title to be shown for e-mail:\n(Leave blank if you want the email address to be shown for the link)","");
	if (txt2!=null) {
		txt=prompt("Enter the e-mail address you wish to use:","name@domain.com");
		if (txt!=null) {
			if (txt2=="") {
				AddTxt="[email]"+txt+"[/email]";
			} else {
				AddTxt="[email="+txt+"]"+txt2+"[/email]";
			}
			AddText(AddTxt);
		}
	}
}

function bold() {
	txt=prompt("Enter the text you wish to make bold:","Text");
	if (txt!=null) {
		AddTxt="[b]"+txt+"[/b]";
		AddText(AddTxt);
	}
}

function italicize() {
	txt=prompt("Enter the text you wish to italicize:","Text");
	if (txt!=null) {
		AddTxt="[i]"+txt+"[/i]";
		AddText(AddTxt);
	}
}

function quote() {
	txt=prompt("Enter the text you wish to quote:","Text");
	if(txt!=null) {
		AddTxt="[quote]"+txt+"[/quote]";
		AddText(AddTxt);
	}
}

function center() {
	txt=prompt("Enter the text you wish to center:","Text");
	if (txt!=null) {
		AddTxt="[center]"+txt+"[/center]";
		AddText(AddTxt);
	}
}

function hyperlink() {
	txt2=prompt("Title shown for the link:\n(Leave this blank if you want the url to be shown for the link)","");
	if (txt2!=null) {
		txt=prompt("Enter the URL you wish to link:","http://");
		if (txt!=null) {
			if (txt2=="") {
				AddTxt="[url]"+txt+"[/url]";
				AddText(AddTxt);
			} else {
				AddTxt="[url="+txt+"]"+txt2+"[/url]";
				AddText(AddTxt);
			}
		}
	}
}

function underline() {
	txt=prompt("Enter the text you wish to underline:","Text");
	if (txt!=null) {
		AddTxt="[u]"+txt+"[/u]";
		AddText(AddTxt);
	}
}