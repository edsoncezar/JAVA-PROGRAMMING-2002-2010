##############################################################################
# PROGRAM : Bannermaster CGI Module                                          #
# VERSION : 2.02                                                             #
#                                                                            #
# NOTES   :                                                                  #
##############################################################################
# All source code, images, programs, files included in this distribution     #
# Copyright (c) 1996 -> 2014                                                 #
#           John C. Cokos, The CCS Network, The Interactive Web              #
#           All Rights Reserved.                                             #
##############################################################################
#                                                                            #
#    ------ DO NOT MODIFY ANYTHING BELOW THIS POINT !!! -------              #
#                                                                            #
##############################################################################


##############################################################################
#  Show a banner for a specific group  (SSI)
##############################################################################
sub Group_Banner {

   local($group) = @_[0];

   if ($search eq "T") {
       $sent = $Saved_Terms;
       $sent =~ s/\+//g;
       $sent =~ s/\-//g;
       if ($sent =~ "\"") {
          @words = split(/\"/,$sent);
          $sent = "";
          foreach $w (@words) {
            $w =~ s/ /_/g;
            $sent .= "$w ";
          }
       }

       @searched = split(/ /,$sent);

       unlink "$data_dir/groups/.grp";
       unlink "$data_dir/groups/.last";

       $group = "default";

       for $s( 0 .. $#searched ) {

          #  $TRY .= "Trying: >>>$searched[$s]<<<<BR>\n";
          $s =~ s/ //g;

          if (-e "$data_dir/groups/$searched[$s].grp") {

            open ("GRP", "$data_dir/groups/$searched[$s].grp");
                @count = <GRP>;
            close(GRP);

            next if ($#count < 0);

            $group = $searched[$s];
            last;

          }
       }

   }

   else {

       unlink "$data_dir/groups/.grp";
       unlink "$data_dir/groups/.last";

       if (-e "$data_dir/groups/$group.grp") {

            open ("GRP", "$data_dir/groups/$group.grp");
                @count = <GRP>;
            close(GRP);

            if ($#count < 0) { $group = "default"; }

       }

       else { $group = "default"; }

   }

   open ("GRP", "$data_dir/groups/$group.grp");
       @grp1 = <GRP>;
   close(GRP);

   for $g(0 .. $#grp1) {
      $a1 = $grp1[$g];
      $a1 =~ s/\cM//g;
      $a1 =~ s/\n//g;
      $a1 =~ s/\r//g;
      if (! -e "$data_dir/accounts/$a1/DISABLED") {
         $found++;
         push @grp_accounts,$a1;
      }
   }

   if ($found < 1) {

       $group = "default";

       open ("GRP", "$data_dir/groups/$group.grp");
           @grp1 = <GRP>;
       close(GRP);

       for $g(0 .. $#grp1) {
          $a1 = $grp1[$g];
          $a1 =~ s/\cM//g;
          $a1 =~ s/\n//g;
          $a1 =~ s/\r//g;
          if (! -e "$data_dir/accounts/$a1/DISABLED") {
             $found++;
             push @grp_accounts,$a1;
          }
       }
   }

   open ("LST", "$data_dir/groups/$group.last");
        @last = <LST>;
   close(LST);



   ### Get the name of the last banner shown
   $Last_Banner_Shown = $last[0];
   $Last_Banner_Shown =~ s/\n//g;
   $Last_Banner_Shown =~ s/\cM//g;

   ### Go through the group file to find it.
   ### If we are at the end of the group, start over
   ### If not, then show the next one.
   $Num_Groups = $#grp_accounts;
   $Found = "F";

   for $x (0 .. $#grp_accounts) {
      $acct = $grp_accounts[$x];
      $acct =~ s/\n//g;
      $acct =~ s/\cM//g;

      if ($acct eq $Last_Banner_Shown) {
         if ($x >= $Num_Groups) {
            $Next_Banner_To_Show = 0;
            $account = $grp_accounts[$Next_Banner_To_Show];
            $account =~ s/\n//g;
            $account =~ s/\cM//g;
            $Found = "T";
         }
         else { 
            $Next_Banner_To_Show = $x + 1;
            $account = $grp_accounts[$Next_Banner_To_Show];
            $account =~ s/\n//g;
            $account =~ s/\cM//g;
            $Found = "T";
         }
         if ($Found eq "T") { last; }
      }
   }
  
   ## If we fail, start over ##
   if ($Found eq "F") { $account = $grp_accounts[0]; }

   &lock("$group.last");

   open ("LAST",">$data_dir/groups/$group.last");
      print LAST "$grp_accounts[$Next_Banner_To_Show]\n";
   close(LAST); 

   &unlock("$group.last");


   ### Update the Account and Get the banner file.
   &bmUpdate_Account($account,"grp");

   if ($banner_type eq "IMAGE") { 
      $CODE =  <<DONE;
<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0"><TR><TD><CENTER>
<A HREF="$click_url?account=$ACCOUNT" TARGET="$target"><IMG SRC="$image" BORDER="0" HEIGHT="$banner_height" WIDTH="$banner_width" ALT="$alt_text"></A></TD></TR><TR BGCOLOR="black"><TD><CENTER><FONT FACE="arial" COLOR="white" SIZE="0">$under_text</FONT></TD></TR></TABLE>
DONE
   }

   elsif($banner_type eq "TEXT") {
      $CLICK = "$click_url?account=$ACCOUNT";
      $banner_text =~ s/CLICK/$CLICK/g;
      $CODE =  <<DONE;
<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="$banner_width"><TR><TD HEIGHT="$banner_height">$banner_text</TD></TR></TABLE>
DONE
   }


   #  $CODE .= "<BR>Bannermaster matching ($Saved_Terms)...<BR>$TRY<BR>Used: $group<BR>\n";

   return($CODE);
}


sub bmUpdate_Account {

   $ACCOUNT = @_[0];
   $SOURCE = @_[1];

   if ( $ENV{'HTTP_REFERER'} ) { $REF=$ENV{'HTTP_REFERER'}; }
   else { $REF=$SELF; }

   open ("ACCT", "$data_dir/accounts/$ACCOUNT/$ACCOUNT.dat");
       @lines = <ACCT>;
   close(ACCT);

   ## Get time for the log file...
   ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

   if(length($mday) == 1) { $mday = "0$mday"; }
   $month = $mon+1;
   if(length($month) == 1) { $month = "0$month"; }
   if ($year < 100) { $year = "19$year"; }
   else { $year = ($year - 100) + 2000; }

   $name = "$month" . "_" . "$mday" . "_" . "$year.log";

   $TIME=time;
   $DATE_STRING = "$month" . "_" . "$mday" . "_" . "$year";

   $filename = "$data_dir/accounts/$ACCOUNT/logs/$name";

   &lock("$filename");
   open("LOG",">>$filename");
      print LOG "$TIME|$REF|$SOURCE\n";
   close(LOG);
   &unlock("$filename");

   $tot_file = "$data_dir/accounts/$ACCOUNT/$ACCOUNT.total";
   open("TOT1","$tot_file");
      @entries=<TOT1>;
   close(TOT1);
   $entries[0] =~ s/\n//g;
   @totals = split(/\|/,$entries[0]);
   $impressions = $totals[0];
   $clicks = $totals[1];
   $NewImpressions = $impressions + 1;

   &lock("$tot_file");
   open("TOT",">$tot_file");
      print TOT "$NewImpressions|$clicks";
   close(TOT);
   &unlock("$tot_file");
 
   $lines[0] =~ s/\n//g;

   ($acct_name,$acct_login,$acct_password,$target,$redirect_url,$alt_text,$under_text,$banner_type,$banner,$banner_width,$banner_height,$banner_text,$expiration_type,$num_clicks,$num_impressions,$start_date,$end_date) = split(/\|/,$lines[0]);

   
   $RAND = time;
   $R1 = "RAND";

   $banner_text =~ s/$R1/$RAND/g;

   if ($banner =~ "http") {
        $LOCAL = "F";
        $image = "$banner";
        $image =~ s/$R1/$RAND/g;
 
   }
   else { 
        $LOCAL = "T";
        $image = "$banner_dir/$banner";
        $real_image = "$full_banner_dir/$banner"; 
        $real_image =~ s/$R1/$RAND/g;
   }

   ### Check for Disabling....
   if ($expiration_type eq "impressions" && $NewImpressions >= $num_impressions) { &bmDisable_Account; }
   elsif ($expiration_type eq "exchange") { &bmDisable_Account; }
   elsif ($expiration_type eq "date") {

       ($e_month, $e_day, $e_year) = split(/\//,$end_date);
       ($d_month, $d_day, $d_year) = split(/\_/,$DATE_STRING);

       $comp .= "Compared $e_month/$e_day/$e_year (expires) to $d_month/$d_day/$d_year (today)...<BR>\n";

       ## Date Comparisons ....
 
       ## This year less than expiration year
       if ($d_year > $e_year) { $comp .= "Disabled due to year."; &bmDisable_Account; }

       ## Same year, this month later than expiration month
       elsif ($d_year == $e_year && $d_month > $e_month) { $comp .= "Disabled due to month."; &bmDisable_Account; }

       ## Same year, same month, today later than expiration day
       elsif ($d_year == $e_year && $d_month == $e_month && $d_day > $e_day) { $comp .= "Disabled due to day."; &bmDisable_Account; }

   }

}


sub bmDisable_Account {

    open ("DIS", ">$data_dir/accounts/$ACCOUNT/DISABLED");
    close (DIS);

}

1;
