###########################################################################
# dclib.pl
#
# Written By David S. Choi, dc@dcscripts.com
# DCScripts, http://www.dcscripts.com
# Date Created 6-10-98
# 
# REVISION:
# 28 Dec 1998 - Modified function send_mail to handle blat mail
# 15 Nov 1998 - Modified readdata, writedata, and appenddata functions
#               to better handle filelock
#
# dclib.pl contains various subroutines that I found useful
# Uses couple of subroutines from Selena and Gunther's auth-extra-lib.pl
# file.  AuthGetFileLock and AuthReleaseFileLock
#
###########################################################################
# NOTE: This perl library is to be used with DCShop scripts
# There are couple of dcshop specific functions that won't work
# for other scripts...hopefully, I'll get around to fix it to work with all
# scripts
#
# Written By David S. Choi, dc@dcscripts.com
# 15 June 1998
#
# Copyright  �1997-1998 DCScripts All Rights Reserved
# As part of the installation process, you will be asked
# to accept the terms of this Agreement. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts and DCForum98.
# You should carefully read the following terms and conditions before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of the Software.
#
# 
# LICENSE TO REDISTRIBUTE
# Distributing the software and/or documentation with other products
# (commercial or otherwise) or by other than electronic means without
# DCScripts's prior written permission is forbidden.
# All rights to the DCForum98 software and documentation not expressly
# granted under this Agreement are reserved to DCScripts.
#
# DISCLAIMER OF WARRENTY
# THIS SOFTWARE AND ACCOMPANYING DOCUMENTATION ARE PROVIDED "AS IS" AND
# WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER
# WARRANTIES WHETHER EXPRESSED OR IMPLIED.   BECAUSE OF THE VARIOUS HARDWARE
# AND SOFTWARE ENVIRONMENTS INTO WHICH DCFORUM98 MAY BE USED, NO WARRANTY OF
# FITNESS FOR A PARTICULAR PURPOSE IS OFFERED.  THE USER MUST ASSUME THE
# ENTIRE RISK OF USING THIS PROGRAM.  ANY LIABILITY OF DCSCRIPTS WILL BE
# LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.
# IN NO CASE SHALL DCSCRIPTS BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR
# CONSEQUENTIAL DAMAGES OR LOSS, INCLUDING, WITHOUT LIMITATION, LOST PROFITS
# OR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, WHETHER SUCH DAMAGES ARE
# BASED UPON A BREACH OF EXPRESS OR IMPLIED WARRANTIES, BREACH OF CONTRACT,
# NEGLIGENCE, STRICT TORT, OR ANY OTHER LEGAL THEORY. THIS IS TRUE EVEN IF
# DCSCRIPTS IS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO CASE WILL
# DCSCRIPTS LIABILITY EXCEED THE AMOUNT OF THE LICENSE FEE ACTUALLY PAID
# BY LICENSEE TO DCSCRIPTS. 
#
#################################################################################
        
#####
# subroutine display_output
# displays output html page using a template file
#
#####

sub display_output {

   my ($templatefile,$r_namespace) = @_;
   my ($template);

	$| = 1;

   # Open template and read in
  
   open(TEMPLATE,"$templatefile") or
  		my_die("Error in subroutine display_output: Can't open $templatefile",$!);
   {
      local($/) = undef;
      $template = <TEMPLATE>;
   }
   close(TEMPLATE);

   $template =~ s/\$([A-Z]+)/$r_namespace->{$1}/g;
   print $template;

}

#####
# subroutine create_file
# Creates an empty file
#####

sub create_file {

   my ($file) = shift;

   open(FILE,">$file") or
      my_die("Error in subroutine create_datafile: Can't open $file",$!);
   close(FILE);

}

#####
# subroutine check_datafile
# Checks to see if $datafile exists
# If it doesn't exists, then it creates one
# and places @{$r_variables}
######

sub check_datafile {

   my($datafile,$r_variables) = @_;

   unless (-e $datafile) {
      open(FILE,">$datafile") or
			my_die("Error in subroutine check_datafile in dclib.pl: Can't open $datafile",$!);

      foreach (@{$r_variables}) {
         print FILE "$_\n";
      }

      close(FILE);
      chmod(0666,$datafile);
   }
}

#####
# subroutine readdata
# Sucks in all the data from $datafile
# and returns reference to the data
####

sub readdata {

   my($datafile) = shift;
   my($r_data) = [];

   # Pull off datafile name and path

   my ($datadir,$file) = pull_off($datafile);

   AuthGetFileLock("$datadir/$file.lock");

   if (open(DATA,"$datafile")) {
   	@$r_data = <DATA>;
	  close(DATA);
		AuthReleaseFileLock ("$datadir/$file.lock");
	}
	else {
  		AuthReleaseFileLock ("$datadir/$file.lock");
		my_die("Error in subroutine readdata: Can't open $datafile",$!);
	}

  $r_data;

}

#####
# function pull_off
# Takes full directory path to a file
# and pulls off directory and file name
#####

sub pull_off {

   my($datafile) = shift;
   my @stuff = split(/\//,$datafile);
   my $file = pop(@stuff);
   my $datadir = join("\/",@stuff);

   return ($datadir, $file);
}

#####
#
# subroutine writedata
#
#####

sub writedata {

   my($datafile,$r_rows) = @_;

   my ($datadir,$file) = pull_off($datafile);

   AuthGetFileLock("$datadir/$file.lock");

   if (open(DATA,">$datafile")) {
      print DATA @$r_rows;
      close(DATA);
	   chmod(0666,$datafile);
      AuthReleaseFileLock("$datadir/$file.lock");
   }
   else {
      AuthReleaseFileLock("$datadir/$file.lock");
      my_die("Error in subroutine writedata: Can't open $datafile",$!);
   }

}

#####
#
# subroutine appenddata
#
#
#####

sub appenddata {

   my($datafile,$row) = @_;

   my ($datadir,$file) = pull_off($datafile);

   AuthGetFileLock("$datadir/$file.lock");

   if (open(DATA,">>$datafile")) {
      print DATA "$row\n";
      close(DATA);
      AuthReleaseFileLock("$datadir/$file.lock");
   }
   else {
      AuthReleaseFileLock("$datadir/$file.lock");
      my_die("Error in subroutine appenddata: Can't open $datafile",$!);
   }
}

#####
# subroutine readdata
# Sucks in all the data from $datafile
# and returns reference to the data
####

sub readdata_nolock {

   my($datafile) = @_;
   my($r_data) = [];

   my ($datadir,$file) = pull_off($datafile);

   open(DATA,"$datafile") or
	   my_die("Error in subroutine readdata_nolock: Can't open $datafile",$!);
      @{$r_data} = <DATA>;
   close(DATA);

   $r_data;
}

#####
#
# subroutine writedata
#
#####

sub writedata_nolock {

   my($datafile,$r_rows) = @_;

   my ($datadir,$file) = pull_off($datafile);
  
   open(DATA,">$datafile") or
      my_die("Error in subroutine writedata_nolock: Can't open $datafile",$!);
      print DATA @$r_rows;
   close(DATA);

   chmod(0666,$datafile);
  
}

#####
#
# subroutine appenddata
#
#
#####

sub appenddata_nolock {

   my($datafile,$row) = @_;

   my ($datadir,$file) = pull_off($datafile);
  
   open(DATA,">>$datafile") or
	   my_die("Error in subroutine appenddata_nolock: Can't open $datafile",$!);
      print DATA "$row\n";
    close(DATA);
}

#####
#
# subroutine remove_dir
# removes directory and all its content
#
####

sub remove_dir {

   my($dir) = shift;  
  
   opendir(F,"$dir") or
	   my_die("Error in subroutine remove_dir: Can't open directory $dir",$!);

   foreach (readdir(F)) {
      unlink("$dir/$_");
   }

   closedir(F);

   rmdir("$dir");
   
}

#####
#
#   subroutine get_setup_variables
#   displays the form for creating a new forum
#
#####

sub get_setup_variables {

   my($datafile,$r_in) = @_;

   $r_rows = &readdata("$datafile");   
  
   foreach (@$r_rows) {
      chomp;
      ($key,$value) = split /\|/;
      $r_in->{$key} = $value;
   }
}

#####
#
# subroutine clean_data
# Remove HTML and control characters
#
#####

sub clean_data {

   my $text = shift;

   $text =~ s/</&lt;/g;
   $text =~ s/>/&gt;/g;
   $text =~ s/\cM//g;
   $text =~ s/\n\n/<p>/g;
   $text =~ s/\n/<br>/g;
   $text =~ s/\r//g;

   return $text;
}


#####
#
# subroutine my_crypt
# encrpytion routine...rather simple one
# 
#####

sub my_crypt {

   my ($arg1, $arg2) = @_;
   unless ($platform eq "NT") {
	   $arg1 = crypt($arg1,substr($arg2,0,2));
   }
   $arg1;
}

####
#
# subroutine send_mail
# REVISION
# 29 Dec 1998
#   Added Blatmail for NT servers
# 17 Mar 1998 - Version 1.0
#   First release
#
# NOTE:
#   Following variables are global
#   $smtp_server
#   $cart_id
#
# This should change later
####

sub send_mail {

   my ($mailprog,$from,$to,$subject,$message) = @_;

   # Remove REMOVE_THIS if it exists

   $from = remove_antispam($from);
   $to = remove_antispam($to);

   # Open The Mail Program

   unless ($platform eq 'NT') {  
		open(MAIL,"|$mailprog -t") or
			my_die("Error in subroutine send_mail: Can't open $mailprog",$!);
    print MAIL "To: $to\n";
    print MAIL "From: $from\n";
    print MAIL "Subject: $subject\n\n";
    print MAIL "$message\n";
		close (MAIL);
	}
	else {	
		#prepare mail message to send
		my (@output,$status);
		my $temp_name = get_session_id();
		my $temp_file = "$cart_dir/$temp_name.emn";
		$output[0] = $message;
		writedata($temp_file,\@output);
		$status = `$mailprog $temp_file -s \"$subject\" -f $from -t $to -server $smtp_server`;
		unlink($temp_file); 
	}

}

#####
#
# subroutine: AuthGetFileLock 
#   Usage:
#     &AuthGetFileLock("lockfilename");
# 
#  This routine locks a file so that no one else
#  can get to it while it is being written to.
# 
#  Parameters:
#     $lock_file = filename to use as a temporary lock file
#
#   Output:
#      None.  It checks for the existance of a lock file
#      and if it finds it, it waits until the lock file
#      disappears.  After the lock file is gone, it opens
#      the lock file up itself.
#
#
#####

sub AuthGetFileLock {  

   my ($lock_file) = @_;
   my ($endtime);  
   $endtime = 10;
   $endtime = time + $endtime;

   my $delta = 1;

   if (-e $lock_file && -M $lock_file > $delta) {
      unlink($lock_file);
   }

   while (-e $lock_file && time < $endtime) {
        # Do Nothing
   }

   open(LOCK_FILE, ">$lock_file") or
      my_die("Error in subroutine AuthGetFileLock: Can't open $lock_file",$!);

#    flock(LOCK_FILE, 2); # 2 exclusively locks the file

}

######
#
# subroutine: AuthReleaseFileLock
#   Usage:
#     &AuthReleaseFileLock($lock_file);
#
#  This routine releases the lock file when we are
#  done with the original file.
#
#  Parameters:
#     $lock_file = filename to use as a temporary lock file
#
#   Output:
#      None. Removes the lock file.
# 
#####

sub AuthReleaseFileLock {

   my ($lock_file) = @_;

#    flock(LOCK_FILE, 8);

   close(LOCK_FILE);
   unlink($lock_file);

} # end of ReleaseFileLock   

###
#
# subroutine sendCookie
# Sends HTTP-COOKIE to the client
#
###

sub send_cookie {

   my ($key,$value,$expires,$domain) = @_;

   if ($expires ne "") {
      print "Set-Cookie: $key=$value; expires=$expires;\n";
	}
	else {
		print "Set-Cookie: $key=$value;\n";
	}
}

###
#
# subroutine get_cookie
# Get cookie from the client
# Cookie's name is $cookie
#
###

sub get_cookie {

   my ($cookie) = @_;
   my (@key_value_pairs, $key, $value);

   @key_value_pairs = split (/;\s/, $ENV{'HTTP_COOKIE'});

   foreach (@key_value_pairs) {
      ($key,$value) = split /=/;
      if ($key eq $cookie) {
         return $value;
      }
   }
   return 0;
}

####
#
# subroutine add_adtispam
#
# Inserts 'REMOVE_THIS' string after @ sign
#
####

sub add_antispam {

	my $email = shift;
	$email =~ s/(.*)\@(.*)/$1\@REMOVE_THIS$2/;
	return $email;

}

####
#
# subroutine remove_adtispam
#
# Removes 'REMOVE_THIS' string after @ sign
#
####

sub remove_antispam {

	my $email = shift;
	$email =~ s/REMOVE_THIS//;
	return $email;

}


####
# subroutine get_date
#
####

sub get_date {

   my ($r_in) = @_;
   my @months = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
	
   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	my $am_pm = 'AM';
	
	if ($hour > 12) {
		$hour -= 12;
		$am_pm = 'PM';
	}
	elsif ($hour == 12) {
		$am_pm = 'PM';
	}

	# Format to look nice
	
   $sec = sprintf("%02d",$sec);
   $min = sprintf("%02d",$min);
   $hour = sprintf("%02d",$hour);
   $mon = sprintf("%02d",$mon);
   $mday = sprintf("%02d",$mday);
   $year += 1900;

   my $month = $months[$mon];

   my $localtime = "$hour\:$min\:$sec $am_pm";
   my $date = "$month-$mday-$year";

	return "$date $localtime";
}

####
#
# subroutine my_die
#
####

sub my_die {

	my($my_mesg, $sys_mesg) = @_;
  	print "\n";

	print qq~
	<html>
	<head>
	<title>$my_mesg</title>
	</head>
	<body bgcolor="#FFFFFF">
	<font face="verdana" size="5"><b>SCRIPT ERROR!!!</b></font>
	<hr>
	<font face="verdana" size="3">
	<b>
	There was an error in processing your request.<br>
	Following is the error message:
	<ul>
	<li>Script Message: $my_mesg
	<li>System Message: $sys_mesg
	</ul>
	<hr>
	Please contact the <a href="mailto:$admin_email">administrator</a> of this site.
	<p>
	Thank you.
	</b>
	</font>

	</body>
	</html>
	~;
	exit;			
}

#####
#
# Subroutine get_session_id
# Generates session ID for a User.
# This portion of code from Selena and Gunther's
# auth-extra-lib.pl
#
####


sub get_session_id {

	my ($session, $session_file);

	# Seed the random generator

	srand($$|time);
	$session = int(rand(60000));

	# pack the time, process id, and random $session into a
	# hex number which will make up the session id.

	$session = unpack("H*", pack("Nnn", time, $$, $session));

} # End of MakeSessionFile

#####
# function toggle_color
#
#####

sub toggle_color {

	my $reset = shift;
	
	unless ($reset) {
		if ($bgcolor eq $bg_color{2}) {
			$bgcolor = $bg_color{3};
			$fontcolor = $font_color{3};
			$fontface = $font_face{3};
			$fontsize = $font_size{3};
		}
		else {
			$bgcolor = $bg_color{2};
			$fontcolor = $font_color{2};
			$fontface = $font_face{2};
			$fontsize = $font_size{2};
		}
	}
	else {
		$bgcolor = $bg_color{2};
		$fontcolor = $font_color{2};
		$fontface = $font_face{2};
		$fontsize = $font_size{2};
	}
}


1;
