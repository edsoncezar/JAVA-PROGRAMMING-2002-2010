# dcprotect.pl - an authentication script
# Written By David S. Choi, dc@sitedeveloper.com
# 15 June 1998
#
# REVISION HISTORY:
#
# 15 June 1998 - Version 1.0 Release for Beta
#
# 10 Oct 1998 - Version 2.0 Release for Beta
#  - Changed authentication scheme - instead of storing
#    username and password as cookies, use session ID
#  - Removed User profile function - too much work :-)
#
#------------------------------------------------------------------
#
# Copyright  �1997-1998 DCScripts All Rights Reserved
# As part of the installation process, you will be asked
# to accept the terms of this Agreement. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts and DCProtect.
# You should carefully read the following terms and conditions before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of the Software.
# 
# LICENSE TO REDISTRIBUTE
# Distributing the software and/or documentation with other products
# (commercial or otherwise) or by other than electronic means without
# DCScripts's prior written permission is forbidden.
# All rights to the DCProtect software and documentation not expressly
# granted under this Agreement are reserved to DCScripts.
#
# DISCLAIMER OF WARRENTY
# THIS SOFTWARE AND ACCOMPANYING DOCUMENTATION ARE PROVIDED "AS IS" AND
# WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER
# WARRANTIES WHETHER EXPRESSED OR IMPLIED.   BECAUSE OF THE VARIOUS HARDWARE
# AND SOFTWARE ENVIRONMENTS INTO WHICH DCFORUM98 MAY BE USED, NO WARRANTY OF
# FITNESS FOR A PARTICULAR PURPOSE IS OFFERED.  THE USER MUST ASSUME THE
# ENTIRE RISK OF USING THIS PROGRAM.  ANY LIABILITY OF DCSCRIPTS WILL BE
# LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.
# IN NO CASE SHALL DCSCRIPTS BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR
# CONSEQUENTIAL DAMAGES OR LOSS, INCLUDING, WITHOUT LIMITATION, LOST PROFITS
# OR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, WHETHER SUCH DAMAGES ARE
# BASED UPON A BREACH OF EXPRESS OR IMPLIED WARRANTIES, BREACH OF CONTRACT,
# NEGLIGENCE, STRICT TORT, OR ANY OTHER LEGAL THEORY. THIS IS TRUE EVEN IF
# DCSCRIPTS IS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO CASE WILL
# DCSCRIPTS LIABILITY EXCEED THE AMOUNT OF THE LICENSE FEE ACTUALLY PAID
# BY LICENSEE TO DCSCRIPTS. 
#
#
#------------------------------------------------------------
# Usage:
#
# $r_userdata = dcprotect($thisurl,$password_file_dir,\%in,
#			\@login_fields,\%field_form_type);
#
#   $thisurl - URL of the cgi script calling dcprotect
#   $password_file_dir - directory location of the password file
#   \%in - reference to all incoming data
#   \@login_fields - login fields
#   \%field_form_type - login field form type
#
#-------------------------------------------------------------

sub dcprotect {

  my ($thisurl,$datadir,$r_in,
			$r_login_fields,$r_form_type) = @_;
  my ($heading,$sub_heading,$html_output);
	my ($r_local);

  # Initialize script hash $r_in and $r_local
  # This subroutine acts as an interface to the mother script

	$r_in->{'datadir'} = $datadir;
  $r_local = init($thisurl,$datadir,$r_in,$r_login_fields,$r_form_type);

  if ($r_in->{'dc_action'} eq 'login' && $r_in->{'login'} ne "") {

    $error = check_password($r_in,$r_local);

    unless ($error) {

			my $session = get_session_id();

			if ($r_in->{'remember'}) {
	      send_cookie($r_local->{'cookie_name'},$session,
					$r_in->{'expires'},$r_local->{'domain'});
			}
			else {
	      send_cookie($r_local->{'cookie_name'},$session,
  	      $r_local->{'expires'},$r_local->{'domain'});
			}

			my @temp_array;

     	foreach (keys %{ $r_local->{'login_fields'} }) {
				unless ($_ eq "Password") {
					my $temp_string = join ("::",$_,$r_local->{'login_info'}->{$_});
        	push(@temp_array,"$temp_string\n");
				}
      }

			# Create session file

			writedata_nolock("$datadir/$session.session",\@temp_array);

			return $r_local->{'login_info'};

    }
    else {
      print "\n";
      $heading = "DCProtect Login Window";
      $sub_heading = "<b><font size=\"+1\">Login Problem: $error<br></font></b>\n";
      $html_output .= display_logon($r_in,$r_local);
    }

  }

  # Check and see if one of the management function was chosen
  
  elsif ($r_in->{'dc_action'} eq 'usermanage' ||
         $r_in->{'dc_action'} eq 'configure' ||
         $r_in->{'dc_action'} eq 'user_mod' ) {

    print "\n";	#End of HTTP Header

    my $cookie = get_cookie($r_local->{'cookie_name'});

    if ($cookie) {

      my $session = $cookie;

			$r_in->{'session'} = $session;
			
      get_userdata("$datadir/$session\.session",$r_local);
 
      if ($r_in->{'dc_action'} eq "user_mod") {

				# Check to make sure this request in not REMOTE POSTING

        unless ($ENV{'HTTP_REFERER'} =~ /$r_local->{'thisurl'}/) {
          $heading = "DCProtect User Manager";
          $sub_heading = "ERROR: User Management Disabled";
          $html_output .= qq~
          <h4 align="center">
          The webmaster of this site has disabled User Management Console.
          To change your password or profile, please email the webmaster
          </h4>
          ~;
        }
        elsif ($r_local->{'auth'}->{'Allow Users to Change Password'} eq 'on') {
          ($heading,$sub_heading,$html_output)
          = user_mod($r_in,$r_local);
        }
        else {
          $heading = "DCProtect User Manager";
          $sub_heading = "ERROR: User Management Console Disabled";
          $html_output .= qq~
          <h4 align="center">
          The webmaster of this site has disabled User Management Console.
          To change your password or profile, please email the webmaster
          </h4>
          ~;
        }

      }
      elsif ($r_in->{'dc_action'} eq 'usermanage') {
        check_group($r_in,$r_local,"admin");
        $heading = $main_heading;
        ($sub_heading, $html_output) = user_manager($r_in,$r_local);

      }
      elsif ($r_in->{'dc_action'} eq 'configure') {
        check_group($r_in,$r_local,"admin");
        $heading = $main_heading;
        $sub_heading = "";
        $html_output = configure($r_in,$r_local);
      }
    
    }
    else {
      $heading = "DCProtect Login Window";
      $sub_heading = "Please Log on";
      $html_output = display_logon($r_in,$r_local);
    }

  }

  # The user has clicked on Register button

  elsif ($r_in->{'dc_action'} eq 'login' && $r_in->{'Register'} ne "") {
    print "\n";

    $heading = "DCProtect Registration Form";
    $sub_heading = "Please complete the follwing form. 
      (*) indicates required field";
    $html_output = output_form($r_in,$r_local);

  }

  # The user completed registration form

  elsif ($r_in->{'dc_action'} eq 'register') {

		# End of HTTP Header

    print "\n";

    $heading = "DCProtect Registration Result";

    my @required = split(/\,/,$r_in->{'required'}); 

		if ($r_local->{'auth'}->{'Register Via EMail'} eq "on") {
			my $session = get_session_id();
	  	$r_in->{'Password'} = substr($session,3,6);
	  	$r_in->{'dup_Password'} = substr($session,3,6);
  	}

    foreach (@required) {
      unless ($r_in->{$_}) {
        push(@ERROR,$_);
      }
    }
    
  # Check and see if all required fields are completed
  
    if (@ERROR) {
      $sub_heading = "Incomplete Registration Form";
      $html_output .= qq~
      <h4 align="center">
      Some of the required fields have not been provided.<br>
      Please try again.
      </h4>
      ~;
      $html_output .= output_form($r_in,$r_local);
    }
    else {

			$username = $r_in->{'Username'};
			$password = $r_in->{'Password'};
      $error = register($r_in,$r_local);

      if ($error) {
        $sub_heading = "$error";
        $html_output = output_form($r_in,$r_local);
      }
      else {        
 
        if ($r_local->{'auth'}->{'Notify Admin on Register'} eq "on") {

          my $subject = "New user registration";
          my $mail_message = "New user has registered at your site\n";
          $mail_message .= "Here is the registration information\n";
          foreach (@{$r_login_fields}) {
            $mail_message .= "$_: $r_in->{$_}\n";
          }
          send_mail( $r_local->{'auth'}->{'Sendmail Path'},
            $r_local->{'auth'}->{'Admin EMail Address'},
            $r_local->{'auth'}->{'Admin EMail Address'},
            $subject,$mail_message );
        }

  			if ($r_local->{'auth'}->{'Register Via EMail'} eq "on") {
				
          my $subject = "DCProtect Registration Information";
          my $mail_message = "Thank you for registering with us\n";
          $mail_message .= "Your username is $username\n";
          $mail_message .= "Your password is $password\n";
          $mail_message .= "Please change your password
											the firsttime you visit our site\n";

          send_mail( $r_local->{'auth'}->{'Sendmail Path'},
            $r_local->{'auth'}->{'Admin EMail Address'},
            $r_in->{'EMail'},$subject,$mail_message );

	        $sub_heading .= qq~
						Your password has been sent to your email.<br>&nbsp;<br>
						If you do not receive it with in next 24 hours, please contact
						the site administrator.  Thank you.<p>~;
						
		      $html_output .= display_logon($r_in,$r_local);

				}
        elsif ($r_local->{'auth'}->{'Activate User on Register'} eq 'on') {
          $sub_heading = "You have been added to Database.<br>&nbsp;<br>
						You may now login using your username and password.";
		      $html_output = display_logon($r_in,$r_local);
        }
        else {
          $sub_heading .= qq~
          <p>
          You have been added to Database.
          <br>However, it has not been activated yet.
          <br>As soon as your account is activated,
          <br>you will be notified via e-mail.  Thank you.
          <p>
          ~;
        }

      }
    } 
  }

  else {

    my $cookie = get_cookie($r_local->{'cookie_name'});
		my $session = $cookie;
		
    if ($cookie && $r_in->{'az'} ne "login") {
      get_userdata("$datadir/$session\.session",$r_local);
      return ($r_local->{'login_info'});

    }
    else {

			unless ($r_in->{'az'} ne "login") {

				if (-e "$datadir/$session\.session") {
					unlink "$datadir/$session\.session";
				}

				my $expires = "Sat, 04-Jul-98 12:00:00 GMT";
	      send_cookie($r_local->{'cookie_name'},$cookie,$expires,$r_local->{'domain'});
			}

    	print "\n";
		
# Following modification is needed to distinguish board from admin

      $heading = "DCProtect Login Window";
      $sub_heading = "Please enter your username and password to log on";     
      $html_output = display_logon($r_in,$r_local);
    }

  }

  my %namespace = (
    MENU => $menu,
    HEADER => $heading,
    SUBHEADER => $sub_heading,
    HTMLOUTPUT => $html_output );

  display_output($templatefile,\%namespace); 

  exit(0);

}


####
#
# subroutine init
#
###

sub init {

  my ($thisurl,$datadir,$r_in,$r_login_fields,$r_form_type) = @_;

  my $r_local = {};

# Let's clean up form data
# remove control characters and etc...

  $r_local->{'thisurl'} = $thisurl;
  $r_local->{'fields'} = $r_login_fields;

  $r_local->{'setup_file'} = "$datadir/$r_in->{'auth_setup_file'}";
  $r_local->{'password_file'} = "$datadir/$r_in->{'password_file'}";
  
  #Let's include Username,Password, and Group

  unshift(@$r_login_fields,"Password","Username","Group");
  push(@$r_login_fields,"Status");

  my @variables = (
    'Admin EMail Address|you@youremail.com',
    'Allow Users to Register|on',
    'Notify Admin on Register|off',
    'Notify User on Act/Deactivation|off',
    'Default Group|normal',
    'Sendmail Path|/usr/lib/sendmail',
    'Activate User on Register|on',
    'Register Via EMail|off',
    'Allow Users to Change Password|on'

  );         

  check_datafile($r_local->{'setup_file'},\@variables);

  # read in setup parameters to $r_local->{'auth'}

  $r_local->{'auth'} = {};

  get_setup_variables($r_local->{'setup_file'},$r_local->{'auth'});

  # Let's define form type
  # NOTE: Status is 'hidden' if this is a new user registration
  
  $r_form_type->{'Username'} = 'text|40|required';
  $r_form_type->{'Password'} = 'password|40|required';
  $r_form_type->{'Group'} = "hidden|$r_local->{'auth'}->{'Default Group'}|required";
  $r_form_type->{'Status'} = 'radio|on|off';

  # If $password_file is empty, then the first person that
  # registers will have 'admin' as Group

  check_datafile($r_local->{'password_file'});
  $r_local->{'form_type'} = $r_form_type;
  
  # Mark off login field locations
  # Needed in subroutines everywhere...
  # $r_in->{$login_field} is a reference to a hash whose
  # keys are the fields and values are the array location
  # $r_local->{'login_info'} is a reference to a hash whose
  # keys are the fields and values are the data read in from
  # the User database
  # $r_in->{'login_data'} is a reference to a hash whose
  # keys are the fields and values are input form values
    
  foreach (@$r_login_fields) {
    $r_local->{'login_fields'}->{$_} = $j;
    $r_local->{'login_info'}->{$_} = '';
    $j++;
  }

  $r_local->{'user_list'} = [];

  # Define Cookie Name

  $r_local->{'cookie_name'} = $r_in->{'cookie_name'};

  # Cookie will expire when the session is over
  
  $r_local->{'expires'} = "";
  $r_local->{'domain'} = "";

  return $r_local;
}

###
#
# subroutine user_mod
# couple of routines let user change password
# and profiles
#
###

sub user_mod {

  my ($r_in,$r_local) = @_;
  my ($html_output);

  if ($r_in->{'sub_action'} eq 'change_password') {

    if ($r_in->{'command'} eq 'save') {

  		get_login_data($r_local->{'password_file'},
					$r_local->{'login_info'}->{'Username'},$r_local);
					
      my $test = my_crypt ($r_in->{'Old_Password'},$r_local->{'login_info'}->{'Password'});

      unless ($test eq $r_local->{'login_info'}->{'Password'}) {
        my $heading = "DCProtect User Manager";
        my $sub_heading = "ERROR: Incorrect Password\n";
        my $html_output = "<h4 align=center>Please go back and try again</h4>";
        return ($heading,$sub_heading,$html_output);
      }

      $r_in->{'Password'} = $r_in->{'New_Password'};
      $r_in->{'dup_Password'} = $r_in->{'dup_New_Password'};

      foreach (@{$r_local->{'fields'}}) {
        unless($_ eq 'Password') {
          $r_in->{$_} = $r_local->{'login_info'}->{$_};
        }
      }

      $error = update_user($r_in,$r_local);

      unless($error) {
				if (-e "$r_in->{'datadir'}/$r_in->{'session'}\.session") {
					unlink("$r_in->{'datadir'}/$r_in->{'session'}\.session");
				}

        $heading = "DCProtect Login Window";
        $sub_heading = "Your password has been changed.\n";
        $html_output .= qq~
        Please do not forget them. Please login again with your new password.
        ~;
	      $html_output .= display_logon($r_in,$r_local);

      }
      else {
        $heading = "User password change result";
        $sub_heading = "Your password has not been changed!!!\n";
        $html_output .= qq~
        <h4 align="center">
        Reason: $error<p>
        Please go back and try again.
        </h4>
        ~;
      }
    }
    else {
      $heading = "DCProtect User Manager";
      $sub_heading = "Change your password";
      $html_output .= qq~
      <form action="$r_local->{'thisurl'}" method="post">
      <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
      <input type="hidden" name="sub_action" value="$r_in->{'sub_action'}">
      <input type="hidden" name="command" value="save">
      <input type="hidden" name="Username" value="$r_local->{'login_info'}->{'Username'}">
      <table border="0" width="100%">
      <tr bgcolor="#DDDDDD">
        <th>Old Password</th>
        <td>
        <input type="password" name="Old_Password" size="40">
        </td>
      </tr>
      <tr bgcolor="#DDDDDD">
        <th>New Password</th>
        <td>
          <input type="password" name="New_Password" size="40">
        </td>
      </tr>
      <tr bgcolor="#DDDDDD">
        <th>New Password Again</th>
        <td>
          <input type="password" name="dup_New_Password" size="40">
        </td>
      </tr>
      <tr bgcolor="#DDDDDD">
        <td align="center" colspan="2">
          <input type="submit" value="Submit">
          <input type="reset" value="Reset">
        </td>
      </tr>
      </table>
      </form>
      ~;
    }
  }

  else {

    $heading = "DCProtect User Manager";
    $sub_heading = "Please choose from following options";
    $html_output .= qq~
    <form action="$r_local->{'thisurl'}" method="post">
    <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
    <table border="0" width="100%" align="center">
    <tr bgcolor="#EEEEEE">
      <td>
        <input type="radio" name="sub_action" value="change_password">
        <b>Change your password</b>
      </td>
    </tr>
    <tr bgcolor="#EEEEEE">
      <td align="center">
      <input type="submit" value="Submit">
      <input type="reset" value="Reset">
      </td>
    </tr>
    </table>
    </form>~;
  }

  return ($heading,$sub_heading,$html_output);
}

###
### subroutine user_manager
###

sub configure {

  my ($r_in,$r_local) = @_;

  # if command is change_settings, the new parameters
  # are saved to the auth variable file

  if ($r_in->{'command'} eq "change_settings") {
    my @rowdata;
    
    $html_output .= qq~
      <h3 align="center">Your system configuration has been changed</h3>
      <table border="0" width="100%" cellpadding="2">
    ~;

    foreach (keys %{$r_local->{'auth'}}) {
      $temp = join("\|",$_,$r_in->{$_});
      
      push(@rowdata,"$temp\n");

      $html_output .=qq~
      <TR>
        <TH BGCOLOR="#DDDDDD" ALIGN="RIGHT" VALIGN="CENTER">
        $_
        </TH>
        <TD BGCOLOR="#DDDDDD" ALIGN="LEFT" VALIGN="CENTER">
        $r_in->{$_}
        </TD>
      </TR>~;
    }
    
    $html_output .= qq~
    <tr bgcolor="#DDDDDD">
      <td colspan="2"align="center">
      </td>
    </tr>
    </table>~;
    
    writedata($r_local->{'setup_file'},\@rowdata);
    
  }
  else {
    
    $html_output .= qq~
    <form action="$r_local->{'thisurl'}" method="post">
    <input type="hidden" name="dc_action" value="configure">
    <input type="hidden" name="command" value="change_settings">

    <table border="0" width="100%" cellpadding="2">
    <tr bgcolor="#DDDDDD">
      <td colspan="2"><b>DCProtect Security Manager</b>
        <br>To modify forum security settings, choose from following
        options.
      </td>
    </tr>
    <tr bgcolor="#DDDDDD">
      <th  align="left" valign="top" colspan="2">
      Current Settings
      </th>
      <td>
      </td>
    </tr>~;

    foreach (keys %{$r_local->{'auth'}}) {
      $html_output .= qq~
      <tr bgcolor="#DDDDDD">
        <th align="right">
        $_
        </th>
      ~;
      if ($_ eq "Default Group") {
        my @group = qw(admin normal member moderator);
        $html_output .= qq~
        <td>
        <select name="$_">~;
        
        foreach $group (@group) {
          if ($r_local->{'auth'}->{$_} eq $group) {
            $html_output .= "<option value=\"$group\" selected>$group\n";
          }
          else {
            $html_output .= "<option value=\"$group\">$group\n";
          }
        }
        $html_output .= qq~
        </select>
        </td>~;
        
      }
      elsif ($r_local->{'auth'}->{$_} eq "on") {
        $html_output .= qq~
        <td>
        <input type="radio" name="$_" value="on" checked>On
        <input type="radio" name="$_" value="off">Off
        </td>~;
      }
      elsif ($r_local->{'auth'}->{$_} eq "off") {
        $html_output .= qq~
        <td>
        <input type="radio" name="$_" value="on">On
        <input type="radio" name="$_" value="off" Checked>Off
        </td>~;
      }
      else {
        $html_output .= qq~
        <td>
        <input type="text" name="$_" value="$r_local->{'auth'}->{$_}" size="40">
        </td>~;
      }

      $html_output .= qq~     
      </tr>~;
    }
    

      $html_output .= qq~
    <tr bgcolor="#DDDDDD">
      <td colspan="2"align="center">
      <input type="submit" value="Submit">
      <input type="reset" value="Reset">
      </td>
    </tr>
    </table>
    </form>~;
    
  }

  return $html_output;
}


###
### subroutine user_manager
###

sub user_manager {

  my ($r_in,$r_local) = @_;

  if ($r_in->{'command'} eq 'save') {

    print "\n";

    $heading = "DCProtect user Registration Result";
    my @required = split(/\,/,$r_in->{'required'});

    foreach (@required) {
      unless ($r_in->{$_}) {
        push(@ERROR,$_);
      }
    }
    
    # Check and see if all required fields are completed

    if (@ERROR) {
      $sub_heading = "Incomplete Registration Form";
      $html_output = "Some of the required fields have
               not been completed. Please try again";
      $html_output .= output_form($r_in,$r_local);
    }
    else {

      if ($r_in->{'sub_action'} eq 'modify') {
        $error = update_user($r_in,$r_local);
        $status = "The user account has been modified.";
      }
      else {
        $error = register($r_in,$r_local);
        $status = "The new user account has been created.";
      }

      if ($error) {
        $sub_heading = "$error";
        $html_output = output_form($r_in,$r_local);
      }
      else {
        $sub_heading = "User Manager Result";
        $html_output .= qq~
        <h4 align="center">
        $status
        </h4>
       ~;
      }
    } 

    return $sub_heading, $html_output;
  
  }
  elsif ($r_in->{'sub_action'} eq 'new_user') {

    $html_output = output_form($r_in,$r_local);
    return $html_output;

  }
  elsif ($r_in->{'command'} eq "list") {
  
    if ($r_in->{'sub_action'} eq 'activate') {
      get_user_list($r_in,$r_local,'off');
      $input_type = "checkbox";
    }
    elsif ($r_in->{'sub_action'} eq 'deactivate') {
      get_user_list($r_in,$r_local,'on');      
      $input_type = "checkbox";
    }
    elsif ($r_in->{'sub_action'} eq 'remove') {
      get_user_list($r_in,$r_local,'');      
      $input_type = "checkbox";
    }
    else {
      get_user_list($r_in,$r_local,'');      
      $input_type = "radio";
    }
    
    $html_output .= qq~
    <form action="$r_local->{'thisurl'}" method="post">
    <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
    <input type="hidden" name="sub_action" value="$r_in->{'sub_action'}">
    <input type="hidden" name="command" value="doit">
    <table border="0" width="100%" cellpadding="2">
    <tr bgcolor="#DDDDDD">
      <td colspan="6"><b>User Account Management Console</b>:
      <br>Choose from following user account to $r_in->{'sub_action'} them.
      <p>
      </td>
    </tr>
    <tr bgcolor=\"#DDDDDD\">
      <th valign="top">
      Select
      </th>
    ~;

    # Here, let's only display the first five fields...
	 # Do not display password

    foreach (@{ $r_local->{'fields'} }[1..5]) {
      $html_output .= qq~
        <th valign="top">
        $_
        &nbsp;
        </th>
      ~;
    }
  
    my $users;

    foreach (@{$r_local->{'user_list'}}) {
      $users = "yes";
      my @fields = @{$_};
      $html_output .= qq~
      </tr>
      <tr bgcolor=\"#DDDDDD\">
      <td valign="top">
      <input type="$input_type" name='user_selected'
        value="$fields[$r_local->{'login_fields'}->{'Username'}]">
      </td>
      ~;
      
      foreach $field (@{ $r_local->{'fields'} }[1..5]) {
      $html_output .= qq~
        <td valign="top">
        $fields[$r_local->{'login_fields'}->{$field}]
        &nbsp;
        </td>
      ~;
      }
      $html_output .= "</tr>\n";    

    }
    
    unless ($users) {
      $html_output .= qq~
      <tr bgcolor="#DDDDDD">
        <th colspan="7" align="center">
        There are no usernames that match your criteria!!!
        </th>
      </tr>
      ~;
    }

    $html_output .= qq~
    <tr bgcolor="#DDDDDD">
      <td colspan="6" align="center">
      <input type="submit" value="Submit">
      <input type="reset" value="Reset">
      </td>
    </tr>
    </table>
    </form>~;
    
  }
  
  elsif ($r_in->{'command'} eq "doit") {

    if ($r_in->{'sub_action'} eq 'modify') {
      get_login_data($r_local->{'password_file'},$r_in->{'user_selected'},$r_local);

      foreach (keys %{$r_local->{'login_info'}} ) {

				if ($_ eq "EMail") {
					$r_in->{$_} = remove_antispam($r_local->{'login_info'}->{$_});
				}
				else {
        	$r_in->{$_} = $r_local->{'login_info'}->{$_};
				}
				
      }

      $html_output = output_form($r_in,$r_local);
      return $html_output;
    }


    my @user_selected = split(/\0/,$r_in->{'user_selected'});
    $r_in->{'user'} = 'all';
    get_user_list($r_in,$r_local,'');

    my @rowdata;
    
    foreach (@{$r_local->{'user_list'}}) {

      my @fields = @{$_};
      my $hit = "";

      foreach (@user_selected) {

        if ($fields[$r_local->{'login_fields'}->{'Username'}] eq $_) {

          $hit = "yes";

          if ($r_in->{'sub_action'} eq 'activate') {

            $subject = "You're account have been activated";
            $mail_message = "Go there now to verify $r_local->{'thisurl'}";
            $fields[-1] = 'on';
            my $temp = join("\|",@fields);
            push(@rowdata,"$temp\n");

          }
          elsif ($r_in->{'sub_action'} eq 'deactivate') {

            $subject = "You're account have been deactivated";
            $mail_message = "You can reply to this email for further inquery";
            $fields[-1] = 'off';
            my $temp = join("\|",@fields);
            push(@rowdata,"$temp\n");

						if (-e "$r_in->{'datadir'}/$_\.session") {
							unlink("$r_in->{'datadir'}/$_\.session");
						}

          }
          elsif ($r_in->{'sub_action'} eq 'remove') {
            $subject = "You're account have been removed";
            $mail_message = "You can reply to this email for further inquery";

						if (-e "$r_in->{'datadir'}/$_\.session") {
							unlink("$r_in->{'datadir'}/$_\.session");
						}

						if (-e "$r_in->{'datadir'}/$_\.log") {
							unlink("$r_in->{'datadir'}/$_\.log");
						}

          }


          if ($r_local->{'auth'}->{'Notify User on Act/Deactivation'} eq "on") {
            send_mail( $r_local->{'auth'}->{'Sendmail Path'},
            $r_local->{'auth'}->{'Admin EMail Address'},
            $fields[$r_local->{'login_fields'}->{'EMail'}],
            $subject,$mail_message );
          }
        }
      }
      unless ($hit) {
        my $temp = join("\|",@fields);
        push(@rowdata,"$temp\n");
      }
    }
    
    writedata($r_local->{'password_file'},\@rowdata);

    $sub_heading = "User Manager Request Result";
    $html_output .= qq~
    <h4 align="center">
    User Database has been updated
    </h4>
    ~;
  }

  else {

    $html_output .= qq~
    <form action="$r_local->{'thisurl'}" method="post">
    <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
    <input type="hidden" name="command" value="list">
    <table border="0" width="100%" cellpadding="2">
    <tr bgcolor="#DDDDDD">
      <td colspan="2"><b>Option 1. Create New User Account</b>
        <br>Just click on 'submit' button to create new user account
      </td>
    <tr bgcolor="#DDDDDD">
      <th  align="right" valign="top">&nbsp;</th>
      <td>
        <input type="radio" name="sub_action" value="new_user" checked>
        <b>Create new user account</b>
      </td>
    </tr>
    <tr bgcolor="#DDDDDD">
      <td colspan="2"><b>Option 2. Manage Existing Accounts</b>
        <br>To manage
        user accounts, narrow your search by selecting the first letter
        of the username and then select a function.
				To list the entire user database, select 'All'.
        <br>
      </td>
    </tr>
    <tr bgcolor="#DDDDDD">
      <th  align="right" valign="top">Step 1.</th>
      <td>
      <b>Reduce account list</b> by selecting the first
      character of your Username begins with:
      <select name="user">
      <option value="all" selected>All
      <option value="a">a or A
      <option value="b">b or B
      <option value="c">c or C
      <option value="d">d or D
      <option value="e">e or E
      <option value="f">f or F
      <option value="g">g or G
      <option value="h">h or H
      <option value="i">i or I
      <option value="j">j or J
      <option value="k">k or K
      <option value="l">l or L
      <option value="m">m or M
      <option value="n">n or N
      <option value="o">o or O
      <option value="p">p or P
      <option value="q">q or Q
      <option value="r">r or R
      <option value="s">s or S
      <option value="t">t or T
      <option value="u">u or U
      <option value="v">v or V
      <option value="w">w or W
      <option value="x">x or X
      <option value="y">y or Y
      <option value="z">z or Z
      <option value="0">0
      <option value="1">1
      <option value="2">2
      <option value="3">3
      <option value="4">4
      <option value="5">5
      <option value="6">6
      <option value="7">7
      <option value="8">8
      <option value="9">9
      <option value="other">Other
      </select>
      </td>
    </tr>
    <tr bgcolor="#DDDDDD">
      <th align="right" valign="top">Step 2.</th>
      <td>
        <input type="radio" name="sub_action" value="activate">
        <b>Activate user accounts:</b> Selecting 'All' will list
        every user accounts that are currently deactivated
        <br>
        <input type="radio" name="sub_action" value="deactivate">
        <b>Deactivate user accounts:</b> Selecting 'All' will list
        every user accounts that are currently activated
        <br>
        <input type="radio" name="sub_action" value="remove">
        <b>Remove user accounts:</b> Narrow your search to list
        only a partial listing of user database (faster download).
        <br>
        <input type="radio" name="sub_action" value="modify">
        <b>Modify user accounts:</b> Narrow your search to list
          only a partial listing of user database (faster download).
      </td>
    </tr>
    <tr bgcolor="#DDDDDD">
      <td colspan="2"align="center">
      <input type="submit" value="Submit">
      <input type="reset" value="Reset">
      </td>
    </tr>
    </table>
    </form>~;
    
  }

  return $html_output;
}

###
#
# subroutine output_form
# Prints registration form to the browser
#
###

sub output_form {

  my ($r_in,$r_local) = @_;

  my ($temp_html);

  my $html_output .= qq~
  <form action="$r_local->{'thisurl'}" method="post">
  ~;
  
  if ($r_in->{'sub_action'} eq 'modify') {

    $r_local->{'form_type'}->{'Group'} = 
      "select|normal|member|moderator|admin";

    $html_output .= qq~
    <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
    <input type="hidden" name="sub_action" value="$r_in->{'sub_action'}">
    <input type="hidden" name="command" value="save">
    ~;
  }
  elsif ($r_in->{'sub_action'} eq 'new_user') {

    $r_local->{'form_type'}->{'Status'} = 
      "hidden|$r_local->{'auth'}->{'Activate User on Register'}";

    $r_local->{'form_type'}->{'Group'} = 
      "select|normal|member|moderator";

    $html_output .= qq~
    <input type="hidden" name="dc_action" value="$r_in->{'dc_action'}">
    <input type="hidden" name="sub_action" value="$r_in->{'sub_action'}">
    <input type="hidden" name="command" value="save">
    ~;

  }
  else {

    $r_local->{'form_type'}->{'Status'} = "";
    $r_local->{'form_type'}->{'Group'} = "";
    $html_output .= qq~
    <input type="hidden" name="dc_action" value="register">
    ~;

  }

# For Internal Use Only...if you find this
# section of the code and don't know why it's here
# you can email me at dc@sitedeveloper.com
  
  $html_output .= qq~ 
  <table border="0" align="center">
  ~;

	my (%temp);

  foreach $field (@{$r_local->{'fields'}}) {

    my @fields = split(/\|/,$r_local->{'form_type'}->{$field});
    my $required = pop(@fields);

    if ($required eq "required") {

      if (defined $temp{'required'}) {
        $temp{'required'} = join("\,",$temp{'required'},$field);
      } else {
        $temp{'required'} = $field;
      }

      $suffix = " <font color=\"#0000FF\"><b>*</b></font>:";
    }
    else {
      push(@fields,$required);
      $suffix = ":";
    }
    
    if ($fields[0] eq "text") {

      if ($field eq 'Username') {
        my $temp .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
          <input type="$fields[0]" name="$field"
            size="$fields[1]" value="$r_in->{$field}">
        </td>
        </tr>
        ~;
        $temp_html = $temp . $temp_html;
      }
      else {
        $temp_html .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
          <input type="$fields[0]" name="$field"
            size="$fields[1]" value="$r_in->{$field}">
        </td>
        </tr>
      	~;
			}
    }
    elsif ($fields[0] eq "password" && $r_local->{'auth'}->{'Register Via EMail'} ne "on") {

      $temp_html .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
          <input type="$fields[0]" name="$field"
            size="$fields[1]" value="$r_in->{$field}">
        </td>
        </tr>~;

      if ($r_in->{'sub_action'} eq 'modify') {

        $temp_html .= qq~
          <tr>
          <th align="right" valign="top">$field again$suffix</th>
          <td>
            <input type="$fields[0]" name="dup_$field" 
              size="$fields[1]" value="$r_in->{$field}">
          </td>
          </tr>
        ~;

      }
      else {

        $temp_html .= qq~
          <tr>
          <th align="right" valign="top">$field again$suffix</th>
          <td>
            <input type="$fields[0]" name="dup_$field"
              size="$fields[1]" value="$r_in->{"dup_" . $field}">
          </td>
          </tr>
        ~;

      }
    }
    elsif ($fields[0] eq "hidden") {

      if ($field eq 'Password') {
        $temp_html .= qq~
        <tr>
        <td>
          <input type="$fields[0]" name="$field" value="$fields[1]">
          <input type="$fields[0]" name="dup_$field" value="$fields[1]">
        </td>
        </tr>
        ~;
      }
      else {
        $temp_html .= qq~
        <tr>
        <td>
          <input type="$fields[0]" name="$field" value="$fields[1]">
        </td>
        </tr>
        ~;
      }
    }
    elsif ($fields[0] eq "radio" || $fields[0] eq "checkbox") {
      
      $temp_html .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
      ~;
      my $type = $fields[0];

      shift(@fields);

      foreach (@fields) {
        if ($_ eq $r_in->{$field}) {
          $temp_html .= qq~
          <input type="$type" name="$field" value="$_" checked>$_
          ~;
        }
        else {
          $temp_html .= qq~
          <input type="$type" name="$field" value="$_" >$_
          ~;
        }
      }

      $temp_html .= qq~
        </td>
        </tr>
      ~;
    }
    
    if ($fields[0] eq "select") {
      
      $temp_html .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
        <select name="$field">
      ~;
      shift(@fields);

      foreach (@fields) {
        if ($_ eq $r_in->{$field}) {
          $temp_html .= qq~
          <option value="$_" selected>$_
          ~;
        }
        else {
          $temp_html .= qq~
          <option value="$_">$_
          ~;        
        }
      }
      $temp_html .= qq~
        </select>
        </td>
        </tr>
      ~;
    }
    
    if ($fields[0] eq "textarea") {
      
      $temp_html .= qq~
        <tr>
        <th align="right" valign="top">$field$suffix</th>
        <td>
          <textarea name="$field" rows="$fields[1]" 
          cols="$fields[2]" wrap="physical">$r_in->{$field}</textarea>
        </td>
        </tr>
      ~;
    }

  }

  $html_output .= qq~
    $temp_html
        <tr>
        <th>&nbsp;
        <input type="hidden" name="required" value="$temp{'required'}"></th>
        <td>
          <input type="submit" value="Submit Registration">
          <input type="reset" value="Reset">
        </td>
        </tr>
  </table>
  </form>
~;

}


###
#
# subroutine display_logon
# Displays logon page
#
###


sub display_logon {

  my ($r_in,$r_local) = @_;

  # First print form tags

  my $html_output .= qq~
  <form action="$r_local->{'thisurl'}" method="post">
  <input type="hidden" name="dc_action" value="login">
  ~;
   
  $html_output .= qq~
  <table border="0" align="center" width="100%">
  <tr>
    <th align="right">Username:</th>
    <td><input type="text" name="Username" width="40"></td>
  </tr>
  <tr>
    <th align="right">Password:</th>
    <td><input type="password" name="Password" width="40"></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><font size="-1">
      Remember Your Password? <input type="checkbox" name="remember" value="YES">
		</font></td>
  </tr>
  <tr>
    <td>
    &nbsp;
    </td>
    <td align="left">
      <input type="submit" name="login" value="Login">
  ~;

  if ($r_local->{'auth'}->{'Allow Users to Register'} eq 'on') {
    $html_output .= qq~
      <input type="submit" name="Register" value="Register">
    ~;
  }
  
  $html_output .= qq~
    </td></tr>
  </table>
  </form>
~;

}


################################################################
#
# subroutine register
# Completes the registration process
#
################################################################

sub register {

  my ($r_in,$r_local) = @_;
  my ($error);

  # Get record according to the Username

	unless ($r_in->{'Password'} eq $r_in->{'dup_Password'}) {
  	  $error = "Passwords are not same";
    	return $error;
  }
	
  $error = check_dup_user($r_in,$r_local);

  if ($error) {
    return $error;
  }
  else {

		# OK, we can now register the user and update the database

    foreach (@{$r_local->{'fields'}}) {

      if ($_ eq "Password") {

				# Following code is from Selena Sol's authentication script
				# This is to keep file format intact

        srand(time|$$);
        my $salt = "";
        my $random = "abcdefghijklmnopqrstuvwxyz1234567890";
        for (1..2) {
          $salt .= substr($random,int(rand(36)),1);
        }
        $r_in->{$_} = my_crypt($r_in->{$_},$salt);

      }
			elsif ($_ eq "Group") {

  			unless (-s $r_local->{'password_file'} > 0) {
    			$r_in->{$_} = 'admin';
  			}
				else {

					if ($r_in->{'sub_action'} eq 'new_user') {
						$r_in->{$_} = $r_in->{'Group'};
					}
					else {
						$r_in->{$_} = $r_local->{'auth'}->{'Default Group'};
					}

				} #End of unless

			}
			elsif ($_ eq "Status") {
				$r_in->{$_} = $r_local->{'auth'}->{'Activate User on Register'};
			}
			elsif ($_ eq "EMail") {
				$r_in->{$_} = add_antispam($r_in->{$_});
			}
      	push(@line,$r_in->{$_});
    	}
  
    	$line = join("\|",@line);
    	appenddata($r_local->{'password_file'},$line);
		}

	if ($r_local->{'auth'}->{'Register Via EMail'} eq "on") {
		# sendmail here
	}

  return;

}

###
### subroutine update_user
###


sub update_user {

  my ($r_in,$r_local) = @_;
  my ($error);
  my $r_data = readdata($r_local->{'password_file'});

  unless ($r_in->{'Password'} eq $r_in->{'dup_Password'}) {
    $error = "Passwords are not same";
    return $error;
  }

  my @new_data;


  foreach (@$r_data) {

    chomp;
    my $r_entry = [ split(/\|/,$_) ];
		
    if ($r_entry->[$r_local->{'login_fields'}->{'Username'}] eq $r_in->{'Username'}) {

      foreach (@{$r_local->{'fields'}}) {

        if ($_ eq 'Password') {

          if ($r_in->{$_} ne $r_entry->[$r_local->{'login_fields'}->{$_}] ) {

            srand(time|$$);
            my $salt = "";
            my $random = "abcdefghijklmnopqrstuvwxyz1234567890";

            for (1..2) {
              $salt .= substr($random,int(rand(36)),1);
            }

            $r_in->{$_} = my_crypt($r_in->{$_},$salt);

          }
        }
				elsif ($_ eq "EMail") {
					$r_in->{$_} =~ s/[REMOVE_THIS]+//;
					$r_in->{$_} = add_antispam($r_in->{$_});
				}

        push(@line,$r_in->{$_});

      } #End of Foreach

      $line = join("\|",@line);
      $line .= "\n";

    }
    else {
      $line = "$_\n";
    }

    push(@new_data,$line);

  }

  writedata($r_local->{'password_file'},\@new_data);

# next update *.session file

	my @temp_array;

  foreach (keys %{ $r_local->{'login_fields'} }) {
		unless ($_ eq "Password") {
			my $temp_string = join ("::",$_,$r_in->{$_});
       		push(@temp_array,"$temp_string\n");
		}
  }
			
# Create session file

	writedata_nolock("$r_in->{'datadir'}/$r_in->{'session'}\.session",\@temp_array);

  return 0;

}


####
#
# subroutine check_password
#
###

sub check_password {

  my ($r_in,$r_local) = @_;
  my ($error);
	my ($orig_username, $orig_password, $test_password);

  # Get record according to the Username
  # This sets $r_local->{'login_info'}
  
  get_login_data($r_local->{'password_file'},$r_in->{'Username'},$r_local);

  $orig_username = $r_local->{'login_info'}->{'Username'};
  $orig_password = $r_local->{'login_info'}->{'Password'};

  $test_password = 
    my_crypt($r_in->{'Password'},$orig_password);

  if (!$orig_username) {
    $error = "Incorrect Username";
    return $error;
  }
  elsif ($orig_password ne $test_password) {
    $error = "Incorrect Password";
    return $error;
  }
  elsif ($r_local->{'login_info'}->{'Status'} ne "on") {
    $error = "Your account is not activated";
    return $error;
  }
  else {   
    foreach (@{$r_local->{'fields'}}) {
      $r_in->{$_} = 
        $r_local->{'login_info'}->{$_};
    }
  }
}


###
### subroutine get_login_data
### Read in all the username and password
### Then, pull off the record that matches
### Input username
###

sub get_login_data {

  my ($password_file,$username,$r_local) = @_;
  my $r_data = readdata($password_file);

  foreach (@$r_data) {
    chomp;
    my $r_entry = [ split(/\|/,$_) ];

    if ($r_entry->[$r_local->{'login_fields'}->{'Username'}] 
            eq $username) {
      foreach (keys %{ $r_local->{'login_fields'} }) {
        $r_local->{'login_info'}->{$_} = 
				$r_entry->[$r_local->{'login_fields'}->{$_}];
      }
    }
  }

}

###
### subroutine check_dup_user
### Read in all the username and password
### Then, pull off the record that matches
### Input username
###

sub check_dup_user {

  my ($r_in,$r_local) = @_;
  my $r_data = readdata($r_local->{'password_file'});
  my $status;

  foreach (@$r_data) {
    chomp;
    my $r_entry = [ split(/\|/,$_) ];

    if ($r_entry->[$r_local->{'login_fields'}->{'Username'}] 
            eq $r_in->{'Username'}) {
        $status = "dup_user";
        return $status;
    }
  }
}


###
### subroutine get_user_list
### Read in all the username and password
### Used for user management
###

sub get_user_list {

  my ($r_in,$r_local,$status) = @_;

  my $r_data = readdata($r_local->{'password_file'});

  foreach (@$r_data) {
    chomp;
    my $r_entry = [ split(/\|/,$_) ];
    
    if ($status ne "" &&
      $r_entry->[$r_local->{'login_fields'}->{'Status'}] eq $status) {

      if ($r_in->{'user'} eq 'all') {
        push( @{$r_local->{'user_list'} }, $r_entry);
      }
      else {
        if ($r_entry->[$r_local->{'login_fields'}->{'Username'}]
            =~ /^$r_in->{'user'}/i) {

          push( @{$r_local->{'user_list'} }, $r_entry);
        }
      }
    }
    elsif ($status eq "") {

      if ($r_in->{'user'} eq 'all') {
        push( @{$r_local->{'user_list'} }, $r_entry);
      }
      else {
        if ($r_entry->[$r_local->{'login_fields'}->{'Username'}]
            =~ /^$r_in->{'user'}/i) {
            
          push( @{$r_local->{'user_list'} }, $r_entry);
        }
      }

    }#End of if ($status...

  }#End of foreach
}

#####
#
# subroutine check_group
#
#####

sub check_group {

  my ($r_in,$r_local,$group) = @_;

  my ($heading,$sub_heading,$html_outout);

  if ($r_local->{'login_info'}->{'Group'} ne $group) {
    $heading = "DCProtect98 User Manager";
    $sub_heading = "Error--Wrong User Group";
    $html_output .= qq~
   <h4 align="center">
   You must be an administrator to manager users.
    </h4>
   ~;
   
    $html_output .= display_logon($r_in,$r_local);

    my %namespace = (
      HEADER => $heading,
      SUBHEADER => $sub_heading,
      HTMLOUTPUT => $html_output );

    display_output($templatefile,\%namespace); 
    exit;
  }

  return;
}

###
### subroutine get_user_login_data
### Read in all the username and password
### Then, pull off the record that matches
### Input username
###

sub get_userdata {

  my ($session_file,$r_local) = @_;
  my $r_data = readdata_nolock($session_file);

  foreach (@{$r_data}) {
    chomp;
		($key,$value) = split(/::/,$_);
		$r_local->{'login_info'}->{$key} = $value;
  }

	return $r_local->{'login_info'};
}

#####
#
# Subroutine get_session_id
# Generates session ID for a User.
# This portion of code from Selena and Gunther's
# auth-extra-lib.pl
#
####


sub get_session_id {

	my ($session, $session_file);

	# Seed the random generator
	srand($$|time);
	$session = int(rand(60000));

	# pack the time, process id, and random $session into a
	# hex number which will make up the session id.

	$session = unpack("H*", pack("Nnn", time, $$, $session));

} # End of MakeSessionFile


1;
