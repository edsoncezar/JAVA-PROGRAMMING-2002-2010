# DCShop Electronic Shopping Cart Script
# 
#
# Copyright  �1997-1998 DCScripts All Rights Reserved
# As part of the installation process, you will be asked
# to accept the terms of this Agreement. This Agreement is
# a legal contract, which specifies the terms of the license
# and warranty limitation between you and DCScripts and DCShop.
# You should carefully read the following terms and conditions before
# installing or using this software.  Unless you have a different license
# agreement obtained from DCScripts, installation or use of this software
# indicates your acceptance of the license and warranty limitation terms
# contained in this Agreement. If you do not agree to the terms of this
# Agreement, promptly delete and destroy all copies of the Software.
# 
# LICENSE TO REDISTRIBUTE
# Distributing the software and/or documentation with other products
# (commercial or otherwise) or by other than electronic means without
# DCScripts's prior written permission is forbidden.
# All rights to the DCShop software and documentation not expressly
# granted under this Agreement are reserved to DCScripts.
#
# DISCLAIMER OF WARRENTY
# THIS SOFTWARE AND ACCOMPANYING DOCUMENTATION ARE PROVIDED "AS IS" AND
# WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER
# WARRANTIES WHETHER EXPRESSED OR IMPLIED.   BECAUSE OF THE VARIOUS HARDWARE
# AND SOFTWARE ENVIRONMENTS INTO WHICH DCSHOP MAY BE USED, NO WARRANTY OF
# FITNESS FOR A PARTICULAR PURPOSE IS OFFERED.  THE USER MUST ASSUME THE
# ENTIRE RISK OF USING THIS PROGRAM.  ANY LIABILITY OF DCSCRIPTS WILL BE
# LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE.
# IN NO CASE SHALL DCSCRIPTS BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR
# CONSEQUENTIAL DAMAGES OR LOSS, INCLUDING, WITHOUT LIMITATION, LOST PROFITS
# OR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, WHETHER SUCH DAMAGES ARE
# BASED UPON A BREACH OF EXPRESS OR IMPLIED WARRANTIES, BREACH OF CONTRACT,
# NEGLIGENCE, STRICT TORT, OR ANY OTHER LEGAL THEORY. THIS IS TRUE EVEN IF
# DCSCRIPTS IS ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO CASE WILL
# DCSCRIPTS LIABILITY EXCEED THE AMOUNT OF THE LICENSE FEE ACTUALLY PAID
# BY LICENSEE TO DCSCRIPTS. 
#
# Revisions:
#
# 29 Dec 1998 DCShop Ver 1.002 Update
#   - Added blatmail function for NT servers
# 20 Dec 1998 DCShop Ver 1.001 Beta release
#   - Options added for items - also can keep track of additional cost
#   - Rewrote dcshop_checkout.cgi
#       - When the user completes an order, the cart is saved in Orders directory
#   - Created dcshop_admin.cgi - administration for the shopping cart program
#       - Implement View Orders
#       - Added dcprotect to password protect it
# 12 June 1998 DCShop Ver 1.0 (called DCShop98) Beta release
#   - Due to major limitations, never distributed.
#
###########################################################################

DCShop is an electronic shopping cart program brought to you by
DCScripts, the same folks who brought you DCGuest, DCLinks, and DCForum.

DCShop uses flat, text-delimited database files to store different products.
It consists of three scripts: dcshop.cgi, dcshop_checkout.cgi, and dcshop_admin.cgi.

This beta release version lacks some features that will be added to the dcshop_admin,
such as the ability to modify product database online.  However, it is fully
functional shopping cart program that will meet most demanding E-Commerce sites.

As is with all beta testings, we would love your feedbacks and bug reports.
Please report them to the DCShop forum at

http://www.sitedeveloper.com/cgi-bin/dcforum97n/dcboard97.cgi

Thank you for checking out DCShop - I'm sure you will enjoy this
awesome shopping cart script! :-)


David S. Choi
Lead Developer
DCScripts
dc@dcscripts.com

-------------------------------------------------------------------
Table of contents:

0. Requirements
1. Files
2. Installation and Customization
3. Setting up your product database
4. Using the administration script
-------------------------------------------------------------------
0. Requirements

   DCShop requires:
   - Perl 5.001 or higher.
   - cgi-bin access
   
   Plus...
   - Secure server for accepting credit cards
   
   Current limitation:
   
      You must have secure server access on the same server as your cgi-bin.
      Typically, the cgi scripts are placed in the same directory but
      different URL is used to access it.  For example, you may have both
      dcshop.cgi and dcshop_checkout.cgi in the same directory, but you access
      dcshop.cgi via:
      
      http://www.yourdomain.com/cgi-bin/DCShop/dcshop.cgi
      
      while you access dcshop_checkout.cgi via:
      
      https://somesecuredomain.com/your_username/cgi-bin/DCShop/dcshop_checkout.cgi
      
      You can also place dcshop_checkout.cgi in different directories, provided that
      you correctly define pertinent parameters in the setup files.  This is rather
      more involved but possible.  Take a look at example setup at:

      http://www.tiac.net/users/dchoi/cgi-bin/DCShop

      and 

      http://www.tiac.net/users/dchoi/secure/cgi-bin

      I've left the directory listing viewable so that you can look at the setup file.
      Following installation assumes that you'll be installing all three cgi scripts
      in the same directory.
   
-------------------------------------------------------------------
1. Files

   DCShop contains following files:

   - readme.txt - this file
   - dcshop.cgi - main shopping cart program
   - dcshop.setup - setup file for dcshop system
   - dcshop_checkout.cgi - checkout program - should be used on secure
      server
   - dcshop_checkout.setup - setup file for checkout script
   - dcshop_admin.cgi - administration script - should be used on secure
      server
   - dcshop_admin.setup - setup file for admin script
   - dcshop.htmlt - template file for customizing the output
   - dclib.pl - library files
   - cgi-lib.pl - perl library
   - dcprotect.pl - authentication script used by dcshop_admin.cgi
   - Three example product setup and txt file - Please use these to
     first setup your shopping cart.  You can check Section 3 for more
     information on how to setup your product database file.

-------------------------------------------------------------------
2. Installation and Customization

   a. General overview of the setup

      Typically, you would use FTP to upload DCShop to your web site.
      Following is the recommended setup:
      
      /secure
          |--- /DCShop
                   |--- /Images
                           |--- Your Image files
      
      /htdocs
          |--- /DCShop
                   |--- /Images
                           |--- Your Image files
      
      /cgi-bin
          |--- /DCShop
                   |--- /Auth_data (777)
                   |--- /Data (777)
                           |--- *.setup and *.txt files
                   |--- /Orders (777)
                   |--- /User_carts (777)
                   |--- dcshop.cgi (755)
                   |--- dcshop.setup (644)
                   |--- dcshop.htmlt (644)
                   |--- dclib.pl (644)
                   |--- cgi-lib.pl (644)
                   |--- dcprotect.pl (644)
                   |--- dcshop_checkout.cgi (755)
                   |--- dcshop_checkout.setup (644)
                   |--- dcshop_admin.cgi (755)
                   |--- dcshop_admin.setup (644)
      
      NOTE: If you are using image files on pages accessed via the secure channel,
      then those images must reside in your secure directory 
      and call via <img src="https://...etc"> instead of <img src="http://...etc">.
   
   b. Setup DCShop secure directory

      - In your secure directory, create a subdirectory named 'DCShop'.
      - Change directory to this new directory.
      - Create a directory named 'Images'
      - Upload your image files to this subdirectory ("/secure/DCShop/Images")
        NOTE: For image files, you must use BINARY mode when you use FTP.
   
   c. Setup DCShop html directory

      - In your html directory, create a subdirectory named 'DCShop'.
      - Change directory to this new directory.
      - Upload any DCShop related HTML page (ones that you created) to this
        directory.  This step not necessary if all your files in your root HTML directory.
      - Create a directory named 'Images'
      - Upload your image files to this subdirectory ("/htdocs/DCShop/Images")
        NOTE: For image files, you must use BINARY mode when you use FTP.
    
   d. Setup DCShop cgi-bin directory
   
      - In your cgi-bin directory, create a subdirectory named 'DCShop'
      - Change directory to DCShop
      - Create subdirectories 'Auth_data','Data', 'Orders', and 
        'User_carts' - NOTE: These names are case sensitive.
      - Change permissions of these directories to 777.
      - Change directory to 'Data' directory.
      - Upload hardware.setup, hardware.txt, pens.setup, pens.txt, products.setup,
        and products.txt to this directory.  MAKE SURE TO USE ASCII MODE WHEN
        YOU UPLOAD THESE FILES.

   e. Edit dcshop.cgi, dcshop_checkout.cgi, and dcshop_admin.cgi

      - Edit first line of these scripts to reflect location of PERL 5
        on your server.  That is, change
      
        #!/usr/bin/perl
      
        to the correct location of PERL 5.
      
      - Edit $path variable.  This variable holds the directory path to
        your /cgi-bin/DCShop directory.  Typically, current directory
      
        $path = ".";
        
        will work.  If not, use absolute path.
        
        IMPORTANT: In somecases when you install scripts different directories, you
        may need to specify correct path to each files defined in
        'require' statements.

   f. Edit dcshop.setup
   
      You will need to edit just about every variable in this setup file
      Please refer this setup file.  Take a look at dcshop_example_NT.setup
      or dcshop_example_UNIX.setup, included in this zip file.
   
   g. Edit dcshop_admin.setup - for using dcprotect

      You will need to edit just about every variable in this setup file
      Please refer this setup file.
   
   h. Edit dcshop_checkout.setup

      You will need to edit just about every variable in this setup file
      Please refer this setup file. NOTE: You don't need to edit this
      setup file to get dcshop working.  You may want to edit it at later time
   
   i. Upload all the file to /cgi-bin/DCShop and set their permission
      as shown:
      
         dcshop.cgi (755)
         dcshop.setup (644)
         dcshop.htmlt (644)
         dclib.pl (644)
         cgi-lib.pl (644)
         dcprotect.pl (644)
         dcshop_checkout.cgi (755)
         dcshop_checkout.setup (644)
         dcshop_admin.cgi (755)
         dcshop_admin.setup (644)

      NOTE: YOU MUST USE ASCII MODE WHEN YOU USE YOUR FTP PROGRAM
      TO UPLOAD THESE FILE...THIS IS VERY IMPORTANT

   j. Customize output by editing dcshop.htmlt - this file is just
      an HTML file except that it is given htmlt extension.
      Be careful not to remove some TAGS denoted by a "$" sign
      followed by TAG name in CAPITAL letters (e.g., $HEADER).
      DO THIS STEP WHEN YOU HAVE DCSHOP UP AND RUNNING.
      
-------------------------------------------------------------------
3. Setting up your product database

   Each product listing (containing various categories) require
   a setup file.  As an example, we will use pens.setup and pens.txt
   file.
   
   a. pens.setup file - You can refer to this file for more info.
      In this file, you need to define various parameters.  These are:

      - @link_fields holds the fields for records.  At minimum, you need
        ID, Name, Category, Description, Price, and Taxable.

         ID - product ID
         Name - Product Name
         Category - numerical ID (0,1,2...) for categories...you define
            categories in @category, %category_list, and %category_desc in
            this setup file (see below).
         Description - product description
         Price - Price
         Taxable - 0 if not taxable, 1 if taxable

         Additionally, you can add other fields.  You can add optional
         fields by prefixing with 'OPT_'.  For example, OPT_Color is
         and option for colors.  For pens.setup, we have:
   
         @link_fields = qw(ID Name Category Description Image
               OPT_Color OPT_Style Price Taxable);

         See Section (b) of this file on how to specify options with
         extra pricing.

      - $product_id and $cat_id - element location of product ID and category
        NOTE: Perl array starts with element 0.

      - $print_fields - layout for product view.  You can change this HTML
         code to change the look of product view page.  Note that each field will
         be inserted in <!--%FIELD_NAME%--> Tag.  <!--%Cart%--> and <!--%Quantity%-->
         are additional tags that you should leave it in there.

      - Define @category, %category_list, and %category_desc.

   b. pens.txt - format for product database file.
      In practice, you may keep your product database file on your PC,
      using some database package.  You can update your products on your PC, then
      export it to *.txt files for each product listing.
      
      These database files should be text delimited using "|" pipe sign.
      The first line must contain the field names
      
      For example, in pens.txt, we have

      ID|Name|Category|Description|Image|OPT_Color|OPT_Style|Price|Taxable
      20001|Waterman Laureat II Series|0|New i...rantee|pens.gif|Red,Blue::2.00,Green,Black|English Tea,American Eagle,Slim Asian::4.00|44.95|1

      NOTE: Image field only holds the image name.  This image must be in
      the directory corresponding to $imgurl
      
      NOTE: Optional values are comma delimited.  Those options that costs extra, you
      append the extra price to the option using "::".  For example:
      
      Red,Blue::2.00,Green,Black
      
      Here, Blue option costs extra $2.00.
-------------------------------------------------------------------
4. Using the administration script

   dcshop_admin.cgi uses cookies to store session ID.  Please be sure your
   cookies are enable on your browser.
   
   The first time you bring up dcshop_admin.cgi, you will get loggin window.
   Click on 'Register' and register yourself as the administrator.
   
   After you register, logon and the main menu should pop up.  Choose
   'Change Configuration Setting'.  Then, turn off 'Allow Users to register'.
   
   The only available feature is 'View Orders' - using this you can track
   your orders.
   
   You can also download orders.txt from Orders directory and import it into your
   database.
   
   Our future release will include a more comprehensive administration script.

-------------------------------------------------------------------

Contacting DCScripts should there be problems during installation

   You can use DCShop dcforum at http://www.sitedeveloper.com/cgi-bin/dcforum97n/dcboard97.cgi 

------------------------------------------------------------------------
�1997-1998 DCScripts, All rights Reserved 