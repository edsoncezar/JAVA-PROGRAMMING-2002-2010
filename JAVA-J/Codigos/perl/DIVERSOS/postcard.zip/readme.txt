
CGI Programming by Collin Forbes
--------------------------------
    Postcards 2.5, released 20 April 2000.

    Copyright Collin Forbes, 2000. All rights reserved.
    This program is free software; you can redistribute it and/or modify
    it under the same terms as Perl itself ( the "Artistic License" ).

Summary:
--------
    Distribute digital greeting cards of a different breed.  This program
    encodes the postcard message directly into the image and sends it to
    the recipient as a file attachment.

Version History:
----------------
    * Version 2.5, released 16 April 2000
      Many changes: new configuration, new image handling, 
      new template handling, and rewritten documentation
    * Version 2.3 - 2.4
      Private releases.
    * Version 2.2, released December 1996
    * Version 2.0, released September 1996
    * Version 1.0, released April 1996

See Also:
---------
    * http://kuoi.asui.uidaho.edu/~collinf/scripts.html/postcards
    * local documentation

