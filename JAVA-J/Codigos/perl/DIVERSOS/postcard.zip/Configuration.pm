# ----------------------------------------------------------------------
#
# Configuration.pm
#    --	a perl object to easily read Windows-style configuration and
#	initialization files.
#
# Copyright Collin Forbes 1999.  All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
#
# ----------------------------------------------------------------------
package Configuration;
use strict;
# ----------------------------------------------------------------------

sub initialize {
#
# initialize the Configuration object
#
    my $class = shift;
    my $filename = shift;
    my $self = {};
    bless( $self, $class );

    $self->_parse_configuration( $filename ) if $filename;
    return $self;
}

# ----------------------------------------------------------------------

sub value {
#
# returns the value for the named item in the given section
#
    my $self = shift;
    my( $section, $name ) = @_;

    if ( wantarray ) {
	return () unless $self->{'config'}{ $section };
	return () unless $self->{'config'}{ $section }{ $name };
	return @{$self->{'config'}{ $section }{ $name }};
    }
    else {
	return undef unless $self->{'config'}{ $section };
	return undef unless $self->{'config'}{ $section }{ $name };
	return $self->{'config'}{ $section }{ $name }[0];
    }
}

# ----------------------------------------------------------------------

sub sections {
#
# returns a list of the section names in order which they appeared 
#
    my $self = shift;
    my %order = %{$self->{'section-order'}};
    return sort { $order{ $a } <=> $order{ $b } } keys %order;
}

# ----------------------------------------------------------------------

sub names {
#
# returns a list of names in the given section, in the order they appear
#
    my $self = shift;
    my( $section ) = @_;
    my %order = %{$self->{'order'}{ $section }} if $self->{'order'}{ $section };
    return sort { $order{ $a } <=> $order{ $b } } keys %order;
}

# ----------------------------------------------------------------------

sub last_modified {
#
# returns the time (unix seconds) the configuration file was last modified
#
    my $self = shift;
    return $self->{'last-modified'};
}

# ----------------------------------------------------------------------

sub _parse_configuration {
#
# read the configuration file and parse it into the configuration hashes
#
    my $self = shift;
    my( $filename ) = @_;

    if ( !-e $filename ) {
	$self->set_errstr( qq|"$filename" does not exist!| );
	return;
    }

    $self->{'last-modified'} = time - int((-M $filename) * ( 24 * 60 * 60 ));

    my $nick; my $count = 0; my $subcount = 0;
    open( FILE, "<$filename" ) || $self->set_errstr( "opening $filename, $!" );
    while(<FILE>) {
	chomp; s/\x0d//s;		# 'chomp' newlines and carriage returns
        next if /^\s*#/;		# skip '#' comment lines
        next if /^\s*;/;		# skip ';' comment lines

        if ( /^\s*\[(.+)\]\s*$/ ) {	# the first line of a new stanza
	    if ( $nick ) { $self->{'section-order'}{ $nick } = $count; }
	    $nick = $1;
	    $count++;
	    $subcount = 0;
	}
        elsif ( /=/ ) {			# probably a name/value pair
	    my( $name, $value );
	    if ( /(.+?)=(.*)$/ ) { $name = $1; $value = $2; }
	    next if $value eq '';

	    my $item;
            foreach $item ( $name, $value ) {
                $item =~ s|^\s+||; 	# trim whitespace at beginning
		$item =~ s|\s+$||;	# trim whitespace at ending
                $item =~ s|^"||; 	# trim unescaped quote at beginning
		$item =~ s|(?<!\\)"$||;	# trim unescaped quote at ending
            }

	    # keep the values as a list reference so we can have multiples
	    if ( $self->{'config'}{ $nick }{ $name } ) {
		push( @{$self->{'config'}{ $nick }{ $name }}, $value );
	    }
	    else {
		$self->{'config'}{ $nick }{ $name } = [ $value ];
		$self->{'order'}{ $nick }{ $name } = $subcount;
	    }
	    $subcount++;
        }
    }
    close( FILE );

    $self->{'section-order'}{ $nick } = $count if $nick;
}

# ----------------------------------------------------------------------

sub set_errstr {
#
# sets the error string to a specific value
#
    my $self = shift;
    my( $string ) = @_;

    $self->{'errstr'} = $string;
}

# ----------------------------------------------------------------------

sub errstr {
#
# returns the current value of the error string
#
    my $self = shift;
    return $self->{'errstr'};
}

# ----------------------------------------------------------------------
1;
