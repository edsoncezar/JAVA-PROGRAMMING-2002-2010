# ----------------------------------------------------------------------
#
# Template.pm
#    -- a lightweight perl object to read, parse and merge text templates.
#
# Copyright Collin Forbes, 2000.  All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
#
# ----------------------------------------------------------------------
package Template;
use strict;
# ----------------------------------------------------------------------

sub initialize {
#
# a constructor to initialize the Template object using a file
#
    my( $proto, $file ) = @_;
    my $class = ref( $proto ) || $proto;
    my $self = {};
    bless( $self, $class );

    $self->{'token'} = {};
    $self->set_errstr( 'uninitialized' );
    $self->{'template'} = $self->_open( $file ) if defined $file;
    $self->set_errstr( undef ) if $self->{'template'};

    return $self;
}

# ----------------------------------------------------------------------

sub start {
#
# a second constructor to initialize the Template object using the given text
#
    my( $proto, $text ) = @_;
    my $class = ref( $proto ) || $proto;
    my $self = {};
    bless( $self, $class );

    $self->{'token'} = {};
    $self->{'template'} = $text;

    return $self;
}

# ----------------------------------------------------------------------

sub token {
#
# with one argument, returns the value for the specified token.
# with two arguments, assigns the given value to the specified token.
# with three arguments, chomps a newline off the value assigned to the token
#
    my $self = shift;
    my( $token, $value, $newline ) = @_;
    return undef unless defined $token;		# no auto-vivification
    chomp $value if defined $newline;		# drop the trailing newline

    # if there's a value, assign it to the specified token
    if ( defined $value ) { $self->{'token'}{$token} = $value; }

    # then return the token's value
    if ( defined $self->{'token'}{$token} ) { return $self->{'token'}{$token}; }
    else { return undef; }
}

# ----------------------------------------------------------------------

sub merge {
#
# merge the tokens with the template
#
    my $self = shift;

    my $t = $self->{'token'};
    my $merger = $self->{'template'};

    # trim any NOTES comments from the template
    $merger =~ s/<!--\s*NOTES.*?-->//sg; 

    my @patterns = (    '%%TOKEN\(?([\w\-\.]+)\)?%%',
                        '<!-+\s*#?TOKEN\s*\(?([\w\-\.]+)\)?\s*-+>'      );

    foreach my $pat ( @patterns ) {
	$merger =~ s/(?<!\\)$pat/$t->{ $1 } if defined $t->{ $1 }/egs;
	$merger =~ s/\\($pat)/$1/gs;
    }

    return $merger;
}

# ----------------------------------------------------------------------

sub template {
#
# returns the unmerged text of the raw template
#
    my $self = shift;
    return $self->{'template'};
}

# ----------------------------------------------------------------------

sub set_template {
#
# replaces the existing template text with the given text
#
    my $self = shift;
    my $text = shift;

    $self->{'template'} = $text;
}

# ----------------------------------------------------------------------

sub count {
#
# returns the number of different tokens in the template 
#
    my $self = shift;
    my $template = $self->{'template'};

    my @patterns = (	'%+TOKEN\(?([\w\-\.]+)\)?%+',
			'<!-+\s*#?TOKEN\s*\(?([\w\-\.]+)\)?\s*-+>'	);

    my %markers;
    foreach my $pat ( @patterns ) {
	while ( $template =~ s/$pat//s ) { $markers{ $1 } = 1; }
    }

    return scalar( keys %markers );
}

# ----------------------------------------------------------------------

sub identifiers {
#
# returns a list of unique token identifiers found in the template
#
    my $self = shift;
    my $template = $self->{'template'};

    my @patterns = (    '%+TOKEN\(?([\w\-\.]+)\)?%+', 
                        '<!-+\s*#?TOKEN\s*\(?([\w\-\.]+)\)?\s*-+>'    );

    my %markers;
    foreach my $pat ( @patterns ) {
        while ( $template =~ s/$pat//s ) { $markers{ $1 } = 1; }
    }

    return ( keys %markers );
}

# ----------------------------------------------------------------------

sub errstr {
#
# returns the current error string.
#
    my $self = shift;
    return $self->{'errstr'};
}

# ----------------------------------------------------------------------

sub set_errstr {
#
# sets the error string to that value.
#
    my $self = shift;
    my $value = shift;

    $self->{'errstr'} = $value;
}

# ----------------------------------------------------------------------

sub _open {
#
# reads the specified file into memory and returns it
#
    my $self = shift;
    my $filename = shift;

    open( FILE, $filename ) or do { $self->set_errstr( $! ); return undef; };
    return join( '', <FILE> );
}

# ----------------------------------------------------------------------
1;	# do not taunt happy fun require
