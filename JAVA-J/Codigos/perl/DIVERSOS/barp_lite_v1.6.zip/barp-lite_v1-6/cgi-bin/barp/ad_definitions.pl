#!/usr/bin/perl

#########################################################
# iMarc Banner Ad Rotation Program                      #
#                                                       #
#       version                   1.6                   #
#       created                   03.01.1999            #
#       modified                  04.39.2002            #
#                                                       #
# http://www.imarc.net                                  #
# dave@imarc.net                                        #
#########################################################
#       sell out!                 options script        #
#########################################################


#########################################################
# VARIABLES: used by ad_display.pl and ad_redirect.pl
#########################################################


###########################
# General Configuration
###########################
$site_url        = "http://dave.imarc.net";      # The base URL of your site
$site_path       = "/usr/local/www/dave";        # The full path to your site's directory
$ad_directory    = "$site_url/barp-files/ads";   # This is where the ads are
$log_directory   = "$site_path/barp-files/logs"; # This is where the ads are

# This should be the virtual path to the redirection script
$redirect_script = "/cgi-bin/ads/ad_redirect.pl";

# Set the Time Zone to one of the 
# Time Zone Variables, listed below
$time_zone       = $USE; # Set to one of the following"
                         # $USE for US Eastern
                         # $USP for US PACIFIC
                         # $GER for Germany

###########################
# Logging
###########################
# Should we log all ad-views?
$use_log         = "1"; # 1=YES; 0=NO
$view_log_file   = "$log_directory/ad_views.log";  # impression/ad-view log file
$click_log_file  = "$log_directory/ad_clicks.log"; # click-thru log file


###########################
# Display
###########################
# Do you want the alt text printed below the ad?
$print_alt_text  = "1"; # 1=YES; 0=NO

# If you are printing the ALT text ($printAlt = 1)
# Then you can specify a size, font, color, and/or class.
$alt_text_size   = "1";
$alt_text_face   = "Arial,Helvetica";
$alt_text_color  = "#999999";
#$alt_text_class = "";

$ad_align        = "bottom"; # Align the ad/image...
$ad_border       = "0"; # Do you want a border around the ad?



###########################
# TIME ZONES
###########################
# Time Zone Variables
$USE      =  0; ## US EASTERN
$USP      = -3; ## US PACIFIC
$GER      = +6; ## 6 hours ahead of USE (Germany)


###########################
# SUB ROUTINES
###########################

# Gets the current time
sub getTime {
	@days = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
	@months = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time + ($TimeZone * 3600));
	if ($mday < 10) { $mday = "0$mday"; }
	if ($hour < 10) { $hour = "0$hour"; }
	if ($min < 10) { $min = "0$min"; }
	if ($sec < 10) { $sec = "0$sec"; }
    $year += 1900;
  	$getTime = "\[$mday/$months[$mon]/$year:$hour\:$min\:$sec\]";
}



# Bug fix in perl
@TEST = ("test.gif");



