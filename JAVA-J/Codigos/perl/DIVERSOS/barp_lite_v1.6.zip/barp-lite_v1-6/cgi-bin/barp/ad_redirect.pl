#!/usr/bin/perl
require './ad_definitions.pl';

#########################################################
# iMarc Banner Ad Rotation Program                      #
#                                                       #
#       version                   1.6                   #
#       created                   03.01.1999            #
#       modified                  04.39.2002            #
#                                                       #
# http://www.imarc.net                                  #
# dave@imarc.net                                        #
#########################################################
#       sell out!                 options script        #
#########################################################


#####################################################
# This stuff shouldn't need to be changed           #
#####################################################

# Redirection the URL:
# The URL Should be coming into this cgi like this:
# <a href="cgi-bin/ad_redirect.pl?http://www.imarc.net/">
# Got it?

$redirect_url = $ENV{'QUERY_STRING'};
&redirectUser;
&getTime;
&logClick;


# Let's send this tool on his way...

sub redirectUser {
	print "Location: $redirect_url\n\n\n";
}


# If you're gonna log, you might as well do it here
# This will write in the same style as Apache's combined log format
# so you can analyze your log clicks with the same software as your web logs

sub logClick {
	if ($useLog eq '1') {
		open(LOG,">> $click_log_file") || die "$! \'$LOG\'";
		print LOG "$ENV{'REMOTE_ADDR'} - - $getTime \"GET /$redirect_url HTTP/1.0\" 100 100 \"$redirect_url\" \"$ENV{'HTTP_USER_AGENT'}\"\n";
		close(LOG);
	}
}

exit(0);
