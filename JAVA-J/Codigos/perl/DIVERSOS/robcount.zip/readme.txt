######################################
#                                    #
# RobCount Version 1.1               #
# Copyright 1998 by Rob Eisler       #
# rob@robplanet.com                  #
# http://www.robplanet.com           #
#                                    #
# Last modified on February 14, 1998 #
#                                    #
######################################
#
# Copyright Notice:
# Copyright 1998 Robert S. Eisler.  All Rights Reserved.
#
# This code may be used and modified by anyone so long as this header and
# copyright information remains intact.  By using this code you agree to 
# indemnify Robert S. Eisler from any liability that might arise from its 
# use.  You must obtain written consent before selling or redistributing 
# this code.
#
#####################################

Here's the deal.  There are a couple things I'd like for you to do if you're
using my scripts, although I have no way of holding you to them, and I
probably wouldn't try to if I did.

-- Please keep my name and copyright info included in this stuff.

-- Tell me you're using my script.  I like to see where my programs are
   being implemented on the web, and I'll add a link to your page on 
   mine.  You can just e-mail me, or fill out the form at 
   http://www.robplanet.com/cgi/form.html

-- If it's at all possible, I'd appreciate a link to my page from yours.
   It's no big deal, though.  You can get a link from my page by filling
   out the form as mentioned in the last point.

-- If you make an improvement to the code, please let me know.  I won't
   include the code in my future distributions if you don't want me to,
   but I'll certainly give you full credit if you do allow your code to
   be included.

-- I'm starting up a mailing list to announce updates and new programs.
   You can add/remove yourself by sending me mail or by filling out that
   same form.

-- Thanks --

If you are having trouble getting this script to work, please read through this
file carefully before e-mailing me with questions.  If you're still stuck, send
mail to rob@robplanet.com - and please include as 
much detail as you can.  I won't be able to help you if I don't know what's 
going on :).

This is version 1.1 of RobCount.  It's compatible with all earlier versions.

This script requires server side includes; you might want to contact your 
system administrator if you're not sure how your server is set up to handle SSI.

These are the files you should have:

  1.  robcount.cgi  . . . . . . the Perl script that logs visitors
  2.  readme.txt  . . . . . . . this file
  3.  robcount.txt  . . . . . . data file
  4.  dg0.gif - dg9.gif . . . . digit images


-- Some Notes --

If you want to use this as a graphical counter, you have to name the
digit images correctly.  The ten digit images must be named: 

xxxX.yyy

where xxx can be anything, X is a digit from 0-9, yyy is the file 
extension (gif, jpg...)

If you want to use text instead of images, you can leave the following
variables alone:
$digiturl, $defaultdigit, $defaultext, @digitstart, @digitext, $rgraphic

If you want to use images instead of text, you can leave the following
variables alone:
$defaultfont, $defaultcolour, @fonts, @colours, $formattext,
$rtextcolour, $rtextfont


Here's what you need to do with these files:

- Put robcount.cgi in your cgi-bin and chmod it 755.
- Upload robcount.txt and chmod it 777.


Now, you need to make a few small edits:


--- robcount.cgi ---

--- Change the first line of this file to reflect the location of the perl
    interpreter on your system.  If the interpreter is at /bin/perl, then
    this line should be #!/bin/perl.  You can get this information with the
    command "which perl" or "where perl".  Check with the system admin
    if you're not sure.

--- $data - change this to the absolute location of the robcount.txt file.

--- $digiturl - change this to the URL of the directory containing the digit
    images

--- $defaultdigit - as described above, your digit images must be named in
    the form xxxX.yyy .  Change this variable to whatever's in xxx in the
    default images.  These will be the images called if you do NOT select
    the randomize graphics option.

--- $defaultext - this is the yyy from xxxX.yyy

--- $defaultfont - this is the default font for the text counter.  This
    will be the font if you select formatted, non-randomized text.

--- $defaultcolout - this is the default font colour.

--- @digitstart - as in $defaultdigit, these are the xxx for all the
    sets of images.

--- @digitext - as in $defaultext, these are the yyy for all the sets
    of images.

--- @fonts - these are all the fonts for the randomized text

--- @colours - these are all the colours for the randomized text


--- your pages ---

Now, the last thing you have to do is call the robcount.cgi from the
pages you want to log.  Put this command on your pages wherever you
want the counter to appear:

<!--#exec cgi="xxx/robcount.cgi"-->

where xxx is the path to your cgi-bin.  This can be
a relative location; this is the command I have on one of my pages:

<!--#exec cgi="./cgi-bin/robcount.cgi"-->

NOTE:  Some systems only execute server side includes on pages ending
in .shtml .  You can check this by trying to call the program from
a page ending in another extension.  Then, load up the page off your
server and view its source.  If the above statement is visible in the
page, the SSI has not executed properly.  

You can e-mail me if you're having trouble with this command, but you 
may need to ask your system administrator how SSI's are set up on 
your server.

-------

Ok!  That should be everything you need.  Good luck!  E-mail me with 
any trouble.

-------
Rob Eisler
rob@robplanet.com
http://www.robplanet.com