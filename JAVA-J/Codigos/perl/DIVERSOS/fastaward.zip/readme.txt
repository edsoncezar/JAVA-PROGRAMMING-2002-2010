##############################################################################
# Fast Award                    Version 1.2a (Public Release #4)             #
# Copyright 1999 Jim Reardon    jim@freecenter.com                           #
# Latest Versions at:           http://www.amusive.com/scripts/              #
##############################################################################
# COPYRIGHT NOTICE                                                           #
# Copyright 1998 Jim Reardon  All Rights Reserved.                           #
#                                                                            #
# Fast Award may be used and modified free of charge by anyone so            #
# long as this copyright notice and the comments above remain intact.  By    #
# using this this code you agree to indemnify Jim Reardon from any liability #
# that might arise from it's use.                                            #
#                                                                            #
# Selling the code for this program without prior written consent is         #
# expressly forbidden.  You are not allowed to make any profit off of this   #
# program.                                                                   #
#                                                                            #
# This file can not be redistributed in any way, shape, or form              #
# without prior written consent from Jim Reardon.  If somebody wants         #
# the script, have them get it from my site.                                 #
##############################################################################

This script easily lets you maintain your own website award.  Even if you
run a quality award, you can still use this software.  It makes the
submissions simple to process, keeps an up-to-date listing of everyone
you've awarded your award, and has a built-in search engine.

File included in this script:

        1) fastaward.cgi - The main program.
        2) apply.html - Sample application form.  This will work as-is, but
                        should be customized to fit the look of your site.
        3) dupe.html - A sample HTML file shown to people that have submitted
                       their site more than once.
        4) index.html - A HTML file showing how to access FastAward's
                        features.
        5) readme.txt - This file (Installation information)
        6) email.txt - This is the text that will be sent to award winners.
                       This must be placed in your data directory!
        7) cgi-lib.pl - A library needed for this program.

TO INSTALL:

Edit fastaward.cgi and edit the variables listed.  Full
descriptions are given for each variable needed to modify.
Be sure to chmod your data directory to 777!  (See fastaward.cgi for
more information).

TO USE:

index.html gives you the proper URLs to use in order to link to FastAward's
abilities.  Here's a rundown:

   "fastaward.cgi?view=1" views a listing of all winners.
   "fastaward.cgi?search=1" brings up a search form.
   "fastaward.cgi?review=1" review/award sites.  Requires a password.
   "apply.html" is a sample application form, feel free to spruce it up
      a little!

______________________________________________________________________________
       Copyright 1998 by Jim Reardon; http://www.amusive.com/scripts/