#
# This is the database schema for acmemail sessions
#

CREATE TABLE Sessions (
  ID VARCHAR(24) NOT NULL PRIMARY KEY,
  Username TEXT NOT NULL,
  Password TEXT NOT NULL,
  Start BIGINT
);
