# Generic class for an acmemail session

package AcmemailSession::POS;

use strict;
use lib '..';
use AcmemailConf qw(dope_directory session_timeout);
use Exporter;
use Persistence::Object::Simple;
use vars qw(@ISA @EXPORT_OK);

@ISA = qw(AcmemailSession);
@EXPORT_OK = qw(create_new new expire
		username password id
	       );

# Class method, creates a new session, given a username and password
sub create_new {
  my($class, $username, $password) = @_;
  my $self = {};
  my $po = new Persistence::Object::Simple(__Dope => dope_directory()) or
    main::bye("Error creating POS session - check dope directory permissions.");
  $po->{username} = $username;
  $po->{password} = $password;
  $po->{time} = time;
  $po->commit();
  $self->{USERNAME} = $po->{username};
  $self->{PASSWORD} = $po->{password};
  $self->{TIME} = $po->{time};
  $self->{ID} = $po->{__Fn};
  $self->{PO} = $po;
  bless $self, $class;
  return $self;
}

# Class method, recreates an existing session, given a session id
# May return undef if the session does not exist or has timed out
sub new {
  my($class, $id) = @_;

  my $self = {};
  my $po = new Persistence::Object::Simple(__Fn => dope_directory() . $id) or
    main::bye("Error creating POS session - check permissions.");

  if ($po->{time} + session_timeout() < time) { # Session expired?
    $po->expire;
    undef $po;
    return;
  }
  $po->{time} = time;
  $po->commit();

  $self->{USERNAME} = $po->{username};
  $self->{PASSWORD} = $po->{password};
  $self->{TIME} = $po->{time};
  $self->{ID} = $po->{__Fn};
  $self->{PO} = $po;
  bless $self, $class;
  return $self;
}

# Object method, expires the session so that it can no longer be used
sub expire {
  my $self = shift;
  my $po = $self->{PO};
  $po->expire;
  undef $po;
  undef $self;
  return;
}

# Object method, returns the username associated with the session
sub username {
  my $self = shift;
  return $self->{USERNAME};
}

# Object method, returns the username associated with the session
sub password {
  my $self = shift;
  return $self->{PASSWORD};
}

# Object method, returns the session id associated with the session
# This should really be something which could be a directory name,
# as it is used for temporary MIME files too
sub id {
  my $self = shift;
  my $id = $self->{ID};
  $id =~ /([^\/]+)$/;
  return $1;
}


1;
