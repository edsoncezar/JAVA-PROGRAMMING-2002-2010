# Generic class for an acmemail session

package AcmemailSession::Database;

use strict;
use lib '..';
use AcmemailConf qw(session_timeout db_datasource db_username db_password);
use Exporter;
use DBI;
use MD5;
use vars qw(@ISA @EXPORT_OK);

@ISA = qw(AcmemailSession);
@EXPORT_OK = qw(create_new new expire
		username password id
	       );


# Class method, creates a new session, given a username and password
sub create_new {
  my($class, $username, $password) = @_;
  my $self = {};

  my $id = substr(MD5->hexhash(time() . {} . rand() . $$ . 'secretacmemailthing'), 0, 24);
  # should really check whether it exists already. oh well

  my $start = time;

  my $dbh = DBI->connect(db_datasource(), db_username(), db_password()) or
    main::bye("Error connecting to the database. Check the datasource, username and password.");

  my @values = ($id, $username, $password, $start);
  @values = map { $dbh->quote($_) } @values;

  my $sql = qq|insert into Sessions values (| . join(',', @values) . ")";
  my $sth = $dbh->prepare($sql);
  my $rv = $sth->execute;
  my $rc = $sth->finish;
  $dbh->disconnect;

  $self->{USERNAME} = $username;
  $self->{PASSWORD} = $password;
  $self->{TIME} = $start;
  $self->{ID} = $id;
  bless $self, $class;
  return $self;
}

# Class method, recreates an existing session, given a session id
# May return undef if the session does not exist or has timed out
sub new {
  my($class, $id) = @_;
  my $self = {};

  my $dbh = DBI->connect(db_datasource(), db_username(), db_password()) or
    main::bye("Error connecting to the database. Check the datasource, username and password.");
  my $sql = qq|select * from Sessions where ID = | . $dbh->quote($id);
  my $sth = $dbh->prepare($sql);
  my $rv = $sth->execute;
  my ($id, $username, $password, $start) = $sth->fetchrow_array;
  my $rc = $sth->finish;

  $self->{USERNAME} = $username;
  $self->{PASSWORD} = $password;
  $self->{TIME} = $start;
  $self->{ID} = $id;
  bless $self, $class;

  if ($start + session_timeout() < time) { # Session expired?
    $dbh->disconnect;
    $self->expire;
    return;
  } else {
    # update timestamp
    $start = time;
    my $sql = sprintf("update Sessions SET start = %s where ID = %s",
		      $dbh->quote($start), $dbh->quote($id));
    $dbh->do($sql);
    $self->{TIME} = $start;
    $dbh->disconnect;
    return $self;
  }
}

# Object method, expires the session so that it can no longer be used
sub expire {
  my $self = shift;
  my $id = $self->id;

  my $dbh = DBI->connect(db_datasource(), db_username(), db_password()) or
    main::bye("Error connecting to the database. Check the datasource, username and password.");
  my $sql = qq|delete from Sessions where ID = | . $dbh->quote($id);
  my $sth = $dbh->prepare($sql);
  my $rv = $sth->execute;
  my $rc = $sth->finish;
  $dbh->disconnect;
  undef $self;
  return;
}

# Object method, returns the username associated with the session
sub username {
  my $self = shift;
  return $self->{USERNAME};
}

# Object method, returns the username associated with the session
sub password {
  my $self = shift;
  return $self->{PASSWORD};
}

# Object method, returns the session id associated with the session
# This should really be something which could be a directory name,
# as it is used for temporary MIME files too
sub id {
  my $self = shift;
  return $self->{ID};
}


1;
