# The configuration file for acmemail
# All code must be valid Perl...

package AcmemailConf;

use Exporter;
use strict;
use vars qw(@ISA @EXPORT_OK);
use Carp qw(verbose);

@ISA = qw(Exporter);
@EXPORT_OK = ('image_path',
	     'smtphost',
	     'mailhost',
	     'mailhost_type',
	     'local_domain',
	     'hide_email_address',
	     'messages_in_new_window',
	     'max_messages_per_page',
	     'show_recent_messages_first',
	     'temporary_mime_directory',
	     'web_temporary_mime_directory',
	     'session_type',
	     'dope_directory',
	     'db_datasource',
	     'db_username',
	     'db_password',
	     'session_timeout',
	     'force_cookies',		# security
	     'force_nojavascript',	# security
	     'force_defang_html',	# security
	     'force_escape_html',	# security
	     'auto_add_hyperlinks',	# security
	     'encrypt_password',	# security
	     'referer_header_test',	# security
	     'acme_server_name',	# security
	     'acme_server_base',	# security
	     'secure_cookie',		# security
	     'cookie_path',		# security
	     'control_cookie_path',	# security
	     'safe_html_list',		# security
	     'control_port',		# security
	     'message_port',		# security
	     'acme_mem_parse_buffer',	# security/performance
	     'acme_anonymize_links',	# security/privacy
	     'inbox_directory',
	     'html_login',
	     'html_head',
	     'html_bottom',
	     'html_bar',
	     'html_message_bar',
	     'html_list_head',
	     'html_list_row',
	     'html_list_bottom',
	     'html_message_head',
	     'html_message_headers',
	     'html_message_bottom',
	     'html_quoted',
	     'html_signature',
	     'acme_version',
	     'acme_preferred_msg_type',
		);

#####
# Options
#####

# Encrypt passwords in the session repository?
#
# (prevents someone from reading passwords if they gain access 
#  to the session repository [though there are other ways to 
#  get the password, e.g., if you have root access, if you
#  can modify the acmemail program, if the password is sent
#  across the network in the clear and sniffed, etc.] to
#  improve security. Additional cost is roughly 0.003 seconds at
#  session creation time, and 0.0005 seconds per additional
#  page on a 300 Mhz AMD K6-2 processor.)
sub encrypt_password() {
  return 1;	# encrypt for more protection
  #return 0;	# store plaintext
}

# Where the images are (in relation to the webserver)
sub image_path() {
  return '/acmemail/graphics/';
}

# What is the SMTP mail server (where I can send mail)?
sub smtphost() {
#  return 'mail';	# or whatever your SMTP server name is
  return 'localhost';
}

# What is the mail server (where the mail resides)?
sub mailhost() {
  return 'localhost';
}

# Should I check POP3 or IMAP mail?
sub mailhost_type() {
#  return 'pop3';
  return 'imap';
}

# If using IMAP, what is the name of the Mail
# directory. Your IMAP daemon will know where
# to find INBOX, but where are the other mailboxes?
sub inbox_directory() {
  return "Mail";	# if users store mail in $HOME/Mail
}

# What is my local domain?
sub local_domain() {
  return 'example.com';
}

# Should I hide email addresses (only show names)?
sub hide_email_address() {
  return 1;
#  return 0;
}

# 0 = messages shown in same window as message list
# 1 = one message list window / one message window
# 2 = one message list window / new messages shown in their
#     own window
sub messages_in_new_window() {
  return 0;
}

# How many messages to show per page
sub max_messages_per_page() {
  return 15;
}

# Show recent messages first?
sub show_recent_messages_first() {
  return 1;
}

# Where is the temporary mime directory?
sub temporary_mime_directory() {
  return "../../html/acmemail/mime-tmp/";
}

# Where is the temporary mime directory? (in relation to the webserver)
# This should NOT be the same direcory that acmemail.cgi is in,
# nor a subdirectory of the directory acmemail.cgi is in, so that
# HTML attachments cannot see the acmemail cookies
sub web_temporary_mime_directory() {
  return "/acmemail/mime-tmp/";
}

# What kind of sessions are we going to use?
sub session_type() {
 return "POS"; # using files and Persistant::Object::Simple
# return "Database"; # using a real database
}

# where to put persistent object records if using the POS session type
# *and* where to put attachments, regardless of session type
sub dope_directory() {
  return "dope/";
}

# If using the Database session type...
# What is the datasource for our database?
sub db_datasource() {
  return "dbi:mysql:acmemail:localhost"; # for MySQL
#  return "dbi:Pg:dbname=acmemail"; # for PostgreSQL
}

# If using the Database session type...
# What is the username for access to the database
sub db_username() {
  return "";
}

# If using the Database session type...
# What is the password for access to the database
sub db_password() {
  return "";
}

# How long should sessions still be valid for (in seconds)?
sub session_timeout() {
  return 60*60; # An hour
}

# Should we force cookies?
sub force_cookies() {
  return 1;
#  return 0;
}

# Should we force people to turn off javascript support?
# (also see control_port() and message_port())
sub force_nojavascript() {
  return 1;		# never allow JS
#  return 0;		# don't care if JS is enabled
}

# Should we try and remove malicious HTML tags
sub force_defang_html() {
  return 1;		# attempt to remove malicious tags
#  return 0;		# anything goes! (NOT recommended)
}


# Should we escape all HTML in message bodies (overrides force_defang_html)
#
# This is generally recommended to be set to "1" to thwart
# Cross-Site Scripting (XSS) and Cross-Site Request Forgeries (CSRF)
# as well as web bugs (www.privacyfoundation.org/resources/webbug.asp)
# but is not the default because users like their HTML mail
#
# Note that acmemail seems vulnerable to CSRF attacks if it
# is running with this set to "0"
sub force_escape_html() {
  return 0;		# HTML will be allowed in messages
#  return 1;		# user will see raw HTML codes
#  return 2;		# a subset of tags will be allowed, others exposed
#  return 3;		# a subset of tags will be allowed, others stripped
}

# Which HTML tags are always allowed?
sub safe_html_list() {
  # return a hash array of tags with trust, with 
  # allowable attribute patterns
  my %safeList = (
	'P' 	=> [ 
			'\balign\s*=\s*\"[a-z]{1,8}\"',
			'\balign\s*=\s*[a-z]{1,8}\b',
		   ],
	'BR'	=> [ ],
	'HR' 	=> [ 
			'\balign\s*=\s*\"[a-z]{1,8}\"',
			'\balign\s*=\s*[a-z]{1,8}\b',
		   ],
	'FONT'  => [ 
			'\bsize\s*=\s*\"[\+\-]?[0-9]\"',
			'\bcolor\s*=\s*\"\#?\w*\"',
			'\bsize\s*=\s*=[\+\-]?[0-9]\b',
			'\bcolor\s*=\s*\#?\w*\b',
		   ],
	'B'	=> [ ],
	'I'	=> [ ],
	'EM'	=> [ ],
	'STRONG'=> [ ],
  );
  return %safeList;
}

# Automatically add hyperlinks for things that look like URLs?
#
# See also acme_anonymize_links()
sub auto_add_hyperlinks() {
  return 1;		# add links 
#  return 0;		# leave the text as-is
}

# Referer header security tests
# 
# Should we require the client request to present a
# Referer HTTP header for more assurance that the request
# is from an acmemail page (CSRF protection)?
sub referer_header_test() {
#  return 0;		# no test
  return 1;		# test before dangerous operations
#  return 2;		# test for all operations (very strict/unfriendly)
}

# The hostname we expect visitors to refer to this server as
# used for referer checks
sub acme_server_name() {
  return($ENV{'SERVER_NAME'});
}

# The full base URL of this server, e.g. "https://example.com:444"
sub acme_server_base() {
  my $name = "http" . ( ($ENV{HTTPS} eq "on") ? "s" : "" ) . "://";
  $name .= lc($ENV{'SERVER_NAME'});
  if ( ( ($ENV{HTTPS} eq "on") && ($ENV{'SERVER_PORT'} ne '443') ) ||
     ( ($ENV{HTTPS} ne "on") && ($ENV{'SERVER_PORT'} ne '80') ) ) {
        $name .= ':' . $ENV{'SERVER_PORT'};
  }
  return($name);
}

# Should the cookies be only used over SSL?
sub secure_cookie() {
  return ( ( $ENV{HTTPS} eq 'on' ) ? 1 : 0 ); # automatic
#  return 1;		# use secure cookies
#  return 0;		# cookies can go to http and https sites
}

# What path should the basic cookies be set with?
sub cookie_path() {
  # calculate the directory this script is in
  # e.g., "/cgi-bin/acmemail.cgi" -> "/cgi-bin"
  my $path = $ENV{'SCRIPT_NAME'};
  $path =~ s/^(.*)\/[^\/]*$/$1/;
  return($path);
}

# What path should the control cookies be set with?
sub control_cookie_path($) {
  # calculate the "directory" for this script + "/control/"
  # e.g., "/cgi-bin/acmemail.cgi" -> "/cgi-bin/acmemail.cgi/control"
  my $q = shift;
  $q->path_info('/control/');
  my $path = $q->url(-query=>0, -absolute=>1, -path_info=>1);
  return($path);
}

# version number
sub acme_version() {
  # please, no HTML
  return "2.2.3";
}

# how much memory to use when parsing a message's MIME parts
# if the message is larger than this number of bytes, acmemail
# will write it to a file and parse it there. This means that
# large messages will be written to disk!
sub acme_mem_parse_buffer() {
  return(1048576);	# 1 Mbyte
#  return(32768);	# 32 Kbyte
#  return(1024);	# 1 Kbyte
#  return(0);		# always write to file
}

# When a message has both text and HTML versions, which do you prefer?
sub acme_preferred_msg_type() {
  return "html";		# the HTML version
#  return "plain";	# the plain text
#  return "";		# neither: display all text parts inline
}

# make links in messages anonymized?
# This protects privacy and helps keep sessions
# more secure if not using cookie (though mere IMG tags
# are problems with non-cookie use of acmemail)
sub acme_anonymize_links() {
  return 1;		# yes, anonymize links
#  return 0;		# no, leave links as-is
}

# For better protection against JavaScript attacks in messages
# and attachments, it is recommended that you configure your 
# Web server to listen to two ports. One of these ports should
# be designated as the "control" port, where acmemail will display
# pages it has high confidence have safe content. The other will
# be designated the "message" port, and will be used to display
# emails and their attachments
#
# TCP port used for "control" pages (compose, login, message list, etc.)
sub control_port() {
  return '';		# do not care
#  return 443;		# sample
}
# TCP port used to display messages and attachments
sub message_port() {
  return '';		# do not care
#  return 444;		# sample
}

#####
# HTML formatting
#####


sub html_login($$$) {
  my $q = shift;
  my $expectedURL = shift;
  my $unsafeBase = shift;
  my $return;
  my $refHost = $ENV{'HTTP_HOST'};
  if ( $ENV{HTTPS} eq 'on' ) { $refHost =~s /:443$//; }
  else { $refHost =~ s/:80$//; }
  $q->path_info('/control/');
  $return .= $q->startform;
  if ( (referer_header_test() != 0) && ($refHost ne acme_server_name()) ) {
	$return .= "<p>You should be referencing acmemail as <a href=\"$expectedURL\">$expectedURL</a>. If you continue using acmemail with a hostname/URL of \"".CGI::escapeHTML($ENV{'HTTP_HOST'})."\" you will be unable to use some features.<br><br>\n";
  }
  $return .= qq|
<table cellspacing="0" cellpadding="2" border="0" bgcolor="#000000"><tr><td>
<table cellspacing="0" cellpadding="3" border="0" bgcolor="#ffffff">
|;
  $return .= '<tr><td class="mheading"><span class="mheading">User</span></td>';
  $return .= '<td class="mheading">' . $q->textfield('username') . '</td></tr>';
  $return .= '<tr><td class="mheading"><span class="mheading">Password</span></td>';
  $return .= '<td class="mheading">' . $q->password_field('password') . '</td></tr>';
  $return .= '<tr><td><br></td><td><br>';
  $return .= $q->submit('Log in');
  $return .= $q->endform;
  $return .= qq|
</td></tr></table></td></tr></table>
|;
  $return;
}


sub html_head($) {
  my $q = shift;
  my $image_path = image_path();
  my $version = acme_version();
  my($js, $js2);
  my $base = acme_server_base();
  my $q2 = new CGI($q);
  $q2->delete_all();
  $q2->param('aredir',"http://acmemail.sourceforge.net/");
  my $acmeURL = CGI::escapeHTML($q2->url(-full=>1, -query=>1, -path_info=>0));

  if ( force_nojavascript() == 1 ) {
    $js = qq|
<SCRIPT LANGUAGE="JavaScript">
<!-- Hide script from old browsers
function force_nojavascript() {
  document.write("For security reasons, you should have JavaScript disabled for reading webmail. ");
  document.write("Please do this and then try to log in again.");
}

// End the hiding here -->
</SCRIPT>
  |;
    $js2 = qq|
<SCRIPT>
  force_nojavascript();
</SCRIPT>
<NOSCRIPT>
  |;
  }

  return qq|<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>acmemail</title>
<base href="${base}">
<LINK rel="stylesheet" type="text/css" href="${image_path}acmemail.css">
$js
</head>
<body bgcolor="#ffffff">
<a href="${acmeURL}"><img src="${image_path}acmemail.gif"
 WIDTH="441" HEIGHT="100" alt="[acmemail v${version}]" border="0"></a>$js2
 <br>|;
}


sub html_bottom($) {
  my $q = shift;
  my $image_path = image_path();
  my $version = acme_version();
  my $js;
  $js = '</NOSCRIPT>' if force_nojavascript();

  return qq|$js<p><hr><div align="right"><small><i>acmemail ${version}</i></small></div></body></html>|;
} 


sub html_bar($) {
  my $q = shift;
  my $image_path = image_path();
  my $currentPath = $q->path_info();
  $q->delete('show');
  $q->delete('msgkey');

  $q->path_info('/control/');
  $q->param('list', 1);
  my $url1 = $q->self_url;
  $q->delete('list');

  $q->param('compose', 1);
  my $url2 = $q->self_url;
  $q->delete('compose');

  $q->param('logout', 1);
  my $url3 = $q->self_url;
  $q->delete('logout');

  # remove the protocol://server[:port] info
  $url1 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url2 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url3 =~ s/^[^\/]*\/\/[^\/]*\///;

  my $return = qq|
<table border="0" cellpadding="0" cellspacing="0">
 <tr>
  <td align="center"><a href="$url1"><img src="${image_path}list.gif" alt="[List]" border=0></a></td>
  <td align="center"><a href="$url2"><img src="${image_path}edit.gif" alt="[Compose]" border=0></a></td>|;
  if ( (referer_header_test() == 0) || ($currentPath eq '/control/') ) {
    $return .= qq|<td align="center"><a href="$url3"><img src="${image_path}logout.gif" alt="[Logout]" border=0></a></td>|;
  }
  $return .= qq|</tr>
 <tr>
  <td>&nbsp;&nbsp;List&nbsp;&nbsp;</td>
  <td>&nbsp;&nbsp;Compose&nbsp;&nbsp;</td>|;
  if ( (referer_header_test() == 0) || ($currentPath eq '/control/') ) {
    $return .= qq|<td>&nbsp;&nbsp;Logout&nbsp;&nbsp;</td>|;
  }
  $return .= qq|</tr>
</table><br>|;
  $return;
}

sub html_message_bar($$) {
  my($q, $show) = @_;
  my $url = $q->self_url;
  my $image_path = image_path();

  $q->path_info('/control/');
  $q->param('list', 1);
  my $url1 = $q->self_url;
  $q->delete('list');

  $q->param('compose', 1);
  my $url2 = $q->self_url;
  $q->delete('compose');

  $q->param('reply', $show);
  my $url3 = $q->self_url;
  $q->param('replytoall', 1);
  my $url4 = $q->self_url;
  $q->delete('replytoall');
  $q->delete('reply');

  $q->param('forward', $show);
  my $url5 = $q->self_url;
  $q->delete('forward');

  $q->param('logout', 1);
  my $url6 = $q->self_url;
  $q->delete('logout');

  # remove the protocol://server[:port] info
  $url1 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url2 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url3 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url4 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url5 =~ s/^[^\/]*\/\/[^\/]*\///;
  $url6 =~ s/^[^\/]*\/\/[^\/]*\///;

  my $return = qq|
<table border="0" cellpadding="0" cellspacing="0">
 <tr>
  <td align="center"><a href="$url1" target="_top"><img src="${image_path}list.gif" alt="[List]" border=0></a></td>
  <td align="center"><a href="$url2" target="_top"><img src="${image_path}edit.gif" alt="[Compose]" border=0></a></td>
  <td align="center"><a href="$url3" target="_top"><img src="${image_path}reply.gif" alt="[Reply]" border=0></a></td>
  <td align="center"><a href="$url4" target="_top"><img src="${image_path}replytoall.gif" alt="[Replytoall]" border=0></a></td>
  <td align="center"><a href="$url5" target="_top"><img src="${image_path}forward.gif" alt="[Forward]" border=0></a></td>|;
  if ( referer_header_test() == 0 ) {
    $return .= qq|<td align="center"><a href="$url6" target="_top"><img src="${image_path}logout.gif" alt="[Logout]" border=0></a></td>|;
  }
  $return .= qq|</tr>
 <tr>
  <td>&nbsp;&nbsp;List&nbsp;&nbsp;</td>
  <td>&nbsp;&nbsp;Compose&nbsp;&nbsp;</td>
  <td>&nbsp;&nbsp;Reply&nbsp;&nbsp;</td>
  <td>&nbsp;&nbsp;Reply to all&nbsp;&nbsp;</td>
  <td>&nbsp;&nbsp;Forward&nbsp;&nbsp;</td>|;
  if ( referer_header_test() == 0 ) {
    $return .= qq|<td>&nbsp;&nbsp;Logout&nbsp;&nbsp;</td>|;
  }
  $return .= qq|</tr>
 </tr>
</table><br>|;
  $return;
}


sub html_list_head ($$$$$$$) {
  my($q, $username, $nmsgs, $previous_offset, $next_offset, $mailbox, $mailboxes) = @_;
  my(@navs,$nlinks,$npages,$start,$stop,$o);
  $q->path_info('/control/');
  my $image_path = image_path();
  my $mailhost = mailhost();
  my $inbox = inbox_directory();
  my $orig_offset = $q->param('offset') || 0;

  my $return = $q->startform;

  $mailbox =~ s|^$inbox/||;
  $return .= qq|Folders: |;
  $return .= $q->popup_menu(-name=>'mailbox', -values=>$mailboxes);
  $return .= qq|<INPUT TYPE="submit" NAME="viewmailbox" VALUE="Go"><p>|;

  my $from = $q->param('offset') || '0';
  if ($nmsgs == 0) {
    $return .= "There are no messages";
  } elsif ($nmsgs == 1) {
    $return .= "Showing the only message";
  } else {
    my $to = (sort {$a <=> $b} ($from + max_messages_per_page(), $nmsgs))[0];
    $from++;
    $return .= "Showing messages <a href=\"".$q->self_url."\">$from-$to</a> of $nmsgs messages";
  }
  $return .= " in the '".CGI::escapeHTML($mailbox)."' folder for ".CGI::escapeHTML("$username\@$mailhost");

  if ( $nmsgs > max_messages_per_page() ) {
    $nlinks = 5; # 2 == 0-10 ... 41-50 51-60 61-70 71-80 81-90 ... 111-120
    $npages = int( ($nmsgs / max_messages_per_page()) + 1);
    $start = (int($from/max_messages_per_page())*max_messages_per_page()) - (int($nlinks/2) * max_messages_per_page());
    while ( ($start + ($nlinks * max_messages_per_page())) > (($npages - 1) * max_messages_per_page()) ) {
      $start -= max_messages_per_page();
    }
    if ($start < (1 * max_messages_per_page()) ) {
      $start = (1 * max_messages_per_page());
    }
    $stop = $start + (($nlinks - 1) * max_messages_per_page());
    if ($stop > (($npages - 1) * max_messages_per_page()) ) {
      $stop = (($npages - 1) * max_messages_per_page());
    }
    push @navs, '0';
    if ($start > max_messages_per_page()) { push @navs, ' ... '; }
    if ($stop < $start) { $stop = $start; }
    for (my $l = $start; (($l <= $stop) && ($l < $nmsgs)); $l += max_messages_per_page() ) {
      push @navs, $l;
    }
    if ( ((($npages - 1) * max_messages_per_page()) - $stop) > max_messages_per_page()) { push @navs, ' ... '; }
    if ($stop < (($npages - 1) * max_messages_per_page())) {
      push @navs, (($npages - 1) * max_messages_per_page());
    }
    $return .= "\n<br><br>Go to messages ";
    foreach $o ( @navs ) {
      if ($o eq ' ... ') {
        $return .= $o;
      } elsif ($o == ($from - 1)) {
        $q->param('offset', $o);
        my $url = $q->self_url;
        $return .= " <b><a href=\"$url\">[".($o + 1)."-";
        $return .= ( (($o + max_messages_per_page() ) < $nmsgs) ? ($o + max_messages_per_page() ) : $nmsgs) . "]</a></b> ";
      } else {
        $q->param('offset', $o);
        my $url = $q->self_url;
        $return .= " <a href=\"$url\">[".($o + 1)."-";
        $return .= ( (($o + max_messages_per_page() ) < $nmsgs) ? ($o + max_messages_per_page() ) : $nmsgs) . "]</a> ";
      }
    }
  }
  $return .= "\n<br>";
  $q->param('offset',(int($from/max_messages_per_page())*max_messages_per_page()));

  my $trash = $q->image_button('-name'=>'delete', '-src'=>qq|${image_path}trash.gif|,
			       '-alt'=>'Delete messages', '-border'=>0);

  $return .= qq|<p>
<!--table cellspacing="0" cellpadding="2" border="0" bgcolor="#000000"><tr><td-->
<table cellspacing="0" cellpadding="2" border="0" bgcolor="#ffffff"><tr><td>
<table cellspacing="0" cellpadding="2" border="0">
<tr>
<td class="heading" width="300"><SPAN CLASS="heading">Subject</SPAN></td>
<td class="heading"><SPAN CLASS="heading">From</SPAN></td>
<td class="heading"><SPAN CLASS="heading">Date</SPAN></td>
<td class="heading"><SPAN CLASS="heading">Size</SPAN></td>
<td class="heading">$trash</td>
</tr>|;

  $return;
}


{ # closure for the $class variable, which alternates
  # between 'one' and 'two' for the stylesheet...
  my $class;

  sub html_list_row($$$$$$$$$$$) {
    my($q, $i, $subject, $from, $date, $size, $notseen, $attachment, $uid2, $secret,$unsafeBase) = @_;

    # Create reference to self with right parameter
    $q->path_info('');
    $q->param('show', $uid2);
    my $md5 = new MD5;
    $md5->add($uid2, $secret,$q->param('mailbox'));
    $q->param('msgkey',$md5->hexdigest());
    my $url = $q->self_url;
    if ( message_port ne '' ) {
      $url =~ s/^[^\/]*\/\/[^\/]*/${unsafeBase}/e;
    }
    $q->delete('show');
    $q->delete('msgkey');
    my $target;
    $target = q| target="_acme_messages"| if (messages_in_new_window() == 1);
    $target = q| target="_blank"| if (messages_in_new_window() == 2);

    $subject = "<b>$subject</b>" if $notseen;

    $subject = qq|<a href="$url"$target>$subject</a>|;
    $subject .= q| <img src="| . image_path() . qq|clip.gif" ALT="[attachment]" WIDTH="16" HEIGHT="15">| if $attachment;

    #my $delete = $q->checkbox('-name'=>'todelete', '-value'=>$i, '-label'=>'');
    my $delete = $q->checkbox('-name'=>'todelete', '-value'=>$uid2, '-label'=>'');

    $class = ($class eq 'one') ? 'two' : 'one';
    
    return qq|
<tr class="$class">
<td>$subject</td>
<td>$from</td>
<td>$date</td>
<td align="right">$size</td>
<td>$delete</td>
</tr>
  |;
  }
} # end of closure


sub html_list_bottom($) {
  my $q = shift;
  my $image_path = image_path();
  my $return;
  $return .= $q->endform . qq|</table></td></tr></table><br>|;
  return $return;
}


sub html_message_head($) {
  my $q = shift;

  return qq|
<table cellspacing="0" cellpadding="2" border="0" bgcolor="#000000"><tr><td>
<table cellspacing="0" cellpadding="3" border="0" bgcolor="#ffffff"><tr><td>
  |;
}


sub html_message_headers($$$$$$) {
  my($q, $from, $subject, $to, $cc, $date) = @_;

  my $return = qq|
<table bgcolor="#aaffaa" cellspacing="0" cellpadding="2" width="100%" border="0">
<tr><td>
<table border=0>
 <tr><td class="mheading" align="right"><span class="mheading">From:</span></td>
     <td>$from</td></tr>
 <tr><td class="mheading" align="right" valign="top"><span class="mheading">Subject:</span></td>
     <td colspan="2">$subject</td></tr>|;

  $return .= qq|<tr><td class="mheading" align="right" valign="top"><span class="mheading">To:</span></td>
                    <td colspan="2">$to</td></tr>| if ($to ne "<br>");
  $return .= qq|<tr><td class="mheading" align="right" valign="top"><span class="mheading">CC:</span></td>
                    <td colspan="2">$cc</font></td></tr>| if ($cc ne "<br>");
  $return .= qq|</table>
</td><td align="right" valign="top"><table><tr><td>$date</td></tr></table></td></tr></table><p>|;
  $return;
}


sub html_message_bottom($) {
  my $q = shift;

  return qq|
</td></tr></table>
</td></tr></table>
  |;
}


sub html_quoted($$) {
  my($q, $text) = @_;

  return qq|<font color="#aa0000">$text</font>|;
}


sub html_signature($$) {
  my($q, $sig) = @_;

  return qq|<font size="-1" color="#555555"><pre>\n--\n\n$sig</pre></font>|;
}






# Keep Perl happy
1;

