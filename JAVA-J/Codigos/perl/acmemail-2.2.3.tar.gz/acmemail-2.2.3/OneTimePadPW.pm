# OneTimePadPW.pm
#
# version 0.3 - 2001/04/01
#
# functions for one-time-pad recoverable encryption
#
# OneTimePadPW.pm is Copyright (c) 2001 Peter Watkins. All rights reserved.
#
# You may distribute OneTimePadPW.pm under the terms of either the GNU General
# Public License as published by the Free Software Foundation (either
# version 2 of the License or at your option any later version)
# or the Artistic License. You should have received a copy of both
# licenses along with this program.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

package	OneTimePadPW;
require	Exporter;
@ISA	= qw(Exporter);
@EXPORT	= qw(GetRandomBytes EncryptOTP DecryptOTP);
@EXPORT_OK = qw($randDevice);
	
my $randDevice = "/dev/urandom";	# faster, less random
#my $randDevice = "/dev/random";	# slower, uses precious system entropy

# GetRandomBytes($len) : retrieves $len random bytes, returns a hex-encoded string
#			 that is twice as long as the number of bytes specified
# 			 e.g., encoding bytes "A7%v;{n" yields "413725763b7b6e"
#	This function is intended for picking a series of random bytes for
#	use in one-time-pad encryption
#
sub GetRandomBytes ($) {
	my ($bytesNeeded) = @_;
	my ($byte, $randomdata, $rc);
	$randomdata = '';
	$rc = 1;
	if (open(RFP,"<$randDevice")) {
		while ( ($rc == 1) && (length($randomdata) < (2 * $bytesNeeded)) ) {
			if ( ($rc = read(RFP,$byte,1)) == 1) {
				$randomdata .= sprintf("%2.2x",(ord($byte) % 256));
			}
		}
		close(RFP);
		if (length($randomdata) >= (2 * $bytesNeeded)) { return(substr($randomdata,0,(2 * $bytesNeeded))); }
	}
	# Ugh. No usable $randDevice, or not enough data
	# BUG: note we're calling the 'ps' program, Unix-specific
	srand( time() ^ $$ ^ unpack "%32L*", `ps axww`);	# Camel
	while (length($randomdata) < (2 * $bytesNeeded)) {
		# get a byte from rand(256)
		$randomdata .= sprintf("%2.2x",rand(256));
	}
	return substr($randomdata,0,(2 * $bytesNeeded));
}

# EncryptOTP($plaintext,$pad) :	returns ciphertext of $plaintext using $pad for the OTP keys,
#				with each byte of ciphertext being a two-character hex 
#				representation of ( ( P + K ) % 256 ) where P and K are the
#				numeric values of the plaintext and key bytes, e.g. when
#				encrypting "secret" with "413725763b7b6e" means calculations like
#				( ( 0x73 + 0x41 ) % 0xFF ) = 0xB4 = "b4"
#				to get the result "b49c88e8a0ef6e"
#				NOTE: $plaintext cannot contain any NULL (0x00) characters
#				(assuming no nulls allows us to hide the length of $plaintext
#				 from someone who sees $ciphertext)
sub EncryptOTP ($$) {
	my ( $text, $pad ) = @_;
	my ( $l, $byte, $ciphertext );
	if ( (2 * length($text)) > length($pad) ) { die "insufficient pad \"$pad\""; }
	$ciphertext = '';
	for ( $l = 0 ; $l < length($text) ; ++$l ) {
		$byte = ( ord(substr($text,$l,1)) + hex(substr($pad,(2*$l),2)) ) % 256;
		$ciphertext .= sprintf("%2.2x",$byte);
	}
	for ( $l = (2 * length($text)) ; $l < length($pad) ; $l += 1 ) {
		$ciphertext .= substr($pad,$l,1);
	}
	return($ciphertext);
}

# DecryptOTP($ciphertext,$pad) :	decrypts cipertext created by EncryptOTP using
#					$pad as the pad of one-time keys, e.g.
#					ciphertext "a8f0d44107014b" with pad "358b71cfa28d4b"
#					decrypts to "secret" (note the last character of
#					the ciphertext is essentially padding)
sub DecryptOTP ($$) {
	my ( $ciphertext, $pad ) = @_;
	my ( $l, $byte, $text );
	if ( length($ciphertext) > length($pad) ) { die "insufficient pad"; }
	$text = '';
	for ( $l = 0 ; 
	    ($l < length($pad)) && (substr($ciphertext,$l,2) ne substr($pad,$l,2)) ; 
	    $l += 2 ) {
		$byte = ( hex(substr($ciphertext,$l,2)) - hex(substr($pad,$l,2)) ) % 256;
		$text .= pack("c",$byte);
	}
	return($text);
}

1;

