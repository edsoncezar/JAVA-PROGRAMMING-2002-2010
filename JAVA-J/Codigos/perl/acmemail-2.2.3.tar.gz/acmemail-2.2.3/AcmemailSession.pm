# Generic class for an acmemail session

package AcmemailSession;

use strict;
use Exporter;
use vars qw(@ISA @EXPORT_OK $TYPE);

@ISA = qw(Exporter);
@EXPORT_OK = qw(set_type get_type
	     create_new new expire
	     username password id
	    );

$TYPE = undef; # Class global

# Class method, sets the type of AcmemailSession that we'll
# be handling thoughout the life of the module
#
# It dies if you pass it a bogus type
sub set_type {
  my($class, $type) = @_;
  my $newclass = $class . '/' . $type . '.pm';
  eval { require $newclass };
  main::bye("$type not a valid AcmemailSession type!\n") if $@;
  $TYPE = $type;
}

# Class method, returns the AcmemailSession type
sub get_type {
  my $class = shift;
  return $TYPE;
}

# Class method, creates a new session, given a username and password
sub create_new {
  my($class, $username, $password) = @_;
  $class .= '::' . $TYPE;
  return $class->create_new($username, $password);
}

# Class method, recreates an existing session, given a session id
# May return undef if the session does not exist or has timed out
sub new {
  my($class, $id) = @_;
  $class .= '::' . $TYPE;
  return $class->new($id);
}

# Object method, expires the session so that it can no longer be used
sub expire {
  my $self = shift;
  return $self->expire;
}

# Object method, returns the username associated with the session
sub username {
  my $self = shift;
  return $self->username;
}

# Object method, returns the username associated with the session
sub password {
  my $self = shift;
  return $self->password;
}

# Object method, returns the session id associated with the session
# This should really be something which could be a directory name,
# as it is used for temporary MIME files too
sub id {
  my $self = shift;
  return $self->id;
}


1;
