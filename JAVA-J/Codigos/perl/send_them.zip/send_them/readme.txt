			Send Them!

       � 2000 Veinotte.com International Inc.
           Basic redirection script.

 This script has only been tested on UNIX, but "should" be fine
 on NT or any Win32 platform.

 A simple redirection script to allow redirect forms on
 your website without having to use JavaScript. This script
 also makes it easy to use one form throught your site if
 you have SSI enabled on your website. Just place a form
 like the one below in a text file somewhere and call it 
 with an ssi call in all the pages you want to use it in:

         <!--#include virtual="/home/usr/htdocs/send.txt" -->

 Just make the call above make sense on your system. It should be
 a direct system path to the text file.

 This allow you to edit one text file when adding a new URL
 instead of editing each HTML file.

 Here is an example of the form use in your pages or in a text
 file with SSI

  <form method="post" action="/cgi-bin/send.pl"> 
  <select name="page">
  <option value="www.veinotte.com/">Veinotte.com</option>
  <option value="www.cgi.veinotte.com/">CGI / Perl</option>
  <option value="www.member-manager.veinotte.com/">Member Manager II</option>
  <option value="www.banner-system.veinotte.com/">Banner System Software</option>
  <option value="www.veinotte.com/lamour/">Lamour Site</option>
  <option value="www.veinotte.com/main.htm">Site Wide Directory</option>
  </select>
  <input type="submit" value="Go">
  </form>

One more note: If you wanted the page to open in a new window, or another frame just
add a target to the first line like so:

  <form method="post" action="/cgi-bin/send.pl" target="_blank"> 



			** DISCLAIMER **
			****************
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 OF THE POSSIBILITY OF SUCH DAMAGE.

Veinotte.com International Inc.
http://www.veinotte.com



