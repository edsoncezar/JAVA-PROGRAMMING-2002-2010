#####################################
# Aktif.cgi v1.0 10/03/2000
# coded by Mesut Akcan 
# http://kaynak.cjb.net
# http://makcan.virtualave.net
# makcan@softhome.net
#####################################

Function of this script is how many online visitor in your web site.

Installing Aktif.cgi is very simple!
If you have installed any cgi script before you can easily install
Aktif.cgi

Just preform the following steps:

1)

 Check the path to perl on .cgi file. If your path to perl is
 different from 
 #!/usr/bin/perl
 you will need to change that on the top of aktif.cgi file.
 If you are unsure what the correct path is, ask your system admin.
 DO NOT CHANGE ANYTHING BELOW #!/usr/bin/perl 

2)

 $tol=60 ; refresh time. 

3)

 Upload aktif.cgi in to your cgi-bin directory. Make sure you upload
 ASCII mode!  If you are using a UNIX server, chmod 755. 
 
4)

 This script must be run in a frame, if your page have not frame, 
 you are exchange your entry page name index2.htm , and then create
 index.htm 

5)

 Specimen codes for index.htm under this help page...	

-------------
 <HTML>
   <FRAMESET ROWS="*,25" BORDER="NONE" FRAMEBORDER="0">
   <FRAME NAME="ust" SRC="index2.htm" SCROLLING="NO" NORESIZE>
   <FRAME NAME="alt" 
     SRC="http://www.yourserver.com/cgi-bin/aktif.cgi"
     SCROLLING="NO" NORESIZE>
   </FRAMESET>
  </HTML>	
-------------

6)

 Other way for showing online visitor(s) :
 Add to following HTML code to your web page between
 <body> and </body> tags

-------------- 
 <IFRAME frameborder="0" scrolling="no" width="120" height="20" 
   SRC="http://www.yourserver.com/cgi-bin/aktif.cgi">
 </IFRAME>
--------------

If you need help you can email Mesut Akcan at makcan@softhome.net
or check out the website at
 http://kaynak.cjb.net ,
 http://akcansoft.virtualave.net

- 0 - 