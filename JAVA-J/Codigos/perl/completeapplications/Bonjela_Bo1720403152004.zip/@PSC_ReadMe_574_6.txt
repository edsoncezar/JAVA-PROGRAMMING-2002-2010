Title: Bonjela Bot - MSN Bot
Description: This is a MSN Bot it comes with the msn protocall (MSNP10) from bot depot.
It has a wizard to help you also..
Commands as follows:
Comes with a few commands (Not intended for total newbies to the msnp)
Public Commands:
- Menu - Shows Menu!
- Hello - Shows You A Simple Command (How to make a reply command)
- Say - Bot Repeats!
- Fact - Get A Fact From Bot-Work!
- Games:
- Dice - Roll A Dice!
Administrator Commands:
- Admin - Main Menu!
- Block - Block A User!
- Reboot - Reboot Bot!
- Convos - Open Sockets!
- Alert - Popup/Toast/Alert!
- Join - Join A Socket!
This has been commented a bit to teach you v. simple commands
It was made by Mat007 and Farkie!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=574&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
