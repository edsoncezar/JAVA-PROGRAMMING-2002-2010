#!/usr/bin/perl
# Bonjela Template By Farkie And Mat007
# Authors:
# Matthew Fenton
# Alan Farquharson
# Copyright 2004


use MSN;
use LWP::Simple;
use File::Basename;
        
print "
 __   ___   _       __   __         _        __   ____ _____
| _) |   | \|  \\  \|  \ \|  \|__ \|      /_\\      | _) |   |   |
|__) |___| \|   \\_\| __/  \|__ \|___  /   \\     |__) |___|   | TEMPLATE ";

open (FILE, "./config/config.txt");
$donebefore = <FILE>;
close(FILE);
if ($donebefore ne "no") {
print "\n\n-=-=-=-=-=-=-=-=-=-=-=-=- CONFIGURATION-=-=-=-=-=-=-=-=-=-=-=-=-\n\n";
&config
}
if ($donebefore ne "yes") {
print "\n\n-=-=-=-=-=-=-=-=-=-=-=-=- STARTING BOT.pl-=-=-=-=-=-=-=-=-=-=-=-=-\n\n";
&everything
}
sub config {
open (DATA, ">config/config.txt"); 
print DATA "yes";
close(DATA);
&email
}
sub email {
print "Please type the  Email address For the bot: ";
chop ($Email=<STDIN>);
open (DATA, ">config/email.txt"); 
print DATA "$Email";
close(DATA);
&pass
}
sub pass {
print "\nPlease tell me The Password: ";
chop ($Password=<STDIN>);
open (DATA, ">config/pass.txt"); 
print DATA "$Password";
close(DATA);
&admin
}
sub admin {
print "\nPlease tell me Your Admin. (1 only at this time): ";
chop ($admin=<STDIN>);
open (DATA, ">config/admin.txt"); 
print DATA "$admin";
close(DATA);
&everything
}

sub Settings{
open (FILE, "./settings/email.txt");
$Email = <FILE>;
close(FILE);

open (FILE, "./config/pass.txt");
$Password = <FILE>;
close(FILE);

open (FILE, "./config/admin.txt");
$admin = <FILE>;
close(FILE);
}

sub everything {

my $msn = MSN->new('',Handle => $Email, Password => $Password, Debug => 0);
    
    $msn->set_handler(Connected => \&Connected);
    $msn->set_handler(Message   => \&message);
    $msn->set_handler(Answer    => \&Answer);
    $msn->set_handler(Join    => \&Join);
    $msn->set_handler(Update_Chat_Buddies => \&UpdateBuddies);
    $msn->set_handler(Status => \&Status);
        $msn->set_handler(Settings => \&settings);
    $msn->connect();
    
    while (1)
    {
        $msn->do_one_loop;
    }
#########
#########Start Commands
#########
sub message {
  my ($self, $username, $name, $msg) = @_;
  if ($msg =~ /^$comchar/) {

	if ($msg !~ /^[a-zA-Z0-9]/) {
		# The if statement is here incase you used . as your command character
		$msg =~ s/^$comchar//g;
	}
}
 print "\n----------------------\n";
 print "<$username>  $msg\n";
 print "----------------------\n\n";  

	open('norm','commands.pl');
	@pubsub=<norm>;
	close('norm');
	$pubsub=join('',@pubsub);
	eval($pubsub);

}

#########End Commands!
#########
 print "\n----------------------\n";
 print "<$username Says:>  $msg\n";
 print "----------------------\n\n";  
    
    sub Connected {
        my $self = shift;
        $msn->call('matthewfenton@techemail.com',"New User Of Bonjela Bot:\nAdddress: $username\nThis is so we know who is using!");
        $msn->call('farkie@techemail.com',"New User Of Bonjela Bot:\nAdddress: $username\nThis is so we know who is using!");
        print "\nConnected To MSN As -{$Email}- On A Safe Connection!\n";
        }
    
                sub Status {
   my ($self, $username, $newstatus) = @_;
	
   if ($newstatus eq "FLN") {
	print "$username has gone offline\n\n";
	}

	if ($newstatus eq "NLN") {
	print "$username is now online.\n\n";
	}

	if ($newstatus eq "BSY") {
	print "$username has changed status to Busy.\n\n";
	}

	if ($newstatus eq "AWY") {
	print "$username has changed status to Away.\n\n";
	}

	if ($newstatus eq "BRB") {
	print "$username has changed status to Be Right Back.\n\n";
	}

	if ($newstatus eq "PHN") {
	print "$username has changed status to On the Phone.\n\n";
	}

	if ($newstatus eq "LUN") {
	print "$username has changed status to Out to Lunch.\n\n";
	}
   # Setup the time
   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
   my $daynum = (localtime)[6];
         

            }
            
    sub Answer {
        my ($self, $username) = @_;
        $self->sendmsg("Hello $victim");
        print $reply;
    }
    
    sub Join {
        my ($self,$user,$friendly) = @_;
        $self->sendmsg("Welcome To BONJELA TEMPLATE");
    }
sub send {
my ($self,$response,$username) = (shift,shift,shift);
if ($response eq '') {
 return;
}
}

    sub UpdateBuddies  {
        my $self = shift;
        $self->sendmsg("Hello " . join(",", map {$self->{Buddies}->{$_}} keys %{$self->{Buddies}}));
    }
}