################User Commands#############################
# Bonjela Bot Template
# By Mat007 And Farkie
# Birth Date! : 11 March 2004 - 20:25!
##########################################################

if ($msg =~/^\!main|!menu/) {
$self->sendtyping();
$self->sendmsg("\(\^\)\(\^\) MAIN MENU \(\^\)\(\^\)\n!hello - i dunno!\n!say - Say what you want!\nBonjela Bot :: V1");
return;
}
if ($msg =~/^\!hello/) { # Start
$self->sendtyping(); # Bot Types!
$self->sendmsg("Hey :P"); # Reply!
return;
}
if ($msg =~ /^\!say (.*)/) { # Command Start (.*) = $1
$self->sendmsg("$1"); # The Bot Replys!
return;
} # End Command!
	
################ ADMIN COMMANDS STARTING ##################

open (FILE, "./config/admin.txt");
$admin = <FILE>;
close(FILE);

# We've included a fair few admin commands!

if ($username =~/$admin/) {
	
if ($msg =~/^!admin/) {
$self->sendmsg("\(\^\)\(\^\) ADMIN MENU \(\^\)\(\^\)\n !admin - i dunno!");
return;
}
	
if ($msg =~ /^!block/i) {    
&send($self, "Please tell me the persons email address","$username" );
$block{$username} = 1;
}
if ($block{$username}) {
undef $block{$username};
$msn->block($msg);
&send($self, "Blocked!","$username" );
goto end;
}
if ($msg =~ /^!reboot/i) {
$self->sendraw("OUT\r\n");
system "perl bot.pl";
goto end;
}
if ($msg =~ /^!convos/i) {
my $id;
print $msn->GetMaster->{Handle} . "\n";
$reply = "Open Sockets:\n\n";
foreach $id (keys %{$msn->GetMaster->{Socks}}) {
next unless defined $msn->GetMaster->{Socks}->{$id} && $msn->GetMaster->{Socks}->{$id}->{Type} eq 'SB';
$reply .= "$id=" . join (", ", keys %{$msn->GetMaster->{Socks}->{$id}->{Buddies}}) . "\n";
}
$self->sendmsg("$reply");
}
if ($msg =~ /^!alert (.*)/) {
$msn->set_status('HDN');
$self->set_name("Admin: $1\r\r\r\r");
sleep(1);
$msn->set_status('NLN');
$self->set_name("Bonjela Template");
return;
}
if ($msg =~ /^!join (.*)/i) {
$reply = "Could not join socket." unless exists $self->GetMaster->{Socks}->{$1};
$self->GetMaster->{Socks}->{$1}->invite($username);
$reply = "Joining socket $1...";
$self->GetMaster->{Socks}->{$1}->sendmsg("$username has joined us...");
&send($self,"$reply", $username);
return;
}

}

end: