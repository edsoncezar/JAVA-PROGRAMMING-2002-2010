Install Activeperl se top of form: frmsyntax
This will report any error in your perl code.
Needs a little bit of work before its done, but a good start.
To get a better color coding, see my code in Planet source:
A Color Code in Richtextbox
