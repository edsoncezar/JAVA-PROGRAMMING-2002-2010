
$document_root=qq|/home/mojosoft/public_html|;
$site_title=   qq|mojoFAQ 1.20 Frequently Asked Question Script|;
$data_path=    qq|/home/mojosoft/public_html/beta/mojofaq/faq/data|;
$email_path=   qq|/home/mojosoft/public_html/beta/mojofaq/faq/emails|;
$log_path=     qq|/home/mojosoft/public_html/beta/mojofaq/faq/data|;
$member_path = qq|/home/mojosoft/public_html/beta/mojofaq/faq/members|;
$mail_path=    qq||;
$template_path=qq|/home/mojosoft/public_html/beta/mojofaq/faq/templates|;
$session_path= qq|/home/mojosoft/public_html/beta/mojofaq/faq/sessions|;
$script_path=  qq|/home/mojosoft/public_html/beta/mojofaq/faq/scripts|;
$image_url=    qq|http://www.mojosoft.net/beta/mojofaq/faq/images|;
$image_path=   qq||;
$cgi_url=      qq|http://www.mojosoft.net/beta/mojofaq/faq|;
$home_url=     qq||;
$myname=       qq|webmaster|;
$myemail=      q|webmaster@mojosoft.net|;
$sendmail=     qq|/usr/lib/sendmail|;
$smtp=         qq||;
$system=       qq|Unix|;
$language_lib= qq||;
$script_ext=   qq|cgi|;
##NOTE: never ever try to edit this file manually, unless you know what you do
##  but why not login your admin area, where you can config everything on the web?
##  if you make some manual changes, and the script won't work, run install.cgi again
##
#######  Email Subjects  #############
$SUBJECT{admin}=         qq|Some one post a question|;
$SUBJECT{user}=          qq|We've recieved your question|;
#######  Email Templates  #############
$EMAIL{admin}=           qq|$email_path/admin.txt|;
$EMAIL{user}=            qq|$email_path/user.txt|;
#######  HTML Templates  #############
$TEMPLATE{home}=         qq|$template_path/home.html|;
$TEMPLATE{ask}=          qq|$template_path/ask.html|;
$TEMPLATE{answer1}=      qq|$template_path/answer1.html|;
$TEMPLATE{cat1}=         qq|$template_path/cat1.html|;
$TEMPLATE{category}=     qq|$template_path/category.html|;
$TEMPLATE{error}=        qq|$template_path/error.html|;
$TEMPLATE{question1}=    qq|$template_path/question1.html|;
$TEMPLATE{question}=     qq|$template_path/question.html|;

######### Configurations ##########
$CONFIG{answered_ext}=   qq|ans|;
$CONFIG{unanswered_ext}= qq|una|;
$CONFIG{lsh}=            qq|1|;
$CONFIG{lex}=            qq|2|;
$CONFIG{lun}=            qq|8|;
$CONFIG{log_ext}=        qq|log|;
$CONFIG{admin_database}= qq|$member_path/admin.cgi|;
$CONFIG{group_database}= qq|$member_path/groups.cgi|;
$CONFIG{ID_db}=          qq|$data_path/id.cgi|;
$CONFIG{cat_db}=         qq|cat.cgi|;
$CONFIG{cat_order}=      qq|cat_order.cgi|;
$CONFIG{log}=            qq|yes|;
$CONFIG{flock}=          qq|yes|;
$CONFIG{rename}=         qq|1|;
$CONFIG{waiting_folder}= qq|_waiting|;
$CONFIG{notify_email}=   q|webmaster@mojoscripts.com|;
$CONFIG{auto_response}=  q|1|;
$CONFIG{redirect}=       qq||;
$CONFIG{catlayout}=      qq|1|;

######### TABLEs ##########
$TABLE{cat_width}=       qq|100%|;
$TABLE{cat_border}=      qq|0|;
$TABLE{cat_cellspacing}= qq|0|;
$TABLE{cat_cellpadding}= qq|0|;
$TABLE{cat_bgcolor}=     qq|#FFFFFF|;
$TABLE{cat_bordercolor}= qq|#DDDDDD|;
$TABLE{cat_rows}=        qq|2|; 
$TABLE{cat_cols}=        qq|4|;

#################################
######### Scripts Location ##########
$admin_url=       qq|$cgi_url/admin.cgi|;
$ask_url=         qq|$cgi_url/ask.cgi|;
$mojo_url=        qq|$cgi_url/mojofaq.cgi|;

########################################################
1;
