###########################################################################
sub PrintError{
	local($title, $message) = @_;
	&PrintTemplate($TEMPLATE{error}, $message);
}
###########################################################################
sub PrintTemplate{
	my($cat, $filename, %HTML, $template);
	($template, $message) = @_;
	$MOJOTAG{message} = $message if $message;
	$template = &ParseUserURL($template);

	$template =~ s/\[LOCATION\]/&BuildLocation()/egis;
	$template =~ s/\[CATEGORY_NAME\]/&BuildCategoryDisplay(0)/eis;
	$template =~ s/\[CATEGORY_DESCRIPTION\]/&BuildCategoryDisplay(1)/eis;
#	$template =~ s/\[NAVIGATION\]/&BuildNavigation/egis;
#	$template =~ s/\[NEXT_CATEGORY\]/$MOJOTAG{next_cat}/ig;
#	$template =~ s/\[NEXT_FILE\]/$MOJOTAG{next_file}/ig;
#	$template =~ s/\[PAGES\]/&BuildPageLinks()/egis;
#	$template =~ s/\[PREV_CATEGORY\]/$MOJOTAG{prev_cat}/ig;
#	$template =~ s/\[PREV_FILE\]/$MOJOTAG{prev_file}/ig;
#	$template =~ s/\[PULLDOWN_MENU\]/&BuildMenu($cat)/egis;
#	$template =~ s/\[SEARCH_BOX\]/&BuildSearchBox($cat)/egis;
#	$template =~ s/\[SLIDESHOW\]/$MOJOTAG{slideshow}/egis;
#	$template =~ s/\[SORT_OPTIONS\]/$MOJOTAG{sort_options}/egis;
#	$template =~ s/\[USER_OPTIONS\]/$MOJOTAG{user_options}/iges;
	
	$template =~ s/\[QUESTIONS\]/$MOJOTAG{questions}/i;
	$template =~ s/\[ANSWERS\]/$MOJOTAG{answers}/i;
	$template =~ s/\[CATEGORIES\]/$MOJOTAG{cats}/i;
	$template =~ s/\[IMAGES_URL\]/$image_url/ig;
	$template =~ s/\[TITLE\]/$title/i;
	$template =~ s/\[MESSAGE\]/$MOJOTAG{message}/i;
	$template =~ s/\[PAGE_TITLE\]/&BuildTitle()/is;
	my $cp = $template =~ s,\[COPYRIGHT\],<p><p><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td height="21"><div align="center"><b><font size="1">Powered by</font></b> <a href="http://www.mojoscripts.com/products/mojofaq/"><b><font size="1">mojoFAQ 1.2 </font></b></a><br><font size="1" face="Tahoma">Copyright &copy; 2001</font> <a href="http://www.mojoscripts.com" target="_blank"><font size="1" face="Tahoma">mojoScripts.com</font></a></div></td></tr></table>,i;
	
###This is for media only
#	$template =~ s/\[options\]/&BuildMediaOptions()/egis;
	&PrintInternalHeader;
	print $template;
	unless($cp){ print qq|<p><p><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td height="21"><div align="center"><b><font size="2">Powered by</font></b> <a href="http://www.mojoscripts.com/products/mojofaq/"><b><font size="2">mojoFAQ 1.2 </font></b></a><br><font size="1" face="Tahoma">Copyright &copy; 2001</font> <a href="http://www.mojoscripts.com" target="_blank"><font size="1" face="Tahoma">mojoScripts.com</font></a></div></td></tr></table>|;	}
	&PrintInternalFooter;
	exit;
}
###########################################################################
sub PrintInternalHeader{
	my($cookie1, $cookie2, $cookie_duration);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n";
	$cookie_duration= time + 24 * 60 * 60 unless $cookie_duration;
	$cookie_username = "mojoMembername" unless $cookie_username;
	$cookie_password = "mojoPassword" unless $cookie_password;
	$cookie1 = cookie(-name=>$cookie_username?$cookie_username:mojoMembername,-value=>$MEMBER{username});
   $cookie2 = cookie(-name=>$cookie_password?$cookie_password:mojoPassword,-value=>$MEMBER{password});
	print header(-cookie=>[$cookie1,$cookie2]);
	print "\n";
}
###########################################################################
sub PrintInternalFooter{
	exit;
}
###########################################################################
sub GetReferer{
	my ($referer);
	if($FORM{referer}){	   $referer = $FORM{referer};			}
	elsif($ENV{HTTP_REFERER}){		$referer = $ENV{HTTP_REFERER};			}
	else{                      $referer = "http://".$ENV{HTTP_HOST};	}
	return $referer;
}
###########################################################################
1;