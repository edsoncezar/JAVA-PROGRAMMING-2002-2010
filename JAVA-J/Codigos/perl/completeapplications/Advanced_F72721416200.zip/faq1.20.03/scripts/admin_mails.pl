###########################################################################
# mojoProtector Personals Edition                                        #
###########################################################################
# First Released: November 2001   v1.0.00                                 #
# Last Released: February 2001    v1.15.19                                #
# ========================================================================#
# Software Distributed by:    http://www.mojoscripts.com                  #
# Software Written by:        Kevin Pham		kevin@mojoscripts.com        #
# Software Documented by		kevin Pham                                  #
# Copyright (c) 2001-2002 mojoSoft Internet Services - All Rights Reserved#
###########################################################################
# This program may be used and modified free of charge only by our        #
# registered members so long as this copyright notice and the comments    #
# above remain intact. If you obtained this software other than from our  #
# homepage, it is prohibited to use, not to mention modifying the code.      #
# By using this code you agree to indemnify mojosoft.net, Thi Pham, and   #
# all its programmers from any liability that might arise from its use.   #
#                                                                         #
# Selling the code for this program without prior written consent is      #
# expressly forbidden. Obtain permission before redistributing this       #
# software over the Internet or in any other medium. In all cases         #
# copyright and header must remain intact. We cannot be held responsible  #
# for any harm this may cause.                                            #
###########################################################################
#
##################################################################################
sub MailMain{
	if($FORM{'class'} eq "mailall"){			&MassMail;		}
	if($FORM{'class'} eq "massmail"){		&MassMail;		}
	elsif($FORM{'class'} eq "sendmail"){	&SendAMail;		}
	elsif($FORM{'class'}){	&PrintError("Do not Understand", $mj{'confuse'});	}
	&MassMail;
}
############################################################
sub MassMail{
	local(@block,$count, @ext, $error, $line, $email, @emails, @members, %MEMBER,
		 $mail_message, $message);
	if($FORM{load}){
		$FORM{message} = &FileReadString("$email_path/$FORM{file}");
	}
	elsif($FORM{'step'} eq "final" && $ADMIN{'mail'}){
		$message = "Please enter something to send to users. It is meaningless to send blank email" unless $FORM{'message'};
		&PrintError($mj{'error'}, $message) if $message;
		$FORM{'reply_to'} = $FORM{'reply_to'}?$FORM{'reply_to'}:$myemail;
		$FORM{'subject'}  = $FORM{'subject'}?$FORM{'subject'}:"Urgent::Please read";


		$line = &FileReadArray($CONFIG{email_db}) if (-f $CONFIG{email_db});
		@emails = @$line;
		foreach $email (@emails){
#			$email = join(", ", @emails);
			$message = &SendMail($myemail, $FORM{'reply_to'}, $email, $FORM{'subject'}, &ParseEmailTemplate($FORM{'message'}, \%MEMBER), $FORM{html_mail});
			if($message == "1"){	$count++;	}
			else{ $error++;}
		}
		$message = "<b>Message has been sent to all $count users</b>";# in account named $FORM{'account'}</b>";
		$message .= "<br>There were $error errors when sending</b>" if $error;
		&PrintError("Message Sent", $message);
	}
	elsif($FORM{'step'} eq "final"){ &PrintError($mj{'error'}, $mj{'deny'});	}
	else{ 	$message = "Your messages will not sent to blocked emails";	}
	&PrintMailAll($message);
}
##################################################################################
sub SendAMail{
	my($count1, $count2, $email, @emails,$line, $message, @tokens, $username, @usernames);
	$count1 = $count2 = 0;
	if($FORM{load}){
		$FORM{message} = &FileReadString("$email_path/$FORM{file}");
	}
	elsif($FORM{'step'} eq "final"){
		&PrintMail("Please enter your message in the message field") unless $FORM{'message'};
		$FORM{'to'} =~ s/\s+//g;
		@tokens = split(/\,/, $FORM{'to'});
		foreach $token (@tokens){
			if($token =~ /\@/){		push(@emails, $token);		}
			else{							push(@usernames, $token);	}
		}
		foreach $username (@usernames){
			if(-f "$member_path/$username.$CONFIG{member_ext}"){
				$line = &RetrieveMemberProfile("$member_path/$username.$CONFIG{member_ext}");
			} elsif(-f "$member_path/$username.$CONFIG{expire_ext}"){
				$line = &RetrieveMemberProfile("$member_path/$username.$CONFIG{expire_ext}");
			} elsif(-f "$amember_path/$username.$CONFIG{pending_ext}"){
				$line = &RetrieveMemberProfile("$member_path/$username.$CONFIG{pending_ext}");
			} elsif(-f "$amember_path/$username.$CONFIG{suspend_ext}"){
				$line = &RetrieveMemberProfile("$member_path/$username.$CONFIG{suspend_ext}");
			} else{
				next;
			}
			if(&SendMail($myemail, $myemail, $MEM{'email'}, $FORM{'subject'}, &ParseEmailTemplate($FORM{'message'}, \%MEM), $FORM{html_mail}) == "1"){
				$count1++;
			} 
		}
		$email = join(/, /, @emails);
		$FORM{'message'} =~ s/\[.+\]//g;
		if(&SendMail($myemail, $myemail, $email, $FORM{'subject'}, $FORM{'message'}, $FORM{html_mail})== "1"){
			$count2 = @emails;
		}
		$message ="Mail has been sent to $count1 usernames and $count2 email addresses";
	}
	&PrintMail($message);
}
##################################################################################
sub PrintMailAll{
	my(%HTML, $message);
	($message) = @_;
	$HTML{puldown_menu} = &BuildPullDownMenu(&DirectoryFiles($email_path), "file", $FORM{file});
	&PrintMojoHeader;
	print qq|
<table width="100%" border="1" cellspacing="0" cellpadding="5" align="center" bordercolor="#999999">
  <tr> 
    <td height="4" bgcolor="#5B9FBE" colspan="4"> 
      <div align="center"><font color="#FFFFFF"><b><i>Send Mails To All Members</i></b></font></div>
    </td>
  </tr>
  <tr> 
    <td height="10" colspan="4" valign="top"> 
      <div align="center"><font color=red><b>$message </b></font>
        <form name="mojoscripts" method="post" action="$admin_url">
          <table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#336666">
            <tr> 
              <td width="15%" valign="top" height="43"> 
                <div align="left"><b>Blocked <br>
                  Email Addresses<br>
                  </b></div>
              </td>
              <td width="85%" height="43"> 
                <textarea name="block" cols="60" rows="2" wrap="VIRTUAL">$FORM{'block'}</textarea>
              </td>
            </tr>
            <tr> 
              <td width="15%" valign="top"> 
                <div align="left"><b>Subject <br>
                  </b></div>
              </td>
              <td width="85%"> 
                <input type="text" name="subject" size="60" maxlength="100" value="$FORM{'subject'}">
              </td>
            </tr>
            <tr> 
              <td width="15%" valign="top"><b>Email Template</b></td>
              <td width="85%">$HTML{puldown_menu}
                <input type="submit" name="load" value=" Load template">
              </td>
            </tr>
            <tr> 
              <td width="15%" valign="top"> 
                <div align="left"><b>Message<i><br>
                  </i> </b></div>
              </td>
              <td width="85%" valign="top"> 
                <textarea name="message" cols="55" rows="10">$FORM{'message'}</textarea>
              </td>
            </tr><!--
            <tr> 
              <td width="15%" valign="top" height="3"><b>Send To</b></td>
              <td width="85%" height="3"> 
                <select name="member_type">
                  <option value="all" selected>All Members</option>
                  <option value="active">Active</option>
                  <option value="pending">Pending</option>
                  <option value="expired">Expired</option>
                  <option value="suspend">Suspended</option>
                </select>
              </td>
            </tr>
            <tr> 
              <td width="15%" valign="top" height="3"><b>Parsing</b></td>
              <td width="85%" height="3"> 
                <input type="radio" name="parse" value="no">
                None 
                <input type="radio" name="parse" value="partial" checked>
                Partial 
                <input type="radio" name="parse" value="complete">
                Complete</td>
            </tr>-->
            <tr> 
              <td width="15%" valign="top" height="5"><b>Email Type</b></td>
              <td width="85%" height="5"> 
                <input type="radio" name="html_mail" value="yes" checked>
                HTML email 
                <input type="radio" name="html_mail" value="0">
                Plain-Text email</td>
            </tr>
            <tr> 
              <td width="15%" valign="top" height="5">&nbsp;</td>
              <td width="85%" height="5">&nbsp;</td>
            </tr>
          </table>
           <input type="hidden" name="type" value="mail">
			 <input type="hidden" name="account" value="$FORM{'account'}">
          <input type="hidden" name="class" value="mailall">
          <input type="hidden" name="step" value="final">
          <input type="submit" name="sendmail" value=" Send">
          <input type="reset" name="reset" value=" Start Over ">
          <br>
          <br>
        </form>
      </div>
    </td>
  </tr>
</table>
<br>
|;
&PrintMojoFooter;
}
##################################################################################
sub PrintMail{
	my(%HTML, $message);
	($message) = @_;
	$HTML{puldown_menu} = &BuildPullDownMenu(&DirectoryFiles($email_path), "file", $FORM{file});
	
	&PrintMojoHeader;
	print qq|
<table width="100%" border="1" cellspacing="0" cellpadding="5" align="center" bordercolor="#999999">
  <tr> 
    <td height="4" bgcolor="#000000"> 
      <div align="center"><font color="#FFFFFF"><b><i>Send mail To A Member</i></b></font></div>
    </td>
  </tr>
  <tr> 
    <td height="254" width="95%" valign="top"> 
      <div align="center"><font color=red><b>$message </b></font>
        <form name="mojoscripts" method="post" action="$ENV{'SCRIPT_NAME'}">
          <table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tr> 
              <td width="14%" valign="top"> 
                <div align="left"><b>To</b></div>
              </td>
              <td width="86%"> 
                <textarea name="to" cols="60" rows="2">$FORM{'to'}</textarea>
                <br>
                Enter your members' email addresses or usernames, seperated by 
                a comma</td>
            </tr>
            <tr> 
              <td width="14%"> 
                <div align="left"><b>Subject </b></div>
              </td>
              <td width="86%"> 
                <input type="text" name="subject" size="60" maxlength="100" value="$FORM{'subject'}">
              </td>
            </tr>
            <tr bordercolor="#336666"> 
              <td width="15%" valign="top"> 
                <div align="left"><b>Email Template</b></div>
              </td>
              <td width="85%">$HTML{puldown_menu}
                <input type="submit" name="load" value=" Load template">
              </td>
            </tr>
            <tr> 
              <td width="14%" valign="top"> 
                <div align="left"><b>Message<br>
                  </b></div>
              </td>
              <td width="86%" valign="top"> 
                <textarea name="message" cols="55" rows="10">$FORM{'message'}</textarea>
              </td>
            </tr>
            <tr bordercolor="#336666"> 
              <td width="15%" valign="top" height="5"> 
                <div align="left"><b>Email Type</b></div>
              </td>
              <td width="85%" height="5"> 
                <input type="radio" name="html_mail" value="yes" checked>
                HTML email 
                <input type="radio" name="html_mail" value="0">
                Plain-Text email</td>
            </tr>
          </table>
          <input type="hidden" name="type" value="mail">
          <input type="hidden" name="account" value="$FORM{'account'}">
          <input type="hidden" name="class" value="sendmail">
          <input type="hidden" name="step" value="final">
          <input type="submit" name="sendmail" value=" Send ">
          <input type="reset" name="reset" value=" Start Over ">
          <br>
          <br>
        </form>
      </div>
    </td>
  </tr>
</table>

	|;
	&PrintMojoFooter;
}
######################################################################
sub PrintMailMain{
	&PrintMojoHeader;
	print qq|
	<table width="100%" border="1" cellspacing="0" cellpadding="3" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="4" valign="top" height="98"> 
      <div align="center"> 
        <p><b><font size="5">Communications<br>
          </font></b><font size="5"><font face="Tahoma" size="2">$mj{'program'} 
          $mj{'version'} provides you many means to communicate with your members. 
          You can send mass maillings to all your members, optionally block out 
          certain people if you wish. You can send mass billing to all members,</font><font size="5"><font face="Tahoma" size="2">optionally 
          block out certain people if you wish</font></font>....</font></p>
        <p align="left">To send mass mail to members, <a href="$admin_url?account=&type=mail&class=mailall">click 
          here</a><br>
          <br>
          To send mail to a certain members, <a href="$admin_url?account=&type=mail&class=sendmail">click 
          here</a></p>
        </div>
      </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
######################################################################
return 1;