###########################################################################
sub ThankyouTemplate{
	return qq|
<p><p>
<table width="100%" border="0" cellspacing="0" cellpadding="0" name="mojo">
  <tr> 
    <td height="17"> 
      <div align="center"><b>Your question has been sent. You should recieve our 
        answer shortly</b></div>
    </td>
  </tr>
  <tr> 
    <td height="4"> 
      <div align="center"> 
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </div>
    </td>
  </tr>
  <tr> 
    <td height="4"> 
      <div align="center"><b><font size="2">[COPYRIGHT]</font></b></div>
    </td>
  </tr>
</table>
|;
}
###########################################################################
return 1;