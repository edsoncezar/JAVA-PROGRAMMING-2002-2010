##############################################################################
sub CheckSession{
	&CleanupSessions;
	$ADMIN{'username'} ="";	
	&RetrieveSessionFile("$session_path/$ENV{'REMOTE_ADDR'}");
#	&PrintInternalHeader;
	#print "Your permissions are:";
	#foreach $key (keys %ADMIN){		print "<br>$key : $ADMIN{$key}";}
	&PrintAdminLogin unless ($ADMIN{username});
}	
##############################################################################
#delete session files that are more than 2 hours old
sub CleanupSessions{
	my($file, @files, $line, @lines);
	$line = &DirectoryFiles($session_path);
	@files = @$line;
	foreach $file (@files){
		if( time - (stat($file))[9] > 72000){	unlink $file;		}
	}
}
##############################################################################


1;