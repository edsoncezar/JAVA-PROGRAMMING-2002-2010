###########################################################################
sub PrintAdmin{
	&PrintMojoHeader;
	&BuildAdminStat;
	print qq|
 
<table width="600" border="1" cellspacing="0" cellpadding="0" align="center" bordercolor="#EFEFEF">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td> 
            <div align="center"><b>Welcome to the admin area of</b><br>
              <b><font size="4">$mj{program} $mj{version}</font></b></div>
          </td>
        </tr>
        <tr> 
          <td>You are logged in as <b>$ADMIN{username}</b>, position: <b>$ADMIN{group}. 
            </b>Please remember to logout when you're done to stop other who might 
            use your computer to have access to this restricted area.</td>
        </tr>
        <tr> 
          <td> 
            <div align="center"><b>Here is a short summary of stats</b></div>
          </td>
        </tr>
        <tr> 
          <td align=center><br><br><b>As a $ADMIN{group} position, you can do the following:</a></td>
        </tr>
        <tr> 
          <td bgcolor="#EFEFEF">$HTML_allowable</td>
        </tr>
        <tr> 
          <td>For more infor, please view a complete permissions by <a href="$admin_url?type=admin&class=group&action=edit&group=$ADMIN{group}">click 
            here</a></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<p>&nbsp;</p>

	|;
&PrintMojoFooter;
}
###########################################################################
sub PrintError{
	my($title, $message) = @_;
&PrintMojoHeader;
print qq|
	<table bgcolor="#bfbfbf" border=2 cellspacing=0 cellpadding=0 align="center">
  <tr> 
    <td height="131" valign="top">
<form> 
      <table border=0 cellspacing=0 cellpadding=2>
        <tr bgcolor="#00007f"> 
          <td colspan=3 height="9"> 
            <table width=100% border=0 cellspacing=0 cellpadding=0 height="8">
              <tr> 
                  <td height="2"><font face="Tahoma" color="#FFFFFF"><b>&nbsp;&nbsp;$title</b></font></td>
                  <td height="2" align="right"> 
                    <input type="button" value=" X " onClick="history.go(-1)" name="button">
                  &nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td width=25 height="26"><br>
          </td>
            <td width=400 height=26><font face="Arial, Helvetica" size=2><br>
              $message<br>
              <br>
              </font></td>
          <td width=25 height="26"><br>
          </td>
        </tr>
        <tr> 
          <td width=25 height="26">&nbsp;</td>
          <td width=10 align="center"> 
                <input type="button" value=" OK " onClick="history.go(-1)" name="button">
          </td>
          <td width=25 height="26">&nbsp;</td>
        </tr>
      </table></form>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}
###########################################################################
sub PrintAdminLogin{
	$message = shift if $_[0];
	$FORM{username} = cookie($cookie_username) unless $FORM{username};
#	$FORM{password} = $COOKIES{$cookie_password} unless $FORM{password};
	print "content-type:text/html\n\n";
	print qq|
	<table width="500" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td> 
      <form name="mojo" method="post" action="$admin_url">
        <input type="hidden" name="action" value="login">
        <input type="hidden" name="step" value="final">
        <table width="400" border="1" cellspacing="1" cellpadding="5" align="center" bordercolor="#000000">
          <tr bgcolor="#666666"> 
            <td colspan="2" height="23"> 
              <div align="center"> <font color="#FFFFFF">MojoScripts' <br>
                <font size="6">$mj{program} $mj{version}</font></font></div>
            </td>
          </tr>
          <tr bgcolor="#CCCCCC"> 
            <td colspan="2" height="23"> 
              <div align="center">$message</div>
            </td>
          </tr>
          <tr> 
            <td>$TXT{username}</td>
            <td> 
              <input type="text" name="username" value="$FORM{username}">
            </td>
          </tr>
          <tr> 
            <td>$TXT{password}</td>
            <td> 
              <input type="password" name="password" value="$FORM{password}">
            </td>
          </tr>
          <tr> 
            <td colspan="2"> 
              <div align="center"> 
                <input type="submit" name="login" value="  $TXT{login} ">
              </div>
            </td>
          </tr>
        </table>
        <div align="center"><br>
          Powered by <a href="http://mojoscripts.com/products/mojoclassified/">$mj{program} 
          $mj{version}</a></div>
        <div align="center"><font size="1" face="Tahoma">&copy; 2001-2002 <a href="http://mojoscripts.com">mojoscripts</a>. 
          All rights reservered.<br>
          Re-distribution, re-use any part of the sourcecode is forbidden.</font></div>
      </form>
    </td>
  </tr>
</table>
|;
exit;
}
###########################################################################
sub PrintMojoHeader{
	&PrintInternalHeader;
	print qq|
		<HTML>
<HEAD>
<TITLE>$page_title</TITLE>
<style>

<!--a:hover{color:bd7637; }-->
</style>

</HEAD>
<BODY BGCOLOR=#FFFFFF topmargin="0" leftmargin="0" marginheight=0 marginwidth=0 rightmargin=0 bottommargin=0 link="#000000" vlink="#000000">
<table width="100%" border="0" cellspacing="0" cellpadding="0"> <tr> <td height="442" valign="top"> 
<table width="100%" border=0 cellpadding=0 cellspacing=0 style="border-collapse: collapse" bordercolor="#111111" height="25"> 
<tr> <td bgcolor="#5B9FBE" height="22"> <div align="center"> <p><font color="#FFFF00"><b><font face="Tahoma" size="6">$mj{program} 
$mj{version}</font></b></font> &nbsp;<SCRIPT LANGUAGE="javascript" src="http://www.mojoscripts.com/cgi-bin/versions/mojo.cgi"> </SCRIPT></p></div></td></tr> <tr> <td bgcolor="#5B9FBE" height="2"> 
<div align="center"><b>by <a href="http://www.mojoscripts.com">mojoscripts.com</a></b></div></td></tr> 
<tr> <td bgcolor="#000000" height="2"></td></tr> </table><table border="1" cellpadding="0" cellspacing="0" width="100%" bordercolor="#5A9EBD"> 
<tr> <td width="161" valign="top" bgcolor="#FFFFFF" height="454"> <table border="0" cellspacing="0" width="162" style="border-collapse: collapse" bordercolor="#111111"> 
<tr> <td bgcolor="#5B9FBE" width="8">&nbsp;</td><td bgcolor="#5B9FBE" width="150"> <p align="center"><b> 
<font size="2" face="Verdana" color="#FFFFFF">Configurations</font> </b> </td></tr> 
<tr> <td valign="top" height="50" width="8">&nbsp;</td><td valign="top" height="50" width="150"> 
                  <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tr> 
                      <td height="2"><b><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=config">Configurations</a></font></b></td>
                    </tr>
                    <tr> 
                      <td><b><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=behavior">Behavior</a></font></b></td>
                    </tr>
                    <tr>
                      <td><b><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=display">Display</a></font></b></td>
                    </tr>
                    <tr> 
                      <td><b><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=email_subject">Email 
                        Subjects </a></font></b></td>
                    </tr>
                    
                    <tr> 
                      <td><b><font face="Tahoma" size="2"><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=email">Email 
                        Templates</a></font></font></b></td>
                    </tr>
                    <tr> 
                      <td><b><font face="Tahoma" size="2"><a href="$admin_url?type=config&class=html">HTML 
                        templates </a></font></b></td>
                    </tr>
                  </table>
                </td></tr> <tr bgcolor="#5A9EBD"> 
<td valign="top" height="17" width="8">&nbsp;</td><td valign="top" height="17" width="150"> 
<div align="center"><b><FONT FACE="Verdana" SIZE="2" COLOR="#FFFFFF">FAQ Topics</FONT></b></div></td></tr> 
<tr> <td valign="top" height="13" width="8">&nbsp;</td><td valign="top" height="13" width="150"> 
<table border="0" cellspacing="0" cellpadding="0" width="100%"> 
                    <tr> <td><b><font face="Tahoma" size="2"><a href="$admin_url?type=cat">View 
Topics</a></font></b></td></tr><tr><td><A HREF="$admin_url?type=question&action=waiting"><B>View 
Unanswered Questions</B></A></td></tr><tr><td><A HREF="$admin_url?type=cat&action=add"><B>Add 
New Topic</B></A></td></tr> </table></td></tr> <tr> <td bgcolor="#5B9FBE" width="8">&nbsp;</td><td bgcolor="#5B9FBE" width="150"> 
<div align="center"><b><font size="2" face="Verdana" color="#FFFFFF">Administrators</font></b></div></td></tr> 
<tr> <td valign="top" height="27" width="8">&nbsp;</td><td valign="top" height="27" width="150"> 
<table border="0" cellspacing="0" cellpadding="0" width="100%"> <tr> <td height="4"><font size="2" face="Tahoma"></font><b><font face="Tahoma" size="2"><a href="$admin_url?type=admin&class=admin">Administrators</a></font></b></td></tr> 
<tr> <td><font size="2" face="Tahoma"></font><b><font size="2" face="Tahoma"><a href="$admin_url?type=admin&class=group">Admin 
Groups</a></font></b></td></tr> <tr> <td height="2"><font size="2" face="Tahoma"></font><b><font size="2" face="Tahoma"><a href="$admin_url?action=logout">Logout</a></font></b></td></tr> 
</table></td></tr> <tr> <td bgcolor="#5B9FBE" width="8">&nbsp;</td><td bgcolor="#5B9FBE" width="150"> 
<div align="center"><b><font size="2" face="Verdana" color="#FFFFFF">Support</font></b></div></td></tr> 
<tr> <td height="51" width="8">&nbsp;</td><td height="51" width="150"> <table border="0" cellspacing="0" cellpadding="1" width="100%"> 
<tr> <td height="4"><font face="Tahoma" size="2"></font> <div align="right"><font face="Tahoma" size="2"><b><a href="$admin_url?type=support&class=faq">FAQ</a></b></font></div></td></tr> 
<tr> <td><font face="Tahoma" size="2"></font> <div align="right"><font face="Tahoma" size="2"><b><a href="$admin_url?type=support&class=documentation">Documentation</a></b></font></div></td></tr> 
<tr> <td height="2"><font face="Tahoma" size="2"></font> <div align="right"><font face="Tahoma" size="2"><b><a href="$admin_url?type=support&class=forum">Support 
Forum</a></b></font></div></td></tr> <tr> <td height="2"><font face="Tahoma" size="2"></font> 
<div align="right"><font face="Tahoma" size="2"><b><a href="$admin_url?type=support&class=rate">Rate 
This</a></b></font></div></td></tr> </table></td></tr> </table></td><td valign="top" bgcolor="#FFFFFF" height="454" width="852"> 
$HTML_location |; } 
########################################################################### 
sub PrintMojoFooter{ &PrintInternalFooter; print qq| </tr> </table></td></tr> 
<tr> <td height="16" bgcolor="#5A9EBD"> <div align="center"><font face="Tahoma" color="#FFFFFF">written 
and copyright &copy;2001-2002 <a href="http://www.mojoscripts.com"><font color="#0000FF">mojoscripts.com</font></a><br> 
<font size="1">no part of this package can be redistributed without our written 
expression.</font></font></div></td></tr> </table>
</BODY>
</HTML>
|;
exit;
}
###########################################################################
sub PrintInternalHeader{
	my($cookie1, $cookie2, $cookie_duration);
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "content-type: text/html\n";
	$cookie_duration= time + 24 * 60 * 60 unless $cookie_duration;
	$cookie_username = "mojoMembername" unless $cookie_username;
	$cookie_password = "mojoPassword" unless $cookie_password;
	$cookie1 = cookie(-name=>$cookie_username?$cookie_username:mojoMembername,-value=>$MEMBER{username});
   $cookie2 = cookie(-name=>$cookie_password?$cookie_password:mojoPassword,-value=>$MEMBER{password});
	print header(-cookie=>[$cookie1,$cookie2]);

##	&SetCookie($cookie_username, $MEMBER{'username'});
##	&SetCookie($cookie_password, $MEMBER{'password'}, $cookie_duration);
#	&SetCookie($cookie_account, $ACCOUNT{'account'});
#	&SetCookie("mojoscripts", $ENV{REMOTE_USER});
	print "\n";
}
###########################################################################
sub PrintInternalFooter{
	exit;
}
###########################################################################
sub PrintHeader{	&PrintMojoHeader;}
sub PrintFooter{	&PrintMojoFooter;}

1;