###########################################################################
sub AdminMain{
	if($FORM{'class'} eq "admin"){		&Administrator;	}
	elsif($FORM{'class'} eq "group"){	&AdminGroup;		}
	elsif($FORM{'class'}){			&PrintError($mj{'error'}, $mj{'confuse'});	}
	&PrintAdminMain;
}
###########################################################################
sub Administrator{
	if($FORM{'action'} eq "add"){				&AddAdmin;		}	
	elsif ($FORM{'action'} eq "delete"){	&DeleteAdmin; 	}
	elsif($FORM{'action'} eq "edit" ){		&EditAdmin;		}
	elsif ($FORM{'action'}){ 		&PrintError($mj{'error'}, $mj{'confuse'});		}
	&PrintAdministrator;
}
################################################################################
sub AddAdmin{
	$message ="";
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{admin_add}){
		$message = &CheckAdminInput;
		&PrintAddAdmin("$mj{'fix'}:<br>$message") if $message;
		&FileAppend($CONFIG{admin_database},"$FORM{'username'}|$FORM{'password'}|$FORM{'email'}|$FORM{'group'}");
####
		$FORM{date_create} = time;		
		$FORM{date_end} = time + 365 * 24 * 60 *60;
		$FORM{ad_allowed} = $FORM{media_allowed} = $CONFIG{ad_allowed};
#		&SaveMemberProfile($member_file, \%FORM);
###
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintAddAdmin;	}
}
################################################################################
sub DeleteAdmin{
	my(@contents, $line, @lines, @tokens);
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{admin_delete}){
		$line = &FileReadArray($CONFIG{admin_database});
		@lines = @$line;
		foreach $line(@lines){
			@tokens = split(/\|/, $line);
			next if($tokens[0] eq $FORM{'username'});
			push (@contents, $line);
		}
		&FileWrite($CONFIG{admin_database}, \@contents);
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintDeleteAdmin;	}
}
################################################################################
sub EditAdmin{
	my(@contents, $line, @lines, @tokens, $key, %MEM);
	$line = &FileReadArray($CONFIG{admin_database});
	@lines = @$line;
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{admin_edit}){
		$message = &CheckAdminInput;
		&PrintEditAdmin("$mj{'fix'}:<br>$message") if $message;
		&UpdateAdminInfo($CONFIG{admin_database}, \%FORM);
###
#		$line = &RetrieveMemberProfile($member_file);
#		%MEM = %line;
#		foreach $key (keys %MEM){	$FORM{$key} = $MEM{$key} unless $FORM{$key};	}
#		&SaveMemberProfile($member_file, \%FORM);
###
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{
		foreach $line(@lines){
			($myusername, $FORM{'password'}, $FORM{'email'}, $FORM{'admingroup'}) = split(/\|/, $line);
			if($myusername eq $FORM{'username'}){				&PrintEditAdmin;			}
		}
		$message = $mj{'admin18'};
	}	
}
################################################################################
sub UpdateAdminInfo{
	my($file, $ptr) = @_;
	my($line, @lines, %FORM, @contents);
	$line = &FileReadArray($file);
	@lines = @$line;
	%FORM = %$ptr;
	foreach $line(@lines){
		@tokens = split(/\|/, $line);
		if($tokens[0] eq $FORM{'username'}){
			push(@contents, "$FORM{'username'}|$FORM{'password'}|$FORM{'email'}|$FORM{'group'}|");
		}
		else{ push(@contents, $line); }
	}
	&FileWrite($file, \@contents);
}
################################################################################
sub BuildAdmin{
	my(@contents, $line, @lines, @tokens);
	$line	= &FileReadArray($CONFIG{admin_database});
	@lines = @$line;
	$html_users =qq|<table width="100%" border="1" bordercolor= "#000000" cellspacing="0" cellpadding="0" bgcolor="#CCCCCC">
                <tr><td>$TXT{'username'}</td>
                  <td bgcolor="#999999">$TXT{'group'}</td>
                  <td>$TXT{'email'}</td>
                  <td bgcolor="#999999">$TXT{'action'}</td>
                </tr> |;
	foreach $line(@lines){
		next if($line =~ /^\s+$/);
		@tokens = split(/\|/, $line);
		$html_users .= qq|<tr>
				<td>$tokens[0]</td>																			
				<td bgcolor="#999999">$tokens[3]</td>
				<td>$tokens[2]</td>
				<td bgcolor="#999999"><a href="$admin_url?account=$FORM{'account'}&type=admin&class=admin&action=edit&username=$tokens[0]&group=$tokens[3]"> $TXT{'edit'}</a>
				\| <a href="$admin_url?account=$FORM{'account'}&type=admin&class=admin&action=delete&username=$tokens[0]&group=$tokens[3]">$TXT{'delete'}</a></td>
				</tr> |;
	}
	$html_users .= qq| </table>|;
	return $html_users;
}
################################################################################
sub BuildAdminGroupMenu{
	my(@content, $group, $j, $line, @lines);
	$line = &FileReadArray($CONFIG{group_database});
	@lines = @$line;
 	foreach $line(@lines){
		($group, $j) = split(/\|/, $line);
		next unless $group;
		push(@content, $group);
	}
	return  popup_menu("group", \@content, $FORM{'group'});
}
##############################################################################
sub BuildAdminStat{
	my($cat, $line, @lines);
%ALLOWABLE =(
	"config"      =>qq|<b>modify configuration</b>|,
	"template"    =>qq|<b>modify HTML templates</b>|,
	"email"       =>qq|<b>modify email templates</b>|,
	"behavior"    =>qq|<b>modify program behavior</b>|,
	"group_add"   =>qq|<b>add new admin group</b>|,
	"group_delete"=>qq|<b>delete existing admin group</b>|,
	"group_edit"  =>qq|<b>edit existing admin group</b>|,
	"admin_add"   =>qq|<b>add new administrator</b>|,
	"admin_delete"=>qq|<b>delete existing administrator</b>|,
	"admin_edit"  =>qq|<b>edit existing administrator</b>|,
	"member_add"   =>qq|<b>add new member</b>|,
	"member_delete"=>qq|<b>delete existing member</b>|,
	"member_edit"  =>qq|<b>edit existing member</b>|,	
	"cat_add"     =>qq|<b>add new categories</b>|,
	"cat_delete"  =>qq|<b>delete existing categories</b>|,
	"cat_edit"    =>qq|<b>edit existing categories</b>|,
	"file_add"    =>qq|<b>add new files</b>|,
	"file_delete" =>qq|<b>delete existing files</b>|,
	"file_edit"   =>qq|<b>edit existing files</b>|,	
	"gw_add"     =>qq|<b>add new creditor</b>|,
	"gw_delete"  =>qq|<b>delete existing creditors</b>|,
	"gw_edit"    =>qq|<b>edit existing creditors</b>|,
	"db_add"     =>qq|<b>add new database fields</b>|,
	"db_delete"  =>qq|<b>delete existing database fields</b>|,
	"db_edit"    =>qq|<b>edit existing database fields</b>|,
	"member_approve"     =>qq|<b>approve new member application</b>|,
	"member_deny"        =>qq|<b>deny new member application</b>|,
	"member_expire"      =>qq|<b>expire/unexpire current member profiles</b>|,
	"ad_approve"     =>qq|<b>approve new posted ads</b>|,
	"ad_deny"        =>qq|<b>deny new posted ads</b>|,
	"ad_expire"      =>qq|<b>expire/unexpire posted ad</b>|,	
	"story_approve"     =>qq|<b>approve new member submitted stories</b>|,
	"story_deny"        =>qq|<b>deny new member submitted stories</b>|,
	"story_expire"      =>qq|<b>expire/unexpire submitted stories</b>|,
	"question_add"    =>qq|<b>add new questions/answer questions</b>|,
	"question_delete" =>qq|<b>delete existing questions</b>|,
	"question_edit"   =>qq|<b>edit existing questions</b>|,	
		
	"mail"        =>qq|<b>send (mass) emails to members</b>|,
	"bill"        =>qq|<b>send (mass) bills to members</b>|,
	"utils"       =>qq|<b>run utilities such as backup, restore, repair, etc</b>|,

	"backup"   =>qq|<b>Backup job</b>|,
	"restore"   =>qq|<b>restore job</b>|,
	"import"   =>qq|<b>import job</b>|,
	"export"   =>qq|<b>export job</b>|,
	"repair"   =>qq|<b>repair job</b>|);
	$db = &DefineAdminDatabase;
	@db = @$db;
	foreach $db (@db){
		$HTML_allowable .= qq|<li>$ALLOWABLE{$db}</li>| if ($ADMIN{$db});
	}
}
################################################################################
sub ExistAdminName{
	my $myusername = shift;
	my($line, @lines, @tokens);
	$line = &FileReadArray($admin_database);
	@lines = @$line;
	foreach $line(@lines){
      @tokens = split(/\|/,$line);
		return 1 if($tokens[0] eq $myusername);
	}
	return 1 if (-f $member_file or -f $pending_file or -f $expire_file);
	return 0;
}
################################################################################
sub CheckAdminInput{
	my $message="";
	if($FORM{'username'}){
		$message .= "<li>$TXT{'username'}: $mj{'admin17'}</li>" unless ($FORM{'username'} =~ /^[0-9a-zA-Z]+$/);
		$message .= "<li>$mj{'admin16'}</li>" unless (length($FORM{'username'}) >=4);
		$message .= "<li>$mj{'admin15'}</li>" if(&ExistAdminName($FORM{'username'}) && $FORM{'action'}=~ /add/i);
	} else{
		$message .= "<li>$mj{'missing_ip'}: $TXT{'username'}</li>" unless $FORM{'username'};
	}
	if($FORM{'password'}){
		$message .= "<li>$mj{'admin16'}</li>" unless (length($FORM{'password'}) >=4);
		$message .= "<li>$TXT{'password'}: $mj{'admin17'}</li>" unless ($FORM{'password'} =~ /^[0-9a-zA-Z]+$/);
	} else{
		$message .= "<li>$mj{'missing_ip'}: $TXT{'password'}</li>" unless $FORM{'password'};
	}	
	#$message .= "<li>$TXT{'password2'}</li>" unless $FORM{'password2'};
	#$message .= "<li>$TXT{'lname'}</li>" unless ($FORM{'password'} eq $FORM{'password2'});
	#$message .= "<li>$TXT{'lname'}</li>" unless $FORM{'last_name'};; 
	#$message .= "<li>$TXT{'fname'}</li>" unless $FORM{'first_name'};;
	$message .= "<li>$mj{'missing_ip'}: $TXT{'email'}</li>" unless $FORM{'email'};; 
	$message .= "<li>$mj{'missing_ip'}: $TXT{'group'}</li>" unless $FORM{'group'};;
	return $message;
}
################################################################################
sub PrintAddAdmin{
	$message = shift if $_[0];
	$html_group = &BuildAdminGroupMenu;
	$page_title = $mj{'admin11'};
	&PrintMojoHeader;
	&PrintAdminMiddle("add", $mj{'admin11'}, $TXT{'add'});
	&PrintMojoFooter;
}
################################################################################
sub PrintAdminMiddle{
	my($action, $title, $text) = @_;
	if($FORM{'action'} eq 'add'){
		$html_username =qq|<input type="text" name="username" size="20" maxlength="20" value="$FORM{'username'}">|;
	} else{
	 	$html_username =qq| $FORM{'username'}|;
		$html_hidden =qq|<input type="hidden" name="username" value="$FORM{'username'}">|;	
	}
	
	print qq|
<table  cellpadding="5" cellspacing="0" width="100%" align="center">
  <tr> 
    <td width="100%" valign="top" align="center" height="259"> 
      <form name="form1" method="post" action="$admin_url">
        <input type="hidden" name="account" value="$FORM{'account'}">
        <input type="hidden" name="type" value="admin">
        <input type="hidden" name="class" value="admin">
        <input type="hidden" name="action" value="$action">
		  $html_hidden
        <input type="hidden" name="step" value="final">
        <table  cellpadding="3" cellspacing="0" width="500" align="center" border="1" bordercolor="#DDDDDD" bgcolor="#FFFFFF">
          <tr> 
            <td colspan="2"> 
              <div align="center"><font size="5">$title</font><font size="4"><br>
                $mj{'admin10'}<br>
                </font></div><b><font color="#FF0000">$message 
                </font></b>
            </td>
          </tr>
          <tr> 
            <td width="26%" valign="top" align="center"> 
              <div align="right"><font face="Arial, Helvetica, sans-serif"><b>$TXT{'username'}</b></font></div>
            </td>
            <td width="74%" valign="top" align="center"> 
              <div align="left"> $html_username</div>
            </td>
          </tr>
          <tr> 
            <td width="26%" valign="top" align="center"> 
              <div align="right"><font face="Arial, Helvetica, sans-serif"><b>$TXT{'password'}</b></font></div>
            </td>
            <td width="74%" valign="top" align="center"> 
              <div align="left"> 
                <input type="password" name="password" size="20" maxlength="20" value="$FORM{'password'}">
                </div>
            </td>
          </tr>
          <tr> 
            <td width="26%" valign="top" align="center"> 
              <div align="right"><font face="Arial, Helvetica, sans-serif"><b>$TXT{'email'}</b></font></div>
            </td>
            <td width="74%" valign="top" align="center"> 
              <div align="left"> 
                <input type="text" name="email" size="50" maxlength="60" value="$FORM{'email'}">
              </div>
            </td>
          </tr>
          <tr> 
            <td width="26%" valign="top" align="center" height="15"> 
              <div align="right"><font face="Arial, Helvetica, sans-serif"><b>$TXT{'group'}</b></font></div>
            </td>
            <td width="74%" valign="top" align="center" height="15"> 
              <div align="left"> $html_group</div>
            </td>
          </tr>
          <tr> 
            <td colspan="2" valign="top" align="center" height="2"> 
              <input type="submit" name="add" value=" $text ">
              <input type="reset" name="reset" value=" $TXT{'reset'} ">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
################################################################################
sub PrintDeleteAdmin{
	$message = shift if $_[0];
	$page_title = $mj{'admin12'};
	&PrintMojoHeader;
	print qq|
	<table  cellpadding="5" cellspacing="0" width="100%" align="center">
  <tr> 
    <td width="100%" valign="top" align="center" height="118"> 
      <form name="mojo" method="post" action="$admin_url">
        <input type="hidden" name="account" value="$FORM{'account'}">
        <input type="hidden" name="type" value="admin">
        <input type="hidden" name="class" value="admin">
        <input type="hidden" name="action" value="delete">
		  <input type="hidden" name="username" value="$FORM{'username'}">
        <input type="hidden" name="step" value="final">
        <table  cellpadding="3" cellspacing="0" width="100%" align="center" border="1" bordercolor="#DDDDDD" bgcolor="#FFFFFF">
          <tr> 
            <td> 
              <div align="center"><font size="5">$mj{'admin12'}: $FORM{'username'}</font><font size="4"><br>
                <font color="#0000FF">$message </font></font></div>
            </td>
          </tr>
          <tr> 
            <td valign="top" align="center" height="7"> 
              <div align="center"><b>$mj{'admin14'}</b></div>
            </td>
          </tr>
          <tr> 
            <td valign="top" align="center"> 
              <input type="submit" name="delete" value=" $TXT{'delete'} ">
              <input type="submit" name="cancel" value=" $TXT{'cancel'} ">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
&PrintMojoFooter;
}
################################################################################
sub PrintEditAdmin{
	$message = shift if $_[0];
	$html_group = &BuildAdminGroupMenu;
	$page_title = $mj{'admin13'};
	&PrintMojoHeader;
	&PrintAdminMiddle("edit", $mj{'admin13'}, $TXT{'edit'});
	&PrintMojoFooter;
}
################################################################################
sub PrintAdministrator{
	$html_admin = &BuildAdmin;
	&PrintMojoHeader;
	print qq|
<table border="1" cellpadding="5" cellspacing="0" width="100%" align="center" bordercolor="#DDDDDD">
  <tr> 
    <td height="6"> 
      <div align="center"><font size="5">$mj{'admin8'}</font><font size="4"><font size="2"><br>
        $mj{'admin9'}<br>
        <font color="#FF00FF"><b><font size="3">$message </font></b></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td height="6" bgcolor="#CCCCCC"> 
      <div align="center">$html_admin</div>
    </td>
  </tr>
  <tr> 
    <td valign="top" align="center"> 
      <form  method="post" action="$admin_url">
        <input type="hidden" name="account" value="$FORM{'account'}">
        <input type="hidden" name="type" value="admin">
        <input type="hidden" name="class" value="admin">
        <input type="hidden" name="action" value="add">
        <input type="submit" name="add" value=" $mj{'admin11'} ">
      </form>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}
###########################################################################
sub PrintAdminMain{
	&PrintMojoHeader;
	print qq|
	<table width="100%" border="1" cellspacing="0" cellpadding="3" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="4" valign="top" height="166"> 
      <div align="center"> 
        <p><b><font size="5">$TXT{'administrators'}<br>
          <font color="#FF0000" size="4">$message </font><br>
          </font></b><font size="5"><font face="Tahoma" size="2">$mj{'admin1'}</font><font size="5"><font face="Tahoma" size="2">.</font></font></font></p>
      </div>
      <ol>
        <li><a href="$admin_url?account=$FORM{'account'}&type=admin&class=admin">$mj{'admin20'}</a>: 
          $mj{'admin21'}.</li>
        <li><a href="$admin_url?account=$FORM{'account'}&type=admin&class=admin&action=add">$mj{'admin22'}</a>: 
          $mj{'admin23'}.</li>
        <li><a href="$admin_url?account=$FORM{'account'}&type=admin&class=group">$mj{'admin30'}</a>: 
          $mj{'admin31'}.</li>
        <li><a href="$admin_url?account=$FORM{'account'}&type=admin&class=group&action=add">$mj{'admin32'}:</a> 
          $mj{'admin33'}</li>
      </ol>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
################################################################################
##								ADMIN GROUP
################################################################################
sub AdminGroup{
	if($FORM{'action'} eq "add"){				&AddAdminGroup;		}	
	elsif ($FORM{'action'} eq "delete"){	&DeleteAdminGroup; 	}
	elsif($FORM{'action'} eq "edit" ){		&EditAdminGroup;		}
	elsif ($FORM{'action'}){ 		&PrintError($mj{'error'}, $mj{'confuse'});		}
	&PrintAdminGroups;
}
################################################################################
sub AddAdminGroup{
	$message ="";
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{group_add}){
		unless ($FORM{'group'}){	$message .=qq|<li>$mj{'admin37'}</li>|;	}
		else{	$message .=qq|<li>$mj{'invalid_ip'}: $mj{'admin17'}</li>| unless ($FORM{'group'} =~ /^[0-9a-zA-Z]+$/);}
		&PrintAddAdminGroup("$mj{'fix'}:<br>$message") if $message;
		&SaveAdminDatabase($CONFIG{group_database}, $FORM{'group'}, \%FORM);
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintAddAdminGroup;	}
}
################################################################################
sub DeleteAdminGroup{
	my(@contents, $line, @lines, @tokens);
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{group_delete}){
		$line = &FileReadArray($CONFIG{group_database});
		@lines = @$line;
		foreach $line(@lines){
			($mygroup,$junk) = split(/\|/, $line);
			next if(lc($mygroup) eq lc($FORM{'group'}));
			push(@contents, $line);
		}
		&FileWrite($CONFIG{group_database}, \@contents);
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintDeleteAdminGroup;	}
}
################################################################################
sub EditAdminGroup{
	my(@contents, $line, @lines, @tokens, $writeline);
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{group_edit}){
		&SaveAdminDatabase($CONFIG{group_database}, $FORM{'group'}, \%FORM);
		$message = $mj{'success'};
	}
	elsif($FORM{'step'} eq "final"){		&PrintError($mj{'error'}, $mj{'deny'});	}
	else{	&PrintEditAdminGroup;	}
}
################################################################################
sub BuildAdminGroup{
	my($line, @lines, @tokens, $html_groups);
	$line = &FileReadArray($CONFIG{group_database});
	@lines = @$line;
	$TXT{group} = ucfirst($TXT{group});
	$html_groups =qq|<table width=100%><tr bgcolor="#DDDDDD"><td>$TXT{group}<td>$TXT{permissions}</td><td>$TXT{actions}</td></tr>|;
	foreach $line (@lines){
		@tokens = split(/\|/, $line);
		$html_groups.=qq|<tr><td>$tokens[0]</td><td>$tokens[1]</td>
			<td><a href="$admin_url?account=$FORM{'account'}&type=admin&class=group&action=delete&group=$tokens[0]">$TXT{delete}</a>
			\| <a href="$admin_url?account=$FORM{'account'}&type=admin&class=group&action=edit&group=$tokens[0]">$TXT{edit}</a></td></tr>|;
	}
	$html_groups .= qq|</table>|;
	return $html_groups;
}
################################################################################
sub ExistAdminGroup{
	my $mygroup = shift;
	my($group, $line, @lines);
	$line = &FileReadArray($CONFIG{group_database}, "ExistGroup");
	@lines = @$line;
	foreach $line(@lines){
      ($group,$junk) = split(/\|/,$line);
		return 1 if($group eq $mygroup);
	} 
	return 0;
}
###########################################################################
sub PrintAdminGroups{
	$message = shift if $_[0];
	$html_admin_groups = &BuildAdminGroup;
	&PrintMojoHeader;
	print qq|
	<table  cellpadding="5" cellspacing="0" width="100%" align="center" border="1" bordercolor="#DDDDDD">
  <tr> 
    <td height="13" bgcolor="#FFFFFF"> 
      <div align="center"><font size="5">$mj{'admin30'}</font><font size="4"><font size="2"><br>
        <font color="#FF00FF"><b><font size="3" face="Geneva, Arial, Helvetica, san-serif" color="#FF0000">$message 
        </font></b></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td height="3" bgcolor="#CCCCCC"> 
      <div align="center">$html_admin_groups</div>
    </td>
  </tr>
  <tr> 
    <td height="32" bgcolor="#FFFFFF"> 
      <form name="form" method="post" action="$ENV{'SCRIPT_NAME'}">
        <div align="center"> 
          <input type="hidden" name="account" value="$FORM{'account'}">
          <input type="hidden" name="type" value="admin">
          <input type="hidden" name="class" value="group">
          <input type="hidden" name="action" value="add">
          <br>
          <input type="submit" name="add" value=" $mj{'admin32'}">
        </div>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
################################################################################
sub PrintAddAdminGroup{
	$message = shift if $_[0];
	$page_title = $mj{'admin32'};
	&PrintMojoHeader;
	&PrintAdminGroupMiddle("add", $mj{'admin32'}, $TXT{'add'});
	&PrintMojoFooter;
}
###########################################################################
sub PrintDeleteAdminGroup{
	&PrintMojoHeader;
	print qq|
	<table  cellpadding="5" cellspacing="0" width="100%" align="center">
  <tr> 
    <td width="100%" valign="top" align="center" height="126"> 
      <form name="form" method="post" action="$admin_url">
        <input type="hidden" name="account" value="$FORM{'account'}">
        <input type="hidden" name="type" value="admin">
        <input type="hidden" name="class" value="group">
        <input type="hidden" name="group" value="$FORM{'group'}">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="step" value="final">
        <table  cellpadding="5" cellspacing="0" width="500" align="center" border="1" bordercolor="#DDDDDD">
          <tr> 
            <td> 
              <div align="center"><font size="4">$mj{'admin34'}: $FORM{'group'}<br>
                <font color="#0000FF">$message </font></font></div>
            </td>
          </tr>
          <tr> 
            <td valign="top" align="center" height="7"> 
              <div align="center"><b>$mj{'sure'}</b></div>
            </td>
          </tr>
          <tr> 
            <td valign="top" align="center"> 
              <input type="submit" name="delete" value=" $TXT{'yes'} ">
              <input type="submit" name="cancel" value=" $TXT{'no'} ">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
################################################################################
sub PrintEditAdminGroup{
	$message = shift if $_[0];
	$page_title = $mj{'admin35'};
	&PrintMojoHeader;
	&PrintAdminGroupMiddle("edit", $mj{'admin35'}, $TXT{'edit'});
	&PrintMojoFooter;
}
###########################################################################
sub PrintAdminGroupMiddle{
	my($action, $title) = @_;
	if($FORM{'action'} eq 'add'){
		$html_admin_group =qq|$mj{'admin36'}: <input type="text" name="group" size="20" maxlength="20" value="$FORM{'group'}">|;
		$line = &DefineAdminDatabase;
		@lines = @$line;
		for(my $i=0; $i<@lines; $i++){
			if($i <13){		$TEMP{$lines[$i]} = 0;	}
			else{					$TEMP{$lines[$i]} = 1;	}
		}
	} else{
	 	$html_admin_group =qq| $FORM{'group'}|;
		$html_hidden =qq|<input type="hidden" name="group" value="$FORM{'group'}">|;	
		%TEMP = &RetrieveAdminDatabase($CONFIG{group_database}, $FORM{'group'});
	}
	foreach $key (keys %TEMP){
		if($TEMP{$key}){	$HTML{$key} =qq|<input type=checkbox name="$key" value="1" checked>|;}
		else{					$HTML{$key} =qq|<input type=checkbox name="$key" value="1">|;}
	}
	print qq|
	<table  cellpadding="5" cellspacing="0" width="100%" align="center">
  <tr> 
    <td width="100%" valign="top" align="center" height="466"> 
      <form name="form1" method="post" action="$admin_url">
        <input type="hidden" name="account" value="$FORM{'account'}">
        <input type="hidden" name="type" value="admin">
        <input type="hidden" name="class" value="group">
        <input type="hidden" name="action" value="$action">
		  $html_hidden
        <input type="hidden" name="step" value="final">
        <table  cellpadding="5" cellspacing="0" width="100%" align="center">
          <tr> 
            <td width="100%" valign="top" align="center" height="30"><font color="#000000" size="5"><b><i> 
              $title<br>
              </i></b></font><font color="#000000">$html_admin_group</font><font color="#000000" size="5"><b><i><br>
              </i></b></font><font color="#000000"><b><font color="#FF0000">$message 
              </font></b></font></td>
          </tr>
          <tr> 
            <td width="100%" valign="top" align="center" height="312"> 
              <table width="100%"  cellspacing="0" cellpadding="2" bordercolor="#CCCCCC" border="1">
                <tr> 
                  <td width="524" bgcolor="#00659C"><b><font size="4" color="#FFFFFF">$mj{admin40}</font></b></td>
                  <td width="107" bgcolor="#00659C"><b><font size="4" color="#FFFFFF">$TXT{config}</font></b></td>
                  <td width="145" bgcolor="#00659C"><b><font size="4" color="#FFFFFF">$TXT{template}</font></b></td>
                  <td width="80" bgcolor="#00659C"><b><font size="4" color="#FFFFFF">$TXT{email}</font></b></td>
                  <td width="80" bgcolor="#00659C"><b><font size="4" color="#FFFFFF">$TXT{behavior}</font></b></td>
                </tr>
                <tr> 
                  <td width="524"><b>$mj{admin41} </b></td>
                  <td width="107"><font size="2">$HTML{config}</font></td>
                  <td width="145"><font size="2">$HTML{template}</font></td>
                  <td width="80"><font size="2">$HTML{email}</font></td>
                  <td width="80"><font size="2">$HTML{behavior}</font></td>
                </tr>
              </table>
              <br>
              <table width="100%"  cellspacing="0" cellpadding="2" bordercolor="#CCCCCC" border="1">
                <tr bgcolor="#00659C"> 
                  <td width="524"><b><font size="4" color="#FFFFFF">$mj{admin50}</font></b></td>
                  <td width="107"><b><font size="4" color="#FFFFFF">$TXT{add}</font></b></td>
                  <td width="145"><b><font size="4" color="#FFFFFF">$TXT{edit}</font></b></td>
                  <td width="161"><b><font size="4" color="#FFFFFF">$TXT{delete}</font></b></td>
                </tr>
                <tr> 
                  <td width="524"><b>$mj{admin51} </b></td>
                  <td width="107"><font size="2">$HTML{group_add}</font></td>
                  <td width="145"><font size="2">$HTML{group_edit}</font></td>
                  <td width="161"><font size="2">$HTML{group_delete}</font></td>
                </tr>
                <tr> 
                  <td width="524"><b>$mj{admin52}</b></td>
                  <td width="107"><font size="2">$HTML{admin_add}</font></td>
                  <td width="145"><font size="2">$HTML{admin_edit}</font></td>
                  <td width="161"><font size="2">$HTML{admin_delete}</font></td>
                </tr><!--
                <tr> 
                  <td width="524"><b>$mj{admin53}</b></td>
                  <td width="107"><font size="2">$HTML{member_add}</font></td>
                  <td width="145"><font size="2">$HTML{member_edit}</font></td>
                  <td width="161"><font size="2">$HTML{member_delete}</font></td>
                </tr>-->
                <tr> 
                  <td width="524"><b>$mj{admin54}</b></td>
                  <td width="107"><font size="2">$HTML{cat_add}</font></td>
                  <td width="145"><font size="2">$HTML{cat_edit}</font></td>
                  <td width="161"><font size="2">$HTML{cat_delete}</font></td>
                </tr>
                <tr> 
                  <td width="524"><b>$mj{admin55}</b></td>
                  <td width="107"><font size="2">$HTML{question_add}</font></td>
                  <td width="145"><font size="2">$HTML{question_edit}</font></td>
                  <td width="161"><font size="2">$HTML{question_delete}</font></td>
                </tr><!--
                <tr> 
                  <td width="524"><b>$mj{admin56}</b></td>
                  <td width="107"><font size="2">$HTML{gw_add}</font></td>
                  <td width="145"><font size="2">$HTML{gw_edit}</font></td>
                  <td width="161"><font size="2">$HTML{gw_delete}</font></td>
                </tr>
                <tr> 
                  <td width="524"><b>$mj{admin57}</b></td>
                  <td width="107"><font size="2">$HTML{db_add}</font></td>
                  <td width="145"><font size="2">$HTML{db_edit}</font></td>
                  <td width="161"><font size="2">$HTML{db_delete}</font></td>
                </tr>-->
              </table><!--
              <table width="100%"  cellspacing="0" cellpadding="2" bordercolor="#CCCCCC" border="1">
                <tr bgcolor="#00659C"> 
                  <td width="523" height="30"><b><font size="4" color="#FFFFFF">$mj{admin60}</font></b></td>
                  <td width="142" height="30"><b><font size="4" color="#FFFFFF">$TXT{approve}</font></b></td>
                  <td width="135" height="30"><b><font size="4" color="#FFFFFF">$TXT{deny}</font></b></td>
                  <td width="137" height="30"><b><font size="4" color="#FFFFFF">$TXT{expire}</font></b></td>
                </tr>
                <tr> 
                  <td width="523"><b>$mj{admin61} </b></td>
                  <td width="142"><font size="2">$HTML{member_approve}</font></td>
                  <td width="135"><font size="2">$HTML{member_deny}</font></td>
                  <td width="137"><font size="2">$HTML{member_expire}</font></td>
                </tr>
                <tr> 
                  <td width="523"><b>$mj{admin62}</b></td>
                  <td width="142"><font size="2">$HTML{ad_approve}</font></td>
                  <td width="135"><font size="2">$HTML{ad_deny}</font></td>
                  <td width="137"><font size="2">$HTML{ad_expire}</font></td>
                </tr>
                <tr> 
                  <td width="523"><b>$mj{admin63}</b></td>
                  <td width="142"><font size="2">$HTML{story_approve}</font></td>
                  <td width="135"><font size="2">$HTML{story_deny}</font></td>
                  <td width="137"><font size="2">$HTML{story_expire}</font></td>
                </tr>
              </table>-->
              <br>
              <!--
              <table width="100%" border="1" cellspacing="0" cellpadding="3" bordercolor="#CCCCCC">
                <tr bgcolor="#00659C"> 
                  <td><b><font size="4" color="#FFFFFF">$mj{admin70}</font></b></td>
                  <td width="50"><b><font color="#FFFFFF" size="4" face="Arial, Helvetica, sans-serif">$TXT{yes}</font></b></td>
                </tr>
                <tr> 
                  <td>$mj{admin71}</td>
                  <td >$HTML{mail}</td>
                </tr>
                 <tr> 
                  <td>$mj{admin72}</td>
                  <td >$HTML{bill}</td>
                </tr>
                <tr> 
                  <td>$mj{admin73}</td>
                  <td >$HTML{utils}</td>
                </tr>
                <tr> 
                  <td>$mj{admin74}</td>
                  <td >$HTML{backup}</td>
                </tr>
                <tr> 
                  <td>$mj{admin75}</td>
                  <td >$HTML{restore}</td>
                </tr>
                <tr> 
                  <td>$mj{admin76}</td>
                  <td >$HTML{import}</td>
                </tr>
                <tr> 
                  <td>$mj{admin77}</td>
                  <td >$HTML{export}</td>
                </tr>
                <tr> 
                  <td>$mj{admin78}</td>
                  <td >$HTML{repair}</td>
                </tr>
              </table>-->
            </td>
          </tr>
          <tr> 
            <td width="100%" valign="top" align="center" height="2"> 
              <input type="submit" name="edit" value="$TXT{'save'}">
              <input type="reset" name="reset" value="$TXT{'reset'}">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
}
###########################################################################
1;