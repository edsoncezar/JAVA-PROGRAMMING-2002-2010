###########################################################################
# mojoGallery                                                             #
###########################################################################
# First Released: December 2001   v1.0.00                                 #
# Last Released: March 2001       v1.10.00                                #
# ========================================================================#
# Software Distributed by:    http://www.mojoscripts.com                  #
# Software Written by:        Kevin Pham		kevin@mojoscripts.com        #
# Software Documented by		kevin Pham                                  #
# Copyright (c) 2001-2002 mojoSoft Internet Services - All Rights Reserved#
###########################################################################
# This program may be used and modified free of charge only by our        #
# registered members so long as this copyright notice and the comments    #
# above remain intact. If you obtained this software other than from our  #
# homepage, it is prohibited to use, not to mention modifying the code.      #
# By using this code you agree to indemnify mojosoft.net, Thi Pham, and   #
# all its programmers from any liability that might arise from its use.   #
#                                                                         #
# Selling the code for this program without prior written consent is      #
# expressly forbidden. Obtain permission before redistributing this       #
# software over the Internet or in any other medium. In all cases         #
# copyright and header must remain intact. We cannot be held responsible  #
# for any harm this may cause.                                            #
###########################################################################
#
###########################################################################
##									ADMIN
###########################################################################
sub DefineAdminDatabase{
	my(@admin) =(
	"config",
	"template",
	"email",
	"behavior",
	"group_add",
	"group_delete",
	"group_edit",
	"admin_add",
	"admin_delete",
	"admin_edit",	
#	"member_add",
#	"member_delete",
#	"member_edit",
	"cat_add",
	"cat_delete",
	"cat_edit",		
	"question_add",
	"question_edit",
	"question_delete",
#	"gw_add",
#	"gw_delete",
#	"gw_edit",
#	"db_add",
#	"db_delete",
#	"db_edit",	
#	"member_approve",
#	"member_deny",
#	"member_expire",
#	"ad_approve",
#	"ad_deny",
#	"ad_expire",
#	"story_approve",
#	"story_deny",
#	"story_expire",
#	"mail",				#send mail
#	"bill",				#send bill and charge
#	"utils",				#do utils
#	"backup",		#approve and add
#	"export",
#	"import",
#	"restore",
#	"repair"
	);
	return \@admin;
}
###########################################################################
## input a admin filename and a goup name, output admin permission
sub RetrieveAdminDatabase{
	my($def, @def, $line, @lines, $filename, $string, @tokens, %PER);
	($filename, $group) = @_;
	&PrintFatal($mj{'error'}, "$mj{'file13'}:$filename", "database.pl", (caller)[1], (caller)[2]) unless (-f $filename);
	$line = &FileReadArray($filename);
	@lines = @$line;
	$string ='000000000000000000000000000000000000000';
	foreach $line (@lines){
		@tokens = split(/\|/, $line);
		if($tokens[0] eq $group){
			$string = $tokens[1];
			last;
		}
	}
	@lines = split(//, $string);
	$def = &DefineAdminDatabase;
	@def = @$def;
	#&PrintInternalHeader;
	for(my $i=0; $i< @def; $i++){
		$PER{$def[$i]} = $lines[$i];
		#print "<br>$i ; $def[$i]; $ADMIN{$def[$i]}: $lines[$i]:-->$group ;$string";
	}
	return %PER;
}
###########################################################################
#input the filename, $group and save it to the database
sub SaveAdminDatabase{
	my($add_new,@contents,$def, @def, $found,$line, @lines, $filename, $group, %PER);
	($filename, $group, $admin) =@_;
	%PER = %$admin;
	###determine the admin string
	$def = &DefineAdminDatabase;
	@def = @$def;
	$string ="$group|";
	foreach $def (@def){
		if($PER{$def}){	$string .= "1";	}
		else				 {	$string .= "0";	}
	}
	##now determine the group to change
	$line = &FileReadArray($filename);
	@lines = @$line;
	@contents = ();
	foreach $line (@lines){
		@tokens = split(/\|/, $line);
		if($tokens[0] eq $group){	push(@contents, $string);	$found=1	}
		else{								push(@contents, $line);			}
	}
	unless($found){	push(@contents, $string);}
	&FileWrite($filename, \@contents);
	chmod(0777, $filename);
}
###########################################################################
sub DefineCategoryDatabase{
	my(@db) =(
	'ID',
	'name',
	'icon',
	'ricon',
	'template',
	'moderator',
	'description');
	return \@db;
}
###########################################################################
sub RetrieveCategoryDatabase{
	my($def, @def, $line, @lines, $filename, %DB);
	$filename = shift;
	if(-f $filename){
		$line = &FileReadArray($filename);
		@lines = @$line;
		$def = &DefineCategoryDatabase;
		@def = @$def;
		for(my $i=0; $i< @def; $i++){
			$DB{$def[$i]} = $lines[$i];
		}
	}
	else{
		$DB{name} = &GetLastDirectory(&GetParentDirectory($filename));
	}
	if($DB{ricon}){					$DB{icon_url} = qq|<img src="$DB{ricon}" border=0>|;	}
	elsif($DB{icon} =~ /http:\/\//){	$DB{icon_url} = qq|<img src="$DB{icon}" border=0>|;	}
	elsif($DB{icon}){		$DB{icon_url} = qq|<img src="$image_url/$DB{icon}" border=0>|;	}
	else{						$DB{icon_url} =qq||;	}
	return \%DB;
}
###########################################################################
sub SaveCategoryDatabase{
	my(@contents,$def, @def, $line, @lines, $filename, %DB);
	($filename, $line) = @_;
	%DB = %$line;
	$def = &DefineCategoryDatabase;
	@def = @$def;
	foreach $def (@def){
		push(@contents, $DB{$def});
	}
	&FileWrite($filename, \@contents);
	chmod(0777, $filename);
}
###########################################################################
###########################################################################
sub DefineQuestionDatabase{
	my(@db)=('ID','s_time','s_name', 's_email','s_IP','r_name','r_email','r_IP','rate',
	'view','vote','question','answer','comment','related');
	return \@db;
}
###########################################################################
sub RetrieveQuestionDatabase{
	my($def, @def, $line, @lines, $filename, %DB, $message);
	($filename) = @_;
	return \%DB unless (-f $filename);
	$line = &FileReadArray($filename);
	@lines = @$line;
	$def = &DefineQuestionDatabase;
	@def = @$def;
	for(my $i=0; $i< @def; $i++){		$DB{$def[$i]} = $lines[$i];	}
	$DB{s_date} = &FormatTime($DB{s_time}, "mdy");
	$DB{r_date} = &FormatTime($DB{r_time}, "mdy");
	return \%DB;
}
###########################################################################
sub SaveQuestionDatabase{
	my(@content,@def, $line, @lines, $filename, %DB, $string, $time);
	($filename, $line) = @_;
	%DB = %$line;
	$DB{question} =~ s/\n/<br>/ig;
	$DB{answer} =~ s/\n/<br>/ig;
	$DB{comment} =~ s/\n/<br>/ig;
	$def = &DefineQuestionDatabase;
	@def = @$def;
	foreach $def (@def){		push(@content, $DB{$def});	}
	&FileWrite($filename, \@content);
	return chmod(0777, $filename);
}
###########################################################################
###########################################################################
#								SESSIONS
###########################################################################
sub RetrieveSessionFile{
	my($def, @def, $i,$line, @lines, $filename);
	$filename = shift;
	return unless (-f $filename);
	$line = &FileReadArray($filename);
	@lines = @$line;
	$def = &DefineAdminDatabase;
	@def = @$def;
	for($i=0; $i< @def; $i++){
		$ADMIN{$def[$i]} = $lines[$i];
	}
	$ADMIN{'username'} = $lines[$i++];
	$ADMIN{'email'} = $lines[$i++];
	$ADMIN{'group'} = $lines[$i++];
}
###########################################################################
sub SaveSessionFile{
	my(@contents,$def, @def, $line, @lines, $filename);
	$filename = shift;
	$def = &DefineAdminDatabase;
	@def = @$def;
	foreach $def (@def){
		push(@contents, $ADMIN{$def});
	}
	push(@contents, $ADMIN{'username'});
	push(@contents, $ADMIN{'email'});
	push(@contents, $ADMIN{'group'});
	&FileWrite($filename, \@contents);
	chmod(0777, $filename);
}
###########################################################################

1;