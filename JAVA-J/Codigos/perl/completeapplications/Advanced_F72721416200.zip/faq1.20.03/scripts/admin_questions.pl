###########################################################################
# mojoClassified Personals Edition                                        #
###########################################################################
# First Released: December 2001   v1.0.00                                 #
# Last Released: February 2001    v1.21.06                                #
# ========================================================================#
# Software Distributed by:    http://www.mojoscripts.com                  #
# Software Written by:        Kevin Pham		kevin@mojoscripts.com        #
# Software Documented by		kevin Pham                                  #
# Copyright (c) 2001-2002 mojoSoft Internet Services - All Rights Reserved#
###########################################################################
# This program may be used and modified free of charge only by our        #
# registered members so long as this copyright notice and the comments    #
# above remain intact. If you obtained this software other than from our  #
# homepage, it is prohibited to use, not to mention modifying the code.   #
# By using this code you agree to indemnify mojosoft.net, Thi Pham, and   #
# all its programmers from any liability that might arise from its use.   #
#                                                                         #
# Selling the code for this program without prior written consent is      #
# expressly forbidden. Obtain permission before redistributing this       #
# software over the Internet or in any other medium. In all cases         #
# copyright and header must remain intact. We cannot be held responsible  #
# for any harm this may cause.                                            #
###########################################################################
# manage questions, what else you expect?                                 #
###########################################################################
###########################################################################
sub QuestionMain{
	local($message);
	if($FORM{'action'} eq 'add'){		&AddQuestion;	}
	elsif($FORM{'action'} eq 'edit'){		&EditQuestion;	}
	elsif($FORM{'action'} eq 'delete'){		&DeleteQuestion;	}
	elsif($FORM{'action'} eq 'answer'){		&AnswerQuestion;	}
	elsif($FORM{'action'} eq "waiting"){	&WaitingQuestion;	}
	if($FORM{cat}){	&BuildQuestions($message);	}
	else{	&DisplayCategories($message);	}
}
############################################################
sub AddQuestion{
	my($time);
	$message = "";
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{question_add}){
		$message = &CheckQuestionInput;
		&PrintAddQuestion($message) if $message;
		$time= time;
		$FORM{s_time} = $FORM{r_time} = $time;
		$FORM{s_IP}   = $FORM{r_IP}  = $ENV{REMOTE_ADDR};
		$FORM{s_name} = $FORM{r_name};
		$FORM{s_email} = $FORM{r_email};
		$FORM{rate} = $FORM{view} = $FORM{vote} = 0;
		$FORM{ID} = &GetNextID;
		while(-f "$data_path/$FORM{cat}/$FORM{ID}.$CONFIG{answered_ext}"){
			$FORM{ID} = &GetNextID;
		}
		&SaveQuestionDatabase("$data_path/$FORM{cat}/$FORM{ID}.$CONFIG{answered_ext}", \%FORM);
		$message =  $mj{success};
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintAddQuestion;	}
}
############################################################
sub AnswerQuestion{
	my($time);
	$message = "";
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && ($ADMIN{question_edit} or $ADMIN{question_add})){
		$message = &CheckQuestionInput;
		&PrintAnswerQuestion($message) if $message;
		unless($FORM{donotpost}){	&SaveQuestionDatabase($question_file, \%FORM);	}
		unlink($unanswered_file);
		&SendMail($FORM{r_email}, $FORM{r_email}, $FORM{s_email}, "Re:$FORM{question}", &ParseEmailTemplate($EMAIL{question_replied}, \%FORM));
		$message =  $mj{success};
		&WaitingQuestion($message);
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	elsif(-f $unanswered_file){	&PrintAnswerQuestion("");	}
	else{	&PrintError($mj{'error'}, " No such question ID waiting to be answered");	}
}
###########################################################################
sub DeleteQuestion{
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{question_delete}){
		unlink ($question_file);
		unlink ($unanswered_file);
		$message = $mj{success};
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintDeleteQuestion;	}
}
############################################################
sub EditQuestion{
	my($message, $time);
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{question_edit}){
		$message = &CheckQuestionInput;
		&PrintEditQuestion($message) if $message;
		&SaveQuestionDatabase($question_file, \%FORM);
		$message =  $mj{success};
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{		&PrintEditQuestion;	}
}
############################################################
sub CheckQuestionInput{
	my($message);
	$message .= qq|<li>Please enter your question, it is required</li>| unless $FORM{'question'};
	$message .= qq|<li>Please answer your question, it is required</li>| unless $FORM{'answer'};
	$message .= qq|<li>Please enter the name of the person who asks</li>| unless $FORM{s_name};
	$message .= qq|<li>Please enter the email of the person who asks</li>| unless $FORM{s_email};
	$message .= qq|<li>Please enter the name of the person who answers</li>| unless $FORM{r_name};
	$message .= qq|<li>Please enter the email of the person who answers</li>| unless $FORM{r_email};
	$FORM{answer} =~ s/\n/<br>/ig;
	$FORM{answer} =~ s/\r//ig;
	return $message;
}
############################################################
sub WaitingQuestion{
	$category_path = $waiting_path;
	$FORM{cat} = "_waiting";
	unless(-d $waiting_path){	mkdir($waiting_path, 0777);	}
	&BuildQuestions(@_);
}
############################################################
sub BuildQuestions{
	my ($action, $count, $file, @files, $filename, $html, $last_modify,
		$pointer, %QUESTION, $total);
	($file, $total) = &DirectoryFiles($category_path, [$CONFIG{answered_ext}, $CONFIG{unanswered_ext}]);
	@files = @$file;
	$count=0;
	
	for(my $i=0; $i< @files; $i++){
		$count = $i+1;
		$file = $files[$i];
		$pointer = &RetrieveQuestionDatabase($file);
		%QUESTION = %$pointer;
		next unless $QUESTION{question};
		$filename = &GetLastDirectory($file);
		$last_modify = &FormatTime((stat("$file"))[9]);
		$question = &ConvertFromHTML($QUESTION{question});
		if($QUESTION{r_email}){		$answerer = qq|<a href="mailto:$QUESTION{r_email}?subject=Re:$question">$QUESTION{r_name}</a>|;		}
		else{			$answerer = qq|Not Yet|;			}
		
		if($filename =~ /$CONFIG{answered_ext}$/){
			$action = qq|<a href="$admin_url?type=question&action=delete&cat=$FORM{cat}&ID=$QUESTION{ID}">Delete</a>
				\| <a href="$admin_url?type=question&action=edit&cat=$FORM{cat}&ID=$QUESTION{ID}">Edit</a>
				|;
		}else{
			$action = qq|<a href="$admin_url?type=question&action=delete&cat=_waiting&ID=$QUESTION{ID}">Delete</a>
				\| <a href="$admin_url?type=question&action=answer&cat=_waiting&ID=$QUESTION{ID}">Answer</a>
				|;
		}
		$html .= qq|<tr>
				<td>$count&nbsp;</td>
				<td><font size=2>$QUESTION{question}&nbsp;</font></td>
				<td>$action&nbsp;</td>
				<td><a href="mailto:$QUESTION{s_email}?subject=Re:$question">$QUESTION{s_name}&nbsp;</a></td>
				<td>$answerer&nbsp;</td>
				</tr> |;
	}
	&PrintBuildQuestions($html, $message);
}
###########################################################################
sub PrintBuildQuestions{
	my(%HTML, $action);
	($HTML{questions}, $HTML{message}) = @_;
	$action = qq|<a href="$admin_url?type=question&cat=$FORM{cat}&action=add">Add new FAQ</a>| unless $FORM{cat} eq $CONFIG{waiting_folder};
	&PrintMojoHeader;
	print qq|<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <div align="center"><b><font face="Tahoma">$CAT{description}<br>
        <font color="#FF0000">$HTML{message}<br>
        </font></font></b></div>
    </td>
  </tr>
  <tr> 
    <td>
      <table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#99CCFF">
        <tr bgcolor="#663300"> 
          <td bgcolor="#7392AD" width="5%"><b>Number</b></td>
          <td bgcolor="#7392AD" width="39%"><b><font face="Tahoma" color="#FFFF99">Question</font></b></td>
          <td bgcolor="#7392AD" width="21%"><b><font face="Tahoma" color="#FFFF99">Action</font></b></td>
          <td bgcolor="#7392AD" width="17%"><b><font face="Tahoma" color="#FFFF99">Asked by </font></b></td>
          <td bgcolor="#7392AD" width="18%"><b><font face="Tahoma" color="#FFFF99">Answered by </font></b></td>
        </tr>
        $HTML{questions} 
        <tr> 
          <td colspan="5"> 
            <div align="center">$action</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintAddQuestion{
	my($message) = @_;
	$FORM{r_name} = $FORM{s_name} = $ADMIN{username};
	$FORM{r_email} =$FORM{s_email}= $ADMIN{email};
	&PrintMojoHeader;
	print qq|
<table align="center" width="100%">
  <tr> 
    <td width="100%" valign="top" height="499"> 
      <div align="center"> 
        <form method="POST" action="$ENV{'SCRIPT_NAME'}">
          <input type=hidden name=type value="question">
          <input type=hidden name=cat value="$FORM{cat}">
          <input type=hidden name=action value="add">
          <input type=hidden name=step value="final">
          <div align="center"> 
            <center>
              <table border="1" cellpadding="5" cellspacing="0" bordercolorlight="#000000" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" width="100%" height="212">
                <tr> 
                  <td valign="top" height="272"> 
                    <div align="left"></div>
                    <table border="1" width="100%" cellspacing="1" cellpadding="3" bordercolor="#CCCCCC">
                      <tr> 
                        <td colspan="2"> 
                          <div align="center"><font color="#0000FF" size="4">A 
                            d d &nbsp; &nbsp;A &nbsp; &nbsp;Q u e s t i o n </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td height="2" colspan="2"> 
                          <div align="center"><font color="#0000FF"><b><font color="#FF0000">$message</font></b></font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="18"> 
                          <div align="right"><b>New question</b></div>
                        </td>
                        <td height="18" width="88%"> 
                          <input type="text" name="question" value="$FORM{'question'}" size="70" maxlength="300">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="19" valign="top"> 
                          <div align="right"><b>Answer</b></div>
                        </td>
                        <td width="88%" height="19"> 
                          <textarea name="answer" cols="60" rows="10" wrap="VIRTUAL">$FORM{'answer'}</textarea>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="9" valign="top"> 
                          <div align="right"><b>Asked By</b></div>
                        </td>
                        <td width="88%" height="9"> 
                          <input type="text" name="s_name" value="$FORM{'s_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="s_email" value="$FORM{'s_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="9" valign="top"> 
                          <div align="right"><b>Answered By</b></div>
                        </td>
                        <td width="88%" height="9"> 
                          <input type="text" name="r_name" value="$FORM{'r_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="r_email" value="$FORM{'r_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr> 
                        <td height="1" colspan="2"> 
                          <div align="center"> 
                            <input type="submit" name="add" value=" $TXT{add}">
                          </div>
                        </td>
                      </tr>
                    </table>
                    <div align="center"></div>
                  </td>
                </tr>
              </table>
            </center>
          </div>
        </form>
      </div>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}

###########################################################################
sub PrintAnswerQuestion{
	my(%HTML, $message, $question, %QUESTION);
	($message) = @_;
	$HTML{topics} = &BuildCategoryList;
	$question = &RetrieveQuestionDatabase($unanswered_file);
	%QUESTION = %$question;
	foreach (keys %QUESTION){	$FORM{$_} = $QUESTION{$_};	}
	$FORM{r_name} = $ADMIN{username};
	$FORM{r_email}= $ADMIN{email};
	
	&PrintMojoHeader;
	print qq|
<table align="center" width="100%">
  <tr> 
    <td width="100%" valign="top" height="499"> 
      <div align="center"> 
        <form method="POST" action="$ENV{'SCRIPT_NAME'}">
          <input type=hidden name=type value="question">
          <input type=hidden name=action value="answer">
          <input type=hidden name=ID value="$FORM{ID}">
          <input type=hidden name=step value="final">
          <div align="center"> 
            <center>
              <table border="1" cellpadding="5" cellspacing="0" bordercolorlight="#000000" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" width="100%" height="212">
                <tr> 
                  <td valign="top" height="272"> 
                    <div align="left"></div>
                    <table border="1" width="100%" cellspacing="1" cellpadding="3" bordercolor="#CCCCCC">
                      <tr> 
                        <td colspan="2"> 
                          <div align="center"><font color="#0000FF" size="4">Reply 
                            Question </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td height="2" colspan="2"> 
                          <div align="center"><font color="#0000FF"><b><font color="#FF0000">$message</font></b></font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="18"> 
                          <div align="right"><b>Question</b></div>
                        </td>
                        <td height="18" width="88%"> 
                          <input type="text" name="question" value="$FORM{'question'}" size="70" maxlength="300">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="19" valign="top"> 
                          <div align="right"><b>Answer</b></div>
                        </td>
                        <td width="88%" height="19"> 
                          <textarea name="answer" cols="60" rows="10" wrap="VIRTUAL">$FORM{'answer'}</textarea>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="9" valign="top"> 
                          <div align="right"><b>Asked By</b></div>
                        </td>
                        <td width="88%" height="9"> 
                          <input type="text" name="s_name" value="$FORM{'s_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="s_email" value="$FORM{'s_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="4" valign="top"> 
                          <div align="right"><b>Answered By</b></div>
                        </td>
                        <td width="88%" height="4"> 
                          <input type="text" name="r_name" value="$FORM{'r_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="r_email" value="$FORM{'r_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr>
                        <td width="12%" height="4" valign="top"> 
                          <div align="right"><b>Post it?</b></div>
                        </td>
                        <td width="88%" height="4">$HTML{topics}
                          <input type="checkbox" name="donotpost" value="donotpost">
                          Do not post. Reply and delete.</td>
                      </tr>
                      <tr> 
                        <td height="24" colspan="2"> 
                          <div align="center"> 
                            <input type="submit" name="add" value=" Answer">
                          </div>
                        </td>
                      </tr>
                    </table>
                    <div align="center"></div>
                  </td>
                </tr>
              </table>
            </center>
          </div>
        </form>
      </div>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}

###########################################################################
sub PrintDeleteQuestion{
	my($question, %QUESTION);
	if(-f $question_file){
		$question = &RetrieveQuestionDatabase($question_file);
	}else{
		$question = &RetrieveQuestionDatabase($unanswered_file);
	}
	%QUESTION = %$question;
	&PrintMojoHeader;
	print qq|<table align="center" width="100%">
  <tr> 
    <td width="100%" valign="top" height="164"> 
      <div align="center"> 
        <form method="POST" action="$admin_url">
          <input type=hidden name=type value="question">
          <input type=hidden name=cat value="$FORM{cat}">
			  <input type=hidden name=ID value="$FORM{ID}">
          <input type=hidden name=action value="delete">
          <input type=hidden name=step value="final">
          <div align="center"> 
            <center>
              <table border="1" width="100%" cellspacing="0" cellpadding="2" bordercolor="#7392AD">
                <tr> 
                  <td> 
                    <div align="center"><font color="#0000FF" size="5">D e l e 
                      t e&nbsp; &nbsp;Q u e s t i o n</font><font color="#0000FF" size="4"><br>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="2"> 
                    <div align="center"><font color="#0000FF"><b>Are You sure 
                      you want to delete this question titled:<br>
                      <font color="#FF6600">$QUESTION{question}</font></b></font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="2"> 
                    <div align="center"> 
                      <input type="submit" name="delete" value=" $TXT{yes}">
                      <input type="submit" name="delete2" value=" $TXT{no}">
                    </div>
                  </td>
                </tr>
              </table>
            </center>
          </div>
        </form>
      </div>
    </td>
  </tr>
</table>
		|;
&PrintMojoFooter;
}
######################################################################################
sub PrintEditQuestion{
	my($message, $question, %QUESTION);
	($message) = @_;
	if(-f $question_file){	$question = &RetrieveQuestionDatabase($question_file);	}
	else{	$question = &RetrieveQuestionDatabase($unanswered_file);	}
	%QUESTION = %$question;
	foreach (keys %QUESTION){	$FORM{$_} = $QUESTION{$_};	}
	$FORM{answer} =~ s/<br>/\n/ig;
	&PrintMojoHeader;
	print qq|
<table align="center" width="100%">
  <tr> 
    <td width="100%" valign="top" height="499"> 
      <div align="center"> 
        <form method="POST" action="$ENV{'SCRIPT_NAME'}">
          <input type=hidden name=type value="question">
          <input type=hidden name=cat value="$FORM{cat}">
			 <input type=hidden name=ID value="$FORM{ID}">
          <input type=hidden name=action value="edit">
          <input type=hidden name=step value="final">
          <div align="center"> 
            <center>
              <table border="1" cellpadding="5" cellspacing="0" bordercolorlight="#000000" bordercolordark="#FFFFFF" bgcolor="#FFFFFF" width="100%" height="212">
                <tr> 
                  <td valign="top" height="272"> 
                    <div align="left"></div>
                    <table border="1" width="100%" cellspacing="1" cellpadding="3" bordercolor="#CCCCCC">
                      <tr> 
                        <td colspan="2"> 
                          <div align="center"><font color="#0000FF" size="4">E 
                            D i t&nbsp; &nbsp;A &nbsp; &nbsp;Q u e s t i o n </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td height="2" colspan="2"> 
                          <div align="center"><font color="#0000FF"><b><font color="#FF0000">$message</font></b></font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="18"> 
                          <div align="right"><b>New question</b></div>
                        </td>
                        <td height="18" width="88%"> 
                          <input type="text" name="question" value="$FORM{'question'}" size="70" maxlength="300">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="19" valign="top"> 
                          <div align="right"><b>Answer</b></div>
                        </td>
                        <td width="88%" height="19"> 
                          <textarea name="answer" cols="60" rows="10" wrap="VIRTUAL">$FORM{'answer'}</textarea>
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="9" valign="top"> 
                          <div align="right"><b>Asked By</b></div>
                        </td>
                        <td width="88%" height="9"> 
                          <input type="text" name="s_name" value="$FORM{'s_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="s_email" value="$FORM{'s_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr> 
                        <td width="12%" height="9" valign="top"> 
                          <div align="right"><b>Answered By</b></div>
                        </td>
                        <td width="88%" height="9"> 
                          <input type="text" name="r_name" value="$FORM{'r_name'}" size="25" maxlength="60">
                          <b>Email</b> 
                          <input type="text" name="r_email" value="$FORM{'r_email'}" size="25" maxlength="60">
                        </td>
                      </tr>
                      <tr> 
                        <td height="1" colspan="2"> 
                          <div align="center"> 
                            <input type="submit" name="add" value=" $TXT{save}">
                          </div>
                        </td>
                      </tr>
                    </table>
                    <div align="center"></div>
                  </td>
                </tr>
              </table>
            </center>
          </div>
        </form>
      </div>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}
###########################################################################
1;