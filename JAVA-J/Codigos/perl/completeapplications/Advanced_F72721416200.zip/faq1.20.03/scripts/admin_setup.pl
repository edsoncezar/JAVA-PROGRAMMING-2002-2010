##############################################################################
sub SetupMain{
	&LoadConfigFile;
	if($FORM{'class'} eq "config"){				&Configuration; 			}
	elsif($FORM{'class'} eq "behavior"){		&Behavior;					}
	elsif($FORM{'class'} eq "email_subject"){	&EmailSubject;				}
	elsif($FORM{'class'} eq "email"){			&EmailTemplate;			}
	elsif($FORM{'class'} eq "html"){				&HTMLTemplate;				}
	elsif($FORM{'class'} eq "display"){			&DisplaySetup;				}
	
	elsif($FORM{'class'}){	&PrintError($mj{error}, $mj{confuse});}
	&PrintSetupMain;
}
##############################################################################
sub Configuration{
	if($FORM{'step'} eq "final" && $ADMIN{'config'}){
		$message = &CheckConfiguration;
		foreach (keys %FORM){	$MOJOSCRIPTS{$_} = $FORM{$_} if defined $FORM{$_};	}
		$message .= "<li>$mj{setup98}</li>" unless (-e "$CONFIG{admin_database}");
		$message .= "<li>$mj{setup99}</li>" unless (-e "$CONFIG{group_database}");
		&PrintConfiguration($message) if $message;		
#		foreach (keys %MOJOSCRIPTS){			$message .= qq|<br>[$_] = [$MOJOSCRIPTS{$_}]|;	}
		$message .=qq|<br><font color=red>$mj{success}</font><br>|;
		&WriteConfig;
		&PrintConfiguration($message);
	}
	elsif($FORM{'step'} eq "final"){		&PrintConfiguration($mj{'deny'});		}
	else{											&PrintConfiguration;							}
}
##############################################################################
sub Behavior{
	$message="";
	if($FORM{'cancel'}){	$message = $mj{'cancel'};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{'behavior'}){
		foreach $key (keys %CONFIG){
			$CONFIG{$key} = $FORM{$key} if (defined $FORM{$key});
		}
		&PrintBehavior($message) if $message;

		$message =qq|<br><font color=red>$mj{success}</font><br>|;
		&WriteConfig;
		&PrintBehavior($message);
	}
	elsif($FORM{'step'} eq "final"){			$message .= $mj{'deny'};	}
	&PrintBehavior($message);
}
##############################################################################
sub DisplaySetup{
	$message="";
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{config}){
		%TABLE = %FORM;
		&WriteConfig;
		$message =qq|<br><font color=red>$mj{success}</font><br>|;
		&PrintDisplaySetup($message);
	}
	elsif($FORM{'step'} eq "final"){			$message .= $mj{deny};	}
	&PrintDisplaySetup($message);
}
##############################################################################
sub EmailSubject{
	$message="";
	if($FORM{cancel}){	$message = $mj{cancel};	}
	elsif($FORM{'step'} eq "final" && $ADMIN{'email'}){
		%SUBJECT = %FORM;
		&WriteConfig;
		$message =qq|<br><font color=red>$mj{success}</font><br>|;
		&PrintEmailSubjects($message);
	}
	elsif($FORM{'step'} eq "final"){			$message .= $mj{deny};	}
	&PrintEmailSubjects($message);
}
##############################################################################
sub EmailTemplate{
	$class = "email";
	@ext = ('txt', 'TXT');
	$this_path = $email_path;
	&SetupTemplates; 
}
##############################################################################
sub HTMLTemplate{
	$class = "html";
	@ext = ('htm', 'html');
	$this_path = $template_path;
	&SetupTemplates;
}
##################################################################################
sub SetupTemplates{
	my (@contents,$file, $line, @lines, $path);
	if($FORM{'edit'}){
		$FORM{'content'} = &FileReadString("$this_path/$FORM{'name'}");
		$FORM{'saveas'} = $FORM{'name'};
		$message = $mj{template1};
	}
	elsif($FORM{'save'}){
		if(($FORM{'class'} eq "html" && $ADMIN{'template'}) or ($FORM{'class'} eq "email" && $ADMIN{'email'})){
			$file = "$this_path/$FORM{'saveas'}";
			@contents = split(/\n/, $FORM{'content'});
			&FileWrite($file, \@contents);
			$message = $mj{success};
		}
		else{	&PrintError($mj{'error'}, $mj{'deny'});		}
	}
	else{
		$message = qq|<b>$mj{template}  |;
		$FORM{'content'} = "";
	}
	$HTML_pull_down_menu = &BuildPullDownMenu(&DirectoryFiles($this_path), "name", $FORM{'saveas'});
	&PrintConfigTemplate;
}
##################################################################################
sub WriteConfig{
	my($filename);
	if($ENV{PATH_TRANSLATED}){
		($filename=$ENV{PATH_TRANSLATED}) =~ s/\\/\//g;
		$filename = &GetParentDirectory($filename);
		$filename .=  "/config.pl";
	}
	else{
		$filename=$ENV{SCRIPT_FILENAME};
		$filename = &GetParentDirectory($filename);
		$filename .=  "/config.pl";
	}
	$MOJOSCRIPTS{root_url} 	= &PathToURL($MOJOSCRIPTS{root_path}) unless $MOJOSCRIPTS{root_url};
	$MOJOSCRIPTS{data_url} 	= &PathToURL($MOJOSCRIPTS{data_path}) unless $MOJOSCRIPTS{data_url};
	$MOJOSCRIPTS{photo_url} 	= &PathToURL($MOJOSCRIPTS{photo_path})unless $MOJOSCRIPTS{photo_url};
	$MOJOSCRIPTS{backup_path}= qq|$MOJOSCRIPTS{session_path}/backup| unless $MOJOSCRIPTS{backup_path};
#	mkdir($MOJOSCRIPTS{testify_path}, 0777); chmod(0777, $MOJOSCRIPTS{testify_path});
#	mkdir($MOJOSCRIPTS{backup_path}, 0777); chmod(0777, $MOJOSCRIPTS{backup_path});
	$script_ext = ".cgi" unless $script_ext;
	open(FILE, ">$filename") or &PrintError($mj{'error'}, "$mj{file3}: $filename");
	flock(FILE,lex) if $CONFIG{flock};;
	print FILE qq~
\$document_root=qq|$MOJOSCRIPTS{document_root}|;
\$site_title=   qq|$MOJOSCRIPTS{site_title}|;
\$data_path=    qq|$MOJOSCRIPTS{data_path}|;
\$email_path=   qq|$MOJOSCRIPTS{email_path}|;
\$log_path=     qq|$MOJOSCRIPTS{data_path}|;
\$member_path = qq|$MOJOSCRIPTS{member_path}|;
\$mail_path=    qq|$MOJOSCRIPTS{mail_path}|;
\$template_path=qq|$MOJOSCRIPTS{template_path}|;
\$session_path= qq|$MOJOSCRIPTS{session_path}|;
\$script_path=  qq|$MOJOSCRIPTS{script_path}|;
\$image_url=    qq|$MOJOSCRIPTS{image_url}|;
\$image_path=   qq|$MOJOSCRIPTS{image_path}|;
\$cgi_url=      qq|$MOJOSCRIPTS{cgi_url}|;
\$home_url=     qq|$MOJOSCRIPTS{home_url}|;
\$myname=       qq|$MOJOSCRIPTS{myname}|;
\$myemail=      q|$MOJOSCRIPTS{myemail}|;
\$sendmail=     qq|$MOJOSCRIPTS{sendmail}|;
\$smtp=         qq|$MOJOSCRIPTS{smtp}|;
\$system=       qq|$MOJOSCRIPTS{system}|;
\$language_lib= qq|$MOJOSCRIPTS{language_lib}|;
\$script_ext=   qq|$MOJOSCRIPTS{script_ext}|;
##NOTE: never ever try to edit this file manually, unless you know what you do
##  but why not login your admin area, where you can config everything on the web?
##  if you make some manual changes, and the script won't work, run install.cgi again
##
#######  Email Subjects  #############
\$SUBJECT{admin}=         qq|$SUBJECT{admin}|;
\$SUBJECT{user}=          qq|$SUBJECT{user}|;
#######  Email Templates  #############
\$EMAIL{admin}=           qq|\$email_path/admin.txt|;
\$EMAIL{user}=            qq|\$email_path/user.txt|;
\$EMAIL{question_replied}=qq|\$email_path/question_replied.txt|;
#######  HTML Templates  #############
\$TEMPLATE{home}=         qq|\$template_path/home.html|;
\$TEMPLATE{ask}=          qq|\$template_path/ask.html|;
\$TEMPLATE{answer1}=      qq|\$template_path/answer1.html|;
\$TEMPLATE{cat1}=         qq|\$template_path/cat1.html|;
\$TEMPLATE{category}=     qq|\$template_path/category.html|;
\$TEMPLATE{error}=        qq|\$template_path/error.html|;
\$TEMPLATE{question1}=    qq|\$template_path/question1.html|;
\$TEMPLATE{question}=     qq|\$template_path/question.html|;

######### Configurations ##########
\$CONFIG{answered_ext}=   qq|ans|;
\$CONFIG{unanswered_ext}= qq|una|;
\$CONFIG{lsh}=            qq|1|;
\$CONFIG{lex}=            qq|2|;
\$CONFIG{lun}=            qq|8|;
\$CONFIG{log_ext}=        qq|log|;
\$CONFIG{admin_database}= qq|\$member_path/admin.cgi|;
\$CONFIG{group_database}= qq|\$member_path/groups.cgi|;
\$CONFIG{ID_db}=          qq|\$data_path/id.cgi|;
\$CONFIG{cat_db}=         qq|cat.cgi|;
\$CONFIG{cat_order}=      qq|cat_order.cgi|;
\$CONFIG{log}=            qq|$CONFIG{log}|;
\$CONFIG{flock}=          qq|$CONFIG{log}|;
\$CONFIG{rename}=         qq|$CONFIG{rename}|;
\$CONFIG{waiting_folder}= qq|$CONFIG{waiting_folder}|;
\$CONFIG{notify_email}=   q|$CONFIG{notify_email}|;
\$CONFIG{auto_response}=  q|$CONFIG{auto_response}|;
\$CONFIG{redirect}=       qq|$CONFIG{redirect}|;
\$CONFIG{catlayout}=      qq|$CONFIG{catlayout}|;

######### TABLEs ##########
\$TABLE{cat_width}=       qq|$TABLE{cat_width}|;
\$TABLE{cat_border}=      qq|$TABLE{cat_border}|;
\$TABLE{cat_cellspacing}= qq|$TABLE{cat_cellspacing}|;
\$TABLE{cat_cellpadding}= qq|$TABLE{cat_cellpadding}|;
\$TABLE{cat_bgcolor}=     qq|$TABLE{cat_bgcolor}|;
\$TABLE{cat_bordercolor}= qq|$TABLE{cat_bordercolor}|;
\$TABLE{cat_rows}=        qq|$TABLE{cat_rows}|; 
\$TABLE{cat_cols}=        qq|$TABLE{cat_cols}|;

#################################
######### Scripts Location ##########
\$admin_url=       qq|\$cgi_url/admin.$script_ext|;
\$ask_url=         qq|\$cgi_url/ask.$script_ext|;
\$mojo_url=        qq|\$cgi_url/mojofaq.$script_ext|;

########################################################
1;
~;

	flock(FILE,8);
	close(FILE);
	chmod(0777, $filename);
	return 1;
}
###########################################################################
sub LoadConfigFile{
$MOJOSCRIPTS{document_root}=$document_root;
$MOJOSCRIPTS{site_title}   =$site_title;
$MOJOSCRIPTS{root_path}    =$root_path;
$MOJOSCRIPTS{root_url}     =$root_url;
$MOJOSCRIPTS{backup_path}  =$backup_path;
$MOJOSCRIPTS{data_path}    =$data_path;
$MOJOSCRIPTS{data_url}     =$data_url;
$MOJOSCRIPTS{email_path}   =$email_path;
$MOJOSCRIPTS{log_path}     =$log_path;
$MOJOSCRIPTS{member_path}  =$member_path;
$MOJOSCRIPTS{mail_path}    =$mail_path;
$MOJOSCRIPTS{photo_path}   =$photo_path;
$MOJOSCRIPTS{photo_url}    =$photo_url;
$MOJOSCRIPTS{testify_path} =$testify_path;
$MOJOSCRIPTS{template_path}=$template_path;
$MOJOSCRIPTS{session_path} =$session_path;
$MOJOSCRIPTS{script_path}  =$script_path;
$MOJOSCRIPTS{cgi_url}      =$cgi_url;
$MOJOSCRIPTS{image_url}    =$image_url;
$MOJOSCRIPTS{image_path}   =$image_path;
$MOJOSCRIPTS{home_url}     =$home_url;
$MOJOSCRIPTS{myname}       =$myname;
$MOJOSCRIPTS{myemail}      =$myemail;
$MOJOSCRIPTS{sendmail}     =$sendmail;
$MOJOSCRIPTS{smtp}         =$smtp;
$MOJOSCRIPTS{system}       =$system;
$MOJOSCRIPTS{language_lib} =$language_lib;
$MOJOSCRIPTS{script_ext}   =$script_ext;
}
##################################################################################
sub PrintBehavior{
	my($message, %HTML,	@label1, %LABEL1, @label2, %LABEL2);
	($message) = @_;
	@label1 = ("1", "0");
	%LABEL1 = ("1"=>"Yes", "0"=>"No");
	%LABEL2 = (1=>"2 Column-Style", 0=>"1 column style");
	
	$HTML{flock}  = popup_menu("flock", \@label1, $CONFIG{flock}, \%LABEL1);
	$HTML{rename}  = popup_menu("rename", \@label1, $CONFIG{rename}, \%LABEL1);
	$HTML{auto_response}= popup_menu("auto_response", \@label1, $CONFIG{auto_response}, \%LABEL1);
	$HTML{catlayout}= popup_menu("catlayout", \@label1, $CONFIG{catlayout}, \%LABEL2);
	
	
	&PrintMojoHeader;
	print qq|
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="107"> 
      <form name="mojo" method="post" action="$admin_url">
        <div align="center">
          <input type="hidden" name="type" value="config">
          <input type="hidden" name="class" value="behavior">
          <input type="hidden" name="step" value="final">
          <b><font color="#FF0000">$message </font></b> 
          <table width="600" border="1" cellspacing="0" cellpadding="1" bordercolor="#CCCCCC">
            <tr> 
              <td colspan="2" height="14"><br>
                <b><font face="Tahoma">$mj{cfg}</font></b><br>
              </td>
            </tr>
            <tr> 
              <td colspan="2">&nbsp;</td>
            </tr>
            <tr> 
              <td>$mj{cfg1}</td>
              <td width="200">$HTML{flock}</td>
            </tr>
            <tr> 
              <td>$mj{cfg2}</td>
              <td width="200"> $HTML{rename}</td>
            </tr>
            <tr> 
              <td height="1" bgcolor="#EEEEEE">Use auto-response?</td>
              <td width="200" height="0" bgcolor="#EEEEEE"> $HTML{auto_response}</td>
            </tr>
            <tr> 
              <td height="1" bgcolor="#EEEEEE">If you want to to recieve an email 
                when someone use this program, enter your email here</td>
              <td width="200" height="0" bgcolor="#EEEEEE"> 
                <input type="text" size="20" name="notify_email" value="$CONFIG{notify_email}" maxlength="105">
              </td>
            </tr>
            <tr> 
              <td height="0">How do you want to display the FAQ categories</td>
              <td width="200" height="0">$HTML{catlayout}</td>
            </tr>
            <tr> 
              <td colspan="2" height="2"> 
                <div align="center"> 
                  <input type="submit" name="Submit" value="Submit">
                  <input type="reset" name="reset" value="Reset">
                </div>
              </td>
            </tr>
          </table>
        </div>
      </form>
    </td>
  </tr>
</table>
|;
	&PrintMojoFooter;
	exit;
}
###########################################################################
sub PrintConfiguration{
	my($error, $message);
	($error) = @_;
	$FORM{document_root}=  $document_root unless $FORM{document_root};
	$FORM{'site_title'}=   $site_title unless $FORM{'site_title'};
	$FORM{'root_path'}=    $root_path unless $FORM{'root_path'};
	$FORM{'root_url'}=     $root_url unless $FORM{'root_url'};
	$FORM{backup_path}=    $backup_path unless $FORM{backup_path};
	$FORM{'data_path'}=    $data_path unless $FORM{'data_path'};
	$FORM{email_path}=     $email_path unless $FORM{email_path};
	$FORM{mail_path}=      $mail_path unless $FORM{mail_path};
	$FORM{'member_path'}=  $member_path unless $FORM{'member_path'};
	$FORM{'photo_path'}=   $photo_path unless $FORM{'photo_path'};
	$FORM{'session_path'}= $session_path unless $FORM{'session_path'};
	$FORM{script_path}=    $script_path unless $FORM{script_path};
	$FORM{'template_path'}=$template_path unless $FORM{'template_path'};
	$FORM{cgi_url}=        $cgi_url unless $FORM{cgi_url};
	$FORM{'image_url'}=    $image_url unless $FORM{'image_url'};
	$FORM{'image_path'}=   $image_path unless $FORM{'image_path'};
	$FORM{'root_url'}=     $root_url unless $FORM{'root_url'};
	$FORM{'homelink'}=     $homelink unless $FORM{'homelink'};
	$FORM{'myemail'}=      $myemail unless $FORM{'myemail'};
	$FORM{system}=         $system unless $FORM{system};
	$FORM{'myname'}=       $myname unless $FORM{'myname'};
	$FORM{'sendmail'}=     $sendmail unless $FORM{'sendmail'};
	$FORM{'smtp'}=         $smtp unless $FORM{'smtp'};
	
	#my $this_dir = &GetParentDirectory(&GetParentDirectory($ENV{'SCRIPT_FILENAME'}));
	#my($file, @files, @languages, @ext);
	#@ext=('lng');
	#$file = &DirectoryFiles($this_dir, \@ext);
	#@files = @$file;
	#for(my $i=0; $i< @files; $i++){ $files[$i] =~ s/$this_dir\///ig;}
	#unless(@files){ print "content-type:text/html\n\n <h1>Missing Language pack</h1><h3>Contact mojoscripts.com now</h3>";}
	
	#$HTML_language = &BuildPullDownMenu(\@files, "language_lib", "english.lng");
	
	&PrintMojoHeader;
	&ConfigTemplate($admin_url, $error?$error:$message);
	&PrintMojoFooter;
}
###########################################################################
sub PrintDisplaySetup{
	my($cat_width,$cat_border,$cat_cellspacing,$cat_cellpadding,$cat_bgcolor,
		$cat_bordercolor,$cat_columns,$menu_width,$menu_border,$menu_cellspacing,
		$menu_cellpadding,$menu_bgcolor,$menu_bordercolor,
		$message);
	($message) = @_;
$cat_width 			= textfield("cat_width", $TABLE{cat_width}, 15, 10);
$cat_border			= textfield("cat_border", $TABLE{cat_border}, 15, 10);
$cat_cellspacing  = textfield("cat_cellspacing", $TABLE{cat_cellspacing}, 15, 10);
$cat_cellpadding  = textfield("cat_cellpadding", $TABLE{cat_cellpadding}, 15, 10);
$cat_bgcolor      = textfield("cat_bgcolor", $TABLE{cat_bgcolor}, 15, 10);
$cat_bordercolor  = textfield("cat_bordercolor", $TABLE{cat_bordercolor}, 15, 10);
$cat_columns      = textfield("cat_columns", $TABLE{cat_columns}, 15, 10);

$media_width       = textfield("media_width", $TABLE{media_width}, 15, 10);
$media_border      = textfield("media_border", $TABLE{media_border}, 15, 10);
$media_cellspacing = textfield("media_cellspacing", $TABLE{media_cellspacing}, 15, 10);
$media_cellpadding = textfield("media_cellpadding", $TABLE{media_cellpadding}, 15, 10);
$media_bgcolor     = textfield("media_bgcolor", $TABLE{media_bgcolor}, 15, 10);
$media_bordercolor = textfield("media_bordercolor", $TABLE{media_bordercolor}, 15, 10);

&PrintMojoHeader;
print qq|
<form name="mojo" method="post" action="$admin_url">
  <input type="hidden" name="type" value="config">
  <input type="hidden" name="class" value="display">
  <input type="hidden" name="step" value="final">
  <table width="567" border="1" cellspacing="0" cellpadding="0" align="center" bordercolor="#99CCFF">
    <tr> 
      <td colspan="2" height="3"> 
        <div align="center"><font size="4"><b>Display Options</b></font><br>
        </div>
      </td>
    </tr>
    <tr> 
      <td colspan="2"><b><font size="4">Category table</font></b></td>
    </tr>
    <tr> 
      <td width="369"><b>Table width</b></td>
      <td width="184">$cat_width</td>
    </tr>
    <tr> 
      <td width="369"><b>Table border</b></td>
      <td width="184">$cat_border</td>
    </tr>
    <tr> 
      <td width="369"><b>Table cellspacing</b></td>
      <td width="184">$cat_cellspacing</td>
    </tr>
    <tr> 
      <td width="369"><b>Table cellpadding</b></td>
      <td width="184">$cat_cellpadding</td>
    </tr>
    <tr> 
      <td width="369"><b>Table background color</b></td>
      <td width="184">$cat_bgcolor</td>
    </tr>
    <tr> 
      <td width="369"><b>Table border color</b></td>
      <td width="184">$cat_bordercolor</td>
    </tr><!--
    <tr> 
      <td colspan="2"> 
        <p>&nbsp;</p>
        <p><b><font size="4">Media Table</font></b></p>
      </td>
    </tr>
    <tr> 
      <td width="369"><b>Table width</b></td>
      <td width="184">$media_width</td>
    </tr>
    <tr> 
      <td width="369"><b>Table border</b></td>
      <td width="184">$media_border</td>
    </tr>
    <tr> 
      <td width="369"><b>Table cellspacing</b></td>
      <td width="184">$media_cellspacing</td>
    </tr>
    <tr> 
      <td width="369"><b>Table cellpadding</b></td>
      <td width="184">$media_cellpadding</td>
    </tr>
    <tr> 
      <td width="369"><b>Table background color</b></td>
      <td width="184">$media_bgcolor</td>
    </tr>
    <tr> 
      <td width="369"><b>Table border color</b></td>
      <td width="184">$media_bordercolor</td>
    </tr>-->
  </table>
  <div align="center"><br>
    <input type="submit" name="Submit" value="$TXT{save}">
    <input type="submit" name="cancel" value="$TXT{cancel}">
  </div>
</form>


	|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintEmailSubjects{
	&PrintMojoHeader;
	foreach (%SUBJECT){	$FORM{$_} = $SUBJECT{$_};	}
	print qq|

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="209"> 
      <form name="mojo" method="post" action="$admin_url">
        <input type="hidden" name="type" value="config">
        <input type="hidden" name="class" value="email_subject">
        <input type="hidden" name="step" value="final">
		  <div align="center"><b><font color="#FF0000">$message</font></b></div>
        <table width="600" border="0" cellspacing="0" cellpadding="2" align="center">
          <tr> 
            <td colspan="3"><font face="Tahoma" size="3">$mj{email30}</font></td>
          </tr>
          <tr> 
            <td width="179" valign="top" bgcolor="#EFEFEF"> 
              <div align="right"><b><font face="Tahoma" size="3">$TXT{admin}</font></b></div>
            </td>
            <td width="6" valign="top" bgcolor="#EFEFEF">&nbsp;</td>
            <td width="565" bgcolor="#EFEFEF"><font face="Tahoma" size="2">What 
              is the email subject send to you when someone send a question?<br>
              <input type="text" size="60" value="$FORM{admin}" name="admin">
              </font></td>
          </tr>
          <tr> 
            <td width="179" valign="top" height="18"> 
              <div align="right"><b><font face="Tahoma" size="3">User</font></b></div>
            </td>
            <td width="6" valign="top" height="18">&nbsp;</td>
            <td width="565" height="18"><font face="Tahoma" size="2"> What is 
              the email subject send to user when they post an question?<br>
              <input type="text" size="60" value="$FORM{user}" name="user">
              </font></td>
          </tr>
          <tr> 
            <td colspan="3" valign="top"> 
              <div align="center"> 
                <input type="submit" name="submit" value="Submit">
                <input type="reset" name="reset" value="Reset">
                <br>
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
&PrintMojoFooter;
exit;
}
###########################################################################
sub PrintConfigTemplate{
	&PrintMojoHeader;
	print qq|
<table  cellpadding="5" cellspacing="0" width="100%">
  <tr> 
    <td height="647" valign="top" align="center"> 
      <form method=POST action="$admin_url">
		<input type=hidden name=account value="$FORM{'account'}">
        <input type=hidden name=type value="setup">
        <input type=hidden name=class value="$class">
        <table width="100%" border="0" cellspacing="2" cellpadding="2">
          <tr> 
            <td> 
              <div align="center"><font face="Geneva, Arial, Helvetica, san-serif" color="#000000"><b>$message 
                <font size="5"></font></b></font></div>
            </td>
          </tr>
          <tr> 
            <td height="27"> 

                
              <table align="center" width="400" height="28" cellpadding="0" cellspacing="0" border="0">
                <tr> 
                    
                  <td height="13"> 
                    <div align="center">$mj{'setup151'}<br>
                      $HTML_pull_down_menu 
                      <input type="submit" name="edit" value="  $TXT{'edit'}">
                      <br>
                    </div>
                    </td>
                  </tr>
                </table>

            </td>
          </tr>
          <tr> 
            <td height="429"> 
              <div align="center"> 
                <table align="center">
                  <tr> 
                    <td> 
                      <table>
                        <tr> 
                          <td> 
                            <div align="center"> 
                              <textarea name="content" cols="70" rows="25" wrap="VIRTUAL">$FORM{'content'}</textarea>
                            </div>
                          </td>
                        </tr>
                        <tr> 
                          <td valign=top> 
                            <div align="center"><b>$TXT{save}</b> 
                              <input type="text" name="saveas" value="$FORM{'saveas'}">
                            </div>
                          </td>
                        </tr>
                        <tr> 
                          <td valign=top> 
                            <div align="center"> 
                              <input type=submit value="  $TXT{'save'}" name="save">
                              <input type="reset" name="reset" value="  $TXT{'reset'}">
                            </div>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}
###########################################################################
sub PrintSetupMain{
	$message = shift if $_[0];
	unless ($message){
		$message =qq|<font face="Tahoma" size="2">$mj{'program'} 
          $mj{'version'} let you configure everything via the browser. No messy 
          text to edit, no files to open, no worry about doing things wrong. By 
          letting you configure everything online, errors are caught right away, 
          minimizing the time you have to spend to make things work. </font>
		|;
	}
	&PrintMojoHeader;
	print qq|
	<table width="100%" border="1" cellspacing="0" cellpadding="3" bordercolor="#CCCCCC" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="4" valign="top" height="231"> 
      <div align="center"> 
        <p><b><font size="5">Setup<br>
          </font></b><font size="5"></font></p>
			 $message
      </div>
      <ol>
        <li><a href="$admin_url?account=&type=setup&class=behavior">Behavior</a>: 
          Configure how members pay you, how many days from the date of registration 
          to get expire....and such</li>
        <li><a href="$admin_url?account=&type=setup&class=config">General 
          Configurations</a>: setup the most important aspect of the programs. 
          These are the variables used to run $mj{'program'} $mj{'version'}. If 
          you set the wrong configurations, $mj{'program'} $mj{'version'} may 
          behave differently as not all errors can be caught (nothing is guarantee 
          anyway).</li>
        <li><a href="$admin_url?account=&type=setup&class=email_subject">Email 
          Subjects</a>: Change the email subjects that used to send to your members. 
        </li>
        <li><a href="$admin_url?account=&type=setup&class=email">Email Templates</a>: 
          Change what to send to your members. You can personalize the emails 
          with codes. Make sure you read the documentation</li>
        <li><a href="$admin_url?account=&type=setup&class=html">HTML Templates</a>: 
          Change what to display to your members. As always, use codes to suite 
          your needs, and make sure you read the documentation</li>
      </ol>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
###########################################################################

1;

