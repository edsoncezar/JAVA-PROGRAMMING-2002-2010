###########################################################################
sub ParseCatTemplate{
	my ($template, $cat)  = @_;
	my %CAT = %$cat;
	if(-f $template){		$template = &FileReadString($template);	}

	$icon = qq|<a href="$CAT{link}">$CAT{icon_url}</a>|;
	if($CAT{new}){	$new = qq|<img src="$IMG{new}" border=0 alt="$TXT{new}">|;	}
	else{			$new = "";	}

	$template =~ s/\[NAME\]/<a href="$CAT{link}">$CAT{name}<\/a>/ig;
	$template =~ s/\[DESCRIPTION\]/$CAT{description}/ig;
	$template =~ s/\[#FAQS\]/$CAT{faqs}/ig;
	$template =~ s/\[NEW\]/$new/ig;
	$template =~ s/\[ICON\]/$icon/ig;
	
	return $template;
}
###########################################################################
sub ParseQuestionTemplate{
	my($question, %QUESTION, $template);
	($template, $question)  = @_;
	%QUESTION = %$question;
	$template =~ s/\[QUESTION_NUMBER\]/$QUESTION{question_number}/ig;
	$template =~ s/\[QUESTION\]/<a href="#mojo$QUESTION{question_number}">$QUESTION{question}<\/a>/ig;
	return $template;
}
###########################################################################
sub ParseAnswerTemplate{
	my($question, %QUESTION, $template);
	($template, $question)  = @_;
	%QUESTION = %$question;
	$template =~ s/\[QUESTION_NUMBER\]/$QUESTION{question_number}/ig;
	$template =~ s/\[QUESTION\]/<a name="mojo$QUESTION{question_number}">$QUESTION{question}<\/a>/ig;
	$template =~ s/\[ANSWER\]/$QUESTION{answer}/ig;
	$template =~ s/\[SUBMITTER\]/$QUESTION{s_name}/ig;
	$template =~ s/\[ANSWERER\]/$QUESTION{r_name}/ig;
	$template =~ s/\[DATE_UPDATED\]/$QUESTION{r_date}/ig;
	return $template;
}
###########################################################################
sub ParseUserURL{
	my $template = shift;
	if(-f $template){		$template = &FileReadString($template);	}
	$template =~ s/\[MOJO_URL\]/$mojo_url/ig;
	$template =~ s/\[ASK_URL\]/$ask_url/ig;
	$template =~ s/\[ADMIN_URL\]/$admin_url/ig;
	$template =~ s/\[SEARCH_URL\]/$search_url/ig;
	return $template;
}
###########################################################################
sub ParseEmailTemplate{
	my ($template, $array) = @_;
	my %ARRAY = %$array;
	$template = &ParseUserURL($template);
	$template =~ s/\[MESSAGE\]/$ARRAY{message}/g;
	$template =~ s/\[QUESTION\]/$ARRAY{question}/g;
	$template =~ s/\[ANSWER\]/$ARRAY{answer}/g;
	$template =~ s/\[S_EMAIL\]/$ARRAY{s_email}/g;
	$template =~ s/\[S_NAME\]/$ARRAY{s_name}/g;
	$template =~ s/\[R_EMAIL\]/$ARRAY{r_email}/g;
	$template =~ s/\[R_NAME\]/$ARRAY{r_name}/g;
	$template =~ s/\[RATE\]/$ARRAY{rate}/g;
	$template =~ s/\[VIEW\]/$ARRAY{view}/g;
	$template =~ s/\[VOTE\]/$ARRAY{vote}/g;
	return $template;
}
###########################################################################

###########################################################################
return 1;