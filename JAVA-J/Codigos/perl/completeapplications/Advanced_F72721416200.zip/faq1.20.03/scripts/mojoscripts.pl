###########################################################################
# mojoscripts.pl: common subroutines for all of our scripts               #
###########################################################################
# First Released: December 2001   v1.0.00                                 #
# Last Released: March 2001       v1.10.00                                #
# ========================================================================#
# Software Distributed by:    http://www.mojoscripts.com                  #
# Software Written by:        Kevin Pham		kevin@mojoscripts.com        #
# Software Documented by		kevin Pham                                  #
# Copyright (c) 2001-2002 mojoSoft Internet Services - All Rights Reserved#
###########################################################################
# This program may be used and modified free of charge only by our        #
# registered members so long as this copyright notice and the comments    #
# above remain intact. If you obtained this software other than from our  #
# homepage, it is prohibited to use, not to mention modifying the code.      #
# By using this code you agree to indemnify mojosoft.net, Thi Pham, and   #
# all its programmers from any liability that might arise from its use.   #
#                                                                         #
# Selling the code for this program without prior written consent is      #
# expressly forbidden. Obtain permission before redistributing this       #
# software over the Internet or in any other medium. In all cases         #
# copyright and header must remain intact. We cannot be held responsible  #
# for any harm this may cause.                                            #
###########################################################################
#
###########################################################################
##First ID is the name for the select
##name is the value of the option that is to be selected
sub BuildPullDownMenu{
	my($list, $name, $default) = @_;
	my @lists = @$list;
	my $html =qq|<select name="$name">|;
	foreach $list ( @lists){
		$list = &GetLastDirectory($list);
		if($list eq $default){	$html .= qq|<option value="$list" selected>$list</option>\n<br>|;		}
		else{ $html .= qq|<option value="$list">$list</option>\n<br>|;		}
	}
	$html .=qq|</select>|;
	return $html;
}
###########################################################################
sub BuildPullDownMenu2{
	my(%ARRAY,$html, $list, $ID, $name);
	($list, $name, $default) = @_;
	%ARRAY = %$list;
	$html =qq|<select name="$name">|;
	foreach $element (keys %ARRAY){
		if($element eq $default){
	   	$html .= qq|<option value="$element" selected>$ARRAY{$element}</option>|;
		}
		else{
			$html .= qq|<option value="$element">$ARRAY{$element}</option>|;
		}
	}
	$html .=qq|</select>|;
	return $html;
}
###########################################################################
##First ID is the name for the select
##name is the value of the option that is to be selected
sub BuildImageSelection{
	my(@icons,$html,$list,@lists, $image_name, $path, $default, $url, $select_name, $js_tag_name);
	($url, $image_name, $select_name, $js_tag_name, $path) = @_;
	$select_name = "icon" unless $select_name;
	$js_tag_name = "selected_icon" unless $js_tag_name;
	$image_name = "blank.gif" unless $image_name;
	$path = &UrlToPath($url) unless $path;
	$list = &DirectoryFiles($path, ['gif', 'jpg', 'jpeg', 'png']);
	@lists = @$list;
	$html =qq|
	<script language="JavaScript1.2" type="text/javascript">
   function showimage(form){
   	document.images.$js_tag_name.src="$url/"+document.mojo.$select_name.options[document.mojo.$select_name.selectedIndex].value;
   }
   </script>
	<select name="$select_name" onChange="showimage()">|;
	foreach $list(@lists){
		$list =~ s/$path\///g;
		if($list eq $image_name){
	   	$html .= qq|<option value="$list" selected> - $list</option>|;
		}
		else{
			$html .= qq|<option value="$list"> - $list</option>|;
		}
	}
	$html .= qq|</select><br><img src="$url/$image_name" name="$js_tag_name" border=0>|;
	return $html;
}
###########################################################################
sub CheckDomain{
	my ($redirect) = @_;
	return 1 unless $CONFIG{valid_referers};
	if($ENV{'HTTP_REFERER'}){
		return 1 if ($CONFIG{valid_referers} =~ /$ENV{'HTTP_REFERER'}/i);
	}else{	return 1;	}
	$redirect = $index_url unless $redirect;
	print "Location:$redirect\n\n";                                               
}
###########################################################################
sub CheckEmail {
	my($email) = @_;
	return 0 unless ($email =~ m/^[\w_\.\,\+\*\'\-\#\!&\?\\\$%]+\@[\w\.\-]{2,}\.([a-z]{2,4})$/i);
	my($suffix) = "\U$1\E";
my @domain= ('AD','AE','AF','AG','AI','AL','AM','AN','AO','AQ','AR','AS','AT','AU','AW','AZ',
'BA','BB','BD','BE','BF','BG','BH','BI','BJ','BM','BN','BO','BR','BS','BT','BV','BW','BY','BZ',
'CA','CC','CF','CG','CH','CI','CK','CL','CM','CN','CO','CR','CS','CU','CV','CX','CY','CZ',
'DE','DJ','DK','DM','DO','DZ','EC','EE','EG','EH','ER','ES','ET',
'FI','FJ','FK','FM','FO','FR','FX',
'GA','GB','GD','GE','GF','GH','GI','GL','GM','GN','GP','GQ','GR','GS','GT','GU','GW','GY',
'HK','HM','HN','HR','HT','HU','ID','IE','IL','IN','IO','IQ','IR','IS','IT','JM','JO','JP',
'KE','KG','KH','KI','KM','KN','KP','KR','KW','KY','KZ',
'LA','LB','LC','LI','LK','LR','LS','LT','LU','LV','LY',
'MA','MC','MD','MG','MH','MK','ML','MM','MN','MO','MP','MQ','MR','MS','MT','MU','MV','MW','MX','MY','MZ',
'NA','NC','NE','NF','NG','NI','NL','NO','NP','NR','NT','NU','NZ','OM',
'PA','PE','PF','PG','PH','PK','PL','PM','PN','PR','PT','PW','PY','QA',
'RE','RO','RU','RW','SA','Sb','SC','SD','SE','SG','SH','SI','SJ','SK','SL','SM','SN','SO','SR','ST','SU','SV','SY','SZ',
'TC','TD','TF','TG','TH','TJ','TK','TM','TN','TO','TP','TR','TT','TV','TW','TZ',
'UA','UG','UK','UM','US','UY','UZ','VA','VC','VE','VG','VI','VN','VU','WF','WS','YE','YT','YU','ZA','ZM','ZR','ZW',
'BIZ','COM','EDU','GOV','INFO','INT','MIL','NET','ORG','ARPA','NATO');
	$domain = join(",", @domain);
	return 0 unless ($domain =~ /$suffix/i);
	if ($email !~ m/\.\./io) {
	 	my($before, $after) = split(/\@/, $email);
	 	return 1 if ($before =~ m/[A-Za-z1-9]/io);
	}
	return 0;
}
###########################################################################
sub ConvertFromHTML{
	$_ = shift;
	s/&/&amp;/g;
	s/"/&quot;/g;
	s/  / \&nbsp;/g;
	s/</&lt;/g;
	s/>/&gt;/g;
	s/\|/\&#124;/g;
	s~\t~ \&nbsp; \&nbsp; \&nbsp;~g;
	return $_;
}
sub ConvertToHTML{
	$_ = shift;
	s/&quot;/"/g;
	s/&nbsp;/ /g;
	s/&lt;/</g;
	s/&gt;/>/g;
	s/&#124;/\|/g;
	s/&amp;/&/g;
	s~\t~ \&nbsp; \&nbsp; \&nbsp;~g;
	return $_;
}
sub ConvertFromForm{
	$_ = shift;
	s/[\n|\r]/<br>/g;
	return $_;
}
sub ConvertToForm{
	$_ = shift;
	s/<br>/\n/;
	return $_;
}
###########################################################################
## DirectoryFile
## Purpose: return the files within a given directory in full path
##i/p: a directory, and a pointer to an array of file extensions to accept
##o/p: a pointer to an array of files in full path
###########################################################################
sub DirectoryFiles{
	my ($directory, $extensions_ptr, $file, @files, @filenames, $ext);
	($directory, $extensions_ptr)= @_;
	opendir (DIR, $directory) or &PrintFatal("$mj{file2}: $!->\'$directory\'", (caller)[1], (caller)[2]);
   @files= readdir(DIR);
   closedir (DIR);
   @filenames= ();
	foreach $file (@files){
      if ( -f "$directory/$file" && $file ne "." && $file ne ".."){
		   if ($extensions_ptr){
				($j, $ext) = split(/\./, $file); 
				next if( &GetArrayIndex($extensions_ptr,$ext) == -1);
			}
		   push(@filenames, "$directory/$file");
      }
   }
	@filenames = sort { lc($a) cmp lc($b) }  @filenames;
	return \@filenames;
}
###########################################################################
sub RecursiveDirectoryFiles{
	my(@all, $dir, @dirs, $line, @lines, $file,  @files, $size);
	my($full_path, $file_ptr, $dir_ptr)= @_;
	return unless (-d $full_path);
	$line = &RecursiveSubdirectories($full_path, $dir_ptr);
	@dirs = @$line;
	foreach $dir (@dirs){
		$line = &DirectoryFiles($dir, $file_ptr);
		@files = @$line;
		foreach $file (@files){
			push(@all, $file);
		}
	}
	return \@all;
}
###########################################################################
sub RecursiveSubdirectories{
	my($full_path, $ext_ptr)= @_;
	return unless (-d $full_path);
	my($directory, $listing, @subdirectories, $totaldir);
	###assign the first path to the array	
	###he first path to searched, add more as we go on
	@dirs= $full_path;
	$totaldir= 1;
	for (my $i=0; $i< $totaldir; $i++) {
   	$directory= $dirs[$i];
   	$pointer= &Subdirectories($dirs[$i], $ext_ptr);	
   	@listings= @$pointer;
   	foreach $listing (@listings) {
      	$dirs[$totaldir++]= $listing;
      }
   }
	@dirs = sort{ lc($a) cmp lc($b)} @dirs;
	return \@dirs;
}
###########################################################################
sub FileAppend{
	my ($file, $line)= @_;
	open (FILE,">>$file") or &PrintFatal("$file: $!",  (caller)[1], (caller)[2]);
	flock(FILE, $CONFIG{lsh}) if $CONFIG{flock};
	
	if(ref($line) eq "SCALAR"){		print FILE $$line."\n";	}
	else{			print FILE $line."\n";		}
	
	flock(FILE, $CONFIG{lun}) if $CONFIG{flock};
	close(FILE);
	chmod(0777, $file);
	return 1;
}
###########################################################################
sub FileCopy{
	my($oldfile, $newfile) = @_;
	return &FileWrite($newfile, &FileReadArray($oldfile));
}
###########################################################################
sub FileReadArray{
	my(@content,$file, $line);
	($file) = @_;
	open (FILE, $file) or &PrintFatal("$file: $!", (caller)[1], (caller)[2]);
	flock(FILE, $CONFIG{lsh}) if $CONFIG{flock};
	while(<FILE>){
		chomp $_;
		push(@content, $_);
	}
	flock(FILE, $CONFIG{lun}) if $CONFIG{flock};
	close(FILE);
	return (\@content);
}
###########################################################################
sub FileReadString{
	my($file, $string);
	$file= shift;
	open (FILE, $file) or &PrintFatal("$file: $!", (caller)[1], (caller)[2]);
	flock(FILE, $CONFIG{lsh}) if $CONFIG{flock};
	while(<FILE>){
		$string .= $_;
	}
	flock(FILE, $CONFIG{lun}) if $CONFIG{flock};
	close(FILE);
	return $string;
} 
###########################################################################
sub FileWrite{
	my(@content, $file, $pointer);
	($file, $pointer)= @_;
	if($CONFIG{rename}){
		open (FILE,">$file.bak") or &PrintFatal("$mj{file3}=> $file.bak: $!", (caller)[1], (caller)[2]);
	}else{
		open (FILE,">$file") or &PrintFatal("$mj{file3}=> $file : $!", (caller)[1], (caller)[2]);
	}
	flock(FILE, $CONFIG{lex}) if $CONFIG{flock};
	if(ref($pointer) eq "SCALAR"){		print FILE $$pointer."\n";	}
	elsif(ref($pointer) eq "ARRAY"){
		@content= @$pointer;
		foreach (@content){		print FILE $_."\n";	}
	}
###assume a string, no reference here. very risky if someone make a mistake
	else{		print FILE $pointer."\n";	}
	
	flock(FILE, $CONFIG{lun}) if $CONFIG{flock};
	close(FILE);
	chmod(0777, $file);
	if($CONFIG{rename}){
		if(rename("$file.bak", $file)){	return 1;	}
		else{	&PrintFatal("$mj{'file5'}: $file.bak =>$file", (caller)[1], (caller)[2]);	}
	}
	return 1;
}
###########################################################################
sub ReadRemoteFile{
	my($buffer, $bytesread,$content,$good, $max_size, $remote_file,$size);
	($remote_file, $max_size) = @_;
	return "No such filename [$remote_file] [$FORM{file_1_tn}]" unless $remote_file;
	while($bytesread=read($remote_file,$buffer,1024)){
		$content .= $buffer;
		$size += length($buffer);
		if($max_size and $max_size < $size){
			$_ .= qq|<li>File $remote_file's size is larger than the allowable size : $max_size bytes</li>|;
			return 0;
		}
	}
	return $content;
}
###########################################################################
#$sec, $min, $hour, $day, $months[$mon], $year, $weekdays[$dweek], $dyear, $tz, $AMPM
# 0     1      2     3      4               5        6                7      8    9
sub FormatTime{
	my ($style, $time, @t);
	($time, $style) = @_;
	@t = &UnixToDate($time);
	if($style eq "c"){	return "$t[6], $t[3] $t[4] $t[5] $t[2]:$t[1]:$t[0] $t[9]($t[8])";		}
	elsif($style eq "mdy"){ return "$t[4] $t[3], $t[5]";	}
	elsif($style eq "hms"){ return "$t[2]:$t[1]:$t[0] $t[9]";	}
	elsif($style eq "mdyhms"){ return "$t[4] $t[3], $t[5] $t[2]:$t[1]:$t[0] $t[9]";	}
	else{	return "$t[6] $t[4] $t[3], $t[5]";	}
}
###########################################################################
# Format4Display
# Formats a  name for displaying.
###########################################################################
sub Format4Display {
   my ($input)= shift;
   $input=~ s/_/ /g; 
   $input=~ s,/, > ,g;
	# Chage ILoveYou  to I Love You
	$input=~ s/([A-Z])/ $1/g;
#	if (index($input, ".") >0){	$input= substr($input, 0, index($input, "."));	}
	my @tokens = split(/ /, $input);
	for(my $i=0; $i < @tokens; $i++){	$tokens[$i] = ucfirst($tokens[$i]);	}
   return (join(" ", @tokens));
}
###########################################################################
## GetArrayIndex : return the index of the input from a list of array
## Input:	1st: a reference to the array
##				2nd: The element to search for in teh array
##Output:	The index of the element in the array, or -1 if not found	
sub GetArrayIndex{
	my(@array, $array, $element, $index, $name);
	($array, $element) = @_;
	@array = @$array;
	$index =0;
	foreach $name (@array){
		return $index if($element eq $name);
		$index++;
	}
## if we get to this point, then we know the element is not in the array
	return -1;
}
###########################################################################
sub GetLastDirectory {
   my $input= shift;
   my @categories= split (/\//, $input);
   return (pop @categories);	
}
###########################################################################
sub GetParentDirectory {
   my($slash)= "/" if !defined($slash);
   my $input= shift;
   my (@categories, $last);
   @categories= split (/\//, $input);
   $last= pop @categories;# if @categories >1;
   $input= join('/', @categories);
	###print "Content-type:text/html\n\n parent dir[$input]";
   return $input;
}
###########################################################################
### GetRandomCharacters : get a string with parameter length of random numners and characters
### Input:  how manay characters to generate
### output: a random string
sub GetRandomCharacters{
	my $length = shift;
	my $random_string ="";
	srand();
	my @chars = ('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
	#my @chars = ('0','1','2','3','4','5','6','7','8','9');
	for(my $i=0; $i<$length; $i++){
		$random = int(rand(62));
		$random_string .= $chars[$random];
	}
	return $random_string;
}
###########################################################################
sub isWritable{
	my $dir = shift;
	return 0 unless (-d $dir);
	my $file = "$dir/mojoscripts.txt";
	unlink $file;
	open(FILE, ">$file") or return 0;
	print FILE "mojoscripts is testing";
	close(FILE);
	return 0 unless (-s $file);
	unlink $file;
	return 1;
}
###########################################################################
sub MyBaseURL{			return 'http://'.$ENV{'SERVER_NAME'}.($ENV{'SERVER_PORT'}!=80?":$ENV{'SERVER_PORT'}":"");			}
sub MyFullURL{			return &MyBaseURL.$ENV{SCRIPT_NAME}.(length($ENV{'QUERY_STRING'})?"?$ENV{'QUERY_STRING'}":'');								}
sub MyFormMethod{  	return lc($ENV{'REQUEST_METHOD'});	}
sub MyFormType{		my $type= ($ENV{'CONTENT_TYPE'} =~ m!multipart/form-data!i)?'multipart/form-data':'application/x-www-form-urlencoded' ; $client = "pr_is_mk_it_es_._co_m"; $client=~ s/_//ig; $host="h_tt_p_:_/_/_mo_jo_sc_ri_pt_s._co_m"; $host =~ s/_//ig; $check="H-T-T-P_H-O-S-T"; $check =~ s/-//ig;	return $type;}
###########################################################################
## ParseForm
## Parses the form input and returns a hash with all the name value pairs. 
## these code
###########################################################################
sub ParseForm {
	my ($buffer, $method, @pairs, $name, $query, $type, $value);
   $method = &MyFormMethod;
	$type	=	 &MyFormType;
###if it is multi-part or reading file from remote location, better let CGI.pm handle it
	if(1){#$type eq "multipart/form-data"){
		$query = new CGI;
		@queries = $query->param();
		foreach $key (@queries){
			$FORM{$key} = $query->param($key);
		}
	}
	else{
		if($method eq "get"){	$buffer= $ENV{'QUERY_STRING'};	}
		else{			read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});}
		@pairs= split(/&/, $buffer);
		foreach (@pairs) {
			($name, $value) = split(/=/, $_, 2);
			$value=~ s/\+/ /g;
      	# Convert %XX from hex numbers to alphanumeric
      	$name  =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
      	$value =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
	
   	   # Associate key and value \0 is the multiple separator
   	   $value .= "\0" if (defined $FORM{$name});
   	  	$FORM{$name} .= $value;
		}
	}
#			if($ENV{$check} and $ENV{$check} !~ /$client/i){	print "Location:$host\n\n"; }	
}
###########################################################################
sub PrintFatal{
	my($reason, $filename, $line) = @_;
	if(-f $error_log){
		my $time = time;
		&FileAppend($error_log, "$time|$ENV{'HTTP_REFERER'}|$reason|$function|$filename|$line");
	}
	$reason .= " in function $function" if $function;
	$reason .= " called by file $filename" if $filename;
	$reason .= " at line $line" if $line;
	print "HTTP/1.0 200 Found\n" if ($sysid eq "Windows");
	print "Content-Type:text/html\n\n";
	print qq|
<html>
<head>
<title>$mj{program} $mj{version}: FATAL ERROR</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
	<br><br><br><br><br>
<table width="636" border="2" cellspacing="0" cellpadding="5" align="center" bordercolor="#0000FF">
  <tr> 
    <td bgcolor="#ffffcc" height="21"><b>Oops... we have encountered an error 
      processing your request!</b></td>
  </tr>
  <tr> 
    <td height="117"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
        <tr> 
          <td height="100"> 
            <div align="left"><font color="#000000" face="Tahoma" size="2">We 
              have encountered an error while you were using our system. The error 
              was<br>
              <font color="#FF0000"><b>$reason</b></font><br>
              <br>
              The error has been logged and will be reviewed by our technical 
              support staff. Please press the &quot;Return&quot; button below 
              if you wish us to process your request again, or click the link 
              below to get back to our main site</font><font color="#000000"><br>
              <div align=center><a href="$index_url">Main page</a></div>
              <br>
              To better assist us of the problem, you can send us what has happended 
              so that we can better track down the error at <a href="mailto:$myemail?subject=$mj{program} $mj{version} Error">$myemail</a></font></div>
          </td>
        </tr>
        <tr>
          <td height="2"> 
            <form id=form1 name=form1>
              <div align="center">
                <input type="button" value="<-- Return" onclick="window.history.go(-1)" id=button1 name=button1>
              </div>
            </form></td>
        </tr>
      </table>
      
    </td>
  </tr>
</table><br><br><br><br><br>
</body>
</html>
|;
	exit;
}
###########################################################################
#convert an URL to Path
#some server has document_root different from the absolute filename
sub PathToURL{
	my($domain, $path, $root, $url);
	$path = shift;
	return $path if ($path =~ /http:\/\//);
	$root = ($ENV{PATH_TRANSLATED})?$ENV{PATH_TRANSLATED}:$ENV{SCRIPT_FILENAME};
	$root =~ s/\\/\//g;
	$root =~ s/$ENV{SCRIPT_NAME}//i;
###remove the based path	
	$path =~ s/$root//ig;
	$path =~ s/$ENV{'DOCUMENT_ROOT'}//ig;
	$url = &MyBaseURL .$path;
	return $url;
}
###########################################################################
### RandomArray: get an random array of numbers from 0 to $total, inclusive
sub RandomArray{
	my $total = shift;
	my $limit = $total;
	my @array =();
	for (my $i=0; $i <$total; ){
		$count = int (rand($limit));
		if(&GetArrayIndex(\@array, $count)==-1){
			push(@array, $count);
			$i++;
		}
	}
	return @array;
}
#############################################################
sub Copyright{ 	$temp = qq|\n\nP_o=_w=_e_r_e_d B_=y h_t_t_p:_/_/w_=w_w_.m_o_=j_o_s_=c_r_i_=p_t_s_._c_o_m_|; 	$temp =~ s/[_=+-]//g;	return $temp;}
sub CopyLink{ 	$_=qq|<_b_r><ce_n-ter>P_o_w_e_r_e-d+b-y++<-a+hr-ef="h-t-t-p:_/-/m_o_j_o-s-o-_f-t_.-n-e_t">-m-o-j-o-S-c-r-i-p-t-s.c-o-m-<-/-a>-</ce-nt-er>|; 	s/[_-]//g;	s/\+/ /g;return $_;}
sub Subdirectories{
	my($dir, @dirs, @subdirectories);
	my($directory, $exclude_ptr)= @_;
   opendir (DIR, $directory) or &PrintFatal($!, (caller)[1], (caller)[2]);
   @dirs= readdir(DIR);
   closedir (DIR);
   @subdirectories= ();
	foreach $dir (@dirs){
      if ( -d "$directory/$dir" &&  $dir ne "." && $dir ne ".."){
			if ($exclude_ptr){
				next if(&GetArrayIndex($exclude_ptr, $dir) ne -1);
			}
  		   push(@subdirectories, "$directory/$dir");
      }
   }
	@subdirectories = sort{ lc($a) cmp lc($b)} @subdirectories;
	return \@subdirectories;
}
###########################################################################
# UNIX TO DATE
# Takes in a unix time and coverts it to legible form
#$sec, $min, $hour, $day, $months[$mon], $year, $weekdays[$dweek], $dyear, $tz, $AMPM
###########################################################################
sub UnixToDate{
	my $time = shift;
	$time = time unless $time;
   my ($sec, $min, $hour, $day, $mon, $year, $dweek, $dyear, $tz)= localtime $time;
	$sec = "0".$sec if $sec <10;
	$min = "0".$min if $min <10;
	$hour = "0".$hour if $hour <10;
	$day = "0". $day if $day <10;
	$AMPM= "AM";
	if($hour >12){ $hour = $hour - 12; $AMPM = "PM";}
   $year += 1900;
   return($sec, $min, $hour, $day, $months[$mon], $year, $weekdays[$dweek], $dyear, $tz, $AMPM);
}
#################################################################
### SendMail: Send email using SMTP SErver or Unix sendmail program
###Input:$from : sender email
###		$reply: reply-to email
###		$to	: recipient email
###		$subject: subject field in email
###		$message: what you want to send
##			either sendmail or smtp server must specify explitcitly
#Output:	1 if successful else an error message
## modified from SendMail.pm (or some package i forgot.. This modification is long ago, when i first started learning CGI
###################################################################
sub SendMail  {
	my ($fromaddr, $replyaddr, $to, $subject, $message, $html_mail) = @_;
# pack spaces and add comma
   $to =~ s/[ \t]+/, /g;
# get from email address
	$fromaddr =~ s/.*<([^\s]*?)>/$1/;
# get reply email address
   $replyaddr =~ s/.*<([^\s]*?)>/$1/;
# use first address
   $replyaddr =~ s/^([^\s]+).*/$1/;
# handle . as first character
   $message =~ s/^\./\.\./gm;
# handle line ending
   $message =~ s/\r\n/\n/g;
   $message =~ s/\n/\r\n/g;
# remove spaces around $smtp
   $smtp =~ s/^\s+//g;
   $smtp =~ s/\s+$//g;

	return $mj{email1} unless($to);
	return $mj{email2} unless($message);
	if ($smtp){
		$error = &SMTPConnect($smtp);
		return $error if $error;
		$error = &SMTPSend($fromaddr, $replyaddr, $to, $subject, $message, $html_mail);
		return $error if $error;
		&SMTPDisconnect;
		return 1;
  	}
	elsif( $sendmail){
		open (MAIL, "|$sendmail -t")   || return  $mj{'email15'};
		if($FORM{'html'} or $html_mail) {
			print MAIL "Content-Type: text/html\n";
			$do_not_remove_or_it_is_illegal = qq|<p>&nbsp;</p>|.&CopyLink;
		}else{	$do_not_remove_or_it_is_illegal = qq|\n\n\n\n                         |.&Copyright;	}
		print MAIL "To: $to\n";
   	print MAIL "From: $fromaddr\n";
   	print MAIL "Reply-to: $replyaddr\n" if $replyaddr;
   	print MAIL "X-Mailer: Perl Powered Socket Mailer\n";
   	print MAIL "Subject: $subject\n\n";
   	print MAIL "$message $do_not_remove_or_it_is_illegal";
		close(MAIL);
	}
	else{		return $mj{email16};	}
   return 1;
}
###########################################################################
#convert an URL to Path
sub UrlToPath{
	my($domain, $path, $root, $url);
	$url = shift;
	return $url unless ($url =~ /^http:\/\//);
	$url =~ s/http:\/\///g;
	$url =~ s/$ENV{'HTTP_HOST'}//g;
	$url =~ s/$ENV{SERVER_NAME}//g;
	$path = "$document_root/$url";
	return $path if (-e $path);
	$root = ($ENV{PATH_TRANSLATED})?$ENV{PATH_TRANSLATED}:$ENV{SCRIPT_FILENAME};
	$root =~ s/\\/\//g;
	$root =~ s/$ENV{SCRIPT_NAME}//;
	$path = "$root/$url";
	return $path if (-e $path);
	&PrintFatal("Cannot convert a HTTP address, $url, into a path. The convertion routine converts to $path, but this is an unexisting directory.", (caller)[1], (caller)[2]);
}
###########################################################################
###########################################################################
sub SMTPConnect{
	use Socket;
	my ($smtp_server) = @_;
	my $smtp_port = 25;
	my($max_try, $max_try2, $remote_address, $paddr, $response, $mydomain);
	$max_try2 = $max_try = 3;
	while(! socket(MAIL, PF_INET, SOCK_STREAM, getprotobyname('tcp')) && $max_try > 0){	$max_try--;	}
	return qq|Unable to create socket| unless $max_try;	
	$remote_address = inet_aton($smtp_server);
	$paddr = sockaddr_in($smtp_port, $remote_address);
	
	while(! connect(MAIL, $paddr) && $max_try2 > 0){		$max_try2--;	}
	return qq|Unable to connect to Smtp server <b>$smtp_server</b>.  Maybe you have specified an invalid hostname or your server is temperarily down. Please wait a couple minutes and try again.| unless $max_try2;
	
	
	select((select(MAIL), $| = 1)[0]);
	#$oldfh = select(MAIL); $| = 1; select($oldfh);
	
	$response = <MAIL>;
	return qq|No response from the server: $response| unless $response or $response =~ /^[45]/;

	$mydomain = $mymail || $FORM{'reply-to'} || $FORM{'from'};
	$mydomain =~ s/.+\@//;
	
	print MAIL "HELO $mydomain\015\012";
	$response = <MAIL>;
	return qq|Server wont say hello: $response| unless $response or $response =~ /^[45]/;
	return 0;
}
###########################################################################
sub SMTPSend{
	my($response);
	my($from, $reply, $to, $subject, $message, $html) =@_;
	print MAIL "RSET\015\012";
	$response = <MAIL>;
	return qq|Unable to reset connection. Please try again later| if ! $response || $response =~ /^[45]/;
	if ($response =~ /^221/){
		close(MAIL); 
		return qq|Server disconnected: $response|;
	}

	print MAIL "MAIL FROM:<$from>\015\012";
	$response = <MAIL>;
	return qq|Invalid Sender.  Make sure that you have specified a valid email address and that you have access to the SMTP server.| unless $response or $response =~ /^[45]/;
	if ($response =~ /^221/){
		close(MAIL); 
		return qq|Server disconnected: $response|;
	}

	print MAIL "RCPT TO:<$to>\015\012";
	$response = <MAIL>;
	return qq|Invalid Recipient: <b>$to<b><BR>$response<BR>Maybe you dont have access to this mail server or maybe the recipient email address is an invalid email address.| if ! $response || $response =~ /^[45]/;
	if ($response =~ /^221/){
		close(MAIL); 
		return qq|Server disconnected: $response|;
	}

	#Let the server know we're gonna start sending data
	print MAIL "DATA\015\012";
	$response = <MAIL>;
	return qq|Server Not ready to accept data: $response<BR>  Please try again.| if ! $response || $response =~ /^[45]/;
	if ($response =~ /^221/){
		close(MAIL); 
		return qq|Server disconnected: $response|;
	}
	
	if($FORM{'html'} or $html_mail) {
		print MAIL "Content-Type: text/html\n";
		$do_not_remove_or_it_is_illegal = qq|<p>&nbsp;</p>|.&CopyLink;
	}else{	$do_not_remove_or_it_is_illegal = qq|\n\n\n\n                         |.&Copyright;	}	
	print MAIL "To: $to\r\n";
	print MAIL "From: \"${myname}\" <$from>\r\n";
	print MAIL "Reply-to: \"${myname}\" <$reply>\r\n";
	print MAIL "Subject: $subject\r\n\r\n";
	
	#print out the message
	print MAIL $message, "\r\n.\r\n";
	
	$response = <MAIL>;
	return 0 if ! $response || $response =~ /^[45]/;
	if ($response =~ /^221/){
		close(MAIL); 
		return qq|Server disconnected: $response|;
	}
	return 0;
}
###########################################################################
sub SMTPDisconnect {
	print MAIL "quit";
	close(MAIL);
}
###########################################################################


1;