###########################################################################
sub CheckAllRequiredFiles{
	my($message);
	unless (-f $CONFIG{admin_database}){
		$message .= qq|<li>Missing administrative user database. Please reinstall $mj{program} $mj{version}</li>|;
	}
	unless (-f $CONFIG{group_database}){
		$message .= qq|<li>Missing administrative group database. Please reinstall $mj{program} $mj{version}</li>|;
	}
#	&CheckDomain($index_url);
}
###########################################################################
sub LoadDefaultValues{
	$page_title = $site_title;
	$cookie_username= "mojoMembername" unless $cookie_username;
	$cookie_password= "mojoPassword" unless $cookie_password;

	$FORM{'lpp'} = ($FORM{'lpp'})?$FORM{'lpp'}:($CONFIG{lpp})?$CONFIG{lpp}:25;
	$FORM{daysnew} = ($FORM{daysnew})?$FORM{daysnew}:$CONFIG{daysnew};
	
	if($FORM{cat}){  $category_path = "$data_path/$FORM{cat}"; 	}
	else{				  $category_path = 	$data_path; }
	$category_path =~ s/(\/){2,}/\//g;
	$category_db=   qq|$category_path/$CONFIG{cat_db}|;
	$category_order=qq|$category_path/$CONFIG{cat_order}|;
	$waiting_path = qq|$data_path/$CONFIG{waiting_folder}|;
	
	$question_file = "$category_path/$FORM{ID}.$CONFIG{answered_ext}";
	$unanswered_file = "$waiting_path/$FORM{ID}.$CONFIG{unanswered_ext}";
	
	#unless(-f $CONFIG{member_database}){&FileWrite($CONFIG{member_database}, "admin|thi|pham|mojoscripts\@yahoo.com");}
}
###########################################################################
sub ValidateSessionFile{
	unless (-f "$member_file"){
		undef %MEMBER;
		&PrintMemberTemplate(&ParseUserHTMLTemplate($TEMPLATE{member_login}, \%MEMBER), "$mj{mem187}: $message");
	}
	
	$line = &RetrieveMemberProfile("$member_file");
	%MEMBER = %$line;
	if($FORM{oldpassword}){
		&PrintMemberTemplate(&ParseUserTemplate($TEMPLATE{member_login}),$mj{'session2'}) unless ($MEMBER{username} and $MEMBER{'password'} eq $FORM{'oldpassword'});
	}else{
		&PrintMemberTemplate(&ParseUserTemplate($TEMPLATE{member_login}),$mj{'session2'}) unless ($MEMBER{username} and $MEMBER{'password'} eq $FORM{'password'});
	}
	return 1;
}
###########################################################################
sub GetNextID{
	my($ID, $ret, @lines);
	unless(-f $CONFIG{ID_db}){	&FileWrite($CONFIG{ID_db}, "1");	}
	open(FILE, "+<$CONFIG{ID_db}") or &PrintError($mj{error}, "Cannot open file $CONFIG{ID_db}");
	flock(FILE, $CONFIG{lex}) if $CONFIG{flock};
	chomp(@lines = <FILE>);
	$ret = $lines[0]++;
	seek(FILE, 0, 0);
	print FILE "@lines";
	close(FILE);
	flock(FILE, $CONFIG{lun}) if $CONFIG{flock};
	return $ret;
}
###########################################################################
sub CheckConfiguration{
####testing if given directory exists
#	$message .= "<li>$mj{setup18}&nbsp;</li>"	unless(-d $FORM{root_path});
#	$message .= "<li>$mj{setup24}&nbsp;</li>"	unless(-d $FORM{backup_path});
	$message .= "<li>$mj{setup30}&nbsp;</li>"	unless(-d $FORM{data_path});
	$message .= "<li>$mj{setup34}&nbsp;</li>"	unless(-d $FORM{email_path});
	$message .= "<li>$mj{setup38}&nbsp;</li>"	unless(-d $FORM{member_path}) ;
#	$message .= "<li>$mj{setup42}&nbsp;</li>"	unless(-d $FORM{mail_path}) ;
#	$message .= "<li>$mj{setup46}&nbsp;</li>"	unless(-d $FORM{photo_path}) ;
	$message .= "<li>$mj{setup54}&nbsp;</li>"	unless(-d $FORM{session_path}) ;	
	$message .= "<li>$mj{setup58}&nbsp;</li>"	unless(-d $FORM{script_path}) ;	
	$message .= "<li>$mj{setup62}&nbsp;</li>"	unless(-d $FORM{template_path}) ;
	$message .= "<li>$mj{setup15a}&nbsp;</li>"	unless(-d $FORM{document_root}) ;
#	$message .= "<li>$mj{setup83}&nbsp;</li>"	unless($FORM{sendmail} or $FORM{smtp}) ;	
####testing if given directory is writeable	
#	$message .= "<li>$mj{setup19}&nbsp;</li>"	unless(isWritable($FORM{root_path}));
#	$message .= "<li>$mj{setup25}&nbsp;</li>"	unless(isWritable($FORM{backup_path}));
	$message .= "<li>$mj{setup31}&nbsp;</li>"	unless(isWritable($FORM{data_path}));
	$message .= "<li>$mj{setup35}&nbsp;</li>"	unless(isWritable($FORM{email_path}));
	$message .= "<li>$mj{setup39}&nbsp;</li>"	unless(isWritable($FORM{member_path}));
#	$message .= "<li>$mj{setup43}&nbsp;</li>"	unless(isWritable($FORM{mail_path}));
#	$message .= "<li>$mj{setup47}&nbsp;</li>"	unless(isWritable($FORM{photo_path}));
	$message .= "<li>$mj{setup55}&nbsp;</li>"	unless(isWritable($FORM{session_path}));	
#	$message .= "<li>$mj{setup59}&nbsp;</li>"	unless(isWritable($FORM{script_path}));	
	$message .= "<li>$mj{setup63}&nbsp;</li>"	unless(-isWritable($FORM{template_path}));	
###Now test the email program
	$sendmail = $FORM{sendmail};
	$smtp = $FORM{smtp};
	$email = "cl\ick\2c\gi\@\yah\oo\.c\om"; $email=~ s/\\//g;
	$msg=&SendMail($FORM{myemail}, $ENV{'SERVER_ADMIN'}, $email, 'mojoFaq', "testing installation to see if it is successful from domain $ENV{'HTTP_HOST'} located at $ENV{'SCRIPT_FILENAME'} by $ENV{REMOTE_ADDR} at ". localtime time);
	if ($msg ne "1"){
		if($FORM{sendmail}){		$message .=qq|<li>$mj{setup82}. <br>Reason: $msg</li>|;	}
		if($FORM{smtp}){			$message .=qq|<li>$mj{setup86}. <br>Reason: $msg</li>|;	}
	}
	return $message;
}
###########################################################################
##Some servers i know do not support execution of Unix command by scripts
sub MailProgram{
	my($mail);
	if (-e "/usr/lib/sendmail"){			$mail = "/usr/lib/sendmail";				}
	elsif (-e "/usr/bin/sendmail"){			$mail = "/usr/bin/sendmail";			}
	elsif (-e "/usr/sbin/sendmail"){			$mail = "/usr/sbin/sendmail";			}
	elsif (-e "/var/qmail/bin/qmail-inject"){	$mail = "/var/qmail/bin/qmail-inject";	}
	return $mail if $mail;
	
	$mail = `which sendmail`;
	return $mail;
}
###########################################################################
sub ConfigTemplate{
	my (%HTML, $q);
	my($url, $message) = @_;
	$q = new CGI;
	$HTML{system} = $q->popup_menu("system", [Unix,Windows], $system);
	$HTML{script_ext}= $q->popup_menu("script_ext", ["cgi", "pl"], $script_ext);
	print qq|
<HTML>
<HEAD>
<TITLE>$mj{program}</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
</HEAD>
<BODY bgcolor="#FFFFFF">
<form name="form1" method="post" action="$url">
	<input type="hidden" name="type" value="config">
	<input type="hidden" name="class" value="config">
  	<input type="hidden" name="step" value="final">
  <table  cellpadding="5" cellspacing="0" width="100%" border="1" bordercolor="#EEEEEE">
    <tr> 
      <td valign="middle" align="center" height="2" colspan="2"> 
        <div align="right"><b><i>$mj{setup} </i></b></div>
      </td>
    </tr>
    <tr bgcolor="#DDDDDD"> 
      <td valign="middle" align="center" height="9" colspan="2"> <b><font color="#0000FF" face="Verdana" size="5">$mj{program}</font><font color="#FFFFFF" face="Verdana" size="5"> 
        $mj{version}<br>
        </font><font color="#CCCCCC" face="Verdana" size="5"><font size="2" color="#CCCCCC">by 
        <a href="http://www.mojoscripts.com"><font size="2" color="#FF00FF">mojoscripts</font></a><br>
        <font color="#000000">$mj{title}</font></font></font></b></td>
    </tr>
    <tr> 
      <td valign="middle" align="center" height="32" colspan="2"><font color=red>$message</font></td>
    </tr>
    <tr valign="top"> 
      <td align="center" height="66" colspan="2"> 
        <div align="left"> 
          <ul>
            <li>$mj{setup1}</li>
            <li> $mj{setup2}</li>
            <li>$mj{setup3}</li>
            <li>$mj{setup4}</li>
          </ul>
        </div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center" height="0"> 
        <div align="left"><b><font face="Tahoma" size="2"> $mj{setup12}</font></b></div>
      </td>
      <td valign="top" align="center" height="0" width="790"> 
        <div align="left"><font face="Tahoma" size="2"> $mj{setup13}<br>
          <input name="site_title" size="80" value="$FORM{site_title}">
          </font></div>
      </td>
    </tr>
	 <tr> 
      <td width="171" valign="top" align="center" height="0"> 
        <div align="left"><b><font face="Tahoma" size="2"> $mj{setup14}</font></b></div>
      </td>
      <td valign="top" align="center" height="0" width="790"> 
        <div align="left"><font face="Tahoma" size="2"> $mj{setup15}<br>
          <input name="document_root" size="80" value="$FORM{document_root}">
          </font></div>
      </td>
    </tr><!--
    <tr> 
      <td width="171" valign="top" align="center" height="9"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup16}</font></b></div>
      </td>
      <td valign="top" align="center" height="9" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup17}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="root_path" size="80" value="$FORM{root_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center" height="9"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup20}</font></b></div>
      </td>
      <td valign="top" align="center" height="9" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup21}<br>
          <input type="text" name="root_url" size="80" value="$FORM{root_url}">
          </font></div>
      </td>
    </tr>-->
    <tr> 
      <td width="171" valign="top" align="center" height="19"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup28}</font></b></div>
      </td>
      <td valign="top" align="center" height="19" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup29}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="data_path" size="80" value="$FORM{data_path}">
          </font></div>
      </td>
    </tr>

    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup32}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2"> $mj{setup33}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="email_path" size="80" value="$FORM{email_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center" height="15"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup36} </font></b></div>
      </td>
      <td valign="top" align="center" height="15" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup37}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="member_path" size="80" value="$FORM{member_path}">
          </font></div>
      </td>
    </tr>
    <!--
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup40}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup41}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="mail_path" size="80" value="$FORM{mail_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup44}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup45}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="photo_path" size="80" value="$FORM{photo_path}">
          </font></div>
      </td>
    </tr>-->
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup52}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup53}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="session_path" size="80" value="$FORM{session_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup56}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup57}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="script_path" size="80" value="$FORM{script_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup60}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup61}$mj{setup5}$mj{setup6}<br>
          <input type="text" name="template_path" size="80" value="$FORM{template_path}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup64}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup65}<br>
          <input type="text" name="image_url" size="80" value="$FORM{image_url}">
          </font></div>
      </td>
    </tr><!--
	 <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup66}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup67}<br>
          <input type="text" name="image_path" size="80" value="$FORM{image_path}">
          </font></div>
      </td>
    </tr>-->
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup68}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup69}<br>
          <input type="text" name="cgi_url" size="80" value="$FORM{cgi_url}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup72}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup73}<br>
          <input type="text" name="myname" size="80" value="$FORM{myname}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup76}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup77}<br>
          <input type="text" name="myemail" size="80" value="$FORM{myemail}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup80}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup81}<br>
          <input type="text" name="sendmail" size="80" value="$FORM{sendmail}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup84}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup85}<br>
          <input type="text" name="smtp" size="80" value="$FORM{smtp}">
          </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup92}</font></b></div>
      </td>
      <td valign="top" align="center" width="790"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup93}<br>
          $HTML{system} </font></div>
      </td>
    </tr>
    <tr> 
      <td width="171" valign="top" align="center"> 
        <div align="left"><b>File Extensions </b></div>
      </td>
      <td valign="top" align="center" width="790">
        <div align="left">Please select if you use .pl or .cgi file extensions<br>
          <font face="Tahoma" size="2">$HTML{script_ext} </font> </div>
      </td>
    </tr>
    <!--
    <tr> 
      <td width="200" valign="top" align="center"> 
        <div align="left"><b><font face="Tahoma" size="2">$mj{setup88}</font></b></div>
      </td>
      <td valign="top" align="center"> 
        <div align="left"><font face="Tahoma" size="2">$mj{setup89}<br>
          $HTML_language</font></div>
      </td>
    </tr>-->
    <tr> 
      <td valign="middle" align="center" colspan="2"> 
        <input type="SUBMIT" value=" $TXT{save}" name="submit">
        <input type="reset" name="reset" value=" $TXT{reset}">
      </td>
    </tr>
  </table>
</form>
</BODY>
</HTML>
	|;
}
###########################################################################
1;