###########################################################################
# mojoClassified Personals Edition                                        #
###########################################################################
# First Released: December 2001   v1.0.00                                 #
# Last Released: February 2001    v1.21.06                                #
# ========================================================================#
# Software Distributed by:    http://www.mojoscripts.com                  #
# Software Written by:        Kevin Pham		kevin@mojoscripts.com        #
# Software Documented by		kevin Pham                                  #
# Copyright (c) 2001-2002 mojoSoft Internet Services - All Rights Reserved#
###########################################################################
# This program may be used and modified free of charge only by our        #
# registered members so long as this copyright notice and the comments    #
# above remain intact. If you obtained this software other than from our  #
# homepage, it is prohibited to use, not to mention modifying the code.      #
# By using this code you agree to indemnify mojosoft.net, Thi Pham, and   #
# all its programmers from any liability that might arise from its use.   #
#                                                                         #
# Selling the code for this program without prior written consent is      #
# expressly forbidden. Obtain permission before redistributing this       #
# software over the Internet or in any other medium. In all cases         #
# copyright and header must remain intact. We cannot be held responsible  #
# for any harm this may cause.                                            #
###########################################################################
# Create categories, what else you expect?                                #
###########################################################################
# cat = the category we currently wan to take actions on (or parent category)
# ID + the new category that we want to add
sub CategoryMain{
	local($message);
	if($FORM{action} eq "add"){			&AddCategory;			}
	elsif($FORM{action} eq "edit"){		&EditCategory;			}
	elsif($FORM{action} eq "delete"){	&DeleteCategory;		}
	elsif($FORM{action} eq "reorder"){	&ReorderCategory;		}
	elsif($FORM{action} eq "waiting"){	&WaitingCategory;		}
	else{											&DisplayCategories;	}
	&DisplayCategories($message);
}
###########################################################################
sub RedefineVar{
	my $cat = &GetParentDirectory($FORM{cat});
	if($cat eq $FORM{cat}){	$category_path = "$data_path";			}
	else{
		$category_path = "$data_path/$cat";
		$FORM{cat} = $cat;	
	}
	$category_db = "$category_path/$CONFIG{cat_db}";
	&BuildAdminLocation;
	&DisplayCategories($message);
}
###########################################################################
sub AddCategory{
	if($FORM{cancel}){		$message = $mj{cancel};		}
	elsif($FORM{step} eq "final" and $ADMIN{cat_add}){
		$message = &CheckCategoryInput;
		&PrintAddCategory($message) if $message;
		mkdir("$category_path/$FORM{ID}", 0777);
		chmod(0777, "$category_path/$FORM{ID}");
		$CAT{date_create}=  time;
		$CAT{date_end}=     time + 10* 365 * 24 * 60 *60;
		if($FORM{no_icon}){	$FORM{icon}=$FORM{ricon}="";		}
		&SaveCategoryDatabase("$category_path/$FORM{ID}/$CONFIG{cat_db}", \%FORM);
		$message = $mj{success};
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{	&PrintAddCategory;	}
}
###########################################################################
sub EditCategory{
	if($FORM{cancel}){		$message = $mj{cancel};		}
	elsif($FORM{step} eq "final" and $ADMIN{cat_edit}){
		$message = &CheckCategoryInput;
		&PrintEditCategory($message) if $message;
		&SaveCategoryDatabase("$category_db", \%FORM);
		$message = $mj{success};	
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{	&PrintEditCategory;	}
	&RedefineVar;
}
###########################################################################
sub DeleteCategory{
	if($FORM{cancel}){		$message = $mj{cancel};		}
	elsif($FORM{step} eq "final" and $ADMIN{cat_delete}){
		rmtree($category_path, 0, 1);
		$message = $mj{success};	
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{	&PrintDeleteCategory;	}
	&RedefineVar;
}
###########################################################################
sub ReorderCategory{
	my($line, @lines);
	if($FORM{cancel}){		$message = $mj{cancel};		}
	elsif($FORM{step} eq "final" and $ADMIN{cat_delete}){
		@lines = split(/\n/, $FORM{cats});
		&FileWrite($category_order, \@lines);
		$message = $mj{success};	
	}
	elsif($FORM{step} eq "final"){	&PrintError($mj{'error'}, $mj{'deny'});	}
	else{	&PrintReorderCategory;	}
}
###########################################################################
sub DisplayCategories{
	my($country, $active, $pending, $cat, @cats, $ID,  $line, @lines, $ptr, $path, $state);
	my($message) = @_;
	unless(-d $category_path){
		&PrintError($mj{error}, "The category you entered does not exist in our database : <br><b>$category_path</b>");
	}
	$ptr = &Subdirectories($category_path);
	@cats = @$ptr;
	foreach $cat (@cats){
		next unless(-f "$cat/$CONFIG{cat_db}");
		$ptr = &RetrieveCategoryDatabase("$cat/$CONFIG{cat_db}");
		%CAT = %$ptr;
		unless($CAT{name}){
			$CAT{ID} = $CAT{name} = &GetLastDirectory($cat);
			&SaveCategoryDatabase("$cat/$CONFIG{cat_db}", \%CAT);
		}
		$ID = ($FORM{cat})? "$FORM{cat}/$CAT{ID}" : $CAT{ID};
		$active = &DirectoryFiles($cat, [$CONFIG{answered_ext}]);
		@lines = @$active;	$active = @lines;
#		$pending = &RecursiveDirectoryFiles($cat, [$CONFIG{unanswered_ext}]);
#		@lines = @$pending;	$pending = @lines;
		if($CAT{ricon}){$CAT{icon_url} = qq|<img src="$CAT{ricon}" border=0 height=32>|;	}
		elsif($CAT{icon}){	$CAT{icon_url} = qq|<img src="$image_url/$CAT{icon}" border=0 height=32>|;	}
		else{		$CAT{icon_url} = qq||;	}		
		$HTML_cat .=qq|<tr><td><div vlign=top>$CAT{icon_url}</div></td>
			<td><b>$CAT{name}</b><br>$CAT{description}</td>
			<td>$CAT{ads} <a href="$admin_url?type=question&cat=$ID">$active FAQ</a></td>
			<td><a href="$admin_url?type=cat&action=edit&cat=$ID">$TXT{edit}</a>
			    <a href="$admin_url?type=cat&action=delete&cat=$ID">$TXT{delete}</a>
				 <a href="$admin_url?type=question&action=add&cat=$ID">Add FAQ</a>
				<br> $actions
				 </td>
			</tr>|;
	}
	&PrintCategories($HTML_cat, $message);			
}
###############################################################################
sub BuildCategoryList{
	my($cat, %CAT, $dir, @dirs, @label, %LABEL);
	$dir = &Subdirectories($data_path);
	foreach (@$dir){
		next unless(-f "$_/$CONFIG{cat_db}");
		$cat = &RetrieveCategoryDatabase("$_/$CONFIG{cat_db}");
		%CAT = %$cat;
		push(@label, $CAT{ID});
		$LABEL{$CAT{ID}} = $CAT{name};
	}
	return popup_menu("cat", \@label, $FORM{cat}, \%LABEL);
}
###############################################################################
sub CheckCategoryInput{
	my $message="";
	$message .="<li>$mj{cat3}</li>" if ($FORM{ID} and -d "$category_path/$FORM{ID}" and $FORM{action} eq "add");
	$message .="<li>$mj{cat4}</li>" unless ($FORM{ID} =~ /^[0-9A-Za-z\-\_]+$/);
	$message .="<li>$mj{cat7}</li>" unless $FORM{name};
#	$message .="<li>Please enter a description for your category</li>" unless $FORM{'description'};
#	$message .="<li>Category description contains database characters </li>" if ($FORM{'description'}=~ /\|/g);
	return $message;
}
###########################################################################
sub PrintCategories{
	my($action, $cat, %CAT, %HTML);
	($HTML{cats}, $HTML{message}) = @_;
	$CAT{description} = qq|Your FAQ Topics|;
	unless($HTML{cats}){	$HTML{cats} =qq|There is no FAQ topic defined yet|;	}
	&PrintMojoHeader;
	print qq|
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <div align="center"><b><font face="Tahoma">$CAT{description}<br>
        <font color="#FF0000">$HTML{message}</font></font></b></div>
    </td>
  </tr>
  <tr> 
    <td>
      <table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#99CCFF">
        <tr bgcolor="#663300"> 
          <td bgcolor="#7392AD" width="5%"><b></b></td>
          <td bgcolor="#7392AD" width="40%"><b><font face="Tahoma" color="#FFFF99">Topic 
            Name</font></b></td>
          <td bgcolor="#7392AD" width="20%"><b><font face="Tahoma" color="#FFFF99"># 
            of FAQ</font></b></td>
          <td bgcolor="#7392AD" width="35%"><b><font face="Tahoma" color="#FFFF99">Actions</font></b></td>
        </tr>
        $HTML_cat
        <tr> 
          <td colspan="5"> 
            <div align="center"><a href="$admin_url?type=cat&cat=$FORM{cat}&action=add">$mj{cat30}</a></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintAddCategory{
	my $HTML_message = shift;
	my(%HTML, @label1, %LABEL1);
	&PrintMojoHeader;
	$FORM{icon} = "blank.gif";
	$HTML{icon} = &BuildImageSelection("$image_url", $FORM{icon});
	@label1=("1", "0");
	%LABEL1=("1"=>"Yes", "0"=>"No");
	$HTML{post} = popup_menu("post", \@label1, $CAT{post}, \%LABEL1);
	$HTML{no_icon} = checkbox("no_icon", "", "yes", "Do not use icon");
	
	print qq|
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"> 
      <div align="center"><b><font face="Tahoma">$mj{cat30}</font></b></div>
    </td>
  </tr>
  <tr> 
    <td colspan="3"> 
      <form name="mojo" method="post" action="">
        <div align="center">
          <input type="hidden" name="type" value="cat">
          <input type="hidden" name="cat" value="$FORM{cat}">
          <input type="hidden" name="action" value="add">
		  <input type="hidden" name="step" value="final">
        </div>
        <table width="554" border="1" cellspacing="0" cellpadding="2" bordercolor="#663300" align="center">
          <tr> 
            <td colspan="2"><font color="#FF0000"><b>$HTML_message</b></font> 
            </td>
          </tr>
          <tr> 
            <td><b>$mj{cat1}</b></td>
            <td> 
              <input type="text" name="ID" size="20" maxlength="30" value="$FORM{ID}">
              <br>
              $mj{cat2}</td>
          </tr>
          <tr> 
            <td><b>$mj{cat5}</b></td>
            <td> 
              <input type="text" name="name" size="30" maxlength="100" value="$FORM{name}">
              <br>
              $mj{cat6}</td>
          </tr><!--
          <tr> 
            <td><b>$mj{cat13}</b></td>
            <td> 
              $HTML_post
              <br>
              $mj{cat14}</td>
          </tr>-->
          <tr> 
            <td><b>$mj{cat10}</b></td>
            <td> 
              <textarea name="description" cols="40" rows="3" wrap="VIRTUAL">$FORM{description}</textarea>
              <br>
              $mj{cat11}</td>
          </tr>
          <tr> 
            <td height="39"><b>$mj{cat15}</b></td>
            <td height="39"> $HTML{icon}<br> $HTML{no_icon}<br>
              $mj{cat16}<br>
              <input type="text" name="ricon" size="50" maxlength="100" value="$FORM{ricon}">
            </td>
          </tr>
          <tr> 
            <td height="39" colspan="2"> 
              <div align="center"> 
                <input type="submit" name="Submit" value="$TXT{add}">
                <input type="reset" name="reset" value="$TXT{reset}">
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintEditCategory{
	my($cat, %CAT, %HTML, @label1, %LABEL1);
	($HTML{message}) = @_;
	$ptr = &RetrieveCategoryDatabase("$category_db");
	%CAT = %$ptr;
	foreach $cat (keys %CAT){	$FORM{$cat} = $CAT{$cat} unless $FORM{$cat};	}
	$FORM{icon} = &GetLastDirectory($FORM{icon});
	$FORM{icon} = "blank.gif" unless $FORM{icon};
	$HTML{icon} = &BuildImageSelection("$image_url", $FORM{icon});
	@label1=("1", "0");
	%LABEL1=("1"=>"Yes", "0"=>"No");
	$HTML{post} = popup_menu("post", \@label1, $CAT{post}, \%LABEL1);
	if($CAT{icon} or $CAT{ricon}){
		$HTML{no_icon} = checkbox("no_icon", "", "yes", "Do not use icon");
	}
	else{
		$HTML{no_icon} = checkbox("no_icon", "checked", "yes", "Do not use icon");
	}
		
	&PrintMojoHeader;
	print qq|
	
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"> 
      <div align="center"><b><font face="Tahoma">$mj{cat33}: $FORM{name}</font></b></div>
    </td>
  </tr>
  <tr> 
    <td colspan="3"> 
      <form name="mojo" method="post" action="">
        <div align="center">
          <input type="hidden" name="type" value="cat">
          <input type="hidden" name="cat" value="$FORM{cat}">
			  <input type="hidden" name="ID" value="$FORM{ID}">
          <input type="hidden" name="action" value="edit">
		  <input type="hidden" name="step" value="final">
        </div>
        <table width="554" border="1" cellspacing="0" cellpadding="2" bordercolor="#663300" align="center">
          <tr> 
            <td colspan="2"><font color="#FF0000"><b>$HTML{message}</b></font> 
            </td>
          </tr>
          <tr> 
            <td><b>$mj{cat1}</b></td>
            <td> <b>$FORM{ID}</b> <br>
              $mj{cat2}</td>
          </tr>
          <tr> 
            <td><b>$mj{cat5}</b></td>
            <td> 
              <input type="text" name="name" size="30" maxlength="100" value="$FORM{name}">
              <br>
              $mj{cat6}</td>
          </tr><!--
          <tr> 
            <td><b>$mj{cat13}</b></td>
            <td> $HTML_post<br>
              $mj{cat14}</td>
          </tr>-->
          <tr> 
            <td><b>$mj{cat10}</b></td>
            <td> 
              <textarea name="description" cols="40" rows="3" wrap="VIRTUAL">$FORM{description}</textarea>
              <br>
              $mj{cat11}</td>
          </tr>
          <tr> 
            <td height="39"><b>$mj{cat15}</b></td>
            <td height="39"> $HTM{icon}<br>
              $HTML{no_icon}<br>
              $mj{cat16}<br>
              <input type="text" name="ricon" size="50" maxlength="100" value="$FORM{ricon}">
            </td>
          </tr>
          <tr> 
            <td height="39" colspan="2"> 
              <div align="center"> 
                <input type="submit" name="Submit" value="$TXT{update}">
                <input type="reset" name="reset" value="$TXT{reset}">
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintDeleteCategory{
	my $HTML_message = shift;
	my($cat, %CAT, $ptr);
	$ptr = &RetrieveCategoryDatabase("$category_db");
	%CAT = %$ptr;
	foreach $cat (keys %CAT){	$FORM{$cat} = $CAT{$cat} unless $FORM{$cat};	}
	&PrintMojoHeader;
	print qq|
	
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"> 
      <div align="center"><b><font face="Tahoma">$mj{cat36}: $FORM{name}</font></b></div>
    </td>
  </tr>
  <tr> 
    <td colspan="3" height="67"> 
      <form name="mojo" method="post" action="">
        <div align="center">
          <input type="hidden" name="type" value="cat">
          <input type="hidden" name="cat" value="$FORM{cat}">
			 <input type="hidden" name="ID" value="$FORM{ID}">
          <input type="hidden" name="action" value="delete">
		  <input type="hidden" name="step" value="final">
        </div>
        <table width="554" border="1" cellspacing="0" cellpadding="2" bordercolor="#663300" align="center">
          <tr> 
            <td colspan="2">
              <div align="center"><font color="#FF0000"><b>$mj{cat37}</b></font> 
              </div>
            </td>
          </tr>
          <tr> 
            <td height="39" colspan="2"> 
              <div align="center"> 
                <input type="submit" name="submit" value="$TXT{yes}">
                <input type="submit" name="cancel" value="$TXT{cancel}">
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
	|;
	&PrintMojoFooter;
}
###########################################################################
sub PrintReorderCategory{
	my(@dirs, $line, @lines);
	if (-f $category_order){
		$FORM{cats} = &FileReadString($category_order);
	}else{
		opendir (DIR, "$category_path") or &PrintFatal("$mj{file7}: $!", (caller)[1], (caller)[2]);
		@dirs= readdir(DIR);
		closedir (DIR);
		@dirs = sort { lc($a) cmp lc($b);} @dirs;
		foreach (@dirs){
			next if /^\./;
		 	$FORM{cats} .= qq|$_\n| if (-d "$category_path/$_");
		}
	}
	&PrintMojoHeader;
	print qq|
		
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"> 
      <div align="center"><b><font face="Tahoma">$mj{cat17}</font></b></div>
    </td>
  </tr>
  <tr> 
    <td colspan="3" height="322"> 
      <form name="mojo" method="post" action="">
        <div align="center">
          <input type="hidden" name="type" value="cat">
          <input type="hidden" name="action" value="reorder">
		  <input type="hidden" name="step" value="final">
        </div>
        <table width="554" border="1" cellspacing="0" cellpadding="2" bordercolor="#663300" align="center">
          <tr> 
            <td colspan="2"> 
              <div align="center"><font color="#FF0000"><b>$HTML_message</b></font> 
              </div>
            </td>
          </tr>
          <tr> 
            <td width="130" valign="top"> <br>
              $mj{cat18} </td>
            <td width="410"> 
              <textarea name="cats" cols="30" rows="15" wrap="VIRTUAL">$FORM{cats}</textarea>
            </td>
          </tr>
          <tr> 
            <td height="18" colspan="2"> 
              <div align="center"> 
                <input type="submit" name="Submit" value="$TXT{update}">
                <input type="reset" name="reset" value="$TXT{reset}">
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
|;
&PrintMojoFooter;
}
###########################################################################
1;