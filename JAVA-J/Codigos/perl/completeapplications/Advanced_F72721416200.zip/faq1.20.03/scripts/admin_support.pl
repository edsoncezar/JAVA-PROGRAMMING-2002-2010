##############################################################################
sub SupportMain{
	if($FORM{class} eq "documentation"){
		print "Location:http://www.mojoscripts.com/docs/mojotaf/\n\n";
	}elsif($FORM{class} eq "forum"){
		print "Location:http://www.mojoscripts.com/forum/\n\n";
	}
	elsif($FORM{class} eq "faq"){
		&PrintFAQ;
	}else{
		&PrintRateUs;
	}
}
##############################################################################
sub PrintFAQ{
	if($FORM{step} eq "final"){
		&SendMail($myemail, $myemail, "webmaster\@mojoscripts.com", "FAQ", $FORM{message}.$ENV{HTTP_HOST});
		$HTML_message = "Your mail has been sent. We will contact you shortly.";
	}
	&PrintMojoHeader;
	print qq|
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="24"> 
      <div align="center"><font size="4"><b>If you have any problem, please send 
        an email to us</b></font></div>
    </td>
  </tr>
  <tr> 
    <td height="2"> 
      <div align="center"><font color="#FF0000">$HTML_message</font></div>
    </td>
  </tr>
  <tr> 
    <td height="37"> 
      <form name="form1" method="post" action="">
        <input type="hidden" name="type" value="support">
        <input type="hidden" name="class" value="faq">
        <input type="hidden" name="step" value="final">
        <table width="500" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td><b>Please be as specific as possible</b></td>
          </tr>
          <tr> 
            <td> 
              <textarea name="message" wrap="VIRTUAL" cols="60" rows="10"></textarea>
            </td>
          </tr>
          <tr>
            <td>
              <div align="center">
                <input type="submit" name="Submit" value="send">
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>

	|;
	&PrintMojoFooter;
}
##############################################################################
sub PrintRateUs{
	&PrintMojoHeader;
	print qq|

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="2"> 
      <div align="center"><b>The best way to support us and let us support you 
        is to rate us</b><br>
        All votes are welcome and appreciated.</div>
    </td>
  </tr>
  <tr> 
    <td width="47%">&nbsp;</td>
    <td width="53%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="47%" height="11"> 
      <form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST">
        <input type="hidden" name="ID" value="14059">
        <table BORDER="0" CELLSPACING="0">
          <tr> 
            <td align="center"><font face="arial, verdana" size="2"><b>Rate Us 
              @ <a href="http://www.hotscripts.com"><i>HotScripts.com</i></a></b></font></td>
          </tr>
          <tr> 
            <td align="center"> 
              <table border="0" cellspacing="2" align="center">
                <tr> 
                  <td align="center"> 
                    <select name="ex_rate" size="1">
                      <option value="5" selected>Excellent!</option>
                      <option value="4">Very Good</option>
                      <option value="3">Good</option>
                      <option value="2">Fair</option>
                      <option value="1">Poor</option>
                    </select>
                  </td>
                  <td align="center"> 
                    <input type="submit" value="Cast My Vote!">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </form>
    </td>
    <td width="53%" height="11"> 
      <table border=0 cellspacing=0 cellpadding=10 bordercolor="#ffcc33" width="100%">
        <tr> 
          <td height="2"> 
            <form action="http://www.scriptsearch.com/cgi-bin/rate.cgi" method="POST">
              <input type=hidden name="ID" value="4337">
              <table border="0" cellspacing="0">
                <tr> 
                  <td align="center"><font face="arial, verdana" size="2"><b>Rate 
                    Us @ ScriptSearch</b></font></td>
                </tr>
                <tr> 
                  <td align="center"> 
                    <table border="0" cellspacing="2" align="center">
                      <tr> 
                        <td align="center"> 
                          <select name="rate" size="1">
                            <option value="5" selected>Excellent!</option>
                            <option value="4">Very Good</option>
                            <option value="3">Good</option>
                            <option value="2">Fair</option>
                            <option value="1">Poor</option>
                          </select>
                        </td>
                        <td align="center"> 
                          <input type="submit" value="Cast My Vote!" name="submit">
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              </form>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan="2" height="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" height="2">
      <div align="center">Thanks</div>
    </td>
  </tr>
</table>

	|;
	&PrintMojoFooter;
}
###########################################################################
1;
