###########################################################################
sub BuildCategoryDisplay{
	my($cat, %CAT, $ret);
	($rat) = @_;
	$cat = &RetrieveCategoryDatabase($category_db);
	%CAT = %$cat;
	
	return ($ret)?$CAT{name}:$CAT{description};
}
###########################################################################
sub BuildLocation {
   my (%CAT, $cat, @cats,$html, $output, $path, $last, $name, $ptr);
   @cats= split (/\//, $FORM{cat});

   $html = qq|<A HREF="$mojo_url">Top</A>|;
	foreach $cat (@cats) {
      if ($i < 1) { $path .= "$cat"; }
      else { $path .= "/$cat"; }
		$ptr = &RetrieveCategoryDatabase("$data_path/$path/$CONFIG{cat_db}");
		%CAT = %$ptr;
      $html .= qq| &gt; <A HREF="$index_url?cat=$path">$CAT{name}</A>|;
      $i++;
   }
	return $html;
}
###############################################################################
#usage $page_link = &BuildPageLink();
sub BuildPageLink{
	my($count, $left_pages, $right_pages, $left_links, $right_links, $next_page, $right_page,
	$current_page, $offset, $page);
	 $FORM{30} if  $FORM{'lpp'} < 30;
	
	$FORM{'offset'} = 0 unless $FORM{'offset'};
	$page =  ($FORM{offset} + $FORM{lpp} < $FORM{total})?$FORM{offset} + $FORM{lpp} : $FORM{total};
### next paage link, nothing if this is the last page
	$offset = $FORM{'offset'} + $FORM{'lpp'};
	$next_page ="<a href=\"".&BuildAdminPageURL($offset)."\">Next Page</a>";
	$next_page ="Next Page" if ($offset > $FORM{'total'});
### previous page link, nothing if this is the first page
	$offset = $FORM{'offset'} - $FORM{'lpp'};
	$offset = 0 if $offset < 0;
	$prev_page ="<a href=\"".&BuildAdminPageURL($offset)."\">Previous Page</a>";
	$prev_page = "Prev Page" if ($FORM{'offset'} ==0);
##last and first
		
	$HTML_page_link =qq|Showing $FORM{offset} to $page of $FORM{total} found \| $prev_page \| $next_page|;
	return $HTML_page_link;
}
###############################################################################
sub BuildTitle{
	return $site_title;
}
###########################################################################
sub BuildCategoryFiles{
	my($answer,$answer_template, $end, %HTML, $line, @lines,
	 $question, %QUESTION,$question_template, $name, $template, $start);
	local($new, $link, $thumnail);
#	&PrintInternalHeader;
	$line = &DirectoryFiles($category_path, [$CONFIG{answered_ext}]);
	@lines = @$line;
	
	$question_template = &FileReadString($TEMPLATE{question1});
	$answer_template = &FileReadString($TEMPLATE{answer1});
	$FORM{total} = @lines;
	$start = $FORM{offset};
	$start = 0 if $start <= 0;
	$end = @lines ;#($start + $FORM{lpp} > $#lines+1)? $#lines+1:$start + $FORM{lpp};
	for(my $i=$start; $i < $end; $i++){
		$question = &RetrieveQuestionDatabase($lines[$i]);
		%QUESTION = %$question;
		$QUESTION{question_number} = $i+1;
		$HTML{answer} .=  &ParseAnswerTemplate($answer_template, \%QUESTION);
		$HTML{question} .=&ParseQuestionTemplate($question_template, \%QUESTION);
	}	
	return ($HTML{question},$HTML{answer});
}
###########################################################################
sub BuildSubcategories{
	my($category, $dir, @dirs, @html, $html, $template, $name, $data, $cat, $half, @t);
	local($new, $link);
	$dir = &Subdirectories($category_path);
	@dirs = @$dir;
	$template = &FileReadString($TEMPLATE{cat1});
	foreach $category (@dirs){
		next unless(-f "$category/$CONFIG{cat_db}");
		$cat = &RetrieveCategoryDatabase("$category/$CONFIG{cat_db}");
		%CAT = %$cat;
		$CAT{new} = (-M $dir > $CONFIG{daysnew})? 0: 1;
		($name = $category) =~ s/$data_path\///;
		$CAT{link} = qq|$mojo_url?cat=$name|;
		$dir = &DirectoryFiles($category, [$CONFIG{answered_ext}]); @t = @$dir;
		$CAT{faqs} = @t;
		$html[$count++] = &ParseCatTemplate($template, \%CAT);
	}
	return $html unless @html;
	$half= int (($#html + 2 ) / 2);
	$html =qq|<table width="$TABLE{cat_width}" border="$TABLE{cat_border}"
		 cellspacing="$TABLE{cat_cellspacing}" cellpadding="$TABLE{cat_cellpadding}" bgcolor="$TABLE{cat_bgcolor}" bordercolor="$TABLE{cat_bordercolor}">
		<tr><td valign="top">|;
	for(my $i=0; $i< @html; $i++){
   	if ($i eq $half and $CONFIG{catlayout}){	$html .= qq|</td><td valign="top">|;		}
		$html .=qq|$html[$i]|;
   }
	$html .=qq|</td></tr></table>|;
	return $html;
}
###########################################################################
return 1;