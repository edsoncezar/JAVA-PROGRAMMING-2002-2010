Title: Advanced FAQ script
Description: An advanced Frequently Asked Question script that will let you build your own, unique FAQ database. It use no special database so everyone has PERL 5.0 or above can used it. FAQs can be arranged by categories which has description and an illustrative icons.
It also come with an advanced secured admin area.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=310&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
