#!/usr/bin/perl

use CGI;
use Data::Dumper;
$q=new CGI;
print $q->header;

$name=$q->param("name");
$subject=$q->param("subject");
$text=$q->param("text");
$num=$q->param("num");
$email=$q->param("email");
$reply=$q->param("reply");
$replyto=$q->param("replyto");
@msgs=();
if (defined $num)
{
	$replybutton=1;
}
@days=(Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday);
@months=(January,February,March,April,May,June,July,August,September,October,November,December);
($seg,$min,$hora,$dia,$mes,$ano,$wday,$yday,$isdst)=gmtime(time());
$year=$ano+1900;
if($min<10)
{
	$min="0".$min;
}
if ($hora<12)
{
	$min.=" AM";
}
$time="$days[$wday-1], $months[$mes] $dia, $year at $hora:$min";
$mess=do "messages.dat";
@msgs=@$mess;
if ((defined $name) && ($name ne ""))
{
	$message->{name}=$name;
	$message->{subject}=$subject;
	$message->{text}=$text;
	$message->{at}=$time;
	$message->{email}=$email;
	if (defined $reply)
	{
		$message->{replyto}=$replyto;
	}
	if (! -e "messages.dat")
	{
		push @msgs, $message;
		
	}
	else
	{
		$mess=do "messages.dat";
		@msgs=@$mess;
		push @msgs, $message;
	}
	open(A,">messages.dat");
	print A Dumper \@msgs;
	close(A);
}

		
#print "<pre>";
#print Dumper \@msgs;
#print "</pre>";
open (A,"templates/header.htm");
while(<A>)
{
	print $_;
}

print "<center>";
print "<table border=0 bgcolor=0080aa cellspacing=0 width=70\%><tr><td>";
print "<table border=0 width=100\% bgcolor=fffffa>";
print "<tr><td align=left><a href=\"/\"><font face=\"arial\" color=\"666666\"><b>Home</b></a> | <a href=\"messBoard.pl\"><font face=\"arial\" color=\"666666\"><b>View all messages</b></font></a> | <a href=\"#post\"><font face=\"arial\" color=\"666666\"><b>Post a message</b></font></a></td></tr>";
print "</table>";
print "</table><br>";

print "<table border=0 bgcolor=0080aa cellspacing=0 width=70\%><tr><td>";
print "<table border=0 width=100\% bgcolor=fffffa><tr><td><span class=\"unnamed1\">";
$mess=do "messages.dat";
#######

#PRINT MESSAGES
if (!defined $num)
{
	print "<ul>\n";
	$num=0;
	for $mesg(@msgs)
	{
	
		if (defined $mesg->{'replyto'})
		{
			push @{$replys{$msgs[$num]->{'replyto'}}},$num;
		}
		elsif($mesg ne "deleted")
		{
			#print "<pre>$mesg \n</pre>";
			push @newMsg,$num;
		}
		$num++;
	}
	$num=0;
	#print "<pre>";
	#print Dumper \%replys;
	#print Dumper \@newMsg;
	#print "</pre>";
	
	$seen=$q->param("seen") or $seen=0;
	for($i=1;$i<=$seen;$i++)
	{
		pop @newMsg;
	}
	$see=0;
	$total=@newMsg;
	while(($see<5) && ($total>0))
	{
		$_= $newMsg[$total-1];
		$see++;
		$total--;
		$mesg=$msgs[$_];
		#if (defined $_)
		#{
			print "<li> <a href=\"messBoard.pl?num=$_\">$mesg->{'subject'}</a> from ";
			if ($mesg->{'email'} ne "")
			{
				print "<a href=\"mailto:$mesg->{'email'}\"><b>$mesg->{'name'} </b></a>";
			}
			else 
			{
				print "<b>$mesg->{'name'} </b>";
			}
			print "on $mesg->{at}";
			if (defined $replys{$_})
			{
				print "<ul>";
				printMsg($_,\@msgs,\%replys);
				print "</ul>";
			}
			print "</li><br><br>";
		
			$num++;
		#}
	}
}
else
{
	print "<br><center>";
	print "<font size=4><b>$msgs[$num]->{'subject'}</b></font><br><br>";
	print "Posted by ";
	if ($msgs[$num]->{'email'} ne "")
	{
		print "<a href=\"mailto:$msgs[$num]->{'email'}\"><b>$msgs[$num]->{'name'}</b></a> ";
	}
	else 
	{
		print "<b>$msgs[$num]->{'name'}</b> ";
	}
	print "on $msgs[$num]->{at}</center><hr>";
	$t=$msgs[$num]->{'text'};
	$t=~s/\n/<br>/g;
	print $t;
	$reply=$num;
}

############

print "</td></tr></table></td></tr></table>";
print "<table border=0 width=70\%><tr><td align=left>";
if ($seen>0)
{
	$pre=$seen-5;
	print "<a href=\"messBoard.pl?seen=$pre\"><font face=arial color=666666><img src=\"/icons/left.gif\" border=0><b>Previous 5</b></font></a>";
}
print "</td>";
if ($total>5)
{
	$next=5;
}
else {$next=$total}
$seen+=5;
if ($total>0)
{
print "<td align=right><a href=\"messBoard.pl?seen=$seen\"><font face=arial color=666666><b>Next $next</b><img src=\"/icons/right.gif\" border=0></a></td>";
}
#FORM
print "</tr></table>";
print "<br>";

print "<table border=0 cellspacing=2 witdh=70\%><tr><td><b>Post a message:</b></td></tr></table><br>";
print "<form method=post action=\"messBoard.pl\">";
print "<table border=0 cellspacing=2>\n";
print "<tr><td><span class=\"unnamed1\"><b>Name:<a name=\"post\"> </a></b></span></td><td>";
print "<input type=text name=\"name\" size=30></td></tr>";
print "<tr><td><span class=\"unnamed1\"><b>Email:</b></span></td><td>";
print "<input type=text name=email size=30></td></tr>";
print "<tr><td><span class=\"unnamed1\"><b>Subject:</b></td><td>";
print "<input type=text name=subject size=40></td></tr>";
print "<tr><td valign=top><span class=\"unnamed1\"><b>Message:</b></span></td><td><textarea name=text cols=40 rows=10></textarea></td></tr>";
print "<tr><td></td><td><input type=\"submit\" name=\"post\" value=\"Post new message\">";
if (defined $replybutton)
{
	print "<input type=hidden name=replyto value=$num>";
	print "<input type=\"submit\" name=\"reply\" value=\"Reply to message\">";
}

print "</td>";

print "</table></form>";

open (A,"templates/footer.htm");
while(<A>)
{
	print $_;
}

sub printMsg
{
	 $num=shift;
	 $arr=shift;
	 $hash=shift;
	#$msgs=$arr;
	for (@{$hash->{$num}})
	{
		
		print "<li> <a href=\"messBoard.pl?num=$_\">$arr->[$_]{'subject'}</a> from ";
		if ($msgs[$_]->{'email'} ne "")
		{
			print "<a href=\"mailto:$arr->[$_]->{'email'}\"><b>$arr->[$_]->{'name'} </b></a>";
		}
		else 
		{
			print "<b>$arr->[$_]->{'name'} </b>";
		}
		print "on $arr->[$_]->{at}";
		
		
		
		if (defined $hash->{$_})
		{
			print "<ul>";
			printMsg($_,$arr,$hash);
			print "</ul>";
		}
		print "</li>";
	}
}