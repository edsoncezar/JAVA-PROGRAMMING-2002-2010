#!/usr/bin/perl


$username="bruno";
$password="bruno";
use Data::Dumper;
use CGI;
$q = new CGI;
print $q->header;
print "<body bgcolor=dddddd>";
print "<table bgcolor=0080aa border=0 cellspacing=0><tr><td>";
print "<table bgcolor=eeeeee border=0><tr><td><font face=arial size=6>Message Board Administration area</font></td></tr></table>";
print "</td></tr></table>";
print "<br><br>";
$delete=$q->param("delete");
$login=$q->param("login");
$pass=$q->param("pass");

if (!defined $login) 
{
	&form;
}
if  (($login ne $username) || ($pass ne $password))
{
	&error_quit;
	&form;
}
$mess=do "messages.dat";
if (defined $delete)
{
	&deleteMsg($mess,$q);
}
$mess=do "messages.dat";


print "<table border=0 bgcolor=ffffff cellspacing=3 >";
print "<form method method=post action=\"admin.pl\">";
print "<input type=hidden name=login value=$login>";
print "<input type=hidden name=pass value=$pass>";
print "<tr bgcolor=0080aa><td><b>Author</td><td><b>Posted on</td><td><b>Subject</td><td><b>Message</td><td><b>Delete</td></tr>";
print "<tr bgcolor=ffffff><td></td><td></td><td></td><td></td><td><input type=submit value=Delete name=delete></td></tr>";
$num=0;
$size=@{$mess};
$color1="eeeeee";
$color2="cccccc";
$c=1;
while($size>0)
{
	$_=$mess->[$size-1];
	$size--;
	$name="delete".$size;
	if ($_ ne "deleted")
	{
		if($c==1)
		{
			$color="eeeeee";
			$c=2;
		}
		else
		{
			$color="aaaaaa";
			$c=1;
		}
		print "<tr bgcolor=$color >";
		print "<td valign=top>$_->{'name'}</td><td valign=top></b>$_->{at}</td><td valign=top>$_->{'subject'}";
		$text=$_->{'text'};
		$text=~s/\n/<br>/g;
		print "</td><td valign=top>$text</td><td>";
		print "<input type=checkbox value=Delete name=$name></td></tr>";
		$num++
	}
}
print "<tr bgcolor=ffffff><td></td><td></td><td></td><td></td><td><input type=submit value=Delete name=delete></td></tr>";
print "</table>";
print "</form><form method=post>
<input type=submit value=\"  LOGOUT  \">
</form>
";

sub deleteMsg
{
	my $mess=shift;
	my $q=shift;
	my $size=@{$mess};
	for ($i=0;$i<$size;$i++)
	{
		$p="delete".$i;
		$par=$q->param($p);
		if(defined $par)
		{
			push @toDelete,$i;
		}
	}
	
	use Data::Dumper;
	
	
	for (@toDelete)
	{
		$mess->[$_]="deleted";
	}
	for (@{$mess})
	{
		if (defined $_->{replyto})
		{
			for $num(@toDelete)
			{
				if ($_->{replyto} == $num)
				{
					delete($_->{replyto})
				}
			}
		}
	}
	
	open(A,">messages.dat");
	print A Dumper $mess;
	close(A);

		
	
}

sub error_quit
{
	print "<font face=arial color=red><b>Wrong username or wrong password</b></font>";
	
}
sub form
{
	print "
	<form method=POST>
	<table bgcolor=0080aa border=0 cellspacing=0><tr><td>
	<table bgcolor=eeeeee border=0><tr><td>
	<font face=arial>Username: </font></td><td>
	<input type=text name=login></td></tr>
	<tr><td><font face=arial>Password: </font></td><td>
	<input type=password name=pass>
	</td></tr>
	<tr><td></td><td><input type=submit value=\"  LOGIN  \">
	</td></tr>
	</table>
	</td></tr></table>
	</form>";
	exit;
}