Title: Fully functional message board with admin area
Description: This a fully functional message board ready to use in you website, you just have to unzip the files to your cgi-bin directory.<br>
It has an admin area with user/password, to change this, you just have to edit the lines of the admin.pl file that says:<br>
$username="bruno";<br>
$pass="bruno";<br><br>
You can configure the header and the footer of the webpage, they are located in the templates folder. If the code has a good rating I will post a second version fully configurable.<br><br>
<font color=blue>if you use this don't forget to vote, Thanks
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=494&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
