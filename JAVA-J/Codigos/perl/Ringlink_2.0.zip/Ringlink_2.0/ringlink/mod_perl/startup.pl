# startup.pl
#
# Things to be done at startup of the Apache server when running
# Ringlink under mod_perl
#
# This file shall be run through a PerlRequire directive.
# For example:
#
#   PerlRequire conf/startup.pl
#

use strict;

# This is instead of changing the third line in every executable
# Ringlink file.
use lib 'C:/Program/IndigoPerl/cgi-bin/ringlink/lib';

# Preloading of Ringlink related modules
use rlmain();
use ring();
use site();
use admhtml();
use mainhtml();
use mailhtml();
use Locale::PGetText();
use Mail::Sender();
use LWP::UserAgent();
use CGI::Carp();

1;

