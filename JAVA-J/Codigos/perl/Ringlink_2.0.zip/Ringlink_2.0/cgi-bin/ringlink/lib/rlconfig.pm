package rlconfig;
use strict;

sub systemvar	{

# Name of this Ringlink set-up
$rlmain::title = 'XYZ\'s Ringlink';

# Address (full URL) to the homepage of this Ringlink set-up
$rlmain::ringlinkURL = 'http://YOURSITE/ringlink/index.html';

# Address (full URL) to the directory with the *.pl or *.cgi files
$rlmain::cgiURL = 'http://YOURSITE/cgi-bin/ringlink';

# Path to the directory where the ring data will be stored
# The suggested expression below assumes that it's a subdirectory to the
# directory with the *.pl or *.cgi files, and that its name is 'data'.
# If you have decided not to let the data direcory be a subdirectory,
# you need to specify the full path, e.g. like this:
#   $rlmain::datapath = '/www/htdocs/username/ringlink/data';
# or like this:
#   $rlmain::datapath = $ENV{'DOCUMENT_ROOT'} . '/ringlink/data';
$rlmain::datapath = $rlmain::cgipath . '/data';

# Path to sendmail program
# (If installed on a Windows server, you have to include the file
# extension .exe, e.g. $rlmain::sendmail = 'd:/scripts/sendmail.exe';)
$rlmain::sendmail = '/usr/sbin/sendmail';

# SMTP-server
# If the $rlmain::sendmail variable is disabled, e.g. through a #
# character before it, Ringlink will try to send messages directly
# from Perl instead. In that case, the variable below shall be
# assigned the host name of your SMTP-server.
$rlmain::smtpserver = 'SMTPSERVER';

# Set to 0 (zero) not to allow anyone to add new rings automatically
$rlmain::allowringadd = 1;

# Set to 1 to enable the statistics feature
# Run "Reset stats" from "Master admin" right after statistics has
# been enabled!
$rlmain::stats = 0;

# Default language code (ISO 639)
$rlmain::lang = 'en';

# Library for language databases (should normally not need to be set)
$rlmain::DBM_File = '';

# Default colors
%rlmain::colors = (
  colbg      => '#000066',
  coltablebg => '#eee9bf',
  coltxt     => '#000000',
  colemph    => '#000066',
  colerr     => '#ff0000',
  collink    => '#0000ee',
  colvlink   => '#333399'
);

%rlmain::leftpanecolors = (
  tablebg    => '#ded685',
  txt        => '#000000',
  link       => '#0000cc',
  vlink      => '#000066'
);

# Max number of characters in site description
$rlmain::numcharsitedesc = 250;

$rlmain::adminname = 'YOURNAME';
$rlmain::adminemail = 'YOUREMAILADDRESS';
$rlmain::adminpw = 'PASSWORD';

}

1;

