#!/usr/bin/perl
use CGI::Carp 'fatalsToBrowser'; CGI::Carp -> VERSION(1.06);
use lib 'lib';

##########################> Ringlink 2.0 <##########################
#                                                                  #
#  Ringlink is a CGI Perl program that provides the tools          #
#  necessary to run and administrate rings of websites.            #
#                                                                  #
#  Copyright (C) 2000, 2001 Gunnar Hjalmarsson,                    #
#  gunnar@ringlink.org; Version 2.0 released August 22, 2001       #
#  Ringlink homepage: http://www.ringlink.org/                     #
#                                                                  #
#  Ringlink is free software; you can redistribute it and/or       #
#  modify it under the terms of the GNU General Public License as  #
#  published by the Free Software Foundation; either version 2 of  #
#  the License, or (at your option) any later version.             #
#                                                                  #
#  Ringlink is distributed in the hope that it will be useful,     #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of  #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the    #
#  GNU General Public License for more details.                    #
#                                                                  #
#  You should have received a copy of the GNU General Public       #
#  License along with this program; if not, write to the Free      #
#  Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,  #
#  MA  02111-1307  USA                                             #
#                                                                  #
####################################################################

use strict;

use rlmain 2.0;
use Locale::PGetText 2.0;

rlmain::execstart;
rlmain::inittests;
my $i = 0;
for (@rlmain::activesites)	{
  $i ++;
  if ($_ =~ /^$rlmain::data{'siteid'}\t/)	{
    my @sitevalues;
    if ($i == scalar @rlmain::activesites)	{
      @sitevalues = split (/\t/, $rlmain::activesites[0]);
    } else	{
      @sitevalues = split (/\t/, $rlmain::activesites[$i]);
    }
    { no strict 'refs';
      for (@rlmain::sitenames)	{
        ${'rlmain::' . $_} = shift (@sitevalues);
      }
    }
    rlmain::addrechits ($rlmain::siteid);
    rlmain::addgenhits ($rlmain::data{'siteid'});
    print "Location: $rlmain::entryURL\n\n";
    rlmain::exit;
  }
}
if (!$rlmain::data{'siteid'})	{
  $rlmain::result = '<p class="error">' . gettext("Error! You must provide a site ID.") . '</p>';
  rlmain::mainhtml;
} else	{
  rlmain::naverror;
}

