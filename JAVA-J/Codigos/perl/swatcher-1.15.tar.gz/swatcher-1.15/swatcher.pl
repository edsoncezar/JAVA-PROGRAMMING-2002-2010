#!/usr/bin/perl -w

use strict;

################################################################################
##                                                                            ##
##                        S W A T C H E R     1 . 0                           ##
##           Writen by Andrey Novikov (swatcher@andrey.novikov.com)           ##
##                         copyright (c) 2001-2004                            ##
##                                                                            ##
##   Latest version is always available at http://swatcher.sourceforge.net/   ##
##                                                                            ##
################################################################################

# COPYRIGHT NOTICE:
#
# Copyright 2001-2004 Andrey Novikov. All Rights Reserved.
#
# This program may be used and modified free of charge by anyone, so long as
# this copyright notice and the header above remain intact. By using this
# program you agree to indemnify Andrey Novikov from any liability.
#
# Selling the code for this program without prior written consent is expressly
# forbidden. Obtain permission before redistributing this program over the
# Internet or in any other medium. In all cases copyright and header must remain
# intact.
#
# WARANTY:
#
# THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

################################################################################

################################################################################

# $Revision: 1.15 $
# $Date: 2004/01/20 13:26:24 $
# $Id: swatcher.pl,v 1.15 2004/01/20 13:26:24 root Exp $

$ENV{PATH} = '/bin:/usr/bin';

use Config::IniFiles;
use Getopt::Long;
use Sys::Syslog qw(:DEFAULT setlogsock);
require 'sys/syscall.ph';

################################################################################
# extensions
################################################################################

use Net::Ping;
use Mail::Sender;
use Net::Domain qw(hostfqdn);

require Net::FTP;
require LWP::UserAgent;
require HTTP::Request;
require Net::SMTP;
require Net::DNS;
require DBI;
require Mail::IMAPClient;

################################################################################
# main body
################################################################################

use vars qw($VERSION);

$VERSION = do { my @r = (q$Revision: 1.15 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r };

# defaults for command line options
my %optctl = (version => 0, daemon => 1, config => '/usr/local/etc/swatcher.conf');
# read command line
usage() unless (GetOptions(\%optctl, "version", "daemon!", "config=s"));

$|=1;
$0='swatcher';

if ($optctl{version}) {
  print "$0 $VERSION\n";
  exit(0);
}

# initialize syslog
setlogsock('unix');
openlog($0,'cons,pid','user');
syslog('warning','starting...');

$SIG{__WARN__} = sub {
  my $text = shift;
  syslog('warning','warned: '.$text);
};

$SIG{__DIE__} = sub {
  my $text = shift;
  syslog('alert','died: '.$text);
  exit(1);
};

my $cfg = Config::IniFiles->new( -file => $optctl{config});
unless ($cfg) {
  syslog('err',"couldn't read configuration file");
  die "couldn't read configuration file";
}

my($pause,$forgetpr,$restart,$pidfile,$results_file,$postpone,$res,%badchecks,%postpones,@badlines);

init(0);

$pidfile = $cfg->val('main','pidfile'); $pidfile ||= '/var/run/swatcher.pid';
syslog('debug','will save my PID into %s',$pidfile);

if (-e $pidfile) {
  syslog('warning','found old PID file');
  # aha, pid file is here, but process could be dead by now.
  unless (open(PIDFILE,$pidfile)) {
    syslog('err',"Too dangerous to start because I can't read old PID");
    exit 1;
  }
  my $oldpid=<PIDFILE>;
  close PIDFILE;
  syslog('err',"OLDPID: %d", $oldpid);
  if ($oldpid > 1 && kill(0,$oldpid)) {
    syslog('err',"Another proccess is running already. Exiting");
    exit 1;
  } else {
    syslog('warning',"but that process is long dead.");
  }
}

my ($m,%hchecks,%hnotifications,$host,$check,$notification,%results,%cparams,%nparams);

my (@hosts,@checks,$key,@notifications);

init(1);

if ($optctl{daemon}) {
  # become a daemon
  if (fork) { exit; }
  close STDOUT; close STDERR; close STDIN;
  chdir '/';
  syscall(&SYS_setsid);
}

$SIG{'INT'} = $SIG{'QUIT'} = $SIG{'TERM'} = 'quit';
$SIG{'HUP'} = 'restart';

# write pid file
open (PID, ">$pidfile") or die "Couldn't open $pidfile\n";
print PID $$;
close(PID);

$restart = 1;

init(2);

# get local domain
my $mydomain = hostfqdn();
# assume SMTP server is at localhost if not specified
$nparams{mail}{smtp} ||= $mydomain;
my $mail = new Mail::Sender {from => $nparams{mail}{from}, smtp => $nparams{mail}{smtp} };
if ($mail < 0)
{
  $mail = undef;
  syslog('alert','Failed to initialize mail sender (%s), disabling all mail notifications', $Mail::Sender::Error);
}

# begin of restart handling code
while ($restart) {
  if ($restart == 2) {
    init(0);
    init(1);
    init(2);
  }
  $restart = 0;
  while (! $restart) {
# end of restart handling code

    # skip all checks on DNS failure - this will preserve from notification flooding
    unless (hostfqdn()) {
      syslog('alert','DNS failure, skipping all checks');
      sleep $pause;
      next;
    }
    # perform checks on all hosts
    foreach $host (%hchecks) {
      foreach $check (@{$hchecks{$host}}) {
        $results{$host}{$check} = checkit($host,$check);
        $m = $results{$host}{$check} ? 'ok' : 'NO';
        syslog('debug',"check of %s for %s returned %s",$host,$check,$m);
      }
    }
    # report the results
    foreach $host (@hosts) {
      foreach $check (@checks) {
        $res = defined($results{$host}{$check}) ? $results{$host}{$check} : -1;
        unless ($res) {
          $badchecks{$host}{$check} = time unless(defined($badchecks{$host}{$check}));
          syslog('err',"failed check of %s for %s",$host,$check);
          notify($host,$check,0);
        # check succeded - clear error condition if set
        } elsif ($badchecks{$host}{$check}) {
          delete $badchecks{$host}{$check};
          syslog('err',"normal condition for check of %s for %s restored",$host,$check);
          notify($host,$check,1);
          delete $postpones{$host}{$check};
        }
      }
    }
    # if asked for results file - update it
    if ($results_file) {
      if (open(RES,">$results_file")) {
        print RES join("\t",('host',@checks)),"\n";
        foreach $host (@hosts) {
          print RES "$host";
          foreach $check (@checks) {
            print RES "\t",defined($results{$host}{$check}) ? $results{$host}{$check} : -1;
          }
          print RES "\n";
        }
        close(RES);
      } else {
        syslog('err',"couldn't open results file %s for writing, the reason is: %m",$results_file);
      }
    }
    # clear alarm if forgot anywhere
    alarm(0);
    # let other processes breathe :)
    syslog('debug','sleeping for %s seconds',$pause);
    sleep $pause;
    syslog('debug','waked up');
  }
}

quit();

################################################################################
# checks
################################################################################

sub checkit {
  my $host = shift;
  my $check = shift;
  my %params = %{$cparams{$check}};
  my $key;
  foreach $key ($cfg->Parameters("$check:$host")) {
    $params{$key} = $cfg->val("$check:$host",$key) if (defined($cfg->val("$check:$host",$key)));
  }
  no strict;
  my $r = &{"check_$check"}($host,\%params);
  alarm 0;
  use strict;
  $r;
}

sub check_ping {
  my $host = shift;
  my $params = shift;
  $params->{timeout} ||= 5;
  $params->{proto} ||= 'icmp';
  syslog('debug','checking %s for ping via %s timeouting after %s seconds',$host,$params->{proto},$params->{timeout});
  my $p = Net::Ping->new($params->{proto});
  return $p->ping($host, $params->{timeout});
}

sub check_http {
  my $host = shift;
  my $params = shift;
  my $r = 0;
  $params->{port} ||= 80;
  $params->{object} ||= '/';
  $params->{timeout} ||= 30;
  my $url = "http://$host:$params->{port}$params->{object}";
  syslog('debug','checking %s for http as %s timeouting after %s seconds',$host,$url,$params->{timeout});
  eval {
    local $SIG{__DIE__} = sub { warn shift; };
    local $SIG{ALRM} = sub { die "timeout" };
    alarm $params->{timeout};
    my $ua = new LWP::UserAgent;
    $ua->agent("swatcher host tester v.$VERSION");
    my $request = HTTP::Request->new('HEAD',$url);
    my $response = $ua->request($request);
    $r = $response->is_success ? 1 : 0;
    alarm 0;
  };
  return 0 if ($@ and $@ eq 'timeout');
  $r;
}

sub check_ftp {
  my $host = shift;
  my $params = shift;
  $params->{port} ||= 21;
  $params->{user} ||= 'anonymous';
  $params->{password} ||= 'my@email.addr';
  $params->{timeout} ||= 30;
  $params->{passive} ||= 0;
  syslog('debug','checking %s for ftp as ftp://%s:%s@%s:%s/ timeouting after %s seconds',$host,$params->{user},$params->{password},$host,$params->{port},$params->{timeout});
  my $r = eval {
    local $SIG{__DIE__} = sub { warn shift; };
    local $SIG{ALRM} = sub { die "timeout" };
    alarm $params->{timeout};
    my $ftp = Net::FTP->new($host, Port => $params->{port}, Debug => 0, Passive => $params->{passive});
    return 0 if ($@ or ! defined($ftp));
    $ftp->login($params->{user},$params->{password}) or return 0;
    return 0 if($ftp->pwd() eq '');
    $ftp->quit;
    alarm 0;
    1;
  };
  return 0 if ($@ and $@ eq 'timeout');
  $r;
}

sub check_smtp {
  my $host = shift;
  my $params = shift;
  $params->{timeout} ||= 30;
  syslog('debug','checking %s for smtp timeouting after %s seconds',$host,$params->{timeout});
  local $SIG{__DIE__} = sub { warn shift; };
  my $smtp = Net::SMTP->new($host, Timeout => $params->{timeout});
  return 0 if ($@ or ! defined($smtp));
  $smtp->quit;
  1;
}

sub check_imap
{
  my $host = shift;
  my $params = shift;
  $params->{timeout} ||= 30;
  $params->{port} ||= 143;
  syslog('debug','checking %s for imap on port %s timeouting after %s seconds',$host,$params->{port},$params->{timeout});
  my $imap = Mail::IMAPClient->new(Server => $host, Port => $params->{port}, User => $params->{user}, Password => $params->{password}, Timeout => $params->{timeout});
  return 0 if ($@ or ! defined($imap));
  my $rr = 0;
  if ($params->{user})
  {
    $rr = $imap->Authenticated();
  }
  else
  {
    $rr = $imap->Connected();
  }
  $imap->disconnect();
  return $rr ? 1 : 0;
}

sub check_dns {
  my $host = shift;
  my $params = shift;
  $params->{host} ||= $host;
  $params->{port} ||= 53;
  $params->{use_tcp} = $params->{use_tcp} ? 1 : 0;
  $params->{proto} = $params->{use_tcp} ? 'tcp' : 'udp';
  $params->{timeout} ||= 10;
  syslog('debug','checking %s for dns on port %s for %s via %s timeouting after %s seconds',$host,$params->{port},$params->{host},$params->{proto},$params->{timeout});
  my $dns = new Net::DNS::Resolver;
  return 0 unless (defined($dns));
  $dns->nameservers($host);
  $dns->recurse(0);
  $dns->tcp_timeout($params->{timeout});
  $dns->usevc($params->{use_tcp});
  $dns->port($params->{port});
  my $query = $dns->send($params->{host});
  return 0 unless ($query);
  my $rr;
  foreach $rr ($query->answer) {
    next unless $rr->type eq "A";
    syslog('debug','got %s from %s',$rr->address,$dns->answerfrom);
    return 1;
  }
  syslog('debug','no A at %s: host %s failed with error: %s',$host,$dns->answerfrom,$dns->errorstring);
  0;
}

sub check_dbms {
  my $host = shift;
  my $params = shift;
  $params->{dbd} ||= 'mysql';
  $params->{host} ||= 'localhost';
  $params->{sql} ||= 'select 1';
  $params->{timeout} ||= 30;
  if ($params->{http_proxy}) {
    syslog('debug','checking %s for dbms as %s:%s:%s via %s timeouting after %s seconds',$host,$params->{dbd},$params->{dbname},$params->{user},$params->{http_proxy},$params->{timeout});
  } else {
    syslog('debug','checking %s for dbms as %s:%s:%s timeouting after %s seconds',$host,$params->{dbd},$params->{dbname},$params->{user},$params->{timeout});
  }
  my $r = eval {
    local $SIG{__DIE__} = sub { warn shift; };
    local $SIG{ALRM} = sub { die "timeout" };
    alarm $params->{timeout};
    if ($params->{http_proxy}) {
      my $ua = new LWP::UserAgent;
      $params->{sql} =~ s/([\x00-\x19"=\+\&#%;:\/<>\?{}|\\\\^~`\[\]\x7F-\xFF])/sprintf('%%%02X',ord($1))/eg;
      $params->{sql} =~ s/\x20/+/g;
      my $url = $params->{http_proxy}.'?dbd='.$params->{dbd}.'&dbname='.$params->{dbname}.'&user='.$params->{user}.'&sql='.$params->{sql};
      $ua->agent("swatcher host tester v.$VERSION");
      my $request = HTTP::Request->new('GET',$url);
      my $response = $ua->request($request);
      return 0 unless ($response->is_success);
    } else {
      my $DB = DBI->connect("DBI:$params->{dbd}:$params->{dbname}",$params->{user},$params->{password}) or return 0;
      my $result = $DB->prepare($params->{sql});
      $result->execute or return 0;
      return 0 unless ($result->rows());
      $result->finish;
      $DB->disconnect();
    }
    alarm 0;
    1;
  };
  return 0 if ($@ and $@ eq 'timeout');
  $r;
}

################################################################################
# notifications
################################################################################

sub notify {
  my ($host,$check,$status) = @_;
  my ($notification, $key, $line);

  # skip silent checks
  return if ($cparams{$check}{'silent'});
  # get notification postpone
  my $lpp = defined($cfg->val("$check:$host",'postpone')) ? $cfg->val("$check:$host",'postpone') : $postpone;
  # skip notification if it is error and it's too early to notify or the
  # forget period is not elapsed, note that badcheck exists only on error
  return if (exists($badchecks{$host}{$check}) && $badchecks{$host}{$check} + $forgetpr > time && ++$postpones{$host}{$check} != $lpp);
  if ($status) {
    return if ($postpones{$host}{$check} < $lpp);
    $line = "normal condition for check of $host for $check restored at ";
  } else {
    # adjust notification time
    $badchecks{$host}{$check} = time unless ($status);
    $line = "failed check of $host for $check at ";
  }
  $line .= scalar(localtime);

  foreach $notification (@{$hnotifications{$host}}) {
    my %params = defined(%{$nparams{$notification}}) ? %{$nparams{$notification}} : ();
    foreach $key ($cfg->Parameters("$notification:$host")) {
      $params{$key} = $cfg->val("$notification:$host",$key) if (defined($cfg->val("$notification:$host",$key)));
    }
    $params{postpone} = $lpp;
    no strict;
    &{"notify_$notification"}($line,\%params);
    use strict;
    syslog('info','sent notification on %s by %s',$host,$notification);
  }
}

sub notify_mail {
  my $line = shift;
  my $params = shift;
  my $to = $params->{addresses};
  my $from = $params->{from};
  my $smtp = $params->{smtp};
  return unless ($mail);
  $mail->MailMsg({ smtp => $smtp, from => $from, to => $to, subject => $line, msg => $line });
  syslog('debug','sent mail notification to %s containing [%s]',$to,$line);
}

sub notify_sms {
  my $line = shift;
  my $params = shift;
  my $msglen = length($line);
  my ($phone,$msg,@to,@d);
  @to = split(/,/,$params->{phones});
  $msg = $line;
  $msg =~ s/ /+/g; $msg =~ s/:/%3A/g;
  @d = (localtime(time+3600))[5,4,3,2,1,0]; $d[0]+=1900;
  my $ua = new LWP::UserAgent;
  $ua->agent("Mozilla/4.6 [en] (Win95; I)");
  my $headers = new HTTP::Headers('Referer' => 'http://www.mts.ru/sms/');
  foreach $phone (@to) {
    $phone =~ s/\+//;
    my $url = "http://www.mts.ru/sms/sent.html?Posted=1&To=$phone&Msg=$msg&count=$msglen&SMSHour=$d[3]&SMSMinute=$d[4]&SMSDay=$d[2]&SMSMonth=$d[1]&SMSYear=$d[0]";
    my $r;
    eval {
      local $SIG{__DIE__} = sub { warn shift; };
      local $SIG{ALRM} = sub { die "timeout" };
      alarm 120;
      my $request = HTTP::Request->new('GET',$url,$headers);
      my $response = $ua->request($request);
      $r = $response->is_success ? 1 : 0;
      alarm 0;
    };
    if ($@ and $@ eq 'timeout' or ! $r) {
      syslog('debug','failed sending sms notification to %s',$phone);
    } else {
      syslog('debug','sent sms notification to %s containing [%s]',$phone,$line);
    }
  }
}

sub notify_beep {
  my $line = shift;
  my $params = shift;
  my $beeps = "\007" x $params->{count};
  if ($params->{count}) {
    for (1..$params->{count}) {
      open(CON, "> /dev/console") or last;
      print CON "\007";
      close(CON);
      select(undef, undef, undef, 0.1);
    }
    syslog('debug','sent beep notification');
  } else {
    syslog('debug','failed sending beep notification');
  }
}

sub notify_console {
  my $line = shift;
  my $params = shift;
  if (open(CON, "> /dev/console")) {
    print CON "$0: $line\n";
    close(CON);
    syslog('debug','sent console notification');
  } else {
    syslog('debug','failed sending console notification');
  }
}

################################################################################
# internal staff
################################################################################

sub init {
  my $stage = shift;
  if ($stage == 0) {
    $pause = $cfg->val('main','pause'); $pause ||= 10;
    syslog('debug','will perform checks every %s second(s)',$pause);
    $postpone = $cfg->val('main','postpone'); $postpone ||= 3;
    syslog('debug','will by default pospone notifications for %s second(s)',$postpone * $pause);
    $forgetpr = $cfg->val('main','forget_period'); $forgetpr ||= 60;
    syslog('debug','will forget about bad checks after %s second(s)',$forgetpr);
    $results_file = $cfg->val('main','results_file');
  }
  if ($stage == 1) {
    %cparams = ();
    # suck in hostnames
    @hosts = split(/,/,$cfg->val('main','hosts'));
    unless (@hosts) {
      syslog('err',"no hosts specified");
      die "no hosts specified\n";
    }

    # suck in checks
    @checks = split(/,/,$cfg->val('main','checks'));
    unless (@checks) {
      syslog('err',"no checks specified");
      die "no checks specified\n";
    }

    # suck in defaults for checks
    foreach $check (@checks) {
      $cparams{$check}{_no_key} = 1;
      next unless (defined($cfg->Parameters($check)));
      foreach $key ($cfg->Parameters($check)) {
        $cparams{$check}{$key} = $cfg->val($check,$key);
      }
    }
  }
  if ($stage == 2) {
    %hchecks = ();
    %hnotifications = ();

    %results = ();
    %nparams = ();

    # suck in checks for each host
    foreach $host (@hosts) {
      my @h_checks = defined($cfg->val($host,'checks')) ? split(/,/,$cfg->val($host,'checks')) : @checks;
      # initialize it only if checks are not empty
      $hchecks{$host} = [@h_checks] if (@h_checks);
    }

    unless (keys %hchecks) {
      syslog('err','nothing to check - exiting');
      quit();
    }

    # suck in notifications
    my @notifications = split(/,/,$cfg->val('main','notifications'));
    syslog('warning','no notifications specified - working silently') unless (@notifications);

    # suck in defaults for notifications
    foreach $notification (@notifications) {
      foreach $key ($cfg->Parameters($notification)) {
        next unless (defined($cfg->val($notification,$key)));
        $nparams{$notification}{$key} = $cfg->val($notification,$key);
      }
    }

    # suck in notifications for each host
    foreach $host (@hosts) {
      my @h_notifications = defined($cfg->val($host,'notifications')) ? split(/,/,$cfg->val($host,'notifications')) : @notifications;
      # initialize it only if checks are not empty
      $hnotifications{$host} = [@h_notifications] if (@h_notifications);
    }
  }
}

sub restart {
  $restart = 2;
  syslog('warning',"Got HUP signal. Rereading configuration file.");
  $cfg->ReadConfig();
  %badchecks = ();
  %postpones = ();
  @badlines = ();
}

sub quit {
  alarm(0);
  syslog('warning',"got QUIT signal - quitting nicely");
  closelog();
  unlink $results_file if (-f $results_file);
  unlink $pidfile;
  exit(0);
}

sub usage {
  print "Usage: $0 [--version] [--[no]daemon] [--config=/path/to/config]\n";
  exit(0);
}
