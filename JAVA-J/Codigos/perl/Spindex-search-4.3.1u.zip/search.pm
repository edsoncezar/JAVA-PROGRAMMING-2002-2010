

package Spindex::search;

use Exporter;
@ISA=('Exporter');
@EXPORT= qw(&Do_Search);

# Yippee, the Spindex config module!
use Spindex::config;
use CGI qw(:standard);

# Gets directories from a directory.
# Syntax: @dirs=Get_Dirs($directory);
sub Get_Dirs { # $basedir
        my $basedir=shift;
        opendir(GD,"$basedir") or return;
        my @ENTRIES=readdir GD;
        closedir GD;

        my @DIRS;
	while(@ENTRIES) {
                my $temp=shift(@ENTRIES);
		# If it has a "dot" at the beginning, ignore it
		# (this will catch "." and ".." too)
                if($temp =~ /^\./) {
                        next;
                }
                if(-d "$basedir$temp") {
                        push(@DIRS,"$basedir$temp/");
                }
        }
        return @DIRS;

} #end Get_Dirs

# Gets files from a directory.
# Syntax: @files=Get_Files($directory);
sub Get_Files { # $basedir
        my $basedir=shift;
        opendir(GF,"$basedir") or return;
        my @ENTRIES=readdir GF;
        closedir GF;

        my @FILES;
        while(@ENTRIES) {
                my $temp=shift(@ENTRIES);
                if(-f "$basedir$temp") {
                        push(@FILES,"$basedir$temp");
                }
        }

        return @FILES;
}

# The stub to someday separate live searches from database 
# searches.
sub Search {
	unless($searchIndex) { return(Search_Filesystem(@_)); }
	else { return(Search_Index(@_)); }
}

# The bitch-of-Spindex.
# Searches a file tree, applying the rules from Spindex::config.
#   NOTE: It looks complex/inefficient, but really isn't. So much
#   indenting looks gaudy.
# Syntax: @results=Search_Filesystem($thing-to-search-for,$base-of-tree,$base-of-url-for-substitution);
sub Search_Filesystem {
        my($searchitem,$basedir,$baseurl)=@_;
	# Initialize @dirs to the base, and all of the directories
	# immediately off the base.
        my @dirs="$basedir",Get_Dirs("$basedir");
        my @yupfiles;

	# Iterate through the directory array
        while(@dirs) {
                my $dir=shift(@dirs);

		# Check for exclusion in Spindex::config.
                unless(Is_Excluded("$dir")) {
			# Ok, put all of the dirs in THIS dir into
			# the array.
                        push(@dirs,Get_Dirs("$dir"));
			#... and put all of the files in THIS dir
			# into their array.
                        my @FILES=Get_Files("$dir");
			#Iterate over the files
                        while(@FILES) {
                                my $file=shift(@FILES);
				# Is it really a file?
                                if(Isa_File("$file")) {
					# Yup, search it
					if(Search_File("$file","$searchitem")) {
                                                if($HTMLmode) {
							# Output in HTML
                                                        my $url="$file";
							# Get the title
                                                        my $title=Get_Title("$file");
							# Transpose
                                                        $url =~ s/$basedir/$baseurl/;
							$url =~ s/\s/\%20/g;
							# Add the HTMLized
							# link and title to
							# the array.
                                                        push(@yupfiles,"<a href=\"$url\">$title</a>");
                                                } else {
							# Text output,
							# filename only
 							push(@yupfiles,"$file");
                                                } #endif
                                        } #endif
                                } #endif 
                        } #end for

                } #end unless
        } # end for
        return @yupfiles;
} # end Search_Filesystem

# Checks to see if a file or directory is
# excluded according to Spindex::config
# Syntax: $boolean=Is_Excluded($filename-or-directory);
sub Is_Excluded {
        my $thing=shift;
        if(defined(@exclusions)) {
                for(@exclusions) {
                        if($thing =~ /$_/i) {
                                return 1;
                        }
                }
        }
        return 0;
}

# Function to ensure that the requested thing is really a file
# in an OS independant way, AND that it is a "valid" file according
# to Spindex::config.
# Syntax: $boolean=Isa_File($filename);
sub Isa_File {
        my $filename=shift;
        my $sofar=0;

	# Check the allowed extensions as defined 
	# in Spindex::config
	my @exts;
	if(defined(@extensions)) { push(@exts,@extensions); }
	if(defined(@titleExtensions)) { push(@exts,@titleExtensions); }
        if(defined(@exts)) {
                for(@exts) {
                        if($filename =~ /$_$/i) {
                                $sofar=1;
                                last;
                        }
                }
                #COND: Not in @extensions or @titleExtensions
		# $sofar is already set to 0
        }

	# Enforce the rules of $searchPriority.
	# This takes two options, "and" or "or"
	#   "and" requires filenames to possess at least one 
	#     "extension" and one "pattern"
	#   "or" allows for either an extension or a pattern 
	#     to satisfy
        if(($searchPriority eq "or") and ($sofar)) { return $sofar; }
        elsif(($searchPriority eq "and") and !($sofar)) { return $sofar; }
        #assume ("or" and sofar eq 0) or ("and" and $sofar eq 1)

	# Do the @searchpatterns stuff.
        if(defined(@searchpatterns)) {
                $sofar=0;
		#Extract the actual filename from the path.
                my $f=(split(/\//,"$filename"))[scalar(split(/\//,"$filename"))-1];
		#iterate through the patterns.
 		for(@searchpatterns) {
                        if($f =~ /$_/i) {
                                $sofar=1;
                                last;
                        }
                }
        }
        #COND: Not in either
        return $sofar;
}

# Extracts the title from an HTML page
# Syntax: $title=Get_Title($local-path-to-webpage);
sub Get_Title {
        my $filename=shift;
	#Check extension
	{ ## Block for garbage collection
        my $searchStatus=0; # 0=not, 1=contents, 2=name
        if(defined(@extensions)) {
                for(@extensions){
                        if($filename =~ /$_$/i) {
                                $searchStatus=1;
                                last;
                        }
                }
        }
        if(defined(@titleExtensions) and ($searchStatus != 1)) {
                for(@titleExtensions){
                        if($filename =~ /$_$/i) {
                                $searchStatus=2;
                                last;
                        }
                }
        }
	if($searchStatus == 2) { 
		# This has NOT been extensively tested yet
		if($filename =~ /.+\/(.+)\.(.+)$/) {
			return(uc($2) . " File - $1");	
	
		} else {
			return("Non-HTML File"); 
	
		}
	}

	} ## end garbage collection block

	my $titleX='';
        open(TI,"<$filename") or return;
        while(<TI>) {
                if($_ =~ /<title>(.*)<\/title>/i) {
                        close TI;
			unless(defined("$1")) { last; }
                        my $title="$1";
			
			#Strip leading whitespace
			$title =~ s/^\s+//;
			#Strip trailing whitespace
			$title =~ s/\s+$//;

			# If the title is good
			if(defined($title) and ($title ne '')) {
				close TI;
				return "$title";
			} else {		
				#Otherwise, get out of the loop
				last;
			}
                } #endif
        } #endwhile
        close TI;

	# Filename does not exist, or is bad. 
	# Make it better. :)
        return "Untitled Document";
}

# Searches a file for a term, or a modification since a date
# Syntax: $flag=Search_File($filename,$searchterm-or-date);
sub Search_File { 
        my($filename,$search)=@_;

	#Check extension
	my $searchStatus=0; # 0=not, 1=contents, 2=name
	if(defined(@extensions)) {
		for(@extensions){
			if($filename =~ /$_$/i) {
				$searchStatus=1;
				last;
			}
		}
	}	
	if(defined(@titleExtensions) and ($searchStatus != 1)) {
		for(@titleExtensions){
                        if($filename =~ /$_$/i) {
                                $searchStatus=2;
                                last;
                        }
                }
	}

	#If it's a byDate search
        if($BYDATE) {
                # If the file was modified on or since $search
                if(-M "$filename" <= "$search") { return($searchStatus);}
                else { return(0); }
        }

	# If it's a normal search
	my $gotit=0; # 0=no,1=content,2=name
	if($searchStatus==1) {	
		#Search contents
        	open(SF,"<$filename") or return(0);
        	while(<SF>) {
                	if("$_" =~ /$search/i) {
                        	$gotit=1;
                        	last;
                	}
        	}
        	close SF;
	} elsif($searchStatus==2) {
		#Search name only
		if($filename =~ /$search/i) {
			$gotit=2;
		}
	}
        return($gotit);
}

# The function actually called from Spindex to do a live 
# filesystem search. The only exported function.
# Syntax: @htmlized-results=Do_Search($searchterm-or-date,[@In-these-roots]);
sub Do_Search {
        my $searchstr=shift;
        my @InHere=();
        if(scalar(@_)) {
                @InHere=@_;
        }

	#Verbose Error Checking/Reporting

        if($BYDATE) {
                # If its not at digit or > 999
                if(($searchstr =~ /\D/) or ($searchstr > 999)) {
                        return h3("Invalid number of days.");
                }
        } else {
                # If it contains a backtick or length > 80
                if(($searchstr =~ /\`/) or (length("$searchstr") > 80)) {
                        return h3("Invalid seach item.");
                }
        }

        # check for blank entries.
        unless($searchstr) {
                return h3("You must enter a value.");
        }
       
	# Check for configuration problem.
	unless(defined(%SearchDirs)) {
                return h3("Configuration Error.");
        }

        my($basedir,$url,@Files);

	# If using the %OptionSearch feature, fix the 
	# %SearchDirs hash.
        if(defined(%OptionSearch) and defined(@InHere)) {
                Fix_SearchDirs(@InHere);
        }

	# Iterate through the $SearchDirs
        while(($basedir,$url)= each %SearchDirs) {
                if($HTMLmode) {
                        push(@Files,Search("$searchstr","$basedir","$url"));
                } else {
                        push(@Files,Search("$searchstr","$basedir"));
                }
        }

	# Change the status of $| (output buffering) if requested.
        if(defined($UnBufferedOutput) and ($UnBufferedOutput==1)) {
                $|=1;
        }
	
	# Resort the files list alphabetically, case insensitive.
        @Files=sort alpha @Files;

	# Push some data to the top of the array.
        unshift(@Files,h3(scalar(@Files), " matches found."));

 	return @Files;
}

# Kludge function to allow the %OptionSearch to
# co-exist with the existing %SearchDirs mechanism.
# Essentially takes the %OptionSearch information 
# That is required for this search, and adds it into
# the %SearchDirs hash. 
#    NOTE: Need to integrate this better in future code
#    bases, even though performance hit is negligible.
# Syntax: Fix_SearchDirs(@Dirs-from-OptionSearch-hash);
sub Fix_SearchDirs {
        my @DIRS=@_;
        my($key,$val,$dir,$url,@OKV);
        while(($key,$val)=each %OptionSearch) {
                for(@DIRS) {
                        if("$_" eq "$$val[0]") {
                                push(@OKV,"$key");
                        }
                }
        }

        #print @DIRS;
        while(($dir,$url)=each %SearchDirs) {
                my $ok=0;
                for(@OKV) {
                        if("$_" eq "$dir") { $ok=1; last; }
                }
                unless($ok) { delete($SearchDirs{$dir}); }
        }
}

# My custom "sort" algorithm that ignores case
sub alpha {
        lc($a) cmp lc($b);
}
1;

