#!/usr/bin/perl
########################################################
######################Echelon Scripts###################
#######################By WebRecka######################
print "Content-type:text/html\n\n";
&parse_form;
$ext=$FORM{'extention'};
if($FORM{action} eq "xtra"){
xtra();
exit;
}
sub xtra{
print qq~
<html>
<body bgcolor="#444455">
<center><img src="http://www.echelondesign.netfirms.com/logo.jpg"></center>
<center><table bgcolor="#eeeeee" valign=top>
<tr><td>Extra Information for $FORM{file}</td></tr>
~;
($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($FORM{file});  

if($FORM{fsize}){
$kils=$size/1000;
print "<tr><td>File Size:</td><Td>$kils Kb</td></tr>"; 
}

if($FORM{acce}){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($atime);
get_time();
print "<Tr><td>Last Access Time</td><td>$day, $mday of $month, $year at $hour:$min:$sec  </td></tr>"; 
}
if($FORM{modi}){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($mtime);
get_time();
print "<Tr><td>Last Modify Time:</td><td>$day, $mday of $month, $year at $hour:$min:$sec  </td></tr>"; 
}
if($FORM{allo}){
print "<tr><Td>Allocated Blocks</td><td>$blocks</td></tr>"; 
}
if($FORM{filei}){
print "<tr><td>Inode Number</td><td>$ino</td></tr>"; 
}
if($FORM{filep}){
print "<Tr><td>File Permission</td>";
print "<td>"; 
printf "%04o\n", $mode & 07777;  
print "</td></tr></table>"; 
} 
}
print qq~
<html>
<body bgcolor="#444455">
<center><img src="http://www.echelondesign.netfirms.com/logo.jpg"></center>
<center><table bgcolor="#eeeeee" valign=top>
~;
if($FORM{'extention'}){
$dirs[0]=$FORM{'start'};
$num=1;
getDirList($FORM{start});

if($ext eq "*"){
print "<Tr><td colspan=10 align=center>There are $asd files with any extention.</td></tr>";
}else{ 
if($asd==1){
print "<tr><td colspan=10 align=center>There is $asd file with the extention(s) $ext.</td></tr>";
}else{
print "<Tr><td colspan=10 align=center>There are $asd files with the extention(s) $ext.</td></tr>";
}
}
print qq~
<tr>
<Td align=center>Lines</td><td align=center>File</td>
~;
if($FORM{len} eq "long"){
if($FORM{fsize}){
print "<td>File Size</td>";
}
if($FORM{acce}){
print "<td>Last Access Time</td>";
}
if($FORM{modi}){
print "<td>Last Modify Time</td>";
}
if($FORM{allo}){
print "<td>Number of Allocated Blocks(unix only)</td>";
}
if($FORM{filei}){
print "<td>Inode Number</td>";
}
if($FORM{filep}){
print "<td>File Permissions</td>";
} 
}elsif($FORM{len} eq "short"){
print "<td>Link</td>";
}
for($x=0;$x<$asd;$x++){
$lines=0;
open("FILE1",$files[$x]);
&count;

print "<tr><Td align=center> ".$lines . "</td><td align=left>";
print $files[$x]."</td>";
($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($files[$x]);  
$toalsize+=$size;
if($FORM{len} eq "long"){
if($FORM{fsize}){
$kils=$size/1000;
print "<td>$kils Kb</td>"; 
}

if($FORM{acce}){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($atime);
get_time();
print "<td>$day, $mday of $month, $year at $hour:$min:$sec  </td>"; 
}
if($FORM{modi}){
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($mtime);
get_time();
print "<td>$day, $mday of $month, $year at $hour:$min:$sec  </td>"; 
}
if($FORM{allo}){
print "<td>$blocks</td>"; 
}
if($FORM{filei}){
print "<td>$ino</td>"; 
}
if($FORM{filep}){
print "<td>"; 
printf "%04o\n", $mode & 07777;  
print "</td>";
} 

}elsif($FORM{len} eq "short"){
print "<td><a href=\"lines.pl?action=xtra&file=$files[$x]&fsize=$FORM{fsize}&acce=$FORM{acce}&modi=$FORM{modi}&allo=$FORM{allo}&filei=$FORM{filei}&filep=$FORM{filep}\">Link</a></td>";
}
print "</tr>";
}
print "<tr><td align=left>";
print $total."</td><td align=left>Total Lines</td>";
if($FORM{fsize}){
$tttt= $toalsize/1000;
$megs= $tttt/1000;
print "<td colspan=3>Total Size $tttt Kb($megs Megs)</td>";
}
print "</tr>";
}else{
print qq~ 
<tr><Td>
<form action=lines.pl method=GET>
What is the path You would like to start in?(. for current dir)<br>
<input name=start value=.><br>
What extention are you looking for? (put a * for all, separate by commas)<br>
<input name=extention value="php,pl,cgi"><br>
Check the additional info you want:<br>
<table>
<Tr><Td>File Size</td><td> <input type=checkbox name=fsize></td></tr>
<Tr><Td>Last Access Time</td><td> <input type=checkbox name=acce></td></tr>
<Tr><Td>Last Modify Time</td><td> <input type=checkbox name=modi></td></tr>
<Tr><Td>Number of Allocated Blocks(unix only)</td><td> <input type=checkbox name=allo></td></tr>
<Tr><Td>Inode Number</td><td> <input type=checkbox name=filei></td></tr>
<Tr><Td>File Permissions</td><td> <input type=checkbox name=filep></td></tr>
<tr><Td>
Long Format(everything displayed on one page)</td><td><input type=radio name=len value=long></td></tr>
<tr><Td>Short Format(Click a link to get file specific info)</td><td><input type=radio name=len value=short checked></td></tr>
</table>
<input type=Submit value="List Em">
</form>
</td></tr>
~; 
}
sub getDirList { 
$Death=0;
$dir = shift."/";
opendir("DIR", $dir);
@items= readdir(DIR);
closedir(DIR);
foreach(@items){
$thisdir=$_;
if(-d "$dir$thisdir" && $thisdir !~ /\.$/){
$dirs[$num]="$dir$thisdir";
$directories++;
$num++;
$todo{$dir}.="getDirList(\"$dir$thisdir\");\n";
}elsif(-f "$dir$thisdir"){
if($ext eq "*"){
$files[$asd]="$dir$thisdir";
$asd++;
}else{
@exts=split(/,/,$ext);
foreach $extention (@exts){
if($thisdir=~ m/$extention$/){
$files[$asd]="$dir$thisdir";
$asd++;
}
}
}
}
}
eval $todo{$dir};
}
sub count{
  while ( ( $line = read_file("FILE1") ) ) {
$lines++;
$total++;
}
}
sub read_file {
    local ($filevar) = @_;
    <$filevar>;
}
sub Death{
$Death=1;
}
sub get_time{
if($wday == 1){
$day="Monday";
}
if($wday eq 2){
$day="Tuesday";
}
if($wday == 3){
$day="Wednesday";
}
if($wday == 4){
$day="Thursday";
}
if($wday == 5){
$day="Friday";
}

if($wday ==6){
$day="Saturday";
}
if($wday == 0 || $wday==7){
$day="Sunday";
}
if($mon == 0 || $mon==13 || $mon==1){
$month="January";
}
if($mon == 2){
$month="February";
}
if($mon == 3){
$month="March";
}
if($mon == 4){
$month="April";
}
if($mon == 5){
$month="May";
}
if($mon == 6){
$month="June";
}
if($mon == 7){
$month="July";
}
if($mon == 8){
$month="August";
}
if($mon == 9){
$month="September";
}
if($mon == 10){
$month="October";
}
if($mon == 11){
$month="November";
}
if($mon == 12){
$month="December";
}
$year += 1900;  
}
sub parse_form {
    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};
    }
    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );
        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $FORM{$name} = $value;
    }
}