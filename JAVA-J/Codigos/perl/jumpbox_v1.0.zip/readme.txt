# ----------------------------------------------------------------------------
# Jump Box - Readme File
# Copyright (C) 2001 interactivetools.com, inc., All Rights Reserved
# http://www.interactivetools.com/
# ----------------------------------------------------------------------------
# COPYRIGHT NOTICE                                                           
# Copyright (C) 2001 interactivetools.com, inc., All Rights Reserved         
#                                                                            
# Jump Box may be used and modified free of charge by anyone 
# so long as this copyright notice and the comments above remain intact.  
# By using this code you agree to indemnify interactivetools.com from any 
# liability that might arise from it's use.
# 
# Selling the code for this program without prior written consent is     
# expressly forbidden.
# 
# Obtain permission before redistributing this software over the Internet or 
# in any other medium. In all cases copyright and header must remain intact.
# ----------------------------------------------------------------------------


Thanks for downloading the Jump Box navigation menu.
This document will explain how to install the program on your 
web server.  

TABLE OF CONTENTS
--------------------------------------------------
1. About the Script
2. System Requirements
3. Installation
4. About Us
5. Contact



1. About the Script
----------------------------------------------------
The Jump Box is a navigation script that allows users to 
navigate a website by selecting the area they want to go to 
from a select box.

The script is written in both JavaScript and Perl/CGI. 
Normally the script redirects site visitors from one 
page to the other by using JavaScript, however, if 
a site visitor has JavaScript disabled, the Perl/CGI  
script will run as a backup. 


2. System Requirements
----------------------------------------------------
- web server 
- perl 5.005+ 
- CGI access 

3. Installation
---------------------------------------------------- 
Unzip the software files on your local computer.

Using an FTP Client, log into your server and attempt to 
locate a CGI Directory. These directories are often named /cgi-bin/, 
/cgi-local/, or /scripts/. It may be one level above your regular 
Web directory.

Upload the jumpbox.cgi file into your cgi directory. Make sure to 
make the file executable. If you're using a Unix server you can 
usually change the permissions with your FTP client, change them 
to chmod 755. If you're using a Windows Server you may need to ask 
your server administrator to make the file executable.

View jumpbox.html in your web browser. Cut and paste the source 
code into a web page of your choice. Be sure to modify the 
"action" attribute in the <form> tag. The action attribute 
should point to the location of the jumpbox.cgi file.

e.g. <form method=get action="/mycgidirectory/jumpbox.cgi" 
onsubmit="location.href=jb.options[jb.selectedIndex].value; 
return false;">

You may also want to modify the options in the <select> tags to reflect 
the links you want the jump box to redirect to. Make sure to use complete 
URLs.

Upload the modified pages to your web server.

Visitors can now come to your site and have an intuitive navigational 
experience.


4. About Us
----------------------------------------------------
At interactivetools.com, we make affordable Perl CGI scripts, 
software and tools to enhance your website. 

For more information about our other interactivetools.com products
visit our website at http://www.interactivetools.com/


5. Contact
----------------------------------------------------
We can be contacted at the following email addresses:

info@interactivetools.com		- General Inquiries
sales@interactivetools.com		- Product Inquiries

Please note that we can not offer support for any of our free scripts.  