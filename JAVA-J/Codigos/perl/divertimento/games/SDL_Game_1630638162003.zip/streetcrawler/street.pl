#!/usr/bin/perl -w

# Street Crawler By Jason Myerscough
#
# Originally created in Delphi for Windows by me :P
#
# Converted to Linux
#
# Started 30 July 2003
#
# The game uses SDL, whichis multi-platformed so you should be able to use it in Windows.
# The game consists of over 600 lines of code. Everything is structured into sub-routines
# The following is a lis of all sub routines used and written by me.
#
# sub Start
#	This sub draws the image of the two cars at the start of the program
# sub DrawTitle
#	DrawTitle draws the title at the position were it stops scrolling upwards
# sub MoveTitle
#	MoveTitle makes the Title of the game scroll upwards
# sub MoveCredits
#	Makes the credits scroll upwards
# sub MoveCar
#	Makes the cars move accross the screen
# sub DrawBG
#	Draws the main games background image
# sub Pause
#	This allows the user to pause the game press p to pause. To unpause press anything of move the
#	mouse
# sub Up
#	moves the game character up 2
# sub Down
#	moves the game character down 2
# sub Left
#	moves the game character left 2
# sub Right
#	moves the game character right 2
# sub DrawPlayer
#	draws the character at his new position
# sub Hit
#	checks to see if the character has been ran over
# sub End
#	Game over screen
# sub Won
#	inform you that you have won
#
#
# to move the character around use the arrow keys up, down, left and right
#
# I have been working on some SDL tutorials that will be uploaded soon..
#
# Finally please rate my code, thanks

use SDL::App;
use SDL::Surface;
use SDL::Event;

	my %GTitle = (
			Img => SDL::Surface->new ( -name => "title.bmp"),
			Xpos => 400,
			Ypos => 400
		);
		
	my %GStart = (
			Img => SDL::Surface->new( -name => "start.bmp"),
			Xpos => 0,
			Ypos => 0
		);
		
	my %GCredits = (
			Img => SDL::Surface->new( -name => "credit.bmp"),
			Xpos => 0,
			Ypos => 0
		);
		
	my %Player = (
			Img => SDL::Surface->new( -name => "manalive.bmp"),
			Dead => SDL::Surface->new( -name => "deadman.bmp"),
			Xpos => 0,
			Ypos => 0,
			Hit => 0,
			X => 100,
			Y => 380
		); 
		
	my %Car = (
			Img => SDL::Surface->new( -name => "truck.bmp"),
			Xpos => 0,
			Ypos => 0,
			Move => 0
		);
		
	my %CoolCar = (
			Img => SDL::Surface->new( -name => "car1.bmp"),
			Xpos => 0,
			Ypos => 0,
			Move => 350
		);
		
	my %CrapCar = (
			Img => SDL::Surface->new( -name => "car2.bmp"),
			Xpos => 0,
			Ypos => 0,
			Move => 350
		);
		
	my %Bus = (
			Img => SDL::Surface->new( -name => "bus.bmp"),
			Xpos => 0,
			Ypos => 0,
			Move => 0
		);
		
	my $My_SDL = SDL::App->new(
					-title => 'Street Crawler',
					-width => 400,
					-height => 400,
					-flags => SDL_DOUBLEBUF
				);
				
	my $event = SDL::Event->new();
			
		
	sub Start {
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $GStart{Img}->width,
							-height => $GStart{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => 0,
							-y => 0,
							-width => $GStart{Img}->width,
							-height => $GStart{Img}->height
						);
						
			$GStart{Img}->blit($Src, $My_SDL, $Destin);
	} # end start
	
	sub DrawTitle {
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $GTitle{Img}->width,
							-height => $GTitle{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => 50,
							-y => 25,
							-width => $GTitle{Img}->width,
							-height => $GTitle{Img}->height
						);
			$GTitle{Img}->blit($Src, $My_SDL, $Destin);
	} # end DrawTitle
			
				
	sub MoveTitle {
			my $i = 400;
			
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $GTitle{Img}->width,
							-height => $GTitle{Img}->height
						);
						
			$MyColor = SDL::Color->new(
							-r => 0,
							-g => 0,
							-b => 255
						);
			$GTitle{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);
			
			while($i > 25) {
				Start;
				
				my $Destin = SDL::Rect->new(
							-x => 50,
							-y => $i,
							-width => $GCredits{Img}->width,
							-height => $GCredits{Img}->height
						);
				
				$GTitle{Img}->blit($Src, $My_SDL, $Destin);
				$My_SDL->flip();
				$i--;
			}
	} # end MoveTitle
	
	sub MoveCredits {
			my $i = 400;
			
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $GCredits{Img}->width,
							-height => $GCredits{Img}->height
						);
						
			$MyColor = SDL::Color->new(
							-r => 0,
							-g => 0,
							-b => 255
						);
			$GCredits{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);
			
			while($i > 250) {
				Start;
				DrawTitle;
				my $Destin = SDL::Rect->new(
							-x => 50,
							-y => $i,
							-width => $GCredits{Img}->width,
							-height => $GCredits{Img}->height
						);
				
				$GCredits{Img}->blit($Src, $My_SDL, $Destin);
				$My_SDL->flip();
				$i--;
			}
	} # end MoveCredits
	
	sub MoveCar {
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Car{Img}->width,
							-height => $Car{Img}->height
						);
			$MyColor = SDL::Color->new(
							-r => 0,
							-g => 0,
							-b => 255
						);
			$Car{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);									
			
			if(($Car{Xpos} ) > 400){
				my $Destin = SDL::Rect->new(
							-x => 0,
							-y => 25,
							-width => $Car{Img}->width,
							-height => $Car{Img}->height
						);	
				$Car{Img}->blit($Src, $My_SDL, $Destin);
				$Car{Xpos} = $Destin->x;
				$Car{Ypos} = $Destin->y;
				$Car{Move} = 0;
			} else {
				$Car{Move} += 3;
				my $Destin = SDL::Rect->new(
							-x => $Car{Move},
							-y => 40,
							-width => $Car{Img}->width,
							-height => $Car{Img}->height
						);
				$Car{Img}->blit($Src, $My_SDL, $Destin);
				$Car{Xpos} = $Destin->x;
				$Car{Ypos} = $Destin->y;
			}
			##### End of truck
			
			$Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $CoolCar{Img}->width,
							-height => $CoolCar{Img}->height
						);
			$CoolCar{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);									
			
			if(($CoolCar{Xpos} ) < 1){
				$Destin = SDL::Rect->new(
							-x => 250,
							-y => 80,
							-width => $CoolCar{Img}->width,
							-height => $CoolCar{Img}->height
						);	
				$CoolCar{Img}->blit($Src, $My_SDL, $Destin);
				$CoolCar{Xpos} = $Destin->x;
				$CoolCar{Ypos} = $Destin->y;
				$CoolCar{Move} = 350;
			} else {
				$CoolCar{Move} -= 5;
				$Destin = SDL::Rect->new(
							-x => $CoolCar{Move},
							-y => 100,
							-width => $CoolCar{Img}->width,
							-height => $CoolCar{Img}->height
						);
				$CoolCar{Img}->blit($Src, $My_SDL, $Destin);
				$CoolCar{Xpos} = $Destin->x;
				$CoolCar{Ypos} = $Destin->y;
			} ##### End of cool car
			##############################################################
			
			$Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Bus{Img}->width,
							-height => $Bus{Img}->height
						);
			$Bus{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);									
			
			if(($Bus{Xpos} ) > 400){
				$Destin = SDL::Rect->new(
							-x => 250,
							-y => 80,
							-width => $Bus{Img}->width,
							-height => $Bus{Img}->height
						);	
				$Bus{Img}->blit($Src, $My_SDL, $Destin);
				$Bus{Xpos} = $Destin->x;
				$Bus{Ypos} = $Destin->y;
				$Bus{Move} = 0;
			} else {
				$Bus{Move} += 3;
				$Destin = SDL::Rect->new(
							-x => $Bus{Move},
							-y => 180,
							-width => $Bus{Img}->width,
							-height => $Bus{Img}->height
						);
				$Bus{Img}->blit($Src, $My_SDL, $Destin);
				$Bus{Xpos} = $Destin->x;
				$Bus{Ypos} = $Destin->y;
			} ### END OF BUS
			##################################
			
			$Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $CrapCar{Img}->width,
							-height => $CrapCar{Img}->height
						);
			$CrapCar{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);									
			
			if(($CrapCar{Xpos} ) < 1){
				$Destin = SDL::Rect->new(
							-x => 250,
							-y => 80,
							-width => $CrapCar{Img}->width,
							-height => $CrapCar{Img}->height
						);	
				$CrapCar{Img}->blit($Src, $My_SDL, $Destin);
				$CrapCar{Xpos} = $Destin->x;
				$CrapCar{Ypos} = $Destin->y;
				$CrapCar{Move} = 350;
			} else {
				$CrapCar{Move} -= 4;
				$Destin = SDL::Rect->new(
							-x => $CoolCar{Move},
							-y => 280,
							-width => $CrapCar{Img}->width,
							-height => $CrapCar{Img}->height
						);
				$CrapCar{Img}->blit($Src, $My_SDL, $Destin);
				$CrapCar{Xpos} = $Destin->x;
				$CrapCar{Ypos} = $Destin->y;
			} 
			
	} # end MoveCar
	
	sub DrawBG {
			my $Bg = SDL::Surface->new( -name => "background.bmp");
			
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Bg->width,
							-height => $Bg->height
						);
			my $Destin = SDL::Rect->new(
							-x => 0,
							-y => 0,
							-width => $Bg->width,
							-height => $Bg->height
						);
						
			$Bg->blit($Src, $My_SDL, $Destin);	
	} # end drawBG
	####################################################
	
	sub Pause {
		my $Pause = SDL::Surface->new( -name => "pause.bmp");
		
		my $Src = new SDL::Rect(
						-x => 0,
						-y => 0,
						-width => $Pause->width,
						-height => $Pause->height
					);
		my $Destin = SDL::Rect->new(
						-x => 100,
						-y => 100,
						-width => $Pause->width,
						-height => $Pause->height
					);
					
		$MyColor = SDL::Color->new(
							-r => 0,
							-g => 0,
							-b => 255
						);
		$Pause->set_color_key(SDL_SRCCOLORKEY, $MyColor);	
					
		$Pause->blit($Src, $My_SDL, $Destin);	
		$My_SDL->flip();
		
		my $My_Event = new SDL::Event;
		$event->wait;
	} # end pause
	
	sub Up {
		
		if($Player{Y} >= 3){
			$Player{Y} -= 2;
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
		} 
	}
	
	sub Down {
		
		if(($Player{Y} + $Player{Img}->width) <= 390){
			$Player{Y} += 2;
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
		} 
	}
	
	sub Left {
		if($Player{X} > 1){
			$Player{X} -=2;
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
		} 
	}
	
	sub Right {
		if(($Player{X} + $Player{Img}->width) <= 390){
			$Player{X} +=2;
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
		} 
	}
	
	sub DrawPlayer {
		if($Player{Hit} == 0) {
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
			my $Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Img}->width,
							-height => $Player{Img}->height
						);
					
			my $MyColor = SDL::Color->new(
								-r => 0,
								-g => 0,
								-b => 255
							);
			$Player{Img}->set_color_key(SDL_SRCCOLORKEY, $MyColor);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
			$Player{Img}->blit($Src, $My_SDL, $Destin);
		} else {
			$Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $Player{Dead}->width,
							-height => $Player{Dead}->height
						);
			$Destin = SDL::Rect->new(
							-x => $Player{X},
							-y => $Player{Y},
							-width => $Player{Dead}->width,
							-height => $Player{Dead}->height
						);
			
			
			$Player{Dead}->set_color_key(SDL_SRCCOLORKEY, $MyColor);
			$Player{Xpos} = $Destin->x;
			$Player{Ypos} = $Destin->y;
			$Player{Dead}->blit($Src, $My_SDL, $Destin);
		}
	
	}
	
	sub Hit {
			if((($Player{Xpos} + $Player{Img}->width) >= $CrapCar{Xpos}) && ($Player{Xpos}  <= ($CrapCar{Xpos}+$CrapCar{Img}->width)) && ($Player{Ypos} <= ($CrapCar{Ypos}+$CrapCar{Img}->height)) && (($Player{Ypos}+$Player{Img}->height) >= $CrapCar{Ypos})){
				$Player{Hit} = 1;
			}
			if((($Player{Xpos} + $Player{Img}->width) >= $CoolCar{Xpos}) && ($Player{Xpos}  <= ($CoolCar{Xpos}+$CoolCar{Img}->width)) && ($Player{Ypos} <= ($CoolCar{Ypos}+$CoolCar{Img}->height)) && (($Player{Ypos}+$Player{Img}->height) >= $CoolCar{Ypos})){
				$Player{Hit} = 1;
			}
			if((($Player{Xpos} + $Player{Img}->width) >= $Car{Xpos}) && ($Player{Xpos}  <= ($Car{Xpos}+$Car{Img}->width)) && ($Player{Ypos} <= ($Car{Ypos}+$Car{Img}->height)) && (($Player{Ypos}+$Player{Img}->height) >= $Car{Ypos})){
				$Player{Hit} = 1;
			}
			if((($Player{Xpos} + $Player{Img}->width) >= $Bus{Xpos}) && ($Player{Xpos}  <= ($Bus{Xpos}+$Bus{Img}->width)) && ($Player{Ypos} <= ($Bus{Ypos}+$Bus{Img}->height)) && (($Player{Ypos}+$Player{Img}->height) >= $Bus{Ypos})){
				$Player{Hit} = 1;
			}
	}	
	
	sub End {
			DrawBG;
			DrawPlayer;
			MoveCar;
			
			my $vote = SDL::Surface->new( -name => "vote.bmp");
			
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $vote->width,
							-height => $vote->height
						);
			$Destin = SDL::Rect->new(
							-x => 70,
							-y => 100,
							-width => $vote->width,
							-height => $vote->height
						);
						
			my $my_color = new SDL::Color(
							-r => 0,
							-g => 0,
							-b => 255
						);
			$vote->set_color_key(SDL_SRCCOLORKEY, $my_color);
			$vote->blit($Src, $My_SDL, $Destin);			
			
			$My_SDL->flip();
			$My_SDL->delay(5000);
			exit;
	}	
	
	sub Won{
		if($Player{Ypos} <= 3) {
			my $won = SDL::Surface->new( -name => "won.bmp");
			
			my $Src = new SDL::Rect(
							-x => 0,
							-y => 0,
							-width => $won->width,
							-height => $won->height
						);
			$Destin = SDL::Rect->new(
							-x => 50,
							-y => 100,
							-width => $won->width,
							-height => $won->height
						);
						
			my $my_color = new SDL::Color(
							-r => 0,
							-g => 0,
							-b => 255
						);
			$won->set_color_key(SDL_SRCCOLORKEY, $my_color);
			$won->blit($Src, $My_SDL, $Destin);			
			
			$My_SDL->flip();
			$My_SDL->delay(5000);
			exit;
		}
	} # end won sub
					
	####################################################################
	
	MoveTitle;
	MoveCredits;
	$My_SDL->flip();
	$My_SDL->delay(500);
	
	for(;;){
		
		DrawBG;
		MoveCar;
		DrawPlayer;
		$My_SDL->flip();
		
		$event->poll();
		if($event->key_sym() == SDLK_UP) { Up; }
		elsif($event->key_sym() == SDLK_DOWN) { Down; }
		elsif($event->key_sym() == SDLK_LEFT) { Left; }
		elsif($event->key_sym() == SDLK_RIGHT) { Right; }
		elsif($event->key_sym() == SDLK_p) { Pause; }
		my $type = $event->type;
		
		if($Player{Hit} == 1) { End ; }
		
		if($type == SDL_QUIT()) { 
			print "Written By Jason Myerscough\n";
			exit;
		}
		Won;
		Hit;
		$My_SDL->delay(20);
	}