#!/user/bin/perl

#######################################
# This Was Just A Game I Made In My   #
# Holidays While Learning Perl. Enjoy #
# It As Much As You Want.             #
#                                     #
# By {FP}HappyHacker                  #
#######################################

#Get Players Names
print "What is player 1's name? ";
chomp($player1 = <STDIN>);
print "What is player 2's name? ";
chomp($player2 = <STDIN>);

##$CP is the CurrentPlayers Symbal(either X or O)

##The @move array for the spots on the board
@move = ("0","1","2","3","4","5","6","7","8","9");

#the win detector(Which doesn't matter anymore)
$won = 0;

##$CP is the CurrentPlayer
$CP = $player1;

##
@s = ("O","X");

##$S is the CurrentPlayers Symbal(either X or O)
$S = "O";
$counter = 0;
##Ask for the input spot
GAME: until ($won == 1)
	{
	check();
	write;
	$counter++;
	print "$CP($S) Its Your Go!!! ";
	chomp($guess = <STDIN>);
	if ($guess eq "quit")
		{
		print "Good Bye\n";
		last GAME;
		}	
	elsif ($guess >= 10)
		{
		$counter--;
		print "$CP You Lose a Turn Because $guess Is Too Big(1-9)!!!\n";
		}
	elsif ($guess <= 0)
		{
		$counter--;
		print "$CP You Lose a Turn Because $guess Is Too Small(1-9)!!!\n";
		}
	
	##Check for that move.  if its already done you lose a turn
	else 
		{
		if ($move[$guess] eq $s[0])
			{
			print "There is already an $s[0] in that spot!!!\n";
			}
		elsif ($move[$guess] eq $s[1])
			{
			print "There is already an $s[1] in that spot!!!\n";
			}
		else
			{
			$move[$guess] = $S;
			print "$CP you have made your move putting a $S in spot $guess\n";
			}
		}
check();		
##player switch
	if ($CP eq $player1)
		{
		$CP = $player2;
		$S = $s[1]
		}
	elsif ($CP eq $player2)
		{
		$CP = $player1;
		$S = $s[0]
		}
	else
		{
		print "Something Went Wrong";
		last GAME;
		}	
	}

##This Sub Checks For The Wining Move
##It tests each wining move


sub check
	{
	if ($move[1] eq $S && $move[2] eq $S && $move[3] eq $S)
		{
		print "$CP You WIN!!!\nmove[1,2,3]";
		last GAME;
		}
	elsif ($move[1] eq $S && $move[4] eq $S && $move[7] eq $S)
		{
		print "$CP You WIN!!!\nmove[1,4,7]";
		last GAME;
		}
	elsif ($move[3] eq $S && $move[6] eq $S && $move[9] eq $S)
		{
		print "$CP You WIN!!!\nmove[3,6,9]";
		last GAME;
		}
	elsif ($move[1] eq $S && $move[5] eq $S && $move[9] eq $S)
		{
		print "$CP You WIN!!!\nmove[1,5,9]";
		last GAME;
		}
	elsif ($move[2] eq $S && $move[5] eq $S && $move[8] eq $S)
		{
		print "$CP You WIN!!!\nmove[2,5,8]";
		last GAME;
		}
	elsif ($move[3] eq $S && $move[5] eq $S && $move[7] eq $S)
		{
		print "$CP You WIN!!!\nmove[3,5,7]";
		last GAME;
		}
	elsif ($move[4] eq $S && $move[5] eq $S && $move[6] eq $S)
		{
		print "$CP You WIN!!!\nmove[4,5,6]";
		last GAME;
		}
	elsif ($move[7] eq $S && $move[8] eq $S && $move[9] eq $S)
		{
		print "$CP You WIN!!!\nmove[7,8,9]";
		last GAME;
		}
		
		
	if ($counter == 9)
		{
		print "Well That Was A Good Game But Neither Of You Win!!!";
		last GAME;
		}
	}


##This is the grid for output
format STDOUT =

			-------------
			| @<| @<| @<|
			$move[1],$move[2],$move[3]
			-------------
			| @<| @<| @<|
			$move[4],$move[5],$move[6]
			-------------
			| @<| @<| @<|
			$move[7],$move[8],$move[9]
			-------------
					
					
.