print "Content-type:text/html\n\n";
$fstprice=80;
$sndprice=200;
$trdprice=500;
$head=qq~<Center>
<img src="http://www.echelondesign.net/newdesign/logo.jpg">
<Center>~;
parse_form();
sub parse_form{
    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};
    }
    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        ${$name} = $value;
#print $name."<br>";
  
  }
}
sub getcookies {
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookies{$name} = $value;
        }
    }
}
sub get_time{
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
if($wday == 1){
$day="Monday";
}
if($wday eq 2){
$day="Tuesday";
}
if($wday == 3){
$day="Wednesday";
}
if($wday == 4){
$day="Thursday";
}
if($wday == 5){
$day="Friday";
}

if($wday ==6){
$day="Saturday";
}
if($wday == 0 || $wday==7){
$day="Sunday";
}
$mon++;
if($mon == 0 || $mon==13 || $mon==1){
$month="January";
}
if($mon == 2){
$month="February";
}
if($mon == 3){
$month="March";
}
if($mon == 4){
$month="April";
}
if($mon == 5){
$month="May";
}
if($mon == 6){
$month="June";
}
if($mon == 7){
$month="July";
}
if($mon == 8){
$month="August";
}
if($mon == 9){
$month="September";
}
if($mon == 10){
$month="October";
}
if($mon == 11){
$month="November";
}
if($mon == 12){
$month="December";
}
$year += 1900;  
if($hour > 12){
$hour-=12;
}
$thetime=qq~$day, $mday of $month, $year at $hour:$min:$sec~;
}
sub sort{
@initial_list = sort { lc($a) cmp lc($b)} @finallist; 
}
sub set_cookie{
my ($name,$value,$defin)=@_;
if($defin != 1){
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="$name=$value;";
</SCRIPT>
~;
}else{
print qq~
<SCRIPT LANGUAGE="JavaScript">
document.cookie="$name=$value; expires=Monday, 04-Apr-1010 05:00:00 GMT";
</SCRIPT>
~;
}
}
sub getcookies{
    my ( @cookies, $name, $value, $cookie );
    if ( $ENV{'HTTP_COOKIE'} ) {
        @cookies = split ( /;/, $ENV{'HTTP_COOKIE'} );
        foreach $cookie (@cookies) {
            ( $name, $value ) = split ( /=/, $cookie );
            $name =~ s/ //g;
            $cookiess{$name} = $value;
	
        }
    }
}
1;