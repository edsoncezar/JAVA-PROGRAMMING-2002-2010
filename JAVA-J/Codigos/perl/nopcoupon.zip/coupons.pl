#!/usr/bin/perl
require 'echelon.pl';
print $head;
if(!$action){
menu();

}else{
&{$action};
}
sub menu{
print qq~
<form action=coupons.pl method=get>
<table><tr><tD colspan=2><b>Go To:</b></tD></tr>
<Tr><Td><B>View A Coupon</b></td><td><input type=radio name=action value="view"></tr>
<Tr><Td><b>Add New Coupon</b></td><td><input type=radio name=action value="add"></tr>
<Tr><Td><B>Edit A Coupon</b></td><td><input type=radio name=action value="edit"></tr>
<Tr><Td><B>Remove A Coupon</b></td><td><input type=radio name=action value="remove"></tr>
<tr><td colspan=2 align=center><input type=submit value="Continue" >
</table>
~;
}
sub view{
Create_buttons("viewcoupon","View");
}
sub viewcoupon{

($mid,$menu)=@_;
if($id){
$mid=$id;
}
$file="coupons.ech";
open(file,$file);
while(<file>){
@dat=split(/\|/,$_);
if($dat[0] eq $mid){
$tid=$dat[1];
$ult=$dat[2];
@data=@dat;
last;
}
}
print qq~<table border=1 width=400><tr>
<td colspan=4 align=center><b>Coupon Code:</b><br>
<font color=gray>$mid</font></td></tr>
~;

for($x=1; $x<=$tid; $x++){
$num1=$x+2;
$num2=$x+2+$data[1];
$name="name_$x";
$name2="name2_$x";
print qq~<tr><Td><b>ID # $x:</b></td>
<Td>$data[$num1]
</td><td><b>Cost Reduction:</b></td>
<td>$data[$num2]</td></tr>~;
}
if($data[2] eq 1){
$checked="Yes";
}else{
$checked="No";
}
print qq~<tr><Td colspan=2><b>Make this an Unlimited Use Coupon?</b></td><td align=center colspan=2>$checked</td></tr>~;
if($menu ne 'no'){
print qq~<tr><Td colspan=4 align=center><form action="coupons.pl" method=post><input type=submit value="Continue"></td></tr>~;
}
}
sub remove3{
if($sure eq "Yes"){
$file="coupons.ech";
open(file,$file);
while(<file>){
@dat=split(/\|/,$_);
if($dat[0] eq $code){
}else{
$back.=$_;
}
}
close(file);
open(file,">$file");
print file $back;
close(file);
print qq~
<table border=1 width=300><tr><td colspan=2 align=center><b>Coupon Code:</b><br>
<font color=gray>$code</font></td></tr>
<Tr><Td align=center><font color=green>
Coupon Removal Successfull!</font></td></tr>
~;
}else{
}
menu();
}
sub remove2{
print qq~
<b>Are you <u>POSITIVE</u> you wish to remove this coupon($id)?  It is <u>UN</u>recoverable!</b><br>
<form action="coupons.pl" method="post">
<input type=hidden name=action value=remove3>
<input type=hidden name=code value=$id>
<input type=submit name=sure value="Yes"> <input type=submit name=sure value="No"></form><br><br>This is what this coupon($id) does:~;
viewcoupon($id,'no');
}
sub remove{
Create_buttons("remove2","Remove");
}
sub Create_buttons{
($action,$oaction)=@_;
print qq~ 
<style>
.but
{
 font-family:verdana;
 background-color:#E3E3E3;
 font-size:9px;
 color:black;
 font:bold;
 width:150;
}
</style>
<centeR><table border=1><Tr><Td><b>Chose a Coupon To $oaction<form action="coupons.pl"><input type=hidden name=action value=$action></b></td></tr>
~;
$file="coupons.ech"; 
open(file,"$file");
while(<file>){
@data=split(/\|/,$_);
print qq~<tr><Td><input type=submit name=id value="$data[0]" class="but"></td></tr>~;
}
}
sub edit3{
$file="coupons.ech";
open(file,$file);
while(<file>){
@dat=split(/\|/,$_);
if($dat[0] eq $code){
$back.="$code|$tid|$ult|";
for($x=1; $x<=$tid; $x++){
$name="name_$x";
$back.= "${$name}|";
}
for($x=1; $x<=$tid; $x++){
$name="name2_$x";
$back.="${$name}|";
}
$back.="\n";
}else{
$back.=$_;
}

}
close(file);
open(file,">$file");
print file $back;
close(file);
print qq~<table border=1 width=300><tr><td colspan=2 align=center><b>Coupon Code:</b><br>
<font color=gray>$code</font></td></tr>
<Tr><Td align=center><font color=green>
Coupon Edit Successfull!</font></td></tr>~;
menu();
}
sub edit2{
$file="coupons.ech";
open(file,$file);
while(<file>){
@dat=split(/\|/,$_);
if($dat[0] eq $id){
$tid=$dat[1];
$ult=$dat[2];
@data=@dat;
last;
}
}
print qq~<table border=1 width=400><tr>
<td colspan=4 align=center><b>Coupon Code:</b><br>
<font color=gray>$id</font></td></tr>
<form action="coupons.pl" method="GET">
<input type=hidden name="action" value="edit3" >
<input type=hidden name=code value=$dat[0]>
~;

for($x=1; $x<=$tid; $x++){
$num1=$x+2;
$num2=$x+2+$data[1];
$name="name_$x";
$name2="name2_$x";
print qq~<tr><Td><b>ID # $x:</b></td>
<Td><input name=$name size=5 value=\"$data[$num1]\">
</td><td><b>Cost Reduction:</b></td>
<td><input name="$name2" size=5 value=\"$data[$num2]\"></td></tr>~;
}
if($data[2] eq 1){
$checked="checked";
}
print qq~ <input type=hidden name=tid value=$tid>~;
print qq~<tr><Td colspan=2><b>Make this an Unlimited Use Coupon?</b></td><td align=center colspan=2><input type=checkbox name=ult value=1 $checked></td></tr>~;
print qq~<tr><Td colspan=4 align=center><input type=submit value="Continue"></td></tr>~;
}
sub edit{
Create_buttons("edit2","Edit");
}
sub add3{
$file="coupons.ech"; 
open(file,">>$file");
print file "$code|$tid|$ult|";
for($x=1; $x<=$tid; $x++){
$name="name_$x";
print file "${$name}|";
}
for($x=1; $x<=$tid; $x++){
$name="name2_$x";
print file "${$name}|";
}
print file "\n";
close(file);
print qq~<table border=1 width=300><tr><td colspan=2 align=center><b>Coupon Code:</b><br>
<font color=gray>$code</font></td></tr>
<Tr><Td align=center><font color=green>
Coupon Additon Successfull!</font></td></tr>~;
menu();
}
sub add2{
print qq~<table border=1 width=400><tr>
<td colspan=4 align=center><b>Coupon Code:</b><br>
<font color=gray>$code</font></td></tr>
<form action="coupons.pl" method="GET">
<input type=hidden name="action" value="add3" >
<input type=hidden name=code value=$code>
~;

for($x=1; $x<=$tid; $x++){
$name="name_$x";
$name2="name2_$x";
print qq~<tr><Td><b>ID # $x:</b></td>
<Td><input name=$name size=5 value=\"#XX\">
</td><td><b>Cost Reduction:</b></td>
<td><input name="$name2" size=5 value=\"1\"></td></tr>~;
}

if($total eq 'yes'){
$tid++;
$name2="name2_$tid";
$name="name_$tid";
print qq~<Tr><Td colspan=2><b>Total Cost Reduction:</b><br>
<font size=\"-\">*Note this number lowers the TOTAL cost AFTER all the other ids have been reduced</font>
</td><td colspan=2 align=center><input type=hidden name=$name value="total"><input name=$name2 size=5 value="1"></td></tr>~;
}

print qq~ <input type=hidden name=tid value=$tid>~;
print qq~<tr><Td colspan=2><b>Make this an Unlimited Use Coupon?</b></td><td align=center colspan=2><input type=checkbox name=ult value=1></td></tr>~;
print qq~<tr><Td colspan=4 align=center><input type=submit value="Continue"></td></tr>~;
}
sub add{
print "<table border=1 width=200><tr><td colspan=2 align=center><b>Coupon Code:</b><br>";
$chars=get_random_chars(10);
print qq~<font color=gray>$chars</font></td></tr>
<form action="coupons.pl" method=POST>
<input type=hidden name=action value=add2>
<input type=hidden name=code value="$chars">
<tr><td>Total # of IDs that will be effected:</td><td><input name=tid size=5 value=1></td></tr>
<Tr><Td>Will the Total cost be effected?</td><Td><input type=checkbox name=total value=yes></td></tr>
<tr><Td colspan=2 align=center><input type=submit value="Continue"></tD></tR></table>~;
}
sub get_random_chars{
my ($total)=@_;
my @array = (a..z,A..Z,0..9);
srand;
my ($string);
foreach (1..$total) 
{    
	my $rand = int(rand scalar(@array));   
        $string.=$array[$rand];    
	splice(@array,$rand,1);    
	
}
$file="coupons.ech";
open(file,$file);
while(<file>){
@data=split(/\|/,$_);
if($data[0] eq $string){
get_random_chars($total);
}
}
return ($string);

}