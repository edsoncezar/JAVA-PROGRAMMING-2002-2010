#! /usr/bin/perl

print <<EOD;
Content-Type: text/html


<HTML><HEAD><TITLE>Boolean Search Example by Ashley Harris</TITLE></HEAD><BODY>

EOD

#basically the same as the asp module
#but with different string parsing and
#query string handling
#and $ before variable names

#querystring parsing

my $req = $ENV{QUERY_STRING};
#$req = "search=%22Legions+of+Terror%22";

my %in = ();
my @vals = split(/\&/,$req);
my $a;
my $key,$value;

 foreach $a (@vals)
 {
  $a =~ m/([a-zA-Z0-9\%\+]{1,40})\=([a-zA-Z0-9\%\+]{1,80})/;
  if ($1 eq "") {next}
  ($key,$value) = ($1,$2);
  $key =~ s/\+/ /g;
  $value =~ s/\+/ /g;
  $key =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
  $value =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
  $in{$key} = $value;
 }

#this works on my perl server, that I built myself.
#(see PSC, vb section, complete perl, php and asp webserver)

if ($in{search} ne "")
{
    my $z,$x;
    print "<B>Searching using the pattern: <I>$in{search}</I> found these results:</B><P>\n";

    open TS,"data.txt";
    while ($x = <TS>)
      {
        $z = checkstring($in{search}, $x);
        #exit;
        if ($z eq "true")
          {
            print "$x<P>\n";
          }
      }
    close TS;
}

sub checkstring()
{
    my ($query,$test) = @_;
    #print "IN: $query\n";
    #query is something like "Ashley and Harris and not Maxwell"
    #test is the string in which to search, ie "Ashley Maxwell Harris"
    # (this example would not match, as maxwell was present)

    return 0 if $query eq "";
    
    #query is a string you'd pass to a search engine like altavista etc. ie:
    #'animal AND (bear OR "Baby fox")'
    #Dim s As Long, f As Long, a As Long, b As Long
    #Dim i() As String
    #dim j() As String
    

    my $s = InStrRev($query, "(");
    my $f = 1;
    my $ns;
    
    while ($s > 0 && $f > 0)
    {
     if ($s > 0)
      {
        $f = InStr($s, $query, ")");
        
        if ($f > 0)
          {
            $ns = uc(CBool(checkstring(Mid($query, $s + 1, $f - $s - 1), $test)));
            $query = Mid($query, 1, $s - 1) . $ns . Mid($query, $f + 1);
          }
      }
     $s = InStrRev($query, "(");
    }
    
    #remove any invalid characters
    $query = Replace($query, "?", "");
    $query = Replace($query, "  ", " ");
    $query = Replace($query, vbCr, "");
    $query = Replace($query, vbLf, "");
    $query = Replace($query, vbTab, "");
    $query = Replace($query, "  ", " ");
    $query = Replace($query, ".", "");
    $query = Replace($query, "(", "");
    $query = Replace($query, ")", "");
    
    my @i = split(/ /,$query);
    
    #ok, this is weird, say this split resulted in:
    # 'Bear' 'OR' '"Baby' ' fox"'
    
    #turn it into: 'bear' 'OR' 'Baby Fox'

    
    if (InStr(1, $query, "\"") > 0)
      {
        for ($a=$#i;$a >=0;$a--)
          {
            if (Right($i[$a], 1) eq "\"" && Mid($i[$a], 1,1) ne "\"")
              {
                $i[$a - 1] = $i[$a - 1] . " " . $i[$a];
                $i[$a] = "";
              }
            if (Right($i[$a], 1) eq "\"" && Mid($i[$a],1, 1) eq "\"" && length($i[$a]) > 1)
              {
                $i[$a] = "!" . Mid($i[$a], 2, length($i[$a]) - 2);
              }
          }
        
        #remove the nulls
        $b = 0;
        for $a (0..$#i)
          {
            if ($i[$a] ne "")
              {
                $j[$b] = $i[$a];
                $b = $b + 1;
              }
          }
    
        @i = @j;
      }

    #now, do the actual searching for each string
    
    #print "PRO: " . join(" ",@i)."\n";
    
    for $a (0..$#i)
      {
        if (uc($i[$a]) ne "AND" && uc($i[$a]) ne "OR" && uc($i[$a]) ne "XOR" && uc($i[$a]) ne "NOT" && uc($i[$a]) ne "TRUE" && uc($i[$a]) ne "FALSE")
          {
            $i[$a] = Mid($i[$a], 2) if Mid($i[$a], 1,1) eq "!";
            $i[$a] = lc(CBool(InStr(1, $test, $i[$a])>0))
          }
      }
    
    #we now have a boolean expression on our hands:
    #false AND true XOR false
    $query = join(" ",@i);
    #print "OUT: $query\n";
    #this is cheating, I know, but, It's quicker then parsing out the
    #proper way, so...

  while (InStr(1,$query," "))
  {
    if (InStr(1, $query, "not"))
      {
        $query = Replace($query, "not false", "true");
        $query = Replace($query, "not true", "false");
      }

    if (InStr(1, $query, "or"))
      {
        $query = Replace($query, "false or false", "false");
        $query = Replace($query, "true or false", "true");
        $query = Replace($query, "false or true", "true");
        $query = Replace($query, "true or true", "true");
      }

    if (InStr(1, $query, "xor"))
      {
        $query = Replace($query, "false xor false", "false");
        $query = Replace($query, "true xor false", "true");
        $query = Replace($query, "false xor true", "true");
        $query = Replace($query, "true xor true", "false");
      }

    if (InStr(1, $query, "and"))
      {
        $query = Replace($query, "false and false", "false");
        $query = Replace($query, "true and false", "false");
        $query = Replace($query, "false and true", "false");
        $query = Replace($query, "true and true", "true");
      }

    if (InStr(1, $query, " "))
      {
        $query = Replace($query, "true true", "true");
        $query = Replace($query, "false true", "true");
        $query = Replace($query, "true false", "true");
        $query = Replace($query, "false false", "false");
      }

    }
    #print "Back: " . CBool($query) . "\n";
    return CBool($query)
}

#I was too lazy to convert most of it, so, I just wrote some function wrappers
#for perl

sub InStr()
{
 my ($pos,$str,$sub) = @_;
 #Similar to the 'Index' command in perl.
 return index($str,$sub,$pos)+1;
}

sub InStrRev()
{
 #similar to 'rindex' perl command
 my ($str,$sub) = @_;
 $z = rindex($str,$sub)+1;
 return $z;
}

sub Mid()
{
 #returns a substring
 my ($str,$start,$len) = @_;
 return substr($str,--$start,$len) if defined($len);
 return substr($str,--$start);
}

sub Replace()
{
 #self explanatory
 my ($str,$find,$replace) = @_;
 $find = quotemeta($find);
 $replace = quotemeta($replace);
 $str =~ s/$find/$replace/gi;
 return $str;
}

sub CBool()
{
 my ($arg) = @_;
 #Convert to Boolean
 return "true" if lc($arg) eq "true";
 return "true" if $arg > 0;
 return "false";
}

sub Right()
{
 #retruns the last $len character of $str
 my ($str,$len) = @_;
 $str =~ /(.{$len})$/;
 return $1;
}
print <<EOD;

<FORM action="search.pl" method=get>
<input cols=80 name=search><input type=submit>
</FORM>

<PRE>
search function that allows for the following conventions:
 x and y : returns true when both strings x and y are in the string searched
 x or y  : returns true when either x or y, or both, are in the string searched
 not x   : returns true when x is not in the document
 x xor y : returns true when x or y is in the document, but false if they both are
 x and (y or z) : just what you'd expect
 x and y or z   : same ('or' is parsed before 'and')
 x or y or z    : matches any of the x, y, or z
 (x and y) or z : just what you'd expect
etc. (you can have nested brackets etc)

copyright Ashley Harris (ashley___harris\@hotmail.com)
You can use this module freely in your own apps/asp scripts.
so long as I get some credit somewhere, and, that I know about it!

    I mean, you can distribute this in any app you want, and make
    obscene amounts of money from it. I just, would like to know
    about it!
    
Also, if you use this, I require a vote on PSC, a preaty good deal
if you ask me. (I hide out in the perl, vb, javascript, and asp sections of the site)

Also, if you make an improvement on this script, please let me know what you did

currently, on a 300Mhz Machine, it can do one 'check' in about .25 miliseconds.
depending on the querystring.

Get in touch with me, if you want to (I don't bite):
Ashley Harris
Email:  Ashley___harris\@hotmail.com
MSN:    Ashley___harris\@hotmail.com
ICQ   : 153577070
AIM:    Ashley000Harris
Y!M   : a_s_h_l_e_y_h_a_r_r_i_s

also, check out my webserver(s) on PSC (in vb section), my mailserver on PSC (vb), and
my beginers guide to perl on PSC.

</PRE>
</BODY>
</HTML>

EOD
