Title: A Boolean Expression Parser (like search engines, nested brackets), very useful
Description: A boolean parser, like that seen in search engines. able to process expressions like:
animals and ((cats or feline) or (dogs or canine)) and "is cuddly"
Very usefull code.
(vote is appreciated)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=350&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
