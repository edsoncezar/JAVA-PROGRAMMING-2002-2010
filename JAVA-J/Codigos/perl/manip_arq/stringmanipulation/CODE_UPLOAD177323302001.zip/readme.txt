README

Binary is another word for "Base 2". Base 10 to Binary Converter converts any given Base 10 value to binary, using Perl 5's "pack" and "unpack" functions. First I pack the input into its ASCII binary value.

chomp($_ = <STDIN>);
$ascii_binary_value = pack("N",$_);

This function looks at the argument $_ and the arguement "N". $_ tells "pack" what value to pack, and "N" tells "pack" what format to pack it in. "N" tells "pack" to pack $_ into a 32-bit binary string. The problem with this is, "pack" packs $_'s ASCII value, not $_'s true base 10 value. For instance,
"36" to us represents the value 36, but to the computer it is two ASCII characters. The ASCII value of "36" is the ASCII value of "3" next to the ASCII value of "6". There are 256 (2**8) different ASCII characters, and each one is represented by an 8-bit binary octet (In binary, you need 8 possible digits inorder to represent any value from 0 to 255). So pack("N",$_) converts $_ to its ASCII binary value, which happens to be: 0011001100110110. If you divide that string into two eight bit strings and convert each one to base 10, you will see that the first eight bits represent "51", and the last eight represent "54". In ASCII, &51; is "3" and &54; is "6", &51;&54; is "36". Now I want to unpack the ASCII binary into the true binary value of 36.

$binary_value = unpack("B32",$asci_binary_value);

Or, for efficiency and less memory waste:

$binary_value = unpack("B32",pack("N",$_));

"B" tells "pack" to pack "pack("N",$_)" into a bit string with descending bit order. The "32" is essential. If that number was not there, "unpack" would unpack only the first eight bits (eight bits in ASCII is equivalent to and represents one digit or character) of "pack("N",$_)". Thus $binary_value would only be 1 digit. And since Base-10 to Binary Converter can take all values up to 4294967295 ((2**32)-1), it has to be able to convert numbers such as 4294967295 which takes up all 32 bits in binary (4294967295 base 10 = 11111111111111111111111111111111 binary). By unpacking into 32 bits, there will be leading zeros if the input is less than 2147483648 (2**31). So, for the simple sake of tidiness I wrote a little loop that chops off all leading zeros so "00000000000000000000000000001011" would become "1011".

Copyright 2001 Orhan Ayasli
Contact me at orhan99@msn.com for anything.