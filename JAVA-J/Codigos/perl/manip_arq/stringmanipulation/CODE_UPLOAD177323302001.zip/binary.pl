#!/usr/bin/perl -w
use strict;
$|++;

$_ = q/
	Base-10 to Binary Converter
	Copyright 2001 Orhan Ayasli/;
print "$_\n\n";

print "Base-10 Value: ";
while (<STDIN>) {
 print "Chomping Newline Character..";
 chomp;
 print "Done.\n";
 if ($_ > 4294967295) {
  print "Sorry! No numbers larger than 4294967295.\n\n";
 } else {
  print "Converting to Binary..";
  my $binary = unpack("B32",pack("N",$_));
  print "Done.\n";
  print "Chopping off leading zeros..";
  my @binary = split(//,$binary);
  shift(@binary) while ($binary[0] eq "0" & defined $binary[1]);
  $binary = join("",@binary);
  print "Done.\n";
  print "Binary Value: $binary\n\n";
  print "Base-10 Value: ";
 }
}