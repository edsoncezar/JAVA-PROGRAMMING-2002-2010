Title: Base 10 to Binary Converter
Description: Base 10 to Binary Converter converts any value in base 10 and returns the binary (base 2) value, without the leading zeros.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=176&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
