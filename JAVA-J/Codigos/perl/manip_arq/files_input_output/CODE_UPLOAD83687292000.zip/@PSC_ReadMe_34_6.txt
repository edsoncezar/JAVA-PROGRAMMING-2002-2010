Title: Cut a large file into smaller pieces
Description: cut-file.pl - to cut a large file into smaller pieces so that they can be copied from one computer to another piece by piece.
Run "%perl cut-file.pl -help" to find out command-line options.
To download, visit: 
http://www.perl.com/CPAN 
or 
http://www.freshmeat.net
or
http://belmont-shores.ics.uci.edu
$Date: 2000/04/26 17:20:10 $ by Chang Liu (liu@ics.uci.edu | changliu@acm.org)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
