Title: Phonebook
Description: This is a great program to help anyone new to working with files how to do it in perl. There is also an example of regexp type expression that serves as a practical example as to how you would use it.
The code is thoroughly commented
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=327&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
