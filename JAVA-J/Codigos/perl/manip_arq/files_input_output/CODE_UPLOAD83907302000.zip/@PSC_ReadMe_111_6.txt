Title: Mp3 Lister
Description: This lists all your mp3's in the given directory in a nice HTML table. The Band is in bold and under it is the Song name. Just change the directory variable and you're ready to go. You can also customize the look and feel of the page very easily. Checkout a demo at http://www.lolindrath.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=111&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
