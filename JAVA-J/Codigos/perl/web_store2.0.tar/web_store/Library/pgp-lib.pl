############################################################
#                       PGP-LIB.PL
#
# Summary: PGP stands for Pretty Good Privacy and it
#  is a utility on the internet that allows you to encrypt
#  and decrypt files.  This library interfaces with this
#  3rd party encryption program
#
# This script was written by Gunther Birznieks.
# Date Created: 11-5-96
# Date Last Modified: 11-25-96
#
# Copyright:
#
#     You may use this code according to the terms specified in
#     the "Artistic License" included with this distribution.  The license
#     can be found in the "Documentation" subdirectory as a file named
#     README.LICENSE. If for some reason the license is not included, you
#     may also find it at www.extropia.com.
#
#     Though you are not obligated to do so, please let us know if you
#     have successfully installed this application.  Not only do we
#     appreciate seeing the wonderful things you've done with it, but we
#     will then be able to contact you in the case of bug reports or
#     security announcements.  To register yourself, simply send an
#     email to register@extropia.com.
#
#    Finally, if you have done some cool modifications to the scripts,
#    please consider submitting your code back to the public domain and
#    getting some community recognition by submitting your modifications
#    to the Extropia Cool Hacks page.  To do so, send email to
#    hacks@extropia.com
#
# Purpose: Provides a set of library routines to interface with
#   PGP to create an encrypted buffer
#
# MAIN PROCEDURE:
#  make_pgp_file - makes a PGP encrypted file and sends its
#                  contents back to the user
#
# Special Notes: Script ties into the PGP executable whose
#  location is specified in the variables below.
# 
# VARIABLES:
#  $pgp_path = path to PGP executable
#  $pgp_options = command line options to the PGP program
#  $pgp_public_key_user_id = which key to use for encrypting
#  $pgp_config_files = path where configuration files are located 
#
############################################################



$pgp_path = "/home/gunther/pgp/pgp";



# Command line options are the following:

#  f for accepting file input and output to PGP

#  e for encrypting

#  a for outputting as RADIX-64 ASCII instead of binary

#  t for text files (cross platform text file conversion

#  +VERBOSE=0 lowers verbosity level so only severe errors

#   print out

#

$pgp_options = "-feat +VERBOSE=0";

$pgp_public_key_user_id = "gunther";

#$pgp_config_files = "/home/selena/public_html/Mis/Test_store/Pgpfiles";

$pgp_config_files = "./Pgpfiles";



############################################################

#

# subroutine: make_pgp_file

#   Usage:

#     &make_pgp_file($output_text, $output_file);

# 

#   Parameters:

#     $output_text = unencrypted text that you want to scramble

#     $output_file = name of a file that you will use to

#                    temporarily create the encryption. It

#                    will be removed after it is created

#                    and its contents are assigned to a buffer.

#

#   Output:

#     $pgp_output = the encrypted text that was stored in

#          the $output_file results of running PGP

############################################################



sub make_pgp_file {

  local($output_text, $output_file) = @_;  

  local($pgp_output);



# Set the PGPPATH environment to tell

# PGP *not* to go to the Web Server User's

# home directory by default to look for key

# files and public keys

#

  $ENV{"PGPPATH"} = $pgp_config_files;



# Generate the command that needs to be used

# to execute PGP. This consists of the PGP 

# executable followed by command line options

# which is followed by the user id which you

# want to use a public key for and then output

# the encrypted results to an output file.

#

  $pgp_command =  "$pgp_path $pgp_options ";

  $pgp_command .= "$pgp_public_key_user_id ";

  $pgp_command .= ">$output_file";



# The command is opened using the special

# file open PIPE command which EXECUTES the

# command and then allows PERL to print to

# it as input for the command.

#

# The path manipulation is to satisfy taint mode

# 

 

    local($old_path) = $ENV{"PATH"};

    $ENV{"PATH"} = "";



    open (PGPCOMMAND, "|$pgp_command");

 

    $ENV{"PATH"} = $old_path;



# The text you want to encrypt is sent to

# the command.

  print PGPCOMMAND $output_text;



  close (PGPCOMMAND);



# The resulting output file is opened,

# read into $pgp_output and closed.

#

  open(PGPOUTPUT, $output_file);



  while (<PGPOUTPUT>) {

    $pgp_output .= $_;

  } 

  close (PGPOUTPUT);



# we remove the temporary file

  unlink($output_file);



# we return PGP output

  return($pgp_output);



} # End of make_pgp_file



# We always return TRUE from requiring

# a library file (1;)

1;

