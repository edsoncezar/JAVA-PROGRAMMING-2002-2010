#!/usr/bin/perl
# 
# ezwbgen.$cgi - EZ WWWBoard Generator - by Manny Juan <manny@jps.net> 4/3/99
# http://www.inet-images.com/manny/$userdir/
#
# this program was adapted from ezhomepg by manny juan
#
# This will give your visitors the opportunity to set up a wwwboard message board
# at your site. the generated board page uses ezwboard.$cgi, modified version of
# matt wright's wwwboard.pl script and ezwadmin.$cgi, modified version of wwwadmin.pl
# for maintaining the board
#
#####################################################################################
$cgi="pl";
$SIG{__DIE__} = \&Error_Msg;

sub Error_Msg {
    $msg = "@_";
    print "\nContent-type: text/html\n\n";
    print "The following error occurred : $msg\n";
    exit;
}

# Get the input
read(STDIN, $input, $ENV{'CONTENT_LENGTH'});

    # split the input
    @pairs = split(/&/, $input);

    # split the name/value pairs
    foreach $pair (@pairs) {

    ($name, $value) = split(/=/, $pair);

    $name =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/<([^>]|\n)*>//g;
    $FORM{$name} = $value;
    }
$userdir = $FORM{'userdir'};
$userdir=~s/\W//g;

$win95=0;
######################################################################################
# DO NOT CHANGE ANYTHING ABOVE THIS LINE
# set variables HERE

# site message limit - msg board owners may not set their msg board message limit over this value
$gmax=200; 

# Set this to your base HTML directory. This is a PATH not a URL
$base_dir = "/home/htdocs/your.isp.com/website/$userdir";

$cgiurl = "http://www.isp.com/website/cgi-bin";

# This is your URL of where the new HTML pages will be kept - keep the trailing slash
$baseurl = "http://www.isp.com/website/$userdir/";

# This is a URL and dir for the images sub directory in the userpages directory.
# Create the images directory in the userpages directory.
$imageurl = $baseurl;

# This is the path for user pages. You don't really need to change this
# Just make sure to create a directory: userpages and chmod it 777
$page_dir = "$base_dir/";

# This is the index list of all generated message boards
$indexpage = "/home/htdocs/your.isp.com/website/$userdir/index.html";

# This is the location of the data.txt file. This holds each user's
# login name and e-mail address for confirmation
$users = "$base_dir/users.txt";

# This is the location of the data.txt file. This holds each user's
# login name and e-mail address for confirmation
$lastmsg = "data.txt";

# This is the location of the faq file
$faqfile = "$baseurl" . "faq.html";

#Site title

$title="EZ Message Board Mall";

# self explanatory variables for your site logo
$logo = "$imageurl/mjmall.jpg";
$logoalt = "Cyber Mall";

# Location of the sendmail program
$sendmail = '/usr/sbin/sendmail';

# webmaster e-mail address
$myemail = 'email@isp.com';
# That's it.

# DO NOT CHANGE ANYTHING BELOW THIS LINE
######################################################################################

# Lets do some translating first
$usrname = $FORM{'usrname'};
$login = $FORM{'login'};
$email = $FORM{'email'};
$pagename = $FORM{'pagename'};
$updact = $FORM{'updact'};
$sitename=$FORM{'sitename'};
$adminpwd=$FORM{'adminpwd'};
$subject_line=$FORM{'subject_line'};
$show_faq=$FORM{'show_faq'};
$allow_HTML=$FORM{'allow_HTML'};
$use_time=$FORM{'use_time'};
$maxmsgs= $FORM{'maxmsgs'};
$flock=$FORM{'flock'};
$colorset=$FORM{'colorset'};
$retlink=$FORM{'retlink'};

$pagename=~s/\W//g;
$adminpwd=~s/\W//g;

# If the user tries to add more than one word in
# the page name field, this will put an underscore
# in the spaces to make it one word
$pagename =~ s/ /_/g;

if ($FORM{'action'} eq "New Page") {
    &newpage;
    }
if ($FORM{'action'} eq "Create Page") {
    &create;
    }
if ($FORM{'action'} eq "Edit Page") {
    &confirm("edit");
    }
if ($FORM{'action'} eq "checkuser") {
    &checkuser;
    }
if ($FORM{'action'} eq "recreate") {
    &recreate;
    }
if ($FORM{'action'} eq "Delete Page") {
    &confirm("delete");
    }
    exit;

sub newpage {
    local($usrname, $email, $sitename,  $pagename, $colorset, $subject_line, $show_faq, $allow_HTML, $use_time, $maxmsgs);

    ($usrname, $email, $sitename,  $pagename, $colorset, $subject_line, $show_faq, $allow_HTML, $use_time, $maxmsgs) = split(/&&/, "");

    $adminpwd="";
    $subject_line="0";
    $show_faq="1";
    $allow_HTML="1";
    $use_time="1";
    $maxmsgs="$gmax";
    $retlink="http://";
    
    # To avoid any security risks. Take out the HTML tags added when HPM translated
    # the && to: <br><br>. They will be re-translated to: && Once the user updates
    # the page, the: && will be put back to: <br><br>

    # print the edit-page form

    print "content-type: text/html\n\n";
    print "<html><head><title>Create Your Own Message Board</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<p><font face=\"Arial, Geneva\"><h2>Create Your Own Message Board</h2></font></p>\n";
    print "<p>Below is an empty form for you to fill in. The next five fields (<b>bold</b>) are required.\n";
    print "You can edit any part of your page later</p>\n";
    print "<p></p>\n";
    print "<form action=\"$cgiurl/ezwbgen.$cgi\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<input type=hidden name=\"action\" value=\"Create Page\">\n";
    print "<b>Your name:</b>";
    print "<font size=\"-1\">(will appear in page as link to your email)</font><br>\n";
    print "<input type=text size=40 name=\"usrname\" value=\"$usrname\"><br><br>\n";
    print "<h3>(The next 4 fields will be used for editing - REMEMBER THEM!)</h3>\n";
    print "<b>Login Id:</b>\n";
    print "<font size=\"-1\">(one word only you should know, used later for editing)</font><br>\n";
    print "<input type=text size=40 name=\"login\" value=\"$login\"><br><br>\n";
    print "<b>Your e-mail:</b>\n";
    print "<font size=\"-1\">(used for editing, will also appear in page)</font><br>\n";
    print "<input type=text size=40 name=\"email\" value=\"$email\"><br><br>\n";
    print "<b>Your page:</b>\n";
    print "<font size=\"-1\">(one word, will become the name of your message board)</font><br>\n";
    print "<input type=text size=40 name=\"pagename\" value=\"$pagename\"><br><br>\n";
    print "<b>Admin Password:</b>";
    print "<font size=\"-1\">(enter a one-word administrator's password)</font>";
    print "<br><input type=text size=20 name=\"adminpwd\" value=\"$adminpwd\"><br><br>\n";
    print "<br><br><b>Message Board Title:</b>\n";
    print "<font size=\"-1\">(title of message board - will also be listed in index)</font><br>\n";
    print "<input type=text size=40 name=\"sitename\" value=\"$sitename\"><br><br>\n";

    print "<b>Select Preset Colors:</b>";
    print "<SELECT NAME=\"colorset\">";
    &put_clropt($colorset,'01','FFFFFF~333333~006699~999900');
    &put_clropt($colorset,'02','CCCCCC~000000~0000CC~660066');
    &put_clropt($colorset,'03','FFFF00~FF6600~FF0033~336633');
    &put_clropt($colorset,'04','CCCC66~330000~CC0000~003300');
    &put_clropt($colorset,'05','FFFF99~330000~CC0000~333333');
    &put_clropt($colorset,'06','99CCCC~000066~0000CC~003366');
    &put_clropt($colorset,'07','CC99FF~000000~FF0033~660066');
    &put_clropt($colorset,'08','CCFF99~666600~006699~003300');
    &put_clropt($colorset,'09','FFCC00~330000~CC0000~660066');
    &put_clropt($colorset,'10','00FF33~0000CC~FF0099~660066');
    &put_clropt($colorset,'11','006699~CCFFCC~FFFF00~00FFFF');
    &put_clropt($colorset,'12','330000~FF6666~FFCC00~CCFF99');
    &put_clropt($colorset,'13','003300~CCCC66~FFFFFF~FFFF00');
    &put_clropt($colorset,'14','333333~CCCCCC~FF6666~CCCC66');
    &put_clropt($colorset,'15','666600~FFFFFF~FFFF00~99CCFF');
    &put_clropt($colorset,'16','000000~99CCFF~FFFF00~CCCC66');
    &put_clropt($colorset,'17','333333~FFFFFF~99CCFF~CC99FF');
    &put_clropt($colorset,'18','CC0000~FFFFFF~FFFF00~00FFFF');
    print "\n</SELECT>";
    print "<br><img src=\"$baseurl" . "ezpalette.gif\">\n";

    &build_form_content($usrname, $retlink, $email, $sitename, $pagename, $subject_line, $show_faq, $allow_HTML, $use_time, $maxmsgs);
    print "<P><input type=submit value=\"create page\">\n";
    print "</form>\n";
    print "</body></html>\n";
    }

sub create {

    # Now, lets do some error checking. Making sure they filled out each field
    &missing(missing_name) unless $usrname;
    &missing(missing_email) unless $email;
    &missing(missing_pagename) unless $pagename;

    &chk_bad_email;
    &chk_bad_maxmsgs;
    &chk_bad_retlink;

    # if they try to name their page "index" This will stop them
    if (uc($pagename) eq "INDEX") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
        print "<p>You cannot name your page <b>index</b>\n";
        print "Please go back and re-name your page</p>\n";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        exit;
        }
    # if they Don't give their page a sitename This will stop them
    if ($sitename eq "") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<p>You MUST give your page a <b>message board title</b>\n";
        print "Please go back and enter one for your page</p>\n";
        exit;
        }

    # if the user tries to name their page 
    # something that is already taken
    # this should stop them - it's a check for directory-present
    if (-d "$base_dir/$pagename") {
        print "content-type: text/html\n\n";
        print "<html><head><title>Error</title></head>\n";
        print "<body>";
        &put_banner;
        print "<p>The page name: <b>$pagename</b>\n";
        print "is already taken.\n";
        print "Please go back and rename your page</p>\n";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        exit;
        }

    # create the new directory for pagename
    umask(000);  # UNIX file permission junk
    mkdir("$base_dir/$pagename", 0777) unless (-d "$base_dir/$pagename");     

    # create the new directory for the messages of pagename
    umask(000);  # UNIX file permission junk
    mkdir("$base_dir/$pagename/messages", 0777) unless (-d "$base_dir/$pagename/messages");     

    # create the config file
    open (CFGFILE,">$base_dir/$pagename/mymsgbd.cfg")||die "i can't open >$base_dir/$pagename/mymsgbd.cfg";
    print CFGFILE "$usrname&&$retlink&&$sitename&&$colorset&&$subject_line&&$show_faq&&$allow_HTML&&$use_time&&$maxmsgs";
    close(CFGFILE);

    # create the last message file
    open (MSGNFILE,">$base_dir/$pagename/$lastmsg")||die "i can't open >$base_dir/$pagename/$lastmsg";
    print MSGNFILE "0";
    close(MSGNFILE);

    # get the colors from colorset
    ($bkgdc, $textc, $linkc, $vlinkc) = split('~', $colorset);

    # create the index file for the board
    open (IDXFILE,">$base_dir/$pagename/index.html")||die "i can't open >$base_dir/$pagename/index.html";
    print IDXFILE <<EOHTML;
<html><head><title>
EZWBoard Version 2.0!
</title></head>
<body bgcolor="#$bkgdc" TEXT="#$textc" link="#$linkc" vlink="#$vlinkc"><center>
<h1>$sitename</h1>
</center>
Below is EZWBoard Version 2.0 ALPHA 1.
<p><hr size=7 width=75%>
<center>[ <a href="#post">Post Message</a> ] [ <a href="$faqfile">FAQ</a> ]</center> <hr size=7 width=75%>
<ul>
<!--begin-->

<a name="post"><center><h2>Post A Message!</h2></center></a>
<form method=POST action="$cgiurl/ezwboard.pl">
<input type=hidden name="userdir" value="$userdir">
<input type=hidden name="forum" value="$pagename">
Name: <input type=text name="name" size=50><br>
E-Mail: <input type=text name="email" size=50><p>

Subject: <input type=text name="subject" size=50><p>
Message:<br>
<textarea COLS=55 ROWS=10 name="body"></textarea><p>
Optional Link URL: <input type=text name="url" size=45><br>
Link Title: <input type=text name="url_title" size=50><br>
Optional Image URL: <input type=text name="img" size=45><p>
<input type=submit value="Post Message"> <input type=reset>
</form><p>
Scripts and EZWBoard created by Matt Wright and can be found at <a href="http://worldwidemart.com/scripts/">Matt's Script Archive</a> 
</ul>
<hr><center><a href="$retlink">Return</a>
<br><a href="$baseurl">Get Your Own EZWBoard</a>
<br><a href="mailto:$email">$usrname</a>
<br><font size="-1">this EZWBoard was generated by <b>ezwbgen.pl</b> script found at <a href="http://www.inet-images.com/manny">manny juan's script page</a></font></center>
</body></html>
EOHTML
    close(IDXFILE);

    # Write the login name and email address to a separate file for confirmation
    # when they want to edit their page
    open (FILE, ">>$users") || die "I can't open >>$users\n";
    if($win95==0){flock (FILE, 2) or die "can't lock data file\n";}
    $cryptpwd=crypt($adminpwd,substr($adminpwd,0,2));
    print FILE "$login&&$email&&$pagename&&$cryptpwd\n";
    close(FILE);

    # Suck the index page, and write the new entry to it
    open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
    @lines = <FILE>;
    close(FILE);
    $sizelines = @lines;

    # Now, re-open the links file, and add the new link
    open(FILE, ">$indexpage") || die "I can't open that file >$indexpage\n";
    if($win95==0){flock (FILE, 2) or die "can't lock index file\n";}

    for ($a = 0; $a <= $sizelines; $a++) {

        $_ = $lines[$a];

        if (/<!--sitename-->/) {
            print FILE "<!--sitename--><h1>$sitename</h1>\n";
            }
        elsif (/<!--begin-->/) {
            print FILE "<!--begin-->\n";
            print FILE "<p><font face=\"Arial, Geneva\" size=4><a href=\"$baseurl$pagename\">$sitename</a></font></p>\n";

        } else {
            print FILE $_;
            }
        }
    close(FILE);


    # Give the user a response
    print "content-type: text/html\n\n";
    print "<html><head><title>thanks</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<BR><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";

    print "Your message board has been created, and you will receive an e-mail confirming this!\n";
    print "You can visit your message board by clicking ";
    print "<a href=\"$baseurl$pagename\">here</a>\n";
    print "  The index page has been updated with this link.\n";
    print "Thanks for your participation!\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";


    # Send the user an e-mail confirming their page
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $usrname <$email>\n";
    print MAIL "From: $myemail\n";
    print MAIL "Subject: Your new URL on the $title\n";
    print MAIL "Your page can be viewed at the URL below:\n";
    print MAIL "\n";
    print MAIL "$baseurl$pagename\n";
    print MAIL "\nThank you for using the $title\n";
    print MAIL "\n\nThe Mall Manager - $myemail\n";
    close (MAIL);

    # Notify us when someone creates a page
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $myemail\n";
    print MAIL "From: $usrname <$email>\n";
    print MAIL "Subject: $title New Page Report\n";
    print MAIL "$usrname created a new page:\n";
    print MAIL "$baseurl$pagename\n";
    close(MAIL);

    }

sub recreate {
    &missing(missing_name) unless $usrname;
    &missing(missing_email) unless $email;
    &chk_bad_email;
    &chk_bad_maxmsgs;
    &chk_bad_retlink;

    # Suck the index page, and update site name (in case it changed)
    open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and replace the index entry
    open(FILE, ">$indexpage") || die "I can't open that file >$indexpage\n";
    if($win95==0){flock (FILE, 2) or die "can't lock index file to delete entry\n";}

            for ($a = 0; $a <= $sizelines; $a++) {

            $_ = $lines[$a];

        if (/$pagename\b/) {
            print FILE "<p><font face=\"Arial, Geneva\" size=4><a href=\"$baseurl$pagename\">$sitename</a></font></p>\n";
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);

    # recreate the config file
    open (CFGFILE,">$base_dir/$pagename/mymsgbd.cfg")||die "i can't open >$base_dir/$pagename/mymsgbd.cfg";
    print CFGFILE "$usrname&&$retlink&&$sitename&&$colorset&&$subject_line&&$show_faq&&$allow_HTML&&$use_time&&$maxmsgs";
    close(CFGFILE);

    &ntfy_usr_edt;

    # Give the user a response
    print "content-type: text/html\n\n";
    print "<html><head><title>thanks</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";
    &put_banner;
    print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\" border=0></CENTER>\n";
    print "<P><BR><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "Your message board has been revised, and you will receive an e-mail confirming this!\n";
    print "You may visit your message board by clicking ";
    print "<a href=\"$baseurl$pagename\">here</a>.\n";
    print "Thanks for your participation!\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";
    }

sub ntfy_usr_edt {
    # Send the user a notice that their page has been re-done
    open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
    print MAIL "To: $usrname <$email>\n";
    print MAIL "From: $myemail\n";
    print MAIL "Subject: Your Changes on the $title\n";
    print MAIL "Your revised page can be viewed at the URL below:\n";
    print MAIL "\n";
    print MAIL "$baseurl$pagename\n";
    print MAIL "\nOnce again thank you for using the $title\n";
    print MAIL "\n\nThe Mall Manager\n";
    close (MAIL);
    }

sub chk_bad_maxmsgs {
    if ($maxmsgs !~ /^(\d){1,3}$/) {
        &input_error("invalid or unreasonable value for max messages (enter 1 to $gmax)");
        exit;
        }
    if (($maxmsgs > $gmax) || ($maxmsgs < 1)) {
        &input_error("invalid or unreasonable value for max messages (enter 1 to $gmax)");
        exit;
        }
    }
sub chk_bad_email {
    if (($email ne "") && ($email !~ /^\w+(\.)*\w+\@(\w|\-)+\.\w+/)) {
        &input_error("invalid email format");
        exit;
        }
    }
sub chk_bad_retlink {
    if (($retlink ne "") && ($retlink ne "http://") && ($retlink !~ /^http:\/\/(\w|\-)+\.\w+/)) {
        &input_error("invalid return link format - URL does not start with http://");
        exit;
        }
    }
sub input_error {
    local ($errmsg) = @_;
    print "content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
    print "<body>";
    &put_banner;
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<h1>Input Error!</h1><h3>$errmsg</h3>\n";
    print "<p>Please go back and correct</p>\n";
    }

# Standard error message for any missing required fields
sub missing {
    local ($missing) = @_;
    print "content-type: text/html\n\n";

    print "<HTML><head><TITLE>You missed something</TITLE></head>\n";
    print "<body>\n";
    &put_banner;    
    print "You forgot to fill in one of the fields. Please go back and make\n";
    print "sure that all required fields are filled in! $missing\n";
    print "</body></HTML>\n";
    exit;
    }

sub confirm {
    local ($updact) = @_;

    print "content-type: text/html\n\n";
    print "<html><head><title>$updact Confirmation</title></head>\n";
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\" >\n";
    &put_banner; 
    print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\"  border=0></CENTER>\n";
    print "<P><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "<p><h3>Please Enter your login name, e-mail and name of your file to $updact\n";
    print "<br>and the administrator's password</h3>";
    print "<form action=\"$cgiurl/ezwbgen.$cgi\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<P><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
    print "Login name:<br>\n";
    print "<input size=40 type=text name=\"login\"><br>\n";
    print "E-mail:<br>\n";
    print "<input size=40 type=text name=\"email\"><br>\n";
    print "Name of your file:<br>\n";
    print "<input type=text size=40 name=\"pagename\"><br>\n";
    print "Admin Password:<br>\n";
    print "<input type=password size=40 name=\"adminpwd\"><br><br>\n";
    print "<input type=submit value=submit>\n";
    print "<input type=hidden name=\"action\" value=\"checkuser\">\n";
    print "<input type=hidden name=\"updact\" value=\"$updact\">\n";
    print "</FONT>\n";
    print "</form></body></html>\n";
    }

sub checkuser {
    open(FILE, "$users") || die "I can't open $users\n";  
    if($win95==0){flock (FILE, 1) or die "can't lock users file\n";}
    while(<FILE>) {
    chop;       
    @all = split(/\n/);

    foreach $line (@all) {
    ($loginname, $loginemail, $loginpagename, $logincrypt) = split(/&&/, $line);
    if($loginname eq "$login" && $loginemail eq "$email" 
    && $loginpagename eq "$pagename" && crypt($adminpwd,substr($logincrypt,0,2)) eq $logincrypt) {
        $match = 1;
        if($updact eq "edit") {
          &edit($loginpagename);
          }
        else {
          &delpage($loginpagename);
          }
        }
      }
    }

    close(FILE);

    if (! $match) {
        &error;
        }

    # del entry from data
    if($updact eq "delete") {

        # Suck the index page, and update it
        open(FILE, "$users") || die "I can't open that file $users\n";
        if($win95==0){flock (FILE, 1) or die "can't lock data file\n";}
            @lines = <FILE>;
            close(FILE);
            $sizelines = @lines;

        # Now, re-open the links file, and comment out the page to delete
        open(FILE, ">$users") || die "I can't open that file >$users\n";
        if($win95==0){flock (FILE,2) or die "can't lock index file for append\n";}
        chop;
            for ($a = 0; $a <= $sizelines; $a++) {
            $_ = $lines[$a];
            $w = $_;
            $w =~ s/\cM//g;
            $w =~ s/\n//g;
            ($loginname, $loginemail, $loginpagename, $logincrypt) = split(/&&/, $line);
            if($loginname eq "$login" && $loginemail eq "$email" 
            && $loginpagename eq "$pagename" && crypt($adminpwd,substr($logincrypt,0,2)) eq $logincrypt) {
              # do nothing  (ie. don't write)
              } 
            else {
              if($w eq "") {
                # do nothing (skip)
                }
              else {
                print FILE "$w\n";
                }
              }
            }
        close(FILE);
        print "content-type: text/html\n\n";
        print "<html><head><title>$updact Confirmation</title></head>\n";
        print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\" >\n";
        &put_banner; 
        print "<CENTER><IMG SRC=\"$logo\" alt=\"$logoalt\" border=0></CENTER>\n";
        print "<P><BR><FONT SIZE=4 FACE=\"COMIC SANS MS,ARIAL\">\n";
        print "<p>your page has been deleted";
        print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
        print "</form></body></html>\n";
      }
    }

sub edit {
    local ($pagename) = @_;
    # get the config file
    open(CFGFILE, "$base_dir/$pagename/mymsgbd.cfg") || die "I can't open $base_dir/$pagename/mymsgbd.cfg\n";
    if($win95==0){flock (CFGFILE, 1) or die "can't lock data file for edit\n";}
    $txrec=<CFGFILE>;
    &build_edit_form($txrec);
    close(CFGFILE);
    }

sub delpage {
    local ($pagename) = @_;
    &deltree(0,"$base_dir/$pagename");

    # Suck the index page, and store entries in array
    open(FILE, "$indexpage") || die "I can't open that file $indexpage\n";
    if($win95==0){flock (FILE, 1) or die "can't lock index file\n";}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, recreate the page but do not write the deleted page
    open(FILE, ">$indexpage") || die "I can't open that file >$indexpage\n";
    if($win95==0){flock (FILE, 2) or die "can't lock index file to delete entry\n";}
        for ($a = 0; $a <= $sizelines; $a++) {
        $_ = $lines[$a];
        if (/$pagename\b/) {
          # do nothing  (ie. don't write)
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);

    # Suck the users page, and store entries in array
    open(FILE, "$users") || die "I can't open that file $users\n";
    if($win95==0){flock (FILE, 1) or die "can't lock users file\n";}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, recreate the page but do not write the deleted page
    open(FILE, ">$users") || die "I can't open that file >$users\n";
    if($win95==0){flock (FILE, 2) or die "can't lock users file to delete entry\n";}
        for ($a = 0; $a <= $sizelines; $a++) {
        $_ = $lines[$a];
        if (/$pagename\b/) {
          # do nothing  (ie. don't write)
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);
    }

sub deltree {
    local ($lvl, $dir) = @_;
    local @tnlist;
    opendir (TN, "$dir");
    rewinddir (TN);
    @tnlist =  grep(!/^\.\.?$/, readdir (TN));
    closedir (TN);
    foreach $tn (@tnlist) {
        if (-d "$dir/$tn") {
            $lvl++;
            &deltree($lvl,"$dir/$tn" );
            $lvl--;
            }
        else {
            $cnt=unlink("$dir/$tn");
#            print "<br>deleting $dir/$tn";
            }
        }
    rmdir ("$dir");
#    print "<br>removing $dir";
    }

sub build_edit_form {
    local ($line) = @_;
    ($usrname,$retlink,$sitename,$colorset,$subject_line,$show_faq,$allow_HTML,$use_time,$maxmsgs)=split(/&&/,$line);

    # To avoid any security risks. Take out the HTML tags added when HPM translated
    # the && to: <br><br>. They will be re-translated to: && Once the user updates
    # the page, the: && will be put back to: <br><br>

    # print the edit-page form

    print "content-type: text/html\n\n";
    print "<html><head><title>Edit Your Page</title></head>\n"; 
    print "<body bgcolor=\"#ffffff\" TEXT=\"#000000\" link=\"#008000\" vlink=\"#800040\">\n";

    &put_banner; 
    print "<center><img src=\"$logo\" alt=\"$logoalt\" border=0></center><p>\n";
    print "<table width=75% cellspacing=2 cellpadding=2 border=0>\n";
    print "<tr><td width=100% align=left valign=top>\n";
    print "<p><font face=\"Arial, Geneva\"><h2>Edit Your Page</h2></font></p>\n";
    print "<p>Below is a form with the contents\n";
    print "of the message board you created. You can edit any part of your board</p>\n";
    print "<p></p>\n";
    print "<form action=\"$cgiurl/ezwbgen.$cgi\" method=POST>\n";
    print "<input type=hidden name=\"userdir\" value=\"$userdir\">\n";
    print "<input type=hidden name=\"action\" value=\"recreate\">\n";
    print "Your name:<br>\n";
    print "<input type=text size=40 name=\"usrname\" value=\"$usrname\"><br><br>\n";
    print "Your e-mail:<br>\n";
    print "<input type=text size=40 name=\"email\" value=\"$email\"><br><br>\n";
    print "</td></tr></table>\n";
    print "Title of Message Board: <b>$sitename</b><br><br>\n";
    print "<input type=hidden name=\"sitename\" value=\"$sitename\">\n";
    print "Name of Message Board: <b>$pagename</b><br><br>\n";
    print "<input type=hidden name=\"pagename\" value=\"$pagename\">\n";

    ($bkgdc, $textc, $linkc, $vlinkc) = split('~', $colorset);
    print "<table><tr><td valign=top><b>Color Scheme Selected:</b><td bgcolor=$bkgdc>";
    print "<font color=$textc>text</font>";
    print "<br><font color=$linkc><u>links</u></font>";
    print "<br><font color=$vlinkc><u>visited</u></font></td></tr></table>";
    print "<input type=hidden name=\"colorset\" value=\"$colorset\">\n";

    &build_form_content($usrname, $retlink, $email, $sitename, $pagename, $subject_line, $show_faq, $allow_HTML, $use_time, $maxmsgs);
    print "<P><input type=submit name=\"selection\" value=\"update page\">\n";
    print "<hr><font face=\"Arial, Geneva\"><h2>Manage Your Board</h2></font></p>\n";
    print "<b>Message Board Administration</b>";
    print "<br>To perform administration tasks, click&nbsp;";
    print "<a href=\"$cgiurl/ezwadmin.$cgi?userdir=$userdir&forum=$pagename\">here</a>";
    print "</form>\n";
    print "</body></html>\n";
    }

sub build_form_content {
    local ($usrname, $retlink, $email, $sitename, $pagename, $subject_line, $show_faq, $allow_HTML, $use_time, $maxmsgs)=@_;

    print "<br><br><b>Subject Quoting Options:</b>&nbsp;options for posting follow-up's";
    print "<br><SELECT NAME=\"subject_line\">";
    &put_opt($subject_line,'Quote the subject, make it editable','0');
    &put_opt($subject_line,'Quote the subject, do NOT make it editable','1');
    &put_opt($subject_line,'Do NOT quote the subject but make it editable','2');
    print "\n</SELECT>";
    print "<br><br><b>Show FAQ:</b><br>";
    &prt_ckb($show_faq, 'show_faq', 'allow users to browse the FAQ');
    print "<br><br><b>Allow HTML:</b><br>";
    &prt_ckb($allow_HTML, 'allow_HTML', 'allow users to enter HTML in message body');
    print "<br><br><b>Time Stamp:</b><br>";
    &prt_ckb($use_time, 'use_time', 'also mark each entry with time-stamp in addition to date-stamp');
    print "<br><br><b>Max Messages:</b>&nbsp;&nbsp;number of messages to keep on the board at all times<br>\n";
    print "<input type=text size=5 name=\"maxmsgs\" value=\"$maxmsgs\">";
    print "&nbsp;&nbsp;(eg. if next msg no. is 234 and max messages is 10, msg no. 224 will be deleted)<br><br>\n";

    print "\n<br><br><b>Return Link (URL):</b>link here when user clicks Return<br>\n";
    print "<input type=text size=50 name=\"retlink\" value=\"$retlink\"><br><br>\n";
    }

sub prt_ckb {
    local ($var, $varname, $ckbdesc) = @_;
    print "\n<INPUT TYPE=\"CHECKBOX\" NAME=\"$varname\" VALUE=\"1\"";
    if ($var eq "1") {print " CHECKED";} 
    print ">&nbsp;$ckbdesc";
    }

sub put_clropt  {
    local ($colorset, $id, $colors)=@_;
    print "\n<OPTION VALUE=\"$colors\"";
    if ($colorset eq $colors) {print " SELECTED";}
    print ">$id";
    }

sub put_opt  {
    local ($inval, $id, $val)=@_;
    print "\n<OPTION VALUE=\"$val\"";
    if ($inval eq $val) {print " SELECTED";}
    print ">$id";
    }

sub error {
    local ($updact) = @_;
    print "content-type: text/html\n\n";
    print "<html><head><title>Permission Denied</title></head>\n";
    print "<body>\n";
    &put_banner; 
    print "<p><h1>Permission Denied</h1></p>\n";
    print "You do not have permission to $updact\n";
    print "<p>(Return to <a href=\"$baseurl\">User Pages</a>)\n";
    print "</body></html>\n";
    exit;
    }
sub put_banner {
    # do nothing
    }
