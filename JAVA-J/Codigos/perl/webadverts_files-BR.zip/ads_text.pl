############################################
##                                        ##
##       WebAdverts  (Text Strings)       ##
##           by Darryl Burgdorf           ##
##       (e-mail burgdorf@awsd.com)       ##
##                                        ##
##             version:  3.20             ##
##        last modified:  09/08/02        ##
##           copyright (c) 2002           ##
##                                        ##
##    latest version is available from    ##
##        http://awsd.com/scripts/        ##
##                                        ##
############################################

# Portugese Translation by:
# David Almeida (admin@lusobanner.com)

##################
# INITIAL ACCESS #
##################

$text{'1000'} = "WebAdverts";
$text{'1001'} = "Administra��o de Contas";

$text{'1010'} = "Para ver o estado de uma conta ou de um grupo,<BR>introduza o nome e a password:";
$text{'1011'} = "Nome da conta ou do grupo:";
$text{'1012'} = "Password:";
$text{'1013'} = "Rever uma conta ou um grupo";

$text{'1020'} = "Para adicionar o seu site � lusobanner,<BR>introduza o nome e a password que deseja:";
$text{'1021'} = "Nome da Conta:";
$text{'1022'} = "Password:";
$text{'1023'} = "Criar uma nova conta";

$text{'1030'} = "Se se esqueceu da password,<BR>introduza o noma da conta, e a password ser-lhe-� enviada por e-mail:";
$text{'1031'} = "Nome da Conta:";
$text{'1032'} = "Enviar Password";

$text{'1040'} = "Para ver o estado de todas as contas da lusobanner,<BR>introduza a password de administrador:";
$text{'1041'} = "Password:";
$text{'1042'} = "Rever Contas";

$text{'1050'} = "A password para";
$text{'1051'} = "A informa��o da sua conta foi enviada para o e-mail associado!";

################
# MAIN DISPLAY #
################

@months = ('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez');

$text{'2000'} = "(Contas no";
$text{'2001'} = "Grupo)";
$text{'2002'} = "Vista Geral:";

$text{'2005'} = "Estat�sticas da";
$text{'2006'} = "Conta:";
$text{'2007'} = "(A sua conta aguarda aprova��o administrativa.)";

$text{'2010'} = "Conta";
$text{'2011'} = "In�cio";
$text{'2012'} = "Fim";
$text{'2013'} = "Zona(s)";
$text{'2014'} = "Peso";
$text{'2015'} = "Exposi��es";
$text{'2016'} = "Exp./Dia";
$text{'2017'} = "Cliques";
$text{'2018'} = "%";
$text{'2019'} = "R�cio";
$text{'2020'} = "N/A";

$text{'2030'} = "Exposi��es<BR>do seu Banner";
$text{'2031'} = "Clicks No<BR>Seu Banner";

$text{'2040'} = "Banners Mostrados<BR>no Seu Site";
$text{'2041'} = "Cliques a partir<BR>seu Site";

$text{'2050'} = "Sa�da";

$text{'2100'} = "EXPIRADA!";
$text{'2101'} = "(sem expira��o!)";
$text{'2102'} = "(data desconhecida)";

$text{'2110'} = "cliques";
$text{'2111'} = "exposi��es";

$text{'2120'} = "A sua conta n�o tem nenhum banner assignado.";
$text{'2121'} = "At� agora, voc� exp�s";
$text{'2122'} = "banners no seu site";
$text{'2123'} = ", e gerou";
$text{'2124'} = "cliques a partir do seu site";
$text{'2125'} = ".";
$text{'2126'} = "Voc� ganhou";
$text{'2127'} = "exposi��es do seu banner nos outros sites. (Ganha";
$text{'2128'} = "1 exposi��o por cada";
$text{'2129'} = "exposi��es no seu site";
$text{'2130'} = ", e";
$text{'2131'} = "exposi��es por cada clique";
$text{'2132'} = ".)";
$text{'2133'} = "Foram assignadas � sua conta";
$text{'2134'} = "exposi��es como &quot;bonus&quot;.";
$text{'2135'} = "O c�digo HTML em baixo deve ser colocado no seu site na posi��o em que quer que os banner sejam expostos.";

$text{'2150'} = "Se quiser mostrar banners em mais que uma p�gina (ou mais que um na mesma p�gina), utilize &quot;page=&quot; com n�meros diferentes para cada chamada ao banner. Isto assegurar� que os novos banners sejam mostrados (e que as exposi��es sejam creditadas na sua conta) em cada uma das suas p�ginas. (Note que h� duas chamadas a este c�digo &quot;page=&quot;, e os n�meros dever�o ser iguais!)";

######################
# SECONDARY DISPLAYS #
######################

$text{'2200'} = "Editar Conta";
$text{'2201'} = "Apagar Conta";
$text{'2202'} = "Ver Estat. da Zona";
$text{'2203'} = "Ver Estat. Di�rias";
$text{'2204'} = "Ver Estat. Mensais";
$text{'2205'} = "Ver Endere�os Ip";
$text{'2206'} = "Ver Estat. Globais";
$text{'2208'} = "Upload Banner";

$text{'2210'} = "Estat�sticas por Zona para";
$text{'2211'} = "Contas";
$text{'2212'} = "Zonas";
$text{'2213'} = "Membros";
$text{'2214'} = "Exposi��es";
$text{'2215'} = "Cliques";

$text{'2220'} = "Estat�sticas Di�rias para";
$text{'2221'} = "a Conta";
$text{'2222'} = "(�ltimas 5 semanas apenas)";
$text{'2223'} = "(Lista Completa)";
$text{'2224'} = "Data";
$text{'2225'} = "Ver Estat�sticas Di�rias para as �ltimas 5 Semanas";
$text{'2226'} = "Ver Estat�sticas Di�rias Completas";

$text{'2230'} = "Ver Estat�sticas Mensais Para";
$text{'2231'} = "a Conta";
$text{'2232'} = "M�s";

$text{'2240'} = "Log dos endere�os IP para";
$text{'2241'} = "a conta";
$text{'2242'} = "O seguinte ficheiro de log mostra os endere�os IP dos indiv�duos que viram ou clicaram no banner desta conta desde a manh� de ontem. Cada linha mostra a hora de exposi��o (E) ou de clique (C), e o endere�o IP do respons�vel.";
$text{'2243'} = "Total de exposi��es";
$text{'2244'} = "Total de Cliques";
$text{'2245'} = "Total de endere�os IP";
$text{'2246'} = "Total de entradas no log por endere�o IP";

###############
# EDIT SCREEN #
###############

$text{'5000'} = "Informa��es da";
$text{'5001'} = "Conta";

$text{'5100'} = "Nome";
$text{'5101'} = "E-Mail";
$text{'5102'} = "URL do Site";
$text{'5103'} = "URL(s) do(s) Banner(s)";
$text{'5104'} = "Zona(s)";

$text{'5200'} = "(Pode deixar isto em branco; depois da conta ter sido criada, ter� a op��o de fazer um uploading do banner a partir do seu computador. Volta ao ecr� de edi��o quando quiser.)";
$text{'5201'} = "(Depois da conta ter sido criada, dever� fazer o upload de um banner a partir do seu computador. Volte ao ecr� de edi��o para o fazer.)";

$text{'5300'} = "(Seleccione as zonas -- ou &quot;categorias escolhidas&quot; -- onde quer que o seu banner seja mostrado.)";
$text{'5301'} = "(Seleccione a categoria de banners que quer mostrar no seu site.)";

$text{'5400'} = "Se quiser mudar a sua password, insere-a em baixo.";
$text{'5401'} = "Nova password";
$text{'5402'} = "Mudar password";

$text{'5500'} = "Se quiser fazer o upload de um novo banner, pode faz�-lo a partir daqui. <EM>(Note que precisa de utilizar o Netscape Navigator vers�o 2 ou superior, ou o Microsoft Internet Explorer vers�o 4 ou superior.)";
$text{'5501'} = "Ficheiro para carregar";
$text{'5502'} = "Carregar Banner";

##################
# ERROR MESSAGES #
##################

$text{'9000'} = "Erro na LusoBanner!";

$text{'9010'} = "Acesso impedido!";
$text{'9011'} = "Voc� n�o tem acesso as fun��es de administrador.";

$text{'9020'} = "Falta a Password!";
$text{'9021'} = "Voc� tem que introduzir uma password!";

$text{'9022'} = "Password Inv�lida!";
$text{'9023'} = "A password que introduziu est� incorrecta!";

$text{'9024'} = "Password Incoerente!";
$text{'9025'} = "A sua password administrativa n�o foi aceite, porque existiram duas entradas diferentes!";
		
$text{'9030'} = "Nome em uso!";
$text{'9031'} = "O nome da conta que introduziu j� existe!";

$text{'9040'} = "N�o existe endere�o de e-mail!";
$text{'9041'} = "N�o existe um endere�o de e-mail associado a esta";
$text{'9042'} = "conta!";

$text{'9050'} = "Conta ou grupo inv�lido!";
$text{'9051'} = "N�o existe uma conta ou grupo ";
$text{'9052'} = "com esse nome! (Note que todos os nomes <EM>s�o</EM> sens�veis �s mai�sculas e min�suculas!)";

$text{'9060'} = "Formato do Banner Inv�lido!";
$text{'9061'} = "O seu banner deve ser do formato <STRONG>GIF</STRONG> (.gif) ou <STRONG>JPEG</STRONG> (.jpg ou .jpeg)!";

$text{'9070'} = "Banner muito grande!";
$text{'9071'} = "O seu banner � muito grande! N�o pode ter um tamanho superior a";
$text{'9072'} = "kilobytes. (O tamanho do banner que tentou carregar foi de";
$text{'9073'} = "kilobytes.)";

$text{'9080'} = "N�o � poss�vel abrir o ficheiro!";
$text{'9081'} = "O script n�o consegue abrir um ficheiro para guardar o seu banner. (Isto dever� ser um erro de permiss�es na directoria de carregamento de ficheiros.)";

$text{'9100'} = "Entrada imcompleta!";
$text{'9101'} = "N�o foi inserida toda a informa��o necess�ria! Dever� <EM>pelo menos</EM> inclu�r a password!";

$text{'9105'} = "Question�rio incompleto!";
$text{'9106'} = "N�o foi introduzida toda a informa��o necess�ria para criar";
$text{'9107'} = "um grupo!";
		
$text{'9110'} = "Entrada inv�lida!";
$text{'9111'} = "Foi indicado que esta conta ganha exposi��es mostrando outros banners, mas tamb�m indicou que a conta expira baseada na data ou nos cliques. Estas duas situa��es s�o incompat�veis! Os r�cios s� podem ser definidos em contas que n�o expiram, ou para um certo n�mero de exposi��es &quot;bonus&quot; que tenham sido definidas.";

$text{'9120'} = "Erro no sistema de mail!";
$text{'9121'} = "O server encontrou um erro quando tentava enviar um e-mail. Isto siginfica que o programa de mail est� incorrectamente definido na configura��o da lusobanner.";

$text{'9130'} = "Erro na permiss�o de ficheiros!";
$text{'9131'} = "O server encontrou um erro quando tentava aceder a um ficheiro!";
$text{'9132'} = "A causa mais comum neste tipo de problemas � um erro de permiss�es na directoria dos banners (";
$text{'9133'} = "). Verfique que a directoria existe e tem os atributos de world-writable.";

$text{'9140'} = "N�o h� estat�ticas di�rias!";
$text{'9141'} = "N�o existe ficheiro de log dispon�vel!";

$text{'9150'} = "O script encontrou um erro quando tentava aceder ao ficheiro de base de dados!";

1;
