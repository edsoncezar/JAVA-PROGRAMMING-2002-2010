#!/usr/local/bin/perl

############################################
##                                        ##
##       WebAdverts (Configuration)       ##
##           by Darryl Burgdorf           ##
##       (e-mail burgdorf@awsd.com)       ##
##                                        ##
##             version:  3.20             ##
##        last modified:  09/08/02        ##
##           copyright (c) 2002           ##
##                                        ##
##    latest version is available from    ##
##        http://awsd.com/scripts/        ##
##                                        ##
############################################

# Define the location of your "ads_settings" file.
$ADVsettings_path = "/full/path/to/ads_settings.pl";

# Define the URL of this configuration file:
$ADVdisplay_cgi = "http://foo.com/ads/ads.pl";

# Define the zone, if any, unique to this configuration file:
$ADVadvertzone = "";

# NOTHING BELOW THIS LINE NEEDS TO BE ALTERED!

require $ADVsettings_path;

unless ($ADVNoPrint) {
	if ($ARGV[0]) { $ADVQuery = $ARGV[0]; }
	else { $ADVQuery = $ENV{'QUERY_STRING'}; }
}

if ($ADVUseCookies && $ADVCheckForCookie && ($ADVQuery =~ /page=/)
  && ($ADVQuery !~ /advert=/) && ($ADVQuery !~ /banner=/)
  && ($ENV{'HTTP_COOKIE'} !~ /TestCookie=TestValue/)  
  && ($ADVQuery !~ /checkforcookie/)) {
	if ($ENV{'PERLXS'} eq "PerlIS") { print "HTTP/1.0 301 Found\n"; }
	else { print "Status: 301 Found\n"; }
	print "Set-Cookie: TestCookie=TestValue\n";
	print "location: $ADVdisplay_cgi?$ADVQuery;checkforcookie\n\n";
	exit;
}
elsif ($ADVCheckForCookie
  && ($ENV{'HTTP_COOKIE'} !~ /TestCookie=TestValue/)) {
	$ADVUseCookies = 0;
}

require $ADVdisplay_path;
&ADVsetup;

unless ($ADVNoPrint) { reset 'A-Za-z'; exit; }

1;
