package CGiClube::Plugin;

use Perlbot;

sub get_hooks {
  return { public => \&on_public };
}

sub on_public {
  my ($self, $event) = (shift, shift);
  my $nick = $event->nick;
  my $chan = ($event->to)[0];
  my ($arg) = $event->args;

  if ($arg =~ /CGiClube/i) {
    $self->privmsg($chan, "$nick: 10http://www.CGiClube.net 4=> 5Aqui voc� realmente aprende!");
  }
}

1;
