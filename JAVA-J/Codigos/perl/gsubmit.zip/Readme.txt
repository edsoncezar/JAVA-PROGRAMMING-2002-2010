### G.Scripts by Nick Grant #########################

Web: http://www.grant-online.co.uk/scripts/

Email: nickgrant_2001@yahoo.co.uk

Yahoo! Messenger: nickgrant_2001
MSN Messenger: nickgrant_uk

#############################################


### Script Information #############################

Name: G.Submit
Version: 1.0

Info:

G.Submit is a way to offer a website submission service to your website, 
allow your visitors to submit there website details to nearly 30 search engines 
in real time. Also the script logs the submissions.

2 Scripts

signup.cgi - This is the script where you fill in your web/personal details
submit.cgi - This is the script where you start submitting your details

##################################################
If you need help with installing this script, email me on:
nickgrant_2001@yahoo.co.uk?subject=ScriptHelp
##################################################

G.Scripts @ http://www.grant-online.co.uk/scripts/