#Program to generate a (very simple) password file

print "Please type the name of the file: ";
$fileloc = <>;
print "Please enter the password (case sensative): ";
$passa = <>;
chomp($passa);
@passb = split(//, $passa);
open (FILE, ">$fileloc");
foreach $let (@passb)
{
$let = $let ^ "�";
}
print FILE @passb;
close FILE;