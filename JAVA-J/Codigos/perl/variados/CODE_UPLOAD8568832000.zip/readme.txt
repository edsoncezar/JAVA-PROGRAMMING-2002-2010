Produced by Nifty Inc.
http://niftyinc.cjb.net
Code by David Friedman

Simple code to be run at startup on a Win95/98 system to provide true password protection. Simple encryption, 3 trys or restart. If you like it please goto the page and put something on the message board.

Use makepass.pl to write your password to a file
Insert pass.pl somewhere in a startup script to secure your computer.