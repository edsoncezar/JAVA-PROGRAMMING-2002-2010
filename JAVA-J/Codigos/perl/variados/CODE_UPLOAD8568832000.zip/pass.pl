#Program to check for the correct password or send computer into a loop

#Set the location of the password file
$fileloc = "c:/perlpass/pass.txt";

$realpass = "";
open (FILE, $fileloc) || die "Could not find file";
$pass = <FILE>;
chomp $pass;
@alllet = split(// , $pass);
foreach $let (@alllet)
{
$realpass = ($realpass . ($let ^ "�"))
}
close FILE;
for ($counter = 1; $counter <= 3; $counter++)
{
print "Please enter your password: ";
$inpass = <>;
chomp($inpass);
if ($inpass eq $realpass)
{
last;
}
}
if ($inpass ne $realpass)
{
do
{
}
while(true);
}