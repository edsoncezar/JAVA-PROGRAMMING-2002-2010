Pure Perl/Tk  Network Commander by Mollensoft Software (www.mollensoft.com)

Welcome to the Network Commander Read Me File.

This program is intended to provide Perl Users with an example program that actually performs some functions 
which always makes learning Perl and Tk much easier. This Program is Free Software; You can do with it what you want! 

Disclaimer: This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

This program performs four basic functions: Ping,Network Scanning, Tracing Routes and Finding IP 
addresses for a named Host. Specific instructions are in the help File.

To Run 
  1. Extract the Contents of zipfile into a directory
  2. If you Have Perl installed, Double click the "netcmdr.pl" file in the directory you unzipped it into.
  3. If you do not have perl installed Double click the "netcmdr.exe" file in the directory you unzipped it into.
   
Note: The exe program file can be downloaded at "www.mollensoft.com/perl/netcmdrexec.zip"

Feedback to me, Enjoy! 
BigAl Sends....