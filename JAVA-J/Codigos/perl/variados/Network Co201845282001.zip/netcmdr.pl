#!perl.exe
##################################################################
#####     Mollensoft Perl/Tk Network Commander Processor v1  #####
##################################################################
#                                                              ###
#     The Purpose of this Program is to provide a working      ###                      
#     example of the Graphic utiltiy found using Perl and Tk,  ###
#     coupled with some commonly used networking functions     ###
#                                                              ### 
#     Displays Good Examples of menus, Dialog Box, Scrolling,  ###  
#     List Box, opening files, reading data from files,        ###
#     acting on that data, etc.                                ###
#                                                              ###
# This program is for learning and is free, Just Like Perl     ###
#                                                              ###
# Creation:  19 May 2001                                       ###
# Last Edit: 28 May 2001                                       ###
#                                                              ###
#  courtesy BigAL Mollenkopf-www.mollensoft.com                ###
#                                                              ###
##################################################################

# Some of the "use" Declarations below are only required to compile script to exe.

use Tk;
use Tk::Text;
use Net::Ping;
use Tk::Toplevel;
use Tk::Pane;
use Tk::DialogBox;
use IO::Socket;
use Socket;
use File::Spec::Win32;
use Tk::Menubutton;

  $date = localtime();
  open (LOGZ, ">>logfile.txt")|| die ("Cannot Open Application Logfile");
            print LOGZ "<<<Perl/Tk Network Commander Started $date>>>\n";
            close(LOGZ);


my $main = new MainWindow;
        $main->title("Perl/Tk Network Commander");
        $menubar = $main->Frame(-relief=>"raised",-borderwidth=>2);
        $filebutton = $menubar->Menubutton(-text=>"Exit",-underline => 0);  
        $filemenu = $filebutton->Menu();
                    $filebutton->configure(-menu=>$filemenu);
                    $filemenu->command(-label => "View Log",-command => \&view_log,-underline => 1);
                    $filemenu->command(-label => "Exit",-command => \&exit_choice,-underline => 1);  
                            
        $scanbutton = $menubar->Menubutton(-text=>"Scan",-underline => 0);  
        $scanmenu = $scanbutton->Menu();
        $scanbutton->configure(-menu=>$scanmenu);
                    $scanmenu->command(-command => \&select_scanvar,-label => "Configure Scan",-underline => 0); 
                    $scanmenu->separator;
                    $scanmenu->command(-command => \&scan_ports,-label => "Start Scan",-underline => 0); 
       
        $tracebutton = $menubar->Menubutton(-text=>"Trace Route",-underline => 0);  
        $tracemenu = $tracebutton->Menu();
        $tracebutton->configure(-menu=>$tracemenu);
                    $tracemenu->command(-command => \&select_tracevar,-label => "Configure Route to Trace",-underline => 0); 
                    $tracemenu->separator;
                    $tracemenu->command(-command => \&trace_routes,-label => "Start Trace Route",-underline => 0); 

        $lookupbutton = $menubar->Menubutton(-text=>"Host Lookup",-underline => 0);  
        $lookupmenu = $lookupbutton->Menu();
        $lookupbutton->configure(-menu=>$lookupmenu);
                    $lookupmenu->command(-command => \&select_lookupvar,-label => "Configure Host To Lookup",-underline => 0); 
                    $lookupmenu->separator;
                    $lookupmenu->command(-command => \&start_lookup,-label => "Start Lookup",-underline => 0); 



                            
        $pingbutton = $menubar->Menubutton(-text=>"Ping",-underline => 0);  
        $pingmenu = $pingbutton->Menu();
        $pingbutton->configure(-menu=>$pingmenu);
        $pingbutton->command(-command => \&edit_list,-label => "Add/Edit Host List",-underline => 0); 
        $pingbutton->separator;
        $pingbutton->command(-command => \&start_ping,-label => "Start Pinging",-underline => 0); 
        $pingbutton->separator;

        $logbutton = $menubar->Menubutton(-text=>"Log",-underline => 0); 
        $logmenu = $logbutton->Menu();
        $logbutton->command(-command => \&view_log,-label => "View Logfile", -underline => 0); 
        $logbutton->separator;
        $logbutton->command(-command => \&clear_log,-label => "Clear Logfile", -underline => 0); 

        
        $helpbutton = $menubar->Menubutton(-text=>"Help",-underline => 0); 
        $helpmenu = $helpbutton->Menu();
        $helpmenu->command(-command => \&about_choice,-label => "About Perl/Tk Network Commander", -underline => 0);
        $helpbutton->configure(-menu=>$helpmenu);
        $helpmenu->command(-command => \&show_help,-label => "Help", -underline => 0); 
$filebutton->pack(-side=>"left");
$pingbutton->pack(-side=>"left");
$scanbutton->pack(-side=>"left");
$tracebutton->pack(-side=>"left");
$lookupbutton->pack(-side=>"left");
$helpbutton->pack(-side=>"right");
$logbutton->pack(-side=>"right");
$menubar->pack(-side=>"top", -fill=>"x");

$status = $main->Label(-text=>"Ready...",-relief=>sunken,-borderwidth=>2,-anchor=>"w");
$status->pack(-side=>"bottom", -fill=>"x");
     $box = $main->Listbox(-relief => 'sunken',-width => 70,-height => 10)->pack(-side =>'left');
     $scroll = $main->Scrollbar(-command => ['yview', $box]);
     $scroll->pack(-side => 'right', -fill => 'y');
     $box->configure(-yscrollcommand => ['set', $scroll]);
     $box->pack(-side => 'left', -fill => 'both', -expand => 'yes');
 
 MainLoop;

sub clear_log {
            open (LOG, ">logfile.txt")|| die ("Cannot Open Logfile File");
            close(LOG);

}


sub view_log {
my $log = new MainWindow;
        $log->title("View Perl/Tk Network Commander Logfile");
        $log->Button(-text => 'Quit',-command => [$log => 'destroy'])->pack(-side=>bottom);
         my $box = $log->Listbox(-relief => 'sunken',-width => 65,-height => 10,-setgrid => 'yes');
        
            open (LOGFILEX, "logfile.txt")|| die ("Cannot Open Scan Database File");
            @logarray = <LOGFILEX>;
            close(LOGFILEX);

                    foreach (@logarray) {
                       chomp $_;
                       $box->insert('end', $_);
                    }
        my $scroll = $log->Scrollbar(-command => ['yview', $box]);
        $box->configure(-yscrollcommand => ['set', $scroll]);
        $box->pack(-side => 'left', -fill => 'both', -expand => 'yes');
        $scroll->pack(-side => 'right', -fill => 'y');
       }



sub select_lookupvar {
        my $lu=MainWindow->new;
        $lu->title("IP Address Lookup Configuration");
  
        $labe75 = $lu->Label(-text => "Enter Hostname to lookup IP Address For",-font => "Verdana 7",-foreground => "Dark Red");
        $labe75->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $lutext1 = $lu ->Text ('-width'=> 30, '-height'=>1)->pack();
                      open(INPUT, "lu.txt");
                         @lut = <INPUT>;
                         close(INPUT);
        $lutext1->insert('end',"$lut[0]");
        $labe79 = $lu->Label(-text => "Clicking the \"Save\" button saves new values. \nClicking \"Quit\"with out clicking the \"Save\" \nbutton keeps the current IP/Hosts intact.",-font => "Verdana 7",-foreground => "Dark Red");
        $labe79->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);

        $lu->Button(-text => 'Quit',-command => [$lu => 'destroy'])->pack(-side=>left);
        $lu->Button(-text => 'Save', -command => sub{save_luvars($lutext1)})->pack(-side=>right);

}

sub save_luvars {
	          
	        my ($lutext1) = @_;
            my $ludata1 = $lutext1 ->Contents(); 
            chop $ludata1;  
            open (OUTFILE, ">lu.txt")|| die ("Cannot Open Look Up Database File");
            print OUTFILE "$ludata1";
            close(OUTFILE);
            $status->configure(-text=>"Lookup Configuration Variables... updated");
                 }


sub start_lookup {
            #using arrayvar here to support next version using list
            $date = localtime();
            open(LUP, "lu.txt");
            @luarray = <LUP>;
            close(LUP);
            $lookup = $luarray[0];
            
my ($name, $aliases, $type, $length, @addrs) = gethostbyname($lookup);
if ($name) {
	foreach (@addrs) {
	$_ = inet_ntoa($_);
	}
$box->insert('end', "<<Starting IP Address Lookup>>");
open (LOGFILE, ">>logfile.txt")|| die ("Cannot Open Logfile File");

if ($name eq $lookup) {
    $box->insert('end', "$lookup IP Address is: @addrs");
	print LOGFILE "$lookup IP address is: @addrs\n";
	} else {
    $box->insert('end', "$lookup (True Name... $name) has IP address: @addrs");
	print LOGFILE "$lookup (True Name... $name) IP Address is: @addrs\n";
	}
  }else{

$box->insert('end', "$lookup Was Not Found");
print LOGFILE "$lookup Was Not Found\n";
  }
$box->insert('end', "<IP Address Lookup Complete on $date>");
print LOGFILE "<IP Lookup Complete on $date\n";

}



sub select_tracevar {

        my $tr=MainWindow->new;
        $tr->title("Route Trace Configuration");
  
        $label7 = $tr->Label(-text => "Input Traceroute IP/Hostname",-font => "times 14",-foreground => "red");
        $label7->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);                                                                                                                                                          

        $label5 = $tr->Label(-text => "IP/Hostname To Trace",-font => "Verdana 7",-foreground => "Dark Red");
        $label5->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $trtext1 = $tr ->Text ('-width'=> 30, '-height'=>1)->pack();
                         open(INPUT, "tr.txt");
                         @trt = <INPUT>;
                         close(INPUT);
        $trtext1->insert('end',"$trt[0]");
        $labe49 = $tr->Label(-text => "Clicking the \"Save\" button saves new values. \nClicking \"Quit\"with out clicking the \"Save\" \nbutton keeps the current IP/Hosts intact.",-font => "Verdana 7",-foreground => "Dark Red");
        $labe49->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);

        $tr->Button(-text => 'Quit',-command => [$tr => 'destroy'])->pack(-side=>left);
        $tr->Button(-text => 'Save', -command => sub{save_trvars($trtext1)})->pack(-side=>right);


}

sub save_trvars {
	          
	        my ($trtext1) = @_;
            my $trdata1 = $trtext1 ->Contents(); 
            chop $trdata1;  
            open (OUTFILE, ">tr.txt")|| die ("Cannot Open Scan Database File");
            print OUTFILE "$trdata1";
            close(OUTFILE);
            $status->configure(-text=>"Trace Route Configuration Variables... updated");
                 }




sub trace_routes {
           $date = localtime();
             open(TRCRT, "tr.txt");
            @trace = <TRCRT>;
            close(TRCRT);
            @tempz = `tracert $trace[0]`;
                                open(TRAACE, ">>logfile.txt");
         print TRAACE "\n<Started Tracing Route to Host $trace[0] on $date>\n";

                                foreach (@tempz) {
                                    $_ =~ s/\r\n//g; 
                                    $box->insert('end', $_);
                                    print TRAACE "$_\n";
			               }
         print TRAACE "\n<<Completed Route Trace to Host $trace[0] on $date>>\n";
         close (TRAACE);
$status->configure(-text=>"Tracing Routes Complete...");

}


sub select_scanvar {
        my $sc=MainWindow->new;
        $sc->title("Scanner Configuration");
        $label38 = $sc->Label(-text => "Warning, Scanning a Host ports takes some time\n It is advisable to Select \n A Small range to scan",-font => "Verdana 7",-foreground => "Dark Red");
        $label38->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);

        $label32 = $sc->Label(-text => "Set Port To Start Scan (Default is Zero)",-font => "Verdana 7",-foreground => "Dark Red");
        $label32->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $sctext2 = $sc ->Text ('-width'=> 5, '-height'=>1)->pack();

        $label33 = $sc->Label(-text => "Set Port to Stop scan (default is 65000)",-font => "Verdana 7",-foreground => "Dark Red");
        $label33->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $sctext3 = $sc ->Text ('-width'=> 12, '-height'=>1)->pack();

        $label31 = $sc->Label(-text => "Set IP/Host To Scan",-font => "Verdana 7",-foreground => "Dark Red");
        $label31->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $sctext1 = $sc ->Text ('-width'=> 25, '-height'=>1)->pack();
                
                         open(INPUT, "sc.txt");
                         @sc = <INPUT>;
                         close(INPUT);
                         
        $sctext1->insert('end',"$sc[0]");
        $sctext2->insert('end',"$sc[1]");
        $sctext3->insert('end',"$sc[2]");
        $sc->Button(-text => 'Quit',-command => [$sc => 'destroy'])->pack(-side=>left);
        $sc->Button(-text => 'Save', -command => sub{save_scanvars($sctext1,$sctext2,$sctext3)})->pack(-side=>right);


}


sub save_scanvars {
	          
	        my ($sctext1, $sctext2, $sctext3) = @_;
            my $scdata1 = $sctext1 ->Contents(); 
            my $scdata2 = $sctext2 ->Contents(); 
            my $scdata3 = $sctext3 ->Contents();
            chop $scdata1;  
            chop $scdata2;       
            chop $scdata3;
            open (OUTFILE, ">sc.txt")|| die ("Cannot Open Scan Database File");
            print OUTFILE "$scdata1$scdata2$scdata3";
            close(OUTFILE);
            $status->configure(-text=>"Scanning Configuration Variables... updated");
                 }

  sub scan_ports {
  
      $dialog=$main->DialogBox(-title => "Really Start Scan?", -buttons => ["OK","Cancel"]);  
      $label8 = $dialog->Label(-text => "Warning, Scanning a Host ports takes some time\n It is advisable to Select \n A Small range to scan!\n Press Cancel to Return to Main Menu",-font => "Verdana 12",-foreground => "Red");
      $label8->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $label = $dialog->Label(-text => "Scanning Takes some time, up to 5 minutes to scan\n several ports...",-font => "Verdana",-foreground => "Dark Red");
      $label->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $result = $dialog->Show;
      if ($result eq "OK") {scan_init();}
      if ($result eq "Cancel") {;}
  }

     sub scan_init {
  

            open(SCAN, "sc.txt");
            @scan = <SCAN>;
            close(SCAN);
$date = localtime();            
$server = ($scan[0] || "127.0.0.1");
$begin =  ($scan[1] || 0);
$end =  ($scan[2] || 65000);
chomp $server;
chomp $begin;
chomp $end;
open(OUTFILE1, ">>logfile.txt");
print OUTFILE1 "\n<Started Scanning Host $server starting port $begin to $end on $date>\n";
 $box->insert('end', ">Started Scanning on $Date Host $server");
for ($port=$begin;$port<=$end;$port++)	{
$sock = IO::Socket::INET->new(PeerAddr => $server,
				 	  PeerPort => $port,
				 	  Proto => 'tcp');

	if ($sock)	{
$Date = localtime();
print OUTFILE1 ">>on $Date Host $server port $port is open\n";
 $box->insert('end', ">>on $Date Host $server port $port is open");

	} else {
$Date = localtime();
print OUTFILE1 ">>on $Date Host $server port $port is closed\n";
 $box->insert('end', ">>on $Date Host $server port $port is closed");

	}

     }
    $date = localtime();
    print OUTFILE1 "<<Completed Host Scan on $date>>\n";
    close OUTFILE1; 
 $Date = localtime();
$box->insert('end', ">Finished Scanning on $Date");
$status->configure(-text=>"Finished Scanning on $Date...");
      }
  
  

    

sub exit_choice {
    $dialog=$main->DialogBox(-title => "Really Quit Perl Network CMDR?", -buttons => ["OK","Cancel"]);  
    $result = $dialog->Show;
    if ($result eq "OK") {$date = localtime();
            open (LOGZ, ">>logfile.txt")|| die ("Cannot Open Application Logfile");
            print LOGZ "<<<Perl/Tk Network Commander Stopped Normally on $date>>>\n";
            close(LOGZ);
exit;}
    if ($result eq "Cancel") {;}
    }



sub start_ping {
            open(INPUT, "hostdbase.txt");
            @data = <INPUT>;
            close(INPUT);
            
            open(OUTFILE, ">pingoutfile.txt");
            $Date = localtime();
            
            print OUTFILE "\n<Starting Ping Session >\n";
            
            foreach $host (@data){
            chop $host; 	
                  if ($host ne "" && $host ne "\n"){
            $p = Net::Ping->new(icmp);
            if ($p->ping($host)) {print OUTFILE "<+>On $Date Host $host is Alive \n";}
            else {print OUTFILE "<->On $Date Host $host is Not reachable\n";}
                                }
            else {print OUTFILE "Skipped Entry...No Hostname Or Ip Entered\n";}
                                  }                                
            $p->close();
            print OUTFILE "<<Ping Session Completed on $date>\n";
            close(OUTFILE);
            
            open(INFILE, "pingoutfile.txt");
            @inz = <INFILE>;
            close(INFILE);
            open(LOGFILE, ">>logfile.txt");
            print LOGFILE "@inz";
            close(LOGFILE);

            $status->configure(-text=>"Pinging Complete...");
                                foreach (@inz) {
                                   chomp $_;       
                                   $box->insert('end', $_); 
                                         } 
                                         $box->insert('end', "<<Ping Session Success>>");
                                          }

sub edit_list {

  
        my $mp=MainWindow->new;
        $mp->title("Edit/Add Hosts or IP Addresses");
        $label4 = $mp->Label(-text => "This program will ping any four hosts you wish. \n Enter the hostnames or Ip addresses into the four text boxes",-font => "Verdana 7",-foreground => "Dark Red");
        $label4->pack(-side=>"top", -expand=>1,-padx=>2, -pady=>2);
        $xwtext1 = $mp ->Text ('-width'=> 30, '-height'=>1)->pack(-padx=>2, -pady=>2);
        $xwtext2 = $mp ->Text ('-width'=> 30, '-height'=>1)->pack(-padx=>2, -pady=>2);
        $xwtext3 = $mp ->Text ('-width'=> 30, '-height'=>1)->pack(-padx=>2, -pady=>2);
        $xwtext4 = $mp ->Text ('-width'=> 30, '-height'=>1)->pack(-padx=>2, -pady=>2);
    
         open(INPUT, "hostdbase.txt");
         @data = <INPUT>;
         close(INPUT);
     
        $xwtext1->insert('end',"$data[0]");
        $xwtext2->insert('end',"$data[1]");
        $xwtext3->insert('end',"$data[2]");
        $xwtext4->insert('end',"$data[3]");
        $label9 = $mp->Label(-text => "Clicking the \"Save\" button saves new values. \nClicking \"Quit\"with out clicking the \"Save\" \nbutton keeps the current IP/Hosts intact.",-font => "Verdana 7",-foreground => "Dark Red");
        $label9->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $mp->Button(-text => 'Quit',-command => [$mp => 'destroy'])->pack(-side=>left,-padx=>25, -pady=>25);
        $mp->Button(-text => 'Save', -command => sub{save_hostsfile($xwtext1,$xwtext2, $xwtext3, $xwtext4)})->pack(-side=>right,-padx=>25, -pady=>25);
                 }

sub save_hostsfile {
	          
	    my ($xwtext1, $xwtext2, $xwtext3, $xwtext4) = @_;
            my $text1 = $xwtext1 ->Contents(); 
            my $text2 = $xwtext2 ->Contents(); 
            my $text3 = $xwtext3 ->Contents(); 
            my $text4 = $xwtext4 ->Contents(); 
            chop $text1;  
            chop $text2;       
            chop $text3;       
            chop $text4;                  
            open (HOSTS, ">hostdbase.txt")|| die ("Cannot Open Hosts/IP Database File");
            print HOSTS "$text1$text2$text3$text4";
            close(HOSTS);
            $status->configure(-text=>"Ping Host List... updated");
                 }



sub about_choice {
      
      my $xw=MainWindow->new;
      $xw->title("About Perl/Tk Network Commander");
      $label1 = $xw->Label(-text => "The Perl/Tk Network Commander \n Version 1.0",-font => "Verdana",-foreground => "Dark Blue");
      $label15 = $xw->Label(-text => "This Freeware Program by ",-font => "Arial 12",-foreground => "Dark Red");
      $label13 = $xw->Label(-text => "Mollensoft Software\n www.mollensoft.com",-font => "Arial 10",-foreground => "Dark Green");
      $label1->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $label15->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $label13->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $xw->Button(-text => 'Exit',-command => [$xw => 'destroy'])->pack;
      $status->configure(-text=>"about Perl/Tk Network Commander");

}



sub show_help{
	          
        my $main = new MainWindow;
        $main->title("Perl/Tk Network Commander Help");
        $main->Button(-text => 'Exit',-command => [$main => 'destroy'])->pack(-side=>"bottom");
        my $box = $main->Listbox(-relief => 'sunken',-width => 50,-height => 10,-setgrid => 'yes');
        
            open (HELPF, "help.txt")|| die ("Cannot Open Help File");
            @helpfilez = <HELPF>;
            close(HELPF);
                    foreach (@helpfilez) {
                       chomp $_;
                       $box->insert('end', $_);
                                     }
        my $scroll = $main->Scrollbar(-command => ['yview', $box]);
        $box->configure(-yscrollcommand => ['set', $scroll]);
        $box->pack(-side => 'left', -fill => 'both', -expand => 'yes');
        $scroll->pack(-side => 'right', -fill => 'y');
                                           
               }

