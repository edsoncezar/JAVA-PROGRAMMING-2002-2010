#!/usr/bin/perl -w

use strict;

use POE;
use POE::Component::IRC;
use Config::General;
use Proc::Daemon;
use WWW::Search;

# Lets get my options from the config file..
my $conf   = new Config::General('poeb.cfg');
my %config = $conf->getall;
my %seen;

# Don't let the bot start, till the config is edited..
if ( $config{edit} == 1 ) {
    die "Edit Your Config Doofus!\nError:";
}

# Initialize Logging
my $nick = $config{nick};
my $ts   = scalar(localtime);
chat_log("Log Initialized at $ts\n");
chan_log("Log Initialized at $ts\n");
serv_log("Log Initialized at $ts\n");
open( FILE, ">>$config{seenlog}" );
print FILE "Log Initialized at $ts\n";
close FILE;
print "$config{nick} Initialized at $ts\n";

# Put me in the background and forget it..
Proc::Daemon::Init();

# Spit STDERR into a log file, just incase something fails with 
# Proc::Daemon running, This will put ALL errors, and output onto this 
# file
open( STDOUT, ">>$config{errlog}" )
  or die "Bah: $!";
open( STDERR, ">&STDOUT" )
  or die "Bah: $!";

# Lets define my name
POE::Component::IRC->new("poeb");

# Lets define some handlers that I'll understand..
POE::Session->new(
    _start           => \&bot_start,
    irc_001          => \&on_connect,
    irc_disconnected => \&on_disco,
    irc_public       => \&on_public,
    irc_msg          => \&on_msg,
    irc_quit         => \&on_quit,
    irc_join         => \&on_join,
    irc_part         => \&on_part,
    irc_socketerr    => \&irc_socketerr,
    irc_ctcp_ping    => \&on_ping,
    irc_ctcp_version => \&on_ver,
    irc_ctcp_finger  => \&on_finger,
    irc_ctcp_page    => \&on_page,
    irc_ctcp_time    => \&on_time,
    keepalive        => \&keepalive,
    irc_433          => \&on_nick_taken,
);

# How about defining some of my "normal" attributes, and connect to a server
sub bot_start {
    my $kernel  = $_[KERNEL];
    my $heap    = $_[HEAP];
    my $session = $_[SESSION];

    $kernel->post( 'poeb', 'register', "all" );

    $kernel->post(
        'poeb',
        'connect',
        {
            Debug    => "$config{debug}",
            Password => "$config{spass}",
            Nick     => "$config{nick}",
            Username => "$config{username}",
            Ircname  => "$config{ircname}",
            Server   => "$config{server}",
            Port     => "$config{port}",
        }
      )
      || die "Oop: $!";
    my $ts = scalar(localtime);
    serv_log("$ts%notice%Connecting to IRC ...]\n");
}

sub keepalive {
    $_[HEAP]->{'keepalive_time'} += 180;
    $_[KERNEL]->alarm( 'keepalive' => $_[HEAP]->{'keepalive_time'} );
    $_[KERNEL]->post( 'poeb', 'sl', 'PING ' . time() );
}

# Store my help commands into an array, for later use..

my @help = (
    "Type help <Command> for help on specific command.",
    "Channel Commands are as follows:",
    "join, op, deop, hop, dehop, voice, devoice, kick, ban, unban",
    "Miscellaneous Commands:",
    "say, part, away, back, search, adduser, deluser, clear, quit, help",
    "All of these commands are reserved for bot owners and admin",
);

# Help contents stored in a hash to be called upon..

my %help = (
    join => '#<chan>                       Joins Specfied channel',
    op   =>
      'op <chan> <nick>             Ops Specified Nick on Specified Channel',
    deop  => 'deop <chan> <nick>           Deops Specified user on Channel',
    hop   => 'hop <chan> <nick>            Gives Specified User a %(Half Op)',
    dehop => 'dehop <chan> <nick>          DeHops Specified user on Channel',
    voice => 'voice <chan> <nick>          Gives the User a Voice for +m Chan',
    devoice => 'devoice <chan> <nick>      Devoices Specified user on Channel',
    kick => 'kick <chan> <nick> <reason>  Kicks the User With Specified Reason',
    ban  => 'ban <chan> <user@host>      Bans user@host from chan',
    unban  => 'unban <chan> <user@host>    Un-Ban user@host from chan',
    say    => 'say <chan> <enter text here> Say something witty to the chan',
    part   => 'part <chan>                  Part Specified Channel',
    away   => 'away <msg>                   Put the bot in "away" status',
    back   => 'back                         Leave "away" status',
    search =>
      'search <phrase>              Search Google for top 10 URLs for string',
    adduser => 'adduser <user>               Adds access for specified user',
    deluser => 'deluser <user>               Deletes User from access list',
    clear   =>
'clear <logname>              Clears Log File.  See help <log> for list of lognames',
    help => 'help                         Prints this help message',
    log  =>
'Log Names for "clear" command: botlog eq Private Bot Interaction log - chanlog eq Channel Log - servlog eq Server Log - seenlog eq Seen Log - all eq All Of Above!',
    seen => 'seen <nick>                   Gives last seen action for <nick>',
    quit => 'quit <msg>			   Quits the server.  You may specify a message, or let the one from the config display as a quit message.'
);

my @mhelp = (
    "This bot responds to the following public commands.",
    "!ver                           Print Current Version Info",
    "!help                          Print This Help File",
"!search <string>               Search Google for best URL match for string",
    "!seen <nick>                   Gives last seen action for <nick>"
);

# Once I've successfully connected to a server, lets do some stuff
# I'll join a channel, and identify myself, provided I've registered 
# My Nick
sub on_connect {
    if ( $config{reg} == 1 ) {
        $_[KERNEL]
          ->post( 'poeb', 'privmsg', 'nickserv', "identify $config{nickpass}" );
    }
    else {
        $_[KERNEL]->post(
            'poeb',     'privmsg',
            'nickserv', "register $config{nickpass} $config{email}"
        );
    }
    $_[KERNEL]->post( 'poeb', 'join', $config{chan} );
    $_[KERNEL]->post( 'poeb', 'mode', $config{nick}, '+B' );
}

# Someone Pinged Me!
sub on_ping {
    my ( $kernel, $who, $text ) = @_[ KERNEL, ARG0, ARG2 ];
    my $nick = ( split /!/, $who )[0];
    $kernel->post( 'poeb', 'ctcpreply', $nick, "PING", "PONG, Bitch" );
}

# Someone wants to know my Version
sub on_ver {
    my ( $kernel, $who, $text ) = @_[ KERNEL, ARG0, ARG2 ];
    my $nick = ( split /!/, $who )[0];
    $kernel->post( 'poeb', 'ctcpreply', $nick, "VERSION", $config{ver1} );
}

# bot got fingered!
sub on_finger {
    my ( $kernel, $who ) = @_[ KERNEL, ARG0 ];
    my $nick = ( split /!/, $who )[0];
    $kernel->post( 'poeb', 'ctcpreply', $nick, "FINGER", "That's the Spot!" );
}

# Give them our pager number (he he)
sub on_page {
    my ( $kernel, $who ) = @_[ KERNEL, ARG0 ];
    my $nick = ( split /!/, $who )[0];
    $kernel->post( 'poeb', 'ctcpreply', $nick, "PAGE", "Pager # is 867-5309" );
}

# Give Them Our Time
sub on_time {
    my ( $kernel, $who ) = @_[ KERNEL, ARG0 ];
    my $nick = ( split /!/, $who )[0];
    my $ts = scalar(localtime);
    $kernel->post( 'poeb', 'ctcpreply', $nick, "TIME", $ts );
}

# What to do if someone quits the server I'm on...
sub on_quit {
    my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
    my $nick = ( split /!/, $who )[0];
    my $ts = scalar(localtime);

    if ( $nick eq $config{owner} ) {
        serv_log("$ts%quit%$config{owner} Left the server!\n");
        seen_log( $nick, "Quitting" );
    }
    else {
        my $ts = scalar(localtime);
        serv_log("$ts%quit%$nick has left the server\n");
        seen_log( $nick, "Quitting" );
    }

}

# What to do if someone joins the channel I'm on.
sub on_join {
    my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
    my $nick = ( split /!/, $who )[0];

    # What to do if its me I see join a chan..
    if ( $config{jmsg} == 1 ) {
        if ( $config{nick} eq $nick ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Never ph33r, $config{nick} is here\!" );
        }

        # Otherwise, let them know we care..
        elsif ( $nick eq $config{owner} ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "$nick, da boss is here!" );
            $kernel->post( 'poeb', 'mode', $where, '+o', $nick );
            my $ts = scalar(localtime);
            chan_log("$where%$ts%$nick, da bos joined channel $where\n");
            seen_log( $nick, "Joining $where" );
        }
        else {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Welcome to $where, $nick!" );
            my $ts = scalar(localtime);
            chan_log("$where%$ts%$nick joined channel\n");
            seen_log( $nick, "Joining $where" );
        }
    }
}

sub on_part {

    my ( $kernel, $who, $where ) = @_[ KERNEL, ARG0, ARG1 ];
    my $nick = ( split /!/, $who )[0];
    my $ts = scalar(localtime);
    chan_log("$where%$ts%$nick parted channel\n");
    seen_log( $nick, "Parting $where" );

}

# Changes nick if current nick is taken
sub on_nick_taken {

    my ($kernel) = $_[KERNEL];
    my $nick  = $config{nick};
    my $rnick = int( rand(999) );
    $kernel->post( 'poeb', 'nick', "$nick$rnick" );

}

# What to do if we can't connect..
sub irc_socketerr {
    my $err = $_[ARG0];
    serv_log("Couldn't connect to server: $err\n");
}

# I'll react to things in a public chan :-)
sub on_public {
    my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
    my $nick = ( split /!/, $who )[0];
    my $channel = $where->[0];
    my $ts      = scalar(localtime);
    chan_log("$channel%$ts%<$nick> $msg\n");

    if ( $msg =~ m/^\!ver$/i ) {
        $kernel->post( 'poeb', 'privmsg', $where, $config{ver1} );
    }
    if ( $msg =~ m/^\!help$/i ) {

        foreach (@mhelp) {
            $kernel->post( 'poeb', 'privmsg', $where, $_ );
        }
    }
    if ( $msg =~ m/^\!ping/i ) {
        $kernel->post( 'poeb', 'privmsg', $where, "Pong!" );

    }
    if ( $msg =~ m/^\!search/i ) {
        my @arg = split ( / /, $msg );
        if ( $arg[1] ) {
            my $msg1 = "$msg";
            $msg1 =~ s/\!search\s*//;
            $kernel->post( 'poeb', 'privmsg', $nick,
                "Top 10 URLs for \"$msg1\" from Google.com" );
            my $key    = "lXRqW/NQFHL81MleACQ1Whfa6oF4l3It";
            my $search = WWW::Search->new( 'Google', key => $key );
            my $match  = "0";
            $search->native_query("$msg1");
            $search->maximum_to_return(10);

            while ( my $result = $search->next_result() ) {
                $kernel->post( 'poeb', 'privmsg', $nick, $result->url );
                $match++;
            }
            $kernel->post( 'poeb', 'privmsg', $nick,
                "No results for \"$msg1\"! Please refine your search." )
              unless $match;
        }
        else {
            $kernel->post( 'poeb', 'privmsg', $channel, $help{'search'} );
        }
    }

    # Seen Stuff
    if ( $msg =~ m/^\!seen/i ) {
        my @arg = split ( / /, $msg );

        if ( $arg[1] ) {
            my $msg1 = "$msg";
            $msg1 =~ s/\!seen\s*//;

            if ( $msg1 eq $nick ) {
                $kernel->post( 'poeb', 'privmsg', $channel,
                    "They make drugs for that, $nick" );
            }
            elsif ( $msg1 eq $config{nick} ) {
                $kernel->post( 'poeb', 'privmsg', $channel,
                    "Silly Mortal, I'm right here, foo!" );
            }
            elsif ( defined $seen{$msg1} ) {
                $kernel->post( 'poeb', 'privmsg', $channel,
                    "Saw $msg1$seen{$msg1}." );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $channel,
                    "Haven't seen $msg1." );
            }
        }
        else {
            $kernel->post( 'poeb', 'privmsg', $channel,
                "Hey $nick, its like this: $help{'seen'}" );
        }
    }
    if ( $config{comon} == 1 ) {
        if ( $msg =~ m/^lol$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Thats pretty Funny $nick!" );
        }
        if ( $msg =~ m/^wtf\?/i ) {
            $kernel->post( 'poeb', 'privmsg', $where, "Hell if I know $nick!" );
        }
        if ( $msg =~ m/^lmao$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "It wasn't that funny $nick!" );
        }
        if ( $msg =~ m/^bbl$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Okay, $nick! Have Fun!" );
        }
        if ( $msg =~ m/^bbiaf$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Bring me back some, $nick!" );
        }
        if ( $msg =~ m/^brb$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Sure you will, $nick..." );
        }
        if ( $msg =~ m/linux/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Thats what I'm talking 'bout" );
        }
        if ( $msg =~ m/perl/i ) {
            $kernel->post( 'poeb', 'privmsg', $where, "#!/usr/bin/perl -w" );
        }
        if ( $msg =~ m/^\:\)$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Someone's smiling at me.." );
        }
        if ( $msg =~ m/^\;\)$/i ) {
            $kernel->post( 'poeb', 'privmsg', $where,
                "Wink, wink, nudge, nudge.." );
        }
    }
}

# When I receive a private message, I'm gonna Parse it for commands, and
# respond to interesting things.
sub on_msg {
    my ( $kernel, $who, $where, $msg ) = @_[ KERNEL, ARG0, ARG1, ARG2 ];
    my $nick = ( split /!/, $who )[0];
    my $channel = $where->[0];
    my $chann   = "#";

    my $ts = scalar(localtime);
    chat_log("$ts%msg%<$nick> $msg\n");

    my $access = 0;
    open( ACC, "$config{accfile}" ) || die "Bah: $!";
    my @plines = <ACC>;
    close(ACC);
    foreach my $line (@plines) {
        $line =~ s/\n+//;
        if ( $line eq $nick ) { $access = 1; last; }
    }

    if ( ( $access == 1 ) || ( $nick eq $config{owner} ) ) {

        if ( $msg =~ /$chann/i ) {
            $kernel->post( 'poeb', 'join', $msg );
        }
        if ( $msg =~ m/^help/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                if ( exists $help{ $arg[1] } ) {
                    $kernel->post( 'poeb', 'privmsg', $nick, $help{ $arg[1] } );
                }
                else {
                    $kernel->post( 'poeb', 'privmsg', $nick,
                        "Sorry! there is no help available for $arg[1]" );
                }
            }
            else {
                foreach (@help) {
                    $kernel->post( 'poeb', 'privmsg', $nick, $_ );
                }
            }
        }
        if ( $msg =~ m/^quit/i ) {
	    my @arg = split ( /"/, $msg );
	    unless ( $arg[1] ) {
              $kernel->call( 'poeb', 'quit', "$config{ver1}: $config{quitmsg}" );
	    }
	    else {
	      $kernel->call( 'poeb', 'quit', "$config{ver1}: $arg[1]" );
	    }
        }
        if ( $msg =~ m/^clear/i ) {
            my @arg = split ( / /, $msg );
            unless ( $arg[1] ) {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'clear'} );
            }
            else {
                if ( exists $config{ $arg[1] } ) {
                    unlink( $config{ $arg[1] } ) || warn "Damn: $!";
                    $kernel->post( 'poeb', 'privmsg', $nick,
                        "Cleared $arg[1]!" );
                    chat_log("$ts%notice%$nick cleared $arg[1]!\n");

                }
                elsif ( $arg[1] =~ m/^all$/i ) {
                    my @count = (
                        $config{botlog},  $config{chanlog},
                        $config{servlog}, $config{seenlog}
                    );
                    unlink(@count) || warn "Bah: $!";
                    $kernel->post( 'poeb', 'privmsg', $nick,
                        "Cleared All Logs!" );
                    chat_log("$ts%notice%$nick cleared all logs!\n");
                }
                else {
                    $kernel->post( 'poeb', 'privmsg', $nick,
                        "Sorry! I can't clear $arg[1] because it's not there!"
                    );
                    chat_log("$ts%notice%$nick tried to clear $arg[1]\n");
                }

            }
        }

        # Rehash that config file!
        if ( $msg =~ m/^rehash$/i ) {

            %config = ParseConfig(
                -ConfigFile => "$config{cpath}",
                AutoTrue    => 1
            );
            $kernel->post( 'poeb', 'privmsg', $nick, "Config Reloaded!" );
            chat_log("$ts%notice%<$nick> rehashed config file!]\n");

        }

        # If you want I'll say something to a channel you specify.     
        if ( $msg =~ m/^say/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/say\s*//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'privmsg', $arg[1], $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'say'} );
            }
        }

        # Someone's naughty, let's get rid of um
        if ( $msg =~ m/^kick/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/kick//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'kick', $arg[1], $arg[2], $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'kick'} );
            }
        }

        # Someone's Been REAL bad
        if ( $msg =~ m/^ban/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/ban//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '+b', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'ban'} );
            }
        }

        # Someone's was forgiven..
        if ( $msg =~ m/^unban/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/unban//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '-b', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'unban'} );
            }
        }

        # Someone's been good, lets reward um
        if ( $msg =~ m/^op/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/op//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '+o', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'op'} );
            }
        }

        # Someone's abusing power, empeach!
        if ( $msg =~ m/^deop/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/deop//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '-o', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'deop'} );
            }
        }

        # Lets make someone "Sorta Powerful"
        if ( $msg =~ m/^hop/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/hop//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '+h', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'hop'} );
            }
        }

        # They don't deserve it ne more..
        if ( $msg =~ m/^dehop/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/dehop//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '-h', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'dehop'} );
            }
        }

        # And god said, +v
        if ( $msg =~ m/^voice/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/voice//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '+v', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'voice'} );
            }
        }

        # Then god got tired of listening to you..
        if ( $msg =~ m/^devoice/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/devoice//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'mode', $arg[1], '-v', $msg1 );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'devoice'} );
            }
        }

        # I don't like that chan, lets leave
        if ( $msg =~ m/^part/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/part//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'part', $arg[1] );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'part'} );
            }
        }

        # Go away!
        if ( $msg =~ m/^away/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/away//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'away', $arg[1] );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'away'} );
            }
        }

        # Come back!
        if ( $msg =~ m/^back/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/$arg[1]//;
                $msg1 =~ s/back//;
                $msg1 =~ s/\n+//;
                $kernel->post( 'poeb', 'away' );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'back'} );
            }
        }

        # Lets Search Google!
        if ( $msg =~ m/^search/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                my $msg1 = "$msg";
                $msg1 =~ s/search\s*//;
                $kernel->post( 'poeb', 'privmsg', $nick,
                    "Top 10 URLs for \"$msg1\" from Google.com" );
                my $key    = "lXRqW/NQFHL81MleACQ1Whfa6oF4l3It";
                my $search = WWW::Search->new( 'Google', key => $key );
                my $match  = "0";
                $search->native_query("$msg1");
                $search->maximum_to_return(10);

                while ( my $result = $search->next_result() ) {
                    $kernel->post( 'poeb', 'privmsg', $nick, $result->url );
                    $match++;
                }
                $kernel->post( 'poeb', 'privmsg', $nick,
                    "No results for \"$msg1\"! Please refine your search." )
                  unless $match;
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'search'} );
            }
        }

        # Add someone to my userlist
        if ( $msg =~ m/^adduser/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                open( ACC, ">>$config{accfile}" ) || die "Bah: $!";
                print ACC "$arg[1]\n";
                close(ACC);
                $kernel->post( 'poeb', 'privmsg', $nick, "$arg[1] added!" );
                $kernel->post( 'poeb', 'privmsg', $arg[1], $config{newusr} );
                chat_log("$ts%notice%$nick added access rights for $arg[1]\n");
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'adduser'} );
            }
        }

        # Take'um out
        if ( $msg =~ m/^deluser/i ) {
            my @arg = split ( / /, $msg );
            if ( $arg[1] ) {
                open( ACC, "$config{accfile}" ) || die "Bah: $!";
                my @stuff = grep { !/^$arg[1]/i } <ACC>;
                open( OUT, ">$config{accfile}" ) || die "Bah: $!";
                print OUT @stuff;
                close(ACC);
                close(OUT);
                $kernel->post( 'poeb', 'privmsg', $nick, "$arg[1] Deleted!!" );
                $kernel->post( 'poeb', 'privmsg', $arg[1],
                    "Your Access Has Been Removed" );
            }
            else {
                $kernel->post( 'poeb', 'privmsg', $nick, $help{'deluser'} );
            }
        }
    }
    else {
        $kernel->post( 'poeb', 'privmsg', $nick,
"Access Denied, please see http://perlb.dsirc.net/index.pl?action=feat for help"
        );
        chat_log("$ts%notice%<$nick> Tried to access me!\n");
    }
}

sub on_disco {

    exit;
}

# Run the bot until it is done.
$poe_kernel->run();

# Open up my chatlog partner..
sub chat_log {
    my $stuff = "@_";
    open( LOG, ">>$config{botlog}" )
      || warn "Can't open $config{botlog} [$!]\n";
    print LOG "$stuff";
    close(LOG) || warn "Can't close $config{botlog} $!\n";
}

sub chan_log {
    my $stuff = "@_";
    open( CHAN, ">>$config{chanlog}" )
      || warn "Can't open $config{chanlog} [$!]\n";
    print CHAN "$stuff";
    close(CHAN) || warn "Can't close $config{chanlog} $!\n";
}

sub serv_log {
    my $stuff = "@_";
    open( LOG, ">>$config{servlog}" )
      || warn "Can't open $config{servlog} [$!]\n";
    print LOG "$stuff";
    close(LOG) || warn "Can't close $config{servlog} $!\n";
}

sub save_seen {
    open( FILE, ">>$config{seenlog}" );

    for ( keys %seen ) {
        print FILE "$_\n$seen{$_}\n";
    }

    close FILE;
}

sub seen_log {
    my ( $who, $message ) = @_;

    if ( $who eq $config{nick} ) {
        return;
    }
    $seen{$who} = " " . $message . " on " . scalar(localtime);

    save_seen();
}
exit 0;

=pod

=head1 NAME

poeb.pl - v.3.4

=head1 SYNOPSIS

poeb was written to accomodate the needs of some users on my irc server.
It is designed to be functional, portable, and configurable by any user
with the desire.  This program takes advantage of a few established Perl 
modules.  These modules include:

 POE                                                                            
 POE::Component::IRC                                                            
 Config::General                                                                
 Proc::Daemon                                                                   
 WWW::Search
 Strict                                                                         
 Warnings                                                                       

These Modules ensure that this program compiles with the least errors, and 
as efficiantly as possible.  Included with the release is a configuration 
file.  In this file is ton's of juicy goodness for you to mess with, in 
fact, the bot won't start unless you do mess with it.  Just don't mess too 
much, or you could mess something up..  ;-)

For more information, see the Docs included with this release.

This program is free software; you can use it, redistribute, and/or
modify it under the same terms as Perl itself.

=head1 USAGE/OPTIONS

Usage:

$ ./poeb.pl

=head2 PUBLIC INTERACTIVE COMMANDS

=over

More To Come:

 This bot responds to the following public commands.

=item !ver

Print Current Version Info

=item !help

Print This Help File

=item !search <string>               

Search Google for top 10 URLs for string

=item !seen <nick>

Displays last seen activity for <nick>

=back

=head2 PRIVATE MESSAGE COMMANDS
 
 This bot responds to the following private message commands.

=over

=item #<chan>

Joins Specfied channel

=item op <chan> <nick>

Ops Specified Nick on Current Channel

=item deop <chan> <nick>

Does the Opposite of Above

=item hop <chan> <nick>

Gives Specified User a %(Half Op)

=item dehop <chan> <nick>

Does the Opposite of Above

=item voice <chan> <nick>

Gives Specified User a Voice for +m Chan

=item devoice <chan> <nick>

Does the Opposite of Above

=item kick <chan> <nick> <reason>

Kicks Specified User with Specified Reason

=item ban <chan> <user@host> 

Bans  Specified user@host from channel

=item unban <chan> <user@host>   

Un-Bans user@host from channel

=item say <chan> <enter text here> 

Say something witty to the chan

=item part <chan>

Part Specified Channel

=item away <msg>

Puts bot in "away" status

=item back

Leaves the "away" status

=item clear <logname>

Clears Log File

 Log Names Include:
 botlog  eq Bot Interaction log
 chanlog eq Channel Log
 servlog eq Server Log
 seenlog eq Seen Log
 all	 eq All Of Above!

=item search <phrase>

Search Google for top 10 URLs for string 

=item adduser

Adds User To Access List

=item deluser

Opposite of above ;)

=item quit

Quits Server with a witty quit message which can be edited in the config

=item help

Prints a help message simmilar to this with a list of commands

=back

    These commands are reserved for bot owners and admin


All these commands are limited to access rights.  If you don't have
access, it won't work.  But your reading this, so your probably the owner,
if you configure things right, you should have access.


=head1 AUTHOR(s) CONTACT(s)


Brandon Himpfen<lt>bhimpfen@hotmail.com<gt>

DeFyance, E<lt>defyance@dsirc.netE<gt>


 last modified: 11/27/02

=cut

