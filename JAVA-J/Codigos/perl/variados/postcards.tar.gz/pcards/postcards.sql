# Creates the database "pcards" and therein the tables
# "postcards" and "senders"

CREATE DATABASE /*! IF NOT EXISTS*/ ppcards;

USE ppcards;

#
# Table structure for table 'postcards'
#

CREATE TABLE /*! IF NOT EXISTS*/ postcards (
  id int(11) NOT NULL default '0',
  sender mediumint(8) unsigned NOT NULL default '0',
  recipient varchar(60) NOT NULL default '',
  remail varchar(50) NOT NULL default '',
  card varchar(50) NOT NULL default '',
  greeting varchar(60) NOT NULL default '',
  message text,
  bg_color varchar(20) NOT NULL default '',
  text_color varchar(20) NOT NULL default '',
  sdate date NOT NULL default '0000-00-00',
  in_date date NOT NULL default '0000-00-00',
  retrieved smallint(6) NOT NULL default '0',
  mod_time timestamp(14) NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Table structure for table 'senders'
#

CREATE TABLE /*! IF NOT EXISTS*/ senders (
  id mediumint(8) unsigned NOT NULL auto_increment,
  sender varchar(60) NOT NULL default '',
  semail varchar(50) NOT NULL default '',
  mod_date timestamp(14) NOT NULL,
  cards smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

