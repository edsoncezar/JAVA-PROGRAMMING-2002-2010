#!/usr/bin/perl -w

use strict;
use DBI;

# Put the full path to the setup file here
require "/var/www/cgi-bin/pcards/pcard-setup.pl";

# Import database access variables from setup file:
use vars qw($driver $server $port $database $db_user $db_pass);

my $today = &get_date;

# Connect to the database
my $dbh = DBI->connect("DBI:$driver:$database:$server:$port",$db_user,$db_pass);
           die "DBI error from connect:", $DBI::errstr unless $dbh;

# Make the SQL query
my $command = "select id, recipient, remail from postcards where sdate = \"$today\" and retrieved = \"-1\"";

# Send the SQL query to the database, catch the errors
my $sth = $dbh->prepare($command);
           die "DBI error with prepare:", $sth->errstr unless $sth;

my $result = $sth->execute;
           die "DBI error with execute:", $sth->errstr unless $result;

while (my ($id, $recipient, $remail) = $sth->fetchrow){

    &pcard_notification($remail,$recipient,$id);

    my $commanda = "update postcards set retrieved = '0' where id = $id";

    my $stha = $dbh->prepare($commanda);
           die "DBI error with prepare:", $sth->errstr unless $sth;

    my $resulta = $stha->execute;
           die "DBI error with execute:", $sth->errstr unless $result;

    $stha->finish;
}

$sth->finish;
$dbh->disconnect;

# Purge the database of old postcards
&purge_db;

exit;

































