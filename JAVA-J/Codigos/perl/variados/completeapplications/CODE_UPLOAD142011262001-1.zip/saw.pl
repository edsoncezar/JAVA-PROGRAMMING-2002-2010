#change these paths to reflect your files on unix use /path/to/file/

$mailit = "User.mail";
$mail_file = "E:\\inetpub\\wwwroot\\arcta\\apps\\mem\\" . $mailit;

$sendmail = 'E:\\inetpub\\wwwroot\\apps\\sendmail.exe';

$sender = 'freebies@freebienews.com';
$subject = "Freebie Hunters News";

$efile = "a.txt";
$emar = "E:\\inetpub\\wwwroot\\apps\\" . $efile;



open (BANDFIT, "$emar") || die "Can't Open $emar";

while(<BANDFIT>)	{

($ID,
 $options) = split(/\|/,$_);
chop($options);
  foreach ($ID) {


$recipient = $ID;






open(MAIL, ">$mail_file");
    print MAIL "To: $recipient";
    print MAIL "From: $sender\n";
    print MAIL "Subject: Freebie Hunters News\n\n\n" ;
    print MAIL "Hi Jenniffer if finding free products is your thing.\n";
    print MAIL "Then I have some great news for you\n";
    print MAIL "I would like to inform you about the existence \n";
    print MAIL "of what promises to be the most comprehensive\n";
    print MAIL "freebies resource in the world today\n";
    print MAIL "http://texweb.cableone.net/htdocs/board/\n";
    print MAIL "\n";
    print MAIL "\n";
    print MAIL "\n";
    print MAIL "P.S.\n";
    print MAIL "Visit by March 1st 2001 and you could win a \$25 Amazon.com gift certificate\n";
    print MAIL "\n";
	    close (MAIL);
system("$sendmail -t -messagefile=$mail_file");





}

}
close(BANDFIT);