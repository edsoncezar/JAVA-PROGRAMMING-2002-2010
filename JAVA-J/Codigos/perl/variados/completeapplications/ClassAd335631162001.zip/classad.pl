#!/usr/bin/perl5

####################################################################################################
# On a unix system, make sure the first line has the true path to perl 5
# on your system!
#
# classad.cgi
#
# Version 1.0, Friday, October 19, 2001
#
# By Glen Yeager | scripts@distantrealm.com | http://www.distantrealm.com
#
# For more recent version of this script, download from sites.
# For customization of this script or other cgi you require, contact
# Glen Yeager at the address above. (that's not free!!)
#
# COPYRIGHT NOTICE:
#
# Copyright 2001, Glen Yeager  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  By using this program
# you agree to indemnify Glen Yeager and Distantrealm. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
#
# Requirements: 	The provided db-lib.pl file placed in the same directory as this file.
#				Perl 5.0 or higher.
#
#
#
####################################################################################################
# Configuration Variables that need to be customized for each application.
#
# require "c:\\Inetpub\\wwwroot\\cgi\\db-lib.cgi";			-  Absolute path to the CGI directory/db-lib file
# $pagetitle="Distantrealm Swap Shop";				-  Your Page's Title
# $data_file="c:\\Inetpub\\wwwroot\\cgi\\datafile.txt";		-  Text flat file Db name and path.
# $item_file="c:\\Inetpub\\wwwroot\\cgi\\item.txt";			-  Record number tracking file location.
# $table_bgcolor ="Lime";						-  Standard Table background color.
# $head_bgcolor = "Yellow";					-  Table header background color.
# $bgimage="/hillback.jpg";					-  Page background image/location.
# $body_bgcolor="lt blue";					-  Page Body background color.
# $title_color ="blue";						-  Title Font Color.
# $script_location="/cgi-bin/classad.pl";				-  Script location/URL.
#
# Edit the @categories line to reflect the catagories that you need and will use in your application.
#
# i.e. -  @categories=("R/C Planes","R/C Cars","C/L Planes","Radios","Motors","General","R/C Electric");
#
####################################################################################################

require "c:\\Inetpub\\wwwroot\\cgi\\db-lib.cgi";
$pagetitle="Distantrealm Swap Shop";
$data_file="c:\\Inetpub\\wwwroot\\cgi\\datafile.txt";
$item_file="c:\\Inetpub\\wwwroot\\cgi\\item.txt";
$table_bgcolor ="Lime";
$head_bgcolor = "Yellow";
$bgimage="/hillback.jpg";
$body_bgcolor="lt blue";
$title_color ="blue";
$script_location="/cgi-bin/classad.pl";
@categories=("R/C Planes","R/C Cars","C/L Planes","Radios","Motors","General","R/C Electric");

####################################################################################################
# 			**	DO NOT EDIT BELOW THIS LINE!	**
####################################################################################################

print "Content-type: text/html\n\n";
&parse_form;
print &set_header;
$action = $FORM{'action'};

CASE:
{
	($action eq 'ADD') and do
	{
		$Posted = scalar(localtime());
		$FORM{'Description'} =~ tr/\n/~/;
		@newrec=($FORM{'Category'},$FORM{'Itemname'},$FORM{'Description'},$FORM{'Price'},$FORM{'Phone'},$FORM{'Email'},$FORM{'State'},$FORM{'Password'},$Posted);
		&add_record(@newrec);
	};
	
	
	($action eq 'ADDITEM') and do
	{
		print qq~
			<form action="$script_location" method="post">
			<table border=1 width=75% align=center bordercolor=Black cellspacing=0 cellpadding=2 bgcolor=$table_bgcolor>
			<tr><td bgcolor=$head_bgcolor colspan=2>
			<font size=4><b>Add New Item</b></font>
			</td></tr>
			<tr><td width=25% valign=top>Item Name:</td><td >&nbsp;<input type="text" name="Itemname" size="20" maxlength="20" value=""></td></tr>
			<tr><td width=25% valign=top>Description:</td><td >&nbsp;<textarea name="Description" rows="3" cols="50"></textarea></td></tr>
			<tr><td width=25%>Category:</td><td >&nbsp;
		~;
		
		&set_option_selected($Category);
		print qq~
			</td></tr>
			<tr><td width=25%>Price:</td><td >&#36;&nbsp;<input type="text" name="Price" size="10" maxlength="20" value=""></td></tr>
			<tr><td width=25%>Phone:</td><td >&nbsp;<input type="text" name="Phone" size="20" maxlength="20" value=""></td></tr>
			<tr><td width=25%>Email:</td><td >&nbsp;<input type="text" name="Email" size="40" maxlength="20" value=""></td></tr>
			<tr><td width=25%>State:</td><td >&nbsp;<input type="text" name="State" size="10" maxlength="20" value=""></td></tr>
			<tr><td width=25%>Password:</td><td >&nbsp;<input type="password" name="Password" size="10" maxlength="20" value=""></td></tr>
			</table><p>
			<input type="hidden" name="action" value="ADD">
			<center><input type="submit" value="Add Item"></center>
			</form>
			~;
		&set_footer;
		last CASE;
	};
	
	
	($action eq 'DETAIL') and do
	{
		($found,@records_found) = &get_record('0',$FORM{'Item'});
		foreach $item (@records_found)
		{
			($Item,$Category,$Itemname,$Description,$Price,$Phone,$Email,$State,$Password,$Posted)=split(/\|/, $item);
			$Description =~ tr/~/\n/;
			print qq~
				<center><b><font size="+2"><br>Item Detail</font></b></center>
				<form action="$script_location" method="post">
				<table border=1 width=75% Align=center bordercolor=Black cellspacing=0 cellpadding=2 bgcolor=$table_bgcolor>
				<tr><td bgcolor=$head_bgcolor colspan=2>
				<font size=4><b>$Itemname</b></font>
				</td></tr>
				<tr><td width=25% valign=top>Description:</td><td>$Description</td></tr>
				<tr><td width=25%>Price:</td><td>&#36;$Price</td></tr>
				<tr><td width=25%>Phone:</td><td>$Phone</td></tr>
				<tr><td width=25%>Email:</td><td><a href="mailto:$Email">
				$Email</a></td></tr>
				<tr><td width=25%>Location:</td><td>$State</td></tr>
				<tr><td width=25%>Posted Date:</td><td>$Posted</td></tr>
				</table><p>
				<input type="hidden" name="Item" value="$Item">
				<center><b>Enter the password to <br>edit or delete this item:</b><br><input type="password" name="Password" size="20" maxlength="20" value=""><br><br>
				<input  type="submit" value="BACK">&nbsp;
			<input name="action" type="submit" value="EDIT DETAIL">&nbsp;
			<input type="submit" name="action" value="DELETE">
				</center>
				</form>
				~;
		}
		&set_footer;
		last CASE;
	};
	
	
	($action eq 'DELETE') and do
	{
		($found,@records_found) = &get_record('0',$FORM{'Item'});
		if ($found){
			foreach $item (@records_found)
			{
				($Item,$Category,$Itemname,$Description,$Price,$Phone,$Email,$State,$Password,$Posted)=split(/\|/, $item);
				if($FORM{'Password'} eq $Password)
				{
					&delete_record($FORM{'Item'});
				}
				else
				{
					print qq~
						<b><font size="+2"><center>Invalid Password!</center></font></b>
						~;
				}
			}
		}
		else
		{
			print qq~
				<b><font size="+2"><center>Record not Found!</center></font></b>
				~;
		}
		
		# last CASE;
	};
	
	
	($action eq 'EDIT') and do
	{
		$FORM{'Description'} =~ tr/\n/~/;
		@newrec=($FORM{'Category'},$FORM{'Itemname'},$FORM{'Description'},$FORM{'Price'},$FORM{'Phone'},$FORM{'Email'},$FORM{'State'},$FORM{'Password'},$FORM{'Posted'});
		&edit_record($FORM{'Item'},@newrec);
		# last CASE;
	};
	
	($action eq 'EDIT DETAIL') and do
	{
		($found,@records_found) = &get_record('0',$FORM{'Item'});
		if ($found){
			foreach $item (@records_found)
			{
				($Item,$Category,$Itemname,$Description,$Price,$Phone,$Email,$State,$Password,$Posted)=split(/\|/, $item);
				$Description =~ tr/~/\n/;
				if($FORM{'Password'} eq $Password)
				{
					print qq~
						<form action="$script_location" method="post">
						<table border=1 width=75% align=center bordercolor=Black cellspacing=0 cellpadding=2 bgcolor=$table_bgcolor>
						<tr><td bgcolor=$head_bgcolor colspan=2>
						<font size=4><b>Edit Item detail</b></font>
						</td></tr>
						<tr><td width=25% valign=top>Item Name:</td><td >&nbsp;<input type="text" name="Itemname" size="20" maxlength="20" value="$Itemname"></td></tr>
						<tr><td width=25% valign=top>Description:</td><td >&nbsp;<textarea name="Description" rows="3" cols="50">$Description</textarea></td></tr>
						<tr><td width=25%>Category:</td><td >&nbsp;~;
					#print $Category;
					&set_option_selected($Category);
					print qq~
						</td></tr><tr><td width=25%>Price:</td><td >&#36;&nbsp;<input type="text" name="Price" size="10" maxlength="20" value="$Price"></td></tr>
						<tr><td width=25%>Phone:</td><td >&nbsp;<input type="text" name="Phone" size="20" maxlength="20" value="$Phone"></td></tr>
						<tr><td width=25%>Email:</td><td >&nbsp;<input type="text" name="Email" size="40" maxlength="20" value="$Email"></td></tr>
						<tr><td width=25%>State:</td><td >&nbsp;<input type="text" name="State" size="10" maxlength="20" value="$State"></td></tr>
						<input type="hidden" name="Password" value="$Password">
						</table><p>
						<input type="hidden" name="Posted" value="$Posted">
						<input type="hidden" name="Item" value="$Item">
						<center><input type="submit" name="action" value="EDIT"></center>
						</form>
						~;
					
					
				}
				else
				{
					print qq~
						<b><font size="+2"><center>Invalid Password!</center></font></b>
						~;
				}
			}
		}
		else
		{
			print qq~
				<b><font size="+2"><center>Record not Found!</center></font></b>
				~;
		}
		&set_footer;	
		last CASE;
	};
	
	
	
	($action eq 'GETCATAGORY') and do
	{
		
		($found,@records_found) = &get_record('1',$FORM{'category'});
		if (!($found))
		{
			print qq~
				<font size="+3"><br><br><b><center>No Items found in this catagory!</center></b></font><br><br>
				~;
		}
		else
		
		{
			print qq~
				<br><center><font size="+1">$found Items found in the $FORM{'category'} category.<br><br></font></center>
				<table border=2 Align=center width=75% bordercolor=Black cellspacing=0 cellpadding=2 bgcolor=$table_bgcolor>
				<tr><td bgcolor=$head_bgcolor colspan=2 width=5%>
				<font size=4><b>Item</b></font>
				</td>
				<td width=35% bgcolor=$head_bgcolor><b>Item Name</B></td>
				<td width=15% bgcolor=$head_bgcolor><b>Price</b></td>
				<td width=10% bgcolor=$head_bgcolor><b>State</b></td>
				<td width=15% bgcolor=$head_bgcolor><b>Date Posted</b></td></tr>
			
			
			~;
			foreach $item (@records_found)
			{
				($Item,$Category,$Itemname,$Description,$Price,$Phone,$Email,$State,$Password,$Posted)=split(/\|/, $item);
				$Description =~ tr/~/\n/;
				print qq~
					<tr><td bgcolor=$head_bgcolor colspan=2 width=5%>
					<font size=4><b><a href="$script_location?action=DETAIL&Item=$Item">$Itemname</a></b></font>
					</td>
					<td width=35% >$Description</td>
					<td width=15%>&#36; $Price</td>
					<td width=10%>$State</td>
					<td width=15%>$Posted</td></tr>
					~;
				
			}
			print"\<\/table\>";
		}
		&set_footer;
		last CASE;
	};
	
	
	($action eq 'SEARCH') and do
	{
		
		($found,@records_found) = &search_records($FORM{'search'});
		if (!($found))
		{
			print qq~
				<font size="+3"><br><br><b><center>No Items found!</center></b></font><br><br>
				~;
		}
		else
		
		{
			print qq~
				<br><center><font size="+1">$found Items found matching $FORM{'search'}.<br><br></font></center>
				<table border=2 Align=center width=75% bordercolor=Black cellspacing=0 cellpadding=2 bgcolor=$table_bgcolor>
				<tr><td bgcolor=$head_bgcolor colspan=2 width=5%>
				<font size=4><b>Item</b></font>
				</td>
				<td width=35% bgcolor=$head_bgcolor><b>Item Name</B></td>
				<td width=15% bgcolor=$head_bgcolor><b>Price</b></td>
				<td width=10% bgcolor=$head_bgcolor><b>State</b></td>
				<td width=15% bgcolor=$head_bgcolor><b>Date Posted</b></td></tr>
			
			
			~;
			foreach $item (@records_found)
			{
				($Item,$Category,$Itemname,$Description,$Price,$Phone,$Email,$State,$Password,$Posted)=split(/\|/, $item);
				$Description =~ tr/~/\n/;
				print qq~
					<tr><td bgcolor=$head_bgcolor colspan=2 width=5%>
					<font size=4><b><a href="$script_location?action=DETAIL&Item=$Item">$Itemname</a></b></font>
					</td>
					<td width=35% >$Description</td>
					<td width=15%>&#36; $Price</td>
					<td width=10%>$State</td>
					<td width=15%>$Posted</td></tr>
					~;
				
			}
			print"\<\/table\>";
		}
		&set_footer;
		last CASE;
		
	};
	
	
	do{
		&show_catagory_list;
		&set_footer;
		last CASE;
	};
};



sub set_header
{
	$page_header = qq~
	
	<!doctype html public "-//w3c//dtd html 3.2//en">
	
	<html>
		<head>
		<title>$pagetitle</title>
		<meta name="GENERATOR" content="Arachnophilia 4.0">
		<meta name="FORMATTER" content="Arachnophilia 4.0">
		</head>
	
	<BODY BACKGROUND="$bgimage" bgcolor="$body_bgcolor">
		<table border=2 cellspacing=0 align=center cellpadding=3 width=90% bordercolor=Black bgcolor=$head_bgcolor>
		<tr><td width=50% align=center rowspan=2>
		<font size=6 color="$title_color"><b><i>$pagetitle</b></i></font>
		</td>
	
	<td width=20% colspan=2 align=center valign=center><a href="$script_location?action=ADDITEM"><font face="Arial,Helvetica" size=2>Enter A New Ad</font>
		</td>
	
	<td width=30% align=center valign=center>
		<form action="$script_location" method="post">
		<input type="text" name="search" size="20" maxlength="30" value=""><br><input name="action" type="submit" value="SEARCH">
		</td>
	
	</form>
	
	</tr>
		</table><br>
	
	~;
	
	return($page_header);
}

sub show_catagory_list
{
	print qq~
		<br>
		<center><b><font size="+3"><font color=#800000>Please Select A Category</font></font></b></center><br>
		<br>
	
	<table  Align=Center width="90%" border="1" cellspacing="0" cellpadding="4" bordercolor=Black bgcolor=$table_bgcolor>
		<tr>
		<!-- Row 1 Column 1 -->
		<td  bgcolor=$head_bgcolor>
		<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Category</b>
	
	</td>
		<!-- Row 1 Column 2 -->
		<td  align="center" bgcolor=$head_bgcolor>
		<b> Items</b>
		</td>
		</tr><tr></tr>
		~;
	
	$afield_num = 1;
	print "\<center\>\n";
	foreach $cat (@categories)
	{
		
		($found,@records_found)=&get_record($afield_num,$cat);
		$catcmd=$cat;
		$catcmd=~ s/ /'%20'/eg;
		print qq~
			<tr><td width=60%><font size=3 color=blue>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=$script_location?category=$catcmd&action=GETCATAGORY>$cat</a></font></td><td align="center" width=20%>$found</td></tr>
				~;
	}
	
	print"\<\/table\>";
}

sub set_option_selected
{
	my($catval)=@_;
	
	print "\<select name\=\"Category\">\n";
	foreach $cat (@categories)
	{
		
		if ($cat ne $catval)
		{
			print "<option>$cat\n";
		}
		else
		{
			print "<option selected>$cat\n";
		}
			
	}
	
	print "\<\/select>\n";
	
}

sub set_footer
{
	print qq~
<br><br>
		</body>
		</html>
		~;
}


