#!/usr/bin/perl -w




use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);


# You are requested not to change any configurations in this file.
# Everything is setup to function as-is, any tamporing may damage
# the script.

require SDBM_File;

my %emails;

my $snail     = "snail.dbm";  #change to location of snail mail database
my $list      = "mylist.dbm"; #change to location of email database

tie %emails, 'SDBM_File', $list, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
    }


print header, start_html('Email Management');


if(param()){
    my $email   = param('email');
    my $name    = param('name');
    my $add1 = param('add1');
    my $add2 = param('add2');
    my $city = param('city');
    my $zip  = param('zip');
    my $country = param('country');
    

if (($name) && ($email)) {
  if (exists $emails{$email}) {
     print "<center><b>Email already exists in mailing list</b></center>";
  } else {
   $name =~ s/</&lt\;/g;
   $add1 =~ s/</&lt\;/g;
   $add2 =~ s/</&lt\;/g;
   $city =~ s/</&lt\;/g;
   $zip =~ s/</&lt\;/g;
   $country =~ s/</&lt\;/g;

$name =~ s/:/&\#58\;/g;
$add1 =~ s/:/&\#58\;/g;
$add2 =~ s/:/&\#58\;/g;
$city =~ s/:/&\#58\;/g;
$zip =~ s/:/&\#58\;/g;
$country =~ s/:/&\#58\;/g;

     my $info = join("::", $name, $add1, $add2, $city, $zip, $country);
     $emails{$email} = $info;
     print "<center>Your information was submitted!</center>";
exit;
  }
} else {
  if ($name) {
     print "<center><b>Your email address was missing</b></center>";
  } elsif ($email) {
     print "<center><b>name is missing</b></center>";
  } else {
     print "<center><b>You can't submit an empty form</b></center>";
  }
}
}

my $name = param('name');
my $email = param('email');
my $add1 = param('add1');
my $add2 = param('add2');
my $city = param('city');
my $zip  = param('zip');
my $country = param('country');
			
print <<"END";

<form method="post" action="">
  <table width="465" border="0" align="center">
    <tr bgcolor="#666666">
      <td colspan="3"><div align="center" class="style1">Join our mailing list </div></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">Name:</td>
    </tr>
    <tr>
    <td colspan="3"><input name="name" value="$name" type="text" id="name" size="40" /></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">Email:</td>
    </tr>
    <tr>
    <td colspan="3"><input name="email" type="text" value="$email" id="email"  size="40" /></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">Address line 1:</td>
    </tr>
    <tr>
      <td colspan="3"><input name="add1" type="text" value="$add1" id="add1"  size="40" /></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">Address line 2:</td>
    </tr>
    <tr>
      <td colspan="3"><input name="add2" type="text" value="$add2" id="add2"  size="40" /></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">City/State:</td>
    </tr>
    <tr>
      <td colspan="3"><input name="city" type="text" value="$city" id="city"  size="40" /></td>
    </tr>
    <tr>
      <td width="99" bgcolor="#CCCCCC">Zip Code: </td>
      <td colspan="2" bgcolor="#CCCCCC">Country:</td>
    </tr>
    <tr>
      <td><input name="zip" type="text" id="zip" value="$zip" size="5" /></td>
      <td colspan="2"><input name="country" type="text" value="$country" id="country"  size="23" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td width="174"><div align="center">
</td>
      <td width="170"><input type="submit" name="submit" /></td>
    </tr>
    <tr>
      <td colspan="3"><p class="style2">&nbsp;</p>
        <p class="style2">* To remove yourself from our lists, only the email address is required to process your request.</p>
      <p class="style2">* By submitting your information, you are granting us permission to mail you on occasion, not to sell it for profit. </p></td>
    </tr>
  </table>
</form>


END


            print end_html();







