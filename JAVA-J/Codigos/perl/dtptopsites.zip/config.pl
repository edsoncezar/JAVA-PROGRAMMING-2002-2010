#!/usr/bin/perl
######################################################
# Deep Thought Productions
# DTP Topsites V1.1 Freeware
#
# This Script may be freely modified, and used as long
# as this header and links to Animelab.com remain!
# Please read licence.txt and disclaimer.txt which WAS
# included with this package. If these files are missing
# Delete this script, and package imediatly and download
# the original from http://www.animeland.net/cgi
# If you do not agree with the licence terms or disclaimer
# then also delete this script and package imediatly!
# 
# (c) Deep Thought Productions 2000
# http://www.animelab.com
######################################################

### How to configure this script
# The configuration of this script is fairly easy
# 1 and 0 are used as booleans where 1 is on and 0 is off
# Colours should be self explanitory if you have some Basic HTML knoledge
# If you are unsure of what things do, then just have a little play or
# Refer to the Read me!

### General Configuration

# The name of your Topsites
$tname = "Your Topsites Name";

# Your E-mail address (keep the \ before the @)
$yemail = "webmaster\@somewhere.ext";

# Number of Ranks to Show
$trank = "50";

# If your site gains more members than the rank list holds
# shall i make more pages and place the goto page box on the topsites?
$multipage = "1";

# Show members site description?
$showdes = "1";

# Show Visitors the Full Stats of the ranked sites?
$stats = "1";

# Max number of banners to show
$ban = "0";

# Banner Type 1 = Static, 0 = One for each position
$bantype = "0";

# If last option = 0 then how many banners are there?
$numban = "50";

# Are they .jpg or .gif?
$banext = ".gif";

# URL to there directory?
$banloc = "http://www.yoursite.ext/topimg";

# If the banner type is static then whats the URL to the banner?
$bannerurl = "http://www.yoursite.ext/banner.gif";

# How often shall we update the ranking (in seconds)
# i recomend a minuite (60)
$refresh = "60";

# Use file locking (Disable this if you get file lock errors)
$uflock = "1";

# Location of your mail program (to disable just leave this blank)
$mail = "/usr/lib/sendmail";

### URLs and Paths

# Path to where topsites.html will be crated
$htmlpath = "./";

# Path to where the CGI scripts will be
$cgipath = "./";

# URL to where topsites.html will be crated
$htmlurl = "http://www.yoursite.ext/topsites";

# URL to where the cgi scripts are stored
$cgiurl = "http://www.yoursite.ext/cgi-bin/topsites";

### Colours & font

# Main Font
$font = "Tahoma, Arial, Helvetica, Georgia, sans-serif";

# Ranklist Table Background and text Colour and size
$tbg = "White";
$ttext = "Black";
$tsize = "1";

### STAMP ###
# DO NOT REMOVE THIS LINE!
$stamp = "<center><font face=\"Tahoma, Arial, Helvetica, sans-serif\" size=1>Powered by <a href=\"http://www.animelab.com/cgi/topsites.shtml\">DTP Topsites Free</a></font></center>";