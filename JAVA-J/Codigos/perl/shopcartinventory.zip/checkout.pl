#!/usr/bin/perl
#=====================================================================||
#               NOP Design JavaScript Shopping Cart                   ||
#                     PERL CGI Checkout Module                        ||
#                                                                     ||
# For more information on SmartSystems, or how NOPDesign can help you ||
# Please visit us on the WWW at http://www.nopdesign.com              ||
#                                                                     ||
# Javascript portions of this shopping cart software are available as ||
# freeware from NOP Design.  You must keep this comment unchanged in  ||
# your code.  For more information contact FreeCart@NopDesign.com.    ||
#                                                                     ||
# JavaScript Shop Module, V.4.4.0                                     ||
#=====================================================================||
#                                                                     ||
#  Function: Writes available form elements from the NOP              ||
#            Free Cart (http://www.nopdesign.com/freecart)            ||
#            and other form elements to an email file, and            ||
#            send user confirmation                                   ||
#                                                                     ||
#=====================================================================||
require 5.001;
print "Content-type: text/html\n\n";
########################################################################
#                                                                      #
#  User defined variables:                                             #
#      $header        - string value containing the complete           #
#                       path of the HTML page header                   #
#      $footer        - string value containing the complete           #
#                       path of the HTML page footer                   #
#      $mailprogram   - string value containing the complete path to   #
#                       the sendmail binary on the system.             #
#      $youremail     - string value containing the email address to   #
#                       send catalog orders in EMAIL or BOTH modes     #
#                       **Don't forget to put a \ before the @ in your #
#                       email address. ie. spam\@nopdesign.com***      #
#      $returnpage    - URL to send user when checkout is complete     #
#      $csvfilename   - string value containing the complete           #
#                       path of the user database.                     #
#      $csvquote      - string value containing what to use for quotes #
#                       in the csv file (typically "" or \")           #
#      $mode          - string value containing 'EMAIL', 'FILE' or     #
#                       'BOTH' to determine if the script should send  #
#                       an email to you with the new order, write the  #
#                       order to a CSV file, or do both.               #
#      $epage	      - String containing path to an html file for pri-#
#			nting when an item is run out of stock	       #
#      [%ID%]         - In the above html file this string will be rep-#	
#			aced with the item's id who has run out of     #
#			stock					       #
########################################################################
$header        = "header.html";
$footer        = "footer.html";
$epage 	       = "error.html";
$mailprogram   = "/usr/lib/sendmail -t";
$returnpage    = "/";
$youremail     = "calane\@wichitaportal.org";
$csvfilename   = "orders.csv";
$csvquote      = "\"\"";
$mode          = "BOTH";
$orderNbr_Data = "ordernbr.dat";


#These are required fields.  I recommend enforcing these by javascript, 
#but let's just make sure here as well.
@required = (
'b_first',
'b_last',
'b_addr',
'b_city',
'b_state',
'b_zip',
'b_phone',
'b_email'
);

##############################################################
#FUNCTION:   urlDecode                                       #
#RETURNS:    The decoded string.                             #
#PARAMETERS: An encoded string.                              #
#PURPOSE:    Decodes a URL encoded string.                   #
##############################################################
sub urlDecode {
    my ($string) = @_;
    $string =~ tr/+/ /;
    $string =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex($1))/eg;
    $string =~ s/['"]/\'/g;
    return ($string);
}

##############################################################
#FUNCTION:   processCGI                                      #
#RETURNS:                                                    #
#PARAMETERS:                                                 #
#PURPOSE:    Retrieves form data submitted via the 'GET'     #
#            method and decodes it.  You may then access     #
#            the passed in variables via calls to $[name]    #
#            where [name] is the name of the form element.   #
##############################################################
sub processCGI {
    local ($cgiData, $key, $value, $pair, @pairs);

   if ($ENV{'REQUEST_METHOD'} eq 'GET') { $cgiData = $ENV{'QUERY_STRING'}; }
   else { $cgiData = <STDIN>; }
   @pairs = split (/&/, $cgiData);
   foreach $pair (@pairs) {
      ($key, $value) = split (/\=/, $pair);
      $key   = &urlDecode($key);
      $value = &urlDecode($value);
      if(defined ${$key}){
         ${$key} .= ", ".$value;
      }else{
         ${$key} = $value;
      }
   }
}

##############################################################
#FUNCTION:   doFormError                                     #
#RETURNS:                                                    #
#PARAMETERS: A error message string.                         #
#PURPOSE:    Generates an HTML page indicating a form        #
#            submission error occurred.                      #
##############################################################
sub doFormError {
    my ($errString) = @_;

    open (HEAD, $header);
    @LINES = <HEAD>;
    close HEAD;

    print "Content-type: text/html\n\n";

    print @LINES;

    print "<FONT SIZE=+2>The form you submitted was not complete.<BR><BR></FONT>";
    print "$errString<BR><BR>\n";
    print "<INPUT TYPE=BUTTON ONCLICK='history.back()' VALUE='  Return to the checkout page '><HR>";

    open (FOOT, $footer);
    @LINES = <FOOT>;
    close FOOT;
    print @LINES;

    exit;
}

##############################################################
#FUNCTION:   doError                                         #
#RETURNS:                                                    #
#PARAMETERS: A error message string.                         #
#PURPOSE:    Generates an HTML page indicating an error      #
#            occurred.                                       #
##############################################################
sub doError {
    my ($errString) = @_;
    print "Content-type: text/html\n\n";

    open (HEAD, $header);
    @LINES = <HEAD>;
    close HEAD;

    print @LINES;

    print "$errString<BR><BR>\n";

    open (FOOT, $footer);
    @LINES = <FOOT>;
    close FOOT;
    print @LINES;

    exit;
}

##############################################################
#FUNCTION:   invalidE                                        #
#RETURNS:    1 if invalid, 0 if valid.                       #
#PARAMETERS: An email address variable.                      #
#PURPOSE:    Checks to see if a submitted email address is   #
#            of the valid form 'x@y'.                        #
##############################################################
sub invalidE {
  my ($szEmail) = @_;
  my ($user, $host);

  $szEmail =~ tr/A-Z/a-z/;
  if ($szEmail =~ /\s/) { return 1; }
  ($user, $host) = split (/\@/, $szEmail);
  if ($host =~ /compuserve/i) { ; }
  else {
    if (! $user =~ /\D/) { return 1; }
    if (! $host =~ /\D/) { return 1; }
    if (substr ($user,0,1) !~ /[a-z]/) { return 1; }
  }
  if ($szEmail =~ /\w+\@[\w|\.]/) { return 0; }
  else { return 1; }
}


sub populateDateVar {
   @months = ();
   push(@months,"January");
   push(@months,"February");
   push(@months,"March");
   push(@months,"April");
   push(@months,"May");
   push(@months,"June");
   push(@months,"July");
   push(@months,"August");
   push(@months,"September");
   push(@months,"October");
   push(@months,"November");
   push(@months,"December");
   @days = ();
   push(@days,"Sunday");
   push(@days,"Monday");
   push(@days,"Tuesday");
   push(@days,"Wednesday");
   push(@days,"Thursday");
   push(@days,"Friday");
   push(@days,"Saturday");
   ($sec,$min,$hour,$day,$month,$year,$day2) =
   (localtime(time))[0,1,2,3,4,5,6];
   if ($sec < 10) { $sec = "0$sec"; }
   if ($min < 10) { $min = "0$min"; }
   if ($hour < 10) { $hour = "0$hour"; }
   if ($day < 10) { $day = "0$day"; }
   $year += "1900";
chomp($year);
   #$todaysdate = "$months[$month] $day, $year $hour:$min:$sec";
}

sub parse_form {

    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        ${$name} = $value;
  
  }
}
##############################################################
##############################################################
###  MAIN                                                  ###
##############################################################
##############################################################

# process the form input.
&parse_form;
&populateDateVar;

foreach $check(@required) {
   unless ($check) {
      doFormError("It appears that you forgot to fill in the <strong>$check</strong> field.");
      exit;
   }
}

# checks for valid email address
if( &invalidE($b_email) ){
   doFormError('You submitted an invalid email address.');
}

# Open "$orderNbr_Data" (ordernbr.dat) and read the Order Number ($last_Nbr) 
# assigned to the previous Customer
if (open(SEQUENCE, "<$orderNbr_Data")) { # Open file for reading (output) 
@lines = <SEQUENCE>; # Read first line 
close(SEQUENCE); # Close file 
@nbr_Info = split(/\|/, $lines[0]); # Separate variables 
$last_Nbr = $nbr_Info[0]; # Read variable 
}

if (defined $last_Nbr) { 
$this_Nbr = $last_Nbr + 1; # Increment Order Nbr by 1 
open(SEQUENCE, ">$orderNbr_Data"); # Open the file for writing (input) 
print SEQUENCE "$this_Nbr\n"; # Write to file 
close(SEQUENCE); # Close the file 
}

if( $mode eq "BOTH" || $mode eq "EMAIL") {
   # Send email order to you...
   open (MAIL,"|$mailprogram");
   print MAIL "To: $youremail\n";
   print MAIL "From: $b_email\n";
   print MAIL "Subject: New Online Order\n";
   print MAIL "\n\n";
   print MAIL "A new order has been placed by Oasis.  A summary of this order appears below.\n";
   print MAIL "\n";
   print MAIL "Order Number: $this_Nbr,   Dated: $months[$month] $day, $year $hour:$min:$sec\n"; 
   print MAIL " \n";
   print MAIL " \n";
   print MAIL "---------------------------------------------------------------------- \n";
   print MAIL "Bill To: \n";
   print MAIL "---------------------------------------------------------------------- \n";
   print MAIL "   $b_id \n";   
   print MAIL "   $b_first $b_last \n";
   print MAIL "   $b_addr \n"; 
   print MAIL "   $b_addr2 \n";
   print MAIL "   $b_city, $b_state  $b_zip \n";
   print MAIL "   $b_phone \n";
   print MAIL "   $b_fax \n";
   print MAIL "   $b_email \n";
   print MAIL " \n";
   print MAIL " \n";
   print MAIL "--------------------------------------------------------------------- \n";
   print MAIL "Ship To: \n";
   print MAIL "--------------------------------------------------------------------- \n";
   
   if ( $s_addr eq "" ) {
   print MAIL "   Use Billing Address\n";
} else {
   print MAIL "   $s_first $s_last \n";
   print MAIL "   $s_store \n";
   print MAIL "   $s_addr \n";
   print MAIL "   $s_addr2 \n";
   print MAIL "   $s_city, $s_state  $s_zip \n";
   print MAIL "   $s_phone \n";
}
   print MAIL " \n";
   print MAIL " \n";
   print MAIL "===================================================================== \n";
   print MAIL "Qty: $QUANTITY_1   \nItem No: $ID_1   \nDescpition: $NAME_1   \nAddtl. Info: $ADDTLINFO_1   \nPrice: \$$PRICE_1 ea.   \n\n";
   if( $NAME_2 ) {print MAIL "Qty: $QUANTITY_2   \nItem No: $ID_2   \nDescpition: $NAME_2   \nAddtl. Info: $ADDTLINFO_2   \nPrice: \$$PRICE_2 ea.   \n\n";}
   if( $NAME_3 ) {print MAIL "Qty: $QUANTITY_3   \nItem No: $ID_3   \nDescpition: $NAME_3   \nAddtl. Info: $ADDTLINFO_3   \nPrice: \$$PRICE_3 ea.   \n\n";}
   if( $NAME_4 ) {print MAIL "Qty: $QUANTITY_4   \nItem No: $ID_4   \nDescpition: $NAME_4   \nAddtl. Info: $ADDTLINFO_4   \nPrice: \$$PRICE_4 ea.   \n\n";}
   if( $NAME_5 ) {print MAIL "Qty: $QUANTITY_5   \nItem No: $ID_5   \nDescpition: $NAME_5   \nAddtl. Info: $ADDTLINFO_5   \nPrice: \$$PRICE_5 ea.   \n\n";}
   if( $NAME_6 ) {print MAIL "Qty: $QUANTITY_6   \nItem No: $ID_6   \nDescpition: $NAME_6   \nAddtl. Info: $ADDTLINFO_6   \nPrice: \$$PRICE_6 ea.   \n\n";}
   if( $NAME_7 ) {print MAIL "Qty: $QUANTITY_7   \nItem No: $ID_7   \nDescpition: $NAME_7   \nAddtl. Info: $ADDTLINFO_7   \nPrice: \$$PRICE_7 ea.   \n\n";}
   if( $NAME_8 ) {print MAIL "Qty: $QUANTITY_8   \nItem No: $ID_8   \nDescpition: $NAME_8   \nAddtl. Info: $ADDTLINFO_8   \nPrice: \$$PRICE_8 ea.   \n\n";}
   if( $NAME_9 ) {print MAIL "Qty: $QUANTITY_9   \nItem No: $ID_9   \nDescpition: $NAME_9   \nAddtl. Info: $ADDTLINFO_9   \nPrice: \$$PRICE_9 ea.   \n\n";}
   if( $NAME_10 ) {print MAIL "Qty: $QUANTITY_10   \nItem No: $ID_10   \nDescpition: $NAME_10   \nAddtl. Info: $ADDTLINFO_10   \nPrice: \$$PRICE_10 ea.   \n\n";}
   if( $NAME_11 ) {print MAIL "Qty: $QUANTITY_11   \nItem No: $ID_11   \nDescpition: $NAME_11   \nAddtl. Info: $ADDTLINFO_11   \nPrice: \$$PRICE_11 ea.   \n\n";}
   if( $NAME_12 ) {print MAIL "Qty: $QUANTITY_12   \nItem No: $ID_12   \nDescpition: $NAME_12   \nAddtl. Info: $ADDTLINFO_12   \nPrice: \$$PRICE_12 ea.   \n\n";}
   if( $NAME_13 ) {print MAIL "Qty: $QUANTITY_13   \nItem No: $ID_13   \nDescpition: $NAME_13   \nAddtl. Info: $ADDTLINFO_13   \nPrice: \$$PRICE_13 ea.   \n\n";}
   print MAIL "===================================================================== \n";
   print MAIL "\n";
   print MAIL "  SUBTOTAL    $SUBTOTAL \n";
   print MAIL "  TAX         $TAX \n";
   print MAIL "  FREIGHT     $SHIPPING \n";
   print MAIL "\n";
   print MAIL "  TOTAL       $TOTAL \n";
   print MAIL "\n\n";
   print MAIL "Comments: \n";
   print MAIL "-------------------------------------------------------------------- \n";
   print MAIL "$comment \n";
   print MAIL
 " \n";
   close MAIL;
}

###############################
#########ECHELON CODE##########
###############################
my $file="purchases.ech";
open(efile,'>>',$file);
$comment=~ s/\n/<br>/g;
$comment=~ s/\r/<br>/g;
print efile qq~\n$months[$month] $day, $year, $hour:$min:$sec|$b_first|$b_last|$b_addr|$b_addr2|$b_city|$b_state|$b_zip|$b_phone|$b_email|$s_first|$s_last|$s_email|$s_first|$s_last|$s_addr|$s_addr2|$s_city|$s_state|$s_zip|$s_phone|~;
print efile qq~$SUBTOTAL|$SHIPPING|$TOTAL|$comment~;
$num=0;
for($y=1;$y<=13;$y++){
$thename="NAME_$y";
if(length(${$thename})>3){
$num++;
}
}

print efile qq~|$num|~;
foreach($x=1; $x<=$num; $x++){
$qnt="QUANTITY_$x";
$prce="PRICE_$x";
$ide="ID_$x";
$naam="NAME_$x";
$adlinfo="ADDTLINFO_$x";
${$naam}=~ s/\n//g;
${$naam}=~ s/\r//g;
print efile qq~${$qnt}|${$prce}|${$ide}|${$naam}|${$adlinfo}|~;
$idadd{${$ide}}=${$qnt};
}

close("efile");


$otherefile="inventory.ech";
open(einventory,$otherefile);
$ncounter=0;
while(<einventory>){
chomp($_);
$numstoadd[$ncounter]=$_;
@data=split(/\|/,$_);
foreach $id (keys %idadd){
if($data[5] eq $id){
$data[3]-=$idadd{$id};
if($data[3] < 0){
fatal_error($id);
}
$numstoadd[$ncounter]=qq~$data[0]|$data[1]|$data[2]|$data[3]|$data[4]|$data[5]|~;
}
}
$ncounter++;
}
close("einventory");
open(einventory,'>',$otherefile);
foreach(@numstoadd){
print einventory $_."\n";
}
close("einventory");
sub fatal_error{
my ($error)=@_;
open('file',$epage);
while(<file>){
$fileinfo.=$_;
}
close(file);
$fileinfo=~s/\[%ID%]/$error/g;
print $fileinfo;
exit;
}
###############################
######END ECHELON CODE#########
###############################
if( $mode eq "BOTH" || $mode eq "FILE") {
   
   $csvcomments = $comment;
   #$csvcomments =~ s/\"/$csvquote/ig;

   open (CSVF,">>$csvfilename");
   print CSVF "\"";
   print CSVF "$this_Nbr";
   print CSVF "\",\"";
   print CSVF "$months[$month] $day, $year $hour:$min:$sec";
   print CSVF "\",\"";
   print CSVF "$b_first";
   print CSVF "\",\"";
   print CSVF "$b_last";
   print CSVF "\",\"";
   print CSVF "$b_addr";
   print CSVF "\",\"";
   print CSVF "$b_addr2";
   print CSVF "\",\"";
   print CSVF "$b_city";
   print CSVF "\",\"";
   print CSVF "$b_state";
   print CSVF "\",\"";
   print CSVF "$b_zip";
   print CSVF "\",\"";
   print CSVF "$b_phone";
   print CSVF "\",\"";
   print CSVF "$b_fax";
   print CSVF "\",\"";
   print CSVF "$b_email";
   print CSVF "\",\"";
   print CSVF "$s_first";
   print CSVF "\",\"";
   print CSVF "$s_last";
   print CSVF "\",\"";
   print CSVF "$s_addr";
   print CSVF "\",\"";
   print CSVF "$s_addr2";
   print CSVF "\",\"";
   print CSVF "$s_city";
   print CSVF "\",\"";
   print CSVF "$s_state";
   print CSVF "\",\"";
   print CSVF "$s_zip";
   print CSVF "\",\"";
   print CSVF "$s_phone";
   print CSVF "\",\"";   
   print CSVF "$QUANTITY_1";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_1";
   print CSVF "\",\"";
   print CSVF "$ID_1";
   print CSVF "\",\"";
   print CSVF "$NAME_1";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_1";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_2";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_2";
   print CSVF "\",\"";
   print CSVF "$ID_2";
   print CSVF "\",\"";
   print CSVF "$NAME_2";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_2";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_3";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_3";
   print CSVF "\",\"";
   print CSVF "$ID_3";
   print CSVF "\",\"";
   print CSVF "$NAME_3";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_3";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_4";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_4";
   print CSVF "\",\"";
   print CSVF "$ID_4";
   print CSVF "\",\"";
   print CSVF "$NAME_4";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_4";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_5";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_5";
   print CSVF "\",\"";
   print CSVF "$ID_5";
   print CSVF "\",\"";
   print CSVF "$NAME_5";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_5";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_6";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_6";
   print CSVF "\",\"";
   print CSVF "$ID_6";
   print CSVF "\",\"";
   print CSVF "$NAME_6";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_6";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_7";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_7";
   print CSVF "\",\"";
   print CSVF "$ID_7";
   print CSVF "\",\"";
   print CSVF "$NAME_7";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_7";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_8";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_8";
   print CSVF "\",\"";
   print CSVF "$ID_8";
   print CSVF "\",\"";
   print CSVF "$NAME_8";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_8";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_9";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_9";
   print CSVF "\",\"";
   print CSVF "$ID_9";
   print CSVF "\",\"";
   print CSVF "$NAME_9";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_9";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_10";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_10";
   print CSVF "\",\"";
   print CSVF "$ID_10";
   print CSVF "\",\"";
   print CSVF "$NAME_10";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_10";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_11";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_11";
   print CSVF "\",\"";
   print CSVF "$ID_11";
   print CSVF "\",\"";
   print CSVF "$NAME_11";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_11";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_12";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_12";
   print CSVF "\",\"";
   print CSVF "$ID_12";
   print CSVF "\",\"";
   print CSVF "$NAME_12";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_12";
   print CSVF "\",\"";
   print CSVF "$QUANTITY_13";
   print CSVF "\",\"";
   print CSVF "\$$PRICE_13";
   print CSVF "\",\"";
   print CSVF "$ID_13";
   print CSVF "\",\"";
   print CSVF "$NAME_13";
   print CSVF "\",\"";
   print CSVF "$ADDTLINFO_13";
   print CSVF "\",\"";
   print CSVF "$SUBTOTAL";
   print CSVF "\",\"";
   print CSVF "$TOTAL";
   print CSVF "\",\"";
   print CSVF "$SHIPPING";
   print CSVF "\",\"";
   print CSVF "$comment";
   print CSVF "\"\n";
   close CSVF;
}



# Send email conformation to the customer.....
   open (MAIL,"|$mailprogram");
   print MAIL "To: $b_email\n";
   print MAIL "From: $youremail\n";
   print MAIL "Subject: Order Confirmation\n";
   print MAIL "\n\n";
   print MAIL "A new order has been received by Total Printing Solutions.  A summary of this order appears below.\n";
   print MAIL "\n";
   print MAIL "Order Number: $this_Nbr,   Dated: $months[$month] $day, $year $hour:$min:$sec\n"; 
   print MAIL " \n";
   print MAIL "---------------------------------------------------------------------- \n";
   print MAIL "Bill To: \n";
   print MAIL "---------------------------------------------------------------------- \n";
   print MAIL "   $b_id \n";   
   print MAIL "   $b_first $b_last \n";
   print MAIL "   $b_addr \n"; 
   print MAIL "   $b_addr2 \n";
   print MAIL "   $b_city, $b_state  $b_zip \n";
   print MAIL "   $b_phone \n";
   print MAIL "   $b_fax \n";
   print MAIL "   $b_email \n";
   print MAIL " \n";
   print MAIL " \n";
   print MAIL "--------------------------------------------------------------------- \n";
   print MAIL "Ship To: \n";
   print MAIL "--------------------------------------------------------------------- \n";
   
   if ( $s_addr eq "" ) {
   print MAIL "   Use Billing Address\n";
} else {
   print MAIL "   $s_first $s_last \n";
   print MAIL "   $s_store \n";
   print MAIL "   $s_addr \n";
   print MAIL "   $s_addr2 \n";
   print MAIL "   $s_city, $s_state  $s_zip \n";
   print MAIL "   $s_phone \n";
}

   print MAIL " \n";
   print MAIL " \n";
   print MAIL "===================================================================== \n";
   print MAIL "Qty: $QUANTITY_1   \nItem No: $ID_1   \nDescpition: $NAME_1   \nAddtl. Info: $ADDTLINFO_1   \nPrice: \$$PRICE_1 ea.  \n\n";
   if( $NAME_2 ) {print MAIL "Qty: $QUANTITY_2   \nItem No: $ID_2   \nDescpition: $NAME_2   \nAddtl. Info: $ADDTLINFO_2   \nPrice: \$$PRICE_2 ea.  \n\n";}
   if( $NAME_3 ) {print MAIL "Qty: $QUANTITY_3   \nItem No: $ID_3   \nDescpition: $NAME_3   \nAddtl. Info: $ADDTLINFO_3   \nPrice: \$$PRICE_3 ea.  \n\n";}
   if( $NAME_4 ) {print MAIL "Qty: $QUANTITY_4   \nItem No: $ID_4   \nDescpition: $NAME_4   \nAddtl. Info: $ADDTLINFO_4   \nPrice: \$$PRICE_4 ea.  \n\n";}
   if( $NAME_5 ) {print MAIL "Qty: $QUANTITY_5   \nItem No: $ID_5   \nDescpition: $NAME_5   \nAddtl. Info: $ADDTLINFO_5   \nPrice: \$$PRICE_5 ea.  \n\n";}
   if( $NAME_6 ) {print MAIL "Qty: $QUANTITY_6   \nItem No: $ID_6   \nDescpition: $NAME_6   \nAddtl. Info: $ADDTLINFO_6   \nPrice: \$$PRICE_6 ea.  \n\n";}
   if( $NAME_7 ) {print MAIL "Qty: $QUANTITY_7   \nItem No: $ID_7   \nDescpition: $NAME_7   \nAddtl. Info: $ADDTLINFO_7   \nPrice: \$$PRICE_7 ea.  \n\n";}
   if( $NAME_8 ) {print MAIL "Qty: $QUANTITY_8   \nItem No: $ID_8   \nDescpition: $NAME_8   \nAddtl. Info: $ADDTLINFO_8   \nPrice: \$$PRICE_8 ea.  \n\n";}
   if( $NAME_9 ) {print MAIL "Qty: $QUANTITY_9   \nItem No: $ID_9   \nDescpition: $NAME_9   \nAddtl. Info: $ADDTLINFO_9   \nPrice: \$$PRICE_9 ea.  \n\n";}
   if( $NAME_10 ) {print MAIL "Qty: $QUANTITY_10   \nItem No: $ID_10   \nDescpition: $NAME_10   \nAddtl. Info: $ADDTLINFO_10   \nPrice: \$$PRICE_10 ea.  \n\n";}
   if( $NAME_11 ) {print MAIL "Qty: $QUANTITY_11   \nItem No: $ID_11   \nDescpition: $NAME_11   \nAddtl. Info: $ADDTLINFO_11   \nPrice: \$$PRICE_11 ea.  \n\n";}
   if( $NAME_12 ) {print MAIL "Qty: $QUANTITY_12   \nItem No: $ID_12   \nDescpition: $NAME_12   \nAddtl. Info: $ADDTLINFO_12   \nPrice: \$$PRICE_12 ea.  \n\n";}
   if( $NAME_13 ) {print MAIL "Qty: $QUANTITY_13   \nItem No: $ID_13   \nDescpition: $NAME_13   \nAddtl. Info: $ADDTLINFO_13   \nPrice: \$$PRICE_13 ea.  \n\n";}
   print MAIL "===================================================================== \n";
   print MAIL "\n";
   print MAIL "  SUBTOTAL    $SUBTOTAL \n";
   print MAIL "  TAX         $TAX \n";
   print MAIL "  FREIGHT     $SHIPPING \n";
   print MAIL "\n";
   print MAIL "  TOTAL       $TOTAL \n";
   print MAIL "\n\n";
   print MAIL "Comments: \n";
   print MAIL "-------------------------------------------------------------------- \n";
   print MAIL "$comment \n";
   print MAIL " \n";
   close MAIL;




open (HEAD, $header);
@LINES = <HEAD>;
close HEAD;
print @LINES;

print "<h2>Thank you</h2>";
print "Thank you for your order from our online store.  You will receive a confirmation email of your order ";
print "momentarily.  Please contact us at (316)264-1612  or 1-800-788-4901 if you have any questions or concerns.";
print "<P>";
print "<A HREF=\"$returnpage\" target=_top>Return Home</A>";
print "<P>";

open (FOOT, $footer);
@LINES = <FOOT>;
close FOOT;

print @LINES;

exit;


