#!/usr/bin/perl
print "Content-type:text/html\n\n";
print qq~
<html>
<head><title>Echelon Stats for Carl</title></head>
<body bgcolor="#ffffff">
<center><img src="http://www.echelondesign.net/newdesign/logo.jpg">
<table width=60%>
<Tr>
<td>
<a href="inventory.pl">
<b><font color=black>Home</font></b></a>
</td>
<td align=left>
<table><tR><td>
~;
&parse_form;

if($action){
&{$action};
}else{
main_menu();
}
sub remove{
$invent="inventory.ech";
@remov=split(/\|/,$ids);
open(invent,$invent);
$itemcount=0;
while(<invent>){
chomp($_);
@data=split(/\|/,$_);
$no=0;
foreach $i (@remov){

chomp($i);
print "<u>$data[5]</u><i>$i</i><br>";
if($data[5] eq $i){
print "<b>$data[5]$i</b><br>";
$no=1;
}
}
print $no;
if($no != 1){
print "<font size=\"+3\">$itemcount</font>";
$putback[$itemcount]=$_;
$itemcount++;
}
}
close("invent");
open(invent,'>',$invent);
foreach(@putback){
chomp($_);
print invent $_."\n";
}
close(invent);
}
sub remove_an_item{
print "Are you sure you want to remove the following items?:";
$invent="inventory.ech";
open(invent,$invent);
while(<invent>){
@data=split(/\|/,$_);
if(${$data[5]} eq "yes"){
print "<br>$data[0], ($data[5])";
$ids.="$data[5]|";
}
}
print qq~<br><a href="inventory.pl?action=remove&ids=$ids"><font color=black>Yes</font></a> <a href="inventory.pl?action=removei"><font color=black>No</font></a>~;
}
sub removei{
$invent="inventory.ech";
open(invent,$invent);
print qq~<form action="inventory.pl" method="POST">
<input type=hidden name=action value="remove_an_item">Item name (ID)</td><Td>Remove?</td></tr>~;
while(<invent>){
@data=split(/\|/,$_);
print qq~<tr><Td><a href="inventory.pl?action=remove_an_item&$data[5]=yes&itemname=$data[0]"><font color=black>$data[0] ($data[5])</font></a></td><td><input type=checkbox name=$data[5] value=yes></tD></tr>~;
}
print "<tr><Td align=center colspan=2><input type=submit value=\"Remove\"></td></tr>";
}
sub updateitemstock{
$invent="inventory.ech";
open(invent,$invent);

while(<invent>){
@data=split(/\|/,$_);
if($data[5] eq $item){
$iname=$data[0];
$iprice=$data[1];
$ibundle=$data[2];
$istock=$data[3];
$restock=$data[4];
$id=$data[5];
}
}
print qq~
<form action="inventory.pl" method="POST">
<input type=hidden name=action value="update_the_item_file">
<input type=hidden name=old value=$id>
<input type=hidden name=iname value=$iname>
<input type=hidden name=price value=$iprice>
<input type=hidden name=bundle value=$ibundle>
<input type=hidden name=restock value=$restock>
<input type=hidden name=id value=$id>
<table border=1><tr><Th colspan=2>Current Stock: $istock</th></tr>
~;
if($restock == 1){
print qq~<Tr><Td>New Stock:</td><td><input name=cstock value=$istock></td></tr>~;
}else{
print qq~<input type=hidden name=cstock value=$istock><Tr><Td colspan=2><font color=gray>Not Restockable</font></td></tr>~;
}
print qq~
<Tr><Td colspan=2 align=center><input type=submit value="Update Stock">
~;
}
sub addstock{
$invent="inventory.ech";
open(invent,$invent);
print "<b>Chose An Item</b></td></tr>";
while(<invent>){
@data=split(/\|/,$_);
print "<Tr><td><a href=\"inventory.pl?action=updateitemstock&item=$data[5]\"><font color=black>$data[0]($data[5])</font></a></td></tr>";
}
}
sub update_the_item_file{
$invent="inventory.ech";
open(invent,$invent);
$count=0;
while(<invent>){
chomp($_);
$item[$count]=$_;
@data=split(/\|/,$_);
if($data[5] eq $old){
$item[$count]=qq~$iname|$price|$bundle|$cstock|$restock|$id|~;
}
$count++;
}
close("invent");
open(invent,'>',$invent);
foreach(@item){
chomp($_);
print invent $_."\n";
}
close("invent");
print "<font color=green>Update Successful!</font>";
}
sub updateitem{
$invent="inventory.ech";
open(invent,$invent);

while(<invent>){
@data=split(/\|/,$_);
if($data[5] eq $item){
$iname=$data[0];
$iprice=$data[1];
$ibundle=$data[2];
$istock=$data[3];
$restock=$data[4];
$id=$data[5];
}
}
print qq~
<form action="inventory.pl" method="POST">
<input type=hidden name=action value=update_the_item_file>
<input type=hidden name=old value="$id">
<input type=hidden name=restock value="$restock">
<center>
<table border=1>
<Tr>
<Td colspan=2 align=center>
<b>Update an Item</b>
</td></tr>
<tr><Td>
Item Name:
</td><Td><input name=iname value="$iname">
</td>
</tr>
<tr><Td>
Item ID:
</td><Td><input name=id value="$id">
</td>
</tr>

<Tr>
<Td>
Price Per Item(NOT per bundle per EACH item!):
</td><td>
<input name=price value="$iprice">
</td></tr>
</table>
<table border=1>
<tr><td colspan=2 align=center>
<b>Stock Options</b></td></tr>
<Tr>
<Td>
Can be purchased in bundles of:
</td><td>
<input name=bundle value="$ibundle">
</td></tr>
<Tr>
<Td>
Current Stock:
</td>
~;
if($restock == 1){
print qq~ 
<td>
<input name=cstock value="$istock">
</td>
~;
}else{
print qq~<td><font color="gray">Not Restockable</font><br>$istock</td>
~;
}
print qq~ </tr>
<tr><Td colspan=2 align=center><input type=submit value="Update Item"></td></tr>
</table>
</center>
~;
}
sub uitem{
$invent="inventory.ech";
open(invent,$invent);
print "<table><Tr><th>Current Items</th></tr>";
while(<invent>){
@data=split(/\|/,$_);
print "<tr><td><a href=\"inventory.pl?action=updateitem&item=$data[5]\"><font color=black>$data[0]($data[5])</a></td></tr>";
}
}
sub viewstock{
$invent="inventory.ech";
open(invent,$invent);
print "<table><Tr><th>Current Items</th><th>Current Stock</th></tr>";
while(<invent>){
@data=split(/\|/,$_);
print "<tr><td><a href=\"inventory.pl?action=updateitem&item=$data[5]\"><font color=black>$data[0]($data[5])</a></td><td>$data[3]</td></tr>";
}
}
sub main_menu{
my ($status)=@_;
print qq~
<form action="inventory.pl" method="POST">
<tr><Td colspan=2 align=center>$status</tD></tr>
<td colspan=2><b>Chose an Option</b></td></tr>
<tr><Td>View Recent Purcahses</td><Td><input type=radio name=action value=purchases>
</td></tr>
<tr><Td>View Item Stock</td><Td><input type=radio name=action value=viewstock>
</td></tr>

<tr><Td>Add Stock to an item</td><Td><input type=radio name=action value=addstock>
</td></tr>

<tr><Td>Add/Remove/Update Item Stock</td><Td><input type=radio name=action value=ustock>
</td></tr>
<Tr><Td colspan=2 align=center><input type=submit value="Continue"></td></tr></table></body></html>
~;
}
sub add{
$invent="inventory.ech";
open(invent,'>>',$invent);
print invent qq~$iname|$price|$bundle|$cstock|$restock|$id|\n~;
close("invent");
main_menu("<font color=green>Addition Complete!</font>");
}
sub addi{
print qq~
<form action="inventory.pl" method="POST">
<input type=hidden name=action value=add>
<table border=1>
<Tr>
<Td colspan=2 align=center>
<b>Add an Item</b>
</td></tr>
<tr><Td>
Item Name:
</td><Td><input name=iname value="My Item">
</td>
</tr>
<tr><Td>
Item ID:(Must Match Javascript and forms!)
</td><Td><input name=id value="X##">
</td>
</tr>

<Tr>
<Td>
Price Per Item(NOT per bundle per EACH item!):
</td><td>
<input name=price value="\$10.00">
</td></tr>
</table>
<table border=1>
<tr><td colspan=2 align=center>
<b>Stock Options</b></td></tr>
<Tr>
<Td>
Can be purchased in bundles of:
</td><td>
<input name=bundle value="20">
</td></tr>
<Tr>
<Td>
Current Stock:
</td><td>
<input name=cstock value="2000">
</td></tr>
<Tr><Td>Can Be Restocked?</td><td><input type=radio name=restock value=1 checked>Yes<br><input type=radio name=restock value=no>No
<tr><Td colspan=2 align=center><input type=submit value="Add Item"></td></tr>
</table>
~;
}
sub ustock{
print qq~
<table>
<Tr>
<form action="inventory.pl" method="POST">
<td colspan=2><b>Chose an Option</b></td></tr>
<tr><Td>Add An Item</td><Td><input type=radio name=action value=addi>
</td></tr>
<tr><Td>Remove an Item</td><Td><input type=radio name=action value=removei>
</td></tr>
<tr><Td>Update an Item and/or it's Stock</td><Td><input type=radio name=action value=uitem>
</td></tr>
<Tr><Td colspan=2 align=center><input type=submit value="Continue"></td></tr></table></body></html>
~;
}
sub purchases{
print qq~
<table border=1>


<Tr><Td><b>Date</n></td><td><b>Number Of Items</b></td><td><b>By Who</b></td><td><b>For How Much Total</b></td><Td>Link</td></tr>
~;
$inventory="purchases.ech";
$count=0;
open(inventory,$inventory);
while(<inventory>){

@items=split(/\|/,$_);
print qq~<Tr><Td>$items[0]</td><td>$items[25]</td><td>$items[1],$items[2]</td><Td>$items[23]</td><td><a href="inventory.pl?action=viewpurchase&purchase=$count">Link</a></tr>~;
$count++;
}

}
sub viewpurchase{
$inventory="purchases.ech";
$count=0;
open(inventory,$inventory);
while(<inventory>){
if($count eq $purchase){
@item=split(/\|/,$_);
}
$count++;
}
$base=0;
$total=0;
$total=$item[23];
$base=$item[21];
$total=~s/\$//;
$base=~s/\$//;
$tax=$total-$base;
$tax="\$".$tax;
$base="\$".$base;
print qq~
<table><Tr><Td valign=top>
<table border=1>
<Tr><Td colspan=5 align=center><b>Basic Stats</b></td></tr>
<Tr><Td>Purchase on $item[0]</td></tr><Tr><td>$item[25] Items</td></tr><tr><td>by $item[1],$item[2]</td><Tr><Td>Item's cost $base</td></tr></tr><Tr><Td>Shipping: $item[22]</tD></tR><Tr><td>Tax: $tax</tD></tr><Tr><td>Totaling:$item[23]</td></tr></table>
</td><td>
<table border=1>
<tr>
<td align=center>
<i>Bussiness Info</i>
</td></tr>
<tr>
<Td>
First Name: $item[1]
</td>
</tr>
<tr>
<Td>
Last Name: $item[2]
</td>
</tr>
<tr>
<Td>
Address 1: $item[3]
</td>
</tr>
<tr>
<Td>
Address 2: $item[4]
</td>
</tr>
<tr>
<Td>
City: $item[5]
</td>
</tr>
<tr>
<Td>
State: $item[6]
</td>
</tr> 
<tr>
<Td>
Zip: $item[7]
</td>
</tr>
<tr>
<Td>
Phone: $item[8]
</td>
</tr>
<tr>
<Td>
Email: $item[9]
</td>
</tr>
</table>
</td>
<td valign=top>
<table border=1>
<tr>
<Td align=center >
<i>Shipping Info<i>
</td>
</tr>
<tr>
<Td>
First Name: $item[10]
</td>
</tr>
<tr>
<Td>
Last Name: $item[11]
</td>
</tr>
<tr>
<Td>
Address 1: $item[12]
</td>
</tr>
<tr>
<Td>
Address 2: $item[13]
</td>
</tr>
<tr>
<Td>
City: $item[14]
</td>
</tr>
<tr>
<Td>
State: $item[15]
</td>
</tr>
<tr>
<Td>
Zip: $item[16]
</td>
</tr>
<tr>
<Td>
Phone: $item[17]
</td>
</tr>
</table>
</td></tr><tr><Td colspan=3 align=center valign=top>
<table border=1>
<tr>
<Td colspan=6 align=center>
<b>Item for Item Stats</b>
</td>
</tr>
<tr><Td>Item Type</td><td>Quantity</td><td>Price</td><Td>Total Price</td><td>Id</td><Td>Additional Info</td></tr>

~;
foreach($x=1; $x<=$item[25]; $x++){

$multi=$x *5;
$qnt=$multi+21;
$prce=$multi+22;
$ide=$multi+23;
$naam=$multi+24;
$addtly=$multi+25;
$totalprice=$item[$prce]*$item[$qnt];
$totalquant+=$item[$qnt];
$totalpricee+=$totalprice;
print qq~
<Tr>
<Td>
$item[$naam]</td><Td>$item[$qnt]</td><Td>$item[$prce]</td><Td>$totalprice</td><Td>$item[$ide]</td><td>$item[$addtly]</td></tr>
~;
}
print qq~ <Tr><td colspan=6 align=center>$totalquant Items bought, with \$$totalpricee  income!</td></tr>~ ;



}

sub parse_form {


    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
    if ( length($buffer) < 5 ) {
        $buffer = $ENV{QUERY_STRING};

        #domain();
    }

    @pairs = split ( /&/, $buffer );
    foreach $pair (@pairs) {
        ( $name, $value ) = split ( /=/, $pair );

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        ${$name} = $value;

  
  }
}