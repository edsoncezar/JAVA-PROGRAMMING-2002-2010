### G.Scripts by Nick Grant #########################

Web: http://www.grantszone.co.uk/scripts/

Email: scripts@grantszone.co.uk

#############################################


### Script Information #############################

Name: G.Date
Version: 1.0

Info:

G.Date is a easy way to add the date to your webpage, no config need.

You can use SSI or JavaScript, follow this example:

# FOR SSI
<!--#exec cgi="cgi-bin/gdate.cgi?use=SSI" -->

# FOR JAVASCRIPT - This one can be used on out-side websites.
<script src="http://yourdomain.com/cgi-bin/gdate.cgi?use=javascript"></script>
 


G.Scripts @ http://www.grantszone.co.uk/scripts/