<?
/*
��Function convdata
��Developer: Ledson Carvalho (tchuck@csti.ufjf.br)
��Date : 23/09/2001
��Last Update: 23/09/2001
��Version: 0.1

  $tipo = 0 -=> Transforma data dd-mm-aaaa para aaaa-mm-dd -=> data brasil for mysql
  $tipo = 1 -=> Transforma data aaaa-mm-dd para dd/mm/aaaa -=> mysql for data brasil
*/

function convdata($dataform, $tipo){
  if ($tipo == 0) {
     $datatrans = explode ("/", $dataform);
     $data = "$datatrans[2]-$datatrans[1]-$datatrans[0]";
  } elseif ($tipo == 1) {
     $datatrans = explode ("-", $dataform);
     $data = "$datatrans[2]/$datatrans[1]/$datatrans[0]";
  }
  return $data;
}

?>