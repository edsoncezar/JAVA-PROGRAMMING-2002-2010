using System;
using GeneticAlgorithm;

namespace GEPAlgorithm
{
	/// <summary>
	/// Summary description for EquationNode.
	/// Equation node represents a symbolic equation that solves a problem
	/// In this case we'll use the following keys to represent our node
	/// 0: a 1: b 2: *  3: / 4: + 5: -  6: Q (square root)
	/// </summary>
	public class EquationNode
	{
		const int SymbolStart = 2;
		EquationNode[] ChildNode = new EquationNode[2]{null, null};
		EquationNode _parent = null;

		public int _value = -1;

		public EquationNode()
		{

		}

		public EquationNode(EquationGenome g, EquationNode parent, ref int index)
		{
			// fill node from Genome
			FillNode(g, ref index);
			_parent = parent;
			
		}

		string test = "";

		void FillNode(EquationGenome g, ref int index)
		{

			test = EquationNode.OutputStraightEquation(g);
			  // top value is
				if (g[index] >= SymbolStart)
				{
					_value = g[index];
					index++;
					if (index >= g.Length)
						return;

					ChildNode[0] = new EquationNode(g,  this, ref index);
					if (index >= g.Length)
						return;

					if (g[index] != 6) // square root (unary operator)
					{
						if (index >= g.Length)
							return;

						ChildNode[1] = new EquationNode(g,  this, ref index);
						if (index >= g.Length)
							return;
					}
				}
				else
				{
					if (index >= g.Length)
						return;
					_value = g[index];
					index++;
					ChildNode[0] = null;
					ChildNode[1] = null;
					return;
				}

		}

		public override string ToString()
		{
			string theString  = "";
			OutputEquation(ref theString);
			return theString;
		}

		public static string OutputStraightEquation(EquationGenome g) // normal output
		{
			string theString="";
			for (int i = 0; i < g.Length; i++)
			{
				switch(g[i])
				{
					case -1:
						theString += "?";
						break;
					case 0: // a
						theString += "a";
						break;
					case 1: // b
						theString += "b";
						break;
					case 2: // *
						theString += "*";
						break;
					case 3: // / 
						theString += "/";
						break;
					case 4: // +
						theString += "+";
						break;
					case 5: // - 
						theString += "-";
						break;
					case 6: // Q
						theString += "Q";
						break;
					default:
						// +
						break;
				} // end switch

			}

			return theString;
		}


		void AddNextValue (int val, ref string theString)
		{
			switch(val)
			{
				case 0: // a
					theString += "a";
					break;
				case 1: // b
					theString += "b";
					break;
				case 2: // *
					theString += "*";
					break;
				case 3: // / 
					theString += "/";
					break;
				case 4: // +
					theString += "+";
					break;
				case 5: // - 
					theString += "-";
					break;
				case 6: // Q
					theString += "Q";
					break;
				default:
					// +
					break;
			} // end switch

		}

		private float PerformOperation(float x, float y, int operation)
		{
			float result = 0.0f;
			switch(operation)
			{
				case 2: // *
					result = x * y;
					break;
				case 3: // / 
					result = x / y;
					break;
				case 4: // +
					result = x + y;
					break;
				case 5: // - 
					result = x - y;
					break;
				case 6: // Q
					result = (float)Math.Sqrt(x);
					break;
				default:
					// +
					break;
			} // end switch

			return result;
		}

		/// <summary>
		/// Calculate value by walking the node
		/// </summary>
		/// <param name="a"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CalculateValue(float a, float b, ref float result)
		{
			
			// this is a value for a or b
			if ((ChildNode[0] == null) && (ChildNode[1] == null))
			{
				if (_parent == null)
					return;

				if (_value == 0)
				{
					// see which you have to do calculation on
					if (_parent.ChildNode[0] == this)
					{
						if ((_parent.ChildNode[1] != null) && (_parent.ChildNode[1]._value == 0))
							result = PerformOperation(a, a, _parent._value);

						if  ((_parent.ChildNode[1] != null) && (_parent.ChildNode[1]._value == 1))
							result = PerformOperation(a, b, _parent._value);
					}

				}

				if (_value == 1)
				{
					// see which you have to do calculation on
					if (_parent.ChildNode[0] == this)
					{
						if ((_parent.ChildNode[1] != null) && (_parent.ChildNode[1]._value == 0))
							result = PerformOperation(a, b, _parent._value);

						if  ((_parent.ChildNode[1] != null) && (_parent.ChildNode[1]._value == 1))
							result = PerformOperation(b, b, _parent._value);
					}
				}

			}// end if
			else
			{
				if (ChildNode[0] != null)
				{
					if (ChildNode[1] != null)
						ChildNode[0].CalculateValue(a, b, ref result);
					else
						ChildNode[0].CalculateValue(a, 0, ref result); // squareroot

				}

			}
		}

		private void OutputEquation(ref string theString) // recursive tree output
		{
				theString += "(";
	

				if ((ChildNode[0] == null) && (ChildNode[1] == null))
				{
					AddNextValue(_value, ref theString);
				}// end if
				else
				{
					if (ChildNode[0] != null)
					{
						ChildNode[0].OutputEquation(ref theString);
						theString += ")";
					}

					AddNextValue(_value, ref theString);

					if (ChildNode[1] != null)
					{
						ChildNode[1].OutputEquation(ref theString);
						theString += ")";
					}



				}



		}

	}
}
