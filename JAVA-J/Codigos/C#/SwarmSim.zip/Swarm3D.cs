// This Code was translated to C# by Michael Gold for educational purposes
// It was originally written in Java by Alex Vulliamy and Jeff Cragg to demonstrate
// swarm behavior in three dimensions. 


//	Java Flies - 	http://www.1stpm.org/alex
//					alex@1stpm.org
//
//	You are welcome to do whatever you wish with this code, as long
//	as Jeff Cragg and I (Alex Vulliamy) are given a credit.
//	updated 12th February 98 to speed it up
//  updated 3rd March 98 to make it less processor-greedy
//  updated 10th March to speed up a little bit by not drawing background in first
//  updated 5th April 98 to add controls
// updated 19th April 98 to stop bugs due to browser's ill-written java VMs
// updated 13th January 2001 to make 3d. Also fixed minor bug with explorer

using System;
using System.Drawing;
using System.Threading;


namespace SwarmSim
{

	public class Swarm3D 
	{
		int delay=20;
		Thread runner;
		Random nrand;
		int NF;
		int REVDIST;
		int ACC;
		int ACCTOMID;	
		int MAXSPEED;
		int BOUNCESPEED;
		int[] flyx;
		int[] flyy;
		int[] flyz;
		int[] flyvx;
		int[] flyvy;
		int[] flyvz;
		int[,] flyn;
		int[] lpx;
		int[] lpy;
		int[] lpz;
		int[] lp2x;
		int[] lp2y;
		int[] lp2z;
		int WIDTH = 300;
		int HEIGHT = 300;
		int DEPTH = 200;
		int ZOOM = 40;

		public int rand(int range)
		{
			return( System.Math.Abs(nrand.Next()) % range);
		}
	

		private Form1 TheForm = null;

		public Swarm3D (Form1 aForm)
		{
			TheForm = aForm;
			WIDTH = TheForm.Width;
			HEIGHT = TheForm.Height;
			init();
		}

		public void init() 
		{
			DateTime d=new DateTime();
			nrand=new Random(0); // d.getTime()
			NF=30;
			REVDIST=2000000;
			ACCTOMID=10;  // 10
			ACC=30;
			MAXSPEED= 500; //500;
			BOUNCESPEED=80;
			flyx = new int[NF*3+1];
			flyy = new int[NF*3+1];
			flyz = new int[NF*3+1];
			flyvx = new int[NF*3+1];
			flyvy = new int[NF*3+1];
			flyvz = new int[NF*3+1];
			flyn = new int[NF*3+1, 2];
			lpx = new int[NF*3+1];
			lpy = new int[NF*3+1];
			lpz = new int[NF*3+1];
			lp2x = new int[NF*3+1];
			lp2y = new int[NF*3+1];
			lp2z = new int[NF*3+1];
			int i;
			for(i=0;i<NF*3;i++)
			{
				lpx[i]=flyx[i]=rand(WIDTH-60)*100+3000;
				lpy[i]=flyy[i]=rand(HEIGHT-60)*100+3000;
				lpz[i]=flyz[i]=rand(DEPTH-60)*100+3000;
				flyvx[i]= rand(500)-200;
				flyvy[i]= rand(500)-200;
				flyvz[i]= rand(500)-200;
			}
			randomize();
		}
	
		public void start()
		{
			if (runner == null)
			{
				runner= new Thread(new ThreadStart(run));
				runner.Start();
			}
		}
	
		public void stop()
		{
			if (runner!=null)
			{
				runner.Abort();
				runner=null;
			}
		}
		public void processfly(int tick)
		{
			// rev determines whether the neighbour attracts or repels, ACC is the acceleration amount
			// lpx & lpy are the last positions of the fly for drawing purposes.
			// REVDIST is the minimum distance squared that the flies can get to without repelling
			// tick is the fly number being processed. flyvx&y are the velocities in x and y directions
			// ACCTOMID is the acceleration towards the middle to attempt to keep the flies in the
			// middle of the display.
			lpx[tick]=flyx[tick];
			lpy[tick]=flyy[tick];
			lpz[tick]=flyz[tick];
			int rev=1;

			// check the distance between the fly and its neighbors
			// use the Acceleration constant and relationship to neighbors to
			// compute the velocity of the fly.
			// reduce the velocity vector if the fly is getting too close to the neighbor
			if (dist(tick,flyn[tick,0])<REVDIST)
				rev=-1;
			if (flyx[tick]<flyx[flyn[tick,0]])
				flyvx[tick]+=ACC*rev;
			else
				flyvx[tick]-=ACC*rev;
			if (flyy[tick]<flyy[flyn[tick,0]])
				flyvy[tick]+=ACC*rev;
			else
				flyvy[tick]-=ACC*rev;
			if (flyz[tick]<flyz[flyn[tick,0]])
				flyvz[tick]+=ACC*rev;
			else
				flyvz[tick]-=ACC*rev;
			rev=1;
			if (dist(tick,flyn[tick,1])<REVDIST)
				rev=-1;
			if (flyx[tick]<flyx[flyn[tick,1]])
				flyvx[tick]+=ACC*rev;
			else
				flyvx[tick]-=ACC*rev;
			if (flyy[tick]<flyy[flyn[tick,1]])
				flyvy[tick]+=ACC*rev;
			else
				flyvy[tick]-=ACC*rev;
			if (flyz[tick]<flyz[flyn[tick,1]])
				flyvz[tick]+=ACC*rev;
			else
				flyvz[tick]-=ACC*rev;

			// make sure that the fly's velocity never exceeds the maximum speed
			if (flyvx[tick]>MAXSPEED) flyvx[tick]=MAXSPEED;
			if (flyvx[tick]<-MAXSPEED) flyvx[tick]=-MAXSPEED;
			if (flyvy[tick]>MAXSPEED) flyvy[tick]=MAXSPEED;
			if (flyvy[tick]<-MAXSPEED) flyvy[tick]=-MAXSPEED;
			if (flyvz[tick]>MAXSPEED) flyvz[tick]=MAXSPEED;
			if (flyvz[tick]<-MAXSPEED) flyvz[tick]=-MAXSPEED;

			// make sure the flies position never exceeds the boundaries of the cube
			if (flyx[tick]<0) flyvx[tick]=BOUNCESPEED;
			if (flyx[tick]>WIDTH*100) flyvx[tick]=-BOUNCESPEED;
			if (flyy[tick]<0) flyvy[tick]=BOUNCESPEED;
			if (flyy[tick]>HEIGHT*100) flyvy[tick]=-BOUNCESPEED;		
			if (flyz[tick]<0) flyvz[tick]=BOUNCESPEED;
			if (flyz[tick]>DEPTH*100) flyvz[tick]=-BOUNCESPEED;		
			if (flyx[tick]<WIDTH*50) flyvx[tick]+=ACCTOMID;
			if (flyx[tick]>WIDTH*50) flyvx[tick]-=ACCTOMID;
			if (flyy[tick]<HEIGHT*50) flyvy[tick]+=ACCTOMID;
			if (flyy[tick]>HEIGHT*50) flyvy[tick]-=ACCTOMID;		
			if (flyz[tick]<DEPTH*50) flyvz[tick]+=ACCTOMID;
			if (flyz[tick]>DEPTH*50) flyvz[tick]-=ACCTOMID;		

			// compute the new fly position based on the computed velocity
			flyx[tick]+=flyvx[tick];
			flyy[tick]+=flyvy[tick];
			flyz[tick]+=flyvz[tick];
		
		}
	
		public void doneighbours(int tick)
		{
			// this re-assigns neighbours if the neighbour's neighbours are closer to the fly than the
			// neighbours.
			int k,l,m;
			for (k=0;k<2;k++)
			{	
				m=flyn[tick,k];
				for (l=0;l<2;l++)
				{
					if (dist(flyn[m,l],tick)<dist(flyn[tick,0],tick))
					{
						if (flyn[m,l]!=flyn[tick,1])
							flyn[tick,0]=flyn[m,l];
					}
					if (dist(flyn[m,l],tick)<dist(flyn[tick,1],tick))
					{
						if (flyn[m,l]!=flyn[tick,0])
							flyn[tick,1]=flyn[m,l];
					}
				}
			}	
			for (k=0;k<2;k++)
			{	
				// this bit randomises the flies neighbour if it has been assigned itself as a neighbour
				if (flyn[tick,k]==tick) flyn[tick,k]=(int) (rand(NF));
			}
		}
	
		// distance between flies function
		public long dist(int tick1,int tick2)
		{
			long d;
			int d1,d2,d3;
			d1=((int)(flyx[tick1]-flyx[tick2]));
			d2=((int)(flyy[tick1]-flyy[tick2]));
			d3=((int)(flyz[tick1]-flyz[tick2]));
			d=d1*d1+d2*d2+d3*d3;
			return(d);
		}
	
		// randomises the neighbours
		public void randomize()
		{
			int k;
			Random r = new Random((int)DateTime.Now.Ticks);
			for (k=0;k<NF;k++)
			{
				flyn[k,0]=(int) (r.Next(NF));
				flyn[k,1]=(int) (r.Next(NF));
			}
		}

		public void run()
		{
			int c=0;
			while (Thread.CurrentThread  ==runner)
			{
				for (int i=0;i<NF;i++)
				{
					doneighbours(i);
					processfly(i);
				}
				c++;
				if (rand(20)==0) randomize();
				try
				{
					Thread.Sleep(delay);
				}
				catch (Exception e)
				{
				}

				TheForm.Invalidate();
			}
		}


		public void Draw (Graphics g2)
		{
			int k;
			int[] x,y;
			int a1,a2,a3,a4,azx,azy;
			float lz,lz2;
			Point[] p = new Point[4];
			x=new int[4];
			y=new int[4];
			for (k=0;k<NF;k++)
			{
				lz=(float)(lpz[k]/100)/(float)(ZOOM*1.5); lz2=(float)(flyz[k]/100)/(float)(ZOOM*1.5); int midx=WIDTH/2; int midy=HEIGHT/2; 
				a1=midx+(int)((lpx[k]/100-midx)/lz); 
				a2=midy+(int)((lpy[k]/100-midy)/lz); 
				a3=midx+(int)((flyx[k]/100-midx)/lz2); 
				a4=midy+(int)((flyy[k]/100-midy)/lz2);
				azx=a1+(a3-a1)*2/3;
				azy=a2+(a4-a2)*2/3;
				x[0]=a1; y[0]=a2; x[2]=a3; y[2]=a4;
				x[1]=(int)(azx)+(int)((a4-a2)/4); x[3]=(int)(azx)-(int)((float)(a4-a2)/4);
				y[1]=(int)(azy)-(int)((a3-a1)/4); y[3]=(int)(azy)+(int)((float)(a3-a1)/4);
				p[0].X = x[0]; p[0].Y =y[0];
				p[1].X = x[1]; p[1].Y =y[1];
				p[2].X = x[2]; p[2].Y = y[2];
				p[3].X = x[3]; p[3].Y = y[3];
				// if fly is far away, draw the fly as a line, otherwise draw as a polygon.
				if (Math.Abs(x[1]-x[3]) < 2 && Math.Abs(y[1]-y[3]) < 2) g2.DrawLine(Pens.Red, midx+(int)((lpx[k]/100-midx)/lz), midy+(int)((lpy[k]/100-midy)/lz), 
																			midx+(int)((flyx[k]/100-midx)/lz2), midy+(int)((flyy[k]/100-midy)/lz2));
				else 
					g2.FillPolygon(Brushes.Red, p);
			}
	
		}
	}
}
























































































