using System;
using System.Collections;

namespace SyncCollections
{
	/// <summary>
	/// Synchronized wrapper around the unsynchronized ArrayList class
	/// </summary>
	public class SyncQueue
	{
		private Queue me;

		public SyncQueue()
		{
			//
			// TODO: Add constructor logic here
			//
			me = new Queue();

		}

		/// <summary>
		/// 
		/// </summary>
		public void Clear()
		{
			lock (me.SyncRoot)
			{
				me.Clear();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int Count() 
		{
			lock (me.SyncRoot)
			{
				return me.Count;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object Dequeue()
		{
			lock (me.SyncRoot)
			{
				return me.Dequeue();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="obj"></param>
		public void Enqueue(object obj)
		{
			lock (me.SyncRoot)
			{
				me.Enqueue(obj);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object Peek()
		{
			lock (me.SyncRoot)
			{
				return me.Peek();
			}
		}

	}
}
