using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace OscilloscopeDotNet1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private AxAWCGP3.AxGP3IO axGP3IO1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Button button3;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label1;
		private VolumeControl.VolumeControl volumeControl1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown TimeScaleControl;
		private VolumeControl.VolumeControl XPositionControl;
		private System.Windows.Forms.Button StorageButton;
		private System.Windows.Forms.CheckBox ShowSampleCheck;

		int[] StorageArray = new int[500];

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			InitializeStorageArray();

			// reduce flicker

			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);

			AxAWCGP3.AxGP3IO IO = this.axGP3IO1;
			axGP3IO1.CommPort = 1;
			axGP3IO1.portopen = true;


			timer1.Interval = 500;
			timer1.Start();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		void InitializeStorageArray()
		{
			for (int i = 0; i < StorageArray.Length; i++)
			{
				 StorageArray[i] = 0;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.axGP3IO1 = new AxAWCGP3.AxGP3IO();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.volumeControl1 = new VolumeControl.VolumeControl();
			this.XPositionControl = new VolumeControl.VolumeControl();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.TimeScaleControl = new System.Windows.Forms.NumericUpDown();
			this.StorageButton = new System.Windows.Forms.Button();
			this.ShowSampleCheck = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.axGP3IO1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.TimeScaleControl)).BeginInit();
			this.SuspendLayout();
			// 
			// axGP3IO1
			// 
			this.axGP3IO1.Enabled = true;
			this.axGP3IO1.Location = new System.Drawing.Point(536, 536);
			this.axGP3IO1.Name = "axGP3IO1";
			this.axGP3IO1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axGP3IO1.OcxState")));
			this.axGP3IO1.Size = new System.Drawing.Size(24, 24);
			this.axGP3IO1.TabIndex = 0;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(0, 496);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(48, 16);
			this.button1.TabIndex = 1;
			this.button1.Text = "test1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(64, 496);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(48, 16);
			this.button2.TabIndex = 2;
			this.button2.Text = "test2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 519);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(560, 22);
			this.statusBar1.TabIndex = 3;
			this.statusBar1.Text = "Ready";
			// 
			// timer1
			// 
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(0, 456);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(56, 24);
			this.button3.TabIndex = 4;
			this.button3.Text = "Off";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(72, 456);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(56, 24);
			this.button4.TabIndex = 5;
			this.button4.Text = "PWM";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(336, 496);
			this.numericUpDown1.Maximum = new System.Decimal(new int[] {
																		   10,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(48, 20);
			this.numericUpDown1.TabIndex = 7;
			this.numericUpDown1.Value = new System.Decimal(new int[] {
																		 1,
																		 0,
																		 0,
																		 0});
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(336, 472);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 8;
			this.label1.Text = "Voltage (Scale)";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// volumeControl1
			// 
			this.volumeControl1.BackColor = System.Drawing.Color.Black;
			this.volumeControl1.Location = new System.Drawing.Point(456, 80);
			this.volumeControl1.Name = "volumeControl1";
			this.volumeControl1.Offset = 0;
			this.volumeControl1.Size = new System.Drawing.Size(72, 72);
			this.volumeControl1.TabIndex = 9;
			// 
			// XPositionControl
			// 
			this.XPositionControl.BackColor = System.Drawing.Color.Black;
			this.XPositionControl.Location = new System.Drawing.Point(456, 192);
			this.XPositionControl.Name = "XPositionControl";
			this.XPositionControl.Offset = 0;
			this.XPositionControl.Size = new System.Drawing.Size(72, 72);
			this.XPositionControl.TabIndex = 10;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(464, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 11;
			this.label2.Text = "Y Position";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(472, 176);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 16);
			this.label3.TabIndex = 12;
			this.label3.Text = "X Position";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(184, 472);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(88, 16);
			this.label5.TabIndex = 15;
			this.label5.Text = "Time  (Scale)";
			// 
			// TimeScaleControl
			// 
			this.TimeScaleControl.Location = new System.Drawing.Point(184, 496);
			this.TimeScaleControl.Maximum = new System.Decimal(new int[] {
																			 50,
																			 0,
																			 0,
																			 0});
			this.TimeScaleControl.Minimum = new System.Decimal(new int[] {
																			 1,
																			 0,
																			 0,
																			 0});
			this.TimeScaleControl.Name = "TimeScaleControl";
			this.TimeScaleControl.Size = new System.Drawing.Size(48, 20);
			this.TimeScaleControl.TabIndex = 14;
			this.TimeScaleControl.Value = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   0});
			// 
			// StorageButton
			// 
			this.StorageButton.Location = new System.Drawing.Point(456, 464);
			this.StorageButton.Name = "StorageButton";
			this.StorageButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.StorageButton.Size = new System.Drawing.Size(72, 24);
			this.StorageButton.TabIndex = 16;
			this.StorageButton.Text = "Store";
			this.StorageButton.Click += new System.EventHandler(this.button5_Click_1);
			// 
			// ShowSampleCheck
			// 
			this.ShowSampleCheck.Location = new System.Drawing.Point(456, 488);
			this.ShowSampleCheck.Name = "ShowSampleCheck";
			this.ShowSampleCheck.TabIndex = 17;
			this.ShowSampleCheck.Text = "Show Samples";
			this.ShowSampleCheck.CheckedChanged += new System.EventHandler(this.ShowSampleCheck_CheckedChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(560, 541);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.ShowSampleCheck,
																		  this.StorageButton,
																		  this.label5,
																		  this.TimeScaleControl,
																		  this.label3,
																		  this.label2,
																		  this.XPositionControl,
																		  this.volumeControl1,
																		  this.label1,
																		  this.numericUpDown1,
																		  this.button4,
																		  this.button3,
																		  this.statusBar1,
																		  this.button2,
																		  this.button1,
																		  this.axGP3IO1});
			this.Name = "Form1";
			this.Text = "DotNet Oscilloscope";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			((System.ComponentModel.ISupportInitialize)(this.axGP3IO1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.TimeScaleControl)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.axGP3IO1.led = true;
		}

		Random r = new Random();

		private void RefreshScope (Graphics g)
		{
			int xmax = 450; // number of sample points
			int ymax = 225;  // maximum y value
			int xlast = -1;
			int ylast = 0;
			int xDraw = 0;
			int yDraw = 0;

			int nToggleColor = 0;


			// put the a/d readings into repeat mode for 450 readings
			axGP3IO1.repeat(xmax + 1);
			int n = 0;
				
			// read the values on channel #0 of the A/D converter
				n = axGP3IO1.a2d(0);

	// read each value from the buffer and plot the sample on the scope		
			for (int xpos = 0; xpos <xmax; xpos++)
			{
				if (StorageOn)
					n = StorageArray[xpos];
				else
					StorageArray[xpos] = n;
				
				// n between 0 and 1023
				System.Single y = 0;
				System.Single volt = 0;
				int yint = 0;

				// normalize the voltage reading
				y = (float)n/ 1024.0f;

				if (n > 64000)
					y = 0;

				// scale the voltage reading to 5 volts

				y = y * 5.0f;

//				Console.WriteLine("n,y = {0}, {1}", n, y);
		//		if (xpos % 64  == 0)
		//		{
		//			volt = (n / 1024) * 5;
		//			statusBar1.Text = "Last = " + volt.ToString("0.00") + "V";
		//		}

				// scale the voltage according to the voltage scale control
				yint = (int)((float)y/(float)numericUpDown1.Value);

				// offset the voltage based on the y position dial
				if (this.volumeControl1.Volume < 5) 
					yint +=  (this.volumeControl1.Volume % 5);
				else 
					yint -=  (this.volumeControl1.Volume % 5);

				// place the y reading into the correct coordinate system
				//    by subtracting from the maximum value
				yint = ymax - yint * ymax/5;

				yDraw = yint;

				// don't draw the first sample point, use it as
				// a starting sample point
				if (xlast !=  -1)
				{
					// scale the x-value based on the TimeScale control
					// translate the x-position by the x-position congrol
					xDraw = xpos * (int)this.TimeScaleControl.Value + this.XPositionControl.Volume * (int)TimeScaleControl.Value;

					// Draw the scaled sample point by connecting
					// the previous scaled sample point to the current
					// scaled sample point
					if (xDraw < kScopeWidth)
					{
						if ((nToggleColor % 2 == 0) || (ShowSamplesOn == false))
							g.DrawLine(Pens.LawnGreen, xlast, ylast, xDraw, yint);
						else
							g.DrawLine(Pens.Red, xlast, ylast, xDraw, yint);

//						g.DrawLine(new Pen(Color.FromArgb(r.Next(255), r.Next(255), r.Next(255))), xlast, ylast, xDraw, yint);
					}
				}
				
				// remember the current sample point to allow for connecting
				// the next sample point
				xlast = xDraw;
			    ylast = yDraw;

				nToggleColor++;

				// read the next a/d value from the buffer
				if (xpos != xmax)
				{ 
					n = axGP3IO1.readword();
				}
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Console.WriteLine("Start");
			for (int i = 0; i < 10; i++)
			{
				this.axGP3IO1.led = true;
				this.axGP3IO1.pwm(1, 128, 500);
				this.axGP3IO1.led = false;
				this.axGP3IO1.pwm(1, 128, 500);
			}
			Console.WriteLine("Stop");
		}

		const int kScopeWidth = 450;
		const int kScopeHeight = 450;
		Rectangle scopeRect = new Rectangle(0, 0, kScopeWidth, kScopeHeight);

		private void DrawGrid(Graphics g)
		{
			// Draw the Whole screen black
			g.FillRectangle(Brushes.Black, scopeRect);

			const int kpadding = 0;
			const int tickheight = 4;
			const int tickheightLarge = 8;
			// draw the Grid Lines
			for (int i = 0; i < 450; i += 50)
			{
				// draw horizontal line
				g.DrawLine(Pens.DarkGray, 0, i + kpadding, kScopeWidth, i + kpadding);

				// draw vertical line
				g.DrawLine(Pens.DarkGray, i + kpadding, 0, i + kpadding, kScopeHeight );

				// draw ticks on each line
				if (i == 200)
				{
					for (int j = 0; j < kScopeWidth; j+= 5)
					{
						if (j % 25 != 0)
						{
							g.DrawLine(Pens.White, j, (i- tickheight/2),
								j, (i + tickheight/2 ));

							g.DrawLine(Pens.White, (i- tickheight/2), j,
								(i + tickheight/2 ), j);
						}
						else
						{
							g.DrawLine(Pens.White, j, (i- tickheightLarge/2) + kpadding,
								j, (i + tickheightLarge/2 ) + kpadding);

							g.DrawLine(Pens.White, (i- tickheightLarge/2), j,
								(i + tickheightLarge/2 ), j);
						}
					}
				}
			}

		
			// Draw Scope from a to d
			if (ScopeOn)
				this.RefreshScope(g);
		}
						  

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics;
		  // Draw the scope Grid
			DrawGrid(g);
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
				Invalidate();
		}

		bool ScopeOn = false;

		private void button3_Click(object sender, System.EventArgs e)
		{
			// put something on pin 0
			ScopeOn = !ScopeOn;

			if (ScopeOn)
			{
				button3.BackColor = Color.LightGreen;
				button3.Text = "On";
			}
			else
			{
				button3.BackColor = Color.Gray;
				button3.Text = "Off";
			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			// set up the pwm wave continuous
			this.axGP3IO1.pwm(-1, 128, 50);
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			this.axGP3IO1.resetall();
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			axGP3IO1.portopen = false;
		}

		private bool StorageOn = false;
		private void button5_Click_1(object sender, System.EventArgs e)
		{

			StorageOn = !StorageOn;

			if (StorageOn == false)
			{
				StorageButton.ForeColor = Color.Black;
			}
			else
			{
				StorageButton.ForeColor = Color.Red;
			}
		}

		private bool ShowSamplesOn = false;
		private void ShowSampleCheck_CheckedChanged(object sender, System.EventArgs e)
		{
			ShowSamplesOn = this.ShowSampleCheck.Checked;
		}
	}
}
