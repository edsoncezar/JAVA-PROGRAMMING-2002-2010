using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace VolumeControl
{
	/// <summary>
	/// Summary description for VolumeControl.
	/// </summary>
	/// 

	/// ************************ VolumeControl ********************
	/// By Michael Gold
	/// Copyright 2002.  All Rights Reserved
	/// *********************************************************

//	[ToolboxBitmap ("VolumeControl.bmp")]
	public class VolumeControl : System.Windows.Forms.UserControl
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		public delegate void VolumeChangedEventHandler(object sender, EventArgs e);
		public event VolumeChangedEventHandler VolumeChanged;

		private Rectangle VolumeRectangle;
		private Font VolumeFont = new Font("Small Fonts", 6);
		private Point midPoint;
		private double TheOffset = 0;
		private double TheDotPosition = 0;
		private Bitmap VolumeImage;
		private Rectangle TheDotRectangle = new Rectangle();
		private const int IMAGEX = 50;
		private const int IMAGEY = 50;
		private const int kDOTWIDTH = 7;
		private const int kOFFSET = 10;
		private bool MovingDial = false;


		public VolumeControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// reduce flicker

			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);

			// TODO: Add any initialization after the InitForm call

		}

		private void DrawVolumeFace(Graphics g)
		{
			g.FillEllipse(Brushes.DarkSlateGray, VolumeRectangle.Left + kOFFSET,
				VolumeRectangle.Top + kOFFSET, VolumeRectangle.Width - kOFFSET*2,
				VolumeRectangle.Width - kOFFSET*2);
			g.DrawEllipse(Pens.Black, VolumeRectangle.Left + kOFFSET,
				VolumeRectangle.Top + kOFFSET, VolumeRectangle.Width - kOFFSET*2,
				VolumeRectangle.Width - kOFFSET*2);
		}

		private void DrawDot(Graphics g)
		{
			double x = (VolumeRectangle.Width - 40)/2 * Math.Cos(TheDotPosition) + (VolumeRectangle.Width - 70)/2 + 32;
			double y = (VolumeRectangle.Width - 40)/2 * Math.Sin(TheDotPosition)+ (VolumeRectangle.Width - 70)/2 + 28;

			if (MovingDial)
			{
				g.FillEllipse(Brushes.Green, (float)x, (float)y, kDOTWIDTH, kDOTWIDTH);
			}
			else
			{
				g.FillEllipse(Brushes.Red, (float)x, (float)y, kDOTWIDTH, kDOTWIDTH);
			}
			TheDotRectangle.X = (int)x;
			TheDotRectangle.Y = (int)y;
			TheDotRectangle.Width = kDOTWIDTH;
			TheDotRectangle.Height = kDOTWIDTH;
		}

		private void DrawSettingMarker(Graphics g)
		{
		//	double x = (VolumeRectangle.Width - 40)/2 * Math.Cos(0) + (VolumeRectangle.Width - 70)/2 + 32;
		//	double y = (VolumeRectangle.Width - 40)/2 * Math.Sin(0)+ (VolumeRectangle.Width - 70)/2 + 28;

			g.FillRectangle(Brushes.White, ClientRectangle.Width - 10, ClientRectangle.Height/2, 10, 5);
		}


		private void DrawNumbers(Graphics g)
		{
			int count = 1;

			for (double a = TheOffset; a < 2 * Math.PI + TheOffset; a += (2.0* Math.PI/10))
			{
				double x = (VolumeRectangle.Width - 40)/2 * Math.Cos(a) + (VolumeRectangle.Width - 70)/2 + 34;
				double y = (VolumeRectangle.Width - 40)/2 * Math.Sin(a)+ (VolumeRectangle.Width - 70)/2 + 30;
				g.DrawString(Convert.ToString(count), VolumeFont, Brushes.Yellow, (float)x,(float)y, new StringFormat());
				count++;
			}
		}

		public double Offset
		{
			get
			{
				return TheOffset;
			}

			set
			{
			  TheOffset = value;
			  TheDotPosition = value;
			}
	    }


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// VolumeControl
			// 
			this.BackColor = System.Drawing.Color.Black;
			this.Name = "VolumeControl";
			this.Resize += new System.EventHandler(this.VolumeControl_Resize);
			this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.VolumeControl_MouseUp);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.VolumeControl_Paint);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.VolumeControl_MouseMove);
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.VolumeControl_MouseDown);

		}
		#endregion

		private void VolumeControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
		  VolumeRectangle = ClientRectangle;
		  DrawVolumeFace(e.Graphics);
		  DrawNumbers(e.Graphics);
		  DrawDot(e.Graphics);
		  DrawSettingMarker(e.Graphics);
		}

		private void VolumeControl_Resize(object sender, System.EventArgs e)
		{
			this.SetBounds(this.Left, this.Top, this.Width, this.Width);
			Invalidate();
			
		}

		private void VolumeControl_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (this.TheDotRectangle.Contains(e.X, e.Y))
			{
				MovingDial = true;
				Invalidate();
			}
		}

//		private void VolumeControl_VolumeChanged(object sender, System.EventArgs e)
//		{
//			
//		}


		private void VolumeControl_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{


			if (MovingDial)
			{
				double xpos  = (double)e.X;
				double ypos = (double)e.Y;

				double xcenter = ClientRectangle.Width/2;
				double ycenter = ClientRectangle.Width/2;


				xpos -= xcenter;
				ypos -= ycenter;

				double angle = Math.Atan2(ypos, xpos);
				TheOffset = angle;
				TheDotPosition = TheOffset;
				int OldVolume = TheVolume;
				CalcVolume(TheOffset);
				if (OldVolume != TheVolume)
				{
					if (VolumeChanged != null)
					VolumeChanged(this, e);
				}
				Invalidate();
			}
		}

		int CalcVolume(double angle)
		{
			float angle1 = (float)TheOffset;


			while (angle1 > 2*Math.PI)
			{
			  angle1 -= 2.0f * (float)Math.PI;
			}

			while (angle1 < 0)
			{
				angle1 += 2.0f * (float)Math.PI;
			}

				
			TheVolume =  (int) Math.Round((((float)angle1 * -10f / (Math.PI*2.0f) ) ) +  2.0f);

			if ((TheVolume == 2) && ((int)((angle1 * -10f)/(Math.PI*2.0f)) == 0) )
			{
			  TheVolume = 1;
			  return TheVolume; // special case on angle
			}

			if (TheVolume <= 1)
			{
			  TheVolume += 9;
			}

			if (TheVolume > 11)
			{
			  TheVolume -= 10;
			}

//			if (TheVolume >= 5)
//				TheVolume++;


			return TheVolume;
		}

		private void VolumeControl_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
		  MovingDial = false;
			CalcVolume(TheOffset);
			Invalidate();
		}

		private int TheVolume = 0;
		public int Volume
		{
			get
			{
			  CalcVolume(TheOffset);
			  return TheVolume;
			}	
		}

	}
}
