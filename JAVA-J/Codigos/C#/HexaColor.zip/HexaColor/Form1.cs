using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace testColor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(104, 152);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(136, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(40, 48);
			this.button1.Name = "button1";
			this.button1.TabIndex = 1;
			this.button1.Text = "Write Colour";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(216, 48);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(80, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "Read Colour";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(352, 273);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.textBox1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		private Color GetColor(string astrHexString)
		{
			string strR;
			string strG;
			string strB;
			string strRL;
			string strRR;
			string strGL;
			string strGR;
			string strBL;
			string strBR;
			int iR;
			int iG;
			int iB;
			int iRL;
			int iRR;
			int iGL;
			int iGR;
			int iBL;
			int iBR;
			Color c;

			strR = astrHexString.Substring(0,2);
			strG = astrHexString.Substring(2,2);
			strB = astrHexString.Substring(4,2);

			strRL = strR.Substring(0,1);
			strRR = strR.Substring(1,1);

			strGL = strG.Substring(0,1);
			strGR = strG.Substring(1,1);

			strBL = strB.Substring(0,1);
			strBR = strB.Substring(1,1);

			iRL = GetIntFromHex(strRL);
			iRR = GetIntFromHex(strRR);
			iGL = GetIntFromHex(strGL);
			iGR = GetIntFromHex(strGR);
			iBL = GetIntFromHex(strBL);
			iBR = GetIntFromHex(strBR);

			iR = 16 * iRL + iRR;
			iG = 16 * iGL + iGR;
			iB = 16 * iBL + iBR;
			
			c = Color.FromArgb(iR, iG, iB);

			return c;
		}//GetColour


		private int GetIntFromHex(string strHex)
		{
			switch (strHex)
			{
				case("A"):
				{
					return 10;
				}
				case("B"):
				{
					return 11;
				}
				case("C"):
				{
					return 12;
				}
				case("D"):
				{
					return 13;
				}
				case("E"):
				{
					return 14;
				}
				case("F"):
				{
					return 15;
				}
				default:
				{
					return int.Parse(strHex);
				}
			}
		}//GetIntFromHex

		
		private void button1_Click(object sender, System.EventArgs e)
		{
			textBox1.BackColor = Color.White;
			if(colorDialog1.ShowDialog() == DialogResult.OK)
			{
				textBox1.Text = WriteHexString(colorDialog1.Color.R, colorDialog1.Color.G, colorDialog1.Color.B);
			}
		}

		
		private string WriteHexString(byte aobjColR, byte aobjColG, byte aobjColB)
		{
			string strRet;

			byte[] btR = {aobjColR};
			string strR = ToHexString(btR);
			strRet = strR; 
			byte[] btG = {this.colorDialog1.Color.G};
			string strG = ToHexString(btG);
			strRet += strG; 
			byte[] btB = {this.colorDialog1.Color.B};
			string strB = ToHexString(btB);
			strRet += strB; 

			return strRet;
		}//WriteHexString


		private static string ToHexString(byte[] bytes) 
		{
			char[] chars = new char[bytes.Length * 2];
			for (int i = 0; i < bytes.Length; i++) 
			{
				int b = bytes[i];
				chars[i * 2] = hexDigits[b >> 4];
				chars[i * 2 + 1] = hexDigits[b & 0xF];
			}
			return new string(chars);
		}//ToHexString


		static char[] hexDigits = {
									  '0', '1', '2', '3', '4', '5', '6', '7',
									  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

		private void button2_Click(object sender, System.EventArgs e)
		{
			textBox1.BackColor = GetColor(textBox1.Text);
			textBox1.Text = "";
		}
	}
}
