namespace synchronization
{
    using System;
    using System.Drawing;
    //using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;
    //using System.Data;
	using System.Threading;
	
    /// <summary>
	
	
    public class Form1 : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Button cmdExit;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtFifthTwoCounter2;
		private System.Windows.Forms.TextBox txtFifthTwoCounter1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtFourthTwoCounter2;
		private System.Windows.Forms.TextBox txtFourthTwoCounter1;
		private System.Windows.Forms.TextBox txtThirdTwoCounter2;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtNoOfUnsync;
		private System.Windows.Forms.Button cmdStart;
		private System.Windows.Forms.Label label6;
		
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtThirdTwoCounter1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtSecondTwoCounter2;
		private System.Windows.Forms.TextBox txtSecondTwoCounter1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtFirstTwoCounter2;
		private System.Windows.Forms.TextBox txtFirstTwoCounter1;
		private System.Windows.Forms.Label label1;
	

		
		//Counter variables for FirstTwoCounter
		//will be incremented by FirstTwoCounter Thread
		private System.Int32 FirstTwoCounterCnt1=0;
		private System.Int32 FirstTwoCounterCnt2=0;

		//Counter variables for SecondTwoCounter
		//will be incremented by SecondTwoCounter Thread
		private System.Int32 SecondTwoCounterCnt1=0;
		private System.Int32 SecondTwoCounterCnt2=0;

		//Counter variables for ThirdTwoCounter
		//will be incremented by ThirdTwoCounter Thread
		private System.Int32 ThirdTwoCounterCnt1=0;
		private System.Int32 ThirdTwoCounterCnt2=0;

		//Counter variables for FourthTwoCounter
		//will be incremented by FourthTwoCounter Thread
		private System.Int32 FourthTwoCounterCnt1=0;
		private System.Int32 FourthTwoCounterCnt2=0;

		//Counter variables for FifthTwoCounter
		//will be incremented by FifthTwoCounter Thread
		private System.Int32 FifthTwoCounterCnt1=0;
		private System.Int32 FifthTwoCounterCnt2=0;



		//Thread For FirstTwoCounter
		private System.Threading.Thread FirstTwoCounterThread;

		//Thread For SecondTwoCounter
		private System.Threading.Thread SecondTwoCounterThread;

		//Thread For ThirdTwoCounter
		private System.Threading.Thread ThirdTwoCounterThread;

		//Thread For FourthTwoCounter
		private System.Threading.Thread FourthTwoCounterThread;

		//Thread For FifthTwoCounter
		private System.Threading.Thread FifthTwoCounterThread;


		//Watches the counters on all the threads and displays whethere the pairs of counters are equal or out of sync
		private System.Threading.Thread WatchThread;

		private static System.Int32 NoOfUnsync=0;

        public Form1 ()
        {
			
			
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
			txtNoOfUnsync.Text=NoOfUnsync.ToString();
	
			FirstTwoCounterThread=new Thread(new ThreadStart(IncrementFirstTwoCounter));
			SecondTwoCounterThread=new Thread(new ThreadStart(IncrementSecondTwoCounter));
			ThirdTwoCounterThread=new Thread(new ThreadStart(IncrementThirdTwoCounter));
			FourthTwoCounterThread=new Thread(new ThreadStart(IncrementFourthTwoCounter));
			FifthTwoCounterThread=new Thread(new ThreadStart(IncrementFifthTwoCounter));
			WatchThread=new Thread(new ThreadStart(WatchCounters));
	
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
			//Clean all the threads

			if (FirstTwoCounterThread.IsAlive)
			{
				FirstTwoCounterThread.Abort();
			}
			
			if (SecondTwoCounterThread.IsAlive)
			{
				SecondTwoCounterThread.Abort();
			}
			
			if (ThirdTwoCounterThread.IsAlive)
			{
				ThirdTwoCounterThread.Abort();
			}

			if (FourthTwoCounterThread.IsAlive)
			{
				FourthTwoCounterThread.Abort();
			}

			if (FifthTwoCounterThread.IsAlive)
			{
				FifthTwoCounterThread.Abort();
			}

			if (WatchThread.IsAlive)
			{
				WatchThread.Abort();
			}

			FirstTwoCounterThread=null;
			SecondTwoCounterThread=null;
			ThirdTwoCounterThread=null;
			FourthTwoCounterThread=null;
			FifthTwoCounterThread=null;
			WatchThread=null;
				}
			}
			base.Dispose( disposing );
		}
        
        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
      
		private void IncrementFirstTwoCounter()
		{
				
				while(true)
				{
				Thread.Sleep(50);
				//Begin of Critical Section
				//Uncomment the following line for proper Synchronization
				//Monitor.Enter(this);
				txtFirstTwoCounter1.Text=(FirstTwoCounterCnt1++).ToString();
				txtFirstTwoCounter2.Text=(FirstTwoCounterCnt2++).ToString();
				//Uncomment the following line for proper Synchronization
				//Monitor.Exit(this);
				//End Of Critical Section
				}

		}

		private void IncrementSecondTwoCounter()
		{

				while(true)
				{

				Thread.Sleep(50);
				//Begin Of Critical Section
				//Uncomment the following line for proper Synchronization
				//Monitor.Enter(this);
				txtSecondTwoCounter1.Text=(SecondTwoCounterCnt1++).ToString();
				txtSecondTwoCounter2.Text=(SecondTwoCounterCnt2++).ToString();
				//Monitor.Exit(this);
				//Uncomment the following line for proper Synchronization
				//End Of Critical Section
				}
			
		}
	
		private void IncrementThirdTwoCounter()
		{
				while(true)
				{
				Thread.Sleep(50);
				//Begin Of Critical Section
				//Uncomment the following line for proper Synchronization
				//Monitor.Enter(this);
				txtThirdTwoCounter1.Text=(ThirdTwoCounterCnt1++).ToString();
				txtThirdTwoCounter2.Text=(ThirdTwoCounterCnt2++).ToString();
				//Monitor.Exit(this);
				//Uncomment the following line for proper Synchronization
				//End Of Critical Section
				}

		}
		private void IncrementFourthTwoCounter()
		{
				while(true)
				{
				Thread.Sleep(50);
				//Begin Of Critical Section
				//Uncomment the following line for proper Synchronization
				//Monitor.Enter(this);
				txtFourthTwoCounter1.Text=(FourthTwoCounterCnt1++).ToString();
				txtFourthTwoCounter2.Text=(FourthTwoCounterCnt2++).ToString();			
				//Uncomment the following line for proper Synchronization
				//Monitor.Exit(this);
				//End Of Critical Section
				}

		}

		private void IncrementFifthTwoCounter()
		{
				while(true)
				{
				Thread.Sleep(50);
				//Begin Of Critical Section
				//Uncomment the following line for proper Synchronization
				//Monitor.Enter(this);
				txtFifthTwoCounter1.Text=(FifthTwoCounterCnt1++).ToString();
				txtFifthTwoCounter2.Text=(FifthTwoCounterCnt2++).ToString();
				//Uncomment the following line for proper Synchronization
				//Monitor.Exit(this);
				//End Of Critical Section
				}

		}		
		
		private  void WatchCounters()
		{
				while(true)
				{
					Thread.Sleep(50);
					//Begin Of Critical Section
					//Uncomment the following line for proper Synchronization
					//Monitor.Enter(this);		
					if(FirstTwoCounterCnt1!=FirstTwoCounterCnt2)
					{
						label2.Text="OutOfSync";
						txtNoOfUnsync.Text=(NoOfUnsync++).ToString();

					}
	
					if(SecondTwoCounterCnt1!=SecondTwoCounterCnt2)
					{
						label3.Text="OutOfSync";
						txtNoOfUnsync.Text=(NoOfUnsync++).ToString();
					}

					if(ThirdTwoCounterCnt1!=ThirdTwoCounterCnt2)
					{
						label5.Text="OutOfSync";
						txtNoOfUnsync.Text=(NoOfUnsync++).ToString();
					}

					if(FourthTwoCounterCnt1!=FourthTwoCounterCnt2)
					{
						label8.Text="OutOfSync";
						txtNoOfUnsync.Text=(NoOfUnsync++).ToString();
					}

					if(FifthTwoCounterCnt1!=FifthTwoCounterCnt2)
					{
						label9.Text="OutOfSync";
						txtNoOfUnsync.Text=(NoOfUnsync++).ToString();
					}

					//Uncomment the following line for proper Synchronization
					//Monitor.Exit(this);
					//End Of Critical Section
				}

		}
		
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.txtSecondTwoCounter1 = new System.Windows.Forms.TextBox ();
			this.cmdExit = new System.Windows.Forms.Button ();
			this.cmdStart = new System.Windows.Forms.Button ();
			this.label10 = new System.Windows.Forms.Label ();
			this.txtSecondTwoCounter2 = new System.Windows.Forms.TextBox ();
			this.label2 = new System.Windows.Forms.Label ();
			this.label11 = new System.Windows.Forms.Label ();
			this.txtFourthTwoCounter1 = new System.Windows.Forms.TextBox ();
			this.txtNoOfUnsync = new System.Windows.Forms.TextBox ();
			this.txtFirstTwoCounter1 = new System.Windows.Forms.TextBox ();
			this.txtFirstTwoCounter2 = new System.Windows.Forms.TextBox ();
			this.label4 = new System.Windows.Forms.Label ();
			this.txtFifthTwoCounter2 = new System.Windows.Forms.TextBox ();
			this.txtFifthTwoCounter1 = new System.Windows.Forms.TextBox ();
			this.label7 = new System.Windows.Forms.Label ();
			this.txtFourthTwoCounter2 = new System.Windows.Forms.TextBox ();
			this.label8 = new System.Windows.Forms.Label ();
			this.label9 = new System.Windows.Forms.Label ();
			this.label1 = new System.Windows.Forms.Label ();
			this.txtThirdTwoCounter2 = new System.Windows.Forms.TextBox ();
			this.label3 = new System.Windows.Forms.Label ();
			this.label5 = new System.Windows.Forms.Label ();
			this.label6 = new System.Windows.Forms.Label ();
			this.txtThirdTwoCounter1 = new System.Windows.Forms.TextBox ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			txtSecondTwoCounter1.Location = new System.Drawing.Point (16, 106);
			txtSecondTwoCounter1.TabIndex = 4;
			txtSecondTwoCounter1.Size = new System.Drawing.Size (120, 20);
			cmdExit.Location = new System.Drawing.Point (400, 224);
			cmdExit.Size = new System.Drawing.Size (64, 32);
			cmdExit.TabIndex = 28;
			cmdExit.Text = "Exit";
			cmdExit.Click += new System.EventHandler (this.cmdExit_Click);
			cmdStart.Location = new System.Drawing.Point (320, 224);
			cmdStart.Size = new System.Drawing.Size (72, 32);
			cmdStart.TabIndex = 12;
			cmdStart.Text = "Start";
			cmdStart.Click += new System.EventHandler (this.cmdStart_Click);
			label10.Location = new System.Drawing.Point (16, 232);
			label10.Text = "FourthTwoCounter";
			label10.Size = new System.Drawing.Size (112, 12);
			label10.TabIndex = 22;
			txtSecondTwoCounter2.Location = new System.Drawing.Point (16, 130);
			txtSecondTwoCounter2.TabIndex = 5;
			txtSecondTwoCounter2.Size = new System.Drawing.Size (120, 20);
			label2.Location = new System.Drawing.Point (152, 48);
			label2.Text = "Counter1=Counter2";
			label2.Size = new System.Drawing.Size (112, 16);
			label2.TabIndex = 3;
			label11.Location = new System.Drawing.Point (16, 320);
			label11.Text = "FifthTwoCounter";
			label11.Size = new System.Drawing.Size (112, 12);
			label11.TabIndex = 27;
			txtFourthTwoCounter1.Location = new System.Drawing.Point (16, 256);
			txtFourthTwoCounter1.TabIndex = 19;
			txtFourthTwoCounter1.Size = new System.Drawing.Size (120, 20);
			txtNoOfUnsync.Location = new System.Drawing.Point (320, 176);
			txtNoOfUnsync.TabIndex = 13;
			txtNoOfUnsync.Size = new System.Drawing.Size (112, 20);
			txtFirstTwoCounter1.Location = new System.Drawing.Point (16, 32);
			txtFirstTwoCounter1.TabIndex = 1;
			txtFirstTwoCounter1.Size = new System.Drawing.Size (120, 20);
			txtFirstTwoCounter2.Location = new System.Drawing.Point (16, 56);
			txtFirstTwoCounter2.TabIndex = 2;
			txtFirstTwoCounter2.Size = new System.Drawing.Size (120, 20);
			label4.Location = new System.Drawing.Point (16, 88);
			label4.Text = "SecondTwoCounter";
			label4.Size = new System.Drawing.Size (120, 16);
			label4.TabIndex = 23;
			txtFifthTwoCounter2.Location = new System.Drawing.Point (16, 360);
			txtFifthTwoCounter2.TabIndex = 25;
			txtFifthTwoCounter2.Size = new System.Drawing.Size (120, 20);
			txtFifthTwoCounter1.Location = new System.Drawing.Point (16, 336);
			txtFifthTwoCounter1.TabIndex = 24;
			txtFifthTwoCounter1.Size = new System.Drawing.Size (120, 20);
			label7.Location = new System.Drawing.Point (312, 144);
			label7.Text = "No of times Unsync occured in any of the two counters";
			label7.Size = new System.Drawing.Size (160, 24);
			label7.TabIndex = 14;
			label7.Click += new System.EventHandler (this.label7_Click);
			txtFourthTwoCounter2.Location = new System.Drawing.Point (16, 280);
			txtFourthTwoCounter2.TabIndex = 20;
			txtFourthTwoCounter2.Size = new System.Drawing.Size (120, 20);
			label8.Location = new System.Drawing.Point (152, 272);
			label8.Text = "Counter1=Counter2";
			label8.Size = new System.Drawing.Size (112, 16);
			label8.TabIndex = 26;
			label9.Location = new System.Drawing.Point (152, 352);
			label9.Text = "Counter1=Counter2";
			label9.Size = new System.Drawing.Size (112, 16);
			label9.TabIndex = 21;
			label1.Location = new System.Drawing.Point (16, 8);
			label1.Text = "FirstTwoCounter";
			label1.Size = new System.Drawing.Size (112, 24);
			label1.TabIndex = 0;
			txtThirdTwoCounter2.Location = new System.Drawing.Point (16, 204);
			txtThirdTwoCounter2.TabIndex = 18;
			txtThirdTwoCounter2.Size = new System.Drawing.Size (120, 20);
			label3.Location = new System.Drawing.Point (152, 122);
			label3.Text = "Counter1=Counter2";
			label3.Size = new System.Drawing.Size (112, 16);
			label3.TabIndex = 6;
			label5.Location = new System.Drawing.Point (152, 196);
			label5.Text = "Counter1=Counter2";
			label5.Size = new System.Drawing.Size (112, 16);
			label5.TabIndex = 10;
			label6.Location = new System.Drawing.Point (24, 164);
			label6.Text = "ThirdTwoCounter";
			label6.Size = new System.Drawing.Size (112, 12);
			label6.TabIndex = 11;
			txtThirdTwoCounter1.Location = new System.Drawing.Point (16, 180);
			txtThirdTwoCounter1.TabIndex = 8;
			txtThirdTwoCounter1.Size = new System.Drawing.Size (120, 20);
			this.Text = "Importance Of Synchronization";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (480, 397);
			this.Click += new System.EventHandler (this.Form1_Click);
			this.Closing += new System.ComponentModel.CancelEventHandler (this.Form1_Closing);
			this.Controls.Add (this.cmdExit);
			this.Controls.Add (this.label11);
			this.Controls.Add (this.label8);
			this.Controls.Add (this.txtFifthTwoCounter2);
			this.Controls.Add (this.txtFifthTwoCounter1);
			this.Controls.Add (this.label4);
			this.Controls.Add (this.label10);
			this.Controls.Add (this.label9);
			this.Controls.Add (this.txtFourthTwoCounter2);
			this.Controls.Add (this.txtFourthTwoCounter1);
			this.Controls.Add (this.label7);
			this.Controls.Add (this.txtNoOfUnsync);
			this.Controls.Add (this.cmdStart);
			this.Controls.Add (this.label6);
			this.Controls.Add (this.label5);
			this.Controls.Add (this.txtThirdTwoCounter2);
			this.Controls.Add (this.txtThirdTwoCounter1);
			this.Controls.Add (this.label3);
			this.Controls.Add (this.txtSecondTwoCounter2);
			this.Controls.Add (this.txtSecondTwoCounter1);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.txtFirstTwoCounter2);
			this.Controls.Add (this.txtFirstTwoCounter1);
			this.Controls.Add (this.label1);
		}

		protected void cmdExit_Click (object sender, System.EventArgs e)
		{
			Close();
		}

		protected void Form1_Closing (object sender, System.ComponentModel.CancelEventArgs e)
		{
	
            			
		}

		protected void label7_Click (object sender, System.EventArgs e)
		{

		}

		protected void cmdStart_Click (object sender, System.EventArgs e)
		{
			
			FirstTwoCounterThread.Start();
			SecondTwoCounterThread.Start();
			ThirdTwoCounterThread.Start();
			FourthTwoCounterThread.Start();
			FifthTwoCounterThread.Start();
            WatchThread.Start();			
		}
		
		protected void Form1_Click (object sender, System.EventArgs e)
		{

		}
		
	

		
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
    
		

        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
			
        }
	}
}
