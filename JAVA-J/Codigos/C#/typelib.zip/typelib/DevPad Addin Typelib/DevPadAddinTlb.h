/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed May 16 15:51:47 2001
 */
/* Compiler settings for C:\Documents and Settings\Administrator\My Documents\Development\Visual Basic\Regular\DevPad\Current Release\Resources\typelib\DevPad AddIn TypeLib\DevPadAddinTlb.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __DevPadAddinTlb_h__
#define __DevPadAddinTlb_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDevPadTools_FWD_DEFINED__
#define __IDevPadTools_FWD_DEFINED__
typedef interface IDevPadTools IDevPadTools;
#endif 	/* __IDevPadTools_FWD_DEFINED__ */


#ifndef __IDevPadApp_FWD_DEFINED__
#define __IDevPadApp_FWD_DEFINED__
typedef interface IDevPadApp IDevPadApp;
#endif 	/* __IDevPadApp_FWD_DEFINED__ */


#ifndef __IDevPadDocuments_FWD_DEFINED__
#define __IDevPadDocuments_FWD_DEFINED__
typedef interface IDevPadDocuments IDevPadDocuments;
#endif 	/* __IDevPadDocuments_FWD_DEFINED__ */


#ifndef __IDevPadDocument_FWD_DEFINED__
#define __IDevPadDocument_FWD_DEFINED__
typedef interface IDevPadDocument IDevPadDocument;
#endif 	/* __IDevPadDocument_FWD_DEFINED__ */


#ifndef __IDevPadDialog_FWD_DEFINED__
#define __IDevPadDialog_FWD_DEFINED__
typedef interface IDevPadDialog IDevPadDialog;
#endif 	/* __IDevPadDialog_FWD_DEFINED__ */


#ifndef __IDevPadMenu_FWD_DEFINED__
#define __IDevPadMenu_FWD_DEFINED__
typedef interface IDevPadMenu IDevPadMenu;
#endif 	/* __IDevPadMenu_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __DevPadAddInTlb_LIBRARY_DEFINED__
#define __DevPadAddInTlb_LIBRARY_DEFINED__

/* library DevPadAddInTlb */
/* [helpstring][version][uuid] */ 







typedef /* [helpstring][version][v1_enum][uuid] */ 
enum ShowYesNoResult
    {	Yes	= 1,
	YesToAll	= 2,
	No	= 3,
	NoToAll	= 4,
	None	= 5,
	Cancelled	= -1
    }	ShowYesNoResult;

typedef /* [version][v1_enum][uuid] */ 
enum DocumentViewModes
    {	ercDefault	= 0,
	ercWordWrap	= 1,
	ercWYSIWYG	= 2
    }	DocumentViewModes;

typedef /* [version][v1_enum][uuid] */ 
enum SaveOptions
    {	vbwNotSet	= 0,
	vbwSave	= 1,
	vbwDiscard	= 2
    }	SaveOptions;


EXTERN_C const IID LIBID_DevPadAddInTlb;

#ifndef __IDevPadTools_INTERFACE_DEFINED__
#define __IDevPadTools_INTERFACE_DEFINED__

/* interface IDevPadTools */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadTools;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("30c1719d-26f6-4346-9f94-628474b0769d")
    IDevPadTools : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Connect( 
            /* [in] */ IDevPadApp __RPC_FAR *DevPadApp) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Disconnect( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE HideDialog( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE ShowDialog( void) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE MenuClick( 
            /* [in] */ long ItemIndex,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadToolsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadTools __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadTools __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadTools __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Connect )( 
            IDevPadTools __RPC_FAR * This,
            /* [in] */ IDevPadApp __RPC_FAR *DevPadApp);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Disconnect )( 
            IDevPadTools __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *HideDialog )( 
            IDevPadTools __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowDialog )( 
            IDevPadTools __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MenuClick )( 
            IDevPadTools __RPC_FAR * This,
            /* [in] */ long ItemIndex,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadToolsVtbl;

    interface IDevPadTools
    {
        CONST_VTBL struct IDevPadToolsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadTools_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadTools_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadTools_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadTools_Connect(This,DevPadApp)	\
    (This)->lpVtbl -> Connect(This,DevPadApp)

#define IDevPadTools_Disconnect(This)	\
    (This)->lpVtbl -> Disconnect(This)

#define IDevPadTools_HideDialog(This)	\
    (This)->lpVtbl -> HideDialog(This)

#define IDevPadTools_ShowDialog(This)	\
    (This)->lpVtbl -> ShowDialog(This)

#define IDevPadTools_MenuClick(This,ItemIndex,pVal)	\
    (This)->lpVtbl -> MenuClick(This,ItemIndex,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadTools_Connect_Proxy( 
    IDevPadTools __RPC_FAR * This,
    /* [in] */ IDevPadApp __RPC_FAR *DevPadApp);


void __RPC_STUB IDevPadTools_Connect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadTools_Disconnect_Proxy( 
    IDevPadTools __RPC_FAR * This);


void __RPC_STUB IDevPadTools_Disconnect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadTools_HideDialog_Proxy( 
    IDevPadTools __RPC_FAR * This);


void __RPC_STUB IDevPadTools_HideDialog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadTools_ShowDialog_Proxy( 
    IDevPadTools __RPC_FAR * This);


void __RPC_STUB IDevPadTools_ShowDialog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadTools_MenuClick_Proxy( 
    IDevPadTools __RPC_FAR * This,
    /* [in] */ long ItemIndex,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadTools_MenuClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadTools_INTERFACE_DEFINED__ */


#ifndef __IDevPadApp_INTERFACE_DEFINED__
#define __IDevPadApp_INTERFACE_DEFINED__

/* interface IDevPadApp */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadApp;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("f347ebdd-42fa-40cf-b002-98c748e53074")
    IDevPadApp : public IUnknown
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AppPath( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Documents( 
            /* [retval][out] */ IDevPadDocuments __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Menus( 
            /* [retval][out] */ IDevPadMenu __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Dialogs( 
            /* [retval][out] */ IDevPadDialog __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ApphWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadAppVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadApp __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadApp __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadApp __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AppPath )( 
            IDevPadApp __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Documents )( 
            IDevPadApp __RPC_FAR * This,
            /* [retval][out] */ IDevPadDocuments __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Menus )( 
            IDevPadApp __RPC_FAR * This,
            /* [retval][out] */ IDevPadMenu __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Dialogs )( 
            IDevPadApp __RPC_FAR * This,
            /* [retval][out] */ IDevPadDialog __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ApphWnd )( 
            IDevPadApp __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadAppVtbl;

    interface IDevPadApp
    {
        CONST_VTBL struct IDevPadAppVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadApp_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadApp_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadApp_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadApp_get_AppPath(This,pVal)	\
    (This)->lpVtbl -> get_AppPath(This,pVal)

#define IDevPadApp_get_Documents(This,pVal)	\
    (This)->lpVtbl -> get_Documents(This,pVal)

#define IDevPadApp_get_Menus(This,pVal)	\
    (This)->lpVtbl -> get_Menus(This,pVal)

#define IDevPadApp_get_Dialogs(This,pVal)	\
    (This)->lpVtbl -> get_Dialogs(This,pVal)

#define IDevPadApp_get_ApphWnd(This,pVal)	\
    (This)->lpVtbl -> get_ApphWnd(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadApp_get_AppPath_Proxy( 
    IDevPadApp __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadApp_get_AppPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadApp_get_Documents_Proxy( 
    IDevPadApp __RPC_FAR * This,
    /* [retval][out] */ IDevPadDocuments __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadApp_get_Documents_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadApp_get_Menus_Proxy( 
    IDevPadApp __RPC_FAR * This,
    /* [retval][out] */ IDevPadMenu __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadApp_get_Menus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadApp_get_Dialogs_Proxy( 
    IDevPadApp __RPC_FAR * This,
    /* [retval][out] */ IDevPadDialog __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadApp_get_Dialogs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadApp_get_ApphWnd_Proxy( 
    IDevPadApp __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadApp_get_ApphWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadApp_INTERFACE_DEFINED__ */


#ifndef __IDevPadDocuments_INTERFACE_DEFINED__
#define __IDevPadDocuments_INTERFACE_DEFINED__

/* interface IDevPadDocuments */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadDocuments;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("30c1719d-26f6-4346-9f94-628474b0759f")
    IDevPadDocuments : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE New( 
            /* [defaultvalue][in] */ VARIANT_BOOL Show,
            /* [defaultvalue][in] */ BSTR Template,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE LoadFile( 
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVAl) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DocumentIndex( 
            /* [in] */ long ID,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ItemByID( 
            /* [in] */ long ID,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ItemByPath( 
            /* [in] */ BSTR FileName,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long Item,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_NextIndex( 
            /* [in] */ long Index,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_PreviousIndex( 
            /* [in] */ long Index,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Remove( 
            /* [in] */ long ID) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ActiveDoc( 
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadDocumentsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadDocuments __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadDocuments __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *New )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL Show,
            /* [defaultvalue][in] */ BSTR Template,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadFile )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVAl);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DocumentIndex )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long ID,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemByID )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long ID,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemByPath )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Item )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long Item,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NextIndex )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long Index,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PreviousIndex )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long Index,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Count )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Remove )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [in] */ long ID);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ActiveDoc )( 
            IDevPadDocuments __RPC_FAR * This,
            /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadDocumentsVtbl;

    interface IDevPadDocuments
    {
        CONST_VTBL struct IDevPadDocumentsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadDocuments_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadDocuments_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadDocuments_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadDocuments_New(This,Show,Template,ForceText,pVal)	\
    (This)->lpVtbl -> New(This,Show,Template,ForceText,pVal)

#define IDevPadDocuments_LoadFile(This,FileName,ForceText,pVAl)	\
    (This)->lpVtbl -> LoadFile(This,FileName,ForceText,pVAl)

#define IDevPadDocuments_get_DocumentIndex(This,ID,pVal)	\
    (This)->lpVtbl -> get_DocumentIndex(This,ID,pVal)

#define IDevPadDocuments_get_ItemByID(This,ID,pVal)	\
    (This)->lpVtbl -> get_ItemByID(This,ID,pVal)

#define IDevPadDocuments_get_ItemByPath(This,FileName,pVal)	\
    (This)->lpVtbl -> get_ItemByPath(This,FileName,pVal)

#define IDevPadDocuments_get_Item(This,Item,pVal)	\
    (This)->lpVtbl -> get_Item(This,Item,pVal)

#define IDevPadDocuments_get_NextIndex(This,Index,pVal)	\
    (This)->lpVtbl -> get_NextIndex(This,Index,pVal)

#define IDevPadDocuments_get_PreviousIndex(This,Index,pVal)	\
    (This)->lpVtbl -> get_PreviousIndex(This,Index,pVal)

#define IDevPadDocuments_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IDevPadDocuments_Remove(This,ID)	\
    (This)->lpVtbl -> Remove(This,ID)

#define IDevPadDocuments_get_ActiveDoc(This,pVal)	\
    (This)->lpVtbl -> get_ActiveDoc(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_New_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL Show,
    /* [defaultvalue][in] */ BSTR Template,
    /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_New_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_LoadFile_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVAl);


void __RPC_STUB IDevPadDocuments_LoadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_DocumentIndex_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long ID,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_DocumentIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_ItemByID_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long ID,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_ItemByID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_ItemByPath_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_ItemByPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_Item_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long Item,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_NextIndex_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long Index,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_NextIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_PreviousIndex_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long Index,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_PreviousIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_Count_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_Remove_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [in] */ long ID);


void __RPC_STUB IDevPadDocuments_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocuments_get_ActiveDoc_Proxy( 
    IDevPadDocuments __RPC_FAR * This,
    /* [retval][out] */ IDevPadDocument __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IDevPadDocuments_get_ActiveDoc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadDocuments_INTERFACE_DEFINED__ */


#ifndef __IDevPadDocument_INTERFACE_DEFINED__
#define __IDevPadDocument_INTERFACE_DEFINED__

/* interface IDevPadDocument */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadDocument;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("34a62c4d-c778-4d2e-93ff-eeaaa9b240e9")
    IDevPadDocument : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FileName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FileTitle( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_CharacterCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_LineCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Saved( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Saved( 
            /* [in] */ VARIANT_BOOL Saved) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FileMode( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DocID( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_DocID( 
            /* [in] */ long NewID) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_hWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DocumenthWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SelText( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_SelText( 
            /* [in] */ BSTR Text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LoadOnActivate( 
            /* [in] */ BSTR FileName,
            /* [in] */ long SelStart,
            /* [in] */ long SelLength) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SelRTF( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_SelRTF( 
            /* [in] */ BSTR RTFCode) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Text( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Text( 
            /* [in] */ BSTR Text) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_RichText( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SelStart( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_SelStart( 
            /* [in] */ long Start) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_SelLength( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_SelLength( 
            /* [in] */ long Length) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_SaveOption( 
            /* [in] */ SaveOptions __RPC_FAR *Option) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_LoadingFile( 
            /* [in] */ VARIANT_BOOL Loading) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Modified( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Modified( 
            /* [in] */ VARIANT_BOOL Modified) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ShowLines( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_ShowLines( 
            /* [in] */ VARIANT_BOOL Visible) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Redraw( 
            /* [in] */ VARIANT_BOOL Redraw) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ViewMode( 
            /* [retval][out] */ DocumentViewModes __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_ViewMode( 
            /* [in] */ DocumentViewModes __RPC_FAR *ViewMode) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_IsRTF( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_IndentString( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_DocumentCaption( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_DocumentCaption( 
            /* [in] */ BSTR Title) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_WindowState( 
            /* [retval][out] */ INT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_WindowState( 
            /* [in] */ INT State) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Save( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SaveDocument( 
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL bIgnoreSave,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SaveAs( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Find( 
            /* [in] */ BSTR Find,
            /* [defaultvalue][in] */ long Start,
            /* [defaultvalue][in] */ long EndLimit,
            /* [defaultvalue][in] */ long Options,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE ChangeMode( 
            /* [in] */ BSTR File) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetFont( 
            /* [in] */ BSTR FontName,
            /* [in] */ short FontSize) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE LoadTemplate( 
            /* [in] */ BSTR FileName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RunCommand( 
            /* [in] */ BSTR Command) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Undo( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Redo( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Cut( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Copy( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Paste( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Append( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ToggleFlag( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddFlag( 
            /* [in] */ long Line) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ClearFlags( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SelectAll( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PreviousLine( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NextLine( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InsertTag( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Indent( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Outdent( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UncommentBlock( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CommentBlock( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteLine( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ChangeCase( 
            /* [in] */ VARIANT_BOOL ToUpperCase) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE StringEncode( 
            /* [in] */ VARIANT_BOOL ToString) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NextFlag( 
            /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PreviousFlag( 
            /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FirstFlag( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LastFlag( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFlags( 
            /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *Flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Show( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFocus( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CursorFile( 
            /* [in] */ VARIANT_BOOL AbsolutePath,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LoadFile( 
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetIndent( 
            /* [in] */ BSTR Line,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_LineText( 
            /* [defaultvalue][in] */ long Line,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_LineIndex( 
            /* [in] */ long Line,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_FlagCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_CurrentLine( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE LineFromChar( 
            /* [in] */ long CharPos,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadDocumentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadDocument __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadDocument __RPC_FAR * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileName )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileTitle )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CharacterCount )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LineCount )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Saved )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Saved )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Saved);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileMode )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DocID )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DocID )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long NewID);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DocumenthWnd )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelText )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelText )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Text);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadOnActivate )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [in] */ long SelStart,
            /* [in] */ long SelLength);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelRTF )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelRTF )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR RTFCode);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Text )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Text )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Text);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RichText )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelStart )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelStart )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long Start);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelLength )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelLength )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long Length);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SaveOption )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ SaveOptions __RPC_FAR *Option);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LoadingFile )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Loading);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Modified )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Modified )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Modified);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ShowLines )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ShowLines )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Visible);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Redraw )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Redraw);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ViewMode )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ DocumentViewModes __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ViewMode )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ DocumentViewModes __RPC_FAR *ViewMode);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsRTF )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IndentString )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DocumentCaption )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DocumentCaption )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Title);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WindowState )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ INT __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WindowState )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ INT State);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Save )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveDocument )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL bIgnoreSave,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveAs )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Find )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Find,
            /* [defaultvalue][in] */ long Start,
            /* [defaultvalue][in] */ long EndLimit,
            /* [defaultvalue][in] */ long Options,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ChangeMode )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR File);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFont )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR FontName,
            /* [in] */ short FontSize);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadTemplate )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR FileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RunCommand )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Command);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Undo )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Redo )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Cut )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Copy )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Paste )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Append )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ToggleFlag )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddFlag )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long Line);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearFlags )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SelectAll )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PreviousLine )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextLine )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InsertTag )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Indent )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Outdent )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UncommentBlock )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CommentBlock )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteLine )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ChangeCase )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL ToUpperCase);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StringEncode )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL ToString);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextFlag )( 
            IDevPadDocument __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PreviousFlag )( 
            IDevPadDocument __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FirstFlag )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LastFlag )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFlags )( 
            IDevPadDocument __RPC_FAR * This,
            /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *Flags);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Show )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFocus )( 
            IDevPadDocument __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CursorFile )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL AbsolutePath,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadFile )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIndent )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ BSTR Line,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LineText )( 
            IDevPadDocument __RPC_FAR * This,
            /* [defaultvalue][in] */ long Line,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LineIndex )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long Line,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FlagCount )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CurrentLine )( 
            IDevPadDocument __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LineFromChar )( 
            IDevPadDocument __RPC_FAR * This,
            /* [in] */ long CharPos,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadDocumentVtbl;

    interface IDevPadDocument
    {
        CONST_VTBL struct IDevPadDocumentVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadDocument_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadDocument_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadDocument_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadDocument_get_FileName(This,pVal)	\
    (This)->lpVtbl -> get_FileName(This,pVal)

#define IDevPadDocument_get_FileTitle(This,pVal)	\
    (This)->lpVtbl -> get_FileTitle(This,pVal)

#define IDevPadDocument_get_CharacterCount(This,pVal)	\
    (This)->lpVtbl -> get_CharacterCount(This,pVal)

#define IDevPadDocument_get_LineCount(This,pVal)	\
    (This)->lpVtbl -> get_LineCount(This,pVal)

#define IDevPadDocument_get_Saved(This,pVal)	\
    (This)->lpVtbl -> get_Saved(This,pVal)

#define IDevPadDocument_put_Saved(This,Saved)	\
    (This)->lpVtbl -> put_Saved(This,Saved)

#define IDevPadDocument_get_FileMode(This,pVal)	\
    (This)->lpVtbl -> get_FileMode(This,pVal)

#define IDevPadDocument_get_DocID(This,pVal)	\
    (This)->lpVtbl -> get_DocID(This,pVal)

#define IDevPadDocument_put_DocID(This,NewID)	\
    (This)->lpVtbl -> put_DocID(This,NewID)

#define IDevPadDocument_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)

#define IDevPadDocument_get_DocumenthWnd(This,pVal)	\
    (This)->lpVtbl -> get_DocumenthWnd(This,pVal)

#define IDevPadDocument_get_SelText(This,pVal)	\
    (This)->lpVtbl -> get_SelText(This,pVal)

#define IDevPadDocument_put_SelText(This,Text)	\
    (This)->lpVtbl -> put_SelText(This,Text)

#define IDevPadDocument_LoadOnActivate(This,FileName,SelStart,SelLength)	\
    (This)->lpVtbl -> LoadOnActivate(This,FileName,SelStart,SelLength)

#define IDevPadDocument_get_SelRTF(This,pVal)	\
    (This)->lpVtbl -> get_SelRTF(This,pVal)

#define IDevPadDocument_put_SelRTF(This,RTFCode)	\
    (This)->lpVtbl -> put_SelRTF(This,RTFCode)

#define IDevPadDocument_get_Text(This,pVal)	\
    (This)->lpVtbl -> get_Text(This,pVal)

#define IDevPadDocument_put_Text(This,Text)	\
    (This)->lpVtbl -> put_Text(This,Text)

#define IDevPadDocument_get_RichText(This,pVal)	\
    (This)->lpVtbl -> get_RichText(This,pVal)

#define IDevPadDocument_get_SelStart(This,pVal)	\
    (This)->lpVtbl -> get_SelStart(This,pVal)

#define IDevPadDocument_put_SelStart(This,Start)	\
    (This)->lpVtbl -> put_SelStart(This,Start)

#define IDevPadDocument_get_SelLength(This,pVal)	\
    (This)->lpVtbl -> get_SelLength(This,pVal)

#define IDevPadDocument_put_SelLength(This,Length)	\
    (This)->lpVtbl -> put_SelLength(This,Length)

#define IDevPadDocument_put_SaveOption(This,Option)	\
    (This)->lpVtbl -> put_SaveOption(This,Option)

#define IDevPadDocument_put_LoadingFile(This,Loading)	\
    (This)->lpVtbl -> put_LoadingFile(This,Loading)

#define IDevPadDocument_get_Modified(This,pVal)	\
    (This)->lpVtbl -> get_Modified(This,pVal)

#define IDevPadDocument_put_Modified(This,Modified)	\
    (This)->lpVtbl -> put_Modified(This,Modified)

#define IDevPadDocument_get_ShowLines(This,pVal)	\
    (This)->lpVtbl -> get_ShowLines(This,pVal)

#define IDevPadDocument_put_ShowLines(This,Visible)	\
    (This)->lpVtbl -> put_ShowLines(This,Visible)

#define IDevPadDocument_put_Redraw(This,Redraw)	\
    (This)->lpVtbl -> put_Redraw(This,Redraw)

#define IDevPadDocument_get_ViewMode(This,pVal)	\
    (This)->lpVtbl -> get_ViewMode(This,pVal)

#define IDevPadDocument_put_ViewMode(This,ViewMode)	\
    (This)->lpVtbl -> put_ViewMode(This,ViewMode)

#define IDevPadDocument_get_IsRTF(This,pVal)	\
    (This)->lpVtbl -> get_IsRTF(This,pVal)

#define IDevPadDocument_get_IndentString(This,pVal)	\
    (This)->lpVtbl -> get_IndentString(This,pVal)

#define IDevPadDocument_get_DocumentCaption(This,pVal)	\
    (This)->lpVtbl -> get_DocumentCaption(This,pVal)

#define IDevPadDocument_put_DocumentCaption(This,Title)	\
    (This)->lpVtbl -> put_DocumentCaption(This,Title)

#define IDevPadDocument_get_WindowState(This,pVal)	\
    (This)->lpVtbl -> get_WindowState(This,pVal)

#define IDevPadDocument_put_WindowState(This,State)	\
    (This)->lpVtbl -> put_WindowState(This,State)

#define IDevPadDocument_Save(This,pVal)	\
    (This)->lpVtbl -> Save(This,pVal)

#define IDevPadDocument_SaveDocument(This,FileName,bIgnoreSave,pVal)	\
    (This)->lpVtbl -> SaveDocument(This,FileName,bIgnoreSave,pVal)

#define IDevPadDocument_SaveAs(This,pVal)	\
    (This)->lpVtbl -> SaveAs(This,pVal)

#define IDevPadDocument_Find(This,Find,Start,EndLimit,Options,pVal)	\
    (This)->lpVtbl -> Find(This,Find,Start,EndLimit,Options,pVal)

#define IDevPadDocument_ChangeMode(This,File)	\
    (This)->lpVtbl -> ChangeMode(This,File)

#define IDevPadDocument_SetFont(This,FontName,FontSize)	\
    (This)->lpVtbl -> SetFont(This,FontName,FontSize)

#define IDevPadDocument_LoadTemplate(This,FileName)	\
    (This)->lpVtbl -> LoadTemplate(This,FileName)

#define IDevPadDocument_RunCommand(This,Command)	\
    (This)->lpVtbl -> RunCommand(This,Command)

#define IDevPadDocument_Undo(This)	\
    (This)->lpVtbl -> Undo(This)

#define IDevPadDocument_Redo(This)	\
    (This)->lpVtbl -> Redo(This)

#define IDevPadDocument_Cut(This)	\
    (This)->lpVtbl -> Cut(This)

#define IDevPadDocument_Copy(This)	\
    (This)->lpVtbl -> Copy(This)

#define IDevPadDocument_Paste(This)	\
    (This)->lpVtbl -> Paste(This)

#define IDevPadDocument_Append(This)	\
    (This)->lpVtbl -> Append(This)

#define IDevPadDocument_ToggleFlag(This)	\
    (This)->lpVtbl -> ToggleFlag(This)

#define IDevPadDocument_AddFlag(This,Line)	\
    (This)->lpVtbl -> AddFlag(This,Line)

#define IDevPadDocument_ClearFlags(This)	\
    (This)->lpVtbl -> ClearFlags(This)

#define IDevPadDocument_SelectAll(This)	\
    (This)->lpVtbl -> SelectAll(This)

#define IDevPadDocument_PreviousLine(This)	\
    (This)->lpVtbl -> PreviousLine(This)

#define IDevPadDocument_NextLine(This)	\
    (This)->lpVtbl -> NextLine(This)

#define IDevPadDocument_InsertTag(This)	\
    (This)->lpVtbl -> InsertTag(This)

#define IDevPadDocument_Indent(This)	\
    (This)->lpVtbl -> Indent(This)

#define IDevPadDocument_Outdent(This)	\
    (This)->lpVtbl -> Outdent(This)

#define IDevPadDocument_UncommentBlock(This)	\
    (This)->lpVtbl -> UncommentBlock(This)

#define IDevPadDocument_CommentBlock(This)	\
    (This)->lpVtbl -> CommentBlock(This)

#define IDevPadDocument_DeleteLine(This)	\
    (This)->lpVtbl -> DeleteLine(This)

#define IDevPadDocument_ChangeCase(This,ToUpperCase)	\
    (This)->lpVtbl -> ChangeCase(This,ToUpperCase)

#define IDevPadDocument_StringEncode(This,ToString)	\
    (This)->lpVtbl -> StringEncode(This,ToString)

#define IDevPadDocument_NextFlag(This,LoopDoc,pVal)	\
    (This)->lpVtbl -> NextFlag(This,LoopDoc,pVal)

#define IDevPadDocument_PreviousFlag(This,LoopDoc,pVal)	\
    (This)->lpVtbl -> PreviousFlag(This,LoopDoc,pVal)

#define IDevPadDocument_FirstFlag(This,pVal)	\
    (This)->lpVtbl -> FirstFlag(This,pVal)

#define IDevPadDocument_LastFlag(This,pVal)	\
    (This)->lpVtbl -> LastFlag(This,pVal)

#define IDevPadDocument_GetFlags(This,Flags)	\
    (This)->lpVtbl -> GetFlags(This,Flags)

#define IDevPadDocument_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IDevPadDocument_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IDevPadDocument_SetFocus(This)	\
    (This)->lpVtbl -> SetFocus(This)

#define IDevPadDocument_CursorFile(This,AbsolutePath,pVal)	\
    (This)->lpVtbl -> CursorFile(This,AbsolutePath,pVal)

#define IDevPadDocument_LoadFile(This,FileName,ForceText,pVal)	\
    (This)->lpVtbl -> LoadFile(This,FileName,ForceText,pVal)

#define IDevPadDocument_GetIndent(This,Line,pVal)	\
    (This)->lpVtbl -> GetIndent(This,Line,pVal)

#define IDevPadDocument_get_LineText(This,Line,pVal)	\
    (This)->lpVtbl -> get_LineText(This,Line,pVal)

#define IDevPadDocument_get_LineIndex(This,Line,pVal)	\
    (This)->lpVtbl -> get_LineIndex(This,Line,pVal)

#define IDevPadDocument_get_FlagCount(This,pVal)	\
    (This)->lpVtbl -> get_FlagCount(This,pVal)

#define IDevPadDocument_get_CurrentLine(This,pVal)	\
    (This)->lpVtbl -> get_CurrentLine(This,pVal)

#define IDevPadDocument_LineFromChar(This,CharPos,pVal)	\
    (This)->lpVtbl -> LineFromChar(This,CharPos,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_FileName_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_FileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_FileTitle_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_FileTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_CharacterCount_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_CharacterCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_LineCount_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_LineCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_Saved_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_Saved_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_Saved_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Saved);


void __RPC_STUB IDevPadDocument_put_Saved_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_FileMode_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_FileMode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_DocID_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_DocID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_DocID_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long NewID);


void __RPC_STUB IDevPadDocument_put_DocID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_hWnd_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_hWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_DocumenthWnd_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_DocumenthWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_SelText_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_SelText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_SelText_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Text);


void __RPC_STUB IDevPadDocument_put_SelText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_LoadOnActivate_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [in] */ long SelStart,
    /* [in] */ long SelLength);


void __RPC_STUB IDevPadDocument_LoadOnActivate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_SelRTF_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_SelRTF_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_SelRTF_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR RTFCode);


void __RPC_STUB IDevPadDocument_put_SelRTF_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_Text_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_Text_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Text);


void __RPC_STUB IDevPadDocument_put_Text_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_RichText_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_RichText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_SelStart_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_SelStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_SelStart_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long Start);


void __RPC_STUB IDevPadDocument_put_SelStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_SelLength_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_SelLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_SelLength_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long Length);


void __RPC_STUB IDevPadDocument_put_SelLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_SaveOption_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ SaveOptions __RPC_FAR *Option);


void __RPC_STUB IDevPadDocument_put_SaveOption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_LoadingFile_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Loading);


void __RPC_STUB IDevPadDocument_put_LoadingFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_Modified_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_Modified_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_Modified_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Modified);


void __RPC_STUB IDevPadDocument_put_Modified_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_ShowLines_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_ShowLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_ShowLines_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Visible);


void __RPC_STUB IDevPadDocument_put_ShowLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_Redraw_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Redraw);


void __RPC_STUB IDevPadDocument_put_Redraw_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_ViewMode_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ DocumentViewModes __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_ViewMode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_ViewMode_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ DocumentViewModes __RPC_FAR *ViewMode);


void __RPC_STUB IDevPadDocument_put_ViewMode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_IsRTF_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_IsRTF_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_IndentString_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_IndentString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_DocumentCaption_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_DocumentCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_DocumentCaption_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Title);


void __RPC_STUB IDevPadDocument_put_DocumentCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_WindowState_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ INT __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_WindowState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_put_WindowState_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ INT State);


void __RPC_STUB IDevPadDocument_put_WindowState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_Save_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_SaveDocument_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [defaultvalue][in] */ VARIANT_BOOL bIgnoreSave,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_SaveDocument_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_SaveAs_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_SaveAs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_Find_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Find,
    /* [defaultvalue][in] */ long Start,
    /* [defaultvalue][in] */ long EndLimit,
    /* [defaultvalue][in] */ long Options,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_Find_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_ChangeMode_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR File);


void __RPC_STUB IDevPadDocument_ChangeMode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_SetFont_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR FontName,
    /* [in] */ short FontSize);


void __RPC_STUB IDevPadDocument_SetFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_LoadTemplate_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR FileName);


void __RPC_STUB IDevPadDocument_LoadTemplate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_RunCommand_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Command);


void __RPC_STUB IDevPadDocument_RunCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Undo_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Undo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Redo_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Redo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Cut_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Cut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Copy_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Copy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Paste_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Paste_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Append_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Append_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_ToggleFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_ToggleFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_AddFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long Line);


void __RPC_STUB IDevPadDocument_AddFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_ClearFlags_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_ClearFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_SelectAll_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_SelectAll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_PreviousLine_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_PreviousLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_NextLine_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_NextLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_InsertTag_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_InsertTag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Indent_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Indent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Outdent_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Outdent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_UncommentBlock_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_UncommentBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_CommentBlock_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_CommentBlock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_DeleteLine_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_DeleteLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_ChangeCase_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL ToUpperCase);


void __RPC_STUB IDevPadDocument_ChangeCase_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_StringEncode_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL ToString);


void __RPC_STUB IDevPadDocument_StringEncode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_NextFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_NextFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_PreviousFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL LoopDoc,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_PreviousFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_FirstFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_FirstFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_LastFlag_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_LastFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_GetFlags_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *Flags);


void __RPC_STUB IDevPadDocument_GetFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Show_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Show_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_Close_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_SetFocus_Proxy( 
    IDevPadDocument __RPC_FAR * This);


void __RPC_STUB IDevPadDocument_SetFocus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_CursorFile_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL AbsolutePath,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_CursorFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadDocument_LoadFile_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [defaultvalue][in] */ VARIANT_BOOL ForceText,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_LoadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_GetIndent_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ BSTR Line,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_GetIndent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_LineText_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [defaultvalue][in] */ long Line,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_LineText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_LineIndex_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long Line,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_LineIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_FlagCount_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_FlagCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_get_CurrentLine_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_get_CurrentLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadDocument_LineFromChar_Proxy( 
    IDevPadDocument __RPC_FAR * This,
    /* [in] */ long CharPos,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDocument_LineFromChar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadDocument_INTERFACE_DEFINED__ */


#ifndef __IDevPadDialog_INTERFACE_DEFINED__
#define __IDevPadDialog_INTERFACE_DEFINED__

/* interface IDevPadDialog */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadDialog;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("30c1719d-26f6-4346-9f94-628474b0769f")
    IDevPadDialog : public IUnknown
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ErrHandler( 
            long ErrorNum,
            BSTR ErrorText,
            /* [defaultvalue][in] */ BSTR Source = L"",
            /* [defaultvalue][in] */ BSTR DebugInfo = L"",
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm = "(null)") = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowHelpTopic( 
            /* [in] */ long Topic,
            /* [in] */ long hWnd) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowHelp( 
            /* [in] */ VARIANT_BOOL Contents) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowOpenSaveDialog( 
            /* [in] */ VARIANT_BOOL Save,
            /* [in] */ BSTR Title,
            /* [in] */ BSTR Filter,
            /* [defaultvalue][in] */ BSTR Filename,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *Owner,
            /* [defaultvalue][in] */ long InitFilterIndex,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowWarning( 
            /* [in] */ BSTR Prompt,
            /* [defaultvalue][in] */ BSTR Source = L"",
            /* [defaultvalue][in] */ BSTR DialogTitle = L"Warning",
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm = "(null)") = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InputBox( 
            /* [in] */ BSTR Prompt,
            /* [in] */ BSTR DialogTitle,
            /* [defaultvalue][in] */ BSTR DefaultValue,
            /* [defaultvalue][in] */ long SelStart,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowYesNo( 
            /* [in] */ BSTR Question,
            /* [in] */ VARIANT_BOOL ShowCancel,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm,
            /* [retval][out] */ ShowYesNoResult __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE BrowseForFolder( 
            /* [defaultvalue][in] */ BSTR InitialDir,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FileName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FileTitle( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FilterIndex( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadDialogVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadDialog __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadDialog __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ErrHandler )( 
            IDevPadDialog __RPC_FAR * This,
            long ErrorNum,
            BSTR ErrorText,
            /* [defaultvalue][in] */ BSTR Source,
            /* [defaultvalue][in] */ BSTR DebugInfo,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowHelpTopic )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ long Topic,
            /* [in] */ long hWnd);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowHelp )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Contents);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowOpenSaveDialog )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL Save,
            /* [in] */ BSTR Title,
            /* [in] */ BSTR Filter,
            /* [defaultvalue][in] */ BSTR Filename,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *Owner,
            /* [defaultvalue][in] */ long InitFilterIndex,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowWarning )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ BSTR Prompt,
            /* [defaultvalue][in] */ BSTR Source,
            /* [defaultvalue][in] */ BSTR DialogTitle,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InputBox )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ BSTR Prompt,
            /* [in] */ BSTR DialogTitle,
            /* [defaultvalue][in] */ BSTR DefaultValue,
            /* [defaultvalue][in] */ long SelStart,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowYesNo )( 
            IDevPadDialog __RPC_FAR * This,
            /* [in] */ BSTR Question,
            /* [in] */ VARIANT_BOOL ShowCancel,
            /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm,
            /* [retval][out] */ ShowYesNoResult __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BrowseForFolder )( 
            IDevPadDialog __RPC_FAR * This,
            /* [defaultvalue][in] */ BSTR InitialDir,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileName )( 
            IDevPadDialog __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FileTitle )( 
            IDevPadDialog __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FilterIndex )( 
            IDevPadDialog __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadDialogVtbl;

    interface IDevPadDialog
    {
        CONST_VTBL struct IDevPadDialogVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadDialog_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadDialog_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadDialog_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadDialog_ErrHandler(This,ErrorNum,ErrorText,Source,DebugInfo,ParentForm)	\
    (This)->lpVtbl -> ErrHandler(This,ErrorNum,ErrorText,Source,DebugInfo,ParentForm)

#define IDevPadDialog_ShowHelpTopic(This,Topic,hWnd)	\
    (This)->lpVtbl -> ShowHelpTopic(This,Topic,hWnd)

#define IDevPadDialog_ShowHelp(This,Contents)	\
    (This)->lpVtbl -> ShowHelp(This,Contents)

#define IDevPadDialog_ShowOpenSaveDialog(This,Save,Title,Filter,Filename,Owner,InitFilterIndex,pVal)	\
    (This)->lpVtbl -> ShowOpenSaveDialog(This,Save,Title,Filter,Filename,Owner,InitFilterIndex,pVal)

#define IDevPadDialog_ShowWarning(This,Prompt,Source,DialogTitle,ParentForm)	\
    (This)->lpVtbl -> ShowWarning(This,Prompt,Source,DialogTitle,ParentForm)

#define IDevPadDialog_InputBox(This,Prompt,DialogTitle,DefaultValue,SelStart,pVal)	\
    (This)->lpVtbl -> InputBox(This,Prompt,DialogTitle,DefaultValue,SelStart,pVal)

#define IDevPadDialog_ShowYesNo(This,Question,ShowCancel,ParentForm,pVal)	\
    (This)->lpVtbl -> ShowYesNo(This,Question,ShowCancel,ParentForm,pVal)

#define IDevPadDialog_BrowseForFolder(This,InitialDir,pVal)	\
    (This)->lpVtbl -> BrowseForFolder(This,InitialDir,pVal)

#define IDevPadDialog_get_FileName(This,pVal)	\
    (This)->lpVtbl -> get_FileName(This,pVal)

#define IDevPadDialog_get_FileTitle(This,pVal)	\
    (This)->lpVtbl -> get_FileTitle(This,pVal)

#define IDevPadDialog_get_FilterIndex(This,pVal)	\
    (This)->lpVtbl -> get_FilterIndex(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ErrHandler_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    long ErrorNum,
    BSTR ErrorText,
    /* [defaultvalue][in] */ BSTR Source,
    /* [defaultvalue][in] */ BSTR DebugInfo,
    /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm);


void __RPC_STUB IDevPadDialog_ErrHandler_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ShowHelpTopic_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ long Topic,
    /* [in] */ long hWnd);


void __RPC_STUB IDevPadDialog_ShowHelpTopic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ShowHelp_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Contents);


void __RPC_STUB IDevPadDialog_ShowHelp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ShowOpenSaveDialog_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL Save,
    /* [in] */ BSTR Title,
    /* [in] */ BSTR Filter,
    /* [defaultvalue][in] */ BSTR Filename,
    /* [defaultvalue][in] */ IDispatch __RPC_FAR *Owner,
    /* [defaultvalue][in] */ long InitFilterIndex,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_ShowOpenSaveDialog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ShowWarning_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ BSTR Prompt,
    /* [defaultvalue][in] */ BSTR Source,
    /* [defaultvalue][in] */ BSTR DialogTitle,
    /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm);


void __RPC_STUB IDevPadDialog_ShowWarning_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_InputBox_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ BSTR Prompt,
    /* [in] */ BSTR DialogTitle,
    /* [defaultvalue][in] */ BSTR DefaultValue,
    /* [defaultvalue][in] */ long SelStart,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_InputBox_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_ShowYesNo_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [in] */ BSTR Question,
    /* [in] */ VARIANT_BOOL ShowCancel,
    /* [defaultvalue][in] */ IDispatch __RPC_FAR *ParentForm,
    /* [retval][out] */ ShowYesNoResult __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_ShowYesNo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_BrowseForFolder_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [defaultvalue][in] */ BSTR InitialDir,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_BrowseForFolder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_get_FileName_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_get_FileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_get_FileTitle_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_get_FileTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDevPadDialog_get_FilterIndex_Proxy( 
    IDevPadDialog __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadDialog_get_FilterIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadDialog_INTERFACE_DEFINED__ */


#ifndef __IDevPadMenu_INTERFACE_DEFINED__
#define __IDevPadMenu_INTERFACE_DEFINED__

/* interface IDevPadMenu */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadMenu;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("30c1719d-26f6-4346-9f94-628474b0769e")
    IDevPadMenu : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Enabled( 
            /* [in] */ VARIANT Key,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Enabled( 
            /* [in] */ VARIANT Key,
            /* [in] */ VARIANT_BOOL Enabled) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Checked( 
            /* [in] */ VARIANT Key,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Checked( 
            /* [in] */ VARIANT Key,
            /* [in] */ VARIANT_BOOL Checked) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ItemKey( 
            /* [in] */ long Index,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_ItemKey( 
            /* [in] */ long Index,
            /* [in] */ BSTR Key) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Caption( 
            /* [in] */ VARIANT Key,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Caption( 
            /* [in] */ VARIANT Key,
            /* [in] */ BSTR Caption) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ItemIndex( 
            /* [in] */ BSTR Key,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Remove( 
            /* [in] */ VARIANT Key) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE AddMenuItem( 
            /* [in] */ BSTR Caption,
            /* [in] */ BSTR Key,
            /* [in] */ long ParentIndex,
            /* [optional][in] */ long IconIndex,
            /* [optional][in] */ long ItemData,
            /* [optional][in] */ VARIANT_BOOL InsertItem) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadMenuVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadMenu __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadMenu __RPC_FAR * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Enabled )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Enabled )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [in] */ VARIANT_BOOL Enabled);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Checked )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Checked )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [in] */ VARIANT_BOOL Checked);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemKey )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ long Index,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemKey )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ long Index,
            /* [in] */ BSTR Key);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Caption )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Caption )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key,
            /* [in] */ BSTR Caption);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemIndex )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ BSTR Key,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Remove )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ VARIANT Key);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddMenuItem )( 
            IDevPadMenu __RPC_FAR * This,
            /* [in] */ BSTR Caption,
            /* [in] */ BSTR Key,
            /* [in] */ long ParentIndex,
            /* [optional][in] */ long IconIndex,
            /* [optional][in] */ long ItemData,
            /* [optional][in] */ VARIANT_BOOL InsertItem);
        
        END_INTERFACE
    } IDevPadMenuVtbl;

    interface IDevPadMenu
    {
        CONST_VTBL struct IDevPadMenuVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadMenu_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadMenu_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadMenu_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadMenu_get_Enabled(This,Key,pVal)	\
    (This)->lpVtbl -> get_Enabled(This,Key,pVal)

#define IDevPadMenu_put_Enabled(This,Key,Enabled)	\
    (This)->lpVtbl -> put_Enabled(This,Key,Enabled)

#define IDevPadMenu_get_Checked(This,Key,pVal)	\
    (This)->lpVtbl -> get_Checked(This,Key,pVal)

#define IDevPadMenu_put_Checked(This,Key,Checked)	\
    (This)->lpVtbl -> put_Checked(This,Key,Checked)

#define IDevPadMenu_get_ItemKey(This,Index,pVal)	\
    (This)->lpVtbl -> get_ItemKey(This,Index,pVal)

#define IDevPadMenu_put_ItemKey(This,Index,Key)	\
    (This)->lpVtbl -> put_ItemKey(This,Index,Key)

#define IDevPadMenu_get_Caption(This,Key,pVal)	\
    (This)->lpVtbl -> get_Caption(This,Key,pVal)

#define IDevPadMenu_put_Caption(This,Key,Caption)	\
    (This)->lpVtbl -> put_Caption(This,Key,Caption)

#define IDevPadMenu_get_ItemIndex(This,Key,pVal)	\
    (This)->lpVtbl -> get_ItemIndex(This,Key,pVal)

#define IDevPadMenu_Remove(This,Key)	\
    (This)->lpVtbl -> Remove(This,Key)

#define IDevPadMenu_AddMenuItem(This,Caption,Key,ParentIndex,IconIndex,ItemData,InsertItem)	\
    (This)->lpVtbl -> AddMenuItem(This,Caption,Key,ParentIndex,IconIndex,ItemData,InsertItem)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_get_Enabled_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadMenu_get_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_put_Enabled_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [in] */ VARIANT_BOOL Enabled);


void __RPC_STUB IDevPadMenu_put_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_get_Checked_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadMenu_get_Checked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_put_Checked_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [in] */ VARIANT_BOOL Checked);


void __RPC_STUB IDevPadMenu_put_Checked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_get_ItemKey_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ long Index,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadMenu_get_ItemKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_put_ItemKey_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ long Index,
    /* [in] */ BSTR Key);


void __RPC_STUB IDevPadMenu_put_ItemKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_get_Caption_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDevPadMenu_get_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_put_Caption_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key,
    /* [in] */ BSTR Caption);


void __RPC_STUB IDevPadMenu_put_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_get_ItemIndex_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ BSTR Key,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IDevPadMenu_get_ItemIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_Remove_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ VARIANT Key);


void __RPC_STUB IDevPadMenu_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDevPadMenu_AddMenuItem_Proxy( 
    IDevPadMenu __RPC_FAR * This,
    /* [in] */ BSTR Caption,
    /* [in] */ BSTR Key,
    /* [in] */ long ParentIndex,
    /* [optional][in] */ long IconIndex,
    /* [optional][in] */ long ItemData,
    /* [optional][in] */ VARIANT_BOOL InsertItem);


void __RPC_STUB IDevPadMenu_AddMenuItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadMenu_INTERFACE_DEFINED__ */

#endif /* __DevPadAddInTlb_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
