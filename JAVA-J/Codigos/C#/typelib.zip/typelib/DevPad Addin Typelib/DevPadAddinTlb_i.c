/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed May 16 15:51:47 2001
 */
/* Compiler settings for C:\Documents and Settings\Administrator\My Documents\Development\Visual Basic\Regular\DevPad\Current Release\Resources\typelib\DevPad AddIn TypeLib\DevPadAddinTlb.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_DevPadAddInTlb = {0xad3cc26f,0xe174,0x4a39,{0x96,0x4a,0x2f,0x7b,0xcb,0x56,0x2a,0xa1}};


const IID IID_IDevPadTools = {0x30c1719d,0x26f6,0x4346,{0x9f,0x94,0x62,0x84,0x74,0xb0,0x76,0x9d}};


const IID IID_IDevPadApp = {0xf347ebdd,0x42fa,0x40cf,{0xb0,0x02,0x98,0xc7,0x48,0xe5,0x30,0x74}};


const IID IID_IDevPadDocuments = {0x30c1719d,0x26f6,0x4346,{0x9f,0x94,0x62,0x84,0x74,0xb0,0x75,0x9f}};


const IID IID_IDevPadDocument = {0x34a62c4d,0xc778,0x4d2e,{0x93,0xff,0xee,0xaa,0xa9,0xb2,0x40,0xe9}};


const IID IID_IDevPadDialog = {0x30c1719d,0x26f6,0x4346,{0x9f,0x94,0x62,0x84,0x74,0xb0,0x76,0x9f}};


const IID IID_IDevPadMenu = {0x30c1719d,0x26f6,0x4346,{0x9f,0x94,0x62,0x84,0x74,0xb0,0x76,0x9e}};


#ifdef __cplusplus
}
#endif

