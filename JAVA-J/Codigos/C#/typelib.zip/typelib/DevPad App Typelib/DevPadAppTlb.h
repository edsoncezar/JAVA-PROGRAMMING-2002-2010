/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed May 09 16:24:06 2001
 */
/* Compiler settings for C:\Documents and Settings\Administrator\My Documents\Development\Visual Basic\Regular\DevPad\Current Release\Resources\typelib\DevPad App Typelib\DevPadAppTlb.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __DevPadAppTlb_h__
#define __DevPadAppTlb_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDevPadProjectEx_FWD_DEFINED__
#define __IDevPadProjectEx_FWD_DEFINED__
typedef interface IDevPadProjectEx IDevPadProjectEx;
#endif 	/* __IDevPadProjectEx_FWD_DEFINED__ */


void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __DevPadAppTlb_LIBRARY_DEFINED__
#define __DevPadAppTlb_LIBRARY_DEFINED__

/* library DevPadAppTlb */
/* [helpstring][version][uuid] */ 


typedef /* [version][v1_enum][uuid] */ 
enum ProjectTypes
    {	tDevPad	= 0,
	tVB	= 1,
	tVBGroup	= 2,
	tVC	= 3,
	tCnet	= 4,
	tVBnet	= 5
    }	ProjectTypes;

typedef struct  ADDININFO
    {
    BSTR ClassName;
    BSTR Name;
    BSTR Description;
    BSTR Icon;
    BSTR Category;
    BSTR Author;
    BSTR Website;
    VARIANT_BOOL ShowInTB;
    VARIANT_BOOL ShowInMenu;
    VARIANT_BOOL LoadAtStartup;
    VARIANT_BOOL Loaded;
    /* external definition not present */ IDevPadTools __RPC_FAR *Tool;
    }	ADDININFO;


IDevPadProjectEx 
EXTERN_C const IID LIBID_DevPadAppTlb;

#ifndef __IDevPadProjectEx_INTERFACE_DEFINED__
#define __IDevPadProjectEx_INTERFACE_DEFINED__

/* interface IDevPadProjectEx */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDevPadProjectEx;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4f627a70-720f-44ec-a4db-7b7fc8a07fc2")
    IDevPadProjectEx : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SaveProject2( 
            /* [out][in] */ ADDININFO __RPC_FAR *TestParam) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SaveProject( 
            /* [in] */ BSTR FileName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LoadProject( 
            /* [in] */ BSTR FileName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_ProjectType( 
            /* [retval][out] */ ProjectTypes __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDevPadProjectExVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDevPadProjectEx __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDevPadProjectEx __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDevPadProjectEx __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveProject2 )( 
            IDevPadProjectEx __RPC_FAR * This,
            /* [out][in] */ ADDININFO __RPC_FAR *TestParam);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveProject )( 
            IDevPadProjectEx __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadProject )( 
            IDevPadProjectEx __RPC_FAR * This,
            /* [in] */ BSTR FileName,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ProjectType )( 
            IDevPadProjectEx __RPC_FAR * This,
            /* [retval][out] */ ProjectTypes __RPC_FAR *pVal);
        
        END_INTERFACE
    } IDevPadProjectExVtbl;

    interface IDevPadProjectEx
    {
        CONST_VTBL struct IDevPadProjectExVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDevPadProjectEx_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDevPadProjectEx_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDevPadProjectEx_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDevPadProjectEx_SaveProject2(This,TestParam)	\
    (This)->lpVtbl -> SaveProject2(This,TestParam)

#define IDevPadProjectEx_SaveProject(This,FileName,pVal)	\
    (This)->lpVtbl -> SaveProject(This,FileName,pVal)

#define IDevPadProjectEx_LoadProject(This,FileName,pVal)	\
    (This)->lpVtbl -> LoadProject(This,FileName,pVal)

#define IDevPadProjectEx_get_ProjectType(This,pVal)	\
    (This)->lpVtbl -> get_ProjectType(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDevPadProjectEx_SaveProject2_Proxy( 
    IDevPadProjectEx __RPC_FAR * This,
    /* [out][in] */ ADDININFO __RPC_FAR *TestParam);


void __RPC_STUB IDevPadProjectEx_SaveProject2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadProjectEx_SaveProject_Proxy( 
    IDevPadProjectEx __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadProjectEx_SaveProject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDevPadProjectEx_LoadProject_Proxy( 
    IDevPadProjectEx __RPC_FAR * This,
    /* [in] */ BSTR FileName,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IDevPadProjectEx_LoadProject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IDevPadProjectEx_get_ProjectType_Proxy( 
    IDevPadProjectEx __RPC_FAR * This,
    /* [retval][out] */ ProjectTypes __RPC_FAR *pVal);


void __RPC_STUB IDevPadProjectEx_get_ProjectType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDevPadProjectEx_INTERFACE_DEFINED__ */

#endif /* __DevPadAppTlb_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
