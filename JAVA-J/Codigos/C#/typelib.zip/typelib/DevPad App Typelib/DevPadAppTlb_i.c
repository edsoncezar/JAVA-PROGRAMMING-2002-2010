/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed May 09 16:24:06 2001
 */
/* Compiler settings for C:\Documents and Settings\Administrator\My Documents\Development\Visual Basic\Regular\DevPad\Current Release\Resources\typelib\DevPad App Typelib\DevPadAppTlb.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_DevPadAppTlb = {0xbe6925f6,0x4b54,0x4e4d,{0xa6,0x24,0xa7,0xd0,0x3c,0xf1,0x6a,0xf8}};


const IID IID_IDevPadProjectEx = {0x4f627a70,0x720f,0x44ec,{0xa4,0xdb,0x7b,0x7f,0xc8,0xa0,0x7f,0xc2}};


#ifdef __cplusplus
}
#endif

