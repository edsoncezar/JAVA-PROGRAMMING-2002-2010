
 Multi-threaded.Web.Application.Case.II.Port.Scanner
 ===================================================

	On: March 07, 2002
	By: Tin Lam (tin@netismtoday.com)
	    http://www.netismtoday.com

 Setup:
 ======

	Put both the portscanner.aspx and portscanner.aspx.cs in 
	a virtual/physical directory of IIS. Make sure
	the directory is marked as an application. If not,
	launch the IIS MMC, right click on the directory,
	select properties, in the "Virtual Directory" tab,
	click "Create" under the Application Settings.