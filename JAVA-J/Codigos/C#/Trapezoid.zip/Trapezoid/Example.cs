/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2003 CenterSpace Software, LLC                            //
//                                                                         //
// This code is free software under the Artistic license.                  //
//                                                                         //
// CenterSpace Software                                                    //
// 2098 NW Myrtlewood Way                                                  //
// Corvallis, Oregon, 97330                                                //
// USA                                                                     //
// http://www.centerspace.net                                              //
/////////////////////////////////////////////////////////////////////////////

using System;

namespace Trapezoid
{
	public class Example
	{
    public static void Main()
    {
      Console.WriteLine();
      double lower = 0.3;
      double upper = 0.6;
      DoubleFunction function = new DoubleFunction( Example.Foo );
      double integral = TrapezoidalRule.Integrate( function, lower, upper );
      Console.WriteLine( "Integral from " + lower + " to " + upper + " is " + integral );
      Console.ReadLine();
    }

    internal static double Foo( double d )
    {
      return Math.Sin( d ) + ( d * d );
    }
	}
}
