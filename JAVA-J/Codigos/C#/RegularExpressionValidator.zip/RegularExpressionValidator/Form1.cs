using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions ;

namespace RegularExpressionValidator
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmRegexValidator : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnValidateRegex;
		private System.Windows.Forms.TextBox txtRegex;
		private System.Windows.Forms.Label lblLine1;
		private System.Windows.Forms.Label lblValidate;
		private System.Windows.Forms.Label lblCompareValue;
		private System.Windows.Forms.Button btnCompareValue;
		private System.Windows.Forms.TextBox txtValue;
		private System.Windows.Forms.RadioButton rdoSingleExactMatch;
		private System.Windows.Forms.Label lblLine2;
		private System.Windows.Forms.Label lblRegulaExpression;
		private System.Windows.Forms.Label lblValueToMatch;
		private System.Windows.Forms.RadioButton rdoMultipleMatch;
		private System.Windows.Forms.Label lblMatchesFound;
		private System.Windows.Forms.TextBox txtMatchesFound;

		//-------- Message Constants -----------------
		private const string VALID_REGEX_MESSAGE = "Valid Regular Expression";
		private const string INVALID_REGEX_MESSAGE = "Not a Valid Regular Expression";
		private const string NO_MATCHES_FOUND_MESSAGE = "--- No Matches ----";
		//--------------------------------------------


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmRegexValidator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnValidateRegex = new System.Windows.Forms.Button();
			this.txtRegex = new System.Windows.Forms.TextBox();
			this.lblLine1 = new System.Windows.Forms.Label();
			this.lblValidate = new System.Windows.Forms.Label();
			this.lblCompareValue = new System.Windows.Forms.Label();
			this.lblLine2 = new System.Windows.Forms.Label();
			this.btnCompareValue = new System.Windows.Forms.Button();
			this.txtValue = new System.Windows.Forms.TextBox();
			this.lblRegulaExpression = new System.Windows.Forms.Label();
			this.lblValueToMatch = new System.Windows.Forms.Label();
			this.rdoSingleExactMatch = new System.Windows.Forms.RadioButton();
			this.rdoMultipleMatch = new System.Windows.Forms.RadioButton();
			this.lblMatchesFound = new System.Windows.Forms.Label();
			this.txtMatchesFound = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btnValidateRegex
			// 
			this.btnValidateRegex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnValidateRegex.Location = new System.Drawing.Point(456, 88);
			this.btnValidateRegex.Name = "btnValidateRegex";
			this.btnValidateRegex.Size = new System.Drawing.Size(144, 23);
			this.btnValidateRegex.TabIndex = 1;
			this.btnValidateRegex.Text = "Validate Regex";
			this.btnValidateRegex.Click += new System.EventHandler(this.btnValidateRegex_Click);
			// 
			// txtRegex
			// 
			this.txtRegex.AutoSize = false;
			this.txtRegex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtRegex.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtRegex.Location = new System.Drawing.Point(56, 56);
			this.txtRegex.Name = "txtRegex";
			this.txtRegex.Size = new System.Drawing.Size(544, 20);
			this.txtRegex.TabIndex = 0;
			this.txtRegex.Text = "";
			// 
			// lblLine1
			// 
			this.lblLine1.BackColor = System.Drawing.SystemColors.Control;
			this.lblLine1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblLine1.Font = new System.Drawing.Font("Microsoft Sans Serif", 1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblLine1.Location = new System.Drawing.Point(72, 16);
			this.lblLine1.Name = "lblLine1";
			this.lblLine1.Size = new System.Drawing.Size(544, 3);
			this.lblLine1.TabIndex = 4;
			// 
			// lblValidate
			// 
			this.lblValidate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblValidate.Location = new System.Drawing.Point(8, 8);
			this.lblValidate.Name = "lblValidate";
			this.lblValidate.Size = new System.Drawing.Size(56, 16);
			this.lblValidate.TabIndex = 5;
			this.lblValidate.Text = "Validate";
			// 
			// lblCompareValue
			// 
			this.lblCompareValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblCompareValue.Location = new System.Drawing.Point(8, 128);
			this.lblCompareValue.Name = "lblCompareValue";
			this.lblCompareValue.Size = new System.Drawing.Size(96, 16);
			this.lblCompareValue.TabIndex = 7;
			this.lblCompareValue.Text = "Compare Value";
			// 
			// lblLine2
			// 
			this.lblLine2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblLine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblLine2.Location = new System.Drawing.Point(80, 136);
			this.lblLine2.Name = "lblLine2";
			this.lblLine2.Size = new System.Drawing.Size(536, 3);
			this.lblLine2.TabIndex = 6;
			// 
			// btnCompareValue
			// 
			this.btnCompareValue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCompareValue.Location = new System.Drawing.Point(456, 256);
			this.btnCompareValue.Name = "btnCompareValue";
			this.btnCompareValue.Size = new System.Drawing.Size(144, 23);
			this.btnCompareValue.TabIndex = 5;
			this.btnCompareValue.Text = "Match with above Regex";
			this.btnCompareValue.Click += new System.EventHandler(this.btnCompareValue_Click);
			// 
			// txtValue
			// 
			this.txtValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtValue.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtValue.Location = new System.Drawing.Point(56, 184);
			this.txtValue.Multiline = true;
			this.txtValue.Name = "txtValue";
			this.txtValue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtValue.Size = new System.Drawing.Size(544, 64);
			this.txtValue.TabIndex = 2;
			this.txtValue.Tag = "";
			this.txtValue.Text = "";
			// 
			// lblRegulaExpression
			// 
			this.lblRegulaExpression.AutoSize = true;
			this.lblRegulaExpression.Location = new System.Drawing.Point(56, 40);
			this.lblRegulaExpression.Name = "lblRegulaExpression";
			this.lblRegulaExpression.Size = new System.Drawing.Size(106, 13);
			this.lblRegulaExpression.TabIndex = 10;
			this.lblRegulaExpression.Text = "Regular Expression:";
			// 
			// lblValueToMatch
			// 
			this.lblValueToMatch.AutoSize = true;
			this.lblValueToMatch.Location = new System.Drawing.Point(56, 168);
			this.lblValueToMatch.Name = "lblValueToMatch";
			this.lblValueToMatch.Size = new System.Drawing.Size(83, 13);
			this.lblValueToMatch.TabIndex = 11;
			this.lblValueToMatch.Text = "Value to Match:";
			// 
			// rdoSingleExactMatch
			// 
			this.rdoSingleExactMatch.Location = new System.Drawing.Point(56, 256);
			this.rdoSingleExactMatch.Name = "rdoSingleExactMatch";
			this.rdoSingleExactMatch.Size = new System.Drawing.Size(144, 24);
			this.rdoSingleExactMatch.TabIndex = 3;
			this.rdoSingleExactMatch.Text = "Single and  Exact Match";

			// 
			// rdoMultipleMatch
			// 
			this.rdoMultipleMatch.Checked = true;
			this.rdoMultipleMatch.Location = new System.Drawing.Point(216, 256);
			this.rdoMultipleMatch.Name = "rdoMultipleMatch";
			this.rdoMultipleMatch.Size = new System.Drawing.Size(168, 24);
			this.rdoMultipleMatch.TabIndex = 4;
			this.rdoMultipleMatch.TabStop = true;
			this.rdoMultipleMatch.Text = "Single or Multiple  Matches";

			// 
			// lblMatchesFound
			// 
			this.lblMatchesFound.AutoSize = true;
			this.lblMatchesFound.Location = new System.Drawing.Point(56, 296);
			this.lblMatchesFound.Name = "lblMatchesFound";
			this.lblMatchesFound.Size = new System.Drawing.Size(85, 13);
			this.lblMatchesFound.TabIndex = 15;
			this.lblMatchesFound.Text = "Matches Found:";
			// 
			// txtMatchesFound
			// 
			this.txtMatchesFound.BackColor = System.Drawing.Color.OldLace;
			this.txtMatchesFound.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMatchesFound.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtMatchesFound.Location = new System.Drawing.Point(56, 312);
			this.txtMatchesFound.Multiline = true;
			this.txtMatchesFound.Name = "txtMatchesFound";
			this.txtMatchesFound.ReadOnly = true;
			this.txtMatchesFound.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtMatchesFound.Size = new System.Drawing.Size(544, 104);
			this.txtMatchesFound.TabIndex = 14;
			this.txtMatchesFound.Tag = "";
			this.txtMatchesFound.Text = "";
			// 
			// frmRegexValidator
			// 
			this.AcceptButton = this.btnValidateRegex;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(634, 439);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblMatchesFound,
																		  this.txtMatchesFound,
																		  this.rdoMultipleMatch,
																		  this.rdoSingleExactMatch,
																		  this.lblValueToMatch,
																		  this.lblRegulaExpression,
																		  this.btnCompareValue,
																		  this.txtValue,
																		  this.lblCompareValue,
																		  this.lblLine2,
																		  this.lblValidate,
																		  this.lblLine1,
																		  this.btnValidateRegex,
																		  this.txtRegex});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmRegexValidator";
			this.Text = "Regular Expression Validator";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmRegexValidator());
		}

		
		private void btnValidateRegex_Click(object sender, System.EventArgs e)
		{
		
			
			if (IsValidRegex(txtRegex.Text))
			{

				MessageBox.Show( VALID_REGEX_MESSAGE );

			}
			else
			{

				MessageBox.Show( INVALID_REGEX_MESSAGE );
				txtRegex.SelectAll();
				txtRegex.Focus();

			}
		
		}

		private void btnCompareValue_Click(object sender, System.EventArgs e)
		{

			string foundMatches = "";

			txtMatchesFound.Text = "";
			
			if (IsValidRegex(txtRegex.Text))
			{
				if( IsMatchFound( txtValue.Text, txtRegex.Text, rdoSingleExactMatch.Checked, ref foundMatches))
				{

					txtMatchesFound.Text = foundMatches ;

				}
				else
				{
					txtMatchesFound.Text = NO_MATCHES_FOUND_MESSAGE ;
				}

			}
			else
			{

				MessageBox.Show( INVALID_REGEX_MESSAGE );
				txtRegex.SelectAll();
				txtRegex.Focus();

			}
		
		}
	
				
		//---- Utility Methods
		private bool IsValidRegex( string regexString )
		{
					
			try
			{   
				
				Regex  regex = new Regex( regexString ) ;
					
				//valid expression
				return true ;       
			 	
			}    
				//else
			catch( ArgumentException  )
			{
				
				//not valid expression
				return false ;	

			}
							
		}

		
		private bool IsMatchFound(string valueToMatch,string regexValue,
								bool isSingleExactMatch,ref string foundMatches)
		{
				//perform pattern check
				MatchCollection matchCollection = Regex.Matches(valueToMatch,regexValue);

				//if pattern matches
				if( matchCollection.Count != 0 )
				{

					//Collect all the matches found
					foundMatches = "";
					foreach( Match match in matchCollection )
					{
						foundMatches += match.Value + Environment.NewLine;
					}

					
					if (isSingleExactMatch)
					{
						if ( valueToMatch.Equals(matchCollection[0].Value))
						{

							//exact match
							return true ;

						}
						else
						{
						
							return false ;

						}
					}
					
					return true;

				}
				else
				{
					
					//pattern mismatch
					return false ;

				}
				
			
		}


	}
}
