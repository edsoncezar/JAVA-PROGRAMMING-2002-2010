﻿namespace CodeDocumenter
{
	partial class CodeDocumenter
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CodeDocumenter));
			this.SelectXmlFile = new System.Windows.Forms.Label();
			this.SourceLabel = new System.Windows.Forms.Label();
			this.TransformationLabel = new System.Windows.Forms.Label();
			this.SourcePreview = new System.Windows.Forms.WebBrowser();
			this.TransformationPreview = new System.Windows.Forms.WebBrowser();
			this.SourceFileLabel = new System.Windows.Forms.Label();
			this.TransformationFileLabel = new System.Windows.Forms.Label();
			this.SourceFile = new System.Windows.Forms.TextBox();
			this.SourceFilePicker = new System.Windows.Forms.Button();
			this.TransformationFile = new System.Windows.Forms.TextBox();
			this.TransformationFilePicker = new System.Windows.Forms.Button();
			this.InfoLabel = new System.Windows.Forms.Label();
			this.CloseButton = new System.Windows.Forms.Button();
			this.TransformButton = new System.Windows.Forms.Button();
			this.OutputFile = new System.Windows.Forms.TextBox();
			this.OutputFileLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
// 
// SelectXmlFile
// 
			resources.ApplyResources(this.SelectXmlFile, "SelectXmlFile");
			this.SelectXmlFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.SelectXmlFile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.SelectXmlFile.MaximumSize = new System.Drawing.Size(700, 60);
			this.SelectXmlFile.MinimumSize = new System.Drawing.Size(700, 60);
			this.SelectXmlFile.Name = "SelectXmlFile";
// 
// SourceLabel
// 
			resources.ApplyResources(this.SourceLabel, "SourceLabel");
			this.SourceLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.SourceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.SourceLabel.MaximumSize = new System.Drawing.Size(700, 200);
			this.SourceLabel.MinimumSize = new System.Drawing.Size(700, 200);
			this.SourceLabel.Name = "SourceLabel";
// 
// TransformationLabel
// 
			resources.ApplyResources(this.TransformationLabel, "TransformationLabel");
			this.TransformationLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.TransformationLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.TransformationLabel.MaximumSize = new System.Drawing.Size(700, 222);
			this.TransformationLabel.MinimumSize = new System.Drawing.Size(700, 222);
			this.TransformationLabel.Name = "TransformationLabel";
// 
// SourcePreview
// 
			this.SourcePreview.AllowWebBrowserDrop = false;
			this.SourcePreview.IsWebBrowserContextMenuEnabled = false;
			resources.ApplyResources(this.SourcePreview, "SourcePreview");
			this.SourcePreview.Name = "SourcePreview";
// 
// TransformationPreview
// 
			this.TransformationPreview.AllowWebBrowserDrop = false;
			this.TransformationPreview.IsWebBrowserContextMenuEnabled = false;
			resources.ApplyResources(this.TransformationPreview, "TransformationPreview");
			this.TransformationPreview.Name = "TransformationPreview";
// 
// SourceFileLabel
// 
			resources.ApplyResources(this.SourceFileLabel, "SourceFileLabel");
			this.SourceFileLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.SourceFileLabel.Name = "SourceFileLabel";
// 
// TransformationFileLabel
// 
			resources.ApplyResources(this.TransformationFileLabel, "TransformationFileLabel");
			this.TransformationFileLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.TransformationFileLabel.Name = "TransformationFileLabel";
// 
// SourceFile
// 
			resources.ApplyResources(this.SourceFile, "SourceFile");
			this.SourceFile.Name = "SourceFile";
			this.SourceFile.TextChanged += new System.EventHandler(this.SourceFile_TextChanged);
// 
// SourceFilePicker
// 
			resources.ApplyResources(this.SourceFilePicker, "SourceFilePicker");
			this.SourceFilePicker.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
			this.SourceFilePicker.Name = "SourceFilePicker";
			this.SourceFilePicker.Click += new System.EventHandler(this.SourceFilePicker_Click);
// 
// TransformationFile
// 
			resources.ApplyResources(this.TransformationFile, "TransformationFile");
			this.TransformationFile.Name = "TransformationFile";
// 
// TransformationFilePicker
// 
			resources.ApplyResources(this.TransformationFilePicker, "TransformationFilePicker");
			this.TransformationFilePicker.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
			this.TransformationFilePicker.Name = "TransformationFilePicker";
			this.TransformationFilePicker.Click += new System.EventHandler(this.TransformationFilePicker_Click);
// 
// InfoLabel
// 
			resources.ApplyResources(this.InfoLabel, "InfoLabel");
			this.InfoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.InfoLabel.MaximumSize = new System.Drawing.Size(293, 50);
			this.InfoLabel.MinimumSize = new System.Drawing.Size(293, 50);
			this.InfoLabel.Name = "InfoLabel";
// 
// CloseButton
// 
			this.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			resources.ApplyResources(this.CloseButton, "CloseButton");
			this.CloseButton.Name = "CloseButton";
			this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
// 
// TransformButton
// 
			resources.ApplyResources(this.TransformButton, "TransformButton");
			this.TransformButton.Name = "TransformButton";
			this.TransformButton.Click += new System.EventHandler(this.TransformButton_Click);
// 
// OutputFile
// 
			resources.ApplyResources(this.OutputFile, "OutputFile");
			this.OutputFile.Margin = new System.Windows.Forms.Padding(2);
			this.OutputFile.Name = "OutputFile";
			this.OutputFile.ReadOnly = true;
// 
// OutputFileLabel
// 
			resources.ApplyResources(this.OutputFileLabel, "OutputFileLabel");
			this.OutputFileLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.OutputFileLabel.Name = "OutputFileLabel";
// 
// CodeDocumenter
// 
			resources.ApplyResources(this, "$this");
			this.CancelButton = this.CloseButton;
			this.Controls.Add(this.OutputFileLabel);
			this.Controls.Add(this.OutputFile);
			this.Controls.Add(this.TransformButton);
			this.Controls.Add(this.CloseButton);
			this.Controls.Add(this.InfoLabel);
			this.Controls.Add(this.TransformationFilePicker);
			this.Controls.Add(this.TransformationFile);
			this.Controls.Add(this.SourceFilePicker);
			this.Controls.Add(this.SourceFile);
			this.Controls.Add(this.TransformationFileLabel);
			this.Controls.Add(this.SourceFileLabel);
			this.Controls.Add(this.TransformationPreview);
			this.Controls.Add(this.SourcePreview);
			this.Controls.Add(this.TransformationLabel);
			this.Controls.Add(this.SourceLabel);
			this.Controls.Add(this.SelectXmlFile);
			this.Name = "CodeDocumenter";
			this.Load += new System.EventHandler(this.CodeDocumenter_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label SelectXmlFile;
		private System.Windows.Forms.Label SourceLabel;
		private System.Windows.Forms.Label TransformationLabel;
		private System.Windows.Forms.WebBrowser SourcePreview;
		private System.Windows.Forms.WebBrowser TransformationPreview;
		private System.Windows.Forms.Label SourceFileLabel;
		private System.Windows.Forms.Label TransformationFileLabel;
		private System.Windows.Forms.TextBox SourceFile;
		private System.Windows.Forms.Button SourceFilePicker;
		private System.Windows.Forms.TextBox TransformationFile;
		private System.Windows.Forms.Button TransformationFilePicker;
		private System.Windows.Forms.Label InfoLabel;
		private System.Windows.Forms.Button CloseButton;
		private System.Windows.Forms.Button TransformButton;
		private System.Windows.Forms.TextBox OutputFile;
		private System.Windows.Forms.Label OutputFileLabel;
	}
}

