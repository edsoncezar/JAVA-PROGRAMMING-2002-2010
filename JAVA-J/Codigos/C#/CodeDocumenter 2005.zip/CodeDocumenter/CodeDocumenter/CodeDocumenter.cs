﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Configuration;
using System.Xml;
using System.Xml.Query;
using System.IO;
using System.Globalization;

#endregion

namespace CodeDocumenter
{
	/// <summary>
	/// the form which allows to choose the XML and XSLT document and then perform the 
	/// transformation to create the help page
	/// </summary>
	partial class CodeDocumenter : Form
	{
		const string DefaultExt = ".xml";
		const string OpenFileFilter = "XML files (*.xml)|*.xml|XSLT files (*.xslt)|*.xslt|All files (*.*)|*.*";
		const string ConfigTransformationFile = "TransformationFile";
		const string ConfigSourceFile = "SourceFile";
		const string OutputExtension = ".html";
		const string CssFileName = "HelpStyleSheet.css";

		/// <summary>
		/// initialize the form
		/// </summary>
		public CodeDocumenter()
		{
			InitializeComponent();
		}

		/// <summary>
		/// user can choose through the open file dialog a existing file
		/// </summary>
		/// <returns>returns the selected file name or null if the user aborts</returns>
		private string ChooseFile()
		{
			// check that the extension, file and path exists
			OpenFileDialog OpenFile = new OpenFileDialog();
			OpenFile.AddExtension = true;
			OpenFile.CheckFileExists = true;
			OpenFile.CheckPathExists = true;
			OpenFile.DefaultExt = DefaultExt;

			// sets the title, the intial folder and the file filter to choose from
			OpenFile.Multiselect = false;
			OpenFile.Title = this.Text;
			OpenFile.InitialDirectory = Environment.CurrentDirectory;
			OpenFile.Filter = OpenFileFilter;

			// show the open file dialog and return the selected file
			if (OpenFile.ShowDialog() == DialogResult.OK)
				return OpenFile.FileName;
			else
				return null;
		}

		/// <summary>
		/// user can choose the XML source file to use
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void SourceFilePicker_Click(object sender, EventArgs e)
		{
			// the user selects a file
			string FileName = ChooseFile();

			// now set the filename except the user aborted which returns null
			if (FileName != null)
				SourceFile.Text = FileName;
		}

		/// <summary>
		/// user can choose the XSLT source file to use
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void TransformationFilePicker_Click(object sender, EventArgs e)
		{
			// the user selects a file
			string FileName = ChooseFile();

			// now set the filename except the user aborted which returns null
			if (FileName != null)
				TransformationFile.Text = FileName;
		}

		/// <summary>
		/// set the XML source file so we can show it in the browser
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void SourceFile_TextChanged(object sender, EventArgs e)
		{
			SourcePreview.Url = SourceFile.Text;
		}

		/// <summary>
		/// perform the transformation, save the output to a file and show it
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void TransformButton_Click(object sender, EventArgs e)
		{
			try
			{
				// load the XML document
				XmlDocument SourceDocument = new XmlDocument();
				SourceDocument.Load(SourceFile.Text);

				// the output file for the transformation
				OutputFile.Text = Path.GetDirectoryName(SourceFile.Text) + "\\" + Path.GetFileNameWithoutExtension(SourceFile.Text) + OutputExtension;

				// load the XSLT document and perform the transformation
				XsltCommand Transformation = new XsltCommand();
				Transformation.Compile(TransformationFile.Text);
				Transformation.Execute(SourceFile.Text, OutputFile.Text);

				// location where the CSS file is located and where to copy to
				string CssSourceFile = Path.GetDirectoryName(TransformationFile.Text) + "\\" + CssFileName;
				string CssDestinationFile = Path.GetDirectoryName(OutputFile.Text) + "\\" + CssFileName;

				// copy the Css stylesheet file to where we create the Html output; otherwise the
				// stylesheet will be missing and the output not properly formatted
				if (String.Compare(CssSourceFile, CssDestinationFile, true, CultureInfo.InvariantCulture) != 0)
					File.Copy(CssSourceFile, CssDestinationFile, true);

				// now show the output from the transformation
				TransformationPreview.Url = OutputFile.Text;

				// selects the control as the active one
				TransformationPreview.Select();
			}
			
			// show any error from the transformation
			catch (Exception ex)
			{
				MessageBox.Show(this, ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		/// <summary>
		/// close the form
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void CloseButton_Click(object sender, EventArgs e)
		{
			Close();
		}

		/// <summary>
		/// prefills the XML and XSLT file with the values set in the .config file
		/// </summary>
		/// <param name="sender">event sender</param>
		/// <param name="e">event arguments</param>
		private void CodeDocumenter_Load(object sender, EventArgs e)
		{
			SourceFile.Text = ConfigurationSettings.AppSettings[ConfigSourceFile];
			TransformationFile.Text = ConfigurationSettings.AppSettings[ConfigTransformationFile];
		}
	}
}
