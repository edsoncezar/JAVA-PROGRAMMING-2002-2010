using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace RemoteTemperatureClient
{
	/// <summary>
	/// Summary description for Thermometer.
	/// </summary>
	public class Thermometer : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private Font TheFont = new Font("Courier New", 12);
		private Font AlarmFont = new Font("Impact", 24);
		private static	double TheTemperature = 30.0;

		public Thermometer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}

		private void DrawBase(Graphics g)
		{
			g.FillRectangle(Brushes.White, this.ClientRectangle);
		}

		private int ConvertTemperatureToHeight(int temperature)
		{
			return ((ClientRectangle.Height - 52) * temperature)/ 212;
		}


		private void DrawTube(Graphics g, int temperature)
		{
			int midPoint = ClientRectangle.Left + ClientRectangle.Width/2;

			Pen aPen = new Pen(Brushes.Black, 2);

			// draw level
			g.FillRectangle(Brushes.Red, midPoint - 10, ClientRectangle.Height - ConvertTemperatureToHeight(temperature) - 30, 20, ConvertTemperatureToHeight(temperature) + 30);

			// fill Arc at bottom
			g.FillPie(Brushes.Red, midPoint - 18, ClientRectangle.Height - 38, 38, 38, -55, 280);

			// draw two parallel vertical lines
			g.DrawLine(aPen, midPoint-10, 20, midPoint-10, ClientRectangle.Height - 30);
			g.DrawLine(aPen, midPoint+10, 20, midPoint+10, ClientRectangle.Height - 32);
			
			// calculate the height of the thermometer
			int height = ClientRectangle.Height - 52;
			float tickHeight = (float)height/212.0f;

			// connect them with arcs
			g.DrawArc(aPen, midPoint - 10, 12, 20, 15, 0, -180);
			g.DrawArc(aPen, midPoint - 18, ClientRectangle.Height - 38, 38, 38, -55, 280);

			// draw tics and values for Farehnheit
			for (int i = 0; i < 212; i+=5)
			{
				g.DrawLine(Pens.Black, midPoint+10, ClientRectangle.Height - (32 + i*tickHeight), midPoint+20, ClientRectangle.Height - (32 + i*tickHeight));
				if (i % 25 == 0)
				{
					g.DrawLine(Pens.Black, midPoint+10, ClientRectangle.Height - (32 + i*tickHeight), midPoint+30, ClientRectangle.Height - (32 + i*tickHeight));
					g.DrawString(i.ToString(), TheFont, Brushes.Navy, midPoint + 20, ClientRectangle.Height - (32 + i*tickHeight), new StringFormat());
				}
			}

			// draw tics and values for Centigrade
			tickHeight = (float)height/118.0f;

			for (int i = 0; i <= 118; i++)
			{
				if ( (i-18) % 5 == 0)
				{
					g.DrawLine(Pens.Black, midPoint-10, 
						ClientRectangle.Height - (32 + ((float)i)*tickHeight), midPoint-20, 
						ClientRectangle.Height - (32 + ((float)i)*tickHeight));
				}


				if ((i-18) % 25 == 0)
				{
					g.DrawLine(Pens.Black, midPoint-10, ClientRectangle.Height - (32 + ((float)i)*tickHeight), midPoint-30, ClientRectangle.Height - (32 + ((float)i)*tickHeight));
					g.DrawString((i-18).ToString(), TheFont, Brushes.Navy, midPoint - 50, ClientRectangle.Height - (32 + ((float)i)*tickHeight), new StringFormat());
				}
			}


		}

	private void DrawAlarm(Graphics g)
	{
		g.DrawString("Alarm", AlarmFont, Brushes.Red, ClientRectangle.Left + 20, ClientRectangle.Top + 5);
	}


		private void DrawThermometer(Graphics g)
		{
			DrawBase(g);
			DrawTube(g, 0);
			DrawTube(g, (int)TheTemperature);
		}

		public double Temperature
		{
			set
			{
				TheTemperature = value;
				Invalidate();
			}

			get
			{
				return TheTemperature;
			}
		}

		bool AlarmSet = false;
		public bool Alarm
		{
			get
			{
				return AlarmSet;
			}

			set
			{
				AlarmSet = value;
				Invalidate();
				this.Update();
			}

		}



		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Thermometer
			// 
			this.Name = "Thermometer";
			this.Size = new System.Drawing.Size(200, 224);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Thermometer_Paint);

		}
		#endregion

		private void Thermometer_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			// draw the thermometer
			Graphics g = e.Graphics;
			DrawThermometer(g);
			if (AlarmSet)
			{
				DrawAlarm(g);
			}
		}
	}
}
