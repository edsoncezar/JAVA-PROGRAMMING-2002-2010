using System;
using System.Timers;
using AWCGP3DLL;
using System.Threading;

namespace RemoteTemperatureObject
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class RemoteObject : MarshalByRefObject
	{
		System.Timers.Timer ThePauseTimer = new System.Timers.Timer();
		public static AWCGP3DLL.GP3DLLClass gp3 = new AWCGP3DLL.GP3DLLClass ();
		public RemoteObject()
		{
			gp3.CommPort = 1;
			if (gp3.portopen == false)
				gp3.portopen = true;

			// take initial reading on the a/d
			long tmp1 = gp3.a2d(0);

			//
			// TODO: Add constructor logic here
			//
			try
			{
				ThePauseTimer.Start();
				SetupTimer();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message.ToString() +  " " + ex.StackTrace.ToString());
			}
		}

		public void SetupTimer()
		{
			// set up parameters for measuring pause time
			ThePauseTimer.Interval = 100; // 100 ms for the pause timer
			ThePauseTimer.Enabled = true;
			ThePauseTimer.Elapsed+=new ElapsedEventHandler(this.OnPauseEvent);
		}

		double[] TempMap = new double[]{-50, 45, -40, -35, -30, -25, -20,-15, -10, -5, 0, 5,
										 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65,
										 70, 75, 80, 85, 90, 95, 100, 105, 110};

		double[] ResistorMap = new double[]{320.2, 247.5, 188.4, 144.0, 111.3, 86.39, 67.74, 53.39, 42.45, 33.89, 27.28, 22.05, 17.96, 14.68, 12.09, 10.00, 8.313, 6.941, 5.826, 4.912, 4.161, 3.537, 3.021, 2.589, 2.229, 1.924, 1.669, 1.451, 1.366, 1.108, .9375, .8575, .7579};


		double FindClosestTemperature(double resistance)
		{
			resistance = resistance/ 1000; // table is in kiloohms
			for (int i = 0; i < ResistorMap.Length; i++)
			{
				if (ResistorMap[i] < resistance) // we found it
				{
				  // do a little interpolation
					double closestConductanceLow = 1.0/ResistorMap[i-1]; // inverse relationship
					double closestConductanceHigh = 1.0/ResistorMap[i];  // inverse relationship
					double closestTemperatureLow = TempMap[i-1];
					double closestTemperatureHigh = TempMap[i];

					double  slope = (closestConductanceHigh - closestConductanceLow)/(closestTemperatureHigh - closestTemperatureLow);
					double  interpolatedTemperature = 1/(slope * resistance);
					
					return interpolatedTemperature;
				}
			}

			return 30;
		}

		public void SoundAlarm()
		{
			Console.WriteLine("*** Sounding Alarm ***");
			// set the value of the loop to zero to force it go
			// through the alarm loop at least once
			int val = 0;
			// read the initial value of the pushbutton
			int x = gp3.inp(3);
			x = gp3.inp(3);
			Pause(5);
			while (val == 0)
			{
				// sound a chirp in the alarm for 1/2 second at 6 KHz
				gp3.freq(5, 6000, 500);
				Pause(10);
				// add the value of the pushbutton input to val
				//  (high == 1,  low == 0)
				val += gp3.inp(3);
				// terminate the loop if the pushbutton is pressed
				if (val > 0)
					break;

				// sound a chirp in the alarm for 1/2 second at 6 KHz
				gp3.freq(5, 6000, 500);
				Pause(10);
				val += gp3.inp(3);
				// terminate the loop if the pushbutton is pressed
				if (val > 0)
					break;
				// sound a chirp in the alarm for 1/2 second at 6 KHz
				gp3.freq(5, 6000, 500);
				Pause(10);
				val += gp3.inp(3);
				// terminate the loop if the pushbutton is pressed
				if (val > 0)
					break;
			}

			Console.WriteLine("-----  Alarm Terminated -----");

		}


		public double GetCurrentTemperature()
		{

			// send voltage across the thermistor divider circuit
			gp3.high(1);

			// get a/d voltage reading across divider
			long tmp1 = gp3.a2d(0);


			// pause 200 milliseconds to debounce
			Pause(2);



			// convert the a/d reading from a count to a voltage
			float voltage = ((float)tmp1 * 5.0f/ 1024.0f);


			// calculate thermistor resistance from voltage across the thermistor
			// therm /(1k + therm) * 5 V = voltage
			// therm = (voltage * 1000 ohms)/(5 volts - voltage);
			float therm = (voltage * 1000) / (5 - voltage);

			// convert to a celcius temperature using the chart
			double temperature = FindClosestTemperature(therm);

			// convert to fahrenheit
			temperature = (temperature * 9/5) + 32;
		

			Console.WriteLine("temperature = {0}, reading = {1}", temperature, voltage);

			// stop current flow across the divider to save the battery
			gp3.low(1);


			return temperature;

		}

		// Specify what you want to happen when the Elapsed event is raised.
		private void OnTimedEvent(object source, ElapsedEventArgs e)
		{
		// Measure temperature by measuring RC time
		// charge capacitor (try again in future)
			/*
			gp3.high(1);
			Pause (2); // first wait 200 ms
//			gp3.inp(0); // set the pin to an input
			int rctime = gp3.rctime(1, 1);
			Console.WriteLine("{0}", rctime);
			*/

		}

		void Pause(int x)
		{
			// Pause x * 100 ms
			long startCount = Count;
			long endCount = startCount + x;
			while (Count < endCount)
			{

			}
		}

		long Count = 0;
		// Specify what you want to happen when the Elapsed event is raised.
		private void OnPauseEvent(object source, ElapsedEventArgs e)
		{
			// This doesn't really do anything but count.
			Count++;
		}


  }
}
