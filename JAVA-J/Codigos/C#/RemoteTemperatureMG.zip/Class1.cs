using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;


namespace RemoteTemperatureServer
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//
			// TODO: Add code to start application here
			//
			//
			// TODO: Add code to start application here
			//
			TcpServerChannel channel =  new TcpServerChannel(1234);
			ChannelServices.RegisterChannel(channel);
			RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteTemperatureObject.RemoteObject), "RemoteTemperatureObject", WellKnownObjectMode.Singleton);
			Console.WriteLine("Press enter to terminate server...");
			Console.ReadLine();
		}
	}
}
