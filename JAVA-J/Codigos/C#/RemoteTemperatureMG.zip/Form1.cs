using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using RemoteTemperatureObject;
using System.Threading;


namespace RemoteTemperatureClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private RemoteTemperatureClient.Thermometer thermometer1;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Timer timer1;
		private Thread ClientThread = null;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			timer1.Start();
			ClientThread = new Thread(new ThreadStart(LinkToServer));
			ClientThread.Start();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		RemoteTemperatureObject.RemoteObject  _remoteTemperatureReader;
		public void LinkToServer()
		{
// ************ Use this code if you are not using a configuration file
//			TcpClientChannel channel = new TcpClientChannel();
//			ChannelServices.RegisterChannel (channel);
			RemotingConfiguration.Configure("remotetemperature.config");
//			RemotingConfiguration.RegisterWellKnownClientType (typeof(RemoteTemperatureObject.RemoteObject),  "tcp://localhost:1234/RemoteTemperatureObject");
//			_remoteTemperatureReader = new RemoteTemperatureObject.RemoteObject();
//			_remoteTemperatureReader = (RemoteTemperatureObject.RemoteObject)Activator.GetObject(typeof(RemoteTemperatureObject.RemoteObject), "tcp://localhost:1234/RemoteTemperatureObject");
		}

		private void RetrieveTemperature()
		{
			WellKnownClientTypeEntry[] entries = RemotingConfiguration.GetRegisteredWellKnownClientTypes();

			string url = entries[0].ObjectUrl;
			// url for remote client "tcp://localhost:1234/RemoteTemperatureObject" 
			_remoteTemperatureReader = (RemoteTemperatureObject.RemoteObject)Activator.GetObject(typeof(RemoteTemperatureObject.RemoteObject), url);

			try
			{
				double theTemperature = _remoteTemperatureReader.GetCurrentTemperature();
				this.thermometer1.Temperature = theTemperature;

				if (theTemperature < 32) // test alarm
				{
					thermometer1.Alarm = true;
					_remoteTemperatureReader.SoundAlarm();
				 timer1.Stop();
				}
			}
			catch (Exception ex)
			{
				timer1.Stop();
				MessageBox.Show(ex.Message.ToString() + "\n " + ex.StackTrace.ToString());
				Console.WriteLine(ex.Message.ToString() + "\n " + ex.StackTrace.ToString());
			}
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.thermometer1 = new RemoteTemperatureClient.Thermometer();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// thermometer1
			// 
			this.thermometer1.Location = new System.Drawing.Point(40, 16);
			this.thermometer1.Name = "thermometer1";
			this.thermometer1.Size = new System.Drawing.Size(200, 224);
			this.thermometer1.TabIndex = 0;
			this.thermometer1.Temperature = 30;
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 3000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(296, 277);
			this.Controls.Add(this.thermometer1);
			this.Name = "Form1";
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Text = "Remote Temperature Monitor";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			RetrieveTemperature();
		}
	}
}
