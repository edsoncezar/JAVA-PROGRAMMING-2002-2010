// This Code was created by Microgold Software Inc. for educational purposes
// Copyright Microgold Software Inc. Wednesday, July 16, 2003

using System;
using System.Drawing;

namespace MathEditor
{
	/// <summary>
	/// Summary description for CharCursor.
	/// </summary>
	public class CharCursor
	{
		public  PointF Position;
		public  bool IsWhite = false;
		public const int kCursorWidth = 4;
		public const int kCursorHeight = 15;
		public CharCursor(int x, int y)
		{
			Position.X = x;
			Position.Y = y;
		}

		public void Reset()
		{
		 Position.X = 10;
		 Position.Y = 22;
		}

		public void Draw(Graphics g)
		{
		  if (this.IsWhite)
			  g.DrawLine(Pens.White, Position.X + kCursorWidth/2, Position.Y, Position.X + kCursorWidth/2, Position.Y + kCursorHeight);
		  else
			  g.DrawLine(Pens.Black, Position.X + kCursorWidth/2, Position.Y, Position.X + kCursorWidth/2, Position.Y + kCursorHeight);
		}

		public Rectangle GetCursorRect()
		{
			Rectangle r = new Rectangle((int)Position.X, (int)Position.Y, kCursorWidth, kCursorHeight);
			return r;
		}
	}
}
