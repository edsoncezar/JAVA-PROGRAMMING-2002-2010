// This Code was created by Microgold Software Inc. for educational purposes
// Copyright Microgold Software Inc. Wednesday, July 16, 2003

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace MathEditor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;
		private Graphics gMeasure = null;
		Font CurrentFont = new Font("Times New Roman", 15);
		private System.Windows.Forms.Timer CursorTimer;
		char CurrentCharacter = ' ';
		Symbol LastSymbol;

		bool DivideOn = false;
		bool DenominatorMode = false;

		int CurrentDivideSymbolIndex = 0;
		bool SquareRootOn = false;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem OpenMenu;
		private System.Windows.Forms.MenuItem SaveMenu;
		private System.Windows.Forms.MenuItem PrintMenu;
		private System.Windows.Forms.MenuItem PrintPreviewMenu;
		private System.Windows.Forms.MenuItem ExitMenu;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintDialog printDialog1;
		private System.Windows.Forms.MenuItem NewMenu;

		CharCursor TheCursor = new CharCursor(0, 20);
		private System.Windows.Forms.MenuItem SaveImageMenu;
		private System.Windows.Forms.SaveFileDialog saveFileDialog2;
		float LevelValue = 20;
		bool TimerEvent = false;

		public Form1()
		{
			gMeasure = this.CreateGraphics();
			LastSymbol = new Symbol(new PointF(20, 0), 'x', this.Font, SymbolDepth.Normal);

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			SetStatus("Ready", "");

			// start the Timer Cursor
			CursorTimer.Start();

			// set up double-buffering
			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);

		}

		void SetStatus(string val)
		{
			statusBar1.Panels[0].Text = val;
			statusBar1.Panels[1].Text = "";
			this.Focus();
		}

		void SetStatus(string val, string description)
		{
			statusBar1.Panels[0].Text = val;
			statusBar1.Panels[1].Text = description;
			this.Focus();
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.CursorTimer = new System.Windows.Forms.Timer(this.components);
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.OpenMenu = new System.Windows.Forms.MenuItem();
			this.SaveMenu = new System.Windows.Forms.MenuItem();
			this.PrintMenu = new System.Windows.Forms.MenuItem();
			this.PrintPreviewMenu = new System.Windows.Forms.MenuItem();
			this.ExitMenu = new System.Windows.Forms.MenuItem();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.printDialog1 = new System.Windows.Forms.PrintDialog();
			this.SaveImageMenu = new System.Windows.Forms.MenuItem();
			this.NewMenu = new System.Windows.Forms.MenuItem();
			this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			this.SuspendLayout();
			// 
			// CursorTimer
			// 
			this.CursorTimer.Interval = 500;
			this.CursorTimer.Tick += new System.EventHandler(this.CursorTimer_Tick);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.NewMenu,
																					  this.OpenMenu,
																					  this.SaveMenu,
																					  this.SaveImageMenu,
																					  this.PrintMenu,
																					  this.PrintPreviewMenu,
																					  this.ExitMenu});
			this.menuItem1.Text = "File";
			// 
			// OpenMenu
			// 
			this.OpenMenu.Index = 1;
			this.OpenMenu.Text = "Open...";
			this.OpenMenu.Click += new System.EventHandler(this.OpenMenu_Click);
			// 
			// SaveMenu
			// 
			this.SaveMenu.Index = 2;
			this.SaveMenu.Text = "Save...";
			this.SaveMenu.Click += new System.EventHandler(this.SaveMenu_Click);
			// 
			// PrintMenu
			// 
			this.PrintMenu.Index = 4;
			this.PrintMenu.Text = "Print...";
			this.PrintMenu.Click += new System.EventHandler(this.PrintMenu_Click);
			// 
			// PrintPreviewMenu
			// 
			this.PrintPreviewMenu.Index = 5;
			this.PrintPreviewMenu.Text = "Print Preview...";
			this.PrintPreviewMenu.Click += new System.EventHandler(this.PrintPreviewMenu_Click);
			// 
			// ExitMenu
			// 
			this.ExitMenu.Index = 6;
			this.ExitMenu.Text = "Exit";
			this.ExitMenu.Click += new System.EventHandler(this.ExitMenu_Click);
			// 
			// statusBar1
			// 
			this.statusBar1.CausesValidation = false;
			this.statusBar1.Enabled = false;
			this.statusBar1.Location = new System.Drawing.Point(0, 275);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(488, 22);
			this.statusBar1.TabIndex = 0;
			this.statusBar1.Text = "statusBar1";
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.Text = "statusBarPanel1";
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Text = "statusBarPanel2";
			this.statusBarPanel2.Width = 400;
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.DefaultExt = "xml";
			this.saveFileDialog1.FileName = "MathScratch.xml";
			this.saveFileDialog1.Filter = "*.xml | *.* ||";
			this.saveFileDialog1.Title = "Save the Math Surface";
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.DefaultExt = "xml";
			this.openFileDialog1.Filter = "*.xml | *.* ||";
			this.openFileDialog1.Title = "Open an existing Math Surface";
			// 
			// printPreviewDialog1
			// 
			this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
			this.printPreviewDialog1.Document = this.printDocument1;
			this.printPreviewDialog1.Enabled = true;
			this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
			this.printPreviewDialog1.Location = new System.Drawing.Point(17, 54);
			this.printPreviewDialog1.MaximumSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.Name = "printPreviewDialog1";
			this.printPreviewDialog1.Opacity = 1;
			this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
			this.printPreviewDialog1.Visible = false;
			// 
			// printDocument1
			// 
			this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
			// 
			// printDialog1
			// 
			this.printDialog1.Document = this.printDocument1;
			// 
			// SaveImageMenu
			// 
			this.SaveImageMenu.Index = 3;
			this.SaveImageMenu.Text = "Save As Image...";
			this.SaveImageMenu.Click += new System.EventHandler(this.SaveImageMenu_Click);
			// 
			// NewMenu
			// 
			this.NewMenu.Index = 0;
			this.NewMenu.Text = "New";
			this.NewMenu.Click += new System.EventHandler(this.NewMenu_Click);
			// 
			// saveFileDialog2
			// 
			this.saveFileDialog2.FileName = "Formula.bmp";
			this.saveFileDialog2.Filter = "Bitmap Files | *.bmp||";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(488, 297);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.statusBar1});
			this.KeyPreview = true;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Math Symbol Editor";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		enum SymbolDepth  {Normal, Raised, Lowered};
		class Symbol
		{
			public Symbol(PointF pos, char c, Font f, SymbolDepth level)
			{
				_character = c;
				_position = pos;
				_font = f;
				_level = level;
			}
		  public Font _font;
		  public PointF _position;
		  public char  _character;
		  public SymbolDepth _level;
		  public bool _squareroot = false;
		}

		ArrayList Symbols = new ArrayList();

		private void DrawAll(Graphics g)
		{
			if (TimerEvent == false) // smart painting, only paint small area on timer event
			{
				// paint surface
				g.FillRectangle (Brushes.White, ClientRectangle);
			}
			else
				g.FillRectangle(Brushes.White, TheCursor.GetCursorRect());

				// paint all of the symbols
				foreach (Symbol s in Symbols)
				{
					g.DrawString(s._character.ToString(), s._font, Brushes.Black, s._position, new StringFormat());

					// if the symbol is under a square root sign, paint a line over it
					if (s._squareroot)
					{
						g.DrawLine(Pens.Black, s._position.X, s._position.Y - 5, s._position.X + 15, s._position.Y - 5);
					}
				}
//			}

			// Draw The Cursor
			TheCursor.Draw(g);
			TimerEvent = false;
		}


		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g = e.Graphics; // get the graphics object
			DrawAll(g);
		}



		Size LastCharSize = new Size(10,10);
		private void AdjustCursor(Symbol s)
		{
			SizeF charSize = gMeasure.MeasureString(s._character.ToString(), s._font);
			AdjustCharSize(ref charSize);
			MoveCursor(charSize);
			LastCharSize = charSize.ToSize();
		}

		/// <summary>
		/// Move Cursor to the last position
		/// </summary>
		private void MoveCursorToEnd()
		{
			Symbol lastSymbol = (Symbol)Symbols[Symbols.Count - 1];
			TheCursor.Position.X = lastSymbol._position.X;
		}

		private void MoveCursorBack(int index)
		{
			Symbol currentSymbol = (Symbol)Symbols[index];
			SizeF charSize = gMeasure.MeasureString(currentSymbol._character.ToString().Trim() , currentSymbol._font);
			AdjustCharSize(ref charSize);
			TheCursor.Position.X -= charSize.Width;
			if (TheCursor.Position.X < 0)
			{
				TheCursor.Position.X = 0;
			}
		}

		private void MoveCursorDown(int amount)
		{
			TheCursor.Position.Y += amount;

			if (TheCursor.Position.Y > ClientRectangle.Height - 11)
			{
				TheCursor.Position.Y = ClientRectangle.Height - 11;
			}
		}

		private void MoveCursorUp(int amount)
		{
			TheCursor.Position.Y -= amount;
			if (TheCursor.Position.Y < 20)
			{
				TheCursor.Position.Y = 20;
			}
		}

		private void MoveCursorRight(int amount)
		{
			TheCursor.Position.X += amount;
			if (TheCursor.Position.X > ClientRectangle.Width - 11)
			{
				TheCursor.Position.X = ClientRectangle.Width - 11;
			}
		}

		private void MoveCursorLeft(int amount)
		{
			TheCursor.Position.X -= amount;
			if (TheCursor.Position.X < 0)
			{
				TheCursor.Position.X = 0;
			}
		}



		private void MoveCursor(SizeF charSize)
		{
			TheCursor.Position.X += charSize.Width ;
			if (TheCursor.Position.X > ClientRectangle.Width - (int)charSize.Width)
			{
				TheCursor.Position.X = 0;
				TheCursor.Position.Y += charSize.Height;
			}
		}

		private void AdjustCharSize(ref SizeF charSize)
		{
			const int kCharAdjustment = 4;
			charSize.Width -= kCharAdjustment;
		}

		private void AdjustCursorToNextLine()
		{
			SizeF charSize = gMeasure.MeasureString(LastSymbol._character.ToString().Trim() , LastSymbol._font);
			AdjustCharSize(ref charSize);
			TheCursor.Position.X = 0;
			TheCursor.Position.Y += charSize.Height;
			LastCharSize = charSize.ToSize();
		}



		private void AdjustCursorBack()
		{
			if (Symbols.Count == 0)
			{
				TheCursor.Position.X = 0;
				TheCursor.Position.Y = 0;
				return; // precondition;
			}

			TheCursor.Position = LastSymbol._position;

			if (LastSymbol._level == SymbolDepth.Lowered)
			{
				TheCursor.Position.Y -= (float)LastSymbol._font.Height/(float)2;
			}

			if (LastSymbol._level == SymbolDepth.Raised)
			{
				TheCursor.Position.Y += (float)LastSymbol._font.Height/(float)3;
			}

		}


		private void Form1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			// use state machine
			if (e.KeyChar == 21)
				return;

			if (e.KeyChar == 21)
				return;

	
			if (ControlPressed)
			{
			}
			else if (e.KeyChar == '\r')
			{
				AdjustCursorToNextLine();
				Invalidate();
				return;
			}

			else
			{
				if (e.KeyChar == '\b')
				{
					if (Symbols.Count > 0)
					{
						if (Symbols.Count > 0)
							LastSymbol = (Symbol)Symbols[Symbols.Count - 1];
						AdjustCursorBack();
						Symbols.RemoveAt(Symbols.Count - 1);
						Invalidate();
					}
				}
				else if (e.KeyChar == ' ')
				{
					// just advance the cursor
					MoveCursor(new Size(11, 11));
					Invalidate();
				}
				else if (e.KeyChar == '\t')
				{
					// just advance the cursor
					MoveCursor(new Size(11, 11));
					MoveCursor(new Size(11, 11));
					Invalidate();
				}
				else if (e.KeyChar == '/') // for divide
				{
					MoveCursor(new Size(0,11));
					DivideOn = true;
					SquareRootOn = false;
					SetStatus("Divide On", "Press the Left Arrow Key to draw divisor line, Esc to quit");
					CurrentDivideSymbolIndex = Symbols.Count - 1;
					HandleNumeratorMode();
				}
				else
				{
					if (e.KeyChar >= 'a' && e.KeyChar <= 'z')
						CurrentFont = new Font("Times New Roman", 11/*, FontStyle.Italic */);
					else
						CurrentFont = new Font("Times New Roman", 11);

					if (e.KeyChar != 0x1b)
					{
						AddSymbol(new Symbol(TheCursor.Position, e.KeyChar, CurrentFont, SymbolDepth.Normal));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
					}
					Invalidate();
				}
			}
		}

		private void AddSymbol(Symbol s)
		{
			// for square root add extra symbol above character
			if (SquareRootOn && s._character != 0xd6 && s._level == SymbolDepth.Normal)
			{
				s._squareroot = true;
			}

			Symbols.Add(s);
		}

		private void CursorTimer_Tick(object sender, System.EventArgs e)
		{
		  // need to blink cursor every tick
		  TheCursor.IsWhite = !TheCursor.IsWhite;
		  TimerEvent = true; // used to only repaint cursor
		  Invalidate(TheCursor.GetCursorRect());
		}

		private bool ControlPressed = false;
		private bool AltPressed = false;
		private bool ShiftPressed = false;

		PointF AdjustForPreviousCharacter(PointF p, SymbolDepth sd)
		{
			if (Symbols.Count == 0) return p; // precondition

			Symbol lastSymbol = ((Symbol)Symbols[Symbols.Count-1]);
			if ( ( lastSymbol._level != SymbolDepth.Normal ) && (lastSymbol._level != sd))
			{
				p.X = p.X - LastCharSize.Width;
			}

			if ( ( lastSymbol._level != SymbolDepth.Normal ) && (lastSymbol._level == sd))
			{
				p.X = p.X + LastCharSize.Width;
			}


			return p;
		}

		const int kNumeratorDistance = 5;

		void HandleNumeratorMode()
		{
			// retrieve the current symbol
			Symbol currentSymbol = ((Symbol)Symbols[CurrentDivideSymbolIndex]);

			// boost the symbol up onto the numerator
			currentSymbol._position.Y -= kNumeratorDistance;

			// create an underline font for the character if its not a subscript or superscript
			if (currentSymbol._level == SymbolDepth.Normal)
				currentSymbol._font = new Font(currentSymbol._font.FontFamily.Name, currentSymbol._font.SizeInPoints, FontStyle.Underline);
			MoveCursorBack(CurrentDivideSymbolIndex);

			// get the next numerator index to the left
			CurrentDivideSymbolIndex--;

			// don't go past the beginning of the symbol list
			if (CurrentDivideSymbolIndex < 0) // post condition
				CurrentDivideSymbolIndex = 0;
			Invalidate();
		}


		private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			char TestChar = 'a';
			string FullChar = "";
			ControlPressed = e.Control;
			AltPressed = e.Alt;
			ShiftPressed = e.Shift;



			if (e.KeyValue == 16 || e.KeyValue == 17 || e.KeyValue == 18)
				return; // precondition

			

			// for dividing move each symbol up
			if (DivideOn && (e.KeyData == Keys.Left))
			{
				HandleNumeratorMode();
			}
			else if (DivideOn)
			{
				DivideOn = false; // now allow for fraction entry
				DenominatorMode = true;
				SetStatus("Ready");
				MoveCursorDown(11);
			}



			if (AltPressed && (e.KeyValue != 18) && (e.KeyValue != 16)) // use alt to raise letters
			{
				TestChar = e.KeyData.ToString()[0];
				if (ShiftPressed)
				{
					if ((e.KeyData.ToString().Length > 1) && (e.KeyData.ToString()[1] >= '0' && e.KeyData.ToString()[1]<= '9'))
					{
						CurrentCharacter = e.KeyData.ToString()[1];
						// place to the power
						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X + 1, TheCursor.Position.Y - LastCharSize.Height/3);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Raised );
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Raised));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
					}
					else if ( e.KeyCode.ToString().Length > 3 && e.KeyCode.ToString().ToLower().Substring(0,3) == "oem")
					{
						CurrentCharacter =(char) ((int)e.KeyValue & 0x7f);
						if (CurrentCharacter == '=')
							CurrentCharacter = '-';
						if (CurrentCharacter == ';')
							CurrentCharacter = '+';

						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X + 1, TheCursor.Position.Y - LastCharSize.Height/3);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Lowered  );
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Raised ));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
					}
					else if ((e.KeyData.ToString().Length > 0) && (e.KeyData.ToString()[0] >= 'A' && e.KeyData.ToString()[0]<= 'Z'))
					{
						CurrentCharacter = (char)(e.KeyData.ToString()[0] + (char)('a' - 'A')); // force to lower case
						// place to the power
						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X + 1, TheCursor.Position.Y - LastCharSize.Height/3);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Raised);
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Raised ));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
						return;
					}
				}
				else
				{
					if ((e.KeyData.ToString().Length > 1) && (e.KeyData.ToString()[1] >= '0' && e.KeyData.ToString()[1]<= '9'))
					{
						CurrentCharacter = e.KeyData.ToString()[1];
						// place to the power
						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X, TheCursor.Position.Y + LastCharSize.Height/2);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Lowered  );
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Lowered ));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
					}
					else if ( e.KeyCode.ToString().Length > 3 && e.KeyCode.ToString().ToLower().Substring(0,3) == "oem")
					{
						CurrentCharacter =(char) ((int)e.KeyValue & 0x7f);

						if (CurrentCharacter == '=')
							CurrentCharacter = '-';
						if (CurrentCharacter == ';')
							CurrentCharacter = '+';


						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X, TheCursor.Position.Y + LastCharSize.Height/2);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Lowered  );
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Lowered ));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
					}
					else if ((e.KeyData.ToString().Length > 0) && (e.KeyData.ToString()[0] >= 'A' && e.KeyData.ToString()[0]<= 'Z'))
					{
						CurrentCharacter = (char)(e.KeyData.ToString()[0] + (char)('a' - 'A')); // force to lower case
						// place to the power
						CurrentFont = new Font("Times New Roman", 8);
						PointF UpFromCursor = new PointF(TheCursor.Position.X, TheCursor.Position.Y + LastCharSize.Height/2);
						UpFromCursor = AdjustForPreviousCharacter(UpFromCursor, SymbolDepth.Lowered );
						AddSymbol(new Symbol(UpFromCursor, CurrentCharacter, CurrentFont, SymbolDepth.Lowered ));
						AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
						Invalidate();
						return;
					}
				}
			}

			if (ControlPressed)
			{
				bool bMakeItalic = false;
				CurrentCharacter = (char)(e.KeyValue & 0x7f);
				if ((ShiftPressed == false) && (CurrentCharacter >= 'A') && (CurrentCharacter <= 'Z'))// need lower case
				{
					CurrentCharacter += (char)((int)'a' - (int)'A');
					bMakeItalic = true;
				}

				// use some of the more interesting symbols to replace other keys

				if (CurrentCharacter == '^')
				{
				 CurrentCharacter = '\"';
				}

				if (CurrentCharacter == ';')
				{
					CurrentCharacter = (char)0xb6;
				}

				if (CurrentCharacter == '=')
				{
					CurrentCharacter = (char)0xb1;
				}

				// square root mode
				if (CurrentCharacter == '?')
				{
					CurrentCharacter = (char)0xd6;
					this.SquareRootOn = true;
					SetStatus("SquareRoot On", "Hit esc key to stop");
				}



				if ((CurrentCharacter >= '0') && (CurrentCharacter <= '9'))// need lower case
				{
					switch (CurrentCharacter)
					{
						case '0':
							CurrentCharacter = (char)0xa5;
							break;
						case '1':
							CurrentCharacter = '!';
							break;
						case '2':
							CurrentCharacter = '@';
							break;
						case '3':
							CurrentCharacter = '#';
							break;
						case '4':
							CurrentCharacter = '$';
							break;
						case '5':
							CurrentCharacter = '%';
							break;
						case '6':
							CurrentCharacter = '^';
							break;
						case '7':
							CurrentCharacter = '&';
							break;
						case '8':
							CurrentCharacter = '\'';
							break;
						case '9':
							CurrentCharacter = (char)0xA6;
							break;
					}
				}


				if (bMakeItalic)
					CurrentFont = new Font("Symbol", 11 /* , FontStyle.Italic */);
				else
					CurrentFont = new Font("Symbol", 11);
				AddSymbol(new Symbol(TheCursor.Position, CurrentCharacter, CurrentFont,  SymbolDepth.Normal));
				AdjustCursor((Symbol)Symbols[Symbols.Count - 1]);
				Invalidate();

			}
			else
			{
				CurrentCharacter = (char)e.KeyValue;
			}

			if (CurrentCharacter == ' ') // used to turn on or off
			{
//				if (DivideOn)
//				{
//					DivideOn = false;
//					MoveCursorToEnd();
//				}

			}

			// special cases

			// allow for arrow keys
			if ( (e.KeyData == Keys.Up || e.KeyData == Keys.Escape) && DenominatorMode)
			{
				MoveCursorUp(11);
				DenominatorMode = false;
			}


			if ((e.KeyData == Keys.Right) || (e.KeyData == Keys.Escape))
			{
				if (SquareRootOn)
				{
					SquareRootOn = false;
					SetStatus("Ready");
				}

				MoveCursorRight(11);
			}




			Console.WriteLine(FullChar);
		}

		DataSet ds = new DataSet();

		void ReadPageFromDataset()
		{
			Symbols.Clear();

			// get a reference to the table of data
			DataTable dt = ds.Tables["MathSymbols"];

			// read in each symbol
			foreach (DataRow dr in dt.Rows)
			{
				// construct the symbol based on the xml fields
				Symbol s = new Symbol(new PointF((float)Convert.ToDouble(dr["X"].ToString()), (float)Convert.ToDouble(dr["Y"].ToString())),
					dr["Character"].ToString()[0], 
					new Font(dr["FontFamily"].ToString(), Convert.ToSingle(dr["FontSize"].ToString()), (FontStyle)Convert.ToInt32(dr["FontStyle"].ToString())),
					(SymbolDepth)(Convert.ToInt32(dr["Level"].ToString())));

				// also determine if its under a square root sign
				s._squareroot = (dr["SquareRoot"].ToString().ToLower() == "true");

				// add the symbol to the arraylist
				AddSymbol(s);
			}

			// redraw the screen
			Invalidate();

		}


		void ReadFile(string filePath)
		{
			ds.Clear();   // clear out the dataset

			// if the album xml database exists, read it in.
			if (File.Exists(filePath))
			{
				ds.ReadXml(filePath);
				ReadPageFromDataset();   // read dataset into form
			} 
		}

		void SetUpDataSetStructure()
		{
			ds.Dispose();
			ds = new DataSet();
			ds.Tables.Add(new DataTable("MathSymbols"));
			ds.Tables[0].Columns.Add(new DataColumn("X", Type.GetType("System.Single")));
			ds.Tables[0].Columns.Add(new DataColumn("Y", Type.GetType("System.Single")));
			ds.Tables[0].Columns.Add(new DataColumn("Character", Type.GetType("System.Char")));
			ds.Tables[0].Columns.Add(new DataColumn("FontFamily", Type.GetType("System.String")));
			ds.Tables[0].Columns.Add(new DataColumn("FontSize", Type.GetType("System.Single")));
			ds.Tables[0].Columns.Add(new DataColumn("FontStyle", Type.GetType("System.Int32")));
			ds.Tables[0].Columns.Add(new DataColumn("Level", Type.GetType("System.Int32")));
			ds.Tables[0].Columns.Add(new DataColumn("SquareRoot", Type.GetType("System.Boolean")));


		}

		void WriteFile(string theFile)
		{

			// try to find the image row from the Position and Page we are inserting the image into
			SetUpDataSetStructure();

			DataTable dt = ds.Tables["MathSymbols"];

			// insert new symbol into dataset
			foreach (Symbol s in Symbols)
			{
				DataRow dr = dt.NewRow();
				dr["X"] = s._position.X;
				dr["Y"] = s._position.Y;
				dr["Character"] = s._character;
				dr["FontFamily"] = s._font.FontFamily.Name;
				dr["FontSize"] = s._font.SizeInPoints;
				dr["FontStyle"] = (int)s._font.Style;
				dr["Level"] = (int)s._level;
				dr["SquareRoot"] = s._squareroot;
				dt.Rows.Add(dr);
			}

			// write out the new data to the XML database

			ds.WriteXml(theFile);

		}



		private void OpenMenu_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.FileName = "*.xml";
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				ReadFile(openFileDialog1.FileName);
				MoveCursorToEnd();
			}
		}

		private void SaveMenu_Click(object sender, System.EventArgs e)
		{
			if (saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				WriteFile(saveFileDialog1.FileName);
			}
		}

		private void PrintMenu_Click(object sender, System.EventArgs e)
		{
			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				printDocument1.Print();
			}
		}

		private void PrintPreviewMenu_Click(object sender, System.EventArgs e)
		{
			if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
			{
			}
		}

		private void ExitMenu_Click(object sender, System.EventArgs e)
		{
		  Application.Exit();
		}

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			DrawAll(e.Graphics);
		}

		private void NewMenu_Click(object sender, System.EventArgs e)
		{
			Symbols.Clear();
			TheCursor.Reset();
			Invalidate();
		}

		private void SaveImageMenu_Click(object sender, System.EventArgs e)
		{
			if (saveFileDialog2.ShowDialog() == DialogResult.OK)
			{
				Image image = new Bitmap(ClientRectangle.Width, 
					ClientRectangle.Height);
				Graphics g = Graphics.FromImage(image);
				g.SmoothingMode = SmoothingMode.HighQuality;
				DrawAll(g);
				image.Save(saveFileDialog2.FileName, ImageFormat.Bmp);
			}
		}

	}
}
