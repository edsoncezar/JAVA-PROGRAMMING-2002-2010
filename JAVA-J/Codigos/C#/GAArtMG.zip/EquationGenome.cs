using System;
using System.Collections;
using MEPArt;
using System.Drawing;

namespace MEPArt
{
	/// <summary>
	/// Summary description for EquationNode.
	/// Equation node represents a symbolic equation that solves a problem
	/// In this case we'll use the following keys to represent our node
	/// 0: a 1: b 2: *  3: / 4: + 5: -  6: %  7: S (sin) 8: PI 9: Power
	/// </summary>
	/// 
	public class EquationGenome : Genome
	{
		public const int NumSymbols = 4;
		public const int NumFunctions = 4;

		public struct Gene
		{
			public int instruction1;
			public int instruction2;
			public int operation;
		};

		ArrayList TheArray = new ArrayList();
		public static Random TheSeed = new Random((int)DateTime.Now.Ticks);
		int TheMin = 0;
		int TheMax = 9;
		int CurrentXPos = 0;
		int CurrentYPos = 0;
		int PreviousSeed = 2;
		public bool TrialFitness; // this needs to be perfect or else we have to throw out the gene

		public override int CompareTo(object a)
		{
			EquationGenome Gene1 = this;
			EquationGenome Gene2 = (EquationGenome)a;
			return Math.Sign(Gene2.CurrentFitness  -  Gene1.CurrentFitness);
		}


		public override void SetCrossoverPoint(int crossoverPoint)
		{
			CrossoverPoint = 	crossoverPoint;
		}

		public EquationGenome()
		{
		}


		public EquationGenome(long length, object min, object max)
		{
			//
			// TODO: Add constructor logic here
			//
			Length = length;
			TheMin = (int)min;
			TheMax = (int)max;
			CurrentXPos = 0;
			CurrentYPos = 0;

			for (int i = 0; i < Length; i++)
			{
				Gene nextValue = (Gene)GenerateGeneValue(min, max, i);
				TheArray.Add(nextValue);
			}
		}

		public override void Initialize()
		{

		}

		public override bool CanDie(double fitness)
		{
			if (CurrentFitness <= (int)(fitness * 100.0f))
			{
				return true;
			}

			return false;
		}


		public override bool CanReproduce(double fitness)
		{
			if (EquationGenome.TheSeed.Next(100) >= (int)(fitness * 100.0f))
			{
				return true;
			}

			return false;
		}


		public override object GenerateGeneValue(object min, object max, int position)
		{
			Gene g = new Gene();
			int nextSeed = 0;
			nextSeed = TheSeed.Next((int)min, (int)max);
			g.operation = nextSeed;

			if (position == 0) // special case, want to generate a symbol for first one
			{
				g.operation = TheSeed.Next(0, NumSymbols);  // generate 0 or 1, for a and b
				return g;
			}

			if (nextSeed > 1) // we have an operation, need postion
			{
				nextSeed = TheSeed.Next((int)min, position);
				g.instruction1 = nextSeed;
				nextSeed = TheSeed.Next((int)min, position);
				g.instruction2 = nextSeed;
			}
			
			return g;
		}

		#region GenerateSmartGene
		/*
				public override object GenerateGeneValue(object min, object max)
				{
					bool hasWall = true;
					int nextSeed = 0;
					int counter = 0;
					while (hasWall)
					{
						nextSeed = TheSeed.Next((int)min, (int)max);
						switch (nextSeed)
						{
							case 0:  // up
								if (PreviousSeed == 2)
								{	
									break; // don't backtrack
								}
								hasWall = TheMaze.HasWall(CurrentXPos, this.CurrentYPos, CurrentXPos, CurrentYPos - 1);
								if (hasWall == false)
								{
								 CurrentYPos--;
								}
								break;
							case 1:  // left
								if (PreviousSeed == 3)
								{	
									break; // don't backtrack
								}

								hasWall = TheMaze.HasWall(CurrentXPos, this.CurrentYPos, CurrentXPos - 1, CurrentYPos);
								if (hasWall == false)
								{
									CurrentXPos--;
								}
								break;
							case 2:  // down
								if (PreviousSeed == 0)
								{	
									break; // don't backtrack
								}
								hasWall = TheMaze.HasWall(CurrentXPos, this.CurrentYPos, CurrentXPos, CurrentYPos + 1);
								if (hasWall == false)
								{
									CurrentYPos++;
								}
								break;
							case 3:  // right
								if (PreviousSeed == 1)
								{	
									break; // don't backtrack
								}

								hasWall = TheMaze.HasWall(CurrentXPos, this.CurrentYPos, CurrentXPos + 1, CurrentYPos);
								if (hasWall == false)
								{
									CurrentXPos++;
								}
								break;
						}

						counter++;
						if (counter > 10)
							break;

					}

					return nextSeed;

				}

		*/

#endregion 



		public override void Mutate()
		{
			int AffectedGenes = TheSeed.Next((int)3); // determine how many genes to mutate
			for (int i = 0; i < AffectedGenes; i++)
			{
				MutationIndex = TheSeed.Next(0, (int)Length);
				//				int val = (int)GenerateGeneValue(TheMin, TheMax);
				TheArray[MutationIndex] = this.GenerateGeneValue(TheMin, TheMax, MutationIndex);
			}

		}


		// This fitness function calculates the fitness of distance travelled
		// from upper left to lower right



		#region fitness2

		// This fitness function calculates the fitness of distance travelled
		/*		// from upper left to lower right
				private double CalculateMazeDistanceFitness()
				{
					double sum = 0.0f;
					int cellPreviousPosX = 0;
					int cellPreviousPosY = 0;
					int cellPosX = 0;
					int cellPosY = 0;
					int trialnumber = 0;
					int backTrack = 0;
					int hasWall = 0;
					int maxConsecutiveNoWalls = 0;
					int consecutiveNoWalls = 0;
					int previousDirection = 0;
					for (int i = 0; i < Length; i++)
					{
						switch ((int)TheArray[i])
						{
							case 0:  // up
								cellPosY--;
								break;
							case 1:  // left
								cellPosX--;
								break;
							case 2:  // down
								cellPosY++;
								break;
							case 3:  // right
								cellPosX++;
								break;
						}

						if ( (previousDirection + 2) % 4 == (int)TheArray[i])
						{
							backTrack++;
						}

						previousDirection = (int)TheArray[i];

						if (maxConsecutiveNoWalls < consecutiveNoWalls)
								maxConsecutiveNoWalls = consecutiveNoWalls;

						if (TheMaze.HasWall(cellPreviousPosX, cellPreviousPosY, cellPosX, cellPosY))
						{
							consecutiveNoWalls = 0;
						}
						else
						{
							consecutiveNoWalls++;
						}

		//				trialnumber++;


						cellPreviousPosX = cellPosX;
						cellPreviousPosY = cellPosY;
					}

					// the score is the distance squared from the origin
					// since the greatest distance is the distance to the destination
					// the lower right hand corner
		//			sum = ((double)(cellPosX*cellPosX + cellPosY*cellPosY))/((double)(Maze.kDimension*Maze.kDimension));  

					sum = sum + ((double)(maxConsecutiveNoWalls))/((double)this.Length);
					sum = sum + ((double)(Length - backTrack))/((double)this.Length);

					sum = sum/2;

					return sum;
				}
		*/

		#endregion 



		public string GetOperationString(int operation)
		{
			string result = "";
			switch(operation)
			{
				case 4: // *
					result = "*";
					break;
				case 5: // / 
					result = "/";
					break;
				case 6: // +
					result = "+";
					break;
				case 7: // - 
					result = "-";
					break;
				case 8: // - 
					result = "%";
					break;
				case 9: // - 
					result = "abs";
					break;
				case 10: // - 
					result = "sin";
					break;
				default:
					// +
					break;
			} // end switch

			return result;

		}


		public double DoOperation(double a, double b, int operation)
		{
			double result = 0;
			switch(operation)
			{
				case 4: // and
					result = a * b;
					break;
				case 5: // or 
					result =  a / b;
					break;
				case 6: // xor
					result =  a + b;
					break;
				case 7: // - 
					result = a - b;
					break;
				case 8: // - 
					result = a % b;
					break;
				case 9: // - 
					result = Math.Abs(a) + Math.Abs(b);
					break;
				case 10: // - 
					result = Math.Sin(a * b);
					break;
				default:
					// +
					break;
			} // end switch

			return result;

		}

		double Factorial(double a)
		{
			
			if ((a > 100) || (a < 0) )
				return 100000000; // too big, just return a very large number just in case it is significant
		    double f = 1.0;
			for (int i = 1; i <= (int)a; i++)
			{
				f = f*i;
				if (double.IsNaN(f))
					return 100000000;  // just return a very large number just in case it is significant
			}

			return f;
		}

		string[] CalculationStringArray = new string[Population.kLength];

		public string FormStepsString()
		{
			string _result = "\n";

			int count = 0;
			foreach (Gene g in TheArray)
			{
				if (g.operation < NumSymbols)
				{
					// a or b, assign value
					if (g.operation == 0)
						_result += count.ToString() +": " + "a\n";
					else
						_result += count.ToString() +": " + "b\n";
				}
				else if (g.operation == 8)
				{
					_result += count.ToString() +": " + "PI\n";
				}
				else
				{
					// operation, use it to fill calculation in array
					_result += count.ToString() +": " + GetOperationString(g.operation) + " " + g.instruction1.ToString() + ", " + g.instruction2.ToString() + "\n";
				}

				count++;
			}

			_result += "\n\n";
			return _result;
		}


		public string FormEquationString()
		{
			string _result = "";

			int count = 0;
			foreach (Gene g in TheArray)
			{
				if (g.operation < NumSymbols)
				{
					// a or b, assign value

					switch (g.operation)
					{
						case 0:
							CalculationStringArray[count] = "a";
							break;
						case 1:
							CalculationStringArray[count] = "b";
							break;
						case 2:
							CalculationStringArray[count] = "1";
							break;
						case 3:
							CalculationStringArray[count] = "2";
							break;
					}

				}
					//				else if (g.operation == 8)
					//				{
					//					CalculationStringArray[count] = "1";
					//				}
					//				else if (g.operation == 7) // unary
					//				{
					//					CalculationStringArray[count] =   "(" + CalculationStringArray[g.instruction1] + GetOperationString(g.operation) + ")";
					//				}
				else if (g.operation == 9) // abs
				{
					CalculationStringArray[count] =   "(" + GetOperationString(g.operation) + "(" + CalculationStringArray[g.instruction1] + ") + " + GetOperationString(g.operation) + "(" + CalculationStringArray[g.instruction2] + ")" +  ")" ;
				}
				else if (g.operation == 10) // abs
				{
					CalculationStringArray[count] =   "(" + GetOperationString(g.operation) + "(" + CalculationStringArray[g.instruction1] + " * " +  CalculationStringArray[g.instruction2] + ")" +  ")" ;
				}
				else
				{
					// operation, use it to fill calculation in array
					CalculationStringArray[count] = "(" + CalculationStringArray[g.instruction1] + GetOperationString(g.operation) + CalculationStringArray[g.instruction2] + ")";
				}

				count++;
			}

			_result = CalculationStringArray[Population.kLength - 1];

			return _result;
		}

		double[] CalculationArray = new double[Population.kLength];

		public double PerformCalculation(double a, double b)
		{
			int count = 0;


			foreach (Gene g in TheArray)
			{
				if (g.operation < NumSymbols)
				{
					// a or b, assign value
					switch (g.operation)
					{
						case 0:
							CalculationArray[count] = a;
							break;
						case 1:
							CalculationArray[count] = b;
							break;
						case 2:
							CalculationArray[count] = 1;
							break;
						case 3:
							CalculationArray[count] = 2;
							break;
					}
				}
				else
				{
					// operation, use it to fill calculation in array
					CalculationArray[count] = DoOperation(CalculationArray[g.instruction1], CalculationArray[g.instruction2], g.operation);
				}

				count++;
			}

			return CalculationArray[TheArray.Count - 1];  // return last calculation
		}


		// a, result  (perfect squares
		/*		double[,] measure = new double[,]{
												   {1,1},
														   {2,4},
														   {3,9},
														   {4,16},
														   {5,25},
														   {6,36},
														   {7,49},
														   {8,64},
														   {9,81},
				};
		*/		

		/*		double[,] measure = new double[,]{
												   {1,1},
														   {4,2},
														   {9,3},
														   {16,4},
														   {25,5},
														   {36,6},
														   {49,7},
														   {64,8},
														   {81,9},
														   {100,10},
														   {169,13},
														   {196,14},
														   {256,16},
														   {1024,32},
														   {10000, 100},
														   {40000, 200}
				};

		*/
		
		double[] primes = new double[]{2,      3,      5,      7,     11,     13,     17,     19,     23,     29, 
										  31,     37,     41,     43,     47,     53,     59,     61,     67,     71, 
		73,     79,     83,    89,     97,      101,    103,    107,    109,    113, 
		127,    131,    137,    139,    149,    151,    157,    163,    167,    173, 
		179,    181,    191,    193,    197,    199,    211,    223,    227,    229, 
		233,    239,    241,    251,    257,    263,    269,    271,    277,    281, 
		283,    293,    307,    311,    313,    317,    331,    337,    347,    349, 
		353,    359,    367,    373,    379,    383,    389,    397,    401,    409, 
		419,    421,    431,    433,    439,    443,    449,    457,    461,    463, 
		467,    479,    487,    491,    499,    503,    509,    521,    523,    541, 
		547,    557,    563,    569,    571,    577,    587,    593,    599,    601, 
		607,    613,    617,    619,    631 ,   641 ,   643 ,   647,    653,    659, 
		661,    673,    677,    683,    691,    701,    709,    719,    727,    733, 
		739,    743,    751,    757,    761,    769,    773,    787,    797,    809, 
		811,    821,    823,    827,    829,    839,    853,    857,    859,    863, 
		877,    881,    883,    887,    907,    911,    919,    929,    937,    941, 
		947,    953,    967,    971,    977,    983,    991,    997};

		double[] primes_save = new double[]{2,      3,      5,      7,     11,     13,     17,     19,     23,     29, 
										  31,     37,     41,     43,     47,     53,     59,     61,     67,     71, 
										  73,     79,     83,    89,     97,      101,    103,    107,    109,    113, 
										  127,    131,    137,    139,    149,    151,    157,    163,    167,    173, 
										  179,    181,    191,    193,    197,    199,    211,    223,    227,    229, 
										  233,    239,    241,    251,    257,    263,    269,    271,    277,    281, 
										  283,    293,    307,    311,    313,    317,    331,    337,    347,    349, 
										  353,    359,    367,    373,    379,    383,    389,    397,    401,    409, 
										  419,    421,    431,    433,    439,    443,    449,    457,    461,    463, 
										  467,    479,    487,    491,    499,    503,    509,    521,    523,    541, 
										  547,    557,    563,    569,    571,    577,    587,    593,    599,    601, 
										  607,    613,    617,    619,    631 ,   641 ,   643 ,   647,    653,    659, 
										  661,    673,    677,    683,    691,    701,    709,    719,    727,    733, 
										  739,    743,    751,    757,    761,    769,    773,    787,    797,    809, 
										  811,    821,    823,    827,    829,    839,    853,    857,    859,    863, 
										  877,    881,    883,    887,    907,    911,    919,    929,    937,    941, 
										  947,    953,    967,    971,    977,    983,    991,    997};


			//		double[,] measure = new double[12,3]{{-1, -3, 3.162277f},  {30,40,50}, {40, 30, 50}, {1, 1, 1.4142f}, {1, 2, 2.23607f}, {3, 1, 3.162277f}, {6, 13, 14.31782f}, {4,3,5}, {1,3, 3.16228f}, {2, 1, 2.23607f}, {4, 5, 6.403f}, {5,4, 6.403f}};
			//		double[,] measure = new double[3,3]{{3,4,5}, {4,3,5}, {1,1,1.4142f}};
			// 3x + 2y = z
	//		 double[,] measure = new double[9,3]{{1,1,5}, {-1, 1, -1}, {1, -1, 1}, {.5f, .1f, 1.7f}, {5, 1, 17}, {-5, 10, 5}, {4,3,18}, {-10,1, -28}, {-2, 3, 0}};
		// x*x + y*y*y
			double[,] measure = new double[9,3]{{1,1,2}, {-1, 1, 2}, {1, -1, 0}, {.5f, .1f, .251f}, {5, 1, 26}, {-5, 10, 1025}, {4,3,43}, {-10,1, 101}, {-2, 3, 31}};

		public void Plot(Form1 TheForm, Graphics g)
		{
			// Fill the whole form with a light gray color to erase old drawing
			g.FillRectangle(Brushes.LightGray, TheForm.ClientRectangle);

			// go through each x,y coordinate and plug it into the equation
			// produced by the genome to derive an integer representing a 
			// color
			for (int i = 0; i < 300; i++)
				for (int j = 0; j < 300; j++)
				{
					double calc1 = PerformCalculation(i, j); // do calculation
					if (calc1  > 4)
						g.DrawLine(Pens.LightBlue, i, j, i+1, j);
					else if (calc1 > 3)
						g.DrawLine(Pens.Purple, i, j, i, j+1);
					else if (calc1 > 2)
						g.DrawLine(Pens.Red, i, j, i+1, j);
					else if (calc1 > 1)
						g.DrawLine(Pens.Yellow, i, j, i, j+1);
					else 
						g.DrawLine(Pens.Navy, i, j, i+1, j);
				}

		}


		
		double[,] measure1 = new double[,]
			{
					{0, 0, 4}, {0, 1, 3}, {0, 2, 4}, {1, 1, 4}, {2, 1, 3}, 
					{8, 20, 4}, {9, 14, 3}, {4, 5, 3}, {3, 7, 4}, {-1, 1, 4},
					{-2, 1, 3}, {-5, 10, 3}, {-8, 1, 3}
		    };

		public double CalculateArtFitness1()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;
			// let's base art fitness completely on the fact that the points stay on the form
			for (int i = 0; i < measure1.GetLength(0); i++)
			{
				calc = PerformCalculation(measure1[i, 0], measure1[i, 1]); // do calculation

				double error = 100 - Math.Abs(measure1[i, measure1.GetLength(1)- 1] - calc); // last byte
				sum +=  error;

				
				if (double.IsNaN(calc))
					return .001;
			}

			CurrentFitness = sum/(measure1.GetLength(0)*100);

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			if (CurrentFitness <= 0.0)
				CurrentFitness = .001;



			return CurrentFitness;
		}

		double[,] measure2 = new double[,]
			{
					{0, 0, 1}, {0, 1, 1}, {0, 2, 1}, {0, 3, 2}, {0, 4, 1}, 
					{1, 0, 1}, {1, 1, 1}, {1, 2, 2}, {1, 3, 1}, {1, 4, 1},
					{2, 0, 1}, {2, 1, 2}, {2, 2, 1}, {2, 3, 1},
					{-2,5, 2}, {13, -10, 2}, {3, 0, 2}
			};


		public double CalculateArtFitness2()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;
			// let's base art fitness completely on the fact that the points stay on the form
			for (int i = 0; i < measure2.GetLength(0); i++)
			{
				calc = PerformCalculation(measure2[i, 0], measure2[i, 1]); // do calculation

				double error = 100 - Math.Abs(measure2[i, measure2.GetLength(1)- 1] - calc); // last byte
				sum +=  error;

				
				if (double.IsNaN(calc))
					return .001;
			}

			CurrentFitness = sum/(measure2.GetLength(0)*100);

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			if (CurrentFitness <= 0.0)
				CurrentFitness = .001;



			return CurrentFitness;
		}

		double[,] measure3 = new double[,]
			{
					{0, 0, 0}, {0, 1, 1}, {0, 2, 2}, {0, 3, 3}, {0, 4, 0}, 
					{1, 0, 1}, {1, 1, 2}, {1, 2, 3}, {1, 3, 0}, {1, 4, 1},
					{2, 0, 2}, {2, 1, 3}, {2, 2, 0}, {2, 3, 1},
					{-2,5, 3}, {13, -10, 3}, {3, 0, 3}
			};


		public double CalculateArtFitness3()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;
			// let's base art fitness completely on the fact that the points stay on the form
			for (int i = 0; i < measure3.GetLength(0); i++)
			{
				calc = PerformCalculation(measure3[i, 0], measure3[i, 1]); // do calculation

				double error = 100 - Math.Abs(measure3[i, measure3.GetLength(1)- 1] - calc); // last byte
				sum +=  error;

				
				if (double.IsNaN(calc))
					return .001;
			}

			CurrentFitness = sum/(measure3.GetLength(0)*100);

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			if (CurrentFitness <= 0.0)
				CurrentFitness = .001;



			return CurrentFitness;
		}

		double[,] measure4 = new double[,]
			{
					{0, 0, 0}, {0, 1, 0}, {0, 2, 0}, {0, 3, 0}, {0, 4, 0}, 
					{1, 0, 0}, {1, 1, 1}, {1, 2, 2}, {1, 3, 3}, {1, 4, 4},
					{2, 0, 0}, {2, 1, 2}, {2, 2, 4}, {2, 3, 2},
					{-2,5, 0}, {13, -10, 0}, {3, 0, 0}, {1,5,1}, {2,4,3},
					{2,5,0}, {3,4,2}, {3,7,1}, {2,9,3}
			};


		public double CalculateArtFitness4()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;
			// let's base art fitness completely on the fact that the points stay on the form
			for (int i = 0; i < measure4.GetLength(0); i++)
			{
				calc = PerformCalculation(measure4[i, 0], measure4[i, 1]); // do calculation

				double error = 100 - Math.Abs(measure4[i, measure4.GetLength(1)- 1] - calc); // last byte
				sum +=  error;

				
				if (double.IsNaN(calc))
					return .001;
			}

			CurrentFitness = sum/(measure4.GetLength(0)*100);

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			if (CurrentFitness <= 0.0)
				CurrentFitness = .001;



			return CurrentFitness;
		}

		double[,] measure5 = new double[,]
			{
					{0, 0, 0}, {0, 1, 0}, {0, 2, 0}, {0, 3, 0}, {0, 4, 0}, 
					{1, 1, 1}, {1, 2, 1}, {1, 3, 1}, {1, 4, 1}, {1, 5, 1},
					{2, 1, 2}, {2, 2, 4}, {2, 3, 3}, {2, 4, 1},
					{-2, 2, 4}, {3, -2, .111}, {3, -5, .00411}, {-1,5,-1}, {2,4,1},
					{2,5,2}, {3,4,1}, {3,7, 2}, {2,9,2}, {5, 2, 0}, 
					{6, 2, 1}, {7, 2, 4}, {4, 2, 1}, {11, 2, 1}, {3, 2, 2},
					{-2, 1, -2}
			};


		public double CalculateArtFitness5()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;

			// go through each data point (produced from the formula a pow b mod 5)
			// and calculate a fitness of the equation
			for (int i = 0; i < measure5.GetLength(0); i++)
			{
				
				calc = PerformCalculation(measure5[i, 0], measure5[i, 1]); // do calculation

				// calculate a fitness number comparing the actual measured value
				// to the value produced by the equation
				double error = 100 - Math.Abs(measure5[i, measure5.GetLength(1)- 1] - calc); // last byte

				// add it to the overall average
				sum +=  error;

				// if its an undefined result, return a low fitness
				if (double.IsNaN(calc))
					return .001;
			}

			// normalize the fitness
			CurrentFitness = sum/(measure5.GetLength(0)*100);

			// if its an undefined result, return a low fitness
			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.001f;

			// don't allow fitnesses less or equal to zero
			if (CurrentFitness <= 0.0)
				CurrentFitness = .001;

			return CurrentFitness;
		}







		public double CalculateLineFitness()
		{
			double fitness = 0.0;
			double calc = 0.0f;
			double sum = 0.0f;
			for (int i = 0; i < measure.GetLength(0); i++)
			{
				calc = PerformCalculation(measure[i, 0], measure[i,1]); // do calculation
				
				if (double.IsNaN(calc))
					return .001;

				double error = 100 - Math.Abs(measure[i, measure.GetLength(1)- 1] - calc); // last byte
				sum +=  error;
			}

			CurrentFitness = sum/(measure.GetLength(0)*100);

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			return CurrentFitness;
		}

		public double CalculatePrimeFitness()
		{
			// use the node to calculate the fitness

//			Console.WriteLine (EquationNode.OutputStraightEquation(this));

			double calc = 0.0f;
			double sum = 0.0f;
			int length = primes.GetLength(0);
			for (int i = 0; i < length; i++)
			{
				calc = PerformCalculation(i, i); // do calculation
				if (double.IsNaN(calc))
					return .001;

				int index = Array.BinarySearch(primes, calc);
				if (index >= 0)
				{
					// remove number each time to ensure unique results
					sum ++;
					primes[index] = -4.3159d; // set it to an impossible value
				}
				else
				{
						// penalize the sum for bad finds
					//if greater than elements in the list penalize less
					if (~index > length-1)
					{
						sum = sum - 0.1;
					}
					else
						sum = sum - 0.25;
				}

			}

			CurrentFitness = sum/length; // Normalize

			primes_save.CopyTo(primes, 0);

			if (CurrentFitness == 0)
				CurrentFitness = .001;

			if (double.IsNaN(CurrentFitness))
				CurrentFitness = 0.01f;

			return CurrentFitness;
		}

		public override double CalculateFitness()
		{
			try
			{
				lock(this)
				{
					// CurrentFitness = CalculateClosestProductSum();
					//			CurrentFitness =  CalculateClosestSumTo10();
					//			CurrentFitness = CalculateMazeDistanceFitness();
					CurrentFitness = CalculateArtFitness5();
					if (CurrentFitness < 0.0f)
						CurrentFitness = 0.01f;
				}
			}
			catch (Exception ex)
			{
				CurrentFitness = .01f;  // ignore occasional exception
			}
			return CurrentFitness;
		}


		public override string ToString()
		{
			string strResult = "";
			//			for (int i = 0; i < Length; i++)
			//			{
			//			  strResult = strResult + ((int)TheArray[i]).ToString() + " ";
			//			}

			int index = 0;
			//			TheArray[0] = 5;			
			//			TheArray[1] = 3;			
			//			TheArray[2] = 1;			
			//			TheArray[3] = 0;			
			//			TheArray[4] = 2;		
//			strResult += " -->  " + this.FormStepsString();
			lock (this)
			{
					strResult += " -->  " + this.FormEquationString();
			}

				strResult += " --> " + CurrentFitness.ToString();

				return strResult;
		}

		public override void CopyGeneInfo(Genome dest)
		{
			EquationGenome theGene = (EquationGenome)dest;
			theGene.Length = Length;
			theGene.TheMin = TheMin;
			theGene.TheMax = TheMax;
		}

		public override Genome UniformCrossover(Genome g)
		{
			EquationGenome aGene1 = new EquationGenome();
			EquationGenome aGene2 = new EquationGenome();
			g.CopyGeneInfo(aGene1);
			g.CopyGeneInfo(aGene2);

// swap genes randomly

			EquationGenome CrossingGene = (EquationGenome)g;
			for (int i = 0; i < Length; i++)
			{
				if (TheSeed.Next(100) % 2 == 0)
				{
					aGene1.TheArray.Add(CrossingGene.TheArray[i]);
					aGene2.TheArray.Add(TheArray[i]);
				}
				else
				{
					aGene1.TheArray.Add(TheArray[i]);
					aGene2.TheArray.Add(CrossingGene.TheArray[i]);
				}

			}



			// 50/50 chance of returning gene1 or gene2
			EquationGenome aGene = null;
			if (TheSeed.Next(2) == 1)			
			{
				aGene = aGene1;
			}
			else
			{
				aGene = aGene2;
			}

			return aGene;
		}


		public override Genome Crossover2Point(Genome g)
		{
			EquationGenome aGene1 = new EquationGenome();
			EquationGenome aGene2 = new EquationGenome();
			g.CopyGeneInfo(aGene1);
			g.CopyGeneInfo(aGene2);

			// Pick a random crossover point
			int CrossoverPoint1 = TheSeed.Next(1, (int)Length);
			int CrossoverPoint2 = TheSeed.Next(CrossoverPoint1, (int)Length);
			// normalize
			if (CrossoverPoint1 > CrossoverPoint2)
			{
				int temp = CrossoverPoint1;
				CrossoverPoint1 = CrossoverPoint2;
				CrossoverPoint2 = temp;
			}

			EquationGenome CrossingGene = (EquationGenome)g;

			for (int j = 0; j < CrossoverPoint1; j++)
			{
				aGene1.TheArray.Add(TheArray[j]);
				aGene2.TheArray.Add(CrossingGene.TheArray[j]);
			}

			for (int j = CrossoverPoint1; j < CrossoverPoint2; j++)
			{
				aGene1.TheArray.Add(CrossingGene.TheArray[j]);
				aGene2.TheArray.Add(TheArray[j]);
			}


			for (int j = CrossoverPoint2; j < Length; j++)
			{
				aGene1.TheArray.Add(TheArray[j]);
				aGene2.TheArray.Add(CrossingGene.TheArray[j]);
			}


			// 50/50 chance of returning gene1 or gene2
			EquationGenome aGene = null;
			if (TheSeed.Next(2) == 1)			
			{
				aGene = aGene1;
			}
			else
			{
				aGene = aGene2;
			}

			return aGene;
		}



		public override Genome Crossover(Genome g)
		{
			EquationGenome aGene1 = new EquationGenome();
			EquationGenome aGene2 = new EquationGenome();
			g.CopyGeneInfo(aGene1);
			g.CopyGeneInfo(aGene2);

			// Pick a random crossover point
			CrossoverPoint = TheSeed.Next(1, (int)Length);

			EquationGenome CrossingGene = (EquationGenome)g;
			for (int i = 0; i < CrossoverPoint; i++)
			{
				aGene1.TheArray.Add(CrossingGene.TheArray[i]);
				aGene2.TheArray.Add(TheArray[i]);
			}

			for (int j = CrossoverPoint; j < Length; j++)
			{
				aGene1.TheArray.Add(TheArray[j]);
				aGene2.TheArray.Add(CrossingGene.TheArray[j]);
			}

			// 50/50 chance of returning gene1 or gene2
			EquationGenome aGene = null;
			if (TheSeed.Next(2) == 1)			
			{
				aGene = aGene1;
			}
			else
			{
				aGene = aGene2;
			}

			return aGene;
		}

		public int this[int arrayindex]
		{
			get
			{
				return (int)TheArray[arrayindex];
			}
		}

		public override void CopyGeneFrom(Genome src)
		{
			EquationGenome theGene = (EquationGenome)src;
			for (int i = 0; i < TheArray.Count; i++)
			{
				TheArray[i] = (Gene)theGene.TheArray[i];			
			}

			Length = theGene.Length;
			TheMin = theGene.TheMin;
			TheMax = theGene.TheMax;
			CurrentFitness = theGene.CurrentFitness;

		}


	}
}
