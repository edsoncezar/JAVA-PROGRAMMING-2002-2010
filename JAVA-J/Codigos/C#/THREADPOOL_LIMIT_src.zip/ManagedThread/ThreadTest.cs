using System;
using System.Timers;
using System.Threading;

namespace ThreadTests
{
	class ThreadTest
	{
		static bool done=false;
		static int threadDone=0;
		static System.Timers.Timer timer=new System.Timers.Timer(1000);

		static decimal[] threadPoolCounters=new decimal[10];
		static Thread[] threads=new Thread[10];
		

		static void Main(string[] args)
		{
			timer.Stop();
			timer.AutoReset=false;
			timer.Elapsed+=new ElapsedEventHandler(OnTimerEvent);
			decimal total=0;
			uint maxWorkerThreads;
			uint maxIOThreads;


			MSCoreeTypeLib.ThreadManager threadManager =
				new MSCoreeTypeLib.ThreadManager();

			// QueryInterface for the ICorThreadPool interface:
			MSCoreeTypeLib.ICorThreadpool  ct = 
				(MSCoreeTypeLib.ICorThreadpool)threadManager;


			maxWorkerThreads = 0;
			maxIOThreads = 0;
			ct.GetMaxThreads(out maxWorkerThreads, out maxIOThreads);
			Console.WriteLine("Total Max Threads= "+maxWorkerThreads.ToString(), "Total I/O Max=",maxIOThreads.ToString());

			// Call SetMaxThreads method on a COM interface.
			maxWorkerThreads = 35;
			maxIOThreads = 35;
			ct.SetMaxThreads(maxWorkerThreads, maxIOThreads);

			// using ThreadPool
			Console.WriteLine();
			Console.WriteLine("ThreadPool:");
			InitThreadPoolCounters();
			QueueThreadPoolThreads();
			while (threadDone != 10) {};
			Console.WriteLine("ThreadPool: 10 simultaneous threads:");
			total=0;
			for (int i=0; i<10; i++)
			{
				Console.WriteLine("T"+i.ToString()+" = "+threadPoolCounters[i].ToString()+"   ");
				total+=threadPoolCounters[i];
			}
			maxWorkerThreads = 0;
			maxIOThreads = 0;
			ct.GetMaxThreads(out maxWorkerThreads, out maxIOThreads);
			Console.WriteLine("Total = "+total.ToString());
			Console.WriteLine("Total Max Threads= "+maxWorkerThreads.ToString(), "Total I/O Max=",maxIOThreads.ToString());
			
		}

		

		


		static void Count3Thread(object state)
		{
			int n=(int)state;
			while (!done)
			{
				++threadPoolCounters[n];
			}
			Interlocked.Increment(ref threadDone);
		}


		

		static void InitThreadPoolCounters()
		{
			threadDone=0;
			for (int i=0; i<10; i++)
			{
				threadPoolCounters[i]=0;
			}
		}

		

		static void StartThreads()
		{
			done=false;
			timer.Start();
			for (int i=0; i<10; i++)
			{
				threads[i].Start();
			}
		}

		static void QueueThreadPoolThreads()
		{
			done=false;
			timer.Start();
			for (int i=0; i<10; i++)
			{
				ThreadPool.QueueUserWorkItem(new WaitCallback(Count3Thread), i);
			}
			
			
		}

		
		static void OnTimerEvent(object src, ElapsedEventArgs e)
		{
			done=true;
		}
	}
}