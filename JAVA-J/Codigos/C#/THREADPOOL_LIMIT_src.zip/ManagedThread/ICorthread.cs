
using System;
using System.Runtime.InteropServices;

namespace MSCoreeTypeLib 
{
	// Declare ThreadManager as a COM coclass:
	[
		// CLSID_CorRuntimeHost from MSCOREE.DLL
		Guid("CB2F6723-AB3A-11D2-9C40-00C04FA30A3E"),ComImport
	]
	class ThreadManager   // Cannot have a base class or
		// interface list here.
	{ 
		// Cannot have any members here 
		// NOTE that the C# compiler will add a default constructor
		// for you (no parameters).
	}

	
	// derives from IUnknown interface:
	[
	// IID_IcorThreadPool
	Guid("84680D3A-B2C1-46e8-ACC2-DBC0A359159A"), 
	InterfaceType(ComInterfaceType.InterfaceIsIUnknown)
	] 
	public interface ICorThreadpool   // Cannot list any base interfaces here 
	{ 
		// Note that IUnknown Interface members are NOT listed here:

		void RegisterWaitForSingleObject(); // Not Implemeted. 
		void UnregisterWait(); //  Not Implemeted. 
		void QueueUserWorkItem(); //  Not Implemeted. 
		void CreateTimer(); //  Not Implemeted. 
		void ChangeTimer(); //  Not Implemeted. 
		void DeleteTimer(); //  Not Implemeted. 
		void BindIoCompletionCallback(); //  Not Implemeted. 
		void CallOrQueueUserWorkItem();  // Not Implemeted. 
		void SetMaxThreads( uint MaxWorkerThreads, uint MaxIOCompletionThreads );
		void GetMaxThreads(  out uint MaxWorkerThreads, out uint MaxIOCompletionThreads );
		void GetAvailableThreads( out uint AvailableWorkerThreads, out uint AvailableIOCompletionThreads );
	}
		

		
	
}

/*
class MainClass 
{ 


	public static void Main(string[] args) 
	{ 
		
		// Create instance of ThreadPool Manager
		// (Calls CoCreateInstance(84680D3A-B2C1-46e8-ACC2-DBC0A359159A, 
		//  NULL, CLSCTX_ALL, IID_IUnknown, 
		//  &objThreadManager). Returns null on failure.):
		MSCoreeTypeLib.ThreadManager threadManager =
			new MSCoreeTypeLib.ThreadManager();

		// QueryInterface for the ICorThreadPool interface:
		MSCoreeTypeLib.ICorThreadpool  ct = 
			(MSCoreeTypeLib.ICorThreadpool)threadManager;

		// Call some methods on a COM interface.
		ct.SetMaxThreads(35,5);
       
	
	}

	
}
*/
