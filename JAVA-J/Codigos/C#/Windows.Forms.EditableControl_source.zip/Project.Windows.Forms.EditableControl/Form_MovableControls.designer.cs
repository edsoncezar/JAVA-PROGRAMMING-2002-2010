﻿namespace Test.Windows.Forms
{
    partial class Form_MovableControls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SomeUserControl1 = new Test.Windows.Forms.SomeUserControl();
            this.SuspendLayout();
// 
// SomeUserControl1
// 
            this.SomeUserControl1.Location = new System.Drawing.Point(1, 0);
            this.SomeUserControl1.Name = "SomeUserControl1";
            this.SomeUserControl1.Size = new System.Drawing.Size(681, 363);
            this.SomeUserControl1.TabIndex = 0;
// 
// Form_MovableControls
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(704, 373);
            this.Controls.Add(this.SomeUserControl1);
            this.Name = "Form_MovableControls";
            this.Text = "Form_MovableControls";
            this.ResumeLayout(false);

        }

        #endregion

        private SomeUserControl SomeUserControl1;

    }
}