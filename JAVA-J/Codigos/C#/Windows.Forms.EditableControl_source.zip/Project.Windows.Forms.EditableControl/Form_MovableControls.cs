﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

#endregion

namespace Test.Windows.Forms
{
    partial class Form_MovableControls : Form
    {
        public Form_MovableControls()
        {
            InitializeComponent();
        }
    }
}