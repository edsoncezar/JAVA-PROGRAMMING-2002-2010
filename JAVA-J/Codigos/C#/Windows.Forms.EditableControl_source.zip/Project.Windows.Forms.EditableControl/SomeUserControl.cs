﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

#endregion

namespace Test.Windows.Forms
{
    /// <summary>
    /// UserControl with runtime editable layout extends EditableControl
    /// </summary>
    public partial class SomeUserControl 
        : Core.Windows.Forms.EditableControl
    {
        public SomeUserControl()
            :base()
        {
            InitializeComponent();

            base.EditableControls.Add(this.textBox1);
            base.EditableControls.Add(this.dataGridView1);
            base.EditableControls.Add(this.checkBox1);
            base.EditableControls.Add(this.checkedListBox1);
            base.EditableControls.Add(this.button1);

            // prepare EditableControl
            base.initialize();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicked");
        }
    }
}
