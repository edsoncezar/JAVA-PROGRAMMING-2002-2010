﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace Core.Windows.Forms
{
    /// <summary>
    /// EditableControl allows user to place Contained Controls as
    /// desired.
    /// Inherit from EditableControl, add some cotrols to be moved and
    /// in inherited (subclass/subform) and in default ctor add 
    ///             base.initialize();
    /// </summary>
    public
        partial
        class
        EditableControl
        :
        UserControl
    {
        /// <summary>
        /// Point where from Control will be moved
        /// </summary>
        private
            Point
            _point_begin
            ;

        /// <summary>
        /// Point where to Control will be moved
        /// </summary>
        private
            Point
            _point_end
            ;

        /// <summary>
        /// Moved Control
        /// </summary>
        private
            Control
            _control_moving
            = null
            ;

        /// <summary>
        /// x offeset on client control
        /// </summary>
        private
            int
            x_offset_on_client_control
            = 0
            ;

        /// <summary>
        /// y offeset on client control
        /// </summary>
        private
            int
            y_offset_on_client_control
            = 0
            ;

        /// <summary>
        /// Container for defining set of movable/editable Controls
        /// </summary>
        public
            System.Collections.ArrayList
            EditableControls
            ;

        public
            EditableControl
            (
            )
        {
            InitializeComponent();

            EditableControls = new System.Collections.ArrayList();
        }

        /// <summary>
        /// initialize memeber function hooks mouse events of all child 
        /// controls to mouse event handlers of the EditableControl
        /// </summary>
        protected
            virtual
            void
            initialize
            (
            )
        {
            foreach (Control ctrl in Controls)
            {
                ctrl.MouseDown += new MouseEventHandler(MouseDownEventHandler);
                ctrl.MouseUp += new MouseEventHandler(MouseUpEventHandler);
                ctrl.MouseMove += new MouseEventHandler(MouseMoveEventHandler);
            }

            return;
        }

        /// <summary>
        /// MouseDownEventHandler detects whether child control was hit and
        /// sets the starting point for the move of the child control
        /// </summary>
        /// <param name="sender">
        /// </param>
        /// <param name="evnt_args_mouse">
        /// </param>
        protected
            virtual
            void
            MouseDownEventHandler
            (
              object sender
            , MouseEventArgs evnt_args_mouse
            )
        {
            int x;
            int y;
            if (
                // while left button pressed (could define other keys)
                evnt_args_mouse.Button == MouseButtons.Left
                &&
                // ignore containing (parent) control
                !"Core.Windows.Forms.EditableControl"
                .Equals(sender.GetType().ToString())
                &&
                // control is defined as movable
                EditableControls.Contains(sender)
               )
            {
                Point pt;

                pt = Cursor.Position;
                x_offset_on_client_control = evnt_args_mouse.X;
                y_offset_on_client_control = evnt_args_mouse.Y;

                x = x_offset_on_client_control + ((Control)sender).Location.X;
                y = y_offset_on_client_control + ((Control)sender).Location.Y;
                pt = new Point(x, y);

                _point_begin = pt;

                foreach (Control ctrl in Controls)
                {
                    if (ctrl.Bounds.Contains(_point_begin))
                    {
                        _control_moving = ctrl;
                    }
                }
            }

            return;
        }

        /// <summary>
        /// MouseMoveEventHandler moves child control on the screen
        /// </summary>
        /// <param name="sender">
        /// </param>
        /// <param name="evnt_args_mouse">
        /// </param>
        protected
           virtual
           void
           MouseMoveEventHandler
           (
             object sender
           , MouseEventArgs evnt_args_mouse
           )
        {
            if (
                !"Core.Windows.Forms.EditableControl"
                .Equals(sender.GetType().ToString())
                &&
                _control_moving != null
                &&
                evnt_args_mouse.Button == MouseButtons.Left
               )
            {
                Point pt = Cursor.Position;
                _control_moving.Left =
                                (this.PointToClient(pt)).X
                                -
                                x_offset_on_client_control
                                ;
                _control_moving.Top =
                                (this.PointToClient(pt)).Y
                                -
                                y_offset_on_client_control
                                ;
            }
        }

        /// <summary>
        /// MouseUpEventHandler detects when and where child control released
        /// and sets the ending point for the move of the child control
        /// </summary>
        /// <param name="sender">
        /// </param>
        /// <param name="evnt_args_mouse">
        /// </param>
        protected
            virtual
            void
            MouseUpEventHandler
            (
              object sender
            , MouseEventArgs evnt_args_mouse
            )
        {
            if (
                _control_moving != null
                &&
                evnt_args_mouse.Button == MouseButtons.Left
               )
            {
                int x;
                int y;

                x = ((Control)sender).Location.X;
                y = ((Control)sender).Location.Y;

                Point pt = new Point(x, y);
                _point_end = pt;
                _control_moving.Location = _point_end;
                _control_moving = null;
            }

            return;
        }
    }
}
