﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Windows.Forms;

// moljac++ 2004.11.10
#endregion

namespace Test.Windows.Forms
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the test case
		/// </summary>
		public
		    static 
            void 
            Main()
		{
            Application.Run
                (
                new Form_MovableControls()
                );
        }
    }
}