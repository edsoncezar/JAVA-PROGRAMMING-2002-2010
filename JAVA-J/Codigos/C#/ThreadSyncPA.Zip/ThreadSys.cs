namespace ThreadSyn
{
    using System;
	using System.Threading;

  
	/// <summary>
	/// This class is used to calculate approximate using trapezoid formula
	/// </summary>
	public class Integral
	{
		public delegate double FTyp(double x);

		/// <summary>
		/// Constructor 
		/// </summary>
		/// <param name="inF">inF is the function, which is to be integrated
		/// </param>
		public Integral(FTyp inF)
		{
			this.F = inF;	
		}
		/// <summary>
		/// this method will calculate the approximate integral using nStep
		/// </summary>
		/// <param name="inA"> </param>
		/// <param name="inB"> </param>
		/// <param name="nStep"> </param>
		public double calculate(double inA,double inB,int nStep)
		{
			double nResult = 0;
			double h = (inB-inA)/nStep;

			for(int i=1;i<nStep;i++)
			{
				nResult += 2*F(inA+i*h);
			}
			nResult += (F(inA)+F(inB));
			nResult *=h/2;
			return 	nResult;	
		}
		
		private FTyp F;
	}

	

	
    /// <summary>
    ///    This class is an example for thread synchronization
    /// </summary>
    public class Synchron
    {
      
		private double m_dSquare;
		private double m_dExp;

		static AutoResetEvent SquareEvent = new AutoResetEvent(false);// non signaled
        static AutoResetEvent ExpEvent = new AutoResetEvent(false);

		static public double  Square(double inX)
		{
			return inX*inX;
		}

		/// <summary>
		/// This method will calculate the integral from f(x) =x*x in [0,4]
		/// </summary>
		private void CalculateSquare( )
		{
			Console.WriteLine(" {0} is Started",Thread.CurrentThread.Name);

			Integral.FTyp  FSquare = new Integral.FTyp(Square);
			Integral SqIntegral = new Integral(FSquare); 

			Monitor.Enter(this); // lock
			this.m_dSquare =SqIntegral.calculate(0,4,500);
			Monitor.Exit(this);
			
			Console.WriteLine("m_dSquare: {0}",m_dSquare);
			
			SquareEvent.Set();// Set Flag 
				
		}

		/// <summary>
		/// This method will calculate the integral from f(x =exp(x) in [0,4]
		/// </summary>
		private void CalculateExp()
		{

			Console.WriteLine(" {0} is started",Thread.CurrentThread.Name);

			Integral.FTyp FExp = new Integral.FTyp(Math.Exp);
			Integral ExpIntegral = new Integral(FExp);

			Monitor.Enter(this); 
			this.m_dExp = ExpIntegral.calculate(0,4,500000);
			Monitor.Exit(this);

			Console.WriteLine("m_dExp: {0}",this.m_dExp);

			ExpEvent.Set(); // Set the Flag 

		}

		

        public static int Main(string[] args)
        {

            Synchron objSynchron = new Synchron();

			AutoResetEvent[] EventField = new AutoResetEvent[2];
            EventField[0] = SquareEvent;
			EventField[1] = ExpEvent;

			Thread SquThread =new  Thread(new ThreadStart(objSynchron.CalculateSquare));
			SquThread.Name = "SquThread";

			Thread ExpThread =new Thread(new ThreadStart(objSynchron.CalculateExp));
			ExpThread.Name = "ExpThread";
			ExpThread.Priority = ThreadPriority.AboveNormal;

            ExpThread.Start();
			SquThread.Start();

			WaitHandle.WaitAll(EventField);

			double dTotal = objSynchron.m_dExp + objSynchron.m_dSquare;


			Console.WriteLine(" ");
			Console.WriteLine("The Result is {0}",dTotal);

          
			
		    
			
		
			string strAnswer = Console.ReadLine();
            return 0;
        }

		

    }
}
