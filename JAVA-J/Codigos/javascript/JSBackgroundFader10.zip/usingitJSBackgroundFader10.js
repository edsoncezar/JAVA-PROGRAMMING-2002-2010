/*---------------------------------------------------------------------------

JavaScript Background Fader for Web Designers Toolkit
(C)1999-2004 USINGIT.COM, All Rights Reserved.
To get more free and professional scripts, visit:
http://www.usingit.com/
http://www.usingit.com/products/webtoolkit
email: support@usingit.com

This script can be used freely for commercial and non-commercial sites only if 
you don't alert the copyright info here! 

-----------------------------------------------------------------------------*/

//Set the parameters below to make this script to fit your need.

//Start color of fade effect.
var startColor='#FFC1C1';
//End color of fade effect.
var endColor='#FFFF00';
//How many steps the script will use to complete the fade animation.
var fadeSteps=30;
//How long the script will wait between each step in millisecond. Lower is faster.
var fadeDelay=10;
//The fade effect is not good if it works with Netscape 4.x during my test.
//Set it to true to disalbe this script for NS4.x users. false to enable it.
var disabledInNS4=true;

//DO NOT CHANGE ANYTHING BELOW.

var ns4=(document.layers)?true:false;
var oarClr=new Array();
for(i=1,j=1;i<=3;i++,j+=2){oarClr[i]=new makeClrObj(j);}
document.bgColor=startColor;

function makeClrObj(num){
this.sclr=parseInt('0x'+startColor.substring(num,num+2));
this.eclr=parseInt('0x'+endColor.substring(num,num+2));
this.incr=this.startpt=(this.eclr>=this.sclr)?true:false;
this.incrnum=Math.abs(this.eclr-this.sclr)/fadeSteps;
this.curclr=this.sclr;
}

function doFadeBG(){
	var arClr=new Array();
	for(i=1;i<=3;i++){
		if(oarClr[i].incr){
			oarClr[i].curclr+=oarClr[i].incrnum;
		}
		else
		{
			oarClr[i].curclr-=oarClr[i].incrnum;
		}
		if(oarClr[i].startpt){
			if(oarClr[i].curclr>=oarClr[i].eclr){
				oarClr[i].incr=false;
				oarClr[i].curclr=oarClr[i].eclr;
			}
			if(oarClr[i].curclr<=oarClr[i].sclr){
				oarClr[i].incr=true;
				oarClr[i].curclr=oarClr[i].sclr;
			}
		}
		else
		{
			if(oarClr[i].curclr<=oarClr[i].eclr){
				oarClr[i].incr=true;
				oarClr[i].curclr=oarClr[i].eclr;
			}
			if(oarClr[i].curclr>=oarClr[i].sclr){
				oarClr[i].incr=false;
				oarClr[i].curclr=oarClr[i].sclr;
			}
		}
		arClr[i]=oarClr[i].curclr;
	}
	r=Math.floor(arClr[1]).toString(16);
	if(r.length==1){r='0'+r;}
	g=Math.floor(arClr[2]).toString(16);
	if(g.length==1){g='0'+g;}
	b=Math.floor(arClr[3]).toString(16);
	if(b.length==1){b='0'+b;}
	document.bgColor='#'+r+g+b;
}

window.onload=function(){
	if(!(disabledInNS4&&ns4))setInterval('doFadeBG()',fadeDelay);
}