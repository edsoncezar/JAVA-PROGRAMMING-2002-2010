/* XSearch version 5.2 - Database file */

/* configuration settings */

	searchname = 'xsearch-5.2.htm'
	
	usebannercode=true
	ButtonCode = "<img src='searchbutton.gif' border=0>" 
	
	function templateBody() {
		document.write('<html><head><title>XSearch</title><'+
		'script language="Javascript">'+
		'<'+'/'+'script'+'></head><body bgcolor="#ffffff" text="#000000" link="#000099" vlink="#996699" alink="#996699"><Center><font face="Arial" size="3"><font face=Verdana size=12><b>XSEARCH</b><i>5.2</i></font><table border=0 width=640><tr><td>');
	}

	function templateEnd() {
		document.write('</td></tr></table></font></center></body></html>');
	}
	function bannerCode() {
	}	

/* end configuration settings */

/* database records */

add("<a href='../index.htm'>SiteNews</a>","news whats new updates information site info pascal plan update what's hot","Site news and plan updates")
add("<a href='../fusion/index.htm'>Fusion Opensource</a>","fusion overview features screenshots mp3 player manager developers opensource source code sourcecode delphi downloads files","Fusion is a full fledged mp3 manager..<br>..Fusion is opensource and written in Delphi 3, you can download")
add("<a href='../jedi/index.htm'>JEDI Javascript editor</a>","jedi javascript editor java script overview information features download jedi.zip files","JEDI is a freeware editing tool for Javascript that lets you create fast javascript powered websites with all the extras found in large programming environments like Delphi or C++ Builder.")
add("<a href='../xsearch/tools.htm'>XSearch Tools</a>","xsearch config configuration opensource download xsearchconfig.zip files","This XSearch Config tool was created to make the maintaining of the XSearch database a simple task to do.")
add("<a href='../javascript/insight/index.htm'>InSight Archive</a>","javascript insight archive calling the archive how does the work cool news system","Download the InSight Archive system, and you'll see the power of DHTML !")
add("<a href='../jsvcl/index.htm'>JSVCL: Javascript Visual Component Library</a>","jsvcl new components overview information javascript widgets tools dhtml dynamic html","The JSVCL is a collection of simple to use component utillizing DHTML that can be incorporated into a Javascript Application. The components are created to work just like real GUI like components found in operating systems like Windows98, X-windows, BeOs, etc..")
add("<a href='../jsvcl/button.htm'>JSVCL: tButton</a>","jsvcl tbutton component javascript dynamic html dhtml","An enhanced button for your website forms.")
add("<a href='../jsvcl/font.htm'>JSVCL: tFont</a>","jsvcl tfont component javascript dynamic html dhtml","A general font object, used by allmost all the components")
add("<a href='../jsvcl/glyph.htm'>JSVCL: tGlyph</a>","jsvcl tglyph component javascript dynamic html dhtml","The standard image component used by buttons, etc... ")
add("<a href='../jsvcl/label.htm'>JSVCL: tLabel</a>","jsvcl tlabel component javascript dynamic html dhtml","A simple label, very handy to place text anywhere on the page.")
add("<a href='../jsvcl/toolbar.htm'>JSVCL: tToolbar</a>","jsvcl ttoolbar component javascript dynamic html dhtml","The dragable toolbar, using the tbutton component")
add("<a href='../jsvcl/mouse.htm'>JSVCL: tMouse</a>","jsvcl tmouse component javascript dynamic html dhtml","A great component for creating your own mouse-pointers.")
add("<a href='../jsvcl/coollist.htm'>JSVCL: tCoolList</a>","jsvcl tcoollist component javascript dynamic html dhtml","A very cool selection component, it's based on the favourites bar in the Internet Explorer 4.0")
add("<a href='../jsvcl/container.htm'>JSVCL: tContainer</a>","jsvcl tcontainer component javascript dynamic html dhtml","A bevelled layer that can contain multiple components on it.")
add("<a href='../jsvcl/tShortCutBar.htm'>JSVCL: tShortCutBar</a>","jsvcl tshortcutbar component javascript dynamic html dhtml","A Outlook style navigation bar. Includes tShortCutBarItem and tShortCutBarButton")
add("<a href='../javascript/messageserver/index.htm'>MessageServer</a>","messageserver message server webapplication news visitor cross-browser cross browser","MessageServer is a webapplication powered by Javascript. It's cross-browser compatible, and squeezes more out of Javascript then ever seen before.")
add("<a href='../javascript/parameter/index.htm'>ParameterApi</a>","parameter api params url adress bar grabbing","This api was developed while I was working on XSearch. I needed to get the parameter values from the current url (parameters can be specified using the ? behind the url...look at search engines to see how they use it). This API will make it very easy to grab a certain value specified by the URL.")
add("<a href='../javascript/treeview99/index.htm'>Treeview 99</a>","treeview99 nodes dynamic html dhtml netscape 3 internet explorer","The Treeview uses DHTML and to make it cross-browser compatible the totally great dynlayer API from DanSteinman was used... visit his homepage for some great DHTML information, and scripts.")
add("<a href='../javascript/toolbar98/index.htm'>Toolbar 98</a>","toolbar98 toolbarinit","All programs have them, the Toolbar, now thanks to this little javascript API you can add this little gadget to your websites. The script is very simple to use so it should be useable by beginners and advanced webdesigners. Read the API Help for more information on how to use the Toolbar script, or click on the download link to grab your own copy of the script.")
add("<a href='../xsearch/index.htm'>XSearch</a>","xsearch javascript search engine cross-browser cross browser information faq howto help tutorial tools","Most other javascript search engines use frames or forms to make displaying their findings easier. XSearch uses the same tricks as real search engines: dynamic-page-creation.")
add("<a href='../knowledgebase/index.htm'>KnowledgeBase</a>","howto information knowledge database tutorials techtalks techtutors help what when how where why","The Just4Fun Productions/Developer knowledge base, with information, howto's, tutorials, techtalks and more information to help.")
add("<a href='../contact.htm'>Contact information</a>","contact information pascal@dynamic-core.net email adress how to","Contact pages")
add("<a href='../widgetx/index.htm'>WidgetX</a>","widgetx dhtml dynamic html widgets dynapi 3d vectorballs vector balls flex bounce layer tricks code javascript","WidgetX - DHTML widgets that are just fun to watch and play with")
add("<a href='../jsvcl/vcl2/index.htm'>JSVCL2</a>","jsvcl vcl2 components widgets button window popup menu window","VCL2 is the follow-up for JSVCL, the new library is created for the DynLayer2, with advanced features and more speed")

/* end database records */