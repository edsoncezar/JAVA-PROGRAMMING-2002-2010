******************
** AUTOEINSTIEN **
***** ReadMe *****
******************

Welcome to the ReadMe.txt file, for the simple, free javascript program, 
AutoEinstien v1.0 which was written by Paul Gardin.

*Discription: 
 AutoEinstein is a JavaScript program that lets users play 
 around with Einstien's famous E=mc2 equation by entering a mass 
 and seeing how much energy that amount of mass possess. The 
 script outputs a discription/explanation of the equation 
 along with the solution to the equation with the inputed value. 

 The script looks best in Microsoft Internet Explorer, however
 has been tested to work in Netscape Navigator and will likely 
 work in other browsers supporting javascript.

 The program download includes one HTML file which contains the
 JavaScript program. The file is named "AutoEinstien.html"


*Contact:
 This program was written by Paul Gardin. He can be contacted 
 through any of the following methods follows:
 
  E-mail: gardinp@lycos.com
  MSN Messenger: mrpaul02@hotmail.com
  ICQ: 148418084
  Yahoo Messenger: papaul22001

 Any questions on AutoEinstien can be asked through any of these methods,
 however, because of the relative simplicity of the program, chances are 
 there will be no questions.

**END**