// Arrays used in generating the shop

Product = new Array();
Description = new Array();
Price = new Array();
Picture = new Array();

// How many entries will be displayed per page

var perb=3;

// The recipient's email address

var receiver="webmaster@somewhere.com";

// Your currency

var currency="$";

// The Products

Product[0]="Product 1";
Description[0]="No description available at this moment";
Price[0]="100";
Picture[0]="images/geenprent.jpg";

Product[1]="Product 2";
Description[1]="No description available at this moment";
Price[1]="80";
Picture[1]="images/geenprent.jpg";

Product[2]="Product 3";
Description[2]="No description available at this moment";
Price[2]="60";
Picture[2]="images/geenprent.jpg";

Product[3]="Product 4";
Description[3]="No description available at this moment";
Price[3]="40";
Picture[3]="images/geenprent.jpg";

Product[4]="Product 5";
Description[4]="No description available at this moment";
Price[4]="20";
Picture[4]="images/geenprent.jpg";