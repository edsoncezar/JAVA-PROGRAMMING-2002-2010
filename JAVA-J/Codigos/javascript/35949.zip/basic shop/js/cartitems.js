// Menu items

function cartitems()

{

items=
'<table border="1" width="550" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF">'+
'<tr bordercolor="#000000" bgcolor="#C0C0C0" align="center">'+
'<td class="but1" onmouseover="this.className=\'but2\';" onmouseout="this.className=\'but1\';" onclick=location="index.htm" width="78">Home</td>'+
'<td bgcolor="#FFFFFF" bordercolor="#FFFFFF" width="78">&nbsp;</td>'+
'<td class="but1" onmouseover="this.className=\'but2\';" onmouseout="this.className=\'but1\';" onclick=location="cart.htm" width="78">Products</td>'+
'<td bgcolor="#FFFFFF" bordercolor="#FFFFFF" width="78">&nbsp;</td>'+
'<td class="but1" onmouseover="this.className=\'but2\';" onmouseout="this.className=\'but1\';" onclick=location="view.htm" width="78">View Cart</td>'+
'<td bgcolor="#FFFFFF" bordercolor="#FFFFFF" width="79">&nbsp;</td>'+
'<td class="but1" onmouseover="this.className=\'but2\';" onmouseout="this.className=\'but1\';" onclick=location="send.htm" width="79">Check Out</td>'+
'</tr></table>';

document.write(items);

}