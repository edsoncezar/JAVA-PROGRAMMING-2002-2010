// ActiveX Object

var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");

// Arrays used in generating the shop

Product = new Array();
Description = new Array();
Price = new Array();
Picture = new Array();

// How many entries will be displayed per page

var perb=3;

// The recipient's email address

var receiver="webmaster@somewhere.com";

// Your currency

var currency="$";

// Load XML File

function loadXML(xmlFile)

{

  xmlDoc.async="false";
  xmlDoc.load(xmlFile);
  xmlObj=xmlDoc.documentElement;

}

loadXML("xml/products.xml");

// Read XML nodes into an array

for (i=0;i<xmlObj.childNodes.length;i++)

{

Product[i]=xmlObj.childNodes[i].childNodes(0).firstChild.text;
Description[i]=xmlObj.childNodes[i].childNodes(1).firstChild.text;
Price[i]=xmlObj.childNodes[i].childNodes(2).firstChild.text;
Picture[i]=xmlObj.childNodes[i].childNodes(3).firstChild.text;

}