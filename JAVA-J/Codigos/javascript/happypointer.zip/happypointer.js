/* HappyPointer par E.D Prod 1998
   etiennedeb@ifrance.com
   http://javascript.lab.cc
*/
var isNS = (navigator.appName == "Netscape" && parseInt(navigator.appVersion) >= 4);
var div1 = (isNS) ? document.obj1 : document.all.obj1.style;
var div2 = (isNS) ? document.obj2 : document.all.obj2.style;
var div3 = (isNS) ? document.obj3 : document.all.obj3.style;
var div4 = (isNS) ? document.obj4 : document.all.obj4.style;
var div5 = (isNS) ? document.obj5 : document.all.obj5.style;
var objet;
var coord;
var coordb = 800;
objet = new Array(div1,div2,div3,div4,div5)
coord = new Array()
function placeObj(i,px,py) {
 objet[i].left=px;
 objet[i].top=py;
}
function voirObj(i) {
 objet[i].visibility="visible";
}
function cacheObj(i) {
 objet[i].visibility="hidden";
}
var userAgent=navigator.appName + " " + navigator.appVersion;
var agentInfo=userAgent.substring(0, 12);
var yBase = 0;
var xBase = 0;
var delay = 15;
var yAmpl = 10;
var yMax = 40;
var step = .1;
var ystep = .5;
var currStep = 0;
var tAmpl=1;
var Xpos = 50;var ox;
var Ypos = 50;var oy;
var j = 0;
if(agentInfo >= "Netscape 4.0") {
 document.captureEvents(Event.MOUSEMOVE);
 function mouveA(evnt) {
  Xpos = evnt.pageX;
  Ypos = evnt.pageY;
 }
 document.onMouseMove = mouveA;
}
else {
 function mouveB() {
  ofy=document.body.scrollTop;ofx=document.body.scrollLeft;
  Xpos = event.clientX+ofx;
  Ypos = event.clientY+ofy;
 }
 document.onmousemove = mouveB;
}
function animation() {
 yBase = 160;xBase = 160;
 var cx;var cy;
 for ( j = 0 ; j < 5 ; j++ ) {
  cx=Xpos + Math.sin((20*Math.sin(currStep/20))+j*70)*xBase*(Math.sin(10+currStep/(10+j))+0.2)*Math.cos((currStep + j*25)/10);
  cy=Ypos + Math.cos((20*Math.sin(currStep/(20+j)))+j*70)*yBase*(Math.sin(10+currStep/10)+0.2)*Math.cos((currStep + j*25)/10);
  placeObj(j,cx,cy);
 }
 currStep += step;
 setTimeout("animation()", 15);
}
animation();

