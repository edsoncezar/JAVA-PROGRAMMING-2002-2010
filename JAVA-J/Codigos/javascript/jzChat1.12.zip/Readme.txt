JzChat V1.x
Copyright JavaZOOM 1999-2001
http://www.javazoom.net

=======================================================
jzChat Support Page :
http://www.javazoom.net/jzservlets/jzchat10/jzchat.html

Forums :
http://www.javazoom.net/services/forums/index.jsp 
=======================================================

V1.12 :
-----
MAXNICKNAMELENGTH parameter added for Admin user.
Charset support improved through CHARSET parameter.
ADMINLOGINCOMMAND parameter added to improve security.
Bug fixes :
  - admin panel no more accessible through "todo=anything" URL parameter.
+ iPlanet support added.

V1.11 :
-----
Private Messages feature added.
"Clear blacklist" feature added to the Admin panel.
Bug fixes :
  - Nickname updated in Admin Panel.
  - No more blank lines (space) allowed.
+ webappcabaret.com support updated.

V1.10 :
-----
HOSTURL parameter removed to support NAT Firewall features.
Improvements on SessionManager.
Bug fixes :
  - Session problems under Tomcat 3.2.
+ Resin support added.

V1.09 :
-----
Buffered-frame mode added (to avoid flickering effect).
Look&Feel chat customization (fontname, fontsize and colors).
Servlet Administration tool added to Admin panel.
Bug Fixes.
  - Nickname updated in Admin Panel.
+ JavaWebServer support added.
+ Jrun support added.

V1.08 :
-----
New implementation of SessionManager.
Bug Fixes.
  - NotSerializable Exception under JWSDK and E.L.S.E.
  - Root cannot kick off itself.
+ Tomcat support added.
+ JServ support added.
+ Jwsdk support added.
+ Weblogic support added.


V1.071 :
------
jzChat.initArgs added for JServ servlet engine.


V1.07 :
-----
Bug Fixes.
MultiLanguage support added.
Framed & Non-Framed support added.
@ root identifier added.
+ mycgiserver.com support added.
+ webappcabaret.com support added.


V1.05 :
-----
100% HTML/JavaScript chatroom performed by a Java Servlet.
