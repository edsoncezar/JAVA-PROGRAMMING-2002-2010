COUNTRY GUESSING GAME
~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~update1



Table of contents
=================
1. About the game
2. Requirements
3. How to play?
4. What's Changed?
5. About us


1. About the game
-----------------
The goal of this game is to guess a country name. It contains 180 country names. This game is for your personal use only. Please do not use it commercially without our permission, but you are free to do any type of experiment with the source code. You can also use it in your web site.


2. Requirements
---------------
This game requires Microsoft Internet Explorer 5+, Netscape Navigator 6.0+, Mozilla 1.2+ or Opera 6+. If you have any of the browsers mentioned above but you turned off your browser's JavaScript supporting feature, you also couldn't play this game. We highly recommend you to use Internet Explorer 5+.


3. How to play?
---------------
The computer will randomly generate a country name and you have to guess it. You have got 5 tries to guess. You will get 3 hints one after another by clicking the Guess! button. Country names are not case sensitive, but be careful of your spelling. You should type some country name as decribed below...

south africa,
sri lanka,
new zealand,
saudi arabia

etc.

You must give appropriate blank space(s) while typing this kind of country names.


4. What's Changed?
------------------
a. The last hint doesn't stay after reloading the game in Netscape or Mozilla.
b. After finishing a game, the page awaits for user input.
c. A clear button added to clean the text box.
d. A new button added to start a new game.
e. Tool tips are added to the buttons and textbox.
f. New style sheet rules added.


5. About us
-----------
author@ShuvoRim
Web site : http://www.shuvorim.tk
Email : shuvorim@hotmail.com
�ShuvoRim Pvt. Ltd. 2002 - 03
All rights reserved.

Visit our web site for free applets, applications, scripts and games. Thank you for using our program.

