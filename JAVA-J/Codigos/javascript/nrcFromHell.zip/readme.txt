No-Right-Click From Hell
Copyright 2004 by www.FFFast.com

Setup:

1.
Insert the following script in the <head> section of the
page you wish to protect with the no-right-click feature.
Modify the path in PopUpURL as noted in the script.

<script language="JavaScript">
// Put this script in the head of your page
// Set the path to screamer.html on your server
// The full http:// path is recommended
PopUpURL = "http://yoursite.com/screamer.html";
// Do not edit below this line
//----------------------------
// Copyright 2004 by FFFast.com
isIE=document.all;isNN=!document.all&&document.getElementById;
isN4=document.layers;if (isIE||isNN){
document.oncontextmenu=checkV;}else{
document.captureEvents(Event.MOUSEDOWN || Event.MOUSEUP);
document.onmousedown=checkV;}
function checkV(e){if (isN4){if (e.which==2||e.which==3){
doFlyMe();return false;}}else{doFlyMe();return false;}}
var M=100;var speed=20;var increment=16;
var nowY=M;var nowX=M;var theWidth=window.screen.width;
var theHeight=window.screen.height;
var limitX=theWidth-100-M;var limitY=theHeight-100-M;
var s="width=100,height=100";
function doFlyMe(){P=window.open(PopUpURL,"q",s);  
P.moveTo(M,M);P.focus();D();}
function D(){if (nowY<=limitY){P.moveTo(nowX,nowY);P.focus();
nowY+=increment;T=setTimeout("D()",speed);}else{
clearTimeout(T);nowY=limitY;P.moveTo(nowX,nowY);P.focus();R();}}
function R(){if (nowX<=limitX){P.moveTo(nowX,nowY);
P.focus();nowX+=increment;T=setTimeout("R()",speed);
}else{clearTimeout(T);nowX=limitX;P.moveTo(nowX,nowY);P.focus();U();}}
function U(){if (nowY>=M){P.moveTo(nowX,nowY);P.focus();nowY-=increment;
T=setTimeout("U()",speed);}else{clearTimeout(T);nowY=M;
P.moveTo(nowX,nowY);P.focus();L();}}
function L(){if (nowX>=M){P.moveTo(nowX,nowY);P.focus();
nowX-=increment;T=setTimeout("L()",speed);}else{
clearTimeout(T);nowX=M;P.moveTo(nowX,nowY);P.focus();}}
</script>

2.
Open the screamer.html page with your editor and set the
path, as noted, to the screamer.wav sound file. Again,
the full http:// path is recommended.

3.
Send your page, screamer.html page, and the screamer.wav
file to your server.

Done!

Regards,

FFFast.com

