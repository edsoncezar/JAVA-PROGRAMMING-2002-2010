/* Titi par E.D Prod 1998
   http://javascript.lab.cc
*/
var isNS = (navigator.appName == "Netscape" && parseInt(navigator.appVersion) >= 4);
var div1 = (isNS) ? document.obj1 : document.all.obj1.style;
var div2 = (isNS) ? document.obj2 : document.all.obj2.style;
var objet;var coord;var coordb = 800;
objet = new Array(div1,div2);coord = new Array();
coord[0]=50;coord[1]=50;
function placeObj(i,px,py) {
 objet[i].left=px;
 objet[i].top=py;
}
function voirObj(i) {
 objet[i].visibility="visible";
}
function cacheObj(i) {
 objet[i].visibility="hidden";
}
var userAgent=navigator.appName + " " + navigator.appVersion;
var agentInfo=userAgent.substring(0, 12);
if(agentInfo >= "Netscape 4.0")
{
 document.captureEvents(Event.MOUSEMOVE);
 var Xpos = 50;var Ypos = 50;
 function MouveA(evnt) {
  Xpos = evnt.pageX;Ypos = evnt.pageY;
 }
 document.onMouseMove = MouveA;
}
else {
 var Xpos = 50;var Ypos = 50;
 function MouveB() {
  ofy=document.body.scrollTop;ofx=document.body.scrollLeft;
  Xpos = event.clientX+ofx;Ypos = event.clientY+ofy;
 }
 document.onmousemove = MouveB;
}

function vole() {
 x0=coord[0];y0=coord[1];ex=Xpos;ey=Ypos
 reelx=x0+0.04;reely=y0+0.04;
 rx=reelx;ry=reely;
 rx+=(ex-rx)*0.04;ry+=(ey-ry)*0.04;
 reelx=rx;reely=ry;
 x0=Math.round(reelx);y0=Math.round(reely);
 coord[0]=x0;coord[1]=y0;
 if (x0<=Xpos) {voirObj(0);cacheObj(1);}
 else {voirObj(1);cacheObj(0);}
 placeObj(0,x0-22,y0-37);placeObj(1,x0-22,y0-37);
 setTimeout("vole()", 15);
}
vole();
