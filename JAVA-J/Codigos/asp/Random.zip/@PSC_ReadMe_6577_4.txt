Title: RandomRecordSet
Description: Return a random ADO recordset using VB Script. I adapted this code from http://www.planetsourcecode.com/vb/scripts/showcode.asp?txtCodeId=6201&lngWId=4 and thought I should upload my solution. I would just post the code but the formating ends up being stripped and it looks just horrible. Updated 4/12/2001 I changed some of the code around when I was looking for what I thought was a bug but turns out the problem was elsewhere. The zip file also now includes a function called RecordSetToString. Updated 5/04/2001 I discovered a bug lead to infinite loops (and fixed it).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6577&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
