----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------



Learning JScript: Reading Files


summary:
===============

Learning JScript: Reading Files

Read files using the Scripting Run Time Library 
( Scripting.FileSystemObject ) and JScript. The 
point is simple, you probably already know how 
to use the FSO with VBScript... It is definitely 
one of the first things you learn. So when learning 
JScript, why not do the same? 

In this case we will use the FSO to read information 
about a file using one function and use two functions 
to model data. 

The output of the function is below: 




documentation:
===============
Please view the file_read.asp file for the complete exposed 
interface definition.



installation:
===============
1.) you will need the file_read.asp file


2.) place the required files from step 1 into any directory on the server.


3.) navigate to file_read.asp on your website with your web browser to test.


known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


