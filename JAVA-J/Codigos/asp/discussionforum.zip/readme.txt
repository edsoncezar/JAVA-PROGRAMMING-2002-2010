This is a basic ASP based discussion form, ready to run right out of the box.

To get it going, all you need to do is the following:

1.  In IIS or PWS, create a new virtual directory named DiscussionForum (or 
    whatever you want).

2.  Unzip all files and copy them into the physical subdirectory you used 
    for the virtual directory.

3.  Type http://[YourDomain]/DiscussionForum into your browser.


This uses an Access database and should not be too hard to migrate to another
database such as SQL Server.  It requires the Microsoft.Jet.OLEDB.4.0 provider, 
which, if you don't have already, you can get at http://www.microsoft.com/data.

If you are going to use this in production, you should put the database into a
different directory and modify the connection string in database.inc to point to
that new location.  Otherwise, internet users will be able to download the database
itself from your web site.  

Finally, if you are using this on Windows NT or 2000, be sure to grant write permissions for the Access database to the Internet Anonymous User.

