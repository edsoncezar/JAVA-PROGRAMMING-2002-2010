Title: Calendar Date Picker
Description: A calendar date picker which allow easy input for date in textbox.
Only works in IE4 & above. IE6 supported.
The current supported date format is mm/dd/yyyy.
Make sure the path for the file calendar.js and datev2.htm is set properly.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7135&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
