var ns=(navigator.appName=="Netscape")
if (ns) document.captureEvents(Event.KEYPRESS)
var nChars="0123456789"
var intChars=nChars
var dblChars=nChars + ",-"
var bitChars="01"
var docChars=nChars + "-/."
var telChars=nChars + "- ()"
var datChars=nChars + "/- "
var strChars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "

function vForm(fObj) {
	if (fObj) {
		for (iField=0;iField<fObj.length;iField++) {
			field=fObj[iField]
			if (field.name.indexOf("-")>-1) {
				if (!vField(field)) return false
			}
		}
	}
	return(true)
}

function getFName(field) {
	var FName=field.name
	if (field.name.indexOf(".")>-1) FName=FName.substr(field.name.indexOf("-")+1,FName.length-1)
	if (FName.indexOf("|")>-1) FName=FName.substr(FName.indexOf("|")+1,FName.length-1)
	return(FName)
}

function isRequired(field) {
	return(eval(field.name.substr(0,4)==".obr"))
}

function getFValue(field) {
	if (field.type=="select-one") return(field.options[field.selectedIndex].value)
	else return(field.value)
}

function getDType(field) {
	DType="unspecified"
	dotIndex=-1
	lastDotIndex=-1
	for (iSt=0;iSt<field.name.length;iSt++) {
		atStr=field.name.substr(iSt,1)
		if (atStr==".") {
			if (dotIndex==-1) {
				dotIndex=iSt
				lastDotIndex=iSt
			}
			else if (lastDotIndex==dotIndex) {
				lastDotIndex=iSt
				break
			}
		}
	}
	sliceIndex=field.name.indexOf("-")
	if (isRequired(field)) {
		if (dotIndex!=lastDotIndex) DType=field.name.substr(lastDotIndex+1,sliceIndex-lastDotIndex-1)
	}
	else DType=field.name.substr(1,sliceIndex-1)
	if (DType=="unspecified") alert(field.name + ":" + dotIndex + "x" + lastDotIndex)
	return(DType)
}

function vField(field) {
	fValue=getFValue(field)
	if (fValue!="") {
		if (getDType(field)=="eml") {
			if (!vMail(field.value)){
				field.focus()
				return false
			}
		}
		else if (getDType(field)=="dat") {
			if (!vDate(field.value)){
				field.focus()
				return false
			}
		}
		else if (getDType(field)!="str") {
			for (iValue=0;iValue<fValue.length;iValue++) {
				if (eval(getDType(field) + "Chars.indexOf('" + fValue.charAt(iValue) + "')==-1")) {
					alert('"' + fValue.charAt(iValue) + '" � um caractere inv�lido para o campo ' + getFName(field))
					field.focus()
					return false
				}
			}
		}
	}
	else if (isRequired(field)) {
		alert("O campo " + getFName(field) + " � obrigat�rio")
		field.focus()
		return false
	}
	return true
}

function fieldMask(field,e) {
	key=(ns) ? e.which : event.keyCode 
	fValue=String.fromCharCode(key)
	for (iValue=0;iValue<fValue.length;iValue++) {
		if (eval(getDType(field) + "Chars.indexOf('" + fValue.charAt(iValue) + "')==-1")) {
			field.focus()
			return false
		}
	}
	return true
}

function vMail(email) {
	if (email.indexOf("@")==-1) {
		alert("Email inv�lido")
		return false
	}
	return true
}

function vDate(date) {
	if (date.indexOf("/")==date.lastIndexOf("/")){ // se houver menos que duas barras caia fora
		alert("data inv�lida")
		return(false)
	}
	day=date.substr(0,date.indexOf("/"))
	month=date.substr(date.indexOf("/")+1,date.lastIndexOf("/")-date.indexOf("/")-1)
	year=date.substr(date.lastIndexOf("/")+1,date.length-date.lastIndexOf("/")-1)
	if (isNaN(day) || isNaN(month) || isNaN(year)) {
		alert("data inv�lida. formato aceito: dd/mm/aaaa")
		return(false)
	}
	if (day<1 || day>31 || month<1 || month>12 || year<1800 || year>2200) {
		alert("data inv�lida")
		return(false)
	}
	return(true)
}