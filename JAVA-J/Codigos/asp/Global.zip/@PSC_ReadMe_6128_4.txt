Title: Count How Many Visitors Are On Your Website
Description: This short code keeps track of the number of people currently on your site - just like Dev-Center. 
Put this in a file called global.asa and upload it to the root web.
[http://www.yourdomain.com/global.asa]
Use the following in an ASP page to display the number of visitors:
<%= Application("NumOfVisitors") %>
or
<% Response.Write Application("NumOfVisitors") %>
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6128&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
