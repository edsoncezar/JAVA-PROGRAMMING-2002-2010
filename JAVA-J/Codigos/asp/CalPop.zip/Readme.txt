EZ-Web CalPop Installation Instructions

EZ-Web CalPop is a script that requires a bit of knowledge about ASP and Javascript in order to use it on your web site. To install and use EZ-Web CalPop follow the following instructions. If you need any help using this script please first refer to the example page that is included in the zip file.  If you still need additional help please email me at dirt@dandybitcandy.com.  Good luck.  And, I hope you enjoy using EZ-Web CalPop.

1) Download CalPop.zip from my web site and save it your hard drive.

2) Unzip CalPop.zip with a program that can decompress ZIP files, such as WinZip.  Make sure you extract your files in a directory under C:/inetpub/wwwroot/ so that the script will work properly.  A good name for the directory is Calendar.

3) On the page that you want to use EZ-Web CalPop you need to create a link (preferably a small icon) that will use javascript to open up CalPop in this manner:

<a href="javascript:CalPop('<name of the input field that needs a date/time to be entered>');"></a>

An Example of this:

<a href="javascript:CalPop('document.Form1.fldDate');"><img SRC="icon_Cal.gif" border="0"></a>		

4) Then, add the folowing javascript on the same page:

<script language="javascript">
function CalPop(sInputName)
{
	window.open('Calendar.asp?N=' + escape(sInputName) + '&DT=' + escape(window.eval(sInputName).value), 'CalPop', 'toolbar=0,width=378,height=225');
}
</script>

You may have to modify this javascript if you have placed Calendar.asp in a different directory then the page that uses EZ-Web CalPop.  For instance, if you installed EZ-Web CalPop in a directory called Calendar you would have to modify the the javascript like this,

window.open('/Calendar/Calendar.asp?N=' + escape(sInputName) + '&DT=' + escape(window.eval(sInputName).value), 'CalPop', 'toolbar=0,width=378,height=225');

You may also need to modify the width and height properties.

That's it!

Thanks for using my scripts.

- Dustin Christopherson (dirt@dandybitcandy.com)


