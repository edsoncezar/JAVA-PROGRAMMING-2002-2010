Title: Force a Save File Dialog
Description: This piece of code FORCES the user to save known file types (ie: *.mpg, *.gif, *.jpg, *.htm... you get the idea). Normally these (known file types) are opened in the browser, if you wish to bypass this feature in the browsers and allow the user to save a copy to their local computer without telling them to "right click" on the file and select "save target", this is the way.
This code is REAL SIMPLE. I commented EVERY line so you know exacly what purpose it serves.
If you have any enhancements to make to it, please let me know I'd love to see them.
Please vote good or bad, 'cause I'd like to know.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6250&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
