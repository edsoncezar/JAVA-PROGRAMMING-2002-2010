---==<< ASP BoardX >>==--
by Mainstream Design
http://www.mainstreamdesign.com
boardx@mainstreamdesign.com

Version 1.0 Beta 1
Sunday, March 25th, 2001

ASP BoardX is a simple, single threaded message
board system that is designed to allow your
visitors to interact with each other in a quick
and efficient manner.

Contents of this documentation:
   1 - Getting Started
   2 - Troubleshooting & Support
   3 - Customizing ASP BoardX
   4 - Version History
   5 - Bug Reports


1) ===== Getting Started =====

   The first and only step required to get
   ASP BoardX up and running is to modify
   the 'config.inc' file. This file allows
   you to change the location of the database
   and make some changes to the appearance of
   the board as well.

   Keep in mind that the database file, 'boardx.mdb',
   must be in a directory to which you have both read
   and write permissions.

   ASP BoardX has been tested with:
   -IIS 4, 5

2) ===== Troubleshooting & Support =====

   To be added in a future release. Email us at
   boardx@mainstreamdesign if you have any problems.

3) ===== Customizing ASP BoardX =====

   Most customization is done through the 'config.inc'
   file, however, the board can be customized further
   by editing 'style.inc' or any other source files.

   To edit or delete messages, open 'admin.asp' in your
   browser. NOTE: Edit the source of 'admin.asp' to modify
   the admin username/password. Defaults are:

   username: aspboardx
   password: aspboardx

   IMPORTANT: Deleting a parent topic will cause any child topics
   to be deleted as well.

   More to be added in a future release.

4) ===== Version History =====

   ( 1.0 Beta 1 ) - First public release.

   Features to be added in a future release:
     -multiple areas or forums
     -more visual customization
     -etc.

   Let me know if you have any ideas!

5) ===== Bug Reports =====

   Though we make every attempt possible to ensure
   there are no bugs in ASP BoardX, it's always a
   possibility that some may still appear.

   This being a Beta version, we welcome any bug
   reports as it will ensure the final version is
   as stable as possible.

   Please send reports of any bugs, being as detailed
   as possible, to boardx@mainstreamdesign.com. Thanks.