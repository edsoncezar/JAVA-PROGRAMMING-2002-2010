
Read Me File- ASP Cookie Baker-
------------------------------------------------
http://Designbliss.com.au/asp
Info@designbliss.com.au

What is it
---------------------------------
I've made is easy Asp cookie maker to advoid constantly having to write 
up script off my own. Just type the name your cookie (eg name) and 
how long you want the cookie to last and thats it. The script makes 
the cookie storing , retreaving asp and even makes the HTML code 
for the form!!! I'm too nice...

History--
----------------
Version 1.1stuffups in the zip- file problems missing a " in the code etc---- Sorry


What can I do with it
-------------------------------
You can - change it
	  play with it
	  us it 
  	  give it away

You cant - Sell it 
  	   Charge for using it.
       Remove the copyright link. (Email me if you do want to)

Installing Information
----------------------------------
Easy, just un-zip the file and up-load to a directory of your choice- Should work straight out of the box-


Files included
--------------------------------
Default.asp ~ Baking Script page- only file
Thats it

Hows its done
-------------------------------
The form takes the takes the info reloads on the same page, asp picks it up then I reform it using hidden fields that hold the template information in-between  the <TEXTAREA> HTML tags. Lots of work arounds. Not bad for a person learning asp for 3 weeks!!

Comming Soon
--------------------------
Advanced Cookie Builder (including Page templates) 
Resume Builder (in the future some time now!)


Have Fun

Adam Ware

http://Designbliss.com.au/asp
Info@designbliss.com.au