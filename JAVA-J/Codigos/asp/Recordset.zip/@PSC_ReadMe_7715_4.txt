Title: Recordset paging
Description: Paging 19 July 2002
Description
A single page search form that when refreshed, displays a paged recordset. 
Permits Search by letter, name or menu option.
Requirements:
ASP, HTML, Javascript, Access
Create appropriate stored procedures or embedded queries and link to an Access db.
Licence
Free
Requests
If you use the code please fill out one of my medical survey forms at http://www.allourhealth.com
Your improvements would be appreciated.
A working example can be seen at:
http://www.allourhealth.com

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7715&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
