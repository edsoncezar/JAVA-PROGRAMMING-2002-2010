NewsPro V1.01

Simply upload all files into a directory called \news\
Run login.asp
Enter demo & demo for username and password.
Then test things out (it's easy to use once you get the hang of it!!)

Updates

Version 1.02

Instead of creating an ASP page news pro now generates a static html page for each news story, the new header and footer can cow be configured from with in the admin area. A new table must be created in the database to make this work. The tables is called config and there must be two rows called html_head and html_foot insert in to that some basic HTML you can change it later at any time.

version 1.01

This version now creates an ASP for each news story, it uses SSI so you can configure the header and footer.

Version 1.00

A few bugs fixed from the Beta version

Version 1.00 beta

Original beta version released



Script updates in April 2001
own.asp string bugs fixed



PLEASE KEEP A LINK TO WWW.ASPBIN.CO.UK WITHIN EVERYPAGE OF THE SCRIT WHICH IS VIEWABLE BY THE PUBLIC.
SUPPORT CAN BE OBTAINED FROM WWW.ASPBIN.CO.UK
TO REMOVE LINKS FROM THIS SCRIPT PLEASE VISIT WWW.ASPBIN.CO.UK/BUY.ASP
