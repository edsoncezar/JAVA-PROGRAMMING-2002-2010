
/****** Object:  Table [dbo].[productCatalog]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[productCatalog]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[productCatalog]
GO

/****** Object:  Table [dbo].[productCatalog]    Script Date: 6/11/2001 5:42:21 AM ******/
CREATE TABLE [dbo].[productCatalog] (
	[adminID] [int] IDENTITY (1, 1) NOT NULL ,
	[itemDesc] [text] NULL ,
	[itemMisc] [varchar] (255) NULL ,
	[itemPicture] [varchar] (255) NULL ,
	[categoryFull] [varchar] (255) NOT NULL ,
	[subCategory] [varchar] (255) NOT NULL ,
	[itemName] [varchar] (255) NOT NULL ,
	[itemPrice] [money] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[productCatalog] WITH NOCHECK ADD 
	CONSTRAINT [PK_productCatalog] PRIMARY KEY  NONCLUSTERED 
	(
		[adminID]
	)  ON [PRIMARY] 
GO