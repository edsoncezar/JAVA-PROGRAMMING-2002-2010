Title: Online photo catalogue VBScript 2.1
Description: This is a simple ASP/VBScript script (8Kb) that allows you to publish your pictures in the Internet. 
You only need to upload your pics and tell the script the folder where the pictures are. It uses the filesystem object to create a dynamic HTML catalog with the pictures found in the folder(s). It works with in a recursive way. 
You can also associate comments to each picture creating a text file with the same name as the picture and the extension .txt, and the script will look for that file and write the content of that file in the screen.
With the new release (2.1), the visitors can also add comments. The comments are stored in XML format in the folder you specify.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7953&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
