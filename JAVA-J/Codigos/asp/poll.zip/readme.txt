ASP Polls
version 1.0
Tipped Cow Development and Adrenalin Labs
http://www.tippedcow.com/ & http://dstoflet.calweb.com/

=====================
WARNING: There is no support for ANY Free Application downloaded from Tipped Cow Development/
Adrenalin Labs or affiliates. We can not take the time to support users with a free app when
we are too busy with other paid work. Sorry, but when its free, whatelse do you want?
=====================

Simple Instructions for Install:

1) Upload the poll directory to your web server, including all the files!

2) If you have access to the servers Management Console, then continue to #3, if not move
to #4.

3) Open Management Console and right click the newly created poll directory and select properties. Click on "Create Application" and give this directory execute permissions. This will allow the global.asa to execute on the server and there is no DSN required. OR you can make /poll/ a virtual directory and this will create the same effect. either way, the choice is yours.

4) Since you do not have access to the Management Console, then do this:
add this line of code to the default.asp page

	<!--#include file="db.inc"-->

This will allow to use a dsn-less connection as well without using the console. 

5) everything should be working now. If not, I'm sorry but that's the way it goes. 

DO NOT EMAIL anyone but support@tippedcow.tzo.com. If you get a reply consider yourself very lucky and be grateful. If you don't get one, it means we're way too busy and can't reply. Maybe we'll reply sooner than later.

If you email anyone but support@tippedcow.tzo.com about a support issue, you will be ignored. 

With all that said, we hope you enjoy the polls. If you feel darning, you may want to try adding an include to poll.inc on your main site page.

<!--#include virtual="/poll/poll.inc"-->

This would give you a poll right on your front page! how cool! you'll need to fix the colors yourself, those we're custom for us.

Good luck!
   