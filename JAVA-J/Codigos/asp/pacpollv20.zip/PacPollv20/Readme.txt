PacPoll V 2.0.2 is simple to use. 

Version 2.0.2 now has 2 databases. Depending on what version of Access you use, you now have a choice. If you use Access 2000 then rename the database poll200.mdb to poll.mdb. If you use an earlier version then rename pollPRE2k.mdb to poll.mdb.

PacPoll does require the server to be using at least version 5 of the scripting engine. Nearly all host are now using at least 5.1, so this should not be a problem.

First at the top of the page you want to use the poll on you must place this line:
<%Response.Buffer=True%>

Second, drop the PacPollv20 directory in the root of your web. On the page you want to have the poll, place this line where the poll should go:
<!-- #include virtual="PacPollv20/poll.asp" -->

Make sure the server has write permisions to the database and thats it for the installation.

Now to change the poll, open a browser to http://www.yoursite.com/PacPollv20/admin/index.asp
Then simply fill out the form. You can change the question and the four responses. You can have 2 3 or 4 responses if you only want two then just leave 3 and 4 blank. There are 9 fonts to choose from and you can set the color of the font as well as the size. You can also set the color of the bar graph and poll background as well.

One last thing. PacPoll sets a cookie so that a visitor can only answer the poll once. When you change the poll it changes the cookie info as well so that when the new poll is set returning visitors will be able to answer the new poll.

Thats it you're done.

Limited setup support is available by emailing help@pacosdrivers.com

DONT FORGET TO READ THE EULA......... (it's not that bad)
