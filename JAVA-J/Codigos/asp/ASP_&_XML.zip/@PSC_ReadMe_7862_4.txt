Title: ASP & XML flickering free Banshee Chat
Description: Banshee Chat is an experimental ASP and XML chat. It is flickering free. It allows unlimited users.
Use XMLDOM to retrive on server the xml file.
The version is 1.1 on next release i implement:
private messages, online user visualization, and multiple room chat with improved graphical frontend.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7862&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
