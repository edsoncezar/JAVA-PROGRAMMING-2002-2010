PM Poll

Latest Version:	1.2 
Author:		PascaL Michaud 
License:	Freeware 
Copyright:	2001 PascaL Michaud
Language:	ASP
Homepage:	http://www.instagib.com/pm/pmPoll/
Support:	eog@home.com

Requirements:

- Basic knowledge of ASP. 
- Web server with ASP support. 

Installation

1. Unzip the "pmPoll.asp" file into the directory of your preference above your web root. Example: "e:/www/" or "e:/www/pmPoll/"

2. Place the database file "pmPoll.mdb" anywhere on your webserver. If security is a concern, place this file in a directory inaccessible to the web, or set it as a "hidden" file in a web-directory.

3. Edit the required variable(s) in pmPoll.asp.

4. Include the file as a regular Server Side Include in any ASP page (see the online FAQ for information on Server Side Include statements) or, simply launch "pmPoll.asp" directly from any web browser. 
  
