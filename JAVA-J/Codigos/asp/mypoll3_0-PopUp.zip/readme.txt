mypoll version 3 - Elad Rosenberg 4/2000
-----------------------------------------
Extract all files to some directory in the server and
open index.asp.
you can switch betwean "forbidden double vote" and "allow double vote"
by switching true or false in poll.asp line 43.
This version includes archive option.
just type the old results to the db.
If you can't open the access file go to our home page and open the "tables design"
link.
You will find the application tables design and then you can build new database.
when you insert new quetions and answers you have to insert new quetion in
the que. table.
then, enter answers in and table.
you MUST enter the quetion id number in the queID field in ans table!
Enjoy!
eladr@tip.co.il

