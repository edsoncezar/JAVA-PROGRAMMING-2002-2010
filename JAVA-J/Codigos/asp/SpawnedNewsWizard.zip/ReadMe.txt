Copyright (c) 2001, Spawned.co.uk & Lee Wilson.
http://www.spawned.co.uk, All rights reserved.
hyperwhore@spawned.co.uk

Spawned.co.uk | Scripted and Documented by Lee Wilson
Mailing List Sign-up and Mailing List Manager | V1.1

A - DISCLAIMER
B - WHAT IS...?
C - REQUIREMENTS
D - INSTALLATION
E - THANK YOU

A. DISCLAIMER

This is freeware - Use at your own risk. No warranties provided.  Redistribution 
of this program, in whole or in part, is strictly prohibited without the expressed 
written consent of the author. Custom programming available on hourly fee basis.

B. WHAT IS SPAWNED NEWS WIZARD?

Spawned Mailer is a full mailing list script allowing your visitors to sign up to
your newsletter. As well as having this feature, you can send an email to all your
users, archive emails, add admins with user permissions, and edit your mailing list.
The script comes with the usual template, but this time you have a config section
which enables you to chnage colours of certain features, such as body background
colour, and link colour.

C. REQUIREMENTS

If your site is hosted on a Windows NT server with IIS 4.0 or higher and ASP 2.0 or 
higher you should be fine using this script. If you are not sure whether your box will 
run this script, run it anyway or contact your administrator.

D. INSTALLATION

Spawned News Wizard is most probably my best script to date, containing dynamic code
and sleak presentation. Installation is as easy as ever, and can be completed
following these steps:

1. Open SpawnedHead.asp with your favourite text editor.

2. On lines 33 and 34, change 'Admin' and 'Test' for a username and password of your
choice. Example:

Line 33: strUserName = "FunkySpunk"
Line 34: strPassword = "Test123"


3. Save the file.

4. Upload the contents of SpawnedNewsWizard to your main web directory. New folders
should be created appropriately.

5. Either:
	
	a) Provide a link on your web site to news_display.asp using the following
	code:
	
		<a href="news_display.asp">My news!</a>

	ii) Copy the code from news_display.txt somewhere to your site. Note that the
	page copied to will need to have the .asp extension.


- To log in to the Admin Section, open Admin.asp in your web browser.

- To view current news: news_display.asp


E. THANK YOU

Firstly, thank you for using my script!

I have Mark Stringer to thank for being on hand with his little code snippets. Mark's
site can be found at http://www.markstringer.co.uk.

~ Lee Wilson
