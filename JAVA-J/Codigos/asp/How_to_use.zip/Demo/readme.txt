										How to use "InternetExplorer.Application"

Requirements:
		- IE 5.0 - 6.0;
		- Windows Script Host 5.6 for HTA version;

Maxim Kazitov
Home page : http://mvkazit.port5.com/demo/
e-mail    : mvkazit@tut.by	