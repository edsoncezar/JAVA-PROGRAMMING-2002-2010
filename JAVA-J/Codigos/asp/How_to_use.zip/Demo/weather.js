var IE        = new ActiveXObject("InternetExplorer.Application");
var HOME_PAGE = "http://www.weather.com/";

// Define how the window should look
IE.left    = 0;
IE.top     = 0;
IE.height  = 720;
IE.width   = 1000;
IE.menubar = 0;
IE.toolbar = 0;
IE.visible = 1;

function dbgPrint(msg) {
	WScript.Echo(msg);
}

function loadPage(page) {
	dbgPrint("load page : "+page);	
	IE.navigate(page);
	waitPage();
}

function waitPage() {
	dbgPrint("wait...")	
	while(IE.Busy) { 
		WScript.Sleep(500);
	}  
	WScript.Sleep(500);
}

function findElement(doc, tag, attr, value) {
	var items = doc.body.getElementsByTagName(tag);
	for(var i=0; i<items.length; i++) {
		try {
			if(items[i].getAttribute(attr) == value) {
				return items[i];
			}
		} catch (e) {}
	}
	return null;
} 

loadPage(HOME_PAGE);

IE.document.body.all['where'].value = "08536";
WScript.Sleep(500);
IE.document.body.all['whatprefs'].selectedIndex = 2;
WScript.Sleep(500);
findElement(IE.document, "input", "VALUE", "Go").click();
waitPage();

dbgPrint("Scroll page down");
for(var i=0; i<10; i++) {
	IE.document.body.doScroll("scrollbarDown");
	WScript.Sleep(50);
}

dbgPrint("Resize window");
for(var i=0; i<20; i++) {
	IE.width-=5;
	IE.height-=5;
	WScript.Sleep(100);
}

IE.document.body.focus();
dbgPrint("Move window");
for(var i=0; i<20; i++) {
	IE.top+=5;
	IE.left+=5;
	WScript.Sleep(100);
}

dbgPrint("Scroll page up");
for(var i=0; i<20; i++) {
	IE.document.body.doScroll("scrollbarUp");
	WScript.Sleep(25);
}
WScript.Sleep(500);
dbgPrint("Change input value");
IE.document.body.all['where'].value = "08540";
WScript.Sleep(1000);
findElement(IE.document, "input", "VALUE", "Go").click();
waitPage();

WScript.Sleep(2000);

dbgPrint("Quit");
IE.Quit();