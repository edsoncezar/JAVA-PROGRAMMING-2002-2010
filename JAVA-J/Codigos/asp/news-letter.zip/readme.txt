Installation:

	- Copy all of the .asp and .inc files to your web directory
	- Move the "newsletter.mdb" to your web server's database directory
	- Open each of the .asp and .inc files with notepad and modify each 
		section directly below the word "MODIFY". There may be 
		several "MODIFY" sections in each file.
	- Modify the subscribe.asp and unsubscribe.asp files to match the 
		look of your site.

Usage:
	- Users will submit their email addresses on the subscribe.asp page,
		and unsubscribe on the unsubscribe.asp page.
	- You can send emails to all newsletter recipients from the 
		send.asp page.