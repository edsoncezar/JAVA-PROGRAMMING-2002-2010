Title: SpeakIt! Reads and Speaks Any Web Page
Description: SpeakIt! will read and Speak Any Page in your browser or any portion you highlight using Microsoft Agent Technology. Not only will SpeakIt! do this but it also allows you to create Microsoft Agent Presentations in your Web Pages as COMMENTS without ANY JavaScript,VBScript, NADA!, Yet it is written in both JavaScript and VBScript. You can also see more info about SpeakIt! at http://www.trav-tech.com/SpeakIt.html
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6248&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
