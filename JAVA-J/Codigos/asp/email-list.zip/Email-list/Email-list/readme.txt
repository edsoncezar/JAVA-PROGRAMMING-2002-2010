Action Mailer- TheASPsite.org,

A simple and advanced mailing list for everyone.

Instuctions -------
1. Un-zip to a directory on your site (eg- /mailer),
2. Open the file config.asp within the admin folder.
3. Edit details in that file. 

Script in Use -----------
You can go to your admin area in the folder /admin , using the password you made up in the config.asp folder. 

Once there you can add emails and remove emails as well, and you can also send the mailing list there.

You can add html code to your pages on your site using the HTML generator at /admin/view_html.asp or use the link on the main admin page.

Thats it ...

TheASPsite.org