Title: HTML Email
Description: I've looked long and hard trying to find a method to do a mass email using graphics...but to no avail...so, I wrote this simple program to send HTML email...just attach to a data source, and you're on your way...(by the way, you won't believe how easy this is!) Let me know what you think???
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7387&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
