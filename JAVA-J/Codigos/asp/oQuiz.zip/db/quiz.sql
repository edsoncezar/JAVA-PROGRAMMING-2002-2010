/****** Object:  Table [dbo].[QuizResults]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[QuizResults]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[QuizResults]
GO

/****** Object:  Table [dbo].[QuizResults]    Script Date: 6/11/2001 5:42:24 AM ******/
CREATE TABLE [dbo].[QuizResults] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Percent_Correct] [int] NOT NULL ,
	[Test_Date] [datetime] NOT NULL ,
	[IP_address] [varchar] (255) NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[QuizResults] WITH NOCHECK ADD 
	CONSTRAINT [DF__QuizResul__Perce__1FCDBCEB] DEFAULT (0) FOR [Percent_Correct],
	CONSTRAINT [DF__QuizResul__Test___20C1E124] DEFAULT (getdate()) FOR [Test_Date],
	CONSTRAINT [PK_QuizResults] PRIMARY KEY  NONCLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO