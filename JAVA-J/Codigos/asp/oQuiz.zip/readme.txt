----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

Quiz Object v1.0



summary:
===============
Provides a system to allow users to take various types of quizzes 
for a grade.



documentation:
===============
This file is considered to be the documentation for this example
as well as any notes in the source code of the asp files included
in the download package. Any other documentation will be in the
.\docs folder within the download package.

The download package for Quiz is as follows:

\readme.txt
	this file.

\asp\cls_quiz.asp
	the vbscript class definition for the Quiz Object

\asp\index.asp
	index page for both quizzes

\asp\quiz1.asp
	take quiz page for quiz #1

\asp\quiz1_results.asp
	results processor for quiz #1

\asp\quiz2.asp
	take quiz page for quiz #2

\asp\quiz2_results.asp
	results processor for quiz #2

\db\quiz.sql
	sql server scripts

\db\mydata.mdb
	ms access 2000 test database.

\docs\cls_quiz_DOCS.txt
	documentation and programmer's reference for the Quiz Object

\images\green.gif
\images\red.gif
	these are used in the results pages for the cheesy graphs.

\quizzes\quiz1.txt
	quiz #1 true/false quiz template.	

\quizzes\quiz2.txt
	quiz #2 multiple choice quiz template.


installation:
===============
1.) Before deciding how to install the quiz system, you must determine
    how you will be using the system. 

    NO DATABASE INTERACTION
    -----------------------
    If you plan to NOT be using the options that allow you to record 
    quiz results into a database, you will only need these files 
    from the download package:
	- the .\asp directory.
	- the .\quizzes directory.

    WITH DATABASE INTERACTION
    -----------------------
    If you choose to save the quiz results into the database, you will
    have to determine the type of database you will be using to record
    results:

        MS ACCESS 2000
        -------------------
		- the .\asp directory.
		- the .\quizzes directory.
		- the .\db directory (mydata.mdb only)

        SQL SERVER 6,7,2000
        -------------------
		- the .\asp directory.
		- the .\quizzes directory.
		- the .\db directory (quiz.sql only)


2.) place the required files from step 1 into the root directory 
    on the server. If you are using SQL Server, run the quiz.sql
    script first to create the necessary database objects.


3.) navigate to the ./asp/ directory on your website with your web browser 
    to test.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


