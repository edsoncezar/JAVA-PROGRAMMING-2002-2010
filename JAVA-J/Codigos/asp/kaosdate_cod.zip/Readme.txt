-------------------------------------
 Custom dates v1.0 - date formatting
-------------------------------------

-[ About ]---------------------------

This function was developed for use in Kaos news. It is based around the functionality of the PHP date() function - when I first learned PHP I read about date() and wanted one for use in my ASP scripts.

It returns date and time information in a format based upon arguments it is fed. Essentially, it takes one date string/object and transforms it to a different format.

The ASP FormatDateTime function is extremely limited. This provides an alternative which gives you far greater control over how the date is returned.


-[ Using Custom dates ]--------------

1. Include the function in your page.

      <!--#include file="kaos_date.asp"-->

   Of course, this will need to be altered to suit if the 2 pages (your code and kaos_date.asp) are in seperate folders.


2. Use the function just as you would any native function.

   Syntax      kaos_date(structure, date)

               structure is a string, containing the formatting parameters.
	       Any characters included in the string, that are not parameters will be included in the output.
	       These can be found in the included kaos_date_key.txt file.

	       date is a valid date expression.


   Note        date will be returned if date is not a valid date expression.
               date will be returned if structure does not appear to contain a formatting parameter.


   Example     MsgBox kaos_date("%E, %d%s %N, %Y - %g:%t%a", Now)

               On November 12, 2001 11:23:42 the MsgBox will display Tuesday, 12th November, 2001 - 11:23am


-[ Other stuff ]--------------------

I made this!  http://www.webkaos.co.uk  |  chrisb@webkaos.co.uk
It has taken me time to code, and is free to use for everyone.. so please don't steal it
or try to make money from it or anything like that. ta :)

If you use the script on your website, I would appreciate an email informing me of the URL for it.
It would be nice who is using it.

E n j o y.