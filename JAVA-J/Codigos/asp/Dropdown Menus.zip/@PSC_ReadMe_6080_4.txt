Title: State and Country Dropdown Menus
Description: Never hand-code state and country dropdowns again! Use this simple sub in your scripts that require these dropdowns, add the call to the sub, upload two text files and you're done. This is saved me a *lot* of time and effort...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6080&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
