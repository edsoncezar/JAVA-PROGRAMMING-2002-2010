Title: Web messaging System
Description: This is a client server application in which client is an ASP site and the server is a VB component that uses Winsock control, the users can send messages to the server via client side ASP code.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6802&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
