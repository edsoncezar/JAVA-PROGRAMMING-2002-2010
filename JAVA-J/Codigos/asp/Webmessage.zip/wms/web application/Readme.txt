Create a new virtual directory in IIS and point it towards the folder than contains the Sendmsg.asp file. Dont forget to run the WMS server before running the site.

S.S.Ahmed

ss_ahmed1@hotmail.com
http://glowbutton.faithweb.com/downloads.htm