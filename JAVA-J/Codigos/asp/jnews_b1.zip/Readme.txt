J News Version Beta 1 Release date 2K/09/29 
-------------------------------------------------------------------------------------------- 
This is freeware, but a link that points to : http://www.jonas.pp.se is always 
a good thing. I am curently runing this with Chili asp so I don't know how this is 
behaving on an NT box ore a W2K box. So pleas seend me mail if you get it up and runing.  

Setup : 
-------------------------------------------------------------------------------------------- 
1. You need to put news.mdb in a directory where it can be read/written to, I 
would recommend the directory where you put you're databases :) 

2. Change the path in db.asp to suite you're server mine is ex: 
Server.MapPath("news.mdb") in the same directory when I drive it on my computer at home. 

3. Change the password in : default.asp And : chkusr.asp

4. I would recommend you also run : keygen_make.asp to make a 
new string for encryption. "Don't upload (keygen_make.asp)" 

5. Customize the look of you're news page by changing news.asp 

PS :
 -------------------------------------------------------------------------------------------- 
Some of comment's are in Swedish so if you don't understand something mail me :) 
/Jonas Happy programing :) 

Buggreports : bugg@jonas.pp.se 

Known Buggs :
---------------------------------------------------------------------------------------------
I Havn't fixed the edit bugg ;)