DUresources.com 
10/08/2001

*********************************************************
Instruction on how to install DUdirectory
**********************************************************

1. Open the folder called Connections
2. Open the ASP file named connDUdirectory.asp
3. Here's the codes in that file:

  <%
' FileName="Connection_ado_conn_string.htm"
' Type="ADO"
' HTTP="false"
' Catalog=""
' Schema=""
MM_connDUdirectory_STRING = "Driver={Microsoft Access Driver (*.mdb)};DBQ=D:\Websites\DUdirectory\database\DUdirectory.mdb"
%>


4. Change the path to where you place the folder of this application. For example,
I unzip DUdirectory.zip into my drive C: in a directory like this:

  c:\Inetpub\wwwroot\mySiteName\DUdirectory

then the codes in connDUdirectory.asp need to be changed to:

 <%
' FileName="Connection_ado_conn_string.htm"
' Type="ADO"
' HTTP="false"
' Catalog=""
' Schema=""
MM_connDUdirectory_STRING = "Driver={Microsoft Access Driver (*.mdb)};DBQ=c:\Inetpub\wwwroot\mySiteName\DUdirectory\database\DUdirectory.mdb"
%>

*****************************************************************

Good luck. 
Please come back to visit www.duresources.com sometimes to check out other new free applications. Also, please come back to where you found us and rate for this application.

Quy To
DUresources.com