########################################
# FotoAlbum 1.0
#
# (c) 2001 WoschNet, Osterhofen
# www.woschnet.com
# Stand: 20.09.2001
########################################

Dies ist ein einfaches Script um ein dynamisches
Fotoalbum zu realisieren.
Es wird keine Datenbank ben�tigt und besteht aus
nur einer Script Datei (album.asp).

--------------------------
1. Vorraussetzungen
--------------------------
~ Windows NT/ Windows 2000 Server mit Unterst�tzung
  von Active Server Pages (ASP)
~ Berechtigung zum Ausf�hren von ASP-Scripts

--------------------------
2. Installation
--------------------------
Erstellen Sie einen neuen Ordner f�r Ihr Fotoalbum.
Bsp.: http://ihrserver.com/fotoalbum/

Kopieren Sie in diesen Ordner die Datei album.asp.

Nehmen Sie in der Datei album.asp im Bereich "Variablen
definieren" die Einstellungen f�r Ihr Fotoalbum vor.

Laden Sie album.asp jetzt auf den Server.

Ihr Fotoalbum ist nun einsatzbereit und kann �ber den Link
http://ihrserver.com/fotoalbum/album.asp aufgerufen werden.

--------------------------
3. Funktionsweise
--------------------------
Um Fotos dynamisch in Ihrem Fotoalbum anzeigen zu
k�nnen m�ssen Sie diese lediglich in den erstellten
Ordner (http://ihrserver.com/fotoalbum/) laden.

Es k�nnen .gif, .jpg und .png Fotos verwendet werden.

Sie k�nnen die Fotos auch in Unterordner (Subfolders)
speichern. Die daf�r notwendigen Links werden
automatisch erstellt, Sie m�ssen also keine Ver�nderungen
an album.asp vornehmen, wenn Sie einen neuen Ordner
erstellt haben.

Bitte beachten Sie folgende Regeln f�r die Benennung der Ordner:
~ verwenden Sie keine Leerzeichen
~ statt �, �, �, � verwenden Sie ae, oe, ue, ss

--------------------------
4. Lizenz, Haftung
--------------------------
Dieses Skirpt ist derzeit kostenlos und darf sowohl
f�r komerzielle als auch private Zwecke verwendet werden,
die Copryright Vermerke m�ssen jedoch erhalten bleiben.

Der Autor �bernimmt keine Haftung f�r Sch�den die durch
die Verwendung dieses Scripts entstehen.

Jegliche �nderungen am Scriptteil des Fotoalbums sind
untersagt und bed�rfen der schriftlichen Genehmigung des
Autors.
�nderungen am Layout der Seite zur Anpassung an die
�brige Website sind gestattet.

--------------------------
5. Kontakt
--------------------------
Bei Fragen, Anregungen und Bugs schreiben Sie an:

service@woschnet.com


Weitere Scripts sowie Informationen �ber unsere
Dienstleistungen finden Sie unter:

www.woschnet.com

########################################