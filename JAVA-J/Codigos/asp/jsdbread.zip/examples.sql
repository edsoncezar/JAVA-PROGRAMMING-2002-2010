/****** Object:  Table [dbo].[examples]    Script Date: 6/11/2001 5:41:39 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[examples]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[examples]
GO

/****** Object:  Table [dbo].[examples]    Script Date: 6/11/2001 5:42:05 AM ******/
CREATE TABLE [dbo].[examples] (
	[exampleID] [int] IDENTITY (1, 1) NOT NULL ,
	[new] [int] NOT NULL ,
	[exampleName] [varchar] (255) NOT NULL ,
	[exampleDesc] [text] NOT NULL ,
	[examplePathName] [varchar] (255) NOT NULL ,
	[clicks] [int] NOT NULL ,
	[exampleVotes] [int] NOT NULL ,
	[exampleRating] [int] NOT NULL ,
	[exampleVersion] [varchar] (255) NOT NULL ,
	[lastModifiedDate] [smalldatetime] NULL ,
	[firstCreatedDate] [smalldatetime] NOT NULL ,
	[isNew] [bit] NOT NULL ,
	[isUpdated] [bit] NOT NULL ,
	[exampleLanguage] [varchar] (20) NOT NULL 
)
GO

ALTER TABLE [dbo].[examples] WITH NOCHECK ADD 
	CONSTRAINT [PK__examples__117F9D94] PRIMARY KEY  CLUSTERED 
	(
		[exampleID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[examples] WITH NOCHECK ADD 
	CONSTRAINT [DF__examples__new__1273C1CD] DEFAULT (1) FOR [new],
	CONSTRAINT [DF__examples__clicks__1367E606] DEFAULT (0) FOR [clicks],
	CONSTRAINT [DF__examples__exampl__145C0A3F] DEFAULT (0) FOR [exampleVotes],
	CONSTRAINT [DF__examples__exampl__15502E78] DEFAULT (0) FOR [exampleRating],
	CONSTRAINT [DF_examples_exampleVersion] DEFAULT ('1.0') FOR [exampleVersion],
	CONSTRAINT [DF_examples] DEFAULT (getdate()) FOR [lastModifiedDate],
	CONSTRAINT [DF_examples_1] DEFAULT (getdate()) FOR [firstCreatedDate],
	CONSTRAINT [DF_examples_isNew] DEFAULT (0) FOR [isNew],
	CONSTRAINT [DF_examples_isUpdated] DEFAULT (0) FOR [isUpdated],
	CONSTRAINT [DF_examples_exampleLanguage] DEFAULT ('VBScript') FOR [exampleLanguage]
GO

 CREATE  INDEX [eg_new_idx] ON [dbo].[examples]([new]) ON [PRIMARY]
GO

 CREATE  INDEX [eg_egName_idx] ON [dbo].[examples]([exampleName]) ON [PRIMARY]
GO

 CREATE  INDEX [eg_egPath_idx] ON [dbo].[examples]([examplePathName]) ON [PRIMARY]
GO

 CREATE  INDEX [eg_clicks_idx] ON [dbo].[examples]([clicks]) ON [PRIMARY]
GO

 CREATE  INDEX [eg_egVotes_idx] ON [dbo].[examples]([exampleVotes]) ON [PRIMARY]
GO
