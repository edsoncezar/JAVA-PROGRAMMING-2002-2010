Surf-net active users hit counter realease v1 beta


The Surf-net active users hit counter v1 beta is written by Bruce Corkhill

*************************************************************************************
**  Copyright Notice                                                               **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                             **
**  This script is free to use and alter as much as you like.                      **
**  You may not resell or redistribute this script without written permission.     **
**  You may not pass the script off as your own work.                              **
**  You must place a link to http://www.surf-net.co.uk somewhere on your web site. **
**  Use at your own risk!							   **
*************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!



If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.surf-net.co.uk/forum 

your questions will be answered there NOT be e-mail




The hit counter uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the active users hit counter

Unzip all the files

Files must be run through an ASP enabled web sever (this is not the same as CGI)

The global.asa file must be in the root directory of your web site.

The page displaying the number of active users can be anwhere you want in your web site. Just make sure if you are using the graphical digits the folder counter_images is in the same directory on your site.



How it works

How it works is very simple and is included here to help set it up and let you understand what is going on.

All the work is done in the global.asa file. This file automactically runs when ever someone access your web site. It does not matter which page, or page in a directory, the user access the global.asa file will always run first.

In the global.asa file an Application scope variables called intActiveVisitorNumber is created and set to 0 when the server is first started. This variable is used to store the active user number and remains until the server is stopped or is rebooted.

Also in the global.asa you have an Seesion_OnStart. As you may guess any script in this part runs when a session to the server first starts (a user connects to your site). In the Session_OnStart the Application variable intActiveVisitorNumber is incremented by 1.

This Application variable has Application Scope so can now be called from anywhere in your site by using the following, to get the number of active users: -

	Application("intActiveUserNumber")

Also in the global.asa you have an Session_OnEnd. As you may guess by now this part runs when the user leaves your site and in this part the Application variable intActiveVisitorNumber is decremented by 1.



The only problem with accessing a web page using the standard web browser HTTP (Hypertext Transfer Protocol) is that a connection begins when a user calls a web page and a connection is dropped when the web page finshes downloading.

This makes it very difficult to keep track of how long a session lasts. A user may stop and read a page for 5 to 10 minutes or click from one page to another during which time the connection is dropped.

To stop problems occuring and to keep track of the user so the web server does not think every new page or graphic within a page is called by a new user they have set the session to last a default time of 20 minutes, after 20 minutes of inactivity the session times out.

This means that this script is not totally accurate as it will display any user as being active for 20 minutes after they have finshed.

The default session time can be altered from the default 20 mintues. However, take caution, as changing this may upset any session variables or cookies you have on your site.

Also if this value is set to low you will not register users as being active when they are reading a page or as soon as the page has finhed downloading! If it is set to high it will use up valuable resources on the web server for a long time after the user has left making your web host provider none to happy.






If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.surf-net.co.uk/asp/FAQ
