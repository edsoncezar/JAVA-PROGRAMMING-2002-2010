	Setup Instructions
**************************************

Just change the "DB_FOLDER_PATH" value in ado.asp to your database directory.

Default username: "username"
Default password: "password"

This works with any access database that has an autonumber field as a primary key.

Additions
=========
Ian Northwood, DeepNet Limited, March 2002
deepnet@mail.com

I have added code to a couple of modules to allow access to password-protected databases.
It seems to work for me.

5/6/2002 - Fixed security vulnerability with the login process.

9/12/2002 - Finally fixed the line error with the databases not showing up.  Seems that systems 
	    foreign to the United States recognize the Access file type name differently, so I 
	    now have the program recognize Access files by the last 4 characters ".mdb" 
	   	
