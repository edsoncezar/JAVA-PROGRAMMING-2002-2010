Title: Online Database Editor
Description: This will allow you to edit a collection of Access database's table data online. The bulk of the working code was originally submitted by Cakkie, and I added some new features, like secure login, the ability to select any database/table in a predefined directory, query tool, paging, result set count, and a new CSS style schema. I tested it a bit, but please report any bugs that may occour. View the ReadMe.txt file for setup instructions.
UPDATED 9/12/2002
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7350&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
