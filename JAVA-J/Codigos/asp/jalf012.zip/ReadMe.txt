JALFILE COM DLL DOCUMENTATION v0.12

07/22/01

Introduction

JALFile is a lightweight freeware COM dll that supports authorized file downloads. It is a work around for failure of the IIS FileScriptingComponent to support binary read. Files may be placed above the root web folder "out of view" where they are only available to privileged components such as JALFile.File. Two pertinent articles are available from MSDN at:

http://msdn.microsoft.com/default.asp
Q193998 - HOWTO Read and Display Binary Data in ASP.htm
Q260519 - HOWTO Raise a File Download Dialog Box for a Known MIME Type.htm

Versioning

v0.12 no longer calls SafeArrayDestroy after calling VariantClear. VariantClear does a deep destroy of the encapsulated  SafeArray.

**** DISCLAIMER ****

The JALFile dll is distributed AS IS and no suggestion or promise of suitability, reliability or correctness of this software is expressed or implied for any purpose other than private non-commercial evaluation and use on an intranet. The user and or installer of this software assume(s) any and all responsibility for damages and or losses resulting from the installation and or use of this software. The installation and or use of this software shall signify consent with this disclaimer.

This software has not been tested extensively and must be considered beta software.

**** END DISCLAIMER ****

General Concepts

The IIS FileScriptingComponent is limited in that it only supports reading in file data in text mode. This makes it difficult to do a BinaryWrite of a file to a browser client for downloading. This component is a workaround for this limitation. The sample solution provided in MSDN article Q193998 passes the entire file as an Array of Bytes from a Visual Basic dll to an ASP script. This solution is impractical for large binary files. The JALFile component writes the file as CHUNKs of data, directly from the dll. The default File.nChunkSize is 4096 bytes. This property can be set by the user to a maximum value of 256K. Before transmitting each CHUNK, the component calls the method Response.IsClientConnected. The method File.BinaryWrite will return true if the entire file is successfully written. The source file for dowloading  is set using the property File.strPath. The C++ string escape character '\' requires that path names be written as c:\\someFile.zip or as c:/someFile.zip.

JAL