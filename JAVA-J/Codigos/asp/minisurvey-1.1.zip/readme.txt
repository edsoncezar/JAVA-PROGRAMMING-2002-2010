Download the latest version from: http://www.2enetworx.com/dev]

What is MiniSurvey?
-------------------
MiniSurvey is a freeware ASP-based tool which you can define surveys to collect information from the visitors of your site.

What's new in Version 1.1?
--------------------------
* Only one vote per IP. (*)
* Graphical display for the visitor. (*)
* "Additional Information" extension. (*)

What's already in?
-----------------
* Add, edit and delete surveys
* Add, edit and delete answer options
* Show graphical voting reports

Easy to use, almost nothing to customize!

(*) Credits :
Thanks to Tom Holder, who developed the IP restriction,
"additional information" extension and ported graphical
display for visitors. 
Visit his site at http://www.ymonda.co.uk/ for more
ASP source code and products.



How to implement it in your pages?
---------------------------------
Just check out the HTML code in index.html file,
You will see that vote.asp file is called in an IFrame tag with the Survey ID parameter.
After you define your surveys, select a survey with this code by supplying the ID.

NOTE : The database should be in a safe folder, not togetger with the asp files!

To Do List
----------
1. Detailed reports will be added.

Notes
-----
� Dont forget to read the disclaimer.html and privacy.html.
� The code is not stress tested but I'm personally using it for our company's Intranet and a couple of web sites.

Final Words
-----------
If you would like to contribute to the development, to report a bug, or to recommend a feature, 
please dont hesitate contact me :)

Hakan Eskici
hakane@2enetworx.com
