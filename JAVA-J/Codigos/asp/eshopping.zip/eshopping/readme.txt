Code Name   : ASP-Access Shopping Cart

Version     : 1.0

Date        : June 6, 2001

email       : shailesh_shet@lycos.com

Also Download from : http://shailesh_shet.tripod.com/

About the code :


    This is a full-featured ASP-based catalog and shopping
cart application for small businesses and developers.This uses Access database
with DSN-less connection







