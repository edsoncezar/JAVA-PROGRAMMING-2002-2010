Easy Postcard ASP:

SamHS is back with another one of those block-rocking-scripts!
This one is really easy to use!
To get it working all you need to do is change 2 variables in the asp code: sitename and thankspage
And replace the images in the form with the images you want to send - it's really that easy!
Rename the form to index.htm, upload all the files to a subdirectory on your server (remember to make a thanks page)
And it's ready to go!

If you want to change it more than that, here are are the full instructions - it's still gonna take you no time to set up

Enjoy! :o)

Sam


Directions for use:

1. Change the necessary variables in the script:

   sitename
   thankspage
   strsubject
   strbody
   

2. Create a form with the following form fields:

   picture (multiple files to send - see the example [form.htm])
   yourname
   youremail
   theirname
   theiremail
   
3. Create a directory in your webspace (lets call it 'postcard' for the sake of argument) and upload the following into it:

   All of your images
   the asp script (easypostcardasp.asp)
   the thank you page
   your form (call it index.asp, or index.htm - sepending on whether you have extra asp code in there or not)
   
4. Access your script:

   http://www.your-domain.co.uk/postcard
   Choose which image to send, fill in the details and press submit.
   
That's it!  Easy!

Having problems with this script ?  Check out the dotdragnet Web Builder forum.

http://www.dotdragnet.co.uk
