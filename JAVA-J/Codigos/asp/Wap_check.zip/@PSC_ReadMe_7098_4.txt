Title: Wap checkin/checkout
Description: This code shows a little example on how to use ASP to generate wml pages, which can be opened using a cellphone or any other microbrowser.
The use is simple, you need to specify a username and password, optionally a customer and select wether we are checking in or out. The asp page will then validate the login, check if the supplied customer exists, and adds a record to the checkings table.
Using the "show checkings" option in the main page shows you all the checkings that are in the database.
Very basic, but shows some usefull stuff.
Possible users/passwords are guest/guest or cakkie/password. If you specify a customer, it must be either m$ (Micro$oft) or psc (planet-source-code). 
Enjoy
As usual, feedback and votes appriciated
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7098&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
