ASP Form Processor
Characteristics:
-Fast form processing
-Works in all ASP servers with FileSystemObject
-Date and IP in all form submissions
-Customizable options like save to file and redirect page

To use form processor in your site first you need to have a folder with write permissions, if you are not sure contact your hosting provider, then in the <FORM> tag in your form page add the following parameters:
action="aspform.asp"
method="POST"

The tag will look like this:
<form action="aspform.asp" method="POST">

Then add 2 hidden fields:
Hidden field #1
<input type="hidden" name="filesave" value="myfile.txt">
Replace the value of tag "filesave" with the name of your file where all the data will be saved.
If your file is in another folder then change it like:
value="\myfolder\myfile.txt"
value="..\myfile.txt"

Hidden field #2
<input type="hidden" name="redirpage" value="mythankyoupage.html">
Replace the value of tag "redirpage" with your "Thank you" page or any page you want to be seen after the form is processed
