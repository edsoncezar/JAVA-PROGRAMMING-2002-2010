Title: ASP Form Processor
Description: This script processes any form and saves the results to a text file including the users IP and posting date. Attached is the script and a readme file with specifications on how to use it.
Please vote and leave your comments.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7804&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
