Title: Html Color Sample
Description: A simple ASP page that shows true html hexadecimal colors for copy and paste. I look that some of the colors that I convert with the RGB function wont look the same in the IE so I made this table. Almost all the code are VBScript Client side and includes a little part of VBScript Server side. Cool for Beginners.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6416&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
