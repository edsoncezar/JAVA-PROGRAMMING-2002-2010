Mylogin - Elad Rosenberg 8/2000
-------------------------------
Mylogin is login system for a secure section in your site.
You have to registered to get your password by email.
see the code in reg.asp to change your server URL.
