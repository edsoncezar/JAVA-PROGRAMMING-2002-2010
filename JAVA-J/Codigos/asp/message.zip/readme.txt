Mail System Ver. 0.9 Beta.

This is a simple internal mail system, originaly developed for an intranet project.

You are free, to use this beta version, modify the code, and pass it on to whom you wish, but please tell them who did it.
If you make any modifications to the code, please would you let me have a copy!

How To Install
==============

Unzip all the files on to your website,
all the images should extract in to a seperate /image directory,

Set up a system DNS called message using the ODBC icon in control pannel.

That should be it.

Sorry it's this readme is a bit short, but....

If you have any comments or suggestions on how to improve this aplication, please e-mail me at -

asp@asp-dev.ml.org

Don't forget to vist my ASP Resources website (still under development) at http://asp-dev.ml.org

Thanks John Penfold

