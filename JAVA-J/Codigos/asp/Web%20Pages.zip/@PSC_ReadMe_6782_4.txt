Title: Special Effects
Description: This file has some source files that can change your browser's scrollbar color, link hover color, and even have a mouse trail with a phrase of your choice. I will update as often as I make new. Vote for me!!! Dont forget to take out the comment tags!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6782&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
