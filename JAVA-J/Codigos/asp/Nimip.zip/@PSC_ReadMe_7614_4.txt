Title: Nimip�iv� / Name day
Description: Code that pulls out of an DB todays Name day winner :). Whos name day is today. DB is currently filled with Finnis names but you can put your own name day calendar to the DB. Very simple one page script and only one table in DB.
At this point, no error correction if date is'n found / empty.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7614&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
