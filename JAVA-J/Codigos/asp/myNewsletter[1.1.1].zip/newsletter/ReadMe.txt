AspCreations myNewsletter Script
Written by Tim Wong
http://www.aspcreations.com
Version 1.1.1

------------------------------------------------------------------------------

Version History
1.1.1 - Fixed a bug where you could not delete an email with spaces in it
1.1 - Fixed a bug with signature editing
1.0 - First release of script

------------------------------------------------------------------------------

[ Notes ]

- The script supports 2 kinds of database. Either MS Access or MS
SQL Server. If you plan on using SQL Server, then you can delete
the file named "renameThisDatabase.mdb" in your /newsletter/ 
directory.

- CDONTS component must be installed on your server. By default,
all NT servers should have the CDONTS component installed. This
component is used to send mail to all your subscribers.

------------------------------------------------------------------------------

[ Basic Instructions ]

- Unzip the zip file that contains all the script files. Note that all
files must be unzipped into your /newsletter folder in your website's
root directory.

E.g: yourDomain.com is your domain name. Then all files must be
unzipped into yourDomain.com/newsletter

If you do not unzip it into the correct directory, it will cause errors
and the script will not run.

- Time to modify variables

[ variables.asp ]
Important: You will need to rename your database name to anything you 
desire if you plan to use MS Access. The default name is 'renameThisDatabase.mdb".

After renaming your database in your /newsletter directory, make sure the 
same name is entered in the databaseName field in variables.asp.

If you are not planning to use MS Access, you can delete this file away.

Next, you will need to do is to uncomment the line (remove the single inverted comma 
at the front of the variable, strServerConnection) that reflects the database that 
you want to use. The default is the first setting, which uses the MS Access as the
database. You can make use of MS SQL or System DNS settings if you know
how to configure them.

Next, make changes so that it reflects your website's URL / domain name, 
email address and company name. There are instructions in the file itself to 
guide you along.

- After you have unzipped/edited your files, run the installation file located
at http://www.yourDomain.com/newsletter/install.asp

This file should only be run once, as it'll create the database information
neccessary for your newsletter to run correctly. It is also highly advised
that you delete this file(install.asp) after installation is complete.

- After installation is completed, it'll then redirect you to the admin center
login page for the newsletter. You can then play around with the options
available.

- To get your users to sign up, all you need to do is to get to to visit
/newsletter/subscribeNewsletter.asp and fill in their email addresses there.
They will then be sent an email, and once they reply the confirmation
email, they will be added into the active subscribers list.

That's all. Your entire newsletter script has been set up successfully. Feel
free to contact me and drop your suggestions. All the best for your
website. Watch out for other scripts at http://www.aspcreations.com

------------------------------------------------------------------------------
