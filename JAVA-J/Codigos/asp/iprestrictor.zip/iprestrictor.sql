/****** Object:  Table [dbo].[permitted_IP_log]    Script Date: 6/11/2001 7:10:54 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[permitted_IP_log]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[permitted_IP_log]
GO

/****** Object:  Table [dbo].[restricted_IP_banks]    Script Date: 6/11/2001 7:10:54 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[restricted_IP_banks]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[restricted_IP_banks]
GO

/****** Object:  Table [dbo].[restricted_IP_log]    Script Date: 6/11/2001 7:10:54 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[restricted_IP_log]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[restricted_IP_log]
GO

/****** Object:  Table [dbo].[restricted_IP_types]    Script Date: 6/11/2001 7:10:54 AM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[restricted_IP_types]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[restricted_IP_types]
GO

/****** Object:  Table [dbo].[permitted_IP_log]    Script Date: 6/11/2001 7:10:56 AM ******/
CREATE TABLE [dbo].[permitted_IP_log] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[logTimestamp] [datetime] NOT NULL ,
	[IP] [char] (15) NULL ,
	[referer] [varchar] (255) NULL 
)
GO

/****** Object:  Table [dbo].[restricted_IP_banks]    Script Date: 6/11/2001 7:10:59 AM ******/
CREATE TABLE [dbo].[restricted_IP_banks] (
	[rule_ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Bank_Start_IP] [char] (15) NULL ,
	[Bank_End_IP] [char] (15) NULL ,
	[Restricted_Since] [datetime] NOT NULL ,
	[IsRestricted] [bit] NOT NULL ,
	[RestrictDescription] [varchar] (255) NULL ,
	[RestrictionTypeID] [int] NOT NULL 
)
GO

/****** Object:  Table [dbo].[restricted_IP_log]    Script Date: 6/11/2001 7:11:02 AM ******/
CREATE TABLE [dbo].[restricted_IP_log] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[rule_ID] [int] NOT NULL ,
	[logTimestamp] [datetime] NOT NULL ,
	[IP] [char] (15) NULL ,
	[referer] [varchar] (255) NULL 
)
GO

/****** Object:  Table [dbo].[restricted_IP_types]    Script Date: 6/11/2001 7:11:05 AM ******/
CREATE TABLE [dbo].[restricted_IP_types] (
	[RestrictionTypeID] [int] IDENTITY (1, 1) NOT NULL ,
	[RestrictionName] [varchar] (255) NOT NULL 
)
GO

ALTER TABLE [dbo].[permitted_IP_log] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[restricted_IP_banks] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[rule_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[restricted_IP_log] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[restricted_IP_types] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[RestrictionTypeID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[permitted_IP_log] WITH NOCHECK ADD 
	CONSTRAINT [DF__permitted__logTi__4C0144E4] DEFAULT (getdate()) FOR [logTimestamp]
GO

ALTER TABLE [dbo].[restricted_IP_banks] WITH NOCHECK ADD 
	CONSTRAINT [DF__restricte__Restr__4EDDB18F] DEFAULT (getdate()) FOR [Restricted_Since],
	CONSTRAINT [DF__restricte__IsRes__4FD1D5C8] DEFAULT (1) FOR [IsRestricted]
GO

ALTER TABLE [dbo].[restricted_IP_log] WITH NOCHECK ADD 
	CONSTRAINT [DF__restricte__logTi__52AE4273] DEFAULT (getdate()) FOR [logTimestamp]
GO

 CREATE  INDEX [permIPlog_1] ON [dbo].[permitted_IP_log]([IP]) ON [PRIMARY]
GO

 CREATE  INDEX [restIPbank_1] ON [dbo].[restricted_IP_banks]([Bank_Start_IP]) ON [PRIMARY]
GO

 CREATE  INDEX [restIPbank_2] ON [dbo].[restricted_IP_banks]([Bank_End_IP]) ON [PRIMARY]
GO

 CREATE  INDEX [restIPbank_3] ON [dbo].[restricted_IP_banks]([RestrictionTypeID]) ON [PRIMARY]
GO

 CREATE  INDEX [restIPlog_1] ON [dbo].[restricted_IP_log]([rule_ID]) ON [PRIMARY]
GO

 CREATE  INDEX [restIPlog_2] ON [dbo].[restricted_IP_log]([IP]) ON [PRIMARY]
GO


