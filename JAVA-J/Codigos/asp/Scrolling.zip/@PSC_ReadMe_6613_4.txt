Title: Scrolling News Ticker with Database Access
Description: This is a scrolling news ticker that looks basically exactly like the one on this page. I even "borrowed" their cell formatting to give it that sunken look.
There are three files in the Zip. Two are the ASP files. One file contains the actual scroller, the other is the detail page that loads after the news item is clicked inside the scroller. The third file is a Microsoft Access 2000 database file. If you don't have Access 2000 and you want to edit records, you can create a database in 97 or whatever database program you use. The table must be called "news", and the fields are "Entry_ID", "Entry_Date", "Title", and "Text". If you use something other than MS Access, you will also have to change the driver in the connection string.
Just extract the three files in the Zip to your C:\inetpub\wwwroot directory. If your not using PWS, extract it where ever you like and change the connection string in the two ASP pages to reflect the location of the database file.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6613&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
