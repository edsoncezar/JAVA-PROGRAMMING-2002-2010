' PortaChat 1.3 
' Author: Peter Brunone
' Release Date: December 12, 2000
' Contact: peterbrunone@aspalliance.com

01/22/2001: (v1.3.1) IE 5 no-refresh issue has been resolved (thanks, Dr. Michael Steele).
    checkusers.asp utility added to view and remove stale logins.  
    **!!** It is recommended that you change the name of this file. **!!**

12/12/2000: (v1.3) No more conflicting names; security hole patched.
    Previously, users were able to change their nickname and preferences to malicious code by executing javascript in the address bar. This has been corrected. 
    Also, a name check has been established to keep users from picking a name already in use.

12/07/2000: (v1.2) "Sign On" bug fixed; /clear, /nick, /logout commands added; persistent user name.
    It had been noted that clicking the Sign On button -- instead of just hitting Enter -- resulted in a JavaScript error. This has been remedied.
    Three IRC-type commands -- /clear (no parameters), /logout (no parameters), and /nick (new nickname as parameter), are now supported.
    Given cookie support, nickname is now remembered between visits. 

12/01/2000: (v1.1) Style support added.
    Now users can customize their "look" for messages. Everyone seems to want an identity, and this is one way to get it. You can easily add more style features by adjusting the list in chatmenu.asp . 

11/30/2000: Source Code available.
    This is completely plug and play. Nothing to configure if you don't want to; just unzip it on your web server and it's ready to go. Rudimentary, but ready. 
