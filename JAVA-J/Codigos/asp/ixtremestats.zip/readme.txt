ixtreme stats version 1

**********************************
**********************************
NOTE: 

You must have "write access to a directory on your server
in order for the database to write the page views to the database
**********************************
**********************************

Extract all files.

Modify statsinclude.asp so that StatsConnString points to where you have your database on the server.

Copy the database (ixtremestats.mdb) to a directory on your server with write access.

Create a directory on the server called "stats".

Copy the rest of the files to "stats"

For each ASP file you would like to get stats for, place the following line of code at the 
top of the page (may need to modify path depending on how your host is set up):

<!--#include virtual="/stats/getstats.asp"-->


To check out the stats for your site, go to

http://yoursite.com/stats





