Web Wiz Guide Advanced Site Search Engine realease v1.65 beta


The Web Wiz Guide Advanced Site Search Engine v1.65 beta is written by Bruce Corkhill

****************************************************************************************
**  Copyright Notice                                                                  **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                                **
**  This script is free to use and alter as much as you like.                         **
**  You may not resell or redistribute this script without permission by the author.  **
**  You may not pass the script off as your own work.                                 **
**  You must place a link to http://www.webwizguide.com somewhere on your web site.   **
**  Use this script at your own risk						      **
****************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.webwizguide.com/forum 

your questions will be answered there NOT by e-mail



The site search engine uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the Advanced Site Search Engine


Unzip all the files to the same directory

Files must be run through an ASP enabled web sever (not the smae as CGI)

The site_search.asp file needs to be in the root directory of your website to be able to search all files on your site




SETTING UP THE SEARCH SCRIPT

Open the script in Note Pad and near the top of the script you can set the following functions: -

How many results you want shown on each page

Set the file extension types you want the script to search, seperated by commas, the default is, htm, html, asp, shtml

Enter the names of the folders, seperated by commas, you don't want searched like adminstration folders or the cgi_bin

Enter the names of the files, (include the extension type ie .htm) seperated by commas, of the files you don't want searching like asp files that are only used for processing forms etc.

Set the English Language boolean to False if you are not using the script on an English Language web site.




The speed at which the searching is done depends on how many files there are to search on the site.

The  website search engine uses the Regular Expressions component which is needs to VBScript 5.0 scripting engine, which older servers may not support.  




WARNING!!!
Due to the complex nature of this script and the different ways directories are mapped on web servers the script is not guaranteed to run on all web sites so please check that the script runs with your web site on the web server before you take the time to customise it.




Tip

The following tips will give more descriptive results from the site search engine also they will give your site higher ratings by search engines like Google, AstaVista, Lycos, etc.


Make sure each page of your site has a title otherwise the script will return a 'no title' for the page. Titles should be standard HTML titles as follows: -

<title>PLACE YOUR PAGE TITLE HERE</title>


make sure that each page has a meta description of what the page contains otherwise the results will return 'There is no description for this page'. Meta descritions should be standard HTML meta tags that the Internet search engines read: -

<meta name="Description" content="PLACE PAGE DESCRIPTION HERE">





If you receive the following error: -

	Microsoft VBScript compilation error '800a03ea'
	Syntax error
	/site_search.asp, line 344
	Set objRegExp = New RegExp

It means that the server does not have the VBScript Engine version 5 or above installed, and so the script will NOT run on the web server you are using.

You will have to download the other simpler version of the Site Search Engine from Web Wiz Guide that does not require the VBScript Engine 5 to run. 

If you are running the server yourself you will have to download and install the latest VBScript Engine from Microsoft.





If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.webwizguide.com/asp/FAQ

