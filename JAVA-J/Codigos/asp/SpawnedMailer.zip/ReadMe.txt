Copyright (c) 2001, Spawned.co.uk & Lee Wilson.
http://www.spawned.co.uk, All rights reserved.
hyperwhore@spawned.co.uk

Spawned.co.uk | Scripted and Documented by Lee Wilson
Mailing List Sign-up and Mailing List Manager | V1.1

A - DISCLAIMER
B - WHAT IS...?
C - REQUIREMENTS
D - INSTALLATION
E - THANK YOU

A. DISCLAIMER

This is freeware - Use at your own risk. No warranties provided.  Redistribution 
of this program, in whole or in part, is strictly prohibited without the expressed 
written consent of the author. Custom programming available on hourly fee basis.

B. WHAT IS SPAWNED MAILER?

Spawned Mailer is a full mailing list script allowing your visitors to sign up to
your newsletter. As well as having this feature, you can send an email to all your
users, archive emails, add admins with user permissions, and edit your mailing list.
The script comes with the usual template, but this time you have a config section
which enables you to chnage colours of certain features, such as body background
colour, and link colour.

C. REQUIREMENTS

If your site is hosted on a Windows NT server with IIS 4.0 or higher and ASP 2.0 or 
higher you should be fine using this script. The script does require CDO 
(Collaborative Data Object) to send mail. If you are not sure whether your box will 
run this script, run it anyway or contact your administrator.

D. INSTALLATION

Spawned Mailer. although a quite large application is probably my easiest script to
date to install on your box. Follow the simple steps below.

1. You have obviously extracted the Zip file, so upload all files to the same
directory on to your server. For example you could upload all files to
www.yourdomain.com/SpawnedMailer

2. Configurate your Mailing List Manager via a web browser. You need to surf on
to the directory which you uploaded to. For example you would type 
www.yourdomain.com/SpawnedMailer in to your address bar.

3. Click the admin option, then login using Name: Admin1 Pass: test60

4. Access the admin section, click Main > Config.

5. Change all of your personal preferences.

6. Go back to the admin home, enter the section marked Admin > Edit.

7. Find your login information and edit it to your own personal preference.


Now you are completely set up to use the script. To enable people to sign up to
your Mailing List either:

a) Add a link to SpawnedMailer.asp or

b) Insert the following code on whatever page:

<center><br>Sign up to my mailing list!<br>
<form method=post action="SpawnedMailerAdd.asp">
<input type=text name="eaddy" value="you@yours.com"><br><br>
<input type=submit size=20 value="Sign me up!"></form></center>


Note: Make sure you change the form action to point to the correct directory!


If you wish to add admins then do so through your admin section. Admins with
a level 1 status can only send emails, and edit the mailing list. Admins with
a level 2 status have access to all features. Choose your admins carefully!
Admins are handy for if you are always too busy to manage your own mailing list.



E. THANK YOU

Firstly, thank you for using my script!

I have Mark Stringer to thank for being on hand with his little code snippets. Mark's
site can be found at http://www.markstringer.co.uk.

~ Lee Wilson
