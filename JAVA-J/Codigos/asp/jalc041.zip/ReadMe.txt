JALCalendar v0.41 COM Server Dll Documentation
J.A.L. 09.02.01

JALCalendar is a freeware C++ server side COM dll that generates a perpetual HTML
Gregorian calendar. The calendar allows the user to navigate to a specific day in
the year using embedded links. The target audience is an Active Server Pages
scripter interested in building a browser based scheduling application for use
on a corporate intranet. This component has been designed for use with server
side JScript or VBScript on an NT4 or Windows2000 IIS web server. The server
side script and dll generates generic HTML output that can be viewed with most
any browser. This dll can be used with Cascading Style Sheets and should be
callable by any language that load a COM server, including a C++ CGI script.
The HTML output can be customized by setting several dll properties. This version
works with both Netscape 4.7 and IE 5.0.

v0.11 Adds new properties isNavLink and isDayLink.
v0.13 Improves the appearance of empty cells under Netscape 4.7
v0.14 Updated sample script to pure JScript.
v0.20 Adds an action bar for rapid navigation by month and year.
v0.30 Adds support for highlighting a day in the month. Sample script now compensates for JScript function Date.getMonth() being ZERO based.
v0.40  Uses <string> for local string manipulation for increased speed.
v0.41 Fixes extra colored cells for nDay= 1.
         
DISCLAIMER

The JALCalendar dl is distributed AS IS and no suggestion or promise of suitability,
reliability, or correctness of this software is expressed or implied for any purpose
other than private non-commercial evaluation and use on an intranet. The user or
installer of this software assume(s) any and all responsibility for damages or
losses resulting from the installation and or use of this software. The installation
and or use of this software shall signify consent with this disclaimer.This
software has not been tested extensively and as such must be considered "beta"
software. However, it does not contain any known defects.

