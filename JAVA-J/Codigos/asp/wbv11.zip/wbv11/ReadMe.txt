Web Banners V 1.1
Copyright 1999-2000 WebPage-Tools.com
-------------------------------------

Thank you for downloading a copy of Web Banners. Web Banners is an ASP based banner rotation system that uses a Microsoft Access database. Some of its main features are:

~ Random banner rotation
~ Ability to track impressions and click-thru's
~ Web based, password protected, administration area to delete/modify/add advertisers
~ Client area to view statistics, including click-thru's, impressions, ratios and other stats
~ Banners that have reached the amount of impressions purchased are marked to keep them out of rotation (but not deleted)
~ By choosing a start date, you can add an advertiser and keep the banner out of rotation until the specified date
~ Advertisers can choose their own text under the banner
~ A default banner is shown if list of advertisers is empty

Setup & Instructions
--------------------

STEP 1:
-------
Open adminConst.asp (found in the "cgi-bin" folder) and make any necessary changes using the comments provided. Open webbanners.mdb (found in the "cgi-bin" folder), open the "Admin" table and change the username and password to whatever you want.

STEP 2:
-------
This script assumes that all of the files located in the "webbanners" folder are found in your root directory. It also assumes that all of the files located in the "cgi-bin" folder are found in your main cgi-bin directory. To make it simple, take all of the files from the "webbanners" folder and put them in your root directory, then take all of the files from the "cgi-bin" folder and put them in your main cgi-bin directory. 

STEP 3:
-------
Point your browser to WBLogin.asp (in your cgi-bin directory) and enter the username and password you chose from the "Admin" table in the database. Upon entering the correct login information, you will be authorized to enter the Web Banners Admin Area. (You will notice that the changes you made to adminConst.asp are shown here, including the colors, title, etc...) From the Web Banners Admin Area, you will be able to view/add/modify/delete your list of advertisers. There are 2 sample advertisers in the database to get you started. (You should see them in the drop-down menus as long as you didn't remove them from the database.) We suggest that you leave the sample advertisers in the database until you have had time to test the sample pages (sample1.asp, sample2.asp & sample3.asp which you already uploaded - files 299546.txt and 766132.txt are sample logfiles for each customer in the database). More about the sample pages is below. All of your advertisers should have a unique id number of their own. This is created for you and entered in to the database when you "add" a new advertiser. For instructions on how to add a new advertiser, and a description of each field, please see below. All of the modifying and deleting can be done directly from this page. You can also view current advertisers and change the default banner. Please note that the default banner will not be tracked. The HTML code required to show banners on your pages can be found in this area as well. 

ADDING A NEW ADVERTISER:
------------------------ 
From the administration area, you can add a new advertiser. Below is a short description of each field.

1) Customer ID #: A 6-digit numeric entry that will be chosen automatically. Each customer should have a unique number.
2) Customer E-mail: A customer's e-mail address so that they can view their stats online.
3) Company: The advertiser's company name.
4) Impressions Purchased: The number of impressions purchased for this banner. When the amount of impressions has been reached, the banner is kept out of rotation.
5) Start Date: A date to begin rotating this banner. The current date is automatically entered in to the field for you, but you can change it if you need to. If you don't want a banner in rotation right away, simply set a later start date.
6) Banner Image: Full Url to the banner image.
7) Banner Width: The width of the banner in pixels.
8) Banner Height: The height of the banner in pixels.
9) Url To Link To: The Url to go to if the banner is clicked on.
10) Text Under Banner: Any text that you want shown under this banner. This is also used for the ALT tag.

THE DEFAULT BANNER:
-------------------
A default banner is included and shown if the database of advertisers is empty. This is to avoid unecessary database errors. Please change the banner image and its properties from the Web Banners Admin Area.

SAMPLE PAGES:
-------------
"sample1.asp" shows the code used to display one random banner. "sample2.asp" shows the code used to display the same banner twice on the same page. "sample3.asp" shows the code used to display two different random banners on the same page. More about this can be found in "FAQ.txt". 

YOUR CUSTOMERS:
---------------
Your customers can login via "Login.asp" to view their banner statistics. They also have the option to view/clear their click-thru log file. The impressions, click-thru's and ratios are generated on-the-fly from the database. A customer will need their ID number and e-mail address in order to access the stats.

OTHER FILES:
------------
"banners.asp" is an include file which contains the code to generate a random banner and count impressions. When a banner is clicked on, "redirect.asp" and "trackclicks.asp" will track click-thru's and create a log file for each advertiser. This log file will contain the date/time, browser version and I.P. address of each click-thru visitor. Then the visitor is redirected to the proper web site. Unless you uploaded these files to a different directory other than what was recommended in Step 2, you should not need to modify these files. They are, however, commented to guide you through making such changes.

SUPPORT & HELP:
---------------
Feel free to modify the layout or design to suit your needs. This code is setup to use a DSN-less connection, the FileSystemObject and an MS Access '97 database. Formal support is not offered for this free product but we may be able to help via e-mail. Send e-mail to: support@webpage-tools.com, and someone will be able to help within 48 hours. Please see FAQ.txt for frequently asked questions about Web Banners.

Send bug reports and suggestions to support@webpage-tools.com .

Thank you.
Web Banners Administration Team

WebPage-Tools.com
-------------------------------------

