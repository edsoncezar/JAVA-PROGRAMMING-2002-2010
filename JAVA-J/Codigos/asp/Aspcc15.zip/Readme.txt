ASP Client Check

Version:	1.5 
Date Created:	May 15, 2001  
Author: 	PascaL Michaud 
License: 	Freeware 
Copyright:	2001 PascaL Michaud
Homepage:	http://www.instagib.com/pm/aspcc/

Installation

1. Unzip contents of the downloaded .zip file to a web directory 

2. For database security, set the hidden property for the "users.mdb" file;
 and/or, place this file in a directory inaccessible to the web;
 and/or, rename the file. 

3. Edit the variables in the "aspccConfig.asp" configuration file. 

4. Test the script by loading "form.asp" in your browser 

5. Customize the subroutine in "aspccConfig.asp" with your own code. 

6. Remove the test section (delimited by HTML comments) from "form.asp".
 
7. Integrate the remaining "form.asp" code into your project,
 or use "form.asp" as a stand-alone script. 

8. Edit your users (using MS Access or the admin script provided [login via the form]) 
