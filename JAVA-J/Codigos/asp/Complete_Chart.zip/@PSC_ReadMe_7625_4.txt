Title: Complete Internet Shopping Cart!
Description: This is a complete ASP shopping cart. Pure ASP. Client side scripting. Just ASP. It has login, register and retrieve password functions already built in.<P>
This also has a function that when you submit the order it e-mails it to an e-mail address specified in the file and also e-mails the user thanking them. It has a complete shopping cart, you find the item you like by browsing through the catogories, select it, click add to cart then select the quanitity(use the calculator to see how much it's going to cost) then click add. The product is added and is now in your cart!
<P>
Please vote because this was quite a bit of work. If I get enough votes(good or bad) I will release a second version.
<P>
This script will work best if you put it in C:\Inetpub\wwwroot\shop\. I didn't bother with a fancy interface, I left that up to you to do.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7625&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
