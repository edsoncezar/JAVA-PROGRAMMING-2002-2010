SiteSearch - TheASP Search Engine
	Alexander Lowe, 2000
	alowe@iadvance.net
	www.iadvance.net
	www.templecrc.com


This is a basic framework for a search engine. It is very simple to use
and is ready to be expanded on.

To begin:
This engine uses ADO to access a database via ODBC. It also uses ASP.
Therefore it is necessary to run this on an ASP capable server, such
as MS IIS. 

You must also setup an ODBC data source in the Control Panel or
Administrative Tools. Create a System DSN with the provided Access
database (sitesearch.mdb) called 'SiteSearch'.

Once that is done you can point your browser to the server containing
the engine asp files and go. It will allow you to search and add new
pages to the site.