Web Wiz Guide Guestbook realease v3.76 beta


The Web Wiz Guide Guestbook v3.76 beta is written by Bruce Corkhill

****************************************************************************************
**  Copyright Notice                                                                  **
**  Copyright 2001 Bruce Corkhill All Rights Reserved.                                **
**  This script is free to use and alter as much as you like.                         **
**  You may not resell or redistribute this script without permission by the author.  **
**  You may not pass the script off as your own work.                                 **
**  You must place a link to http://www.webwizguide.com somewhere on your web site.   **
**  Use this script at your own risk						      **
****************************************************************************************

The copyright notice has been placed here as I have found people passing my scripts of as there own and I have even come across someone selling them!!


If you are having problems running the script then please post a message about the problem to the surf-net web forum at: -
	
	 http://www.webwizguide.com/forum 

your questions will be answered there NOT by e-mail



The Guestbook uses ASP and must be run through a web sever supporting ASP.

Luckily Windows 98 comes with Personal Web Sever found on the windows 98 CD. Windows 2000 is even better as it comes with Microsoft's Web Sever, IIS 5. 

Windows NT 4 and 95 users can get a copy of Personal Web Sever by downloading NT 4 Option Pack from Microsoft. Don't be fooled by the name as it asks if you wish to download Windows 95 version.

A Text Editing program like UltraEdit is also highly recommended for editing any ASP scripts and an FTP program like Bullet FTP for uploading any scripts to your ASP enabled web space.




Using the gusetbook


Unzip all the files to the same directory (smiley images should be in the directory guestbook_images)

Files must be run through an ASP enabled web sever

The main page is 'guestbook.asp'

To adminster the guestbook use the page 'admin.asp' to delete or amend any comments

To configure the guestbook use the page 'configuration.asp', from here you can set the colours for the database to fit in with your own site and set the number of comments shown on each page (once you have configured the Guestbook I would suggest you delete the file from the server).

the database is written in Access 2000, this program must be used to amend the database directly.



If you are having problems with the Guestbook running then edit the file common.inc with note pad where you can select to use a diffrent OBDC database driver or use DSN if you are able to setup DSN on your web server.



Tip

If you customise the guestbook try to keep the comments within there own table row otherwise if a user uses bold or italic in there commets and don't close the tags it may make your entire page bold or italic.



If you recieve the following error: -

Microsoft OLE DB Provider for ODBC Drivers error '80004005' 
[Microsoft][ODBC Microsoft Access Driver] Operation must use an updateable query.

This means that the directory the database is in does not have the right permissions to be able to write to the database. 

If you are running the web server yourself and using the NTFS file system then there is an FAQ page at, http://www.webwizguide.com/asp/FAQ, on how to change the server permissions on Win2k/NT4.  

If you are not running the server yourself then you will need to contact the server's adminstrator and ask them to change the permissions otherwise you cannot update a database.



If you are having trouble with the script then please take a look at my FAQ's, before e-mailing me, at: -

http://www.webwizguide.com/asp/FAQ

