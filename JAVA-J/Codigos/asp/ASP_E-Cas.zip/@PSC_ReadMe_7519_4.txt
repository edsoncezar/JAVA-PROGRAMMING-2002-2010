Title: ASP E-Cards
Description: This E-Card is coded into a single file. It works by allowing the user to enter the complete URL, including filename and extension of any image on the internet. The user then clicks a link and are taken to a form where they can fill in the recievers email address and name, any message they have for the reciever and their own name and email address. Once submitted, they preview the e-card as the receiver will see it. Now they have the choice to start over or to send the e-card. It can also be used to turn each image in a picture gallery into a link which will make the image an e-card.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7519&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
