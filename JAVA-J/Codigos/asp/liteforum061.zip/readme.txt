LiteForum by Tim Hegyi
_______________________

Ver. 0.61
	- Access level bug fix...
Ver. 0.59
	- HTML bug fixed...

Ver. 0.58
	- First public release...


Installation.
1. Unzip the file to read this file :D
2. Edit the file calld: config_db.asp
   Now, edit the string so it match your your location on the database file(liteforum.mdb) on your webserver.
   I think its good to put the databas i a separate dir, its mutch harder to hack the forum that way.
   like this:
   Your normal database path: \forum\liteforum.mdb
   Now put the database file in a dir like \forum\iut4qy08fg\liteforum.mdb
   Its good if you do it that way because the extra text will make it harder to hack the forum.
3. Upload everything to your server.
4. Now login with
   username: Admin
   password: admin
   Go to the profile selection and change your password.
   Now go to options and make your changes there too so the forum is the way you want it.
5. Done...

Sorry if there is any bad spelling in the texts i write..

Need help? Mail me: tim_hegyi@hotmail.com