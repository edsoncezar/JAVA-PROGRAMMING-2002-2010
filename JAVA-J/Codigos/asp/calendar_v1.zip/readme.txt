Web-Calendar v. 1.0

-------------------------------------------------------
Realized by

3net s.n.c.
Via Chiesanuova 148
35136 Padova - Italy

March 2001
-------------------------------------------------------

This calendar application is free and we do not offer
support due to time limitations. The application is build
in Asp3 code.

You can still contact us with your feedback. Thank you!

E-mail : fabio@trenet.it

-------------------------------------------------------

This application features :
> Browser-indipendent
> Symple to use and install
> Access 2000 database
> Friendly interface
> Absolutely Free

-------------------------------------------------------

If you find any bug please send us an

E-mail : fabio@trenet.it

-------------------------------------------------------

If you apport any modify to original code please send us
an e-mail.

New releases are coming... ;-)
