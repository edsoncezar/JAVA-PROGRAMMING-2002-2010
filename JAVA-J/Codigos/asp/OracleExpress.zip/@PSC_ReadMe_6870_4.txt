Title: Oracle Export with ASP
Description: This asp page allows the User to create a backup file of a database user's tables. This application uses Oracle Objects for OLE (OO4O) for database access and Oracle's Export utility for the backup process. This program also shows how to execute an executable file in the web server from the ASP page.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6870&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
