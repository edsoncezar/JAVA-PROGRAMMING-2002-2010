----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

IPRestrictor Object v3.0



summary:
===============
restricts a user from a given asp page if and only if their ip address
is stored in a database table representing restricted ip addresses.
Provides methods to add, remove and test a user's ip address to determine
if it is or is not restricted.



documentation:
===============
This file is considered to be the documentation for this example
as well as any notes in the source code of cls_iprestrictor.asp



installation:
===============
1.) required files from download package:
	cls_iprestrictor.asp
	restrictedAccess.asp
		
		* cls_iprestrictor.asp
			this file is the re-usable VBScript class.
			it should be included into any asp page that
			needs it's functionality. This file includes
			the properties and methods sheet for the object.
		
		* restrictedAccess.asp
			this file is an example of what has to happen
			in each page that calls the class above.

		* mydata.mdb
			the database that the class works with.
			


2.) place the required files from step 1 into the root directory 
    on the server.


3.) navigate to restrictedAccess.asp on your website with your web browser 
    to test.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/



Version History:
===============
	3.0 - 2/16/2003
		- Complete rewrite using a VBScript Class design.
		- Database connection strings are now properties of the class rather 
		  than hardcoded session variables which were problematic.
		- All known security issues were repaired.

	2.0 - 8/19/2000
		- modified to not use global.asa file for persistent 
		  db connections

	1.0 - 1/9/2000
		- initial release



Properties:
===============
	ConnString
		Required. String. Gets/Sets the connection string 
		to the database used
	
		set:
			obj.ConnString = string
		get:
			string = obj.ConnString

		You must set the ConnString property before using
		any of the methods of the class.

	ConnUser
		Optional. String. Gets/Sets the user id to use to
		access the specified database in the ConnString
		property (SQL Server only)
	
		set:
			obj.ConnUser = string
		get:
			string = obj.ConnUser

	ConnPass
		Optional. String. Gets/Sets the password to use to
		access the specified user id in the ConnUser
		property (SQL Server only)
	
		set:
			obj.ConnPass = string
		get:
			string = obj.ConnPass



Methods:
===============
	Restrict(ByVal ipaddr)
		Restricts the given ip address by adding it to the 
		database.

		obj.restrict "127.0.0.1"

	Free(ByVal ipaddr)
		Frees the given ip address by removing it from the 
		database.

		obj.free "127.0.0.1"

	Restricted(Byval ipaddr)
		Determines whether or not the given ip address has 
		been restricted.

		bool = obj.restricted("127.0.0.1")



Required database objects:
===============
	This vbscript wraps the following table and stored procedures
	which must be created in either sql server or ms access.


	CREATE TABLE restrictedAccess_IP
	(
	ID		Int		Identity(1, 1),
	restrictedIP	VarChar(255)	Not Null	Default ('Unknown or empty IP address')
	)



	CREATE PROCEDURE sp_RestrictAnIPAddress
	(
	@mIP		VarChar(255)
	)
	AS	
	INSERT INTO
	restrictedAccess_IP
	(restrictedIP)
	VALUES
	(@mIP)



	CREATE PROCEDURE sp_FreeAnIPAddress
	(
	@mIP		VarChar(255)
	)
	AS
	DELETE
	FROM
	restrictedAccess_IP
	WHERE
	restrictedIP = @mIP



	CREATE PROCEDURE sp_ValidationTestIP
	(
	@mIP		VarChar(255)
	)
	AS
	SELECT
	restrictedIP
	FROM
	restrictedAccess_IP
	WHERE
	restrictedIP = @mIP

