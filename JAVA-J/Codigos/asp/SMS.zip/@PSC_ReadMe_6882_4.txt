Title: SMS via HTTP for free - next generation
Description: This is the second generation of my code firing off SMS messages programmatically. You can make use of three different services: zetsms, mtnsms, ICQ.
From these three samples you can learn how to scrape screens in difficult situations. Each sites uses different tricks to prevent us from leveraging it. The zip file contains VB code and ASP code. For additional information be sure to visit http://www.klemid.de/vbsms.aspx.
New information (30-Oct-02): I uploaded my third generation of SMS code under "SMS via HTTP - third generation".

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6882&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
