InstaRemind V1.3

Thank you for downloading InstaRemind

This is a very straight forward program thats very easy to use.  Just unzip the zip files and upload to your site.  Everything is barebones and scaled down so you can easily implement it into your design.

This is freeware and can be changed and modified, just not redistributed under another name.

For the reminding service to work you'll need to set the server task scheduler to run the remind.asp everyday or use they server crontabs to do the same.  if those too options are not availible then you'll have to run remind.asp from your browser everyday.

Greg Bernhardt
ghb@uwm.edu

http://www.physicsforums.com
http://www.physicspost.com