Title: Send Email from ASP with attachment using CDONTS without getting unspeciefied error 80004005
Description: You can send an Email with attachment(s) from your ASP page using CDONTS. There is some code here on planet-source-code, but it does only work on the webserver itself, because the code does NOT first upload the attachment to the WebServer. This is neccesary, because the webserver the ASP is on cannot access your harddrive and pick up the file you want to send as attachment. If you don't, you get "Unspecified Error 80004005"
Make sure you have IIS with CDONTS (standard under IIS5) installed and the SMTP virtual server is running on the webserver.
The magnificent code to upload a file to a webserver is from Karl P. Grear and can be found on planet-source-code (Form Based File Upload Using Pure ASP).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6607&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
