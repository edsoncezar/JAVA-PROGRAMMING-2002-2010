Title: Talking IE
Description: I am developing this application for a physician who has lost his vision. This application is just a prototype, this browser will talk, from desk top. I have a request to viewer, if you wish to join and help, please email short stories. I shall thank his nephew who emailed me and my son who thought of sending a story that can talk. Kids have wonderful ideas, I wish I have their mind to think out of the shell. 
Win 98 users need to have Vtext.dll "CLSID:2398E32F-5C6E-11D1-8C65-0060081841DE" it comes with win2k prof/server. Also included in Microsoft Speech API 4.0a.
The First para responds to onmousemove. Once you have tested with your mouse, click yes if you get activx warning. Please press F5 and click on Read Text button. AudioPause did not work, I used StopSpeaking to stop audio. To start again, click Read Text. 
My regards to all viewers.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7274&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
