Easy Graphic Page Counter

This very simple page counter will count hits on a .asp page and display the result in graphic format. Can be used to count multiple pages. Uses the FileSystemObject to create/edit text files on the server. Graphic digits are included in this zip file. If you would prefer to make your own images, it is recommended that you use the same filenames as we did, to avoid extra modifications.

Setup and Instructions:

Create a folder in your cgi-bin. Name it "PageCntG". Upload "getHitCntG.asp" and "showHitCntG.asp, found in this zip, to the new folder. Make sure this folder has script or execute permissions set. Place all of the .gif image files anywhere. Open "showHitCnt.asp" in a text editor and change the Url to the images so it reflects the correct location.

On the top of every .asp page you wish to track, add this line of code:
<!-- #include virtual="/cgi-bin/PageCntG/getHitCntG.asp" -->

Then, anywhere on the same page where you want to display the count, write:
<!-- #include virtual="/cgi-bin/PageCntG/showHitCntG.asp" -->

That's all there is to it! A new log file is automatically created and updated on the server for each page you are tracking, and is placed in the "PageCntG" folder. (Please note that if you place "getHitCntG.asp" in a different directory, you will need to change the include file to reference the new location. Also note that if you want the log files to save in to a different directory, you will need to open "getHitCntG.asp" in a text editor and change the Urls to reflect the new location.)

Although formal support is not offered for this code, feel free to e-mail us with your questions. Send e-mail to: support@thewebhut.com or support@webpage-tools.com, and someone will be able to help within 48 hours. Thank you.

We always appreciate a small link back to our site, but of course, this is not required! 

<a href="http://www.WebPage-Tools.com/scripts/aspdownload.asp">ASP Scripts @ WebPage-Tools.com</a>

Thanks!

****************************************************************************
This zip file can be freely redistributed, so long as all files remain intact, including this readme document. This script is freeware, and may not be sold alone, or as part of any collection. 
****************************************************************************

The Web Hut [http://www.TheWebHut.com]
E-mail: [sales@thewebhut.com | design@thewebhut.com]

WebPage-Tools.com [http://www.WebPage-Tools.com]
E-mail: [support@webpage-tools.com]

****************************************************
