Web Wiz Guide Advanced Site Search Engine realease v1.70


****************************************************************************************
**  Copyright Notice    
**
**  Web Wiz Guide Advanced Site Search Engine
**                                                              
**  Copyright 2001-2002 Bruce Corkhill All Rights Reserved.                                
**
**  This program is free software; you can modify (at your own risk) any part of it 
**  under the terms of the License that accompanies this software and use it both 
**  privately and commercially.
**
**  All copyright notices must remain in tacked in the scripts and the 
**  outputted HTML.
**
**  You may use parts of this program in your own private work, but you may NOT
**  redistribute, repackage, or sell the whole or any part of this program even 
**  if it is modified or reverse engineered in whole or in part without express 
**  permission from the author.
**
**  You may not pass the whole or any part of this application off as your own work.
**   
**  All links to Web Wiz Guide and powered by logo's must remain unchanged and in place
**  and must remain visible when the pages are viewed unless permission is first granted
**  by the copyright holder.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR ANY OTHER 
**  WARRANTIES WHETHER EXPRESSED OR IMPLIED.
**
**  You should have received a copy of the License along with this program; 
**  if not, write to:- Web Wiz Guide, PO Box 4982, Bournemouth, BH8 8XP, United Kingdom.
**    
** 
**
**  No official support is available for this program but you may post support questions at: -
**  http://www.webwizguide.info/forum
**
**  Support questions are NOT answered by e-mail ever!
**
**  For correspondence or non support questions contact: -
**  info@webwizguide.com
**
**  or at: -
**
**  Web Wiz Guide, PO Box 4982, Bournemouth, BH8 8XP, United Kingdom
**
****************************************************************************************



Introduction
===========================================================================================
Thank you fordownloading this application and hoepfully you will find it of benefit to you.

If you have not downloaded this appliaction from Web Wiz Guide then check for the latest
version at: -

http://www.webwizguide.info


This applcation uses ASP and must be run through a web sever supporting ASP. 

It has been tested on PWS 4 and IIS 4 and 5 on Windows 2000/XP/NT4/98

You must also have the VB Scripting Engine version 5 or above installed on the web server
if you don't then you must download the simpler version of this script from Web Wiz guide.

===========================================================================================




Using the Advanced Site Search Engine
===========================================================================================

1. Unzip all the files to the same directory

2. Files must be run through an ASP enabled web sever (not the smae as CGI)

3. The site_search.asp file needs to be in the root directory of your website to be able 
to search all files on your site as it can only seach files in the directory the script is
placed in and files in sub directories

===========================================================================================





SETTING UP THE SEARCH SCRIPT
===========================================================================================

Open the script in Note Pad and near the top of the script you can set the following 
functions: -

1. How many results you want shown on each page

2. Set the file extension types you want the script to search, seperated by commas, the default 
is, htm, html, asp, shtml

3. Enter the names of the folders, seperated by commas, you don't want searched like 
adminstration folders or the cgi_bin

4. Enter the names of the files, (include the extension type ie .htm) seperated by commas, of 
the files you don't want searching like asp files that are only used for processing forms etc.

5. Set the English Language boolean to False if you are not using the script on an English 
Language web site.
===========================================================================================



Take Note!!!!
===========================================================================================
The speed at which the searching is done depends on how many files there are to search on 
the site, the load on the server, and the speed of the servers hard drives.

The  website search engine uses the Regular Expressions component which is needs to 
VBScript 5.0 scripting engine, which older servers may not support.  


WARNING!!!
Due to the complex nature of this script and the different ways directories are mapped on 
web servers the script is not guaranteed to run on all web sites so please check that the 
script runs with your web site on the web server before you take the time to customise it.

===========================================================================================




Tips For Better Search Results
===========================================================================================

The following tips will give more descriptive results from the site search engine also they 
will give your site higher ratings by search engines like Google, AstaVista, Lycos, etc.


1. Make sure each page of your site has a title otherwise the script will return a 'no title' 
for the page. Titles should be standard HTML titles as follows: -

	<title>PLACE YOUR PAGE TITLE HERE</title>


2. Make sure that each page has a meta description of what the page contains otherwise the 
results will return 'There is no description for this page'. Meta descritions should be 
standard HTML meta tags that the Internet search engines read: -

	<meta name="Description" content="PLACE PAGE DESCRIPTION HERE">
===========================================================================================





Compilation Errors
===========================================================================================

If you receive the following error: -

	Microsoft VBScript compilation error '800a03ea'
	Syntax error

It means that the server does not have the VBScript Engine version 5 or above installed, 
and so the script will NOT run on the web server you are using.

You will have to download the other simpler version of the Site Search Engine from Web 
Wiz Guide that does not require the VBScript Engine 5 to run. 

If you are running the server yourself you will have to download and install the latest 
VBScript Engine from Microsoft.
===========================================================================================




Problems running the Site Search Engine
===========================================================================================

If you are having trouble with the application then please take a look at the FAQ pages at: -

	http://www.webwizguide.info/asp/FAQ


If you are still having problems then post support questions, queries, suggestions, at: -
	
	http://www.webwizguide.info/forum 

The is no official support for this application as support costs a large amount of unpaid 
time that is not always available to devote to the many questions posted.

===========================================================================================





Donations
===========================================================================================

Many 1000's of unpaid hours have gone into developing this and the other applications 
available for free from Web Wiz Guide.

If you like using this application then please help support the development and update of 
this and future applications.

If you would like to remove the powered by logo from the application then you must make a 
donation to Web Wiz Guide.



You can send donations to: -

	Bruce Corkhill
	PO Box 4982
	Bournemouth
	BH8 8XP
	United Kingdom

Please make personal checks or International money orders payable to: - Bruce Corkhill
(Sorry, I can't cash anything made payable to Web Wiz Guide) 

Please don't send a foreign check drawn on a non-UK bank, as the fees usually exceed the 
value of the donation.



Or you can use your credit/debit Card or E-Check at PayPal, for US and International donators
or at NoChex for UK donators, via Web Wiz Guide's web site at: -

	http://www.webwizguide.info/donations

PayPal and NoChex are easy ways to send donations over the internet for free. You can use a 
credit/debit card or bank account and best of all it's fast, free and secure. 

===========================================================================================




Other ASP Applications
===========================================================================================

The following ASP Appliacations are available for free from http://www.webwizguide.info 

	ASP Discussion Forum
	ASP Guestbook
	Site Search Engine
	Weekly Poll
	Site News Administrator
	Internet Search Engine
	Mailing List
	Graphical Hit Counter
	Graphical Session Hit Counter
	Database Hidden Hit Counter
	Active Users Counter
	E-mail Form's
	Database Login Page

===========================================================================================




If I have missed anything out or any bugs then please let me know by e-mailing me at: -

asp@webwizguide.com

