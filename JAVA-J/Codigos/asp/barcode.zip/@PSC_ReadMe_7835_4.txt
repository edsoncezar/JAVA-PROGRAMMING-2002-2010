Title: Code 128 B barcodes
Description: Write "Code 128 B" barcodes to a web page with just a little bit of VBScript and a little HTML. Some people are charging so much for such a little thing. I wrote this so I wouldn't have to pay hundreds of dollars for it...and it was worth it. It was just a piece of cake... There are many other barcode standards out there, of course, but I leave those to someone else.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7835&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
