Title: RDS Like connection on a ASP Page with a Combo Box
Description: This is not real RDS but a simulation (Like Access's Not_In_List event). This functions gives the user the ability to 1) Add a new Value into a Database table and 2) update and select the value in the combobox WITHOUT REFRESHING the page from the server. I found this to be a life saver with large ASP pages with comboboxes on them that need to be dinamicaly filled. (You don't have to worry about the controls on the pages)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2661&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
