Session("UName") - When User login, he's name
Session("Status") - 0 - offline, 1 - Junior, 2 - member , 3 - intermediate, 4 - advanced, 5 - master (can add new category)
Session("UserID") = 0 - User ID number in database
Session("Rights") = 0 - user, 1 - moderator, 2 - admin
Session("CatId") = CatId
Session("GalId") = GalId
Session("Language") = 0 - English, 1 - Russian, 2 - Spanish, 3 - Deutche, etc. Make appropriate changes in lang.asp file