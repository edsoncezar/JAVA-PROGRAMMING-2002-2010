Thanks for downloading the ASP-DEv Diary script.

This is a very simple ASP app, that uses the built in VB Script date functions to display a calendar, that you can add events to.

All you need to do to install the script, is to open dbcon.asp, and change the path to the database to that of that on the server.

You must make sure this folder has write permissions set for the IUSER_???? account.

If you make use of this script, and feel like being generous, then you can send me a donation by visiting http://www.asp-dev.com/donate.asp

For support please visit the forums, at http://www.asp-dev.com/forum/.  