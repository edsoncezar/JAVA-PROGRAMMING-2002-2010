----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

Connecting to a database and retrieving results in 9 easy steps.



summary:
===============
An extremely simplified example to show beginners how to connect
to a database using the ActiveX Data objects and VBScript on the
server and how to process the returned results set.



documentation:
===============
documentation for this app is considered to be everything in this
document as well as the verbose notes included directly in the 
source code. Open dbconn.asp in notepad to view the source code.



installation:
===============
1.) determine what database you will be using. The type of database
    you choose determines what files you will need from the download
    package and how much preparation is involved before the software
    can be used without errors. Most examples come configured to run
    with the provided MS Access test database with no recoding necessary.

	> MS Access (DB provided in download)
	  ----------------------------------------------
		required files from download package:
			dbconn.asp
			mydata.mdb

		* The file dbconn.asp has been pre-configured to work
		  with the included MS Access database. The database is 
		  in Access 2000 format. MS Access 97 specific editions
		  of the database are not supported for use on the web 
		  but are available for downloading at the link below. 
		  You should use the 97 version only to view the 
		  structure of the database and only if you do not have
		  MS Access 2000 installed. The server does not need to
		  be running any version of MS Access to be able to read
		  the MS Access 2000 database.

		  http://www.aspemporium.com/aspEmporium/downloads/myData_db.asp

		* ms access databases require read/write/modify permissions
		  in the directory where they live to work properly. It is 
		  up to you to provide a directory with adequate read/write 
		  permissions for the database.

	> SQL Server (sql scripts provided in download)
	  ----------------------------------------------
		required files from download package:
			dbconn.asp
			examples.sql

		* sql server users must first run the examples.sql
		  script via query analyzer to set the database up
		  with the necessary objects. Please check to make
		  sure that nothing already exists in the database
		  with the same name because they will be dropped
		  in favor of new definitions in this script once 
		  it is run. By the time you realize you made a 
		  mistake, the script will have already run and you
		  cannot undo...

		* sql server users are responsible for populating
		  the newly created tables (if any) on your own.
		  via enterprise manager, you can import records from
		  the provided MS Access test database directly into
		  the newly created objects.

		* sql server users must change the database connection
		  string so that it does not use the provided MS Access
		  database but instead uses the database that you ran
		  the examples.sql script in. Please view the source
		  code of dbconn.asp for more information on changing 
		  the connection string.


2.) place the required files from step 1 into the same directory 
    on the server. (sql server users: you can discard examples.sql after you
    run it with query analyzer.) 


3.) navigate to dbconn.asp on your website with your web browser to execute
    the code.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. 



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/


