============================================
== Ocean12 ASP Mailing List Manager v1.06 ==
== http://scripts.ocean12tech.com         ==
============================================

=========================================================================
== If you are looking for more features than this software provides,   ==
== we suggest checking out the Ocean12 Mailing List Manager Pro, which ==
== includes many updates and upgrades from this script at a discount   ==
== rate.  To check it out, simply point your browser towards:          ==
==                                                                     ==
== http://www.ocean12scripts.com/scripts/mailinglist/                  ==
=========================================================================

====================
== Script History ==
====================
1.06  5/25/2002
      Corrected a few bugs
1.05  5/5/2002
      Corrected a few bugs
1.04  2/13/2002
      Added ability to use the ASPmail component for email sending
1.03  1/15/2002
      Added ability to use the ASPEmail component for email sending
1.02  10/17/2001
      Corrected a few bugs
      Added ability to sort subscribers by assending and descending order
      Added ability to search for subscribers
      Added ability to archive messages along with being able to search/sort those archived messages
      Added ability to send HTML or Text Mailings
      Added ability to generate HTML using your specified colors
1.01  10/4/2001
      Corrected a few bugs
1.00  9/21/2001
      Script Released

======================
== Copyright Notice ==
======================

The Ocean12 ASP Mailing List Manager is copyrighted �2001-2002 Ocean12 Technologies (http://www.ocean12tech.com). All Rights Reserved.

Use of this program is free of charge, although the "Maintained with the Ocean12 ASP Mailing List Manager v1.06" and "�2001-2002 Ocean12 Technologies, all rights reserved." text and links must remain unchanged at all times.

Selling the code for this program without prior written consent is expressly forbidden. Obtain permission before redistributing this software over the Internet or in any other medium. In all cases copyright information must be unchanged.

===================
== Documentation ==
===================

In order to provide you with the most up-to-date documentation for this program, we have placed the documenation on our website.  You can find it at:

    http://scripts.ocean12tech.com/asp/mailinglist/docs/

Thank you, and we hope you enjoy the Ocean12 ASP Mailing List Manager.