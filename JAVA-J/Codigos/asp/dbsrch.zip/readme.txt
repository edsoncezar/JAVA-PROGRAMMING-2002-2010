----------------------------------------------------------------
Example Script
http://www.aspemporium.com/
----------------------------------------------------------------

DBSearchEngine Object v2.0



summary:
===============
searches the ASP Emporium "examples" table for various criteria to 
illustrate how to search a table in a database.



documentation:
===============
This file is considered to be the documentation for this example
as well as any notes in the source code of cls_DBSearchEngine.asp



installation:
===============
1.) required files from download package:
	cls_DBSearchEngine.asp
	DB_Search_Engine.asp
	mydata.mdb
		
		* cls_DBSearchEngine.asp
			this file is the re-usable VBScript class.
			it should be included into any asp page that
			needs it's functionality. This file includes
			the properties and methods sheet for the object.
		
		* DB_Search_Engine.asp
			this file is an example of what has to happen
			in each page that calls the class above.

		* mydata.mdb
			the database that the class works with.
			


2.) place the required files from step 1 into the root directory 
    on the server.


3.) navigate to DB_Search_Engine.asp on your website with your 
    web browser to test.



known bugs:
===============
there are no known bugs.

send mail to bugs@aspemporium.com if you find one. I will grill you hard
so make sure that you're sure that it's a bug and not a problem with your 
server or configuration first. 99% of the time, the problem's on your end
however bugs have been found before in some apps. Bugs will be corrected
immediately by me and the source code updated. Unless otherwise noted in
the documentation, all apps work on windows 98, NT, 2000, ME, XP, any 
variation... assuming you have the most recent scripting engine and other
recent versions of common components like ADO.



updates/new versions:
===============
I regularly update and alter existing examples to add new functionality or
repair existing problems. Subscribe to the mailing list for an email whenever 
an example is updated or a new one is created:

	http://www.aspemporium.com/list/



support:
===============
Only the latest version of any app is supported. Older versions should be
scrapped for the latest version. In most cases, older properties and methods
are supported in newer versions if the example is a VBScript class or a 
JScript object. All examples require the most current scripting engines.

	support@aspemporium.com

	http://www.aspemporium.com/support/



Version History:
===============
	2.0   4/25/2001
		- new class interface
		- searches more fields
		- updated to reflect the newest "examples"
		  table in use at the ASP Emporium

	1.5   8/2000
		no longer uses a global.asa

	1.0   4/2000
		initial release



Properties:
===============
	DBConnectionString
		String. Required. DB Connection String.

	DBConnectionAccount
		String. Optional. DB Account Name.

	DBConnectionAcctPassword
		String. Optional. DB Account Password.

	bNoFieldsToSearch
		Boolean. Optional. Returns boolean indicating
		whether or not fields were selected to search.

	SearchType
		String. Required. Sets/returns the type of the
		search... Acceptable values are "AND" or "OR"


Methods:
===============
	SearchTitles
		Void. Calling this method will
		search any terms entered against titles.
		Must be called before the search method.

	SearchDescriptions
		Void. Calling this method will
		search any terms entered against descriptions.
		Must be called before the search method.

	Search(keywords)
		String. Required. Calling this method searches
		the string entered in the keywords argument
		against the ASP Emporium examples table.

	Count
		String. Returns the count of records
		found after the search method is called.
		Must be called after the search method.

	Version
		String. Returns the version of the class that
		you are running.



Required database objects:
===============
	This vbscript wraps the following table and stored procedures
	which must be created in either sql server or ms access.



	create table examples
	(
	exampleID int identity primary key,
	new int,
	exampleName varchar(255),
	exampleDesc text,
	examplePathName varchar(255),
	clicks int,
	examplevotes int,
	examplerating int,
	exampleversion varchar(255),
	lastmodifieddate datetime,
	firstcreateddate datetime,
	isnew int,
	isupdated int,
	examplelanguage varchar(255)
	)

