Title: Xml Menu System
Description: This class draws out a tree style menu from an xml file. Pretty simple if you look at it and will help with a better understanding of how xml and xml objects work. I've put in class form for functionality.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7574&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
