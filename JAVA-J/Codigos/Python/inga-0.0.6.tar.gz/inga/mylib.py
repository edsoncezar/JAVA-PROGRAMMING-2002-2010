#!/usr/bin/python
#################################################################
#
# Helper classes: opener, robot
#
# Program Copyright (C) 2000 Robert August Vincent, II
# Released under the GNU General Public License.  See LICENSE.txt
#
#################################################################

# Imports

from htmllib import HTMLParser
from formatter import NullFormatter
from urlparse import urlparse,urljoin
import md5
from signal import signal,SIGALRM,alarm
import re
from struct import unpack
from urllib import FancyURLopener
import MySQLdb
from ConfigParser import ConfigParser
import cgi
import Cookie
import os
import Image

imagetypes = {}
Image.init()
for filetype in Image.MIME.keys():
    imagetypes[Image.MIME[filetype]] = filetype

#################################################################
#
# "opener" is a subclass of urllib.FancyURLopener.  It overrides
# the "prompt_user_passwd" method to supply a static username
# and password instead of prompting the user.
#
#################################################################


class opener(FancyURLopener):

    def __init__(self,user,passwd,*args):
        apply(FancyURLopener.__init__, (self,) + args)
        self.methods = {'http':1}
        self.user = user
        self.passwd = passwd

    def prompt_user_passwd(self, host, realm):
        return self.user,self.passwd

#
# "robot" implements a generalized web crawler.
#
# Usage:
#
#   r = robot(iterator)
#   robot.run(url,opener)
#
# The robot recursively searches the network for files starting
# with a seed URL.
#
# It requires two helper classes, an "iterator" class, and an
# "opener" class.
#
# The "iterator" class performs actions on the file once it's
# loaded.  For instance, in the case of INGA (for which this
# module was written), the iterator makes thumbnails and loads
# graphic info into the database.  The iterator must define
# the following elements and methods:
#
# iterator ELEMENTS:
#
#   types	A dictionary object whose keys contain a list of
#		mime types that the iterator will accept, such as
#		'text/html', 'image/jpeg', 'image/gif', etc.
#
#   timeout	The number of seconds to try fetching any one
#		network file before giving up.
#
# iterator METHODS:
#
#   recurse(url)	Takes the URL of an html file or directory
#			path, and returns a boolean indicating
#			whether the robot should recursively load
#			files beneath it.
#
#   load(url)		Main callback function whereby the robot
#			hands urls to the iterator for action.
#
# The opener class should be derived from urllib.URLopener.  It
# does the actual work of loading a file from a URL.  It should
# also take care of supplying the username and password for
# password-protected resources.  In addition to the elements and
# methods defined in URLopener, this class should define the
# following element
#
# opener ELEMENT:
#
#    methods	A dictionary object whose keys contain a list of
#		network protocols that the opener will handle,
#		such as 'http', 'ftp', and (someday) 'smb'.
#
# Program Copyright (C) 2000 Robert August Vincent, II
# Released under the GNU General Public License.  See LICENSE.txt
#
#################################################################


def bin2hex(str):
    return('%08x%08x%08x%08x' % unpack('llll',str[:16]))

def safeint(str):
    try:
        return int(str)
    except:
        return 0

def sighandler(signum, frame):
    raise IOError

class robot:

    slashre = re.compile('/[^/]+/\.\./')
    hashre = re.compile('#.*')

    class urlfetcher(HTMLParser):
        def __init__(self,url,opener,robot):
            HTMLParser.__init__(self, NullFormatter(), 0)
            self.url = url
            self.opener = opener
            self.robot = robot
            
        
        def start_a(self,attrs):
            for attr in attrs:
                if attr[0]=='href':
                    self.robot.run(urljoin(self.url,attr[1],0),self.opener)
                    return

        def start_img(self,attrs):
            for attr in attrs:
                if attr[0]=='src':
                    self.robot.run(urljoin(self.url,attr[1],0),self.opener)
                    return

    def __init__(self,iterator,bufsize=65536):
        self.iterator = iterator
        self.bufsize = bufsize
        self.urls = {}

    def run(self,url,opener):
        url = self.slashre.sub('/',self.hashre.sub('',url))
        protocol,netloc,dirpath,dummy,dummy,dummy = urlparse(url,'http',0)
        url = protocol+'://'+netloc+dirpath
        if not opener.methods.has_key(protocol):
            return
        digest = bin2hex(md5.new(url).digest())
        if self.urls.has_key(digest):
            return
        self.urls[digest] = 1
        if not self.iterator.recurse(url):
            return
        signal(SIGALRM,sighandler)
        alarm(self.iterator.timeout)
        try:
            doc = opener.open(url)
            newurl = doc.geturl()
        except IOError:
            print 'IO Error opening',url,'in robot.run'
            self.iterator.fail(url)
            return
        alarm(0)
        doc.close()
        if newurl != url:
            self.run(newurl,opener)
            return
        filetype = doc.info().gettype()
        if not self.iterator.types.has_key(filetype):
            return
        alarm(self.iterator.timeout)
        try:
            localfile,info = opener.retrieve(url)
        except IOError:
            print 'IO Error retrieving',url,'in robot.run'
            self.iterator.fail(url)
            return
        alarm(0)
        doc = open(localfile,"r")
        # and digestify it
        m = md5.new()
        alarm(self.iterator.timeout)
        try:
            while 1:
                line = doc.read(self.bufsize)
                if not line:
                    break
                m.update(line)
        except IOError:
            doc.close()
            print 'IO Error reading',localfile,'in robot.run'
            self.iterator.fail(url)
            return
        alarm(0)
        digest = bin2hex(m.digest())
        # if we've seen it before
        if self.urls.has_key(digest):
            # don't do it again
            doc.close()
            return
        self.urls[digest] = 1
        # Else hand it over
        doc.seek(0)
        self.iterator.load(url,doc,info,digest)
        doc.seek(0)
        if filetype[:5]=='text/':
            # Go ahead and parse it
            p = self.urlfetcher(url,opener,self)
            while 1:
                line = doc.readline()
                if not line:
                    break
                p.feed(line)
            p.close()
        doc.close()

#################################################################
#
# "connect" is a subclass of MySQLdb that parses a config file
# for the relevant parameters so I don't have to inline-code
# them.
#
#################################################################


class connect(MySQLdb.connect):

    def __init__(self, **args):
        try:
            p = ConfigParser()
            if args.has_key('conf'):
                conf = args['conf']
                del args['conf']
            else:
                conf = 'conf/inga.conf'
            p.read(conf)
            for arg in ('host','db','user','passwd'):
                try:
                    args[arg] = p.get('inga',arg)
                except:
                    pass
        except:
            pass
        apply(MySQLdb.connect.__init__, (self,),args)


#################################################################
#
# "Cookie" is a subclass of the Cookie class from Cookie.py,
# using methods "borrowed" from slide 57, "Cookie example",
# by Guido van Rossum.
#
#################################################################



class cookieform(cgi.FieldStorage):

    def __init__(self, cnames={}, *args):
        apply(cgi.FieldStorage.__init__, (self,) + args)
        from Cookie import Cookie
        self.cookie = Cookie()
        try:
            self.cookie.load(os.environ['HTTP_COOKIE'])
        except KeyError:
            pass
        for cname in cnames.keys():
            try:
                cval = self[cname].value
            except KeyError:
                try:
                    cval = self.cookie[cname].value
                except KeyError:
                    cval = cnames[cname]
            self.cookie[cname] = str(cval)
            try:
                for item in self.list:
                    if item.name == cname:
                        item.value = cval
                else:
                    raise KeyError
            except:
                self.list.append(cgi.MiniFieldStorage(cname,str(cval)))
