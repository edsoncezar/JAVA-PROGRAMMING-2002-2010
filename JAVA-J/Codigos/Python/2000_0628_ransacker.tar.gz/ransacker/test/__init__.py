# test suite for zikesearch

import ransacker
import unittest
import os.path


from testWordHash import *

# a directory for storing our test files:
TESTDIR = "./test" 

class RansackerTestCase(unittest.TestCase):

    def setUp(self):

        self.idx=None; self.tearDown()
                
        self.idx = ransacker.Index(TESTDIR+"/test.rki")
        self.idx.index('first', 'my dog has fleas')
        self.idx.index('second', 'the cat in the hat')
        self.idx.index('third', 'the quick brown dog jumped over the lazy dog')
        

    def check_create(self):

        del self.idx
        self.idx = ransacker.Index(TESTDIR+"/test.rki", TESTDIR+"/words.rkw")

        for file in ["test.rki", "test.rkw", "words.rkw"]:
            assert os.path.isfile(TESTDIR+"/"+file), \
                   "didn't create " + file + "... :/"
        

    def check_search(self):
        actual = self.idx.search('dog')

        assert ('third' in actual) and ('first' in actual), \
               "search doesn't retrieve things that were indexed!"
            
        assert actual == ('third', 'first'), \
               "seach doesn't order results correctly!"


    def check_searchAfterChange(self):

        self.idx.index("third", "none of them canines here...")
        actual = self.idx.search('dog')

        assert actual == ('first',), \
               "search doesn't work after reindexing"

    def check_words(self):

        words = self.idx.wordHash.keys()
        # strip out NEXTNUM:
        words = filter(lambda w: w[:2]!="\t:", words)
        words.sort()

        assert words == [
            'brown','cat','dog','fleas', 'has',
            'hat','in','jumped','lazy','my','over',
            'quick','the'], "not all words were indexed!"




    def tearDown(self):
        del self.idx

        try:
            os.remove(TESTDIR+"/test.rki")
            os.remove(TESTDIR+"/test.rkw")
            os.remove(TESTDIR+"/words.rkw")
        except:
            pass
                
    

suites = {}
suites["ransacker"] = unittest.makeSuite(RansackerTestCase, "check_")
suites["wordhash"] = unittest.makeSuite(WordHashTestCase, "check_")
