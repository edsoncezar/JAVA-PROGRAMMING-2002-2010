#!/usr/bin/python
#
# viewportfolio.py
# Version:  2.0
# Release Date:  1 Nov 2000
#
# CVS: $Id$
#
# This program reads in information about your stock portfolio
# from a text data file and generates reports about the status
# of your portfolio.
# 
# See the README file or the NOTES section below for more
# information on usage.
#
# Note that this program relies entirely on Jonathan Corbet's
# "Quote.py" module which can be found at 
#
#     ftp://ftp.eklektix.com/pub/Quote/
#
# viewportfolio 2.0 has been tested with version 1.8 of Quote.py
# which should have been included with the source distribution
# of viewportfolio. Note that Jonathan has now included changes
# to the code which allow for quotes to be retrieved from
# uk.yahoo.com in addition to finance.yahoo.com.       
#
# If you have any comments about this program, of if you make
# an improved version, please contact Dan York at 
# dyork@lodestar2.com
#
# Copyright (c) 2000 Dan York, dyork@Lodestar2.com
# http://www.Lodestar2.com/software/viewportfolio/
#
# The author acknowledges significant contributions from 
# William McVey <wam@wamber.net> which have made this program
# much stronger. Thank you, William. At this point, I will be
# listing him as a co-author.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or any later version.
#
# This program is distributed in the hope that it will be useful
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details.
# http://www.gnu.org/copyleft/gpl.html
#
# -------------------------------------------------------------
# NOTES
#
# The program assumes a data file in the current directory called
# 'portfolio.dat' (unless changed by command-line options below)
# that has the following format:
#
# Ticker|Shares|InitialPrice
#
# The default delimiter is the pipe ('|') symbol, unless changed.
#
# Available command-line options include:
#
# -c          - compares current stock values against initial prices
# -d symbol   - use a different delimiter (i.e. -d ',' to use a comma)
# -f file     - uses data file 'file' instead of 'portfolio.dat'
# -h          - prints out help 
# -l          - prints a 'long' listing of more market data
# -v          - verbose output
# 
# The program assumes you have a live Internet connection and can
# pull data from finance.yahoo.com.
#
# As mentioned previously, this program relies on Jonathan Corbet's
# Quote.py module, so if you don't have it, you need to get it. A
# version is supplied with this code, but you may want to check his
# ftp site mentioned above to see if there is a newer version.
#
# To run the program using the provided sample 'portfolio.dat', 
# type (assuming a Unix/Linux prompt without '.' in your path):
#
#  $ ./viewportfolio.py
#
# To use several of the command line options at once, try:
#
#  $ ./viewportfolio.py -c -d ',' -f portfolio2.dat
#
# This does a comparison check using a data file 'portfolio2.dat'
# which uses a comma as a separator.
#
# -------------------------------------------------------------
# BUGS
#
#    It has been reported by one user that his mutual funds
#    report shares in up to three decimal places. viewportfolio
#    currently codes the shares as an integer and, as such,
#    truncates decimals.         
#
# -------------------------------------------------------------
# REVISION HISTORY
#
#  1 Nov 00 - 2.0 - integrated changes by William McVey which
#                   include allowing multiple stock entries
# 25 Jul 00 - 1.1 - fixed divide by zero error (gift stocks)
# 27 Apr 00 - 1.0 - first public release
# 25 Apr 00 - 0.1 - first beta release to a few people
#
# -------------------------------------------------------------


#
# import the other commands we need. 
#
import Quote
import getopt
from sys import argv, stdout, stderr, exit
from string import split, strip
from os import environ
# WAM: import copy.copy() for non-destructive summarizations of the portfolio
from copy import copy

#
# Set certain global constants
#
TRUE  = 1
FALSE = 0

#
# Define a class for the data type used to store the information
# for each stock.  The fields are the:
#   .symbol    - ticker symbol
#   .shares    - how many shares you have
#   .price     - the initial price you paid
#   .quote     - the quote obtained from Yahoo.com using Quote.py
#
# Note that .quote is a class itself that has a wide range of other
# options. See the Quote.py file for a full list of what is inside
# of a Quote data type
#
class PortEntry:
	# WAM: The portfolio object now does the type conversion from
	# string to the "actual" value type.  This allows the object
	# types to be added, multiplied, etc in the reports without having
	# to duplicate the conversions on every use.
   def __init__(self,content):
       self.symbol = content[0]
       self.shares = int(content[1])
       self.price = float(content[2])
       self.quote = Lookup(content[0])

	# provide a print mechanism for the class primarily for
	# debugging purposes
   def __repr__(self):
       return "%s\t%d\t%8.2f" % ( self.symbol, self.shares , self.price)

# WAM: this is new.  It impliments a cache-ing layer to Quote.Lookup()
# Performs a stock lookup and returns the Quote object associated
# with the passed in ticker name.  If that particular ticker has already
# been looked up, return the object that was cached.

ticker_cache = {}
def Lookup(ticker):
	# WAM:we might want to store these lookups in persistent storage (perhaps
	# using a shelve?) based on a commandline option.  Maybe usefull for 
	# marginally connected hosts or if the script is expected to be called
	# many times (eg, to view all the various reports) over a slow link.
	if ticker_cache.has_key(ticker):
		return ticker_cache[ticker]
	QuoteObject=Quote.Lookup(ticker)
	ticker_cache[ticker]=QuoteObject
	return QuoteObject

#
# Reads the data in from a data file.  It assumes a data file with
# the format:
# 
# Ticker|Shares|InitialPrice
#
# such as:
#
# CALD|100|25
# LNUX|100|40
#
# The pipe character is used as the delimiter by default.
#

def ReadData(infile,delim,verbose):
    if verbose == TRUE:
       print "Opening data file...",
    try:
       input=open(infile,'r')
    except:
	# WAM: Changed error message to be more descriptive
       stderr.write('viewportfolio: Error opening file ' + infile + '. \n')
       exit (1)

    if verbose == TRUE:
       print "done.\nGetting stock quotes..."

	# WAM: I changed the main data structures from being a dictionary
	# of quotes and an array to specify an order to just being an array
	# of quotes.
      # The main data structure is an array of PortEntry objects.
    portfolio = []

    # cycle through the list of stocks and load them in.
    for line in input.readlines():
          # split the line based on the delimiter
        x = split (line, delim)
	# WAM: Changed error message to go to stderr and to be more descriptive 
        if len(x) < 3:
           stderr.write('viewportfolio: ' + infile + ', line ' + str(i) +': bad data format: Not enough fields\n')
           exit (1)

        ticker=strip(x[0])

          # This is where the actualy quote lookup gets done. When
	  # a new PortEntry instance is created, part of it's 'init'
	  # function is to do a QuoteLookup
	entry = PortEntry(x)

	  # Add the portfolio entry into the portfolio dataset
	portfolio.append( entry )

	if verbose == TRUE:
	   print "Retrieved "+ ticker

    input.close()

    if verbose == TRUE:
       print "done."

    	# Return the list of stock quotes 
    return portfolio

# WAM:	Added so that the default and long reports can handle multiple 
#	purchases of the same stock as if it were one purchase.
#
# Takes an array of PortEntries and returns a new array indicating count of 
# how many of what stock is owned.  This routine uses copy.copy() so that
# the original portfolio and the objects it's built from are not modified.
# This should allow the passed in portfolio to be reused in other reports,
# if we should want to allow that in the future.

def SummarizePortfolio(portfolio):
	uniqportfolio={}
	for entry in portfolio:
		ticker=entry.symbol
		if uniqportfolio.has_key(ticker):
			orig = uniqportfolio[ticker]
			# Orig price becomes an average of all purchased prices
			# We don't use this value currently, but it might be
			# be usefull to someone.
			orig.price = (orig.price*orig.shares + entry.price*entry.shares) / (orig.shares + entry.shares)
			# shares becomes the total shares owned of this stock
			orig.shares = orig.shares + entry.shares
		else:
			uniqportfolio[ticker]=copy(entry)
	tickers=uniqportfolio.keys()
	tickers.sort()
	newportfolio=[]
	for ticker in tickers:
		newportfolio.append(uniqportfolio[ticker])
	return newportfolio

#
# Prints out a basic report:
# Stock   #Shares   CurrentPrice   CurrentValue
#
# where CurrentValue is just the #Shares multiplied by the CurrentPrice
# retrieved from Yahoo.com (and delayed 20 minutes)
#
def PrintPort(p):
	# set portfolio value to 0
    portvalue=0

    print 'Ticker \tShares \t%8s \t %8s' % ('Price','Value')

    for stock in p:
       currvalue=stock.quote.value* stock.shares
       portvalue = portvalue+currvalue
       print '%s \t%5d \t%8.2f \t%9.2f' % (stock.symbol, stock.shares,stock.quote.value, currvalue)

    print '\nTotal portfolio value : \t %8.2f\n' % (portvalue)

    PrintFooter()


#
# Prints out a long report:
# Stock   #Shares  Price   DailyChange  DailyHigh  DailyLow Volume CurrentValue 
#
# Note that this was just an arbitrary choice of parameters based on what
# I personally wanted to see and what I thought would fit into the screen
# on a typical xterm window.  See the README file or Quote.py for the
# full range of parameters that are possible.
#
def PrintLong(p):
	# set portfolio value to 0
    portvalue=0

    print '\nTicker\t%8s %8s %8s %8s %8s %13s %11s' % ('Shares','Price','Chg','High','Low','Volume','CurrVal')

    for stock in p:
       currvalue=stock.quote.value* stock.shares
       portvalue = portvalue+currvalue
       print '%s\t%8d %8.2f %8.2f %8.2f %8.2f %13s %11.2f' % (stock.symbol, stock.shares,stock.quote.value, stock.quote.change, stock.quote.high,stock.quote.low, comma(stock.quote.volume), currvalue)

    print '\nTotal portfolio value : \t %8.2f\n' % (portvalue)

    PrintFooter()


#
# Print out a report that compares the current valuation of your
# portfolio with the initial prices at which you bought the shares.
#
def PrintComp(p):
	# set current portfolio value to 0
    cportvalue=0
	# set initial portfolio value to 0
    iportvalue=0

	# WAM: Added column for per share purchase price, and the per share
	# delta from current price to purchase price.
    print '%7s %8s %8s %8s %8s %11s %11s %8s' % ('Ticker','Shares', 'PurPrice', 'CurPrice', 'Delta', 'CurVal','$Change','%Change')

    for stock in p:
	# calculate the current and initial values of the stock
       currvalue= stock.shares*stock.quote.value
       ivalue= stock.shares*stock.price
       pricediff = stock.quote.value - stock.price

	# add to the total value of the current and initial portfolio
       cportvalue = cportvalue+currvalue
       iportvalue = iportvalue+ivalue

        # calculate the difference in dollars between the current and
	# initial prices
       stockdiff = currvalue - ivalue
	#
        # calculate the percentage change btw current and initial
	#
	# 25 Jul 00 - added section here to deal with initial price
	# being 0 (i.e. gift of stock)
	#
       if ivalue != 0:
           stockchange = (stockdiff/ivalue)*100
           print '%-7s %8d %8.3f %8.3f %8.3f %11.3f %11.3f %8.2f' % (stock.symbol, stock.shares, stock.price, stock.quote.value, pricediff, currvalue, stockdiff,stockchange)
       else:
           print '%-7s %8d %8.3f %8.3f %8.3f %11.3f %11.3f %8s' % (stock.symbol, stock.shares, stock.price, stock.quote.value, pricediff, currvalue, stockdiff,"n/a")

     # print out summary data.
    print '\nTotal current portfolio value : \t %8.2f' % (cportvalue)
    print 'Total initial portfolio value : \t %8.2f' % (iportvalue)
    print 'Difference:\t\t\t \t %8.2f' % (cportvalue-iportvalue)
    print 'Percentage Change:\t\t \t %8.2f\n' % (((cportvalue-iportvalue)/iportvalue)*100)

    PrintFooter()

    
#
# Simply prints a generic footer at the end of the report.
#
def PrintFooter():
    print '\nAll stock quotes from Yahoo.com and delayed by 20 minutes.\n'


#
# Prints out help
#
def PrintHelp():
    print"\nThe program assumes a data file in the current directory called\n"+\
    " 'portfolio.dat' (unless changed by command-line options below)\n"+\
    "that has the following format:\n\n"+\
    "Ticker|Shares|InitialPrice\n\n"+\
    "The default delimiter is the pipe ('|') symbol, unless changed.\n" 

    print "Available command-line options include:\n\n"+\
    " -c          - compares current stock values against initial prices\n"+\
    " -d symbol   - use a different delimiter (i.e. -d ',' to use a comma)\n"+\
    " -f file     - uses data file 'file' instead of 'portfolio.dat'\n"+\
    " -h          - prints out help\n"+\
    " -l          - prints a 'long' listing of more market data\n"+\
    " -v          - verbose output\n"
    print "The program assumes you have a live Internet connection and can\n"+\
    "pull data from finance.yahoo.com.\n"


#
# This function is purely here for debugging. It just prints the
# list of stocks and the contents of the dictionary. It was called
# during development and testing and is left here in case there
# is a need for it in the future.
#
# WAM: Had to re-tool this for new datastructure.

def DebugPrint(portfolio):
  for entry in portfolio:
    print entry

#
# A function to put commas in the thousands and millions
# Thanks to Seth David Schoen at Linuxcare for providing
# this nice piece of code.
#
# 11 Sep 2000 - DY: A quick hacking session with Seth Schoen
# fixed the bug found by WAM where this function was not
# putting in leading zeros.
#
def comma(n):
        if n < 0:
                return "-" + comma(-n)
        if n < 1000:
                return str(n)
        return "%s,%s" % (comma(n/1000),real_comma(n % 1000))

def real_comma(n):
        if n < 1000:
                return "%03i" % (n)
        return "%s,%s" % tuple(map(real_comma,divmod(n,1000)))


#
# main function
#
def main():
   #set some more defaults
  compare = FALSE
  long = FALSE
  verbose = FALSE

# WAM: this change meets my prefered location for the datafile.  You might
# want to set it back if you want current directory to reign supreme.
#  homedir = environ["HOME"]
#  datafile = homedir + "/lib/portfolio"
#
# DY: For the moment, I'd like to leave it as is, but I'll leave the code
# here (above) in case someone else likes that idea better.

  datafile = "portfolio.dat"
  delimiter = '|'

   # see if there are command-line arguments
  try:
     opts, args = getopt.getopt(argv[1:],"chlvd:f:")
   # trap for non-permitted command-line options
  except getopt.error, msg:
	# WAM: re-wrote error message and exit on commandline botch.
     stderr.write("viewportfolio: commandline error: " + msg + "\n")
     exit(1)

   # scan throught the options and see what needs to be done.
  for i in opts:
     if i[0] == '-c':
         compare = TRUE
     elif i[0] == '-d':
         delimiter = i[1]
     elif i[0] == '-f':
         datafile = i[1]
     elif i[0] == '-h':
         PrintHelp()
	 exit(0)
     elif i[0] == '-l':
         long = TRUE
     elif i[0] == '-v':
         verbose = TRUE

   # go get the data (including the quote info)
  portfolio= ReadData(datafile,delimiter,verbose)

  # DebugPrint(portfolio)

   # print out the appropriate report
  if compare == TRUE:
      PrintComp(portfolio)
  elif long == TRUE:
      newport=SummarizePortfolio(portfolio)
      PrintLong(newport)
  else:
      newport=SummarizePortfolio(portfolio)
      PrintPort(newport)

#
# if the file is called directly on the command line (as compared
# to being imported), execute 'main()'
#

if __name__== '__main__':
  main()
