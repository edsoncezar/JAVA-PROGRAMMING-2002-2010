#!/usr/local/bin/python
#
# Antibot 1.0
#
#         File: png.py
#  Description: Vorras Antibot: prevents automatic form submissions.
#       Author: Haris Lekatsas
#        Email: info@vorras.com
#          Web: http://www.vorras.com/
#      Version: 1.0
#
# COPYRIGHT NOTICE:
#
# Copyright 2002 Vorras Corporation.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Vorras Corporation from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.

import sys
import os, sha
import struct
import zlib, random
from stat import *
from shutil import *
import time, re
from config import *
class IDAT:
    def __init__(self):
       self.filedata = ''    
       self.width = 0
       self.extrawidth = 0
    def compress(self):
       self.filedata = zlib.compress(self.filedata)
    def addFilesHorizontal(self, filenamelist, widths):
        try:
	    fd = []
	    for f in filenamelist:
               fd.append(open(f, 'rb'))
        except IOError:
            print "Could not open .dat file " + f
            sys.exit(0)
	verticalSpacers  = [3,6,9,12]
	try:
	   fd_vert = []
	   for f in verticalSpacers:
	      fd_vert.append(open('data/space'+`f`+'h.dat', 'rb'))
        except IOError:
            print "Could not open .dat file" + "space"+`f`+"h.dat"
            sys.exit(0)
	d_vert = ['']    
	for fdes in fd_vert:
           d_vert.append(zlib.decompress(fdes.read()))
	   fdes.close()
	d = []
	index = []
	for fdes in fd:
	   rand = random.randint(0,4)
	   rand2 = len(d_vert)-rand-1
           d.append(d_vert[rand]+zlib.decompress(fdes.read())+d_vert[rand2])
	   index.append(0)
	   fdes.close()
	spacers = []
	extrawidth = 0
	for i in range(0, len(d)):
	   space = random.randint(0,15)
	   extrawidth = extrawidth + space
	   spacers.append(space)  
        res = ''
        while index[0] < len(d[0]):
           res = res + d[0][index[0]]  
	   for i in range(0, len(index)): index[i]=index[i]+1
	   for j in range(0, len(d)):  
	      i = 0
	      while i<4*widths[j]:
		 R, = struct.unpack('B', d[j][index[j]+i])
		 G, = struct.unpack('B', d[j][index[j]+i+1])
		 B, = struct.unpack('B', d[j][index[j]+i+2])
		 a, = struct.unpack('B', d[j][index[j]+i+3])
		 if (R==255 and G==255 and B==255):
		    rand = random.randint(0,3)
		    if rand > 0:
		       R = 255; G = 255; B=255
                    else:
		       R = 0; G = 0; B=0
		 res = res + struct.pack('B', R)
		 res = res + struct.pack('B', G)
		 res = res + struct.pack('B', B)
		 res = res + struct.pack('B', a)
		 i = i + 4
	      for i in range(0, spacers[j]):
		 rand = random.randint(0,3)
		 if rand > 0:
		    R = 255; G = 255; B=255
                 else:
		    R = 0; G = 0; B=0
		 res = res + struct.pack('B', R)
		 res = res + struct.pack('B', G)
		 res = res + struct.pack('B', B)
		 res = res + struct.pack('B', 255)
	   for i in range(0, len(index)): index[i]=index[i]+4*widths[i]
	for fdes in fd:
           fdes.close()
	self.filedata = res
	width = 0
	for w in widths: width=width+w
	self.width = w + extrawidth
	self.extrawidth = extrawidth
class encodePNG:
    def __init__(self, filename, width=0, height=0):
        try:
            self.fd = open(filename, 'wb')
        except:
            print "Could not open file"
            sys.exit(0)
        self.width = width
        self.height = height
        self.crcTable = []
        for i in range(0,256):
           self.crcTable.append(0)  
        self.crcComputed = 0    
        self.makeCRCTable()
	self.IDAT = ''
        return
    def close(self):
        self.fd.close()
    def makeCRCTable(self):
        for n in range(0,256):
            c = n
            for k in range(0,8):
                if c & 1 != 0:
                    c = 0xedb88320L ^ (c >> 1)
                else:
                    c = c >> 1
            self.crcTable[n] = c
        self.crcComputed = 1
    def updateCRC(self, crc, buf, len):
        c = crc
        if not self.crcComputed:
            makeCRCTable()
        for n in range(0, len):
            c = self.crcTable[(c ^ buf[n]) & 0xff] ^ (c >> 8)
        return c
    def CRC(self, buf, len):
        return self.updateCRC(0xffffffffL, buf, len) ^ 0xffffffffL
    def writeBin(self, i, size):
        if size == 1:  
            self.fd.write(struct.pack('B', i))
        elif size == 4:  
            self.fd.write(struct.pack('>I', i))
        else:
            print "writeBin: unknown size"
    def header(self):
        return [137,80,78,71,13,10,26,10]
    def chunks(self):
        self.ihdr()
        self.idat()
        self.iend()
    def ihdr(self):
        length = 13
        type = [73,72,68,82]  
        data1 = []
        for x in struct.pack('>i', self.width):
            val, = struct.unpack('B', x)
            data1.append(val)
        for x in struct.pack('>i', self.height):
            val, = struct.unpack('B', x)
            data1.append(val)
        data2 = [
                8,              
                6,              
                0,              
                0,              
                0               
                ]
        crc = self.CRC(type+data1+data2, 17)
        self.writeBin(length, 4)
        for x in type:
            self.writeBin(x, 1)
        for x in data1:
            self.writeBin(x, 1)
        for x in data2:
            self.writeBin(x, 1)
        self.writeBin(crc, 4)
        return
    def idat(self):
        data = []
        for x in self.IDAT:
            tmp, = struct.unpack('B', x)
            data.append(tmp)
        type = [0x49,0x44,0x41,0x54]  
        self.writeBin(len(data), 4)   
        for x in type: self.writeBin(x, 1)
        self.fd.write(self.IDAT)
        crc = self.CRC(type+data, len(type)+len(data))
        self.writeBin(crc, 4)
        return
    def iend(self):
        self.writeBin(0, 4)  
        type = [73,69,78,68]  
        for x in type: self.writeBin(x, 1)
        self.writeBin(0xae, 1)
        self.writeBin(0x42, 1)
        self.writeBin(0x60, 1)
        self.writeBin(0x82, 1)
        return
    def create(self):
        for x in self.header():
            self.writeBin(x, 1)
        self.chunks()
        return
def removeOldFiles():
   for f in os.listdir(ImagePath):
      if re.search('test\w+.png', f):
         if int(time.time()-os.stat(ImagePath+'/'+f)[ST_MTIME]) > SecondsBeforeDeletion:
            os.remove(ImagePath+'/'+f)
def createHtml(seqstr):
   output = ''
   try:
      fd = open('templates/'+template, 'r')
   except IOError:
      print 'Could not open template file'
      sys.exit(0)
   while 1:
      line = fd.readline()
      if not line: break
      if re.search('xxxxIMAGEURLxxxx',line):
	 line = re.sub('xxxxIMAGEURLxxxx',ImageURL+'/test'+seqstr+'.png',line)
      if re.search('xxxxREALSEQUENCExxxx',line):
	 line = re.sub('xxxxREALSEQUENCExxxx',seqstr,line)
      if re.search('xxxxFORMACTIONxxxx',line):
	 line = re.sub('xxxxFORMACTIONxxxx',FormAction,line)
      output = output+line
   return output
def createPic():
    d = {0:'a',1:'b',2:'c',3:'d',4:'e',5:'f',6:'g',7:'h',8:'i',9:'j',10:'k',
	 11:'l',12:'m',13:'n',14:'o',15:'p',16:'q',17:'r',18:'s',19:'t',20:'u',
         21:'v',22:'w',23:'x',24:'y',25:'z',26:'0',27:'1',28:'2',29:'3',30:'4',
	 31:'5',32:'6',33:'7',34:'8',35:'9'}
    exclusions = [11,27]    
    comb = IDAT()
    sequence = []; seqstr = ''
    for i in range(0,NumberOfChars):
	rnd = random.randint(0,35)
	while rnd in exclusions: rnd = random.randint(0,35)
        sequence.append(d[rnd])
	seqstr = seqstr + d[rnd]
    n = 0
    flist = []
    widthlist = []
    while n < NumberOfChars:
       flist.append('data/'+sequence[n]+'.dat')
       widthlist.append(WidthOfChars)
       n=n+1
    comb.addFilesHorizontal(flist, widthlist)
    comb.compress()
    s = sha.new(seqstr)
    image=encodePNG(ImagePath+'/test'+s.hexdigest()+'.png',NumberOfChars*WidthOfChars+comb.extrawidth,HeightOfChars+12)
    image.IDAT = comb.filedata
    image.create()
    image.close()
    h = createHtml(s.hexdigest())
    print h
removeOldFiles()
createPic()
