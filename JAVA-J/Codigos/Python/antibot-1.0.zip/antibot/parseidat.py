#!/usr/local/bin/python
#
# Antibot 1.0
#
#         File: parseidat.py
#  Description: Vorras Antibot: prevents automatic form submissions.
#       Author: Haris Lekatsas
#        Email: info@vorras.com
#          Web: http://www.vorras.com/
#      Version: 1.0
#
# COPYRIGHT NOTICE:
#
# Copyright 2002 Vorras Corporation.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program
# you agree to indemnify Vorras Corporation from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.

import re, struct
import sys, zlib
from config import *
class IDATread:
   def __init__(self, filename):
      fields = re.split('\.', filename)
      if len(fields) > 0:
         self.filenameonly = fields[0]
         self.extension = fields[len(fields)-1]
         if self.extension != 'png':
            print 'Filename should end with .png'
            sys.exit(0)
      else:
         print 'Filename should end with .png'
         sys.exit(0)
      try:
         self.fd = open(filename, 'rb')
      except IOError:
         print 'Could not open png file'
         sys.exit(0)
      self.filename = filename
      self.data = ''     
   def close(self):
      self.fd.close()
      try:
         fd = open(self.filenameonly+ '.dat', 'wb')
      except IOError:
         print 'Could not open destination .dat file'
         sys.exit(0)
      fd.write(self.data)
      fd.close()
   def decompress(self, s):
      return zlib.decompress(s)
   def checkSig(self):
      sig = [137,80,78,71,13,10,26,10]
      for i in range(0,8):
         x = self.fd.read(1)
         tmp, = struct.unpack('B',x)
         if tmp != sig[i]:
            print 'This file is either not a PNG image or its corrupt'
            sys.exit(0)
   def readChunk(self, mode=''):
      ihdr = [73,72,68,82]
      idat = [0x49,0x44,0x41,0x54]
      iend = [73,69,78,68]
      len = self.fd.read(4)
      len, = struct.unpack('>I',len)  
      if len > 1000000:    
         len, = struct.unpack('<I',len)
      chunktype = []
      for i in range(0,4):
         x = self.fd.read(1)
         tmp, = struct.unpack('B',x)
         chunktype.append(tmp)
      if chunktype == idat:    
	 if mode == 'decomp':
            self.data=self.data+self.decompress(self.fd.read(len))
	 else:
            self.data = self.data + self.fd.read(len)
         crc = self.fd.read(4)   
      elif chunktype == iend:
         crc = self.fd.read(4)   
         return 'END'
      else:    
         x = self.fd.read(len+4)  
      return 'CONT'
   def parse(self, mode=''):
      self.checkSig()
      ret = 'CONT'
      while ret != 'END':
         ret = self.readChunk(mode)
if len(sys.argv) > 1: filename = sys.argv[1]
else:
   print "Please specify png file"
   sys.exit(0)
if len(sys.argv) > 2: 
   mode = sys.argv[2]
   if mode == 'decomp': pass
   else: 
      print "Unrecognized mode"
      sys.exit(0)
else: mode = ''
idat = IDATread(filename)
idat.parse(mode)
idat.close()
