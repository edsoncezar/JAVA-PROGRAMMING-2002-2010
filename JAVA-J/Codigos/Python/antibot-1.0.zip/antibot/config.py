# Antibot 1.0
#
#         File: png.py
#  Description: Vorras Antibot: prevents automatic form submissions.
#       Author: Haris Lekatsas
#        Email: info@vorras.com
#          Web: http://www.vorras.com/
#      Version: 1.0
#
# COPYRIGHT NOTICE:
#
# Copyright 2002 Vorras Corporation.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program
# you agree to indemnify Vorras Corporation from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.

ImagePath = '/usr/home/agri/usr/local/etc/httpd/vhosts/www.vorras.com/htdocs/images/antibot'
ImageURL = 'http://www.vorras.com/images/antibot'
NumberOfChars = 5   # Number of characters in one secret code
WidthOfChars = 25   # in pixels
HeightOfChars = 35   # in pixels
SecondsBeforeDeletion = 60   # seconds before old image files are deleted
template = 'template1'  #  set it to your own template file if you wish
                        # templates must be stored in the templates subdirectory
FormAction = 'http://www.vorras.com/cgi-bin/demo/antibot/pythonreply.cgi'  # URL to the script that checks the result

