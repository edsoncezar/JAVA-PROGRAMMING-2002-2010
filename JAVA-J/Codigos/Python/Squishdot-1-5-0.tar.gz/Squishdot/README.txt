Squishdot  
 
SquishDot is a web-based news publishing and discussion product for the  
Z Object Publishing Environment(ZOPE). It allows you to build a web-based 
news site along with the capability to handle threaded discussions with  
a minimum of configuration and day-to-day management. 
