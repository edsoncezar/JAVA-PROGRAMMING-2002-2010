# $Id: 0-3-x_0-4-x.py,v 1.6 2002/05/09 11:32:56 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log
from Products.Squishdot.Updaters import update_indexing
import sys

def do_update(self):
    """ Do the update """
    try:
        self.manage_renameObject('searchResults', 'showSearchResults')
        thestring = _log('','Renamed searchResults to showSearchResults')
    except:
        thestring = _log('','Failed to rename searchResults to showSearchResults:\nType:%s'%(sys.exc_type,))
        
    thestring = thestring + update_indexing.do_update(self)

    return thestring


def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])
