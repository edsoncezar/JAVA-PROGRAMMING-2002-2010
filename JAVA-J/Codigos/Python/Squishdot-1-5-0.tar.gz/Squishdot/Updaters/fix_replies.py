# $Id: fix_replies.py,v 1.5 2003/01/07 16:38:20 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log

def do_update(self):
    """ Set the reply count and moderated count to what they should be """
    
    for id in self.data.keys():
        obj = self.data[id]
        obj.revsub=0
        obj.reply_cnt=0
        
    for id in self.data.keys():
        obj = self.data[id]
        for tid in obj.thread:
            tobj = self.data[tid]
            if obj.reviewed:
                tobj.reply_cnt = tobj.reply_cnt + 1
            else:
                tobj.revsub = tobj.revsub + 1
                    
    return _log('','Fixing up reply counts and moderation counts')

def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])
