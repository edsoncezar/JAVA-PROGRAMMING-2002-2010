# $Id: fix_threading.py,v 1.3 2003/01/07 16:38:20 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log

def _recursor(self,dict,obj):
        for id in obj.ids:
            dict[id]={}
            _recursor(self,dict[id],self.data[id])

def _updatethread(self,dict,list):
    for id in dict.keys():
        theList = []
        for x in list:
            theList.append(x)
        
        self.data[id].thread = theList
                
        _updatethread(self,dict[id],list + [id])

def do_update(self):
    """ Do the update """
    root = {}
    _recursor(self,root,self)
    _updatethread(self,root,[])
    return _log('',"Threading fixed.")

def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])
            
