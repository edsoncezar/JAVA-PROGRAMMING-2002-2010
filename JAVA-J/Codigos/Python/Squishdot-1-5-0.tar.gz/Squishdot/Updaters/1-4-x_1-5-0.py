# $Id: 1-4-x_1-5-0.py,v 1.2 2003/01/08 10:11:57 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log
from Products.Squishdot.Updaters import fix_replies
from Products.Squishdot.Updaters import fix_indexes
from BTrees.IIBTree import IISet

def do_update(self):
    """ Do the update """
    thestring = ''
    
    # code to change intSets to IISets
    self.ids=IISet(self.ids)
    for posting in self.data.values():
        self.ids=IISet(self.ids)
    thestring = _log(thestring,'Converted intSets to IISets')
    
    # code to fix reply counts
    thestring = fix_replies.do_update(self)
    thestring = _log(thestring,'Fixed Threading.')
    
    # code to fix pre-2.4 indexes
    thestring = fix_indexes.do_update(self)
    thestring = _log(thestring,'Fixed indexes and re-catalogued.')

    return thestring


def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])




