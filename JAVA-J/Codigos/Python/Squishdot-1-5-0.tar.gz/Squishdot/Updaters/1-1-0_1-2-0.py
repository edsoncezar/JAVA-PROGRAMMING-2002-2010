# $Id: 1-1-0_1-2-0.py,v 1.2 2002/05/09 11:32:56 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log
from Products.Squishdot.Updaters import fix_replies
import sys

def do_update(self):
    """ Do the update """
    # code to fix reply counts
    thestring = fix_replies.do_update(self)
    
    # code to re-index everything
    self.recatalogPostings()
    thestring = _log(thestring,'Re-catalogued everything to be safe.')

    return thestring


def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])




