# $Id: update_indexing.py,v 1.4 2003/01/07 16:38:20 fresh Exp $
from Products.UpdateSupport.updatesupport import _updateall,_log

def do_update(self):
    """ Do the update """
    try:
        self.updateIndexing()
        return _log('','Updated indexing')
    except:
        return _log('','Update indexing failed. This may be because it has been done already')

def updateall(self):
    return _updateall(self,do_update, metatypes=['Squishdot Site'])
