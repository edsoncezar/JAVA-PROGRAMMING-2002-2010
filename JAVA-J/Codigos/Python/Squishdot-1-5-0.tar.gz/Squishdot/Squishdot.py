##############################################################################  
#   
# This software is released under the Zope Public License (ZPL) Version 1.0
#
# Copyright (c) Digital Creations.  All rights reserved.  
# Portions Copyright (c) 1999 by Butch Landingin.
# Portions Copyright (c) 2000-2001 by Chris Withers.
#   
##############################################################################  
     
__version__='$Revision: 1.41 $'[11:-2]     
     
# Make sure things are still accessible from where they used to be
from Posting import Posting,Comment
from Article import Article
from SquishSite import SquishSite
from Squishfile import Squishfile


