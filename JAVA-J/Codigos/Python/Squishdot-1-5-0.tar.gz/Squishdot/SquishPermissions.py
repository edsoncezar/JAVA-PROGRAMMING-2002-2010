##############################################################################  
#   
# This software is released under the Zope Public License (ZPL) Version 1.0
#
# Copyright (c) Digital Creations.  All rights reserved.  
# Portions Copyright (c) 1999 by Butch Landingin.
# Portions Copyright (c) 2000-2001 by Chris Withers.
#   
##############################################################################  
     
# Permissions used by Squishdot
ManageSquishdot =  'Manage Squishdot'
ModeratePostings = 'Moderate Postings'
AddPostings =      'Add Postings'
View =             'View'
