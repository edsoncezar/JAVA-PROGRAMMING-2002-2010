Wasp is an HTML preprocessor written in Python.

Read the document \static\readme.html for more.

This program and associated documentation are copyright (C) 2001-2 Robin Parmar. 