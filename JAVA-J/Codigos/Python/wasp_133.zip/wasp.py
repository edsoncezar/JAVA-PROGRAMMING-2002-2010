#!/usr/bin/py

"""
Program:
	wasp.py

Description:
	Wasp is an HTML preprocessor.
	Read the document static/readme.html for more.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

__version__ = '1.32 (2002.05.14)'

import string, sys, getopt, os, traceback, re
import waspHive, waspCookie

tab = ' ' * 2

def Banner():
	""" prints out welcome message. """
	print ''
	print 'Wasp HTML preprocessor version %s' % (__version__)
	print 'Copyright (C) 2001-2 Robin Parmar'
	print 'Wasp is licensed under the GPL. Check readme.html for more.'
	print ''

def Usage():
	""" prints out usage message """
	print ''
	print 'usage: wasp [-h] [-f] [-cFilespec] [inputFile...]'
	print '-h: help'
	print '-f: force translation (override date stamp)'
	print '-x: force exit; don\'t pause'
	print '-c: configuration file'
				
def Wasp2Html(in_files, options):
	""" converts list of input files to list of output files. """
	
	out_files = []
	for in_file in in_files:
		in_file2 = waspHive.RatioPath(in_file, options['path_output'], options['path_input'])
		(p, e) = os.path.splitext(in_file2)

		if e == '':
			raise 'myError', '%s has no extension.' % (in_file)
		elif e == options['wasp']:
			e = options['html']
		else:
			e = ''
			
		out_files.append( p + e )
	return out_files

def MakeIndex( in_files, tag_open, tag_close ):
	""" create alphabetic list of keywords in specified files. """
	key_words = []

	# escape tags
	tag_open	= string.replace(tag_open, '?', '\?')
	tag_close	= string.replace(tag_close, '?', '\?')

	# find index tag
	str = r'%s\s*?index\s*?:\s*?key\s*?%s' % (tag_open, tag_close)
	re_index = re.compile(str, re.S)

	# first, check our files for presence of wasp index tag
	index_files = []
	for in_file in in_files:
		contents = waspHive.ReadFile(in_file)
		if contents <> []:
			if re_index.search(contents):
				index_files.append(in_file)
			
	# then, process our list of files, parsing out META Keywords tag
	# <meta name="keywords" content="Python"> 
	rec = re.compile(r'.*?<meta\s*?name\s*?=\s*?"keywords"\s*?content\s*?=\s*?"(?P<tag_content>.*?)".*?', re.S | re.I)

	if index_files <> []:
		for file in in_files:
			contents = waspHive.ReadFile(file)
			if contents <> []:
				tag_done= rec.search(contents)
				if tag_done:
					word_list = tag_done.group('tag_content')
					words = string.split(word_list, ',')
					for word in words:
						word = string.strip(word)
						key_words.append( (string.lower(word), word, file) )
		key_words.sort()
	return index_files, key_words

def CommandLine():
	""" main sequence of events """

	Banner()

	# determine options.
	clOptions = waspHive.Options()
	try:
		clOptions.DoCommandLine()
	except 'Usage':
		Usage()
		
	print 'Reading configuration file.'
	clOptions.DoConfigFile()
	clOptions.DoArguement()
	waspFiles = clOptions.GetFileList()
	options = clOptions.GetOptionDict()

	
	# shared data
	global public
	public = {	'path_input'	: options['path_input'],
				'path_output'	: options['path_output'],
				'path_include'	: options['path_include'],
				'path_execute'	: options['path_execute'],
				'file'			: '',
				'directive'		: '',
				'option'		: ''
				}

	# add these keys for CGI compatibility
	public.update( {	'header'	: '',
						'cookie_in'	: waspCookie.CookieJar(),
						'cookie_out': waspCookie.CookieJar(),
						'query'		: {},
						'form'		: {},
						'cgi'		: {}
				})
	
	public['options'] = options

	# namespace for program execution
	namespace = {}
	namespace = clOptions.DoImport(namespace)
	del clOptions

	# build output file list
	if waspFiles == []:
		raise 'myError', 'no files to process!'
	htmlFiles = Wasp2Html( waspFiles, options )


	# check time stamp
	if options['force'] == 'off':
		# iterate backwards
		for i in range(len(waspFiles)-1, -1, -1):
			# remove items if source file is older
			if os.path.isfile(htmlFiles[i]):
				if os.path.getmtime(waspFiles[i]) <= os.path.getmtime(htmlFiles[i]):
					del waspFiles[i]
					del htmlFiles[i]


	# create any needed folders
	for file in htmlFiles:
		p = os.path.dirname(file)
		if p and not os.path.isdir(p):
			os.mkdir(p)


	#------------------
	# insert pre
	waspHive.Execute( options['path_input'], options['runpre'], namespace, public )


	#------------------
	# Pass 1: parse each wasp file
	if waspFiles == []:
		raise 'myError', 'no files to process!'

	sub1 = {	'include':	'include',
				'i':		'include',
				'macro':	'macro',
				'm':		'macro' }
	sub2 = {	'if':		'if',
				'end':		'null',
				'execute':	'execute',
				'e': 		'execute' }
	
	print 'Reading files: pass 1'
	count = 0
	for numFile in range(len(waspFiles)):
		print tab + waspFiles[numFile]
		
		myWasp = waspHive.waspObject( options, namespace, public )
		myWasp.Read( waspFiles[numFile] )
		begin = myWasp.GetInput()
		end = ''

		# do substitutions until no more exist
		while begin <> end:
			begin = myWasp.GetInput()
			if myWasp.Parse( sub1 ):
				break
			if myWasp.Parse( sub2 ):
				break
			end = myWasp.GetOutput()
		
		myWasp.Write( htmlFiles[numFile] )
		del myWasp
		count = count + 1

	print 'Processed %s files.' % (count)


	#------------------
	# insert mid
	waspHive.Execute( options['path_input'], options['runmid'], namespace, public )


	#------------------
	# Pass 2: index
	# get list of files containing index and list of keyword
	(index_files, key_words) = MakeIndex(htmlFiles, options['tag_open'], options['tag_close'])
	if index_files <> []:
		print ''
		print 'Indexing files: pass 2'
		
		# create banner	
		ban = options['indexbannertop'] == 'on' or options['indexbannertail'] == 'on'
		if ban:
			bannerText = options['indexbanneropen'] 
			for alpha in string.uppercase:
				bannerText = bannerText + '<A HREF="#' + alpha + '">' + alpha + '</A>' + options['indexbannersep']
			bannerText = bannerText + options['indexbannerclose'] + '\n'

		# process each file with an index	
		substituteThese = {	'index':	'index',
							'x':		'index' }
		count = 0
		for indexFile in index_files:
			text = ''
			if options['indexbannertop'] == 'on':
				text = text + bannerText

			for alpha in string.uppercase:
				if ban:
					text = text + '<A NAME="' + alpha + '"</A>'
				text = text + options['indexletteropen'] + alpha + options['indexletterclose']
				sep = 0
				for keyLow, key, file in key_words:
					if key <> '' and string.upper(key[0]) == alpha:
						if sep:
							text = text + options['indexlettersep']
						sep = 1
						text = text + '<A HREF="' + waspHive.Relative(file, indexFile) + '">' + key + '</A>'

			if options['indexbannertail'] == 'on':
				text = text + bannerText

			public['text'] = text

			print tab + indexFile
			myWasp = waspHive.waspObject( options, namespace, public )
			myWasp.Read( indexFile )
			myWasp.Parse( substituteThese )
			myWasp.Write( indexFile )
			del myWasp
			count = count + 1
		print 'Processed %s files.' % (count)


	#------------------
	# Pass 3: sequence
	sequence = options['sequence']
	if sequence <> []:
		print ''
		print 'Sequencing files: pass 3'
		
		# form full file paths and check for existence
		for x in range(len(sequence)):
			ok = 0
			file_path = os.path.join(options['path_output'], sequence[x][0] + options['html'])

			if os.path.isfile(file_path):
				ok = 1
				sequence[x] = ( file_path, sequence[x][1] )
			if not ok:
				raise 'myError', '%s is not found. Can\'t process sequence' % (file_path)
			
	options['sequence'] = sequence
	substituteThese = {	'seq':		'sequence',
						's':		'sequence' }
	if sequence <> []:
		count = 0
		for file, indent in sequence:
			print tab + file
			myWasp = waspHive.waspObject( options, namespace, public )
			myWasp.Read( file )
			myWasp.Parse( substituteThese )
			myWasp.Write( file )
			del myWasp
			count = count + 1
		print 'Processed %s files.' % (count)


	#------------------
	# insert post
	waspHive.Execute( options['path_input'], options['runpost'], namespace, public )

	return options['exit'] == 'off'


if __name__ == '__main__':
	# this program is designed to run as top-level
	
	pause_exit = 1
	try:
		pause_exit = CommandLine()
		exitCode = 0
	except 'myError', err:
		print err
		exitCode = 1
	except:
		traceback.print_exc()
		exitCode = 2

	if pause_exit:
		print ''
		print 'Press <return> to continue...'
		sys.stdin.readline()
	sys.exit(exitCode)
