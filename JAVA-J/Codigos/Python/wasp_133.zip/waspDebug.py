"""
Program:
	waspDebug.py

Description:
	Debugging modules and classes.
	
	* Datagram class allows generic message passing.
	* Debugagram class customises this for Wasp debug messages.
	* Debug() is the top-level function you should call.
	* Terminate() allows quick server shutdown.
	* Watch() allows you to monitor variables.

	Note that this module is not likely to work correctly in an
	interactive	development environment like PythonWin, since
	such IDEs grab control over the trace stack.
	
Usage:
	* Run waspDebugServer.py on the computer you wish to use as a monitor.
	* In your Wasp configuration file, make sure you have a debug entry
		in the [cgi] section. This should contain the IP address of the
		computer on which waspDebugServer.py is running.
		Eg: "debug : 192.168.1.27"
	* Put this line at the top of any module you wish to remotely debug:
		from waspDebug import Debug
	* Whenever you wish to see the value of a variable, use this command:
		Debug(my_variable)
	* This will send a debug line to the server which will be displayed and
		logged. These lines are of the format:
		time_stamp => module => method => line => <var_type> var => var_value
	* If you wish to simply trace execution, omit the variable, like so:
		Debug()
	* In this case the message omits the last two items, thus:
		time_stamp => module => method => line
	* Messages are not guaranteed to be received in the order they are sent,
		but on a simple network with a single path, they should be.
	* The timestamp is generated at the client, so you could sort on this
		field to accurately put messages in order.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import socket, os, traceback, time, sys
import waspHive

class Datagram:
	"""
		Datagram class with both client and server.
	"""
	def __init__(self, host='localhost', port=8081, bite=1024):
		self.wait	= 0.2
		self.host	= host
		self.port	= port
		self.bite	= bite
		self.pause	= 0
		self.name	= 'Datagram Server'
		self.mg_end		= '[END]'
		self.mg_cls		= '[CLS]'
		self.mg_pause	= '[PAUSE]'
		self.mg_resume	= '[RESUME]'

		# platform-dependent command to clear the display
		# you may wish to add more
		if sys.platform in ('linux-i386', 'linux2'):
			self.clear = 'clear'
		elif sys.platform in ('win32', 'dos', 'ms-dos'):
			self.clear = 'cls'
		else:
			self.clear = ''

	def Server(self, log=''):
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.bind(('', self.port))

		print '%s waiting on port: %d' % (self.name, self.port)

		# start log
		if log:
			l = waspHive.Log(log)
		
		# just keep listening
		while 1:
			time.sleep(self.wait)
			
			try:
				data, addr = s.recvfrom(self.bite)
				data = str(data)
				
				if data == self.mg_end:
					break
				elif data == self.mg_cls:
					os.system(self.clear)
				elif data == self.mg_pause:
					self.Pause()
				elif data == self.mg_resume:
					self.Resume()
				else:
					if not self.pause:
						print self.PrintFormat(data)

				if log and not self.pause:
					l.Write( self.LogFormat(data) )
				
			except socket.error, err:
				print '** %s **' % err

		# stop log
		if log:
			del l

	def SendFormat(self, msg):
		"""
			Custom message formatting: sender.
			Parameter can be any data type you like.
			Return value must be a string.
			Over-ride in subclass.
		"""
		return str(msg)

	def PrintFormat(self, msg):
		"""
			Custom message formatting: server console output.
			Parameter can be any data type you like.
			Return value must be a string.
			Over-ride in subclass.
		"""
		return str(msg)

	def LogFormat(self, msg):
		"""
			Custom message formatting: server logging.
			Parameter can be any data type you like.
			Return value must be a string.
			Over-ride in subclass.
		"""
		return str(msg)

	def Send(self, msg):
		"""
			Client component of datagram.
			Sends message to server. Order of receiving not guaranteed.
			Parameter can be any data type you like.
		"""
		if not self.pause:
			s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			s.bind(('', 0))
			
			# custom formatting
			if type(msg) is type('') and \
					msg in (self.mg_end, self.mg_cls, self.mg_pause, self.mg_resume):
				pass
			else:
				msg = self.SendFormat(msg)

			# chunk up message and send
			while msg:
				s.sendto(msg[:self.bite], (self.host, self.port))
				msg = msg[self.bite:]
			
	def Terminate(self):
		"""
			Terminate server by sending magic string.
		"""
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.bind(('', 0))
		s.sendto(self.mg_end, (self.host, self.port))
			
	def Clear(self):
		"""
			Terminate server by sending magic string.
		"""
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.bind(('', 0))
		s.sendto(self.mg_cls, (self.host, self.port))
			
	def Pause(self):
		self.pause = 1

	def Resume(self):
		self.pause = 0

class Debugagram(Datagram):
	"""
		Datagram debugger.
	"""
	def __init__(self, host='localhost', port=8081, bite=1024):
		Datagram.__init__(self, host, port, bite)
		self.name = 'Debugagram Server'

	def SendFormat(self, msg):
		"""
			Custom message formatting: sender.
			Return value must be a string.
			Parameter is a tuple of location, text.
		"""
		f_name, m_name, m_line, v_type, v_name, v_value = msg

		# only first variable
		hit = v_name.find(',')
		if hit > -1:
			v_name = v_name[:hit]

		ret = AccurateTime()
		ret += ' > %s > %s > %d' % (f_name, m_name, m_line)
		if v_type:
			ret += ' > %s <%s> = %s' % (v_type, v_name, v_value)

		return ret

	def PrintFormat(self, msg):
		"""
			Custom message formatting: server console output.
			Return value must be a string.
			Parameter can be any data type you like.
		"""
		return msg[9:] + '\n'

	def LogFormat(self, msg):
		"""
			Custom message formatting: server logging.
			Parameter can be any data type you like.
			Return value must be a string.
		"""
		return str(msg)

def AccurateTime():
	now_c = time.clock()
	now_t = time.time()
	
	ret = time.strftime('%y.%m.%d %H:%M:%S', time.localtime( now_t ))

	# process thousandths of seconds
	sec = str(round(now_c, 3))
	sec = sec[sec.find('.'):] + '000'

	return ret + sec[:4]

def Terminate(server=None):
	"""
		Top-level routine.
		Call this directly from running program to terminate server.
	"""
	if not server:
		options = waspHive.GetPublic('options')
		if options and options.has_key('debug'):
			server = str(options['debug'])

	if server:
		Debugagram(server).Terminate()
	
def Clear(server=None):
	"""
		Top-level routine.
		Call this directly from running program to clear server display.
	"""
	if not server:
		options = waspHive.GetPublic('options')
		if options and options.has_key('debug'):
			server = str(options['debug'])

	if server:
		Debugagram(server).Clear()
	
def Debug(var=None, server=''):
	"""
		Top-level routine.
		Call this directly from running program to send debug message.
		Sends to server current file position and value of variable (if provided).
	"""
	if not server:
		options = waspHive.GetPublic('options', 'debug')
		if options:
			server = str(options)

	if server:
		if var in ('[END]', '[CLS]', '[PAUSE]', '[RESUME]'):
			msg = var			
		else:
			# grab stack 
			f_name, m_line, m_name, m_pop = traceback.extract_stack()[-2]
			if m_name == '?':
				m_name = '[top]'

			fd, fn, fx = waspHive.ParseFile(f_name)
			f_name = fn + fx
				
			# get variable info
			if m_pop and var is not None:
				v_name	= m_pop[ m_pop.find('(')+1 : m_pop.find(')') ].strip()
				v_type	= str( type(var) )[7:-2]
				v_value	= repr(var)
			else:
				v_name = v_type = v_value = ''
				
			msg = (f_name, m_name, m_line, v_type, v_name, v_value)
			
		Debugagram(server).Send(msg)
		
def Watch(var=None):
	"""
		Return current file position and value of variable (if provided).
	"""
	# grab stack 
	f_name, m_line, m_name, m_pop = traceback.extract_stack()[-2]
	if m_name == '?':
		m_name = '[top]'
		
	ret = '%s > %s > %d' % (f_name, m_name, m_line)

	# get variable info
	if m_pop and var is not None:
		v_name	= m_pop[ m_pop.find('(')+1 : m_pop.find(')') ].strip()
		v_type	= str( type(var) )[7:-2]
		v_value	= repr(var)
		ret += '\n%s <%s> = %s' % (v_type, v_name, v_value)

	return ret

def Testdebug():
	import sys
	if len(sys.argv) < 2:
		# test client
		d = Datagram()
		d.Send('Hello there server.')
		d.Pause()
		d.Send('How are you?')
		d.Resume()
		d.Send('Not answering?')
		d.Terminate()
		d.Send('Let us try again.')
	else:
		# start server:
		Datagram().Server('debug.log')

def Testwatch():
	print
	animal = 'dog'

	# watch a variable
	print Watch(animal)
	
	# or just watch a position in the file
	print Watch()

if __name__ == "__main__":
	if 1:
		Testwatch()
		
	if 0:
		Testdebug()

	import os, sys

	(head, tail) = os.path.split(sys.argv[0])
	if tail is None:
		# we just got invoked in the current working directory
		path = os.getcwd()
	else:
		# head contains a relative path to where we were invoked from
		path = os.path.abspath(head)
	print path