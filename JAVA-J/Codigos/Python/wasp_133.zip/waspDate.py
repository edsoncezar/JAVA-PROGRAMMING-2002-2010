"""
Module:
	waspDate.py

Description:
	Provides a Date class with arithmetic and conversion methods, as well
	as a Python implementation of strptime.

	The following date formats are supported:
		Unix time: seconds since the epoch
		Standard Python string tuple
		ISO string format: yyyy-mm-dd hh:mm:ss
		ANSI string format: yyyy.mm.dd hh:mm:ss
		COM format
		Julian day number: days since beginning of calendar

	The Date class and related routines were originally written by
	Gon�alo Rodrigues. My version is simplified through using Julian
	numbers for most calculations. The included implementation of strptime
	is modified from that by Brett Cannon.

	Localisation has been added for: English, Swedish, French, German, Italian,
	and Spanish. Only the first two are completely implemented.

	Requires Python 2.2.

	Deprecates waspLocale.py

Limitations:
	* In making conversions, local time is always used.
	
	* Only works for dates since the definitive adoption of the Gregorian
	  calendar (varies by country). Unless you're a historian, that's probably ok.

Copyright:
	(C) 2002 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

Original Copyrights:
	(C) 2002 Gon�alo Rodrigues
			[version 2.0 2002.03.05]
	(C) 2002 Brett Cannon <drifty@bigfoot.com>
			[version 2.0 2002.03.05]
"""

import time, re
from exceptions import Exception
from waspDebug import Debug
ip = '192.168.1.126'

# this is what we export
__all__ = ['IsLeapYear', 'DaysInYear', 'DaysInMonth', 'DayofWeek',\
		   'GregToJulian', 'GregToModifiedJulian', 'JulianToGreg',\
		   'Date', 'Locale', 'MegaDate']

LOC_GB = (
	{'%a':r'(?P<a>[^\s\d]{3,3})', 					# Abbreviated weekday name.
	 '%A':r'(?P<A>[^\s\d]{6,9})', 					# Full weekday name.
	 '%b':r'(?P<b>[^\s\d]{3,3})', 					# Abbreviated month name.
	 '%B':r'(?P<B>[^\s\d]{3,9})', 					# Full month name.
	 '%c':r'(?P<m>\d\d)/(?P<d>\d\d)/(?P<y>\d\d) (?P<H>\d\d):(?P<M>\d\d):(?P<S>\d\d)', # Appropriate date and time representation.
	 '%p':r'(?P<p>(a|A|p|P)(m|M))', 				# Equivalent of either AM or PM.
	 '%x':r'(?P<m>\d\d)/(?P<d>\d\d)/(?P<y>\d\d)', 	# Appropriate date representation.
	 '%X':r'(?P<H>\d\d):(?P<M>\d\d):(?P<S>\d\d)'}, 	# Appropriate time representation.
	{'January':1,		'Jan':1,
	 'February':2,		'Feb':2,
	 'March':3,			'Mar':3,
	 'April':4,			'Apr':4,
	 'May':5,
	 'June':6,			'Jun':6,
	 'July':7,			'Jul':7,
	 'August':8,		'Aug':8,
	 'September':9,		'Sep':9,
	 'October':10,		'Oct':10,
	 'November':11,		'Nov':11,
	 'December':12,		'Dec':12},
	{'Monday':0,		'Mon':0,   # Adjusted for Monday-first counting.
	 'Tuesday':1,		'Tue':1,
	 'Wednesday':2,		'Wed':2,
	 'Thursday':3,		'Thu':3,
	 'Friday':4,		'Fri':4,
	 'Saturday':5,		'Sat':5,
	 'Sunday':6,		'Sun':6},
	(('am','AM'),('pm','PM')),
	(('day', 'days'), ('hour', 'hours'), ('minute', 'minutes'), ('second', 'seconds'))
	)
LOC_SE = (
	{'%a':r'(?P<a>[^\s\d]{3,3})',
	 '%A':r'(?P<A>[^\s\d]{6,7})',
	 '%b':r'(?P<b>[^\s\d]{3,3})',
	 '%B':r'(?P<B>[^\s\d]{3,8})',
	 '%c':r'(?P<a>[^\s\d]{3,3}) (?P<d>[0-3]\d) (?P<b>[^\s\d]{3,3}) (?P<Y>\d\d\d\d) (?P<H>[0-2]\d):(?P<M>[0-5]\d):(?P<S>[0-6]\d)',
	 '%p':r'(?P<p>(a|A|p|P)(m|M))',
	 '%x':r'(?P<m>\d\d)/(?P<d>\d\d)/(?P<y>\d\d)',
	 '%X':r'(?P<H>\d\d):(?P<M>\d\d):(?P<S>\d\d)'},
	{'Januari':1,   'Jan':1,
	 'Februari':2,  'Feb':2,
	 'Mars':3,	  'Mar':3,
	 'April':4,	 'Apr':4,
	 'Maj':5,	   'Maj':5,
	 'Juni':6,	  'Jun':6,
	 'Juli':7,	  'Jul':7,
	 'Augusti':8,   'Aug':8,
	 'September':9, 'Sep':9,
	 'Oktober':10,  'Okt':10,
	 'November':11, 'Nov':11,
	 'December':12, 'Dec':12},
	{'M�ndag':0,	'M�n':0,
	 'Tisdag':1,	'Tis':1,
	 'Onsdag':2,	'Ons':2,
	 'Torsdag':3,   'Tor':3,
	 'Fredag':4,	'Fre':4,
	 'L�rdag':5,	'L�r':5,
	 'S�ndag':6,	'S�n':6},
	(('am','AM'),('pm','PM')),
	(('dag', 'dagar'), ('timm', 'timmar'), ('minut', 'minuter'), ('sekund', 'sekunder'))
	)

# locales need to be filled in for other countries -- volunteers?
LOC_FR = LOC_GB
LOC_DE = LOC_GB
LOC_IT = LOC_GB
LOC_ES = LOC_GB

try:
	# needed for conversion to (not from) COM dates
	import pythoncom
	com_works = 1
except:
	com_works = 0

class DateError(Exception):
	def __init__(self, args=None):
		self.args = args

def Pluralise(num, text):
	"""
		Pluralisation, using tuple of strings (singular, plural).
	"""
	if num==1:
		t = text[0]
	else:
		t = text[1]
	
	return '%d %s' % (num, t)

def IsLeapYear(year):
	"""
		Returns 1 if year is a leap year, 0 otherwise.
	"""
	if year%4 == 0:
		if year%100 == 0:
			if year%400 == 0:
				return 1
			else:
				return 0
		else:
			return 1
	else:
		return 0

def DaysInYear(year):
	"""
		Returns the number of days in the year.
	"""
	return 365 + IsLeapYear(year)

def DaysInMonth(year=None, month=None):
	"""
		Returns the number of days in the month.
		Parameters default to current month and year.
	"""
	if month is None:
		m = time.localtime()[1]
	else:
		m = month

	if year is None:
		y = time.localtime()[0]
	else:
		y = year
	
	if m == 2:
		if IsLeapYear(y):
			return 29
		else:
			return 28
	elif m in (1, 3, 5, 7, 8, 10, 12):
		return 31
	else:
		return 30

def DayofWeek(year=None, month=None, day=None):
	"""
		Returns the day of the week, with Monday 0.
		Parameters default to current year, month, and day.
	"""
	if year is None:
		y = time.localtime()[0]
	else:
		y = year

	if month is None:
		m = time.localtime()[1]
	else:
		m = month

	if day is None:
		d = time.localtime()[2]
	else:
		d = day

	a = (14-m)//12
	y = y - a
	m = m + 12*a - 2
	dw = (d + y + (y//4) - (y//100) + (y//400) + ((31*m)//12)) % 7

	if dw == 0:
		dw = 6
	else:
		dw = dw - 1
	return dw

def IsWeekday(year=None, month=None, day=None):
	"""
		Returns true if the specified day is a weekday.
		Parameters default to current year, month, and day.
	"""
	dow = DayofWeek(year, month, day)
	if dow < 5:
		return 1
	else:
		return 0

def ElapsedBusHours(d1, d2):
	push = 0
	elapsed = 0.

	minhour	= TimeToJulian(Date.start_hour)
	maxhour	= TimeToJulian(Date.stop_hour)
	day_hrs = 24*(maxhour-minhour)
	
	#determine start and end date
	if d2 < d1:
		d1,d2 = d2,d1

	#push start and end dates forward to first weekday
	while not IsWeekday(d1.year, d1.month, d1.day):
		d1.NextDay()
		push = 1
	if push:
		d1.SetTime(Date.start_hour)
		push = 0
	
	while not IsWeekday(d2.year, d2.month, d2.day):
		d2.NextDay()
		push = 1
	if push:
		d2.SetTime(Date.start_hour)	

	d1_time = TimeToJulian(d1.hour, d1.minute, d1.second)
	d2_time = TimeToJulian(d2.hour, d2.minute, d2.second)

	d1_time = max(d1_time, minhour)
	d1_time = min(d1_time, maxhour)
	
	d2_time = max(d2_time, minhour)
	d2_time = min(d2_time, maxhour)

	#if start and end dates are on the same day, calculate time difference and return
	if (d1.year,d1.month,d1.day) == (d2.year,d2.month,d2.day):
		return 24*(d2_time - d1_time)
		

	elapsed += 24*(maxhour - d1_time)
	elapsed += 24*(d2_time - minhour)
	
	d1.NextDay()
	d1.SetTime(Date.start_hour)
	
	while (d1.year,d1.month,d1.day) != (d2.year,d2.month,d2.day):
		if IsWeekday(d1.year, d1.month, d1.day):
			elapsed += day_hrs
		d1.NextDay()
		
	return elapsed	

def TimeToJulian(*arg):
	"""
		Returns the fractional Julian day number for the specified time.
	"""
	try:
		if len(arg) == 1:
			h, mn, s = arg[0]
		else:
			h, mn, s = arg
	except:
		raise ValueError, 'Requires hours, minutes, seconds.'

	j = ((h*60*60) + (mn*60) + s ) / 86400.
	return j

def GregToJulian(*arg):
	"""
		Returns the Julian day number of the specified date as a float.
		Argument should be either a six-value tuple, or all six values individually.
	"""
	if len(arg) == 1:
		y, m, d, h, mn, s = arg[0]
	else:
		y, m, d, h, mn, s = arg
		
	a = (14 - m)//12
	y = y + 4800 - a
	m = m + 12*a - 3
	jd = d + ((153*m + 2)//5) + 365*y + y//4 - y//100 + y//400 - 32045

	jp = ((h*60*60) + (mn*60) + s ) / 86400.
	j = jd + jp
	return j

def GregToModifiedJulian(*arg):
	"""
		Returns the Modified Julian day number of this date as a float.
		
		This is the format used by astronomers, which has two main characteristics:
		1. Days begin at midnight rather than noon. 
		2. For dates in the period from 1859 to about 2130 only five digits need
		   to be used to specify the date rather than seven. 
	"""
	return GregToJulian(arg) - 2400000.5

def JulianToGreg(jd):
	"""
		Returns a tuple date corresponding to the given Julian day number.
		Unlike most algorithms, this includes fractions of a day.
		Astronomers rejoice!
	"""
	n = int(jd)
	a = n + 32044
	b = (4*a + 3)//146097
	c = a - (146097*b)//4
	d = (4*c + 3)//1461
	e = c - (1461*d)//4
	m = (5*e + 2)//153

	year	= 100*b + d - 4800 + m/10
	month	= m + 3 - 12*(m//10)
	day		= e + 1 - (153*m + 2)//5

	# now do fractions of day
	x = jd - n
	if x > 0:
		x = int(round(x* 86400, 1))
		hour = x//3600
		x = x - hour*3600
		minute = x//60
		second = x - minute*60
	else:
		hour	= 0
		minute	= 0
		second	= 0
	
	return (year, month, day, hour, minute, second)

class Date:
	century 		= 2000
	format_default	= '%Y-%m-%d %H:%M:%S'
	start_hour		= (9, 0, 0)
	stop_hour		= (17, 0, 0)
	weekdays		= []
	months			= []

	# slots constrained
	__slots__ = ['year', 'month', 'day', 'hour', 'minute', 'second',\
				 'day_week', 'julian_date', 'daylight', 'jd', \
				 'lang_re', 'lang_m', 'lang_d', 'lang_ampm', 'lang_dhms', 'lang']

	def __init__(self, lang_tuple):
		"""
			Constructor does little but decompose language tuple.
		"""
		self.lang_re, self.lang_m, self.lang_d, self.lang_ampm, self.lang_dhms = lang_tuple
		self.lang = lang_tuple

		self.year		= None
		self.month		= None
		self.day		= None
		self.hour		= None
		self.minute		= None
		self.second		= None
		self.day_week	= None
		self.julian_date= None
		self.daylight	= None
		self.jd			= None
		
	def Put(self, tm=None, format=format_default):
		"""
			The time argument can be of any supported type. 
			If not provided, then the current date is assumed.

			The format argument is a string used to format time
			if it too is a string representation.
		"""
		# take in input of any type and convert
		if type(tm) is type(''):
			# string format, so use strptime
			self.Strptime(tm, format)
		else:
			if tm is None:
				# current time
				t = time.localtime()
			elif type(tm) is type(0):
				if tm == 0:
					# our application zero time
					t = (1900, 1, 1, 0, 0, 0, None, None, None)
				else:
					# unix time
					t = time.localtime(tm)
			elif type(tm) is type(0.):
				# julian date
				t = JulianToGreg(tm)
			elif type(tm) is type(()):
				# python time tuple, but maybe not complete
				t = tm + (None, None, None)
			else:
				# assume COM
				t = time.localtime(int(tm))

			# trick to ensure enough values
			self.year, self.month, self.day,\
				self.hour, self.minute, self.second,\
				self.day_week, self.julian_date, self.daylight = t[:9]

		self.__Integrity()
		self.__Interpolate()
		
	def __str__(self):
		return self.GetAsNiceDate()

	def copy(self):
		"""
			Deep copy of Date objects.
		"""
		ret = Date(self.lang)
		ret.year, ret.month, ret.day, ret.hour, ret.minute, ret.second,\
				ret.day_week, ret.julian_date, ret.daylight, ret.jd =\
				self.year, self.month, self.day, self.hour, self.minute, self.second,\
				self.day_week, self.julian_date, self.daylight, self.jd
		return ret

	def __iter__(self):
		"""
			The iteration is "destructive", like in files.
		"""
		return self

	def __eq__(self, dt):
		return self.jd == dt.jd

	def __lt__(self, dt):
		return self.jd < dt.jd

	def __le__(self, dt):
		return self.jd <= dt.jd

	def __hash__(self):
		"""
			Dates can be used as keys in dictionaries.
		"""
		return hash((self.year, self.month, self.day, self.hour, self.minute, self.second))

	def __radd__(self, n):
		"""
			Adding dates is commutative.
		"""
		return self.__add__(n)

	def __add__(self, n):
		"""
			Adds a (signed) number of days to the date.
		"""
		if type(n) is type(0):
			jd = float(n)
		elif type(n) is type(0.):
			jd = n
		else:
			raise TypeError, 'You must add an integer or float to a date.'

   		x = JulianToGreg( self.jd + jd )

		# create new instance
		newdate = Date(self.lang)
		newdate.Put(x)
		return newdate

	def __sub__(self, n):
		"""
			Subtracts a (signed) number of days from the date.
			Returns a number of days.
		"""
		if isinstance(n, Date):
			jd = n.GetAsJulian()
			return self.jd - jd
		else:
			if type(n) is type(0):
				jd = float(n)
			elif type(n) is type(0.):
				jd = n
			else:
				raise TypeError, 'You must subtract an integer, float, or another date.'

			x = JulianToGreg( self.jd - jd )

			# create new instance
			newdate = Date(self.lang)
			newdate.Put(x)
			return newdate

	#Conversion methods.
	def __Integrity(self):
		"""
			Checks info integrity based on range, raising DateError.
		"""
		if self.month is not None:
			if not (1<=self.month<=12):
				raise DateError, 'Month incorrect'
		if self.day is not None:
			if not 1<=self.day<=31:
				raise DateError, 'Day incorrect'
		if self.hour is not None:
			if not 0<=self.hour<=23:
				raise DateError, 'Hour incorrect'
		if self.minute is not None:
			if not 0<=self.minute<=59:
				raise DateError, 'Minute incorrect'
		if self.second is not None:
			#61 covers leap seconds.
			if not 0<=self.second<=61:
				raise DateError, 'Second incorrect'
		if self.day_week is not None:
			if not 0<=self.day_week<=6:
				raise DateError, 'Day of the Week incorrect'
		if self.julian_date is not None:
			if not 0<=self.julian_date<=366:
				raise DateError, 'Julian Date incorrect'
		if self.daylight is not None:
			if not -1<=self.daylight<=1:
				raise DateError, 'Daylight Savings incorrect'
		return 1
		
	def __Interpolate(self):
		"""
			Interpolates missing date/time information
			and calculates Julian day number.
		"""
		if self.hour==None:
			self.hour = 0
		if self.minute==None:
			self.minute = 0
		if self.second==None:
			self.second = 0
			
		if self.julian_date==None and self.year and self.month and self.day:
			self.julian_date = self.MakeYearDay()
			
		if (self.month==None or self.day==None or self.year==None) and self.jd:
			self.year, self.month, self.day = JulianToGreg(self.jd)
			
		if self.day_week==None and self.year and self.month and self.day:
			self.day_week = self.GetDayofWeekNumber()

		if self.daylight==None:
			self.daylight = 0

		if self.jd==None:
			self.jd	= GregToJulian(self.year, self.month, self.day, self.hour, self.minute, self.second)

	def __Compile(self, format):
		"""
			Creates re based on format string and directive dictionary.
		"""
		directive	= 0
		re_string	= ''
		for char in format:
			if char == '%' and not directive:
				directive = 1
			elif directive:
				try:
					re_string = '%s%s' % (re_string, self.lang_re["%%%s" % char])
				except KeyError:
					raise DateError, 'Can\'t parse format string.'
				directive = 0
			else: 
				re_string = '%s%s' % (re_string, char)
		return re.compile(re_string, re.IGNORECASE)

	def Strptime(self, string_time, format):
		"""
			Determines all date-time info from string based on format string
			and a locale constant.
		"""
		REComp = self.__Compile(format)
		reobj = REComp.match(string_time)
		if not reobj:
			raise DateError, 'Format string does not match format of the data'

		for found in reobj.groupdict().keys():
			if found in ('y','Y'): #Year
				if found=='y': #Without century
					self.year = Date.century + int(reobj.group('y'))
				else: #With century
					self.year=int(reobj.group('Y'))
			elif found in ('b','B','m'): #Month
				if found=='m':
					self.month=int(reobj.group(found))
				else: #Int
					try:
						self.month=self.lang_m[reobj.group(found)]
					except KeyError:
						raise DateError, 'Unrecognized month'
			elif found=='d': #Day of the Month
				self.day=int(reobj.group(found))
			elif found in ('H','I'): #Hour
				hour=int(reobj.group(found))
				if found=='H':
					self.hour=hour
				else:
					try:
						if reobj.group('p') in self.lang_ampm[0]:
							AP=0
						else:
							AP=1
					except (KeyError,IndexError):
						raise DateError, 'Lacking needed AM/PM information'
					if AP:
						if hour==12:
							self.hour=12
						else:
							self.hour=12+hour
					else:
						if hour==12:
							self.hour=0
						else:
							self.hour=hour
			elif found=='M': #Minute
				self.minute=int(reobj.group(found))
			elif found=='S': #Second
				self.second=int(reobj.group(found))
			elif found in ('a','A','w'): #Day of the week
				if found=='w':
					day_value=int(reobj.group(found))
					if day_value==0:
						self.day_week=6
					else:
						self.day_week=day_value-1
				else:
					try:
						self.day_week=self.lang_d[reobj.group(found)]
					except KeyError:
						raise DateError, 'Unrecognized day'
			elif found=='j': #Julian date
				self.julian_date=int(reobj.group(found))
			elif found=='Z': #Daylight savings
				TZ=reobj.group(found)
				if len(TZ)==3:
					if TZ[1] in ('D','d'):
						self.daylight=1
					else:
						self.daylight=0
				elif TZ.find('Daylight')!=-1:
					self.daylight=1
				else:
					self.daylight=0

	def NextDay(self):
		"""
			Increments the day by one.
		"""
		self.jd += 1
		self.Put( JulianToGreg(self.jd) )
		
	def PreviousDay(self):
		"""
			Decrements the day by one.
		"""
		self.jd -= 1
		self.Put( JulianToGreg(self.jd) )

	def AddJulianDays(self, n):
		"""
			Adds the specified number of Julian days.
			Works just as well with negative numbers.
		"""
		if type(n) is type(0):
			jd = float(n)
		elif type(n) is type(0.):
			jd = n
		else:
			raise TypeError, 'You must add an integer or float.'

		self.jd += jd
		self.Put( JulianToGreg(self.jd) )
		
	def AddWeekdays(self, n=0.):
		"""
			Skips forward the specified number of weekdays.

			This may be a float representing fractional Julian days,
			but in this case only the day portion of the result has
			much meaning. Maybe use AddWorkhours() instead?

			Uses a brute force method.
		"""
		# push today forward to weekday
		while not IsWeekday(self.year, self.month, self.day):
			self.NextDay()

		# increment whole days
		days = int(n)
		for i in xrange(days):
			self.NextDay()
			while not IsWeekday(self.year, self.month, self.day):
				self.NextDay()	

		# then increment fractional days
		frac = n - days
		if frac > 0:
			self.AddJulianDays(frac)

			# push result forward to weekday
			while not IsWeekday(self.year, self.month, self.day):
				self.NextDay()

	def AddWorkhours(self, n=0):
		"""
			Skips forward the specified number of whole hours,
			and also accounts for work hours of 9am-5pm.

			Uses these float constants: Date.start_hour, Date.stop_hour
		"""
		# push today forward to start of next workday
		push = 0
		while not IsWeekday(self.year, self.month, self.day):
			self.NextDay()
			push = 1
		if push:
			self.SetTime(Date.start_hour)

		# gather info in Julian days
		min		= TimeToJulian(Date.start_hour)
		max		= TimeToJulian(Date.stop_hour)
		start	= TimeToJulian(self.hour, self.minute, self.second)
		incr	= (n, 0, 0)

		# how many calendar work days and hours is this?
		days, hours	= divmod( n, 24 * (max - min) )

		# add work days first
		if days > 0:
			self.AddWeekdays(days)

		# then the balance of hours
		j = start + (float(hours) / 24)
		if j > max:
			self.AddWeekdays(1)
			j = j - max + min
		
		# set hours
		self.SetTime(0, 0, 0)
		self.jd += j
		self.Put( JulianToGreg(self.jd) )			

	def MakeYearDay(self):
		"""
			Returns the number of days from the beginning of the year.
		"""
		ret = self.day
		for month in range(1, self.month):
			ret += DaysInMonth(self.year, month)

		return ret

	def GetYearDay(self):
		"""
			Returns the number of days from the beginning of the year.
		"""
		return self.julian_date

	def GetYearDayRemaining(self):
		"""
			Returns the number of days until the end of the year.
		"""
		return DaysInYear(self.year) - self.GetYearDay()

	def GetMonthName(self, month):
		"""
			Returns the month name of the date.
		"""
		return Date.months[month]

	def GetDayofWeekNumber(self):
		"""
			Returns the numeric day of the week for current date.
		"""
		return DayofWeek(self.year, self.month, self.day)

	def GetDayofWeekString(self):
		"""
			Returns the weekday of the date as a string.
		"""
		return Date.weekdays[ self.GetDayofWeekNumber() ]

	def GetMonth(self):
		"""
			Returns the month of the date in as a string.
		"""
		return self.GetMonthName(self.month - 1)

	def GetAsJulian(self):
		"""
			Returns the Julian day number of this date as a float.
		"""
		return self.jd

	def GetAsModifiedJulian(self):
		"""
			Returns the Modified Julian day number of this date as a float.
		"""
		return self.jd - 2400000.5

	def GetAsTuple(self):
		"""
			Return date into a time tuple.
		"""
		t = 	self.year, self.month, self.day,\
				self.hour, self.minute, self.second,\
				self.day_week, self.julian_date, self.daylight
		return tuple(t)

	def GetAsUnix(self):
		"""
			Convert date into Unix time (seconds since the epoch)
			corresponding to the same day with the midnight hour.
		"""
		return time.mktime(self.GetAsTuple())

	def GetAsISO(self):
		"""
			Convert date into ISO format.
		"""
		return self.Strftime('%Y-%m-%d %H:%M:%S')

	def GetAsANSI(self):
		"""
			Convert date into ANSI format.
		"""
		return self.Strftime('%Y.%m.%d %H:%M:%S')

	def GetAsNiceDate(self):
		"""
			Format current date into nice string.
		"""
		return '%s %d %s %d' % (self.GetDayofWeekString(), self.day, \
								self.GetMonth(), self.year)

	def GetAsNiceTime(self):
		"""
			Format current time into nice string.
		"""
		h = Pluralise(self.hour,	self.lang_dhms[1]) 
		m = Pluralise(self.minute,	self.lang_dhms[2]) 
		s = Pluralise(self.second,	self.lang_dhms[3]) 
	
		return '%s %s %s' % (h, m, s)

	def GetAsNiceDateTime(self):
		"""
			Format current date into nice string, with clock time.
		"""
		# use locale
		if self.hour >= 12:
			p = self.lang_ampm[1][0]
		else:
			p = self.lang_ampm[0][0]

		if self.hour > 12:
			h = self.hour - 12
		else:
			h = self.hour
			
		t = ' %d:%02d:%02d %s' % (h, self.minute, self.second, p)
		return self.GetAsNiceDate() + t
		
	def GetAsCOM(self):
		"""
			Convert date into COM format.
		"""
		if com_works:
			return pythoncom.MakeTime(self.GetAsUnix())
		else:
			raise Error, "COM component not loaded."
		
	def Strftime(self, format=''):
		"""
			Convert date using strftime.
		"""
		return time.strftime(format, self.GetAsTuple())
	
	def DaysToText(self, jd):
		"""
			Format number of julian days into nice string format.
		"""
		d = int(jd)
		h = 0
		m = 0
		s = 0

		x = jd - d
		if x > 0:
			x = int(round(x* 86400, 1))
			h = x//3600
			x = x - h*3600
			m = x//60
			s = x - m*60

		t = ''
		if d>0:
			t += ', ' + Pluralise(d, self.lang_dhms[0]) 
		if h>0:
			t += ', ' + Pluralise(h, self.lang_dhms[1]) 
		if m>0:
			t += ', ' + Pluralise(m, self.lang_dhms[2]) 
		if s>0:
			t += ', ' + Pluralise(s, self.lang_dhms[3])
			
		if t:
			t = t[2:]
		return t

	def UpdateJulian(self):
		"""
			Calculates Julian day number.
		"""
		self.jd	= GregToJulian(self.year, self.month, self.day, self.hour, self.minute, self.second)

	def SetTime(self, *arg):
		"""
			Sets time component of date.
		"""
		try:
			if len(arg) == 1:
				h, mn, s = arg[0]
			else:
				h, mn, s = arg
		except:
			raise ValueError, 'Requires arguments for hours, minutes, seconds, even if these are None.'

		if h is not None:
			self.hour	= h
		if mn is not None:
			self.minute	= mn
		if s is not None:
			self.second	= s
		self.UpdateJulian()
		
	def SetDate(self, *arg):
		"""
			Sets date component of date.
		"""
		try:
			if len(arg) == 1:
				y, m, d = arg[0]
			else:
				y, m, d = arg
		except:
			raise ValueError, 'Requires arguments for years, months, days, even if these are None.'

		if y is not None:
			self.year	= y
		if m is not None:
			self.month	= m
		if d is not None:
			self.day	= d
		self.UpdateJulian()
		

def CreateLocale(l):
	"""
		Creates locale tuple for use by strptime.

		Takes in lang_re (locale-specific regexes for extracting info from
		time string), self.lang_m (locale full and abbreviated month names), self.lang_d
		(locale full and abbreviated weekday names), and am_pm (locale's valid
		representation of AM and PM).

		lang_re, lang_m, and lang_d are dictionaries, while am_pm is a
		tuple.  Look at how the ENGLISH dictionary is created for an example of how
		the passed-in values should be constructed.  Also, make sure that every
		value in your language dictionary has a corresponding version to one in the
		ENGLISH dictionary; leaving any out could cause problems.

		Also note: if there are any values in the BasicDict that you would like to
		override, just put the overrides in the directive_d dictionary argument.
	"""
	lang_re, lang_m, lang_d, lang_ampm, lang_dhms = l[0], l[1], l[2], l[3], l[4]
	
	BasicDict={'%d':r'(?P<d>[0-3]\d)',				# Day of the month [01,31].
		'%H':r'(?P<H>[0-2]\d)',						# Hour (24-h) [00,23].
		'%I':r'(?P<I>[01]\d)',						# Hour (12-h) [01,12].
		'%j':r'(?P<j>[0-3]\d\d)',					# Day of the year [001,366].
		'%m':r'(?P<m>[01]\d)',						# Month [01,12].
		'%M':r'(?P<M>[0-5]\d)',						# Minute [00,59].
		'%S':r'(?P<S>[0-6]\d)',						# Second [00,61].
		'%U':r'(?P<U>[0-5]\d)',						# Week number of the year, Sunday first [00,53]
		'%w':r'(?P<w>[0-6])',						# Weekday [0(Sunday),6].
		'%W':r'(?P<W>[0-5]\d)',						# Week number of the year, Monday first [00,53]
		'%y':r'(?P<y>\d\d)',						# Year without century [00,99].
		'%Y':r'(?P<Y>\d\d\d\d)',					# Year with century.
		'%Z':r'(?P<Z>(\D+ Time)|([\S\D]{3,3}))',	# Time zone name (or empty)
		'%%':r'(?P<percent>%)'						# Literal "%" (ignored, in the end)
		}
	BasicDict.update(lang_re)
	return (BasicDict, lang_m, lang_d, lang_ampm, lang_dhms)

class Locale:
	# class constants
	weekdays = {'gb' : ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
				'fr' : ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'],
				'de' : ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'],
				'it' : ['luned�', 'marted�', 'mercoled�', 'gioved�', 'venerd�', 'sabato', 'domenica'],
				'se' : ['M�ndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Fredag', 'L�rdag', 'S�ndag'],
				'es' : ['lunes', 'martes', 'mi�rcoles', 'jueves', 'viernes', 's�bado', 'domingo']
				}
	months = {	'gb' : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
				'fr' : ['Janvier', 'F�vrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Ao�t', 'Septembre', 'Octobre', 'Novembre', 'D�cembre'],
				'de' : ['Januar', 'Februar', 'M�rz', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
				'it' : ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'],
				'se' : ['Januari', 'Februari', 'Mars', 'April', 'Maj', 'Juni', 'Juli', 'Augusti', 'September', 'Oktober', 'November', 'December'],
				'es' : ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'] 
				}
	locales = {	'gb' : LOC_GB,
				'fr' : LOC_FR,
				'de' : LOC_DE,
				'it' : LOC_IT,
				'se' : LOC_SE,
				'es' : LOC_ES	}
	languages = ['gb', 'fr', 'de', 'it', 'se', 'es']
	
	__slots__ = ['lang_tuple']

	def __init__(self, lang='gb'):
		"""
			The argument is the ISO standard country code for the
			language and formatting to be used. This defaults to 'gb' for English.
		"""
		# language defaults to English
		if lang not in Locale.languages:
			lang = Locale.languages[0]
			
		self.lang		= lang
		self.lang_tuple	= CreateLocale( Locale.locales[lang] )

	def Make(self, tm=None, format=None):
		""" Purpose:	Produces Date instance.
			Parameters:	<args> is a list of arguments to the Date class.
			Returns:	Date instance or empty string if there is some problem.
		"""
		Date.weekdays	= Locale.weekdays[self.lang]
		Date.months		= Locale.months[self.lang]

		d = Date(self.lang_tuple)
		d.Put(tm, format)

		return d

def MegaDate(tm=None, format=None):
	"""
		All in one easy date instantiation, assuming default locale.
	"""
	df = Locale()
	return df.Make(tm, format)
	
if __name__ == '__main__':
	print 'Date test suite'
	print '==============='
	print 

	if 0:
		print 'Section 1: Julian conversion'
		print '----------------------------'
		print 

		print 'Start with a Gregorian date:'
		greg = (2002, 5, 24, 13, 6, 49)
		print greg
		print 

		print 'Convert to Julian number:'
		jd = GregToJulian(greg)
		print jd
		print 

		print 'Convert back to Gregorian date:'
		greg = JulianToGreg(jd)
		print greg
		print 

		print 'Julian day fraction for 9am:'
		print TimeToJulian(9, 0, 0)
		print 
		print 'Julian day fraction for 5pm:'
		print TimeToJulian(17, 0, 0)
		print 


		print 'Section 2: Date representations'
		print '-------------------------------'
		print 

		print 'Define locale to be Sweden'
		df = Locale('gb')
		# df = Locale('se')
		print 
		
		print 'Today in various formats:'
		t = df.Make()
		print 'Tuple:      %s' % str(t.GetAsTuple())
		print 'ISO:        %s' % t.GetAsISO()
		print 'ANSI:       %s' % t.GetAsANSI()
		print 'Nice:       %s' % t.GetAsNiceDateTime()
		print 'UNIX:       %s' % t.GetAsUnix()
		print 'Julian:     %s' % t.GetAsJulian()
		print '(modified): %s' % t.GetAsModifiedJulian()
		print 

		print 'Section 3: Copying'
		print '------------------'
		print 

		print 'Grab a copy of today\'s date.'
		t2 = t.copy()
		print t2.GetAsNiceDateTime()
		print 
		
		print 'Section 4: Date math'
		print '--------------------'
		print 

		print 'Tomorrow (using function):'
		t.NextDay()
		print t.GetAsNiceDateTime()
		print 

		print 'Seven days from then (using addition operator):'
		t = 3 + t + 4	
		print t.GetAsNiceDateTime()
		print 

		print 'Two days before that:'
		t = t - 2
		print t.GetAsNiceDateTime()
		print 

		print 'An hour later:'
		t = t + 1./24
		print t.GetAsNiceDateTime()
		print 

		print 'Number of days from the beginning of the year:'
		print t.GetYearDay()
		print 

		print 'Number of days until the end of the year:'
		print t.GetYearDayRemaining()
		print 

		print 'Set time to 11pm:'
		t.SetTime(23, 0, 0)
		print t.GetAsNiceDateTime()
		print 

		print 'Subtract saved copy of today\'s date:'
		d = t - t2
		print 'Difference: %s' % t2.DaysToText(d)
		print 

		print 'Section 5: Formatting'
		print '--------------------'
		print 

		print 'Use MegaDate to define string date, in English this time.'
		t3 = MegaDate('1963-02-08 12:39:43', '%Y-%m-%d %H:%M:%S')
		print t3.GetAsNiceDateTime()
		print 

		print 'Displayed a different way.'
		print '%s, %s.' % (t3.GetAsNiceDate(), t3.GetAsNiceTime())
		print 

	if 0:
		print 'Section 6: Weekday Math'
		print '-----------------------'
		print 

		today = MegaDate()
		print 'Today:'
		print today.GetAsNiceDateTime()
		print 
		
		today.AddWeekdays(2)
		print 'Add 2 weekdays:'
		print today.GetAsNiceDateTime()
		print 
		
		today.AddWeekdays(6)
		print 'add 6 more'
		print today.GetAsNiceDateTime()
		print 

	if 0:
		print 'Section 6: Weekday Math'
		print '-----------------------'
		print 

		t = MegaDate((2002, 06, 13, 12, 0, 0))
		print 'June 13th at noon:'
		print t.GetAsNiceDateTime()
		print 
		
		print 'Now add 4 work hours:'
		t.AddWorkhours(4)
		print t.GetAsNiceDateTime()
		print 

		print 'Add 4 more:'
		t.AddWorkhours(4)
		print t.GetAsNiceDateTime()
		print 

		print 'And 12 more:'
		t.AddWorkhours(12)
		print t.GetAsNiceDateTime()
		print 

		print 'And 1 more:'
		t.AddWorkhours(1)
		print t.GetAsNiceDateTime()
		print 

		print 'And 9 more:'
		t.AddWorkhours(9)
		print t.GetAsNiceDateTime()
		print 

	if 1:
		now = MegaDate()
		print 'Now: %s' % now.GetAsNiceDateTime()

		now.AddWeekdays(2)
		print 'Add 2 weekdays: %s' % now.GetAsNiceDateTime()

		then = MegaDate((2002, 06, 13, 12, 0, 0))
		print 'June 13th at noon: %s' % then.GetAsNiceDateTime()

		then.AddWorkhours(6)
		print 'Add 6 work hours: %s' % then.GetAsNiceDateTime()

		then.SetTime(23, 0, 0)
		print 'Set time to 11pm: %s' % then.GetAsNiceDateTime()

		print 'Displayed nice time: %s' %  then.GetAsNiceTime()

		d = now - then
		print 'Subtract from now: %s' % now.DaysToText(d)
