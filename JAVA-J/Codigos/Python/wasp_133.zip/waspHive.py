"""
Program:
	waspHive.py

Description:
	Core modules and classes. Used by both wasp and waspCGI.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import string, sys, os, getopt, types, time, re, StringIO, glob, md5, base64, urllib, imp 
import waspCfg

tab = ' ' * 2

class Error:
	""" error class """
	def __init__(self, where='', *msg):
		self.msg = [where] + list(msg)
	def __repr__(self):
		return '|'.join(self.msg)

class Log:
	def __init__(self, file='default.log', header=(), delim='\t'):
		"""
			Initialises log by opening file, writing header if it is provided
			and the file is new.
			Takes a file spec, list/tuple of strings, and column delimiter.
		"""
		self.file	= file
		self.delim	= delim
		self.h		= -1
		self.talk	= 0

		# append or write new log
		new_file = not os.path.exists(self.file)		
		if new_file:
			self.h = open(self.file, 'w')
		else:
			self.h = open(self.file, 'a')

		# wait for exclusive lock
		if 'fcntl' in dir():
			# we are guaranteed to be the only process with a flock() hereafter
			# but programs that ignore this protocol can do as they wish
			fcntl.flock(self.h, 2) 

		# write header
		if new_file and header:
			self.h.write( string.join(header, self.delim) + '\n' )
		
	def Talk(self, talk=0):
		"""
			Toggles verbose mode, which simply prints any messages as they are logged.
		"""
		if talk:
			self.talk = 1
		else:
			self.talk = 0
		
	def __del__(self):
		"""
			Closes file handle as object is destroyed.
		"""
		if self.h <> -1:
			self.h.write( '* end\n\n' )
			self.h.close()

	def Write(self, columns=None):
		"""
			Adds an entry to the log.
			Takes a list/tuple of values to be used for column contents.
		"""
		msg = ''
		if columns:
			if type(columns) not in (types.ListType, types.TupleType):
				columns = (columns, )
			for col in columns:
				col = str(col)
				
				# encode line termination characters
				col = col.replace('\n', '|')
				col = col.replace('\r', '')

				# encode delimiters if they appear as data
				col = col.replace(self.delim, '~')
				
				msg += self.delim + col
			
			msg = msg[len(self.delim):]
			self.h.write( msg + '\n' )
			self.h.flush()
		
			if self.talk:
				print msg


def Upload(loc):
	"""
		Upload a file from form.
	"""
	size = 0
	err = ''
	obj = GetPublic('file')
	try:	
		f = obj.file
	except:
		err = 'no file present'
	else:
		err = 'file incompletely uploaded'
		f = open(loc, 'wb')

		# read file in increments -- saves memory supposedly
		bunch = 2048
		count = 0
		while 1:
			count += 1
			if count / 100 * 100 == count:
				x = 'loaded %s' % count

			line = obj.file.read(bunch)
			if line:
				size += len(line)
				f.write(line)
			else:
				break

		# read file in one fell swoop
		# f.write(obj.value)
		f.close()
		err = ''
		
	return err, size
	
def Splice(our_list, delim = ', '):
	"""
		Return string produced by joining all members of specified list using the
		<delim>.
	"""
	return string.joinfields(map(str, our_list), delim)
	
def Escape(x):
	"""
		Base-64 encoding to conform with RFC 1521.

		This results in characters in this range:
			string.letters + string.digits + '/+=' + '\n'

		Not sure why we have \n in here -- better get rid of them!
	"""
	if x:
		ret = base64.encodestring(x)[:-1]
		ret = ret.replace('\n', '?')
	else:
		ret = ''
	return ret

def Unescape(x):
	"""
		Base-64 decoding to conform with RFC 1521.
	"""
	ret = ''
	if x:
		x = x.replace('?', '\n')
		ret = base64.decodestring(x + '\n')
	return ret

def Encode(plain, cryptic):
	"""
		Hash secret string with specified string to simulate security.
		A tilde (~) should not appear in our data, as it is used as
		a delimiter.
	"""
	# use RSA's MD5 message digest algorithm (RFC 1321) to get 128-bit checksum
	checksum = md5.new(cryptic + plain + cryptic).digest()

	# append our checksum
	x = plain + '~' + checksum

	# use base-64 encoding to conform with RFC 1521
	code = base64.encodestring(x)
	
	# remove newline
	return code[:-1]

def Decode(code, cryptic):
	"""
		Convert specified string from plain text plus checksum.
	"""
	# add CR, then base-64 decode
	x = base64.decodestring(code + '\n')
	ok = ''

	# split into plain text and our checksum
	if '~' in x:
		(plain, checksum) = x.split('~', 1)
		
		if plain and checksum:
			# regenerate checksum and check for validity
			if checksum == md5.new(cryptic + plain + cryptic).digest():
				ok = plain
	else:
		ok = x
	
	return ok

def AllMatch(s, t):
	"""
	Returns true if all characters in string s are from the set
	defined by string t
	"""
	ret = 1
	for char in s:
		if char not in t:
			ret = 0
			break
	return ret

def isEven( x ):
	""" returns true if number is even """
	return int(x / 2) * 2 == x
	
def NiceTime( my_time=None ):
	"""
	Returns time in ISO format required by datetime fields.
	If you pass is a time, make sure it is a 
	"""
	iso_format = '%Y-%m-%d %H:%M:%S'
	if my_time:
		# check for float
		if type(my_time) == type(1.0):
			# convert to 9-item tuple
			my_time = time.localtime(my_time)
		iso = time.strftime(iso_format, my_time)
	else:		
		iso = time.strftime(iso_format)
		
	return iso

def GetHttpError(code):
	"""
	given an HTTP error code, GetHttpError() returns a tuple of short and 
	long messages as defined by:
	www.w3.org/hypertext/WWW/Protocols/HTTP/HTRESP.html
	"""
	
	if type(code) is StringType:
		code = int(code)
		
	responses = {
		200: ('OK',
			  'Request fulfilled, document follows'),
		201: ('Created',
			  'Document created, URL follows'),
		202: ('Accepted',
		      'Request accepted, processing continues off-line'),
		203: ('Partial information',
			  'Request fulfilled from cache'),
		204: ('No response',
			  'Request fulfilled, nothing follows'),

		301: ('Moved',
			  'Object moved permanently -- see URI list'),
		302: ('Found',
			  'Object moved temporarily -- see URI list'),
		303: ('Method',
			  'Object moved -- see Method and URL list'),
		304: ('Not modified',
		      'Document has not changed since given time'),
		
		400: ('Bad request',
		      'Bad request syntax or unsupported method'),
		401: ('Unauthorized',
		      'No permission -- see authorization schemes'),
		402: ('Payment required',
		      'No payment -- see charging schemes'),
		403: ('Forbidden',
		      'Request forbidden -- authorization will not help'),
		404: ('Not found',
			  'Nothing matches the given URI'),
		
		500: ('Internal error',
			  'Server got itself in trouble'),
		501: ('Not implemented',
		      'Server does not support this operation'),
		502: ('Service temporarily overloaded',
		      'The server cannot process the request due to a high load'),
		503: ('Gateway timeout',
		      'The gateway server did not receive a timely response'),
		}
	
	try:
		ret = responses[code]
	except KeyError:
		ret = ('no such code', 'no such code')

	return ret

def GetTag( file, tag ):
	"""
	Returns contents of first occurrence of the specified HTML tag from
	the specified file, ignoring case.
	"""
	ret = ''
	contents = ReadFile(file)
	if contents <> []:
		tag_text= r'.*?<%s>(?P<tag_content>.*?)</%s>.*?' % (tag, tag)
		tag_re	= re.compile(tag_text, re.S | re.I)
		tag_done= tag_re.search(contents)
		if tag_done:
			ret = tag_done.group('tag_content')
	return ret

def ParseFile( file ):
	""" parses file spec into tuple of:
		list of drive and folders, file name, and file extension (incl. dot). """
	(root, ext) = os.path.splitext(file)
	(x, y) = os.path.split(root)
		
	name = y
	parts = []

	y = '-'

	while y <> '':
		(x, y) = os.path.split(x)
		parts.append(y)

	parts = parts[:-1]
	parts.append(x)
	parts.reverse()
	
	return (parts, name, ext)


def AbsPath( path ):
	"""
	corrected version of os.path.abspath()
	that does not throw away terminal slash.
	"""
	path = os.path.abspath(path)
	if os.path.exists(path) and os.path.isdir(path):
		path = path + os.sep
	return path


def NormPath( path ):
	"""
	corrected version of os.path.normpath()
	that does not throw away terminal slash.
	"""
	path = os.path.normpath(path)
	if os.path.exists(path) and os.path.isdir(path):
		path = path + os.sep
	return path


def RatioPath( in_file, out_path, in_path ):
	"""
	Returns path that is to <in_file> as <out_path> is to <in_path>.
	Notes:
	1. If one path has a drive letter, both must.
	2. Only works for *real* paths currently accessible
	"""
	rel = AbsPath( Relative( out_path, in_path ) )
	out_file = NormPath( os.path.join(rel, in_file) )

	return out_file

def Relative( this_path, base_path ):
	"""
	Returns first path relative to second.
	Works across platforms (hopefully!).
	Notes:
	1. If one has a drive letter, both must.
	2. Only works for *real* paths currently accessible
	"""

	this_path = AbsPath( this_path )
	base_path = AbsPath( base_path )
	
	thisChunk, name, ext = ParseFile( this_path )
	baseChunk, yyyy, yyy = ParseFile( base_path )

	thisLen = len(thisChunk)
	baseLen = len(baseChunk)
	
	length = min(thisLen, baseLen)
	res = ''
	go = 0
	for i in range(length):
		if thisChunk[i] <> baseChunk[i]:
			go = 1
		if go:
			res = os.path.join(res, thisChunk[i])

	up = os.pardir

	if thisLen == baseLen and not name:
		res = os.path.join(up, res)
	elif thisLen < baseLen:
		for i in range(thisLen, baseLen):
			res = os.path.join(up, res)
	elif baseLen < thisLen:
		for i in range(baseLen, thisLen):
			res = os.path.join(res, thisChunk[i])

	return os.path.join(res, name + ext)

def SetHTTPHeader(text=''):
	"""
		Sets HTTP header. Terminating line feeds are added automatically.
	"""
	if not text:
		text = 'Content-type: text/html'

	text += '\n\n'
	
	SetPublic('header', text)

def SetPublic(thingy, key1=None, key2=None):
	"""
	Changes specified key in public data dictionary to value specified.
	The key does not already have to exist for this to work.
	"""
	# puts main name space in module name space (or something)
	import __main__

	# set part of it
	if key1:
		if key2:
			__main__.__dict__['public'][key1][key2] = thingy
		else:
			__main__.__dict__['public'][key1] = thingy

def GetPublic(key1=None, key2=None):
	"""
		Returns specified key from public data dictionary
		(or entire dictionary if unspecified).
	"""
	# puts main name space in module name space (or something)
	import __main__

	# we only want part of it
	ret = __main__.__dict__['public']

	if key1 and ret and type(ret) is types.DictType:
		ret = ret.get(key1, '')
		if key2 and ret and type(ret) is types.DictType:
			ret = ret.get(key2, '')

	return ret

def Redirect(location='index.html'):
	""" redirects to specified page """
	SetPublic('Location:%s\n\n' % location, 'header')
	
def Refresh():
	""" auto-refresh current page -- a useful idiom """
	Redirect( GetPublic('cgi', 'page_name')[1:] )
	
def Terminate():
	""" Immediately stop this page from rendering. """
	raise 'Terminate'

def Execute( path, routine, namespace, publish ):
	""" execute user routine located in file on path """
	
	# short circuit
	if routine == '':
		return ''
	
	# split routine into actual routine name and list of parameters
	re_par = re.compile(r'(?P<our_def>.*?)\((?P<our_par>.*?)\)$', re.S)
	found = re_par.search( routine )

	if found:
		our_def = string.strip(found.group('our_def'))
		our_par = string.strip(found.group('our_par'))
	else:
		raise Error('waspHive.Execute', 'can\'t split %s into parts.' % routine)
	
	# switch to input directory
	save_path = os.getcwd()
	os.chdir(path)
		
	# update public stuff (publish contains cumulative dict)
	import __main__
	__main__.__dict__['public'] = publish

	# compile the call to our routine through our namespace
	# call = 'namespace["%s"](%s)' % (our_def, our_par)
	call_plain = '%s(%s)' % (our_def, our_par)
	try:
		call_compiled = compile(call_plain, '<string>', 'eval')
	except:
		raise Error('waspHive.Execute', str(sys.exc_value), routine)

	# capture standard out
	# sys.stdout.flush()
	real_stdout = sys.stdout
	sys.stdout = StringIO.StringIO()

	# execute code now!	
	return_value = ''
	try:
		return_value = eval( call_compiled, namespace )
	except 'LibError', err:
		# error set by user in library
		sys.stdout = real_stdout
		raise Error(our_def, err)
	except:
		# uncontrolled error
		sys.stdout = real_stdout
		raise

	os.chdir(save_path)
	ret = sys.stdout.getvalue()

	# return standard out to how it was
	sys.stdout = real_stdout
	if return_value:
		ret = return_value
	return ret

def ReadFile(file):
	""" opens specified file and returns contents as a string. """
	try:
		contents = open(file).read()
	except:
		raise Error('waspHive.ReadFile', tab + '%s cannot be read.' % (file))
	return contents
	
def WriteFile(file, contents):
	""" writes specified contents to file. """
	try:
		h = open(file, 'w').write(contents)
	except:
		raise Error('waspHive.WriteFile', tab + '%s cannot be written.' % (file))

class waspObject:
	"""
		Process a file by text substitution.
		Takes three dictionaries:
			configuration options,
			namespace for executing programs,
			public data
			
		Public data is as follows:
			from wasp:
				path_input: path to input (.wasp) files
				path_output: path to output (.html) files
				path_include: path to include (.inc) files
				path_execute: path to library (.py) files

			from waspCGI:
				cgi_head: cgi header
				cgi_form: cgi form fields
				cgi_env: cgi environment
			for each file executed add:
				wasp_file: current Wasp file name
				wasp_tag: current Wasp directive, eg: 'execute'
				wasp_option: routine to execute
	"""

	def __init__(self, options, namespace, public):
		# our initialization parameters
		self.options	= options
		self.namespace	= namespace
		self.public		= public

		# custom tags
		self.d_open		= self.options['tag_open']
		self.d_close	= self.options['tag_close']
		self.d_open_esc	= string.replace(self.d_open, '?', '\?')
		self.d_close_esc= string.replace(self.d_close, '?', '\?')
		
		# current tag parts
		self.wasp_tag = ''
		self.wasp_atr = ''
		self.wasp_par = ''
		
		# all possible tags		
		self.tags = [	'include', 'i',
						'macro', 'm',
						'if', 'end',
						'execute', 'e',
						'seq', 's',
						'index', 'x' ]

		# other properties		
		self.inFile		= ''
		self.outFile	= ''
		self.inText		= ''
		self.outText	= ''
		self.warning	= 0
		self.recursion_limit = self.options['recursion_limit']

		# compile regular expressions
		# r''	raw string notation: backslashes are not handled in any special way
		# *?	non-greedy qualifier matches as *little* text as possible
		# re.S	match across lines

		str = r'(%s.*?%s)' % (self.d_open_esc, self.d_close_esc)
		self.re_fld = re.compile(str, re.S)
		
		str = r'(%s\s*(?P<wasp_tag>.*?):(?P<wasp_atr>.*?)\s*%s)' % (self.d_open_esc, self.d_close_esc)
		self.re_tag = re.compile(str, re.S)

		str = r'(?P<wasp_atr>.*?)\((?P<wasp_par>.*?)\)$'
		self.re_par = re.compile(str, re.S)
	
	def Read( self, inFile=None ):
		# read in text from file to property
		if inFile <> None:
			self.inFile = inFile
		self.inText = ReadFile(self.inFile)
		
	def Write( self, outFile=None ):
		# write out text to file to property
		if outFile <> None:
			self.outFile = outFile
		if not self.warning:
			WriteFile(self.outFile, self.outText)

	def GetInput( self ):
		return self.inText
	
	def GetOutput( self ):
		return self.outText
	
	def SetInput( self, text ):
		self.inText = text
	
	def SetOutput( self, text ):
		self.outText = text
	
	def Parse( self, subDict ):
		self.warning = ''
		done = 0
		deep = 0
		len_tag = len(self.d_open)
		cr = os.linesep
		
		while not done:
			self.outText = ''

			# support for conditional code
			if_level	= 0
			if_ok		= {}
			if_ok[0]	= 1

			# split into blocks around Wasp tags
			fld = self.re_fld.split(self.inText)

			for f in fld:
				# found a possible tag
				if f[:len_tag] == self.d_open:
					tag = self.re_tag.search(f)
					if not tag:
						# could not parse tag
						self.warning = 'malformed preprocessor directive at: %s.' % f
						break
					else:
						# parsed tag
						self.wasp_tag = string.strip(tag.group('wasp_tag'))
						self.wasp_atr = string.strip(tag.group('wasp_atr'))
						self.wasp_par = ''

						if not self.wasp_tag in self.tags:
							# not a valid tag
							self.warning = 'malformed preprocessor directive at: %s:%s.' % (self.wasp_tag, self.wasp_atr)
							break
						else:
							# valid tag
							if not subDict.has_key(self.wasp_tag):
								# just pass through
								text = self.D_passs()
							else:
								# has an assigned action
								command = subDict[self.wasp_tag]
								do_it = 'self.D_%s()' % command
								code = compile(do_it, '<string>', 'eval')
								text = eval( code )
								
								# remove extra line feeds
								if text and self.wasp_tag <> 'if':
									for x in range(len(text)):
										if ord(text[-1]) == 10:
											text = text[:-1]
										else:
											break

								# conditionals processing
								if self.wasp_tag == 'if':
									if_level += 1
									if text:
										if_ok[if_level] = 1
									else:
										if_ok[if_level] = 0
									text = ''
								elif self.wasp_tag == 'end':
									if_level -= 1
								else:
									if not if_ok[if_level]:
										text = ''
								
				else:
					# not a tag, just plain text
					if if_ok[if_level]:
						text = f
					else:
						text = ''
						
				self.outText += text

			if self.outText == self.inText or self.warning:
				done = 1
			else:
				# contents have changed, so we may have more tags to parse
				deep = deep + 1
				if deep > self.recursion_limit:
					done = 1
					self.warning = 'recursion limit of %s passed.' % (self.recursion_limit)
				else:
					self.inText = self.outText
					
		if self.warning:
			print tab + tab + self.warning		
		return self.warning

	def D_passs(self):
		""" directive -- do nothing, preserve tag for next pass. """
		return self.d_open + ' ' + self.wasp_tag + ':' + self.wasp_atr + ' ' + self.d_close
		
	def D_null(self):
		""" directive -- do nothing, remove tag. """
		return ''
		
	def D_index(self):
		""" directive -- use index list. """
		return self.public['text']
		
	def D_macro(self):
		""" directive -- look up specified macro, return result from expansion dictionary."""
		dict = self.options['expansion']
		macro = string.lower(self.wasp_atr)
		if not dict.has_key(macro): 
			raise Error('waspHive.waspObject.D_macro', tab + '%s is not a valid macro.' % (macro))
		return dict[macro]

	def D_include(self):
		""" directive -- includes specified file in the current file. """

		# decompose into attribute and parameters
		if string.find(self.wasp_atr, '(') <> -1:
			par = self.re_par.search(self.wasp_atr)
			self.wasp_atr = par.group('wasp_atr')
			self.wasp_par = par.group('wasp_par')

		# read in file
		file_spec = os.path.join( self.options['path_include'], self.wasp_atr + self.options['include'] )
		if not os.path.isfile(file_spec): 
			raise Error('waspHive.waspObject.D_include', tab + '%s is not a valid include file.' % (file_spec))
		x = ReadFile(file_spec)
	
		# process parameters
		if self.wasp_par <> '':
			self.wasp_par = re.findall(r".*?'(.*?)'.*?", self.wasp_par)
			
			# self.wasp_par = string.split(self.wasp_par, ',')
			for c in range(1, len(self.wasp_par)+1):
				par = string.strip(self.wasp_par[c-1])
				par = string.replace(par, "'", "")

				evaluate_me = "re.compile(r'(" + self.d_open_esc + "\s*" + ("%s" % c) + "\s*\?>)')" 
				compiled = compile(evaluate_me, '<string>', 'eval') 
				look_for = eval(compiled)
				x = look_for.sub(par, x)
		return x

		
	def D_execute(self):
		""" directive -- execute custom routine."""

		text = ''
		if self.options['execute'] and self.wasp_atr:
			self.public['wasp_file']	= self.inFile
			self.public['wasp_tag']		= self.wasp_tag
			self.public['wasp_option']	= self.wasp_atr

			text = Execute( self.options['path_input'], self.wasp_atr, self.namespace, self.public )
		return text

	def D_sequence(self):
		""" 
		directive -- command is one of: prev, next, up, home, toc
		Inserts a relative URL to the previous, next, upwards, and home link respectively, 
		according to the sequence list. Also, toc will build a Table of Contents.
		"""
		sequence	= self.options['sequence']
		current		= self.inFile
		command		= self.wasp_atr

		if command in ('prev', 'next', 'up'):
			# find current position
			thisI = -1
			for i in range(len(sequence)):
				if sequence[i][0] == current:
					thisI = i
			
			if thisI == -1:
				raise Error('waspHive.waspObject.D_sequence', tab + '%s not in sequence' % (current))
			
			elif command == 'prev':
				newI = thisI - 1
				if newI < 0:
					if self.options['seqwrap'] == 'off':
						ret = 'javascript:alert(\'no more pages\');'
					else:
						ret = Relative(sequence[len(sequence)-1][0], current)
				else:
					ret = Relative(sequence[newI][0], current)
					
			elif command == 'next':
				newI = thisI + 1
				if newI >= len(sequence):
					if self.options['seqwrap'] == 'off':
						ret = 'javascript:alert(\'no more pages\');'
					else:
						ret = Relative(sequence[0][0], current)
				else:
					ret = Relative(sequence[newI][0], current)
					
			elif command == 'up':
				# previous indent level
				indent = max( sequence[thisI][1] - 1, 0 )
				newI = -1
				for i in range(thisI, -1, -1):
					if sequence[i][1] == indent:
						newI = i
						break
				if newI == -1:
					newI = 0
				ret = Relative(sequence[newI][0], current)
				
		elif command == 'home':
			# first node
			ret = Relative(sequence[0][0], current)
					
		elif command == 'toc':
			# table of contents

			if self.options['seqfancy'] == 'on':
				# "fancy" sequence list using CSS
				# requires that there are CSS classes seq0, seq1... seqN
				# where N is the maximum indent level

				bullet = {0: '', 1: '<B>&#183;</B>', 2: '&#186;', 3: '&#164;'}
				ret = ''
				for (target, indent) in sequence:
					if self.options['seqfirst'] == 'off' and indent == 0:
						continue
					
					x = '<P CLASS="seq%s">' % indent
					if self.options['seqdot'] == 'on':
						x = x + bullet[indent % 4] + '&nbsp;'
					ret = ret + x + '<A HREF="' + Relative(target, current) + '">' + GetTag(target, 'TITLE') + '</A></P>\n'
			else:
				# "normal" sequence list using unordered lists
				
				oldIndent = 0
				ret = '<UL>\n'
				for (target, indent) in sequence:
					if self.options['seqfirst'] == 'off' and indent == 0:
						continue
					
					# indent
					if indent > oldIndent:
						for i in range(oldIndent, indent):
							ret = ret + '<UL>\n'
						oldIndent = indent 
					# outdent
					elif indent < oldIndent:
						for i in range(indent, oldIndent):
							ret = ret + '</UL>\n'
						oldIndent = indent
						
					ret = ret + '<LI><A HREF="' + Relative(target, current) + '">' + GetTag(target, 'TITLE') + '</A></LI>\n'
					
				# finish off correctly
				for i in range(-1, indent):
					ret = ret  + '</UL>\n'
		else:
			raise Error('waspHive.waspObject.D_sequence', tab + 'Sequence command not valid in: %s' % (current))
		
		return ret
	
	def D_if(self):
		""" directive -- execute custom routine and use return value to set flag."""
		return self.D_execute()

class Options:
	""" 
		parses command line and reads configuration file to determine options

		usage for CGI single-file access:
			drone = Options()
			drone.DoConfigFile()
			options		= drone.GetOptionDict()
			name_space	= drone.DoImport(name_space)

		usage for command line multi-file access:
			drone = Options()
			drone.DoCommandLine()
			drone.DoConfigFile()
			drone.DoArguement()
			waspFiles	= drone.GetFileList()
			options		= drone.GetOptionDict()
			name_space	= drone.DoImport(name_space)
	"""
	
	def __init__(self, more_options={}):
		self.opt	= []
		self.args	= []
		self.files	= []
		self.custom	= {}
		
		# used to force on the force option if selected on command line
		self.force_force = 0
		
		# default options
		self.options = {
				'cfgfile'		: 'wasp.cfg',
				'cfgwarn'		: 0,
				'force'			: 'off',
				'exit'			: 'off',
				'tag_open'		: '<?w',
				'tag_close'		: '?>',
				'path_input'	: '.',
				'path_include'	: '.',
				'path_output'	: '.',
				'path_execute'	: '.',
				'language'		: 'en',
				'import'		: [],
				'include'		: '.inc',
				'wasp'			: '.wasp',
				'html'			: '.html',
				'execute'		: [],
				'expansion'		: {},
				'sequence'		: [],
				'indexletteropen'	: '<H2>',
				'indexletterclose'	: '</H2>',
				'indexlettersep'	: '&nbsp;|&nbsp;',
				'indexbanneropen'	: '<H2>',
				'indexbannerclose'	: '</H2>',
				'indexbannersep'	: '&nbsp;|&nbsp;',
				'indexbannertop'	: 'on',
				'indexbannertail'	: 'on',
				'seqwrap'			: 'on',
				'seqfirst'			: 'on',
				'seqfancy'			: 'off',
				'seqdot'			: 'on',
				'recursion_limit'	: 10,
				'runpre'			: '',
				'runmid'			: '',
				'runpost'			: '' }

		self.options.update(more_options)
		
	def GetFileList(self):
		return self.files
	
	def GetOptionDict(self):
		return self.options
	
	def GetCustom(self):
		return self.custom
	
	def DoCommandLine(self):
		# read command line
		try:
			self.opt, self.args = getopt.getopt(sys.argv[1:], 'fxhc:')
		except getopt.error, msg:
			raise 'Usage'

		for o, a in self.opt:
			if o == '-h':
				raise 'Usage'
			elif o == '-c':
				if a == '':
					raise Error('waspHive.Options.DoCommandLine', '-c option requires a configuration file.')
				else:
					self.options['cfgfile'] = a
					self.options['cfgwarn'] = 1
			elif o == '-f':
				self.options['force'] = 'on'
				self.force_force = 1
			elif o == '-x':
				self.options['exit'] = 'on'
			else:
				raise Error('waspHive.Options.DoCommandLine', '%s is not a valid option.' % (o))

	def DoConfigFile(self):
		# read configuration file
		myCfg = waspCfg.Cfg( self.options['cfgfile'] )

		# paths & global & look & insert
		for (n, v) in myCfg.GetSection('paths'):
			self.options[string.lower(n)] = v
		for (n, v) in myCfg.GetSection('global'):
			self.options[string.lower(n)] = v
		for (n, v) in myCfg.GetSection('look'):
			self.options[string.lower(n)] = v
		for (n, v) in myCfg.GetSection('insert'):
			self.options[string.lower(n)] = v

		# cgi
		for (n, v) in myCfg.GetSection('cgi'):
			self.options[string.lower(n)] = v

		# fill execute list with file names
		for (n, v) in myCfg.GetSection('execute'):
			self.options['execute'].append(n)

		# fill sequence list with tuples: file name, indent
		for (n, v) in myCfg.GetSection('seq'):
			self.options['sequence'].append( (n, int(v)) )

		# fill expansion dictionary with abbreviation -> expansion pairs
		for (n, v) in myCfg.GetSection('macro'):
			self.options['expansion'][string.lower(n)] = v

		if self.force_force:
			self.options['force'] = 'on'
			
		# custom entries
		for (n, v) in myCfg.GetSection('custom'):
			self.custom[n] = v
			

	def DoImport(self, namespace):
		# add module to search path
		if self.options['path_execute'] not in sys.path:
			sys.path.append( self.options['path_execute'] )

		# import required code modules
		x = self.options['execute']
		if x:
			for file in x:
				# not already available
				if not sys.modules.has_key(file):
					importSpec = os.path.join( self.options['path_execute'], file ) + '.py'
					if not os.path.isfile( importSpec ):
						raise Error('waspHive.Options.DoImport', tab + 'Execute file %s is not found in path.' % (importSpec))

					dict = GetNamespace(file, self.options['path_execute'])
					namespace.update(dict)
		
		return namespace
	
	def DoArguement(self):
		# process arguement which is a list of file specs

		if self.args:
			for f in self.args:
				# append 'wasp' if there is no extension
				(p, n, e) = ParseFile(f)
				if e == '':
					f = n + self.options['wasp']
					
				# find all matching files
				file_list = glob.glob(f)
				if file_list:
					for ff in file_list:
						self.files.append( ff )
		else:
			self.args = []
			self.args.append( self.options['path_input'] )

			# walk tree to build input file list
			for arg in self.args:
				os.path.walk( arg, self._FileWalk, (self.files, self.options['wasp']) )

	def _FileWalk(self, (file_list, file_valid), dirname, names):
		# FileWalk with me!
		# Compiles file list for specified valid extensions, 
		# excluding directory names beginning with an underscore.
		for name in names:
			(n, e) = os.path.splitext(name) 
			if e == file_valid:

				if NormPath(dirname)[0] <> '_':
					fullpath = os.path.join(dirname, name)
					file_list.append(fullpath)



def GetNamespace(f_name='', f_path=''):
	"""
		Returns a dictionary representation of the namespace imported
		by the specified module on the given path.

		f_name		= 'waspLib'
		f_path		= 'U:/rparmar/wasp/'
	"""
	ret = {}
	
	# get module info
	f_hand, f_pather, f_desc = imp.find_module(f_name, [f_path])

	try:
		# import it and snag namespace
		module = imp.load_module(f_name, f_hand, f_pather, f_desc)
		ret = module.__dict__
	finally:
		if f_hand:
			f_hand.close()

	return ret


if __name__ == '__main__':
	x = Log()
	x.Write('hello')
	del x