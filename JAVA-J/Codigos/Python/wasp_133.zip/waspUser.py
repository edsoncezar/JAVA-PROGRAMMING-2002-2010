"""
Program:
	waspUser.py

Description:
	A user registration class that uses waspSession. Methods are provided
	to Register, Login, Logout, and get current user. Initialize with the
	names of the user ID and password form fields.
	This implementation is database independent, but you will need a database
	of some type or other. The routines here assume dbAPI 2 conformity.
	
	Inherit this class and over-ride the following methods:
		FindUserPost, AddUserPost
	And optionally these:
		FindUser, AddUser, Logging
	
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.
"""

import string, time, os
import waspSession, waspHive, waspLib
from waspDebug import Debug

try:
	import fcntl
except:
	pass

class User:
	def __init__(self, f_user='x_user', f_pass='x_pass', c_user='x_user', c_pass='x_pass'):
		"""
			Initialises current user.
		"""
		# form field names
		self.f_user = f_user
		self.f_pass = f_pass

		# browser column names
		self.c_user = c_user
		self.c_pass = c_pass
		self.x_user = ''
		self.x_pass = ''
		
		# legal user ID characters
		self.legal = string.letters + string.digits  + '_'

		# connection object for database use
		self.conn = None

		# log it?
		self.log = 0
		
		# timeout in seconds
		timeout = long(waspHive.GetPublic('options', 'time_out'))

		# key string for encoding/decoding
		cryptic = waspHive.GetPublic('options', 'cryptic')

		# establish session	
		self.session = waspSession.Session(timeout, cryptic)
		
	def RestoreSession(self):
		"""
			Restores a current session.
			Returns false if it has expired.
		"""
		ok = self.session.Restore()
		if ok:
			self.x_user = self.session.get('x_user', '')

		return ok
	
	def CreateSession(self):
		"""
			Create a new session.
		"""
		self.session.Create()

	def ClearSession(self):
		"""
			Clear session.
		"""
		self.session.Clear()

	def SaveSession(self):
		"""
			Save session.
		"""
		self.session.Save()

	def InitSession(self):
		"""
			Initialise session data.
		"""
		self.session.data = {}

	def LoggingOff(self):
		"""
			Turns logging off.
		"""	
		self.log = 0
		
	def LoggingOn(self):
		"""
			Turns logging on.
		"""	
		self.log = 1

	def SetConnection(self, conn=None):
		"""
			Defines a connection object for user validation.
		"""	
		self.conn = conn

	def Logging(self, message):
		"""
			Implements logging of complete user info to a tab-delimited file.
		"""	
		if not self.log:
			return
		
		# data
		header = ('time',
				  'message',
				  'id',
				  'user',
				  'page',
				  'referer',
				  'query_string',
				  'status',
				  'user_agent',
				  'user_ip',
				  'user_host'
				  )
		detail = (	waspHive.NiceTime(),
					message,
					self.session.id,
					self.x_user,
					waspHive.GetPublic('cgi', 'page_script'),
					waspHive.GetPublic('cgi', 'referer'),
					waspHive.GetPublic('cgi', 'page_query'),
					waspHive.GetPublic('cgi', 'client_status'),
					waspHive.GetPublic('cgi', 'client_agent'),
					waspHive.GetPublic('cgi', 'client_ip'),
					waspHive.GetPublic('cgi', 'client_host')
				  )
		
	 	l = waspHive.Log(self.logfile, header)
	 	l.Write(detail)
 		del l

	def FindUser(self, confirm=0):
		"""
			Finds the current user record in database table.
			Returns empty string on success, or error message otherwise.
			Confirm flag indicates if we should verify.
			Over-ride this behaviour.
		"""
		res = ''
		if not self.conn:
			res = 'No database connection defined.'
		else:
			# execute query
			cursor = self.conn.cursor()
			q = "SELECT * FROM user WHERE %s = '%s'" % (self.c_user, self.x_user)
			cursor.execute(q)

			# report problems
			res = ''
			if cursor.rowcount == 0:
				res = 'Your user ID was not found in our database.'
			elif cursor.rowcount > 1:
				res = 'Our database requires maintenance.'
			else:
				res = self.FindUserPost(cursor)

		return res

	def FindUserPost(self, cursor):
		"""
			do whatever else you need to with record here
		"""
		res = ''
		return res

	def AddUser(self):
		"""
			Adds the current user record to the database table.
			Returns empty string on success, or error message otherwise.
			Over-ride this behaviour.
		"""

		res = ''
		if not self.conn:
			res = 'No database connection defined.'
		else:
			q = """	INSERT INTO user (%s, %s)
					VALUES ('%s', '%s')	""" % (self.c_user, self.c_pass, self.x_user, self.x_pass)

			# execute query
			cursor = self.conn.cursor()
			cursor.execute(q)

			# report problems
			if cursor.rowcount <> 1:
				res = 'You could not be added to our database.'
			else:
				res = self.AddUserPost(cursor)

		return res

	def AddUserPost(self, cursor):
		"""
			Do whatever else you need to with record here
		"""
		res = ''
		return res

	def __confirm(self):
		"""
			Basic confirmation that user ID and password are present.
			Returns empty string on success, or error message otherwise.
		"""	
		res = 'Please fill in the user ID and password fields.'
		
		form = waspHive.GetPublic('form')
		if form.has_key(self.f_user) and form.has_key(self.f_pass):
			self.x_user	= form[self.f_user].strip()
			self.x_pass	= form[self.f_pass].strip()
			
			if self.x_user and self.x_pass:
				res = ''

		return res

	def Register(self):
		"""
		Register user, confirming user ID and password. Returns empty
		string on success, or error message otherwise.
		"""	
		res = self.__confirm()
	
		if not res:
			res = self.AddUser()
			if res:
				self.Logging('registration attempt failed')
			else:
				# save user id
				self.session['x_user'] = self.x_user
				self.session.Save()

				self.Logging('registered')
			
		return res

	def SignIn(self):
		"""
			Login user, confirming user ID and password. Returns empty
			string on success, or error message otherwise.
		"""	
		res = self.__confirm()

		if not res:
			res = self.FindUser(confirm=1)
			if res:
				self.Logging('sign-in attempt failed')
			else:
				self.PutUserToSession(self.x_user)
				self.Logging('signed in')

		return res

	def SignOut(self):
		"""
			Logout user.
		"""	
		self.session.Clear()
		self.Logging('signed out')
				
		return ''

	def GetUser(self):
		"""
			Returns user name.
		"""
		return self.x_user

	def PutUserToSession(self, user):
		"""
			Stores user name in session.
		"""
		self.session['x_user'] = user
		self.session.Save()

	def GetUserFromSession(self):
		"""
			Retrieves user name from session.
		"""
		user = self.session['x_user']
		return user

	def IsSignedIn(self):
		"""
			Confirm user is signed in. Need to have done RestoreSession() first.
		"""	
		saved = self.GetUserFromSession()
		
		# handy debug line: all three should be the same
		# current	= self.x_user
		# public	= waspLib.Restore('x_user')
		# raise 'saved [%s] current [%s] public [%s]' % (saved, current, public)
	
		return saved

