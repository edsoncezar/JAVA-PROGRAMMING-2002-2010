"""
Program:
	waspLocale.py

Description:
	Contains Wasp routines to handle localization.
	It's a small world after all.

	Languages currently implemented:
		en - english [default]
		fr - french.
		
Note:
	A more robust solution would use gettext.py as documented here:
	www.python.org/doc/current/lib/module-gettext.html
				
	Based on a contribution by Cristian Tibirna.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

class Locale:
	def __init__(self, language='en'):
		self.valid = ['en', 'fr']
		
		if not language in self.valid:
			language = self.valid[0]
			
		self.language = language

	def Weekday(self):
		"""
		Returns localized weekday names.
		"""
		names = {'en' : ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
			 'fr' : ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche']}

		return names[self.language]

	def Month(self):
		"""
		Returns localized month names.
		"""
		names = {'en' : ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
			 'fr' : ['', 'Janvier', 'F�vrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Ao�t', 'Septembre', 'Octobre', 'Novembre', 'D�cembre']}

		return names[self.language]

if __name__ == '__main__':
	print 'Typical usage:'

	l = Locale('fr')
	print 'Third month of the year: %s' % l.Month()[3]