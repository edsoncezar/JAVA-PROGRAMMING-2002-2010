"""
Program:
	waspBuffer.py

Description:
	These classes implement structured containers for tabular data,
	for example dbAPI 2.0 compliant cursors. Nothing here is dependent
	on the database vendor. You may wish to write a layer above this
	module to incorporate vendor-specific functionality.
		
	The ColumnType class is used to derive new instances, each of which
	encapsulate a name, single-character ID, empty value, and alignment.
	
	The Column class has methods to set and get its attributes. These are
	primarily for use by the Buffer class. The attributes are passed in a
	dictionary that should minimally include name, type (a ColumnType
	instance), size, precision, and null (whether nulls are allowed). You
	can include additional properties.

	The ColumnType and Column properties are not used by anything except
	the Print() method, but are ready to be used by your application.
	Exception: the "empty" value is now used to fill empty cells when
	appending columns or buffers.

	The Buffer class implements list of list storage for tabular data.
	Columns may be defined, appended, and dropped. Rows may be appended
	singly or in groups. Rows, columns, and individual cells may be
	retrieved. Finally, the Buffer as an entirety can be accessed as a list
	or as a dictionary keyed by column name.

	Additional methods provide pretty print text and HTML output.	

	It is recommended that you not retrieve Buffer properties directly.
	Instead use:
		self.data --> b.GetAsList()
		size      --> len(b)

	GetAttributes() and	SelectNext() methods are provided for interfacing
	with dbAPI 2.0 compliant cursors.

Example of use:
	Please see the minimal unit test code at the end of this module.
	
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import waspHTML, copy
from waspDebug import Debug

ip = '192.168.1.126'

class ColumnType:
	def __init__(self, name, id, empty, align):
		""" Parameters: [none]
			Purpose:	instantiates new column type
			Returns:	column type instance 
		"""
		self.name	= name	
		self.id		= id		
		self.empty	= empty
		self.align	= align

# instantiate column types         
CColType	= ColumnType('character', 'C', '', 'l')
CrColType	= ColumnType('character', 'C', '', 'r')
DColType	= ColumnType('date', 'D', '2000.01.01', 'l')
IColType	= ColumnType('integer', 'I', 0, 'r')
FColType	= ColumnType('float', 'F', 0., 'r')
BColType	= ColumnType('binary', 'B', None, 'l')
	
class Column:
	""" Description: Container for attributes specific to a column.
	
		Private methods: 2
		Public methods: 5
	"""
	def __init__(self):
		""" Parameters: [none]
			Purpose:	instantiates new column
			Returns:	column instance 

			Types:
				C = Character
				I = Integer
				F = Float
		"""
		self.name 		= ''
		self.type 		= None
		self.size 		= 0
		self.precision 	= 0
		self.null	 	= 1
		
	def __len__(self):
		""" Parameters: [none]
			Purpose:	retrieves size of column
			Returns:	integer
		"""
		return self.size

	def GetAttribute(self, key=''):
		""" Parameters: attribute name
			Purpose:	retrieves specified attribute value
			Returns:	any
		"""
		if self.__dict__.has_key(key):
			return self.__dict__[key]
		else:
			raise ValueError, 'Column instance does not have attribute: %s.' % key		

	def GetAttributes(self):
		""" Parameters: [none]
			Purpose:	retrieves all attributes
			Returns:	dictionary
		"""
		return self.__dict__

	def GetAttributeNames(self):
		""" Parameters: [none]
			Purpose:	retrieves attribute names
			Returns:	list
		"""
		return self.__dict__.keys()

	def SetAttribute(self, key='', value=None):
		""" Parameters: attribute name, attribute value
			Purpose:	sets specified attribute to given value
			Returns:	[none]
		"""
		if self.__dict__.has_key(key):
			self.__dict__[key] = value
		else:
			raise ValueError, 'Column instance does not have attribute: %s.' % key		

	def SetAttributes(self, d={}):
		""" Parameters: dictionary keyed by attribute
			Purpose:	sets specified attributes to given values
			Returns:	[none]
		"""
		for k, v in d.items():
			self.SetAttribute(k, v)
		
class Buffer:
	""" Description: Container for tabular data with named columns.
	
		Private methods: 5
		Public methods: 33
	"""
	def __init__(self, col_class=Column):
		""" Parameters: [column class]
			Purpose:	instantiates new buffer
			Returns:	buffer instance 
		"""
		# class to instantiate for each column
		self.col_class = col_class
		
		# class attributes
		self.data 		= []		# a list of lists
		self.columns 	= []		# a list of instances
		
		# constant
		self.tabber 	= ' ' * 2

		# styles for HTML display
		self.style = None
		
	def __len__(self):
		""" Parameters: [none]
			Purpose:	retrieves number of rows
			Returns:	integer
		"""
		return len(self.data)
	
	def __getitem__(self, i):
		""" Parameters: row number
			Purpose:	retrieves nth row
			Returns:	list
		"""
		return self.GetRow(i)
	
	def __convert(self, col):
		""" Parameters: column name or number
			Purpose:	standardizes to column number
			Returns:	column number
		"""
		if type(col) == type(0):
			# numeric
			col_num = col
		elif type(col) == type(''):
			# string
			col_num = -1
			for i in range(self.GetColSize()):
				if self.columns[i].name == col:
					col_num = i
					break
			if col_num == -1:
				raise ValueError, 'Column "%s" not found.' % col
		else:
			# whoops
			raise TypeError, 'Column designator %s must be integer or string.' % col

		return col_num

	def Define(self, col_attr={}):
		""" Parameters: column attributes (dictionary of lists)
			Purpose:	Adds columns with specified attributes.
						Use before data is added.
			Returns:	[none]
		"""

		# initialise
		self.data 		= []
		self.columns 	= []
		
		# determine number of columns
		num_cols = 0
		if col_attr:
			try:
				num_cols = len(col_attr['name'])
			except:
				pass
			
		if num_cols == 0:
			raise ValueError, 'Column attribute dictionary is empty.'
		else:
			# grab dictionary one column at a time
			for c in range(num_cols):
				d = {}
				for k, vl in col_attr.items():
					try:
						v = vl[c]
					except:
						raise ValueError, 'Column attribute dictionary does not contain lists of the same size.'
					d[k] = v
				self.DefineColumn(d)

	def DefineColumn(self, col_attr={}, values=None, pos=-1):
		""" Parameters: column attributes, value or list of values, [position]
			Purpose:	Adds a column with attributes based on the passed dictionary
			Returns:	[none]
		"""
		# default to character type
		if not col_attr.has_key('type'):
			col_attr['type'] = CColType
		
		# class factory: derive class instance
		kol = self.col_class()
		kol.SetAttributes(col_attr)
		empty = kol.type.empty

		# add to column list or insert at specified position
		if pos == -1:
			self.columns.append(kol)
		else:
			self.columns.insert(pos, kol)
			
		# offset data
		data = []
		for i in range(len(self.data)):
			row = self.data[i]
			if pos == -1:
				row.append(empty)
			else:
				row.insert(pos, empty)
			data.append(row)
			
		# print data
		self.data = data

		# fill
		if values:
			self.FillColumn(col_attr['name'], values)

	def GetColObject(self, col):
		""" Parameters: column number or name
			Purpose:	retrieves specified column object
			Returns:	column instance
		"""
		col_num = self.__convert(col)
		kol = self.columns[col_num]
		
		return kol
	
	def FillColumn(self, col, values=None):
		""" Parameters: column name or number, value or list of values
			Purpose:	Fills specified column with (constant) value.
			Returns:	[none]
		"""
		col = self.__convert(col)
		
		# substitute values in each row
		data = []
		for i in range(len(self.data)):
			if values == None:
				value = None
			else:
				if type(values) == type([]) or type(values) == type(()):
					value = values[i]
				else:
					value = values
					
			row = self.data[i]
			row[col] = value
			data.append(row)
			
		self.data = data

	def IsColumn(self, col):
		""" Parameters: column name or number
			Purpose:	does this column exist in buffer?
			Returns:	boolean
		"""
		ret = 0
		size = self.GetColSize()
		if type(col) == type(0):
			if col < size:
				ret = 1
		elif type(col) == type(''):
			col_num = -1
			for i in range(size):
				if self.columns[i].name == col:
					ret = 1
					break
		else:
			raise TypeError, 'Column designator "%s" must be integer or string.' % col
		return ret
	
	def DropColumn(self, col_name):
		""" Parameters: column name
			Purpose:	Deletes specified column.
			Returns:	[none]
		"""
		c = self.__convert(col_name)

		# delete column instance
		del self.columns[c]

		# delete data
		for i in range(len(self.data)):
			del self.data[i][c]		
		
	def GetRowSize(self):
		""" Parameters: [none]
			Purpose:	retrieves number of rows
			Returns:	integer
		"""
		return len(self.data)
			
	def GetColSize(self):
		""" Parameters: [none]
			Purpose:	retrieves number of columns
			Returns:	integer
		"""
		return len(self.columns)
			
	def GetColNames(self, col=None):
		""" Parameters: [column number]
			Purpose:	retrieves column name by number
			Returns:	list of names OR name
		"""
		col_names = []
		if self.columns:
			for c in self.columns:
				col_names.append(c.name)

		if col <> None:
			col_names = col_names[col]

		return col_names

	def GetColAttributeNames(self):
		""" Parameters: [none]
			Purpose:	retrieves column attribute names
			Returns:	list
		"""
		attr = []
		if self.columns:
			attr = self.columns[0].GetAttributeNames()
				
		return attr

	def GetColAttribute(self, col=None, attr=None):
		""" Parameters: column name or number, attribute name
			Purpose:	retrieves specified column attribute
			Returns:	dictionary
		"""
		res = None
		if self.columns and col:
			col_num = self.__convert(col)
			res = self.columns[col_num].GetAttribute(attr)

		return res

	def GetColAttributes(self, col=None):
		""" Parameters: [column name or number]
			Purpose:	retrieves column attributes for specified column (or all
						columns if unspecified)
			Returns:	dictionary or dictionary of lists
		"""
		attr = {}
		if self.columns:
			if col:
				# single specified column
				col_num = self.__convert(col)
				attr = self.columns[col_num].GetAttributes()
			else:
				# all columns
				keys = self.GetColAttributeNames()
				for key in keys:
					l = []
					for col in self.columns:
						value = col.GetAttribute(key)
						l.append(value)
					attr[key] = l

		return attr

	def SetColAttribute(self, col=None, attr=None, value=None):
		""" Parameters: column name, attribute name, value
			Purpose:	sets column names
			Returns:	[none]
		"""
		if col==None:
			raise ValueError, 'Specify a <column name> or <column number>.'
		if attr==None:
			raise ValueError, 'Specify an <attribute name>.'
		if value==None:
			raise ValueError, 'Specify an <attribute value>.'

		col_num = self.__convert(col)
		kol = self.columns[col_num]
		kol.SetAttribute(attr, value)
		
	def SetColNames(self, col_names=[]):
		""" Parameters: list of column names
			Purpose:	sets column names
			Returns:	[none]
		"""
		if self.columns:
			for c in range(len(self.columns)):
				self.columns[c].name = col_names[c]

	def GetEmptyRow(self):
		""" Parameters: [none]  
			Purpose:	returns empty row corresponding to current structure
			Returns:	list
		"""
		row = []
		for kol in self.columns:
			row.append(kol.type.empty)
			
		return row
		
	def AddRow(self, row=[]):
		""" Parameters: row data (list) 
			Purpose:	appends row to buffer
			Note: 		size of row should match number of columns
			Returns:	[none] 
		"""
		try:
			self.data += [row]
		except:
			raise IndexError, 'size of row should match number of columns'

	def AddRows(self, rows=[]):
		""" Parameters: row data (list of lists) 
			Purpose:	appends rows to buffer
			Note: 		size of row should match number of columns
			Returns:	[none] 
		"""
		try:
			self.data += rows
		except:
			raise IndexError, 'size of row should match number of columns'

	def Zap(self):
		""" Parameters: [none] 
			Purpose:	deletes all data
			Returns:	[none] 
		"""
		self.data = []

	def AppendFromList(self, new_data=[]):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use AddRows() instead.'

	def AppendFromDict(self, dict={}):
		""" Parameters: dictionary of lists, keyed by column name
			Purpose:	Appends data from dictionary.
						Each list must be the same length.
						Columns must already exist.
			Returns:	[none]
		"""
		# get integer keys
		ikeys = []
		for name in dict.keys():
			if not self.IsColumn(name):
				raise IndexError, 'column [%s] not found.' % name
			ikeys.append( self.__convert(name) )
			
		# add records
		for i in range(len( dict[names[0]] )):
			row = []
			
			# tricky stuff:
			# for each column number find matching contents of ikeys
			# and use this as an index into the dictionary
			for j in range(len( self.columns )):
				col = None
				for k in range(len(ikeys)):
					if j == ikeys[k]:
						col = dict[keys[k]][i]
						break
				row.append( col )

			self.data.append(row)

	def AppendFromBuffer(self, b=None):
		""" Parameters: buffer
			Purpose:	appends new columns from specified buffer
			Note:		existing columns are not changed
			Returns:	[none]
		"""
		if not b:
			raise ValueError, 'AppendFromBuffer() requires a buffer instance.'

		for name in b.GetColNames():
			if self.IsColumn(name):
				raise ValueError, 'All the columns must be new.'

		# current empty fields
		starter = self.GetEmptyRow()

		# add new columns
		ender = []
		for name in b.GetColNames():
			attrib = b.GetColAttributes(name)
			empty = attrib['type'].empty
			
			self.DefineColumn(attrib)
			ender.append(empty)

		# complete current rows
		temp = []
		for row in self.data:
			temp.append(row + ender)

		# add new rows
		for row in b:
			temp.append(starter + row)

		# update
		self.data = temp

	def GetRow(self, row_num):
		""" Parameters: row number
			Purpose:	retrieves specified row as list
			Returns:	row == list of cell values
		"""
		try:
			ret = self.data[row_num]
			return ret
		except:
			raise IndexError
		
	def GetRowAsDict(self, row_num):
		""" Parameters: row number
			Purpose:	retrieves specified row as dictionary
			Returns:	dictionary, keyed by column name
		"""
		row = self.GetRow(row_num)

		# for each column
		dict = {}
		for c in range(len(self.columns)):
			dict[self.columns[c].name] = row[c]
			
		return dict

	def GetCol(self, col):
		""" Parameters: column number or name
			Purpose:	retrieves specified column data
			Returns:	column == list of cells
		"""
		col_num = self.__convert(col)

		col = []
		for row in self.data:
			col.append( row[col_num] )
		
		return col
	
	def GetCell(self, row_num, col):
		""" Parameters: row number, column number or name
			Purpose:	retrieves specified cell
			Returns:	cell contents
		"""
		col_num = self.__convert(col)
		row = self.GetRow(row_num)

		try:
			ret = row[col_num]
			return ret
		except:
			raise IndexError

	def GetCellStrip(self, row_num, col):
		""" Parameters: row number, column number or name
			Purpose:	retrieves specified cell
			Returns:	cell contents stripped of whitespace
		"""
		c = self.GetCell(row_num, col)
		return str(c).strip()
			
	def PutCell(self, row_num, col, value):
		""" Parameters: row number, column number or name
			Purpose:	stores value to specified cell
			Returns:	cell contents
		"""
		col_num = self.__convert(col)
		row = self.GetRow(row_num)

		try:
			self.data[row_num][col_num] = value
		except:
			raise IndexError
	
	def GetAsCursor(self):
		""" Parameters: [none]
			Purpose:	returns data in format cursor objects expect
			Returns:	list of tuples
		"""
		cursor = []
		for row in self.data:
			cursor.append( tuple(row) )

		return cursor

	def GetAsList(self):
		""" Parameters: [none]
			Purpose:	returns a list of columns for each row
			Returns:	list of lists
		"""
		return self.data

	def GetAsDict(self):
		""" Parameters: [none]
			Purpose:	returns a list of columns for each key
			Returns:	dictionary, keyed by column name
		"""
		dict = {}
		# for each column
		for i in range(len(self.columns)):
			roww = []
			# for each row
			for row in self.data:
				roww.append(row[i])
			dict[self.columns[i].name] = roww
		return dict
	
	def FindRowNum(self, col, match):
		""" Parameters: column to search in, contents to match
			Purpose:	finds first row where column equals match contents
			Returns:	row number
		"""
		ret = -1
		col = self.__convert(col)

		for row_num in range(len(self.data)):
			row = self.GetRow(row_num)
			if row[col] == match:
				ret = row_num
				break
			
		return ret

	def FindRowAsDict(self, col, match):
		""" Parameters: column to search in, contents to match
			Purpose:	finds first row where column equals match contents
			Returns:	row as dictionary
		"""
		ret = {}
		row_num = self.FindRowNum(col, match)
		if row_num > -1:
			ret = self.GetRowAsDict(row_num)

		return ret
	
	def Print(self, most=0):
		""" Parameters: [maximum number of rows to print]
			Purpose:	pretty prints
			Returns:	<null>
		"""
		print self.__FormatRow(self.GetColNames())

		x = ''
		for i in range(len(self.columns)):
			col		= self.columns[i]
			width	= max( col.size, len(col.name) )
			x += ('=' * width) + self.tabber
		print x

		rows_done = 0
		size = self.GetRowSize()
		for row_num in range(size):
			print self.__FormatRow( self.GetRow(row_num) )
			rows_done += 1
			if most <> 0 and rows_done == most:
				break
			
		print 'printed %s of %s rows' % (rows_done, size)
	
	def __FormatRow(self, row):
		""" Parameters: row == list of cell values
			Purpose:	prints row with correct column justification 
			Visibility:	<private>
			Returns:	<null>
		"""
		buffer = ''
		for i in range(len(self.columns)):
			col		= self.columns[i]
			cell	= str(row[i])
			width	= max( col.size, len(col.name) )
			
			# justify (placed in-line for efficiency)
			n = width - len(cell)
			if n > 0:
				if col.type.align == 'l':
					buffer += cell + ' ' * n
				else:
					buffer += ' ' * n + cell 
			else:
				buffer += cell[:width]

			buffer += self.tabber
		
		return buffer

	def ApplyStyle(self, style=None):
		""" Parameters: style
			Purpose:	Applies specified style
			Returns:	[none]
		"""
		if style:
			self.style = style

	def HTMLKey(self):
		""" Parameters: [none]
			Purpose:	prints cursor attributes in nice HTML
			Returns:	[none]
		"""
		# data consists of:
		#   attribute key labels in the first row,
		#   followed by attributes themselves for each column name

		attr = self.GetColAttributes()
		if attr:
			printme = []
			printme.append( ['&nbsp;'] + attr.keys() )
			for k, v in attr.items():
				printme.append([k, v])

			x = waspHTML.ListToHTML(printme)
			x.ApplyStyle(self.style)
			print x.WithBothHeaders()

	def HTMLbyRow(self, empty_ok=0):
		""" Parameters: print even if empty
			Purpose:	prints cursor in nice HTML, row-first
			Returns:	<null>
		"""
		if empty_ok or len(self.data) > 0:
			# add column names as first row in our data
			printme = copy.copy(self.data)
			printme.insert(0, self.GetColNames()) 

			x = waspHTML.ListToHTML(printme)
			x.ApplyStyle(self.style)
			print x.WithRowHeader()
			
	def HTMLbyCol(self, empty_ok=0):
		""" Parameters: print even if empty
			Purpose:	prints cursor in nice HTML, column-first
			Returns:	<null>
		"""
		if empty_ok or len(self.data) > 0:
			# invert row/column
			printme = []
			for i in range(len(self.columns)):
				row = [self.columns[i].name]
				for j in range(len(self.data)):
					datum = self.data[j][i]
					row.append(datum)
				printme.append(row)
				
			x = waspHTML.ListToHTML(printme)
			x.ApplyStyle(self.style)
			print x.WithColHeader()
			
	def HTML(self, empty_ok=0):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use HTMLbyRow() instead.'
	
	def GetCursor(self):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use GetAsCursor() instead.'

	def GetBufferAsList(self):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use GetAsList() instead.'

	def GetBufferAsDict(self):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use GetAsDict() instead.'
		
	def LoadDescription(self, description, column_first=0):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use () instead.'
		
	def FromCursor(self, cursor, column_first=0):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use () instead.'
		
	def AddColumn(self, col_name, values=None, pos=-1):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use DefineColumn() instead.'
		
	def FromDict(self, dict):
		""" DEPRECATED
		"""
		raise DeprecationWarning, 'Use AppendFromDict() instead.'


def GetAttributes(mapping, cursor, column_first=1):
	""" Parameters: dbAPI cursor, [ordering of data]
		Purpose:	load attributes from cursor description
		Notes:		If different interfaces followed the spec the same
					way, we wouldn't need column_first. Note: pypg uses 1.
		Returns:	column attributes (dictionary of lists)
	"""
	desc = cursor.description
	if not desc:
		# can't do this because null cursors have no description!
		# raise ValueError, 'Cursor description not found.'
		return {}
		
	# first, translate to our dictionary
	d = {}
	if column_first: 
		d['name']		= []
		d['type']		= []
		d['size']		= []
		d['precision']	= []
		d['null']		= []
		
		for info in desc:
			d['name'].append( info[0] )
			d['type'].append( info[1] )
			d['size'].append( info[2] )
			d['precision'].append( info[4] )
			d['null'].append( info[6] )
			
			# not used -- here FYI
			internal_size	= info[3]
			scale			= info[5]
	else:
		d['name']		= list(desc[0])
		d['type']		= list(desc[1])
		d['size']		= list(desc[2])
		d['precision']	= list(desc[4])
		d['null']		= list(desc[6])

	# then, convert to column type instances
	t = []
	for ty in d['type']:
		ty = str(ty)
		if not mapping.has_key(ty):
			raise ValueError, 'Column type [%s] not found in mapping.' % ty
			
		inst = mapping[ty]

		t.append(inst)
	d['type'] = t
	
	return d

def SelectNext(mapping, cursor, page=0):
	""" Parameters: dbAPI cursor, [number of records]
		Purpose:	Returns a "page" of records from cursor as a Buffer.
		Notes:		If page is zero, all the records are returned.
					That could be a lot!
		Returns:	Buffer instance
	"""
	# grab requisite number of records
	if page > 0:
		rows = cursor.fetchmany(page)
	else:
		rows = cursor.fetchall()

	attr = GetAttributes(mapping, cursor)
	if attr:
		# define buffer
		b = Buffer()
		b.Define(attr)

		# load data
		b.data	= [list(row) for row in rows]
		
		# add new properties
		b.oid	= cursor.oidValue
		b.page	= page
	else:
		# need an object that has a length
		b = ''

	return b
	
if __name__ == '__main__':
	#==== test suite ====#

	if 1:
		# subclass column
		class MyColumn(Column):
			def __init__(self):
				Column.__init__(self)
				self.flag = 0
			
		# column structure
		structure = {	'name' 		: ['id', 'first', 'last', 'city', 'year'],
						'type' 		: [CColType, CColType, CColType, CColType, IColType],
						'size' 		: [6, 30, 30, 20, 4],
						'precision'	: [0, 0, 0, 0, 0],
						'null'		: [0, 0, 0, 1, 1],
						'flag'		: [1, 0, 0, 0, 0]
					}
						
		# define some data sets
		set1 = [['000001', 'Max', 'Ernst', 'Br�hl', 1891],
				['000002', 'Dorothea', 'Tanning', 'Galesburg', 1910],
				['000003', 'Marcel', 'Duchamp', 'Blainville', 1887],
				['000004', 'Hugo', 'Ball', 'Pirmasens', 1886 ] ]
		set2 = [['000011', 'Jean', 'Arp', 'Strasbourg', 1887],
				['000012', 'Paul', 'Eluard', 'Saint-Denis', 1895],
				['000013', 'Francis', 'Picabia', 'Paris', 1879] ]
		set3 = { 'first'	: ['Jean', 'Paul', 'Francis'],
				 'id'		: ['000011', '000012', '000013'],
				 'last'		: ['Arp', 'Eluard', 'Picabia'],
				 'city'		: ['Strasbourg', 'Saint-Denis', 'Paris'],
				 'year'		: [1887, 1895, 1879] }
		
		# test ahoy!
		print
		print 'Define our buffer...'
		b = Buffer(MyColumn)
		b.Define(structure)

		print
		print 'View column names:'
		print b.GetColAttributeNames()

		print
		print 'Change column attributes (set flag to 1 for <last>):'
		b.SetColAttribute('last', 'flag', 1)

		print
		print 'View all column attributes:'
		d = b.GetColAttributes()
		for k, v in d.items():
			print '%s : %s' % (k, v)

		print
		print 'Add first data set...'
		b.AddRows(set1)

		print
		print 'Column named "first":'
		print b.GetCol('first')

		print
		print 'Plain view of buffer:'
		print b.data

		print
		print 'GetBufferAsDict:'
		print b.GetAsDict()

		print
		print 'GetCursor:'
		print b.GetAsCursor()
		
		print
		print 'Plain loop:'
		for row in b:
			print row

		print
		print 'Add second data set...'
		b.AddRows(set2)

		print
		print 'Row number "5":'
		print b.GetRow(5)

		print
		print 'Find last name Ernst:'
		print b.FindRowAsDict('last', 'Ernst')

		class style:
			def __init__(self):
				self.table_attribute			= 'border="0" cellspacing="2" cellpadding="6"'
				self.form_table					= 'orang'
				self.form_td_label_align_left	= 'orangLabel'
				self.form_td_label_align_right	= 'orangLabel'
				self.form_td_column_right		= 'orangField'
				self.form_td_grid_detail		= 'orangGrid'
				self.form_td_grid_header		= 'orangGridh'
				
				self.buffer_table				= 'orang'
				self.buffer_th_header			= 'orangLabel'
				self.buffer_tr_row				= ''
				self.buffer_td_even				= 'orangEven'
				self.buffer_td_odd				= 'orangOdd'
				
		my_style = style()

		print
		print 'HTML:'
		b.ApplyStyle(my_style)
		b.HTMLbyRow()

		print
		print 'Print:'
		b.Print()
		
		print
		print 'Delete column named "city"...'
		b.DropColumn('city')

		print
		print 'Add new column...'
		b.DefineColumn({'name':'hobby', 'type':CColType, 'size':60}, 'painting', 0)
		
		print
		print 'Print:'
		b.Print()
		
		print
		print 'New buffer:'
		bb = Buffer(MyColumn)
		struc2 = {	'name' 		: ['sample'],
					'type' 		: [CColType],
					'size' 		: [10],
					'precision'	: [0],
					'null'		: [0],
					'flag'		: [0]
				}
		bb.Define(struc2)
		bb.AddRows([['one'], ['two']])

		print
		print 'Print:'
		bb.Print()
		
		print
		print 'Append from original buffer:'
		bb.AppendFromBuffer(b)
		bb.Print()

		del b
		del bb
		
	if 1:
		# our table structure and data
		structure = {	'name' : ['name', 'city', 'year'],
						'type' : [CColType, CColType, IColType],
						'size' : [20, 15, 4]
					}
		data = [['Max Ernst', 'Br�hl', 1891],
				['Dorothea Tanning', 'Galesburg', 1910],
				['Marcel Duchamp', 'Blainville', 1887],
				['Hugo Ball', 'Pirmasens', 1886 ]
				]
		
		# define buffer
		b = Buffer()
		b.Define(structure)

		# load data
		for datum in data:
			b.AddRow(datum)

		# now work with buffer
		total = 0
		count = 0
		for row in b:
			total += row[2]
			count += 1

		# some output
		b.Print()
		print
		print 'average year: %s' % (total/count)
		