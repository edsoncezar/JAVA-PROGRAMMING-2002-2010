"""
Program:
	waspDebugServer.py

Description:
	Debugging server. Run from command-line. Include a parameter
	if you wish a non-default name for the log file.

Usage:
	See waspDebug.py
	
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import waspDebug
import sys

if len(sys.argv) < 2:
	waspDebug.Debugagram().Server()
else:
	waspDebug.Debugagram().Server(sys.argv[1])

