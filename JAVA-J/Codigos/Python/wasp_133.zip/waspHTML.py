"""
Program:
	waspHTML.py

Description:
	HTML output modules and classes for Wasp.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import os, string

class WebColour:
	""" Defines three colour sets plus greyscale and allows stepping
		through them using common colour names. """
	def __init__(self, design):
		if design == 'hard' :
			self.c_list = {	'red'		: 'ff0000',
							'blue'		: '0000ff',
							'orange'	: 'ff6600',
							'purple'	: 'cc00ff',
							'green'		: '009900',
							'yellow'	: 'ffff00',
							'grey'		: '666666'
							}

		elif design == 'mid' :
			self.c_list = {	'red'		: 'ff0066',
							'blue'		: '0033ff',
							'orange'	: 'ff9933',
							'purple'	: '9933cc',
							'green'		: '339900',
							'yellow'	: 'ffff66',
							'grey'		: '999999'
							}

		elif design == 'pastel' :
			self.c_list = {	'red'		: 'ff9999',
							'blue'		: '66ccff',
							'orange'	: 'ffcc33',
							'purple'	: 'cc99ff',
							'green'		: '00cc99',
							'yellow'	: 'cc9966',
							'grey'		: 'cccccc'
							}
		else:
			print 'Error: please choose an available design'
			
		self.c_list['white'] = 'ffffff'
		self.c_list['black'] = '000000'
		self.c_index = ['red', 'orange', 'yellow', 'grey', 'blue', 'purple', 'green', 'white', 'black']
		self.c_x = 0
		self.c_bw = {	'100'	: '000000',
						'80'	: '333333',
						'60'	: '666666',
						'40'	: '999999',
						'20'	: 'cccccc',
						'0'		: 'ffffff'
						}
		
	def Get(self, name):
		""" get colour by name """
		try:
			ret = self.c_bw[name]
		except:
			try:
				ret = self.c_list[name]
			except:
				ret = name
		return ret
		

	def Next(self):
		""" increment colour """
		colour_name = self.c_index[self.c_x]
		colour_code = self.c_list[colour_name]
					
		self.c_x = self.c_x + 1
		if self.c_x == len(self.c_index):
			self.c_x = 0
			
		return [colour_name, colour_code]
	
class DictToHTML:
	"""
		Turn an arbitrarily nested dictionary into an HTML table in
		two easy methods. Now accepts a list, in which case the first
		item is taken to be the key.
	"""
	
	def __init__(self, data, table=''):
		self.data = data
		self.table = table
		
		# define some good stuff
		self.cr = os.linesep
		self.tr = '<tr align="left">'
		self.td = '<td valign="top" bgcolor="eeeeee">'
		self.th = '<th valign="top">'

		if type(self.data) is type({}):
			self.keys = self.data.keys()
		elif type(self.data) is type([]):
			self.keys = self.data[0]
			self.data = self.data[1:]
		else:
			self.keys = []

	def byCol(self, sort=0):
		# return string containing table by column
		
		# sort keys?
		self.sort = sort
		if self.sort:
			self.keys.sort()
			
		# write header
		text = self.tr
		for key in self.keys:
			text = text + self.th + '%s</th>' % (key)
		text = text + '</tr>' + self.cr
		
		# write each row
		text = text + self.tr
		for key in self.keys:
			item = self.data[key]
			text = text + self.td + '%s</td>' % (self._getCell(item, 'col'))
		text = text + '</tr>' + self.cr

		return self._startTable() + text + self._endTable()

	def byRow(self, sort=0):
		# return string containing table by row

		# sort keys?
		self.sort = sort
		if self.sort:
			self.keys.sort()
			
		# do each row
		text = ''
		for key in self.keys:
			item = self.data[key]
			text = text + self.tr + self.th + ('%s</th>' % (key))
			text = text + self.td + ('%s</td>' % (self._getCell(item, 'row'))) + '</tr>' + self.cr
		
		return self._startTable() + text + self._endTable()

	def _startTable(self):
		return '<table %s>%s' % (self.table, self.cr)
		
	def _endTable(self):
		return '</table>' + self.cr
		
	def _getCell(self, item, axis):
		# return cell contents
		import types

		# process according to type
		if type(item) is type({}):
			# cell is itself a dictionary: mmm... recursion
			if axis == 'row':
				cell = DictToHTML(item, self.table).byRow(self.sort)
			elif axis == 'col':
				cell = DictToHTML(item, self.table).byCol(self.sort)
				
		elif type(item) is types.InstanceType:
			# cell rather undefined, so try stuff 'till it works
			try:
				cell = '' 
				for itemer in item:
					cell = cell + str(itemer) + '<br>'
			except:
				try:
					if axis == 'row':
						cell = DictToHTML(item, self.table).byRow(self.sort)
					elif axis == 'col':
						cell = DictToHTML(item, self.table).byCol(self.sort)
				# exceptions rock!
				except:
					cell = str(item)
					
		elif type(item) is type([]):
			# cell is a list
			if self.sort:
				item.sort()
			cell = '' 
			for itemer in item:
				cell = cell + str(self._getCell(itemer, axis)) + '<br>'

				
		elif type(item) is type(()):
			# cell is a tuple
			cell = '' 
			for itemer in item:
				cell = cell + str(self._getCell(itemer, axis)) + '<br>'
		else:
			cell = item

		return FixCell(cell)

class ListToHTML:
	"""
		Parameters: list of lists
		Purpose:	prints data as nice HTML, with first row and
					column as headers
		Returns:	<null>
	"""
	def __init__(self, data):
		self.data	= data
			
		self.tb_on	= '<table>\n'
		self.tb_of	= '</table>\n'
		self.tr_on	= '<tr align="left">'
		self.tr_of	= '</tr>\n'
		self.td_eve_on	= '<td valign="top" bgcolor="eeeeee">'
		self.td_odd_on	= '<td valign="top" bgcolor="eeffee">'
		self.td_of	= '</td>'
		self.th_on	= '<th valign="top">'
		self.th_of	= '</th>'
		
	def ApplyStyle(self, style):
		"""
		Applies specified styles:
		table attributes, table class, tr class, th class, td class
		"""
		tb_a	= style.table_attribute	
		tb_s	= style.buffer_table
		th_s	= style.buffer_th_header
		tr_s	= style.buffer_tr_row
		td_se	= style.buffer_td_even
		td_so	= style.buffer_td_odd

		if tb_a:
			tb_a = ' ' + tb_a
		if tb_s:
			tb_s = ' class="%s"' % tb_s 
		self.tb_on	= '<table%s%s>\n' % (tb_a, tb_s)
			
		if tr_s:
			self.tr_on	= '<tr class="%s">' % tr_s
		if th_s:
			self.th_on	= '<td class="%s">' % th_s
		if td_se:
			self.td_eve_on	= '<td class="%s"">' % td_se
		if td_so:
			self.td_odd_on	= '<td class="%s"">' % td_so

	def WithBothHeaders(self):
		"""
		First row is a header.
		First column in subsequent rows is a header.
		"""
		count = 0
		text = self.__row1(count, 'h', self.data[0][0], self.data[0][1:])
		for dat in self.data[1:]:
			text += self.__row1(count, 'd', dat[0], dat[1:])
			count += 1
			
		return self.tb_on + text + self.tb_of

	def WithBothHeadersCustom(self, l=[]):
		"""
		Requires list as long as number of rows, containing row type.
		First column is a header.
		"""
		if len(l) <> len(self.data):
			raise 'list must be as long as rows'
		
		count = 0
		text = ''
		for i in range(len(self.data)):
			dat = self.data[i]
			typ = l[i]
			text += self.__row1(count, typ, dat[0], dat[1:])
			count += 1
			
		return self.tb_on + text + self.tb_of

	def WithColHeader(self):
		"""
		First column in each row is a header.
		"""
		count = 0
		text = ''
		for dat in self.data:
			text += self.__row1(count, 'd', dat[0], dat[1:])
			count += 1
			
		return self.tb_on + text + self.tb_of

	def __row1(self, count, ty, label, row):
		""" Parameters: count, row type, row label, row cells
			Purpose:	formats each row for WithBothHeaders()
			Returns:	<null>
		"""
		if ty == 'h':
			ton = self.th_on
			tof = self.th_of
			text = '%s%s%s%s' % (self.tr_on, self.th_on, label, self.th_of)
		else:
			if count % 2:
				ton = self.td_odd_on
			else:
				ton = self.td_eve_on
			tof = self.td_of
			text = '%s%s%s%s' % (self.tr_on, self.th_on, label, self.th_of)
			
		for cell in row:
			cell = FixCell(cell)
			text += '%s%s%s' % (ton, cell, tof)
		text += self.tr_of
		
		return text

	def WithRowHeader(self):
		"""
		First row is a header.
		Subsequent rows are just data.
		"""
		count = 0
		text = self.__row2(count, 'h', self.data[0])
		for dat in self.data[1:]:
			text = text + self.__row2(count, 'd', dat)
			count += 1
			
		return self.tb_on + text + self.tb_of

	def __row2(self, count, ty, row):
		""" Parameters: count, row type, row label, row cells
			Purpose:	formats each row for WithRowHeader()
			Returns:	<null>
		"""
		if ty == 'h':
			ton = self.th_on
			tof = self.th_of
		else:
			if count % 2:
				ton = self.td_odd_on
			else:
				ton = self.td_eve_on
			tof = self.td_of
			
		text = ''
		for cell in row:
			cell = FixCell(cell)
			text += '%s%s%s' % (ton, cell, tof)
		text = '%s%s%s' % (self.tr_on, text, self.tr_of)
		
		return text

class Form:
	"""
		Handles HTML forms as a table with two columns.
		
		Normal procedure is to call methods in this order:
			DefineAction()
			ApplyStyle()	optional
			DefineWidths()	optional
			Add*()			as needed
			Write()
		
		Uses the following style properties:
			style.attribute	
			style.class_table
			style.class_header
			style.class_label
			style.class_data
		To do:
			Add method for BUTTON
			Add accesskey="" to BUTTON, INPUT, TEXTAREA

	"""
	def __init__(self):
		self.wid_l	= ''
		self.wid_r	= ''
		self.css_h	= ''
		self.css_l	= ''
		self.css_r	= ''
		self.action	= ''
		self.submit	= 'Submit'
		self.output = ''
		self.grid	= ''
		self.grid_width = 0
		self.tb_on	= '<table border="0" cellspacing="3" cellpadding="3">\n'
		self.encoding = ''

	def DefineAction(self, action=None, submit=None):
		if action:
			self.action	= action
		if submit:
			self.submit	= submit

	def ApplyStyle(self, style):
		tb_a	= style.attribute	
		tb_s	= style.class_table
		css_h	= style.class_header
		css_l	= style.class_label
		css_r	= style.class_data	
		               
		if tb_a:
			tb_a = ' ' + tb_a
		if tb_s:
			tb_s = ' class="%s"' % tb_s 
		self.tb_on	= '<table%s%s>\n' % (tb_a, tb_s)

		if css_h:
			self.css_h = ' class="%s"' % css_h
		if css_l:
			self.css_l = ' class="%s"' % css_l
		if css_r:
			self.css_r = ' class="%s"' % css_r

	def DefineWidths(self, wid_l=None, wid_r=None):
		if wid_l:
			self.wid_l = wid_l
		if wid_r:
			self.wid_r = wid_r

	def DefineEncoding(self, encoding=''):
		self.encoding = encoding

	def __start(self):
		if self.encoding:
			enc = 'enctype="%s" ' % self.encoding
		else:
			enc = ''
			
		self.output = '<form action="%s" %smethod="post">\n%s' % (self.action, enc, self.tb_on)
		if self.wid_l or self.wid_r:
			self.output += '<tr height="1"><td width="%s">&nbsp;</td><td width="%s"&nbsp;</td></tr>\n' %\
				(self.wid_l, self.wid_r)
		
	def __end(self):
		self.__print( '<tr><td>&nbsp;</td><td%s><input type="submit" value="%s"></td></tr>' % (self.css_r, self.submit) )
		self.__print( '</table></form>' )

	def __wrap(self, field, label_l=None, label_r=None):
		"""
			produce row by wrapping left and right labels around field
		"""
		if label_r:
			label_r = '&nbsp;<small>%s</small>' % label_r
		if not label_l:
			label_l = '&nbsp;'
		self.__print( '<tr><td%s>%s</td><td%s>%s%s</td></tr>' %\
			(self.css_l, label_l, self.css_r, field, label_r) )

	def __print(self, text):
		if not self.output:
			self.__start()
		self.output = self.output + text + '\n'
		
	def AddHeader(self, label_l='', label_r=''):
		self.__print( '<tr><td colspan="2"%s>%s&nbsp<small>%s</small></td></tr>' % (self.css_h, label_l, label_r) )
		
	def AddFooter(self, label_l='', label_r=''):
		self.__print( '<tr><td colspan="2"%s>%s&nbsp<small>%s</small></td></tr>' % (self.css_r, label_l, label_r) )
		
	def AddText(self, name, label_l='', label_r='', size=10, value=''):
		x = '<input type="text" name="%s" size="%s" maxlength="%s" value="%s">' %\
			(name, size, 80, value)
		self.__wrap(x, label_l, label_r)

	def AddPassword(self, name, label_l='', label_r='', size=10, value=''):
		x = '<input type="password" name="%s" size="%s" maxlength="%s" value="%s">' %\
			(name, size, 80, value)
		self.__wrap(x, label_l, label_r)

	def AddTextArea(self, name, label_l='', label_r='', rows=2, cols=40, value=''):
		x = '<textarea name="%s" rows="%s" cols="%s">%s</textarea>' %\
			(name, rows, cols, value)
		self.__wrap(x, label_l, label_r)

	def AddFile(self, name, label_l='', label_r='', size=40, accept='*.*'):
		x = '<input type="file" name="%s" size="%s" accept="%s">' %\
			(name, size, accept)
		self.__wrap(x, label_l, label_r)
		
	def AddHidden(self, name, value=''):
		x = '<input type="hidden" name="%s" value="%s">' % (name, value)
		self.__wrap(x, '', '')

	def AddCheckBox(self, name, label_l='', label_r='', checked=0):
		if checked:
			y = ' checked'
		else:
			y = ''
		x = '<input type="checkbox" name="%s" value="X"%s>' % (name, y)
		self.__wrap(x, label_l, label_r)
		
	def AddPickList(self, name, label_l, label_r, contents=[]):
		"""
			option selector
			pass a list that is either:
			a) a list of labels
			b) a list of lists containing values and labels
		"""
		x = '<select name="%s">\n' % name 
		
		first = ' selected'
		if type(contents[0]) is type([]):
			for val, label in contents:
				if val and label:
					x = x + '<option value="%s"%s>%s</option>\n' % (val, first, label)
				else:
					x = x + '-' * 15
				first = ''
		else:
			for label in contents:
				if label:
					x = x + '<option%s>%s</option>\n' % (first, label)
				else:
					x = x + '-' * 15
				first = ''
		x = x + '</select>\n'

		self.__wrap(x, label_l, label_r)

	def AddGridHeader(self, width=0, *labels):
		""" put a table of labels in right cell """
		self.grid = ''
		self.grid_width = width
		size = len(labels)
		if size > 0:
			x = '<table border="0" cellspacing="3" cellpadding="3"><tr>'
			for lab in labels:
				x = '%s<td width="%s"><small>%s</small></td>' % (x, self.grid_width, lab)
			x = '%s</tr></table>\n' % (x)
			self.__wrapgrid(x, '')

	def AddGridCell(self, name, size=10, value=''):
		self.grid += '%s<td width="%s"><input type="text" name="%s" size="%s" maxlength="%s" value="%s"></td>' % (self.grid_width, name, size, 80, value)

	def AddGridRow(self, label_l=''):
		x = '<table border="0" cellspacing="3" cellpadding="3"><tr>%s</tr></table>\n' % self.grid
		self.__wrapgrid(x, label_l)
		self.grid = ''

	def __wrapgrid(self, field, label_l=None):
		if not label_l:
			label_l = '&nbsp;'
		self.__print( '<tr valign="middle"><td align="right"%s><small>%s</small></td><td%s>%s</td></tr>' %\
			(self.css_l, label_l, self.css_r, field) )

	def Write(self):
		self.__end()
		print self.output,
		
def Row(claz, columns):
	"""
	Formats a list/tuple of strings as an HTML table row.
	"""
	if type(columns[0]) is (type(()) or type([])):
		columns = columns[0]

	ret = ''
	for cell in columns:
		cell = FixCell(cell)
		ret += '<td class="%s">%s</td>' % (claz, cell)
	print '<tr>%s</tr>' % ret

def FixCell(cell):
	cell = str(cell)
	if cell == '':
		cell = '&nbsp;'
	return cell
