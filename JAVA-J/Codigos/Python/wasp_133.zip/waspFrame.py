#!/usr/local/bin/py

"""
Program:
	waspFrame.py

Description:
	waspFrame is shallow wrapper around WaspCGI.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

pass
# uncomment the following to aid in debugging
# print 'Content-type: text/html\n\n'

# change this as needed
execute_path = '/usr/local/apache/wasp'

import os, sys

if os.environ.has_key('DOCUMENT_ROOT'):
	global public
	public = {}

	if execute_path not in sys.path:
		sys.path.append(execute_path)

	import waspCGI

	sys.exit( waspCGI.WaspCGI().Sting() )
else:
	print 'Content-type: text/html\n\n'
	print 'Error: waspCGI must run under a CGI environment.'
