"""
Program:
	waspCookie.py

Description:
	A simple Cookie class, derived from RFC HTTP State Management Mechanism,
	available at: http://www.ietf.org/rfc/rfc2109.txt
	
	Note: I now know that Python 2.0 has a cookie implementation, but I wrote
	this one before seeing it.
	
	This module knows nothing of os.environ['HTTP_COOKIE'], though you
	would likely pass that to CookieJar when instantiating. This makes
	it easier to test in a non-CGI environment. Maybe.
	
Interface:
	SetCookie(name, value=None, expires=None, comment=None, domain=None, path=None, secure=None, version=None, age=None):
		takes a required cookie name followed by optional keyword parameters
		for each cookie attribute. Age is in seconds from the present.
	KillCookie(name): deletes specified cookie (by setting age to 0)
	GetCookieValue(name): value of specified cookie
	GetCookieFormatted(name): specified cookie, formatted for HTTP headers
	GetJarFormatted(): concatenated output from all cookies, formatted for HTTP headers
	GetJarPlain(): plain text concatenated output from all cookies
	GetJarScript(): concatenated output from all cookies, setting JavaScript
			property document.cookie, so you can use them on the client side
	
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.
"""

import string, time, os
from waspDebug import Debug

zero_time = time.mktime((1990, 1, 1, 12, 00, 00, 0, 1, 0))

def ConvertDate(my_time=None, offset=0):
	"""
	Returns given time (defaults to current) in the GMT format expected by
	a Set-Cookie expires attribute. Second argument is a time offset in seconds.
	"""
	if not my_time:
		my_time = time.time()
		
	ret = time.strftime('%a, %d-%b-%Y %H:%M:%S GMT', time.gmtime(my_time + offset))
	return ret

class CookieError(Exception):
	pass

class Cookie:
	def __init__(self):
		self.ok_attrib	= ['Expires', 'Comment', 'Domain', 'Max-Age', 'Path', 'Secure', 'Version']
		self.attrib = {}
		self.name	= None
		self.value	= None

	def Read(self, x=None):
		if x:
			# split into attribute and value
			if '=' in x:
				(a, v) = string.split(x, '=', 1)
				a = string.strip(a)
				v = string.strip(v)
			else:
				a = string.strip(x)
				v = ''
			
			# is it an attribute?
			if a in self.ok_attrib:
				self.attrib[a] = v
			elif a:
				# or name/value?
				self.name = a
				self.value = v
					
			self.__Required()
		
	def Create(self, n=None, v=None):
		if not n:
			raise CookieError('Cookie requires a name')
		self.name = n

		if not v:
			v = ''
		self.value = v
		
		self.__Required()

	def __Required(self):
		""" enforce required attributes """
		if not self.attrib.has_key('Version'):
			self.attrib['Version'] = '1'

	def SetName(self, x=None):
		self.name = x

	def SetValue(self, x=None):
		self.value = x

	def SetAttribute(self, a, v):
		# will not prevent illegal settings
		if a in self.ok_attrib:
			self.attrib[a] = v
			
			if a == 'Max-Age':
				# HTTP/1.0 method uses Expires attribute
				if v == 0:
					# January 1, 1990
					expires = ConvertDate(zero_time)
				else:
					expires = ConvertDate(None, v)
				
				self.SetAttribute('Expires', expires)
			
	def GetName(self):
		return self.name

	def GetValue(self):
		return self.value

	def GetFormatted(self):
		# according to the spec, there can be spaces around the =
		# but don't do it or older browsers might barf
		x = 'Set-Cookie: %s=%s' % (self.name, self.value)
		for (a, v) in self.attrib.items():
			x = '%s;%s=%s' % (x, a, v)
		return x
			
	def GetPlain(self):
		# according to the spec, there can be spaces around the =
		# but don't do it or older browsers might barf
		x = '%s=%s' % (self.name, self.value)
		for (a, v) in self.attrib.items():
			x = '%s;%s=%s' % (x, a, v)
		return x
	
	def Kill(self):
		""" stale cookie """
		self.SetAttribute('Max-Age', 0)

		
class CookieJar:
	""" a dictionary-like class """
	def __init__(self, enviro=None):
		"""
		Create dictionary of Cookie objects. You should
		likely pass os.environ['HTTP_COOKIE'] as enviro.
		"""
		
		# dictionary of cookies, indexed by name
		self.data = {}
		cookies = ''
		
		# grab cookies from passed environment
		if enviro and enviro is type(''):
			# cookies are separated by semi-colons
			cookies = enviro.split(';')
			for cook in cookies:
				cook = cook.strip()
				snack = Cookie()
				snack.Read(cook)
				self.data[ snack.GetName() ] = snack

	def SetCookie(self, name, value=None, expires=None, comment=None, domain=None, path=None, secure=None, version=None, age=None):
		"""
		Sets attributes of specified cookie. Creates
		cookie if it is not found in the jar.
		"""
		ok = 1
		
		# retrieve cookie from jar
		if self.data.has_key(name):
			snack = self.data[name]
			if value:
				snack.value = value
		else:
			snack = Cookie()
			if value:
				snack.Create(name, value)
			else:
				snack.Create(name, '')
				
		if ok:
			# required for old Netscape browsers
			if not path:
				path = '/'

			if not age and expires:					# deprecated
				snack.SetAttribute('Expires', expires)
			if age <> None:
				snack.SetAttribute('Max-Age', age)

				# HTTP/1.0 method requires Expires attribute
				if age==0:
					# January 1, 1990
					expires = ConvertDate(zero_time)
				else:
					expires = ConvertDate(None, age)
				
				snack.SetAttribute('Expires', expires)
			if comment:
				snack.SetAttribute('Comment', comment)
			if domain:
				snack.SetAttribute('Domain', domain)
			if path:
				snack.SetAttribute('Path', path)
			if secure:
				snack.SetAttribute('Secure', secure)
			if version:
				snack.SetAttribute('Version', version)
				
			self.data[name] = snack
				
	def KillCookie(self, name):
		""" delete specified cookie """

		if self.data.has_key(name):
			# stale cookie  
			self.SetCookie(name, maxage=0)
		
	def GetCookieValue(self, name, domain=None):
		""" retrieve value of specified cookie """
		
		ok = None

		# retrieve cookie from jar
		if self.data.has_key(name):
			snack = self.data[name]
			
			# confirm domain
			if domain:
				if snack.attrib.has_key('Domain') and snack.attrib['Domain'] == domain:
					ok = snack.GetValue()
			else:
				ok = snack.GetValue()
		return ok

	def GetCookieFormatted(self, name):
		""" retrieve specified cookie, formatted """
		
		# retrieve cookie from jar
		if self.data.has_key(name):
			snack = self.data[name]
			
			# get formatted
			ok = snack.GetFormatted()
		else:
			ok = None

		return ok

	def GetJarFormatted(self):
		"""
		Concatenate formatted output from all cookies.
		Put each on it's own line because some browsers have issues otherwise.
		"""
		
		x = ''
		for (name, snack) in self.data.items():
			x = x + '\nSet-Cookie: ' + snack.GetPlain()
		if x:
			x = x[1:]
		return x
	
	def GetJarPlain(self):
		""" concatenate output from all cookies """
		
		x = ''
		for (name, snack) in self.data.items():
			x = x + ',' + snack.GetPlain()
		if x:
			x = x[1:]
		return x

	def GetJarScript(self):
		""" get all cookies, formatted for JavaScript """
		
		x = '<script type="text/javascript" language="JavaScript 1.2"> <!-- Cloak On\n'
		x = '%sdocument.cookie = "%s"\n//--> </script>\n' % (x, self.GetJarFormatted())
		return x

	# =====
	# basic dictionary functionality ripped from UserDict.UserDict
	# rather than inheriting for performance (yes, it makes a difference)
	def __repr__(self): return repr(self.data)
	def __len__(self): return len(self.data)
	def __setitem__(self, key, item):
		# !! modified !!
		if self.data.has_key(key):
			self.SetCookie(key, value=item)
			
	def __getitem__(self, key):
		# !! modified !!
		if self.data.has_key(key):
			return self.GetCookieValue(key)
		else:
			return ''

	def get(self, key, failobj=None):
		# !! modified !!
		if self.data.has_key(key):
			return self.GetCookieValue(key)
		else:
			return failobj
		
	def __delitem__(self, key):
		# different behaviour to avoid throwing error
		if self.data.has_key(key):
			del self.data[key]

	def __cmp__(self, dict):
		if isinstance(dict, Session):
			return cmp(self.data, dict.data)
		else:
			return cmp(self.data, dict)

	def clear(self): self.data.clear()
	def keys(self): return self.data.keys()
	def items(self):
		# !! modified !!
		x = []
		for key in self.data.keys():
			x.append( (key, self.GetCookieValue(key)) )
		return x
	
	def values(self):
		# !! modified !!
		x = []
		for key in self.data.keys():
			x.append( self.GetCookieValue(key) )
		return x
	
	def has_key(self, key): return self.data.has_key(key)
	def update(self, dict):
		if isinstance(dict, UserDict):
			self.data.update(dict.data)
		elif isinstance(dict, type(self.data)):
			self.data.update(dict)
		else:
			for k, v in dict.items():
				self.data[k] = v
	def setdefault(self, key, failobj=None):
		# !! change?
		if not self.data.has_key(key):
			self.data[key] = failobj
		return self.data[key]
	def popitem(self):
		return self.data.popitem()
