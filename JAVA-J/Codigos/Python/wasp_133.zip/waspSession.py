"""
Program:
	waspSession.py

Description:
	This session class transparently handles web application data
	persistence, thus enabling "sessions".

	Session state is maintained by saving a unique ID to a client side cookie.

	The session class acts as a dictionary for whatever other info you 
	wish to stuff in it. This data is saved on the server side by pickling
	it to a flat file. The implementation is hence database independent.

Interface:
	Restore(): If there is a session for this user, restores it. Otherwise,
		create a new session. Returns false if a session has expired.
	Create(): starts a new session with new ID and timeout based on now
	Clear(): removes current session
	Save(): saves current session info 
		
Notes:
	This implementation is new as of Wasp 1.29. Several methods of
	Session() have been	simplified or trimmed. Outside functions have been
	integrated as methods.

	Timeouts seem to be buggy under Explorer 5.5 when on daylight-savings time
	(and in other cases?). In any case this implementation does not care about
	cookie timeouts since this is tracked on the server side.
	
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.
"""

import string, time, os, glob, md5, base64, random

# wasp likes pickles
try:
	import cPickle
	dill = cPickle
except ImportError:
	import pickle
	dill = pickle
	
# wasp likes cookies too
import waspHive
from waspDebug import Debug
ip = '192.168.1.126'

# container for pickles
class glass:
	pass

def GetID():
	"""
		Returns a unique key based on current time.
		Attributes:
		* 22 characters long
		* safe to use as file name
	"""
	# seed that is likely unique
	seed =	random.choice(string.printable) +\
			str(time.time()) +\
			random.choice(string.printable)
			
	# RSA's MD5 message digest algorithm (RFC 1321)
	m = md5.new(seed).digest()

	# use base-64 encoding to conform with RFC 1521
	# remove static junk at end
	m = base64.encodestring(m)[:-3]
	
	# don't want characters that upset file naming
	m = m.replace('/', '_')
	m = m.replace('+', '_')
	return m
	
class SessionError(Exception):
	pass

class Session:
	""" a dictionary with additional methods """
	def __init__(self, time_out=0, cryptic='', domain=None):
		self.path		= ''		# path for session files
		self.fn			= '.sess'	# extension for session files
		self.name		= 'wasp'	# session cookie name
		
		# variables
		self.cryptic	= cryptic
		self.expiry		= 0
		self.data		= {}
		self.id			= None
		
		# time out in seconds (from cfg file)
		# we're not using this timeout for cookies right now
		self.time_out = time_out
		
		# domain
		self.__CheckDomain(domain)
		self.domain	= domain
		
	def SetName(self, name):
		self.name = name
		
	def SetPath(self, path):
		# should be absolute
		self.path = path
		
	def Restore(self):
		"""
			1. Checks for existing session.
				a) Creates a new session if there is not one.
				b) Otherwise, restores session data.
			2. Saves data in public space
			3. Returns false if session has expired.
		"""
		# delete expired session files
		# should do this in separate daemon for sites with high hit rate
		self.__DeleteExpiredFiles()
		
		ok = 1
		
		# grab cookies from current environment
		cookie = waspHive.GetPublic('cookie_in').GetCookieValue(self.name)
		if not cookie:
			# no session established, so start one
			self.Create()
		else:
			# we have a cookie, so a session exists
			self.id = self.__Unpack( cookie )
		
			# is session id valid?
			if not self.__FileExists(self.id):
				# what we do at this point depends on security
				ok = 0
			else:
				# get contents
				self.data, self.expiry = self.__FromFile(self.__FileName(self.id))
				
				now = time.time()
				if self.expiry < now:
					# we've expired!
					ok = 0
				else:
					# update time so session continues
					self.Save()

			# clean up
			if not ok:
				self.Clear()
			
		return ok
		
	def Create(self):
		""" Starts a new session """
		self.data	= {}

		# get fresh id
		id = GetID()
		while self.__FileExists(id):
			id = GetID()
		self.id	= id

		self.Save()

	def Clear(self):
		""" remove session """

		# remove session file
		if self.id:
			fn = self.__FileName(self.id)
			if os.path.exists(fn):
				os.remove(fn)
			
		# clear data
		self.data		= {}
		self.id			= ''
		c_domain		= None
		if self.domain:
			c_domain = self.domain
		
		# save to public space
		waspHive.SetPublic(self.data, 'session')

		# clear cookie
		waspHive.GetPublic('cookie_out').SetCookie(self.name, age=0, domain=c_domain)

	def Save(self):
		"""
		Save current session to file, public space, and cookie.
		(Proper headers are written by waspCGI in due course from the
		cookie public dictionary.)
		"""
		# parameters
		c_value		= None
		c_domain	= None
		c_age		= 0
		
		if self.id:
			c_value = self.__Pack(self.id)
		if self.domain:
			c_domain = self.domain
		if self.time_out:
			c_age = 60*60*8			# 8 hours
			
		self.expiry	= time.time() + self.time_out

		# save to file
		if self.id:
			self.__ToFile( self.__FileName(self.id) )

		# save to public space
		waspHive.SetPublic(self.data, 'session')

		# save to cookie
		waspHive.GetPublic('cookie_out').SetCookie(self.name, value=c_value, age=c_age, domain=c_domain)
		
	def __FromFile(self, fn):
		""" loads data from persistent storage in specified file """
		
		# container for all things picklable
		glaz = glass()
		glaz.data	= self.data
		glaz.expiry	= self.expiry

		fd = open(fn, 'rb')
		glaz = dill.load(fd)
		fd.close()
		
		return glaz.data, glaz.expiry

	def __ToFile(self, fn):
		""" saves data to persistent storage """
		
		# container for all things picklable
		glaz = glass()
		glaz.data	= self.data
		glaz.expiry	= self.expiry
		glaz.id		= self.id

		fd = open(fn, 'wb')
		dill.dump(glaz, fd)
		fd.close()

	def __CheckDomain(self, domain):
		"""
		Is specified domain ok? If we are "www.yahoo.com" then domain should
		be ".yahoo.com".
		"""
		
		if domain:
			x = ''
			if domain[0] <> '.':
				x = 'Domain %s must start with a dot (according to spec).' % domain
			elif '.' not in domain[1:]:
				x = 'Domain %s must have an embedded dot (according to spec).' % domain
			elif domain[len(domain)-3:] == '...':
				x = 'Domain %s must not end with three dots (to prevent spoofing).' % domain

			if x:
				raise SessionError(x)
		
	def __FileExists(self, id):
		""" does session file exists? """
		return os.path.exists(self.__FileName(id))

	def __FileName(self, this_id):
		""" create full file path from id """
		ret = os.path.join( self.path, '%s%s' % (this_id, self.fn) )
		return ret

	def __DeleteExpiredFiles(self):
		""" delete expired session files """

		# what time is now?
		now = time.time()

		# grab all session files
		fn_list = glob.glob( self.__FileName('*') )
		for fn in fn_list:
			# check expiry
			data, expiry = self.__FromFile(fn)

			if expiry < now:
				os.remove(fn)

	def __Unpack(self, val):
		"""	Unpack session id from cookie by unescaping and decoding. """
		return waspHive.Decode( waspHive.Unescape(val), self.cryptic )

	def __Pack(self, id):
		""" Pack session id into cookie by encoding and escaping. """
		return waspHive.Escape( waspHive.Encode('%s' % id, self.cryptic) )
				
	# =====
	# basic dictionary functionality ripped from UserDict.UserDict
	# rather than inheriting for performance (yes, it makes a difference)
	def __repr__(self): return repr(self.data)
	def __len__(self): return len(self.data)
	def __getitem__(self, key):
		# different behaviour to avoid throwing error
		if self.data.has_key(key):
			return self.data[key]
		else:
			return ''

	def __setitem__(self, key, item):
		self.data[key] = item
	def __delitem__(self, key):
		# different behaviour to avoid throwing error
		if self.data.has_key(key):
			del self.data[key]

	def __cmp__(self, dict):
		if isinstance(dict, Session):
			return cmp(self.data, dict.data)
		else:
			return cmp(self.data, dict)

	def clear(self): self.data.clear()
	def keys(self): return self.data.keys()
	def items(self): return self.data.items()
	def values(self): return self.data.values()
	def has_key(self, key): return self.data.has_key(key)
	def update(self, dict):
		if isinstance(dict, UserDict):
			self.data.update(dict.data)
		elif isinstance(dict, type(self.data)):
			self.data.update(dict)
		else:
			for k, v in dict.items():
				self.data[k] = v
	def get(self, key, failobj=None):
		return self.data.get(key, failobj)
	def setdefault(self, key, failobj=None):
		if not self.data.has_key(key):
			self.data[key] = failobj
		return self.data[key]
	def popitem(self):
		return self.data.popitem()
