"""
Program:
	waspCfg.py

Description:
	A simple configuration file class. Such "INI" or "CFG" files
	consists of sections starting with [headers], followed by 
	"name: value" entries, separated by : or whatever. Comment lines 
	start with # or * or ;.

	This module is simpler (no interpolation) than ConfigParser, but
	lacks a couple of bugs <grin>.

	Section names are not case sensitive but name: value entries are.

	Needs a few more methods to be useful for updating files.

	Parameters are:
		full file spec
		separator character [default :]
		boolean indicating full parsing of value, using same separator
		
Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

Version:
	1.05	2001.02.13	new self.comment, support for ; comments
	1.04	2001.02.12	new PutValue(), update Write(), deprecated GetSectionRaw()
	1.03	2001.01.25	add parameter to do full parsing of value
	1.02	2000.11.22	updated a tad, read() renamed __read(),
						new PrettyPrint(), GetValue(), GetValueError(), __getValue()
						changed method names to interCap style
	1.01	2000.07.28	updated a tad, new error class
	1.00	2000.05.12	born
"""

import sys, string, os

__version__ = '1.05 (2001.02.13)'

class Error:
	""" error class """
	def __init__(self, msg=''):
		self._msg = '%s -- %s' % ('class Cfg', msg)
	def __repr__(self):
		return self._msg

class Cfg:
	def __init__(self, cfgFile, sep=':', full=0):
		if cfgFile is None:
			raise Error('requires a file name.')
		if not os.path.isfile(cfgFile):
			raise Error('%s is not found at: %s.' % (cfgFile, os.path.abspath(cfgFile)))

		self.sep 		= sep
		self.sections	= []
		self.items		= []
		self.file		= cfgFile
		self.full		= full
		self.comment	= ('#', '*', ';')
		self.__read()

	def __read(self):
		try:
			h = open(self.file, 'r')
		except:
			raise Error('%s cannot be read.' % (self.file))
		else:
			section = ''
			while 1:
				line = h.readline()
				if line == '':
					break
				else:
					line = string.strip(line)
					# comments
					if line == '' or line[0] in self.comment:
						pass
					# section headers
					elif line[0] == '[' and line[-1] == ']':
						section = string.lower( line[1:-1] )
						self.sections.append(section)
					# name, value pairs
					else:
						if string.find(line, self.sep) == - 1:
							name = line
							value = ''
						else:
							(name, value) = string.split(line, self.sep, 1) 
							if not name:
								raise Error('bad configuration line.')
							if not value:
								value = ''
						if section == '':
							raise Error('name/value pair outside of section.')
						else:
							name = string.strip(name)
							value = string.strip(value)
				
							# full parsing of value, using same separator
							if self.full:
								v = string.split(value, self.sep)
								value2 = []
								for item in v:
									value2.append( string.strip(item) )
								if len(value2) > 1:
									value = value2
							self.items.append([section, name, value])
			h.close()

	def GetSections(self):
		""" return list of sections """
		return self.sections
		
	def GetSection(self, section):
		""" return list of name: value entries for section """
		section = string.lower(section)
		ret = []
		if self.HasSection(section):
			for (s, n, v) in self.items:
				if s == section:
					ret.append((n, v))
		return ret

	def GetSectionRaw(self, section):
		""" return list of name: value entries for section """
		section = string.lower(section)
		ret = []
		if self.HasSection(section):
			for (s, n, v) in self.items:
				if s == section:
					ll = []
					ll.append(n)
					cells = string.split(v, self.sep)
					for x in range(len(cells)):
						ll.append(cells[x])
					ret.append(ll)
		return ret

	def PutValue(self, section='', name='', value=''):
		if section and name and value:
			section = string.lower(section)
			if self.HasSection(section):
				ok = 0
				for i in range(len(self.items)):
					(s, n, v) = self.items[i]
					if string.lower(s) == section and n == name:
						self.items[i] = [s, n, value]
						ok = 1
						break
				if not ok:
					self.items.append([section, name, value])
			else:
				self.AddSection(section)
				self.items.append([section, name, value])
		
	def GetValue(self, section='', name=''):
		return self.__getValue(section, name, 0)


	def GetValueError(self, section='', name=''):
		return self.__getValue(section, name, 1)
		
	def __getValue(self, section, name, err=0):
		""" return value given section and name """
		section = string.lower(section)

		ok = 0
		ret = ''
		for (s, n, v) in self.items:
			if string.lower(s) == section and n == name:
				ok = 1
				ret = v

		if not ok and err:
			raise Error('section / name not found.')
			
		return ret

	def HasSection(self, section):
		""" do we have specified section? """
		return section in self.sections

	def AddSection(self, section):
		""" adds a section if it does not already exists """
		section = string.lower(section)
		if not self.HasSection(section):
			self.sections.append(section)

	def DelSection(self, section):
		""" deletes a section if it exists """
		section = string.lower(section)
		if self.HasSection(section):
			for x in range(len(self.sections)):
				if self.sections[x] == section:
					del self.sections[x]
					break
			for x in range(len(self.items)-1, -1, -1):
				if self.items[x][0] == section:
					del self.items[x]

					
	def PrettyPrint(self):
		tab = ' ' * 4
		n_col = 'Name'
		v_col = 'Value'
		
		for s in self.GetSections():
			print 
			print 'Section: %s' % s
			
			# find maximum column widths
			n_max = len(n_col)
			v_max = len(v_col)
			for (n, v) in self.GetSection(s):
				n_max = max( n_max, len(n) )
				v_max = max( v_max, len(v) )

			# now print
			print tab + string.ljust(n_col, n_max) + tab + string.ljust(v_col, v_max)
			print tab + '=' * n_max + tab + '=' * v_max
			for (n, v) in self.GetSection(s):
				print tab + string.ljust(n, n_max) + tab + string.ljust(v, v_max)

	def Write(self):
		""" writes the configuration file """
		try:
			h = open(self.file, 'w')
		except:
			raise Error('%s cannot be opened.' % (self.file))
		else:
			section = ''
			for (s, n, v) in self.items:
				if s <> section:
					if section:
						h.write('\n')
					h.write( '[%s]\n' % s )
					section = s
				h.write('%s %s %s\n' % (n, self.sep, v))
			h.close()

			
if __name__ == '__main__':
	""" an example of use """

	x = """[me]
myMail = robin.escalation@ACM.org
myName = Robin Parmar
myUrl = http://www.execulink.com/~robin/
myWeb = The Theatre of Noise

[macro]
* lines like this are ignored
x = xmas
e = easter
m = mother's day

[fauna]
# these too
animals = 0
reptile = 1
lizards= 2
gecko = 3
anole = 3
snake = 2
asp = 3
python = 3"""
	
	h = open('test.cfg', 'w')
	h.write(x)
	h.close()
	
	myCfg = Cfg('test.cfg', '=')


	print '====='

	print myCfg.GetSections()
	print myCfg.HasSection('macro')

	
	myCfg.DelSection('macro')
	print myCfg.HasSection('macro')



	myCfg.PrettyPrint()

	

