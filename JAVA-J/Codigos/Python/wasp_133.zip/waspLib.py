"""
Program:
	waspLib.py

Description:
	Contains Wasp user routines. A few protocols:

	* If your routine encounters an error, raise "LibError"
	so it can be handled properly.

	* Simply print any output you wish output to HTML.

	* If you wish to share data between routines, declare it global.
	See Store() and Restore() for implementation.

	* Public variables are returned in a dictionary from GetPublic().

	* Return values are used by if/endif constructs.
	
	See the HTML docs for more.

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import time, os, sys, re, string
import waspHive, waspHTML, waspCfg, waspSession, waspLocale
from waspDebug import Debug
from waspHive import GetPublic as Get

def WhoAmI():
	"""
		Test routine to query current page info.
	"""
	page	= Get('cgi', 'page_name')
	fullpath= Get('cgi', 'page_fullpath')
	script	= Get('cgi', 'page_script')

	print '<p>%s: %s</p>' % ('page',	page)
	print '<p>%s: %s</p>' % ('fullpath',fullpath)
	print '<p>%s: %s</p>' % ('script',	script)
	                                   
def SetCookie():
	"""
		Test routine to set cookies (see test_cookie.wasp).
	"""
	# here's how you access forms
	form = Get('form')
	name = form.get('name', '')

	if name:
		c_name		= form.get('name', '')
		c_value		= form.get('value', '')
		c_age		= int(form.get('age', 0))

		# here's how you set a cookie
		Get('cookie_out').SetCookie(name, value=c_value, age=c_age)

		# auto-refresh current page
		waspHive.Refresh()

def GetCookie():
	"""
		Test routine to get cookies (see test_cookie.wasp).
	"""
	jar = Get('cookie_in')
	x = ''
	for k, v in jar.items():
		x += '<b>%s</b>: %s<br>' % (k, v)
	if x:
		print '<p>%s</p>' % x[:-4]
	else:
		print '<p>None.</p>'

def StateRestore():
	"""
		Session test routine: restores session
		See session.wasp
	"""
	# timeout in seconds
	timeout = long(Get('options', 'time_out'))

	# key string for encoding/decoding
	cryptic = Get('options', 'cryptic')

	# establish session	
	s = waspSession.Session(timeout, cryptic)
	s.Restore()
	return s

def StateSave():
	"""
		Session test routine: stores values from form to session
		See session.wasp
	"""
	s = StateRestore()

	# grab form
	form = Get('form')

	# retrieve fields
	s['first_name']	= form.get('first_name', '')
	s['last_name']	= form.get('last_name', '')
	s['magic']		= form.get('magic', '')

	# save values (on server side)
	s.Save()

	print '<p>Thanks for logging in.</p>'
	print '<p>Try the other pages using the little menu below. Your name should be restored from the session. Voila! State persistence!</p>'
	print '<p>If you wait a while, the session will expire.</p>'

def StateRecall():
	"""
		Session test routine: displays values restored from session
		See session.wasp
	"""
	s = StateRestore()
	
	first_name	= s['first_name']
	last_name	= s['last_name']
	magic		= s['magic']
		
	if first_name and last_name:
		print '<p>Welcome: %s %s<br>(with magic %s)</p>' % (first_name, last_name, magic)
	else:
		print '<p>Sorry, your session has expired.</p>'
	
def Test( str ):
	"""
		Merely returns the parameter given. Used to test if/endif directives.
	"""
	return str

def Store(name, value):
	"""
		Stores <value> in variable <name> using persistent
		dictionary 'storage'.
	"""
	# we want this to persist
	global storage

	# initialize if it's not present already
	g = globals()
	if not g.has_key('storage'):
		storage = {}

	# go ahead and store		
	storage[name] = value

	return

def Restore(name):
	"""
		Prints the value of variable <name> from persistent
		dictionary 'storage'.
	"""
	# it's this simple!
	global storage
	ret = storage.get(name, None)

	return ret

def Compare(name, value):
	"""
		Compares the content of variable <name> (if it exists
		in the persistent dictionary 'storage') with <value>.
		To be used with the <?w if: ?> tag.
		
		Based on a contribution by Cristian Tibirna (ctibirna@giref.ulaval.ca).
	"""
	global storage
	ret = 0
	if storage.has_key(name):
		ret = storage[name] == value

	return ret

def PrintEnviro():
	"""
		Output useful info on current environment.
	"""
	
	# general
	err_dump = {	'time'				: waspHive.NiceTime( time.time() ),
					'current folder'	: os.getcwd(),
					'system path'		: sys.path,
					'process id'		: os.getpid(),
					'imported modules'	: dir()}
	
	if sys.platform[:5] == 'linux':
		err_dump['process user id']			= os.getuid()
		err_dump['process id of parent']	= os.getppid()

	print '<h2>General environment:</h2>'
	print waspHTML.DictToHTML(err_dump).byRow(1)


	# cookies
	print '<h2>cookie:</h2><p>'
	jar = Get('cookie_in')
	x = ''
	for k, v in jar.items():
		x += '<b>%s</b>: %s<br>' % (k, v)
	if x:
		print '<p>%s</p>' % x[:-4]
	else:
		print '<p>None.</p>'


	# Wasp
	print '<h2>Wasp environment:</h2>'

	sections = ['form', 'query', 'options', 'custom', 'cgi']
	for section in sections:
		print '<h2>%s:</h2><p>' % section
		d = Get(section)
		if d:
			print waspHTML.DictToHTML(d).byRow()
		else:
			print '<p>None.</p>'
	return

def Row(claz, *columns):
	"""
		Formats a list/tuple of strings as an HTML table row.
	"""
	if type(columns[0]) is type([]):
		columns = columns[0]

	ret = '<tr class="%s">' % claz
	for col in columns:
		ret = '%s<td>%s</td>' % (ret, col)
	print ret + '</tr>'
	return ''

def PRow(claz, column, per):
	"""
		Creates an HTML table row from column data and numeric percentage.
	"""
	x = ''
	per = int(per/10)

	for i in range(10):
		if i > per or (per == 0 and i == per):
			x += '<img src="res/p3.gif">'
		elif i == per:
			x += '<img src="res/p2.gif">'
		elif i < per:
			x += '<img src="res/p1.gif">'
		
	ret = '<tr class="%s">' % claz
	ret += '<td>%s</td>' % column
	ret += '<td>%s</td>' % x
	print ret + '</tr>'
	return ''

def Cfg2Table(file, clazz='', total_on=0, bg_h1='green', bg_h2='greeny', bg_row='grey'):
	"""
		Formats a tab-delimited cfg file as an HTML table.
	"""
	if not os.path.isfile(file):
		raise 'LibError', '%s is not found.' % (file)
	myCfg = waspCfg.Cfg(file, '|')

	if clazz:
		clazz = ' class="%s"' % clazz
	clazz = '<table%s ' % clazz
	
	for s in myCfg.GetSections():
		print clazz + 'cellspacing="4" cellpadding="4" width="90%" align="center">'
		if bg_h1:
			Row(bg_h1, '%s' % s)
		count = -1

		for col in myCfg.GetSection(s):
			c = string.split(col[0], '\t')

			if count == -1 and bg_h2:
				claz = bg_h2
			else:
				claz = bg_row
			Row(claz, c)
			count = count + 1
			
		if total_on:
			Row('green', 'total: %s' % count)
		print '</table><p>&nbsp;</p>'

	del myCfg
	return ''

def ReadTable(file, my_section='', colour='pastel', table_open='<def>'):
	"""
		Formats the specified section of a tab-delimited cfg file as an HTML table.
		The colour palette and attributes for the table tag may optionally be specified.

		Each line in the cfg file consists of three or more elements.
		The first is the type of formatting:
			b	bar chart
			c	two cells, first coloured
			d	data
			p	percentile
		The second is either the colour from the specified palette or the css class to use.
		The third and subsequent are the table cell contents.
		Here's a summary, commas standing in for tabs.
			b, cell colour for bar, text, bar width
			c, cell colour for column 1, text1, text2
			d, row class, text1, text2,...
			p, row class, text1, text2,..., percent of bar width
	"""
	# read config file
	if not os.path.isfile(file):
		raise 'LibError', 'ReadTable() could not find file %s.' % (file)
	myCfg = waspCfg.Cfg(file, '\t')

	# read global configuration section
	table_wid = None
	key_wid = None

	section = 'config'
	if myCfg.HasSection(section):
		# width of entire table
		table_wid = float(myCfg.GetValue(section, 'table_width'))
		# width of first column
		key_wid = int(myCfg.GetValue(section, 'key_width'))

	if not table_wid:
		table_wid = 500.0
	if not key_wid:
		key_wid = 150

	# process section
	section = my_section
	if not myCfg.HasSection(section):
		raise 'LibError', 'ReadTable() could not find section %s in file %s.' % (section, file)

	# process rows
	rows = []
	max_value = 0
	for (row_type, row) in myCfg.GetSection(section):
		cells = string.split(row, '\t')
		rows.append( [row_type, cells[0], cells[1:]] )
		
		if row_type == 'b':				# bar chart
			max_value = max(max_value, int(cells[-1]) )
	del myCfg
		
	# scale cell size
	if max_value == 0:
		scale_factor = 0
	else:
		scale_factor = table_wid / max_value
	
	# prepare table tags
	if table_open == '<def>':
		table_open = ' cellspacing="2" cellpadding="2"'
	elif table_open <> '':
		table_open = ' ' + table_open
	table_open = '<table%s>\n' % table_open
	table_close = '</table>\n\n'
	
	myColour = waspHTML.WebColour(colour)

	col = ''
	print table_open

	# do each row
	for (row_type, look, cells) in rows:
		result = ''
		
		if row_type == 'b':				# bar chart with colours
			# if max_value == 0:
			# 	continue
	
			# only 2 cells allowed
			key	= cells[0]
			val	= int(cells[1])
			col1_wid = int(val * scale_factor)
			col2_wid = int(table_wid) - col1_wid
			
			if look == 'next':
				col = myColour.Next()
			elif look == 'same':
				if col == '':
					col = myColour.Next()
			else:
				col = myColour.Get(look)
			
			result = '<tr><td width="%s">%s</td>' % (key_wid, key)
			result += '<td><table cellspacing="0" cellpadding="0" width="%s"><tr>' % (int(table_wid))
			result += '<td width="%s" bgcolor="#%s">&nbsp;</td>' % (col1_wid, col)
			result += '<td width="%s">%s</td>' % (col2_wid, val)
			result += '</tr></table></tr></td></tr>'
	
		if row_type == 'c':				# equal chart with colours
			# only 2 cells allowed
			key	= cells[0]
			val	= cells[1]
			
			if look == 'next':
				col = myColour.Next()
			elif look == 'same':
				if col == '':
					col = myColour.Next()
			else:
				col = myColour.Get(look)
			
			result = '<tr><td bgcolor="#%s" width="%s">%s</td>' % (col, key_wid, key)
			result += '<td>%s</td></tr>' % val
	
		if row_type == 'd':				# regular data with classes
			for col in cells:
				result += '<td>%s</td>' % col
			result = '<tr class="%s">%s</tr>\n' % (look, result)
			
		elif row_type == 'p':			# percentile bars with classes
			per		= cells[-1]
			cells	= cells[:-1]
			for col in cells:
				result += '<td>%s</td>' % col
			
			result = '%s<td>' % result
			div	= 10
			per	= int(int(per)/div)
			for i in range(div):
				if i > per or (per == 0 and i == per):
					result += '<img src="res/p3.gif">'
				elif i == per:
					result += '<img src="res/p2.gif">'
				elif i < per:
					result += '<img src="res/p1.gif">'
			result = '%s</td>' % result
			result = '<tr class="%s">%s</tr>\n' % (look, result)

		print result
	print table_close
	return ''

def GanttChart(file):
	"""
		Creates an HTML Gantt chart from the specified tab-delimited cfg file.
		A Gantt chart depicts progress in relation to time, and is often used
		to plan and track a project.
	"""
	# read config file
	if not os.path.isfile(file):
		raise 'LibError', 'GanttChart() could not find file %s.' % (file)
	myCfg = waspCfg.Cfg(file, '\t')

	# read global configuration section
	section = 'config'
	if not myCfg.HasSection(section):
		raise 'LibError', 'GanttChart() could not find [%s] section in file %s.' % (section, file)
	try:
		# number of cfg sections to follow
		c_parts		= int(myCfg.GetValueError(section, 'parts'))

		# width in pixels of each bar chart unit
		c_pixel_per_unit = float(myCfg.GetValueError(section, 'pixel_per_unit'))

		# total number of bar chart units
		c_unit_max	= int(myCfg.GetValueError(section, 'unit_max'))

		# colour palette to use
		c_palette	= myCfg.GetValueError(section, 'palette')

		# text label and size for column 1 
		temp		= string.split( myCfg.GetValueError(section, 'label1'), '\t' )
		c_label1	= temp[0]
		c_size1		= int(temp[1])

		# text label and size for column 2
		temp		= string.split( myCfg.GetValueError(section, 'label2'), '\t' )
		c_label2	= temp[0]
		c_size2		= int(temp[1])

		# text label for column 3
		c_label3	= myCfg.GetValueError(section, 'label3')
		c_size3		= int(c_pixel_per_unit * c_unit_max)

		# table tag attributes (optional)
		c_table		= myCfg.GetValue(section, 'table_tag')

		# first row tag attributes (optional)
		c_head		= myCfg.GetValue(section, 'head_tag')

		# odd row tag attributes (optional)
		c_odd		= myCfg.GetValue(section, 'odd_tag')
		if c_odd == None:
			c_odd = ''
		else:
			c_odd = ' ' + c_odd
			
		# even row tag attributes (optional)
		c_even		= myCfg.GetValue(section, 'even_tag')
		if c_even == None:
			c_even = ''
		else:
			c_even = ' ' + c_even

		# timeline on? (optional)
		c_time			= myCfg.GetValue(section, 'time_on')
		if c_time in ('1', 'on', 'yes', 'true'):
			c_time = 1
			temp		= string.split( myCfg.GetValueError(section, 'time_look'), '\t' )
			c_time_odd	= temp[0]
			c_time_even	= temp[1]
		else:
			c_time = 0
	except:
		raise 'LibError', 'GanttChart() could not find correct entries in section %s of file %s.' % (section, file)


	col = waspHTML.WebColour( c_palette )
	c_size_total = c_size1 + c_size2 + c_size3

	# prepare tags
	if c_table:
		table_open = '<table %s width="%s">\n' % (c_table, c_size_total)
	else:
		table_open = '<table width="%s">\n' % (c_size_total)
		
	table_head = '<td width="%s"><b>%s</b></td><td width="%s"><b>%s</b></td><td width="%s"><b>%s</b>' % (c_size1, c_label1, c_size2, c_label2, c_size3, c_label3)

	# build timeline
	if c_time:
		y = ''
		for i in range(c_unit_max):
			if waspHive.isEven(i):
				my_class = c_time_even
			else:
				my_class = c_time_odd
			y = y + '<td width="%s" class="%s">&nbsp;</td>' % (int(c_pixel_per_unit), my_class)
		table_head = '%s<br><table cellspacing="0" cellpadding="0"><tr>%s</tr></table>' % (table_head, y)

	table_head = '%s</td></tr>\n' % (table_head)
	if c_head:
		table_head = '<tr %s>%s' % (c_head, table_head)
	else:
		table_head = '<tr>%s' % table_head

	# output header row
	print table_open
	print table_head

	# read each part
	for x in range(1, c_parts + 1):
		if waspHive.isEven(x):
			row_tag = c_even
		else:
			row_tag = c_odd	

		# count entries
		count = 0
		for row in myCfg.GetSection('%s' % x):
			count = count + 1
		rows = count - 1
		
		count = 0
		for row in myCfg.GetSection('%s' % x):
			# get row data
			if count == 0:
				r_col_fore	= col.Get( row[0] )
				temp		= string.split( row[1], '\t' )
				r_col_back	= col.Get( temp[0] )
				r_text1		= temp[1]
				r_text2		= ''
				r_offset	= float(temp[2])
				r_width		= float(temp[3])
			else:
				r_text2	= row[0]
				r_per	= float(row[1])

				# output text columns
				if count == 1:
					print '<tr%s><td rowspan="%s"><b>%s</b></td><td>%s</td>' % (row_tag, rows, r_text1, r_text2)
				else:
					print '<tr%s><td>%s</td>' % (row_tag, r_text2)
				
				# output percentile bar chart
				r_off	= c_pixel_per_unit * r_offset
				r_size0	= c_pixel_per_unit * r_width
				r_size1 = int(r_size0 * r_per / 100.0)
				r_size2 = int(r_size0) - r_size1
				r_val	= int(r_per)
				r_off	= int(r_off)
				r_size_t= int(r_size0) + r_off
				if r_val < 10:
					r_text3 = '&nbsp;'
					r_text4 = r_val
				else:
					r_text3 = r_val
					r_text4 = '&nbsp;'
					
				y = '<td><table cellspacing="0" cellpadding="0" width="%s"><tr>' % (r_size_t)	# start table
				if r_off > 0:																# offset
					y = y + '<td width="%s">&nbsp;</td>' % (r_off)
				if r_size1 > 0:																# colour bar
					y = y + '<td width="%s" bgcolor="#%s">%s</td>' % (r_size1, r_col_fore, r_text3)	
				if r_size2 > 0:																# remainder
					y = y + '<td width="%s" bgcolor="#%s">%s</td>' % (r_size2, r_col_back, r_text4)		
				y = y + '</tr></table></td></tr>\n'											# end table
				
				print y
			count = count + 1
			
	print '</table>\n\n'
	del myCfg
	
	return ''


def Dt(format, dt=None):
	"""
		Returns date & time in nice format. Defaults to the current date.
	"""
	# get language config
	loc = waspLocale.Locale( Get('options', 'language') )
	
	# current date & time
	if dt == None:
		dt = time.time()
		
	# grab tuple elements
	(y, m, d, h, n, s, w, julianD, dst) = time.localtime(dt)
	
	# get localised weekday and month names
	W = loc.Weekday()[w]
	M = loc.Month()[m]
	
	# build formatting template and list of values
	template	= ''
	values		= ''
	symb		= '%s'
	for i in format:
		# indicates format change for next value
		if i in list('123456789'):
			symb = '%0' + i + 'd'
			
		# value
		elif i in ('y', 'm', 'd', 'h', 'n', 's', 'w', 'W', 'M'):
			template += symb
			symb = '%s'
			if values == '':
				values += i
			else:		
				values += ', ' + i
				
		# literal
		else:		
			template += i

	x = '"' + template + '" % (' + values + ')'
	nice = eval( x )
	
	print nice,

def SourceDoc(file, bg_h1='green', bg_h2='greeny', bg_row='grey'):
	"""
		Formats doc strings from Python source code.
		Notes:	triple quotes must be first characters on line.
				prints only first doc string from each class/def
				stops at module block
	"""
	# read file
	try:
		lines = open(file, 'r').readlines()
	except:
		raise 'LibError', '%s cannot be read.' % (file)

	# process lines
	name	= file
	status	= '_'
	indent	= 0
	mindent	= 0
	output	= []
	for line in lines:
		line_only = line.strip()
		line_crunch = line_only.lower().replace(' ', '')
		
		if line_only[:6] == 'class ' or line_only[:4] == 'def ':
			if status not in ('', '_'):
				output.append([name, indent, None])
			status	= line_only[:1]
			name	= line_only
			indent	= line.find(status) + 1
			mindent	= max(mindent, indent)
		elif line_only[:3] == '"""':
			if status == 'doc':
				output.append([name, indent, doc])
				status	= ''
				doc		= ''
			elif status in ('d', 'c', '_'):
				status	= 'doc'
				doc		= line_only[4:].strip()
		elif status == 'doc':
				doc += '\n' + line_only
		elif line_crunch[:12] == 'if__name__==':
			break

	
	# process output
	ret = '<table cellspacing="1" cellpadding="4" width="100%">\n<tr>'
	for i in range(mindent+1):
		ret += '<td width="30">&nbsp;</td>'
	ret += '</tr>\n'
	
	for name, indent, doc in output:
		if doc <> None:
			doc = doc.replace('<', '&lt;')
			doc = doc.replace('>', '&gt;')
		if name == file:
			claz = bg_h1
		else:
			claz = bg_h2

		ret += '<tr height="5"><td colspan="%s">&nbsp;</td></tr>\n' % (mindent+1)

		ret += '<tr>'
		for i in range(0, mindent+1):
			if i == indent:
				ret += '<td class="%s" colspan="%s">%s</td>' % (claz, mindent-indent+1, name)
				break
			else:
				ret += '<td></td>'

		ret += '</tr>\n<tr>'

		for i in range(0, mindent+1):
			if i == indent:
				ret += '<td class="%s" colspan="%s"><pre>%s</pre></td>' % (bg_row, mindent-indent+1, doc)
				break
			else:
				ret += '<td></td>'
		ret += '</tr>\n'
		
	ret += '</table>\n<p>&nbsp;</p>'
	print ret

def Talk(text):
	"""
		Prints some text for debugging purposes.
	"""
	print ''
	print 'This is the ' + text + ' insert point.'

if __name__ == '__main__':
	print 'typical samples:'
	print "dt('d M y')    => " + dt('d M y')
	print "dt('4y.2m.2d') => " + dt('4y.2m.2d')
	print "dt('2h:2n:2s') => " + dt('2h:2n:2s')
