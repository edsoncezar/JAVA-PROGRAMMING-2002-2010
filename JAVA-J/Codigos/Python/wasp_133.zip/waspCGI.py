"""
Program:
	waspCGI.py

Description:
	WaspCGI is CGI framework inspired by A. M. Kuchling's
	"A CGI Framework in Python" published in Web Techniques:
	http://www.webtechniques.com/archives/1998/02/kuchling/

	But it's come a long way since then!	

Copyright:
	(C) 2001-2 Robin Parmar <robin.escalation@ACM.org>.
	Licensed for free use under GPL.

License:
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License at http://www.gnu.org/copyleft/gpl.html 
	for more details.
"""

import os, sys, cgi, StringIO, traceback, time, string, random, urllib
import waspHive, waspHTML, waspCookie
from waspDebug import Debug
ip = '192.168.1.126'

class WaspCGI:
	def __init__(self):
		# parameters
		self.root		= ''
		self.script		= ''
		self.query		= ''
		self.page		= ''
		self.parent		= ''
		self.bug		= None
		self.myWasp		= None		# Wasp object
		self.options	= {}		# configuration options
		self.namespace	= {}		# namespace for program execution
		self.public		= {}		# data that page scripts can access

		# fill environment parameters
		# Debug('[CLS]', '192.168.1.27')
		self.__GetEnv()
		
		# general properties
		self.start_time	= 0
		self.stop_time	= 0
		self.success	= 0
		self.out_text	= ''
			
		# additional configuration parameters
		config = {	'cookie_stamp'	: '',
					'session_folder': '/usr/local/apache/session',
					'cryptic'		: '',
					'time_out'		: 30 * 60,
					'log_path'		: './log',
					'log_file'		: 'wasplog.txt',
					'smtp_host'		: '',
					'smtp_port'		: '',
					'404_file'		: '404.html',
					'err_file'		: 'error.html',
					'err_from'		: '',
					'err_to'		: '',
					'err_to_browser': 'admin',
					'err_to_file'	: 'admin',
					'err_to_email'	: 'admin',
					'err_subject'	: 'Wasp error.',
					'err_can_wrap'	: '<html><head><title>Server Error</title></head><body><p>%s</p></body></html>\n',
					'err_can_msg'	: 'Technical difficulties have been encountered and logged. We will fix the problem as soon as possible.'
					}
		try:
			# configure
			cgiOptions = waspHive.Options(config)
			cgiOptions.DoConfigFile()
			self.options = cgiOptions.GetOptionDict()
			self.namespace = cgiOptions.DoImport(self.namespace)
			self.public['options'] = self.options
			self.public['custom'] = cgiOptions.GetCustom()
			del cgiOptions
		except:
			# capture error state
			err_type = sys.exc_type
			err_value = sys.exc_value
			print self.__AdminErrorReport(err_type, err_value)

	def __Error(self, err_type='', err_value=''):
		""" Report an error. """
		
		# rescue some output?
		if self.myWasp:
			self.out_text = self.myWasp.GetOutput()
		
		err_path = self.__GetUniqueFile()

		# create reports if need be
		x = 'admin'
		if	self.options['err_to_file'].find(x) > -1 or \
			self.options['err_to_email'].find(x) > -1 or \
			self.options['err_to_browser'].find(x) -1:
			try:
				err_admin	= self.__AdminErrorReport(err_type, err_value)
			except:
				err_admin	= self.__UnhandledError()

		x = 'adminlong'
		if	self.options['err_to_file'].find(x) > -1 or \
			self.options['err_to_email'].find(x) > -1 or \
			self.options['err_to_browser'].find(x) -1:
			try:
				err_adminlong	= self.__AdminLongErrorReport(err_type, err_value)
			except:
				err_adminlong	= self.__UnhandledError()
			
		x = 'user'
		if	self.options['err_to_file'].find(x) > -1 or \
			self.options['err_to_email'].find(x) > -1 or \
			self.options['err_to_browser'].find(x) -1:
			try:
				err_user	= self.__UserErrorReport()
			except:
				err_user	= self.__UnhandledError()

		err_text = ''

		# handle 404
		if err_type == waspHive.Error:
			if str(err_value)[:17] == 'waspHive.ReadFile':
				err_text = self.__404ErrorReport()
				
		if not err_text:
			# write message to file?
			if self.options['err_to_file'] in ('admin', 'adminlong', 'user') and err_path:
				err_text = eval( 'err_' + self.options['err_to_file'] )
				open(err_path, 'w').write(err_text)
			
			# mail message to admin?
			if self.options['err_to_email'] in ('admin', 'adminlong', 'user'):
				err_text = eval( 'err_' + self.options['err_to_email'] )
				self.__MailError(err_text)

			# display message			
			if self.options['err_to_browser'] in ('admin', 'adminlong', 'user'):
				err_text = eval( 'err_' + self.options['err_to_browser'] )
			else:
				err_text = err_bad
			
		# send to browser
		print self.__GetStandardHeader() + err_text
				
	def Sting(self):
		""" Error wrapper around page execution method. """
		
		# record the starting time
		self.start_time = time.time()
		self.success = 0
		try:
			self.Poison()
		except:
			# record the ending time
			self.stop_time = time.time()

			# capture error state
			err_type = sys.exc_type
			err_value = sys.exc_value

			self.__Error(err_type, err_value)
		else:
			# record the ending time
			self.stop_time = time.time()

			# output result of our page
			print self.__GetCurrentHeader() + self.out_text
			self.success = 1	

		self.__LogScript()
		return self.success

	def Poison(self):
		""" Read and execute page code. """
		
		# read page
		self.myWasp = waspHive.waspObject( self.options, self.namespace, self.public )
		self.myWasp.Read( self.page )

		# insert pre
		waspHive.Execute( self.options['path_input'], self.options['runpre'], self.namespace, self.public )

		# parsing stages
		sub1 = {'include':	'include',
				'i':		'include',
				'macro':	'macro',
				'm':		'macro'}
		sub2 = {'if':		'if',
				'end':		'null',
				'execute':	'execute',
				'e': 		'execute'}

		terminate = 0
		while not terminate:
			start = self.myWasp.GetInput()

			# do first stage parsing
			self.myWasp.Parse( sub1 )

			# prepare
			text = self.myWasp.GetOutput()
			self.myWasp.SetInput( text )

			# do second stage parsing
			try:
				self.myWasp.Parse( sub2 )
			except 'Terminate':
				terminate = 1
					   
			# prepare
			text = self.myWasp.GetOutput()
			self.myWasp.SetInput( text )
			
			if text == start:
				break

		# insert post
		waspHive.Execute( self.options['path_input'], self.options['runpost'], self.namespace, self.public )

		self.out_text = self.myWasp.GetOutput()
		del self.myWasp

	def __UserErrorReport(self):
		# return HTML error message appropriate for user

		ok = 0
		if self.options.has_key('err_file') and self.options['err_file'] <> '':
			# use specified file if we can		
			err = os.path.join( self.root, self.options['err_file'] )
			if os.path.exists(err):
				text = waspHive.ReadFile(err)
				ok = 1
				
		if not ok:
			# otherwise use canned message		
			text = self.options['err_can_wrap'] % self.options['err_can_msg']
		return text
	
	def __404ErrorReport(self):
		# return HTML error message appropriate for 404

		text = ''
		if self.options.has_key('404_file') and self.options['404_file'] <> '':
			# use specified file if we can		
			err = os.path.join( self.root, self.options['404_file'] )
			text = waspHive.ReadFile(err)
		return text
	
	def __AdminErrorReport(self, err_type, err_value):
		"""
			Concise administrative error report.
			err_value is a list set by class Error in WaspHive.
		"""
		style = """
<STYLE>
TABLE {border-color: #ff0000; border-width: 2px; border-style: solid;}
TR {vertical-align: text-top; text-align: left;}
TD {background-color: #eeeeee;}
TH {background-color: #ff6a6a; color: #ffffff;}
</STYLE>
"""

		# build html for error value
		errl = str(err_value).split('|')
		if len(errl) > 1:
			errl2 = errl[1]
			if len(errl) > 2:
				for e in errl[2:]:
					errl2 += '<br>' + e
			errl_html = errl2
		else:
			errl_html = errl[0]
		
		# grab error stack
		err = '<table cellpadding="6" cellspacing="4"><tr><th>module</th><th>routine</th><th>line</th><th>code</th></tr>'
		tb = traceback.extract_tb(sys.exc_traceback)
		if len(tb) > 7:
			tb = tb[7:]
		for name, line, mod, text in tb:
			if mod == '?':
				mod = '[top]'
			p, f, n = waspHive.ParseFile(name)
			err += '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n' % (f, mod, line, text)

		err += '<th colspan="4">%s</th>' % errl_html
		err += '</table>'

		# create output
		error = StringIO.StringIO()
		error.write( '<html><head>\n<title>Wasp Error Report</title></head><body>\n' )
		error.write( style )
		error.write( '<h2>Error:</h2>\n' )
		error.write( '%s\n' % err )
		error.write( '<h2>Form:</h2>\n' )
		error.write( waspHTML.DictToHTML( self.public['form'], 'cellpadding="6" cellspacing="4"').byRow(1) )
		error.write( '<h2>Cgi:</h2>\n' )
		error.write( waspHTML.DictToHTML( self.public['cgi'], 'cellpadding="6" cellspacing="4"').byRow(1) )
		error.write( '</body></html>' )
		ret = error.getvalue()	
		error.close()
		
		return ret
		
	def __AdminLongErrorReport(self, err_type, err_value):
		# excrutiatingly long error report
		title = 'Wasp Error Report'
		table_tag = 'cellpadding="2" cellspacing="2"'

		# not all platforms support these (NT doesn't)
		try:
			a = os.getuid()
			b = os.getppid()
		except:
			a = -1
			b = -1
		
		err_dump = {'start time'		: time.asctime(time.localtime(self.start_time)),
					'stop time'			: time.asctime(time.localtime(self.stop_time)),
					'system path'		: sys.path,
					'process id'		: os.getpid(),
					'process user id'	: a,
					'process id of parent'	: b,
					'cgi headers'		: self.public['header'],
					'form fields'		: self.public['form'],
					'options'			: self.public['options'],
					'environment'		: self.public['cgi'] }

		# create error dump
		error = StringIO.StringIO()
		error.write( '<html><head>\n<title>%s</title></head><body>\n<h2>' % (title) )
		error.write( 'Script %s reports this error:</h2>\n<pre>' % (self.script) )
		traceback.print_exc(file=error)
		error.write( '</pre>\n' )
		error.write( '<h2>Page so far:</h2>\n%s\n' % self.out_text)
		error.write( '<h2>Here\'s a snapshot:</h2>\n' )
		error.write( waspHTML.DictToHTML( err_dump, table_tag).byRow(1) )
		
		# trim for reading ease
		local_space = self.namespace
		if local_space.has_key('__builtins__'):
			local_space['__builtins__'] = '[...]'
		if local_space.has_key('cgi_env'):
			local_space['cgi_env'] = '[see above]'
			
		error.write( '<h2>Current Name Space:</h2>\n' )
		error.write( waspHTML.DictToHTML( local_space, table_tag ).byRow(1) )
		error.write( '</body></html>' )

		ret = error.getvalue()	
		error.close()
		
		return ret

	def __UnhandledError(self):
		error = StringIO.StringIO()
		error.write( '<html><head>\n<title>Unhandled Error Report</title></head><body>\n<pre>' )
		traceback.print_exc(file=error)
		error.write( '</pre>\n</body></html>' )
		ret = error.getvalue()	
		error.close()
		
		return ret
		
	def __GetFileSpec(self, file):
		# build path using provided file name
		if self.options.has_key('log_path'):
			log_path = self.options['log_path']
		else:
			log_path = ''
		return os.path.abspath(os.path.join(log_path, file))
	
	def __GetUniqueFile(self):
		# try a fixed number of times to create a unique file name
		success		= 0
		count		= 0
		count_max	= 10
		while count <= count_max:
			try_file = self.__GetFileSpec( 'error_%s.html' % random.randint(1000, 9999) )
			if not os.path.isfile(try_file):
				success = 1
				break
			count = count + 1
			
		if success:
			return try_file
		else:
			return ''
			
	def __MailError(self, body):
		# e-mail error text
		if self.options.get('err_to', ''):
			import smtplib

			# set port and server
			smtp_host = self.options.get('smtp_host', '')
			smtp_port = self.options.get('smtp_port', 25)
			if smtp_host:
				server = smtplib.SMTP(smtp_host, smtp_port)
			else:
				server = smtplib.SMTP()
			server.set_debuglevel(0)

			# set header
			head = 'content-type: text/html\nSubject: %s\nFrom: %s\n' % (self.options['err_subject'], self.options['err_from'])

			for to_here in string.split(self.options['err_to'], ','):
				to = 'To: %s\n\n' % (to_here)
				server.sendmail(self.options['err_from'], string.strip(to_here), head + to + body)

			server.quit()

		
	def __LogScript(self):
		if self.options.has_key('log_file') and self.options['log_file']:
			# data
			header = ('start',
					  'elapsed',
					  'script',
					  'parameters',
					  'page',
					  'parent',
					  'success')
			elapsed = '%f' % (self.stop_time - self.start_time)
			
			detail = (waspHive.NiceTime(self.start_time),
					  elapsed,
					  self.script,
					  self.query,
					  self.page,
					  self.parent,
					  self.success)
		
			l = waspHive.Log(self.__GetFileSpec( self.options['log_file'] ), header)
			l.Write(detail)
			del l
		
	def __GetCurrentHeader(self):
		""" returns current HTML header """
		ret = ''
		
		# cookie should be first header written
		cookie = self.public['cookie_out'].GetJarFormatted()
		if cookie:
			ret = '%s%s\n' % (ret, cookie)

		# then content header
		cgi_head = self.public['header']
		if cgi_head:
			ret = '%s%s\n' % (ret, cgi_head)

		return ret + '\n'
	
	def __GetStandardHeader(self):
		# returns standard HTML header
		return 'Content-type: text/html\n\n'
	
	def __GetEnv(self):
		"""
			Creates a dictionary of all required CGI entries, keyed
			by easy english names. Updates the public dictionary.
		"""
		# =====
		# list of cgi environment variables
		cgil = [	['referer',			'HTTP_REFERER'],
					['server_ip',		'SERVER_ADDR'],
					['server_host',		'HTTP_HOST'],
					['server_host2',	'SERVER_NAME'],
					['server_soft',		'SERVER_SOFTWARE'],
					['server_port',		'SERVER_PORT'],
					['server_protocol',	'SERVER_PROTOCOL'],
					['server_cgi',		'GATEWAY_INTERFACE'],
					['proxy_soft',		'HTTP_VIA'],
					['proxy_ip',		'HTTP_X_FORWARDED_FOR'],
					['page_root',		'DOCUMENT_ROOT'],
					['page_query',		'QUERY_STRING'],
					['page_name',		'PATH_INFO'],
					['page_name_abs',	'PATH_TRANSLATED'],
					['page_script',		'SCRIPT_NAME'],
					['page_script_abs',	'SCRIPT_FILENAME'],
					['page_content',	'CONTENT_TYPE'],
					['page_len',		'CONTENT_LENGTH'],
					['page_language',	'HTTP_ACCEPT_LANGUAGE'],
					['client_ip',		'REMOTE_ADDR'],
					['client_host',		'REMOTE_HOST'],
					['client_port',		'REMOTE_PORT'],
					['client_connect',	'HTTP_CONNECTION'],
					['client_agent',	'HTTP_USER_AGENT'],
					['client_accept',	'HTTP_ACCEPT'],
					['client_uri',		'REQUEST_URI'],
					['client_cache',	'HTTP_CACHE_CONTROL'],
					['client_method',	'REQUEST_METHOD'],
					['client_status',	'REDIRECT_STATUS'],
					['client_pragma',	'HTTP_PRAGMA'],
					['auth_type',		'AUTH_TYPE'],
					['auth_user',		'REMOTE_USER'],
					['auth_id',			'REMOTE_IDENT'],
					['auth_ssl',		'SSL_PROTOCOL'],
					['cookie',			'HTTP_COOKIE']
				]
		
		# create cgi dictionary
		cgid = {}
		for ours, theirs in cgil:
			cgid[ours] = os.environ.get(theirs, '')

		# create absolute parent page
		cgid['parent'] = ''
		if cgid['referer'] and cgid['server_host']:
			# trim off prefix
			x = cgid['referer']
			x = x.replace('https://', '')
			x = x.replace('http://', '')
			
			# replace host name with absolute path
			x = x.replace(cgid['server_host'], cgid['page_root'])
			x = x.replace('//', '/')
			cgid['parent'] = x

		# fill local properties
		self.root	= cgid['page_root']
		self.script	= cgid['page_script']
		self.page	= cgid['page_name_abs']
		self.query	= cgid['page_query']
		self.parent	= cgid['parent']

		# =====
		# form handling
		fr = {}
		fn = None
		form = cgi.FieldStorage()
		if form:
			for key in form.keys():
				x = form[key]
				# Debug(key, ip)
				
				# check first for file upload
				# don't read value or file will be sucked up
				if x.filename:
					# store in special area
					fn = x
				else:
					try:
						v = x.value
						if type(v) is type([]):
							# multiple fields with same name
							fr[key] = '|'.join(v)
						else:
							# regular field
							fr[key] = v
					except:
						pass

		# =====
		# cookie handling -- store jar object
		if cgid['cookie']:
			jar = waspCookie.CookieJar(cgid['cookie'])
		else:
			jar = waspCookie.CookieJar()
			

		# =====
		# query string (parameter) handling
		qr = {}
		for x in self.query.split('&'):
			if x.find('=') >= 0:
				k, v = x.split('=', 1)
				k = urllib.unquote(k)
				v = urllib.unquote(v)
				qr[k] = v

		# =====
		# update public
		self.public = {	'header'	: self.__GetStandardHeader(),
						'cookie_in'	: jar,
						'cookie_out': waspCookie.CookieJar(),
						'query'		: qr,
						'form'		: fr,
						'file'		: fn,
						'cgi'		: cgid,
						'options'	: ''
						}
