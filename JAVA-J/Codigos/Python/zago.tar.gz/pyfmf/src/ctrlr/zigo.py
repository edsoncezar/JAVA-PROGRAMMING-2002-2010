#!/usr/bin/env python
"""Top-level module of the framework, contains the Controller class.

Import this module to use the framework.  All operations with the framework
are performed through the Controller class which contains a configurable
handler stack.

The creation of a Controller instance uses a configuration
dictionary.  It also accepts a suffix string that is used to configure
each handler in the stack."""

__version__ = "0.4"
__author__ = "Dan Perl"
__author_email__ = "danperl@users.sourceforge.net"
__url__ = "http://pyfmf.sourceforge.net"
__description__ = "An extensible toolkit for file management in Python."
__copyright__ = "Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>"
__license__ = """Released under the GNU General Public License (GPL).

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place, Suite 330, Boston, MA 02111-1307 USA"""

_usage = \
"""Usage: zigo.py <config module name> [<path to config package>]
    Examples:
    zigo.py ctrlrCfg
    zigo.py frsCfg ../config/saved/frsCfg.zip"""

import os
import imp
import sys
import time
import copy

if '__main__' == __name__:
    if hasattr(sys, "frozen") or \
       hasattr(sys, "importers") or \
       imp.is_frozen("__main__"):
        pathGoingUp = sys.executable
    else:
        pathGoingUp = sys.argv[0]
else:
    pathGoingUp = __file__
# Calculate the installation dir as '../..'
pathGoingUp = os.path.dirname(os.path.abspath(pathGoingUp))
for level in range(2):
    pathGoingUp = os.path.split(pathGoingUp)[0]
installDir = os.path.abspath(pathGoingUp)
os.environ['zigzag_install_dir'] = installDir
if not (installDir in sys.path):
    sys.path.insert(0, installDir)
srcDir = os.path.join(installDir, 'src')
if not (srcDir in sys.path):
    sys.path.insert(0, srcDir)
# Default configuration for a new controller
_defaultConfigDict = {
    'workDir':os.path.join(os.environ['zigzag_install_dir'], 'work'),
    'topDirs':[],
    'handlersCfg':[],
    'description':''}

class Controller:
    """Uses a Handler stack and walks through trees of directories."""
    def __init__(self, configDict=None, suffix=None):
        """Constructor that uses a configuration dictionary.
        
        Creates and configures the Handler stack."""

        self.dirGen = None
        self.topDir = None
        self.topDirList = []
        self.dirPath = None
        self.handler = None
        self.suffix = None
        self.handlersList = []

        # Mechanism to pause and stop a running stack.
        # Need to add mutexes around the use of the following attributes.
        # Flag to pause the running stack.  Set to True to pause.
        self.pauseFlag = False
        # Flag to stop the running stack.  Set to True to stop.
        self.stopFlag = False
        # Running state of the stack.  Can be 'stopped', 'running', or 'paused'
        self.runState = 'stopped'

        if configDict:
            self.setConfig(configDict, suffix)
        else:
            self.configDict = copy.deepcopy(_defaultConfigDict)

    def setConfig(self, configDict=None, suffix=None):
        """Configure the stack based on a configuration dictionary."""
        # Ignore the call if the controller is running or paused
        if self.runState != 'stopped':
            return
        # If no configDict is passed, re-configure based on the present
        # value.  Used if the configDict is changed externally.
        if configDict == None:
            configDict = self.configDict
        if configDict.has_key('workDir'):
            workDir = configDict['workDir']
            if workDir:
                os.chdir(workDir)
        self.topDirList = configDict['topDirs']
        handlerCfgList = configDict['handlersCfg']
        handlersConfigNames = [tup[0] for tup in handlerCfgList]
        handlersConfig = [tup[1] for tup in handlerCfgList]
        # Import every handler module from the names in the configuration.
        # Create a list of Handler instances, one for each imported module.
        # Each Handler instance is created with its configuration
        # dictionary.
        self.handlersList = []
        for i, modName in enumerate(handlersConfigNames):
            try:
                module = __import__('handlers.'+modName,
                                    globals(),
                                    locals(),
                                    ['Handler'])
            except ImportError:
                print 'Failed to import module', modName
                sys.exit()
            if suffix:
                handlersConfig[i]['suffix'] = suffix
            self.handlersList.append(
                vars(module)['Handler'](handlersConfig[i]))
        # Create the handlers stack by concatenating all the instances
        if self.handlersList:
            self.handler = reduce((lambda x, y: x + y), self.handlersList)
        else:
            self.handler = None
        self.configDict = configDict
        self.suffix = suffix
    
    def getHandlerByIndex(self, hndlrIndex):
        """Get a handler in the stack by its index."""
        if hndlrIndex >= len(self.handlersList) or hndlrIndex < 0:
            return None
        else:
            return self.handlersList[hndlrIndex]

    def walk(self, topDir):
        """Generator that walks through the tree.
        
        It handles all the sub-directories and all the files in each directory
        that is walked through.  Modeled after the code in os.walk."""

        # Keep track of the present parent directory for debugging
        self.dirPath = topDir
        # Finish if the stop flag is set
        if self.stopFlag:
            return
        
        # Build the list of sub-directories and the list of files
        try:
            nodes = os.listdir(topDir)
        except os.error:
            nodes = []
        dirNames = []
        fileNames = []
        for node in nodes:
            path = os.path.join(topDir, node)
            if os.path.isdir(path):
                dirNames.append(node)
            else:
                fileNames.append(node)

        # Invoke the wrapper methods
        if self.handler.beginParentDirWrapper(topDir, dirNames, fileNames):
            # For each child dir, remove it from the 'walk' if the
            # handlers stack has filtered it out.
            for dirName in dirNames[:]:
                if not self.handler.handleChildDirWrapper(dirName):
                    del dirNames[dirNames.index(dirName)]
            for fileName in fileNames:
                self.handler.handleFileWrapper(fileName)
        self.handler.endParentDirWrapper( )

        yield self.dirPath
        for dirName in dirNames:
            dirPath = os.path.join(topDir, dirName)
            if not os.path.islink(dirPath):
                for self.dirPath in self.walk(os.path.join(topDir, dirName)):
                    yield self.dirPath

    def run(self):
        """Executes the entire traversal of the tree.  Invokes walk."""
        # Ignore the call if the stack is running already
        if self.runState != 'stopped':
            return
        # Make sure the flags match the state.  Just a precaution.
        self.stopFlag = False
        self.pauseFlag = False
        # Set the state
        self.runState = 'running'
        for topDir in self.topDirList:
            # Initialize the top directory and create the walk generator
            self.topDir = topDir
            if self.handler and self.handler.setTopDir(topDir):
                for dirPath in self.walk(topDir):
                    #print self
                    # Pause if the flag is set
                    while self.pauseFlag and not self.stopFlag:
                        self.runState = 'paused'
                        time.sleep(1)
                    # Finish the iteration if the stop flag is set
                    if self.stopFlag:
                        return
                    # Set the state to 'running' in case it's coming out of
                    # a pause
                    self.runState = 'running'
        # Make the handlers release their resources
        if self.handler:
            self.handler.finalizeWrapper()
        self.runState = 'stopped'

    def __repr__(self):
        """String representation of the state of the object.
        Gives the top of the tree and the present position in the tree."""
        return "<Root:%s, traversed to %s>" % (self.topDir, self.dirPath)

# Recommended use of the controller.
if '__main__' == __name__:
    print time.ctime(time.time())

    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print _usage
        sys.exit()

    # Add "../" to sys.path to get access to "../config", "../handlers"
    if not (installDir in sys.path):
        sys.path.insert(0, installDir)
    # If there is an argument for the path to the "config" module, add that path
    # to sys.path.  Insert it at the beginning so it is checked before "../"
    if len(sys.argv) == 3:
        configPath = os.path.abspath(sys.argv[2])
        sys.path.insert(0, configPath)

    try:
        impMod = __import__('config.'+sys.argv[1],
                            globals(),
                            locals(),
                            ['configDict'])
    except ImportError:
        print 'Failed to import module', sys.argv[1]
        sys.exit()

    cd = vars(impMod)['configDict']

    ctrlr = None
    try:
        ctrlr = Controller(cd)
        print time.ctime(time.time())
        ctrlr.run( )
        print time.ctime(time.time())
    finally:
        if ctrlr:
            del ctrlr
