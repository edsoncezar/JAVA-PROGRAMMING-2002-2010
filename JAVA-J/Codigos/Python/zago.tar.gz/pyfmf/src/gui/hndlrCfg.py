"""Pane on the right side, showing a handler's configuration.

Includes widgets that are generated dynamically for each entry in the
handler's configuration."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx

wxID_HNDLRCFG = wx.NewId()

class hndlrCfgWin(wx.Panel):
    """Window for viewing the configuration of the handler.
    
    Implemented as a subclass of wx.Panel."""
    def __init__(self, parent):
        """Initializer."""
        wx.Panel.__init__(self,
                          id=wxID_HNDLRCFG,
                          parent=parent)
        self.configDict = None
        self.mainSizer = None
        self.parent = parent

    def loadConfig(self, configDict):
        """Load a configuration for viewing."""
        self.configDict = configDict

    def saveConfig(self):
        """Saves what is in the view into the controller's configDict."""
        # Every object in self.mainSizer corresponds to a configuration entry.
        # Each one of these objects is a sizer itself, with 2 children: one
        # for the name and description of the entry, the second for the value
        # of the entry.  The type of the object corresponding to the value
        # depends on the type of the value.
        # The entry's key is the name of the first child.
        # The entry's value is the value of the second child.
        if self.mainSizer:
            if self.hndlrIndex>=len(self.configDict['handlersCfg']):
                return
            entrySizersList = self.mainSizer.GetChildren()
            entriesList = [(child.GetSizer().GetChildren()[0].GetWindow(),
                            child.GetSizer().GetChildren()[1].GetWindow()) for
                           child in entrySizersList]
            hndlrConfigDict = self.configDict['handlersCfg'][self.hndlrIndex][1]
            for entry in entriesList:
                label = entry[0].GetName()
                if isinstance(entry[1], wx.TextCtrl):
                    hndlrConfigDict[label] = entry[1].GetValue()
                if isinstance(entry[1], wx.gizmos.EditableListBox):
                    hndlrConfigDict[label] = entry[1].GetStrings()
                if isinstance(entry[1], wx.CheckBox):
                    hndlrConfigDict[label] = entry[1].GetValue()
        
    def cleanView(self):
        """Cleans up the view, leaving an empty panel."""
        self.DestroyChildren()
        if self.mainSizer:
            del self.mainSizer
        self.mainSizer = None

    def loadView(self, hndlrIndex):
        """Load the configuration of a specific handler into the view.
        
        Creates widgets dynamically, based on the configuration metadata of
        the handler."""
        # Every object in self.mainSizer corresponds to a configuration entry.
        # Each one of these objects is a sizer itself, with 2 children: one
        # for the name and description of the entry, the second for the value
        # of the entry.  The type of the object corresponding to the value
        # depends on the type of the value.
        # The entry's key is the name of the first child.
        # The entry's value is the value of the second child.
        self.hndlrIndex = hndlrIndex
        self.cleanView()
        configItem = self.configDict['handlersCfg'][self.hndlrIndex]
        # Get the handlers module name and its configuration dictionary
        hndlrCfgDict = configItem[1]
        hndlrModName = configItem[0]
        # Import the handler's module to get the configuration metadata.
        impMod = __import__('handlers.'+hndlrModName,
                            globals(),
                            locals(),
                            ['Handler'])
        hndlrCls = vars(impMod)['Handler']
        
        self.mainSizer = wx.BoxSizer(wx.VERTICAL)
        spacer = 0
        # Add an object to self.mainSizer for each entry
        for metaCfgData in hndlrCls.getMetaCfg(hndlrCls):
            entrySizer = wx.BoxSizer(wx.VERTICAL)
            labelTxt = wx.StaticText(
                parent=self,
                size=(100,30),
                #label=metaCfgData.label + ":    " + metaCfgData.desc,
                name=metaCfgData.label,
                style=wx.TE_CENTRE | wx.TE_MULTILINE | wx.SUNKEN_BORDER)
            labelTxt.SetLabel(metaCfgData.label + ":    " + metaCfgData.desc)
            entrySizer.Add(labelTxt, 0, wx.EXPAND)

            if metaCfgData.typ == 'string':
                if hndlrCfgDict.has_key(metaCfgData.label):
                    val = hndlrCfgDict[metaCfgData.label]
                else:
                    val = ""
                valTxt = wx.TextCtrl(
                    parent=self,
                    value=val)
                entrySizer.Add(valTxt, 1, wx.EXPAND)
                self.mainSizer.Add(
                    entrySizer,
                    0,
                    wx.EXPAND | wx.NORTH, spacer)

            if metaCfgData.typ == 'sequence':
                if hndlrCfgDict.has_key(metaCfgData.label):
                    val = list(hndlrCfgDict[metaCfgData.label])
                else:
                    val = []
                valSeq = wx.gizmos.EditableListBox(
                    parent=self,
                    label="")
                valSeq.SetStrings(val)
                entrySizer.Add(valSeq, 1, wx.EXPAND)
                self.mainSizer.Add(
                    entrySizer,
                    1,
                    wx.EXPAND | wx.NORTH, spacer)

            if metaCfgData.typ == 'bool':
                if hndlrCfgDict.has_key(metaCfgData.label):
                    val = hndlrCfgDict[metaCfgData.label]
                else:
                    val = False
                valCheck = wx.CheckBox(
                    parent=self,
                    label=metaCfgData.label,
                    size=(100,25))
                valCheck.SetValue(val)
                valCheck.Centre()
                entrySizer.Add(valCheck, 1, wx.EXPAND | wx.WEST, 20)
                self.mainSizer.Add(
                    entrySizer,
                    0,
                    wx.EXPAND | wx.NORTH, spacer)
            spacer = 20

        self.mainSizer.Fit(self)
        self.SetSizer(self.mainSizer)
        self.Fit()
        self.parent._layout()
