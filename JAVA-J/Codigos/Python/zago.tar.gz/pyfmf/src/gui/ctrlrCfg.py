"""Pane on the left side, showing the controller configuration.

Includes widgets for the stack configuration, the list of trees, and the
work directory."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx, wx.gizmos
import stackCfg

wxID_CTRLRCFG = wx.NewId()
wxID_STACKLIST = wx.NewId()
wxID_TREECFG = wx.NewId()
wxID_CHANGEWORKDIRBUTTON = wx.NewId()

class ctrlrCfgWin(wx.Panel):
    """Window for viewing the configuration of the controller.
    
    Implemented as a subclass of wx.Panel."""
    def __init__(self, parent, hndlrCfgW):
        """Initializer.  Takes a reference to the handler window."""
        wx.Panel.__init__(self, parent)
        # Keep references to the parent window and the handler window
        self.parent = parent
        self.hndlrCfgW = hndlrCfgW

        # Use a sizer for the entire window.  This will include the view of
        # the stack configuration, the view of the trees, and the view of
        # the work directory
        self.mainSizer = wx.BoxSizer(wx.VERTICAL)

        # The view of the stack configuration is implemented in stackCfg.
        # It uses a reference to the handler view
        self.stackCfg = stackCfg.stackCfgWin(self, hndlrCfgW)
        self.mainSizer.Add(
            self.stackCfg,
            1,
            wx.EXPAND)

        # The view of the trees
        self.treeCfg = wx.gizmos.EditableListBox(
            parent=self,
            label="Roots of the Directory Trees:",
            style=wx.gizmos.EL_ALLOW_NEW | wx.gizmos.EL_ALLOW_DELETE)
        newButtonId = self.treeCfg.GetNewButton().GetId()
        self.treeCfg.Bind(wx.EVT_BUTTON, self.OnNewTreeClick, id=newButtonId)
        self.mainSizer.Add(self.treeCfg, 1, wx.EXPAND | wx.NORTH, 10)
        
        # The view of the work directory.  It has its own sizer and it
        # includes several widgets.
        workDirHeader = wx.Panel(
            parent=self,
            style=wx.SUNKEN_BORDER)
        workDirSizer = wx.BoxSizer(wx.HORIZONTAL)
        workDirLabelW = wx.StaticText(
            parent=workDirHeader,
            label="Work Directory:",
            size=(80,15))
        workDirSizer.Add(
            item=workDirLabelW,
            proportion=1,
            flag=wx.ALIGN_CENTER | wx.EXPAND | wx.WEST,
            border=5)
        # Changing the work directory is done with a button
        changeWorkDirButton = wx.Button(
            parent=workDirHeader,
            id=wxID_CHANGEWORKDIRBUTTON,
            label="Change",
            name="changeWorkDirButton")
        self.Bind(
            wx.EVT_BUTTON,
            self.OnChangeWorkDirButtonClick,
            id=wxID_CHANGEWORKDIRBUTTON)
        workDirSizer.Add(changeWorkDirButton, 0, wx.ALIGN_CENTER)
        workDirSizer.Fit(workDirHeader)
        workDirHeader.SetSizer(workDirSizer)
        workDirHeader.Fit()
        self.mainSizer.Add(workDirHeader, 0, wx.EXPAND | wx.NORTH, 10)
        self.workDirW = wx.StaticText(
            parent=self,
            label="",
            size=(80,20),
            style=wx.TE_CENTRE | wx.TE_MULTILINE | wx.SUNKEN_BORDER)
        self.mainSizer.Add(self.workDirW, 0, wx.EXPAND)
        
        self.mainSizer.Fit(self)
        self.SetSizer(self.mainSizer)
        self.Fit()
        
        self.configDict = {}

    def OnNewTreeClick(self, event):
        """Handler for the 'New' button in the tree view."""
        # Use a file dialog to select a new directory for the top of a tree.
        dlg = wx.DirDialog(
            parent=self,
            message="Choose a path",
            style=wx.OPEN
            )
        if dlg.ShowModal() == wx.ID_OK:
            pathsList = self.treeCfg.GetStrings()
            path = dlg.GetPath()
            pathsList.append(path)
            self.treeCfg.SetStrings(pathsList)
        dlg.Destroy()
        event.Skip()

    def OnChangeWorkDirButtonClick(self, event):
        """Handler for the button that changes the work directory."""
        # Use a directory dialog to select a new directory.
        dlg = wx.DirDialog(
            parent=self,
            message="Choose the workDir",
            defaultPath=self.workDirW.GetLabel(),
            style=wx.OPEN
            )
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            self.workDirW.SetLabel(path)
        dlg.Destroy()
        # This may affect sizes of widgets, so layout again
        self._layout()
        event.Skip()

    def loadConfig(self, configDict):
        """Load a configuration for viewing."""
        self.configDict = configDict
        self.treeCfg.SetStrings(configDict['topDirs'][:])
        self.workDirW.SetLabel(configDict['workDir'])
        self.stackCfg.loadConfig(configDict)
        # This may affect sizes of widgets, so layout again
        self._layout()

    def saveConfig(self):
        """Saves what is in the view into the controller's configDict."""
        self.configDict['topDirs'] = self.treeCfg.GetStrings()
        self.configDict['workDir'] = self.workDirW.GetLabel()
        self.stackCfg.saveConfig()

    def _layout(self):
        """Resizes this window and its parent.  Not the same as Layout()."""
        sizer = self.GetSizer()
        if sizer:
            sizer.Layout()
        self.parent._layout()
