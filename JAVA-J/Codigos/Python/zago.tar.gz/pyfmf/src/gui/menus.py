"""Implements the menu bar, the menus in it, and the actions for the menus."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx
import sys
import os
import thread
import pprint

wxID_MENUFILEEXIT = wx.NewId()
wxID_MENUFILENEW = wx.NewId()
wxID_MENUFILEOPEN = wx.NewId()
wxID_MENUFILECLOSE = wx.NewId()
wxID_MENUFILESAVE = wx.NewId()
wxID_MENURUNRUN = wx.NewId()
wxID_MENURUNPAUSE = wx.NewId()
wxID_MENURUNRESUME = wx.NewId()
wxID_MENURUNSTOP = wx.NewId()
wxID_MENUHELPABOUT = wx.NewId()
wxID_MENUVIEWCONFIGURATION = wx.NewId()
wxID_MENUVIEWRESULTS = wx.NewId()

# This is a header that is inserted in every config file that is saved by
# Zago
_headerForConfigSave = \
"""# Configuration file.
#
# The configuration is entirely contained in a dictionary, 'configDict'.
# This dictionary has four members, with the keys 'description' (optional),
# 'topDirs', 'workDir' (optional), and 'handlersCfg'.
#
# The value associated with 'description' is a string with a short description
# of the configuration.  This entry is optional in configDict and defaults to
# an empty string.
#
# The value associated with 'topDirs' is a list of the roots of directory trees
# that are to be traversed and processed.
#
# The value associated with 'workDir' is the directory where all result files
# are located.  This entry is optional and if it is not specified in configDict
# or if the value is an empty string, the working directory is unchanged from
# the directory where the controller is invoked.
#
# The value associated with 'handlersCfg' is a list of tuples.  Each one of the
# tuples in this list is associated with a handler in the stack.  The order of
# the list follows the order of the stack, top-to-bottom, the first element in
# the list corresponding to the top of the stack and the last element of the
# list corresponding to the bottom of the stack.  Processing is done in reverse
# order, the bottom handler is the first one to process directories and files,
# the top handler is the last one processing.
#
# Each tuple in the list associated with 'handlersCfg' has 2 items.  The first
# item is the name of the module which contains the Handler.  The second item
# is a dictionary used to configure the Handler instance.  To understand what
# members are expected in the dictionary for each Handler class, look at the
# unbound member _metaCfg of that class; it is a tuple of 'metaCfgCls' (a class
# nested in class baseClass.Handler) objects, each object describing a member
# of the dictionary.  These objects have three attributes: 'label', 'desc',
# and 'typ'.  'label' represents the key used in the configuration dictionary,
# 'desc' represents the description of the value, and 'typ' represents the
# type of the value ('string', 'bool', or 'sequence').  A 'sequence' value can
# be either a tuple or a list.
#
# Example of a 'metaCfgCls' object:
#    metaC = baseClass.Handler.metaCfgCls(
#	    label='name'
#	    description='Optional, unused.  Identifies a handler in the stack.'
#	    typ='string')
# In configDict, this object may be represented by an entry:
#    'name': 'fodSeqP'
"""

class menuBar (wx.MenuBar):
    """Implements the menu bar.  Derived from wx.MenuBar."""

    def _init_coll_mnuFile_Items(self, parent):
        """Initializes the 'File' menu."""
        # The 'New' menu item
        parent.Append(help='Create a new configuration',
                      id=wxID_MENUFILENEW,
                      text='New',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUFILENEW,
                    self.OnMnuFileNewMenu)

        # The 'Open' menu item
        parent.Append(help='Open an existing configuration',
                      id=wxID_MENUFILEOPEN,
                      text='Open',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUFILEOPEN,
                    self.OnMnuFileOpenMenu)

        # The 'Close' menu item.
        # Disabled for now, until there is a mechanism for multiple open
        # configurations.
        #parent.Append(help='Close the configuration',
        #              id=wxID_MENUFILECLOSE,
        #              text='Close',
        #              kind=wx.ITEM_NORMAL)
        #wx.EVT_MENU(self.parent,
        #            wxID_MENUFILECLOSE,
        #            self.OnMnuFileCloseMenu)

        # The 'Save As' menu item.
        # No 'Save' item yet, this one serves for both.
        parent.Append(help='Save a configuration',
                      id=wxID_MENUFILESAVE,
                      text='Save As',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUFILESAVE,
                    self.OnMnuFileSaveMenu)

        parent.AppendSeparator()

        # The 'Exit' menu item
        parent.Append(help='Exit the application',
                      id=wxID_MENUFILEEXIT,
                      text='Exit',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUFILEEXIT,
                    self.OnMnuFileExitMenu)

    def _init_coll_mnuView_Items(self, parent):
        """Initializes the 'View' menu."""
        # The 'Configuration' menu item
        parent.Append(help='Configuring a Project',
                      id=wxID_MENUVIEWCONFIGURATION,
                      text='Configuration',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUVIEWCONFIGURATION,
                    self.OnMnuViewConfigurationMenu)
        """Initializes the 'Results' menu."""
        # The 'Results' menu item
        parent.Append(help='Results of Running a Project',
                      id=wxID_MENUVIEWRESULTS,
                      text='Results',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUVIEWRESULTS,
                    self.OnMnuViewResultsMenu)

    def _init_coll_mnuRun_Items(self, parent):
        """Initializes the 'Run' menu."""
        # The 'Run' menu item
        parent.Append(help='Run the configuration',
                      id=wxID_MENURUNRUN,
                      text='Run',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENURUNRUN,
                    self.OnMnuRunRunMenu)

        parent.AppendSeparator()

        # The 'Pause' menu item
        parent.Append(help='Pause the run',
                      id=wxID_MENURUNPAUSE,
                      text='Pause',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENURUNPAUSE,
                    self.OnMnuRunPauseMenu)

        # The 'Resume' menu item
        parent.Append(help='Resume a paused run',
                      id=wxID_MENURUNRESUME,
                      text='Resume',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENURUNRESUME,
                    self.OnMnuRunResumeMenu)

        parent.AppendSeparator()

        # The 'Stop' menu item
        parent.Append(help='Stop the run',
                      id=wxID_MENURUNSTOP,
                      text='Stop',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENURUNSTOP,
                    self.OnMnuRunStopMenu)

    def _init_coll_mnuHelp_Items(self, parent):
        """Initializes the 'Help' menu."""
        # The 'About' menu item
        parent.Append(help='General Information on Zago',
                      id=wxID_MENUHELPABOUT,
                      text='About',
                      kind=wx.ITEM_NORMAL)
        wx.EVT_MENU(self.parent,
                    wxID_MENUHELPABOUT,
                    self.OnMnuHelpAboutMenu)

    def __init__(self, parent):
        """Overall initialization of the menu bar."""
        wx.MenuBar.__init__(self)
        self.parent = parent
        self.mnuFile = wx.Menu( )
        self.mnuView = wx.Menu( )
        self.mnuRun = wx.Menu( )
        self.mnuHelp = wx.Menu( )

        self._init_coll_mnuFile_Items(self.mnuFile)
        self._init_coll_mnuView_Items(self.mnuView)
        self._init_coll_mnuRun_Items(self.mnuRun)
        self._init_coll_mnuHelp_Items(self.mnuHelp)
        self.Append(menu=self.mnuFile, title='File')
        self.Append(menu=self.mnuView, title='View')
        self.Append(menu=self.mnuRun, title='Run')
        self.Append(menu=self.mnuHelp, title='Help')
        
    def OnMnuFileNewMenu(self, event):
        """Handler for the 'New' item in the 'File' menu."""
        # Ignore the command unless the stack is stopped
        if self.parent.GetSelectedProj().ctrlr.runState=='stopped':
            self.parent.GetSelectedProj().clearConfig()
        self.parent.Notify()

    def OnMnuFileOpenMenu(self, event):
        """Handler for the 'Open' item in the 'File' menu."""
        # Ignore the command unless the stack is stopped
        if self.parent.GetSelectedProj().ctrlr.runState=='stopped':
            # Create the dialog. Display only ".py" files and only in the config
            # directory.  Allow only single selection.
            dlg = wx.FileDialog(
                self,
                message="Choose a file",
                defaultDir=os.path.join(os.environ['zigzag_install_dir'], 'config'), 
                defaultFile="",
                wildcard="Python source (*.py)|*.py",
                style=wx.OPEN
                )

            # Show the dialog and retrieve the user response. If it is the OK
            # response, import the configuration module and update the controller.
            if dlg.ShowModal() == wx.ID_OK:
                # This returns a Python list of files that were selected.
                paths = dlg.GetPaths()
                modName = 'config.'+os.path.split(os.path.splitext(paths[0])[0])[1]
                try:
                    if sys.modules.has_key(modName):
                        impMod = sys.modules[modName]
                        reload(impMod)
                    else:
                        impMod = __import__(modName,
                                            globals(),
                                            locals(),
                                            ['configDict'])
                except ImportError, data:
                    print data
                else:
                    configDict = vars(impMod)['configDict']
                    self.parent.GetSelectedProj().loadConfig(configDict)
            dlg.Destroy()
        self.parent.Notify()

    def OnMnuFileCloseMenu(self, event):
        """Handler for the 'Close' item in the 'File' menu."""
        # Ignore the command unless the stack is stopped
        if self.parent.GetSelectedProj().ctrlr.runState == 'stopped':
            self.parent.GetSelectedProj().clearConfig()
        self.parent.Notify()

    def OnMnuFileSaveMenu(self, event):
        """Handler for the 'SaveAs' item in the 'File' menu."""
        
        # First save the configuration that is being viewed into the
        # configuration dictionary
        self.parent.GetSelectedProj().saveConfig()
        configDict = self.parent.GetSelectedProj().ctrlr.configDict

        # Use a dialog to enter a description for the configuration
        dlg = wx.TextEntryDialog(
            parent=self,
            message="Enter a short description of the configuration [Optional]",
            defaultValue=configDict['description'],
            style=wx.OK | wx.CENTRE)
        if dlg.ShowModal() == wx.ID_OK:
            configDict['description'] = dlg.GetValue()
        if not configDict['description']:
            configDict['description'] = "Configuration for Zago"
        dlg.Destroy()

        # Use a dialog to choose the file where the configuration will be
        # saved.  Display only ".py" files and only in the 'config' directory.
        # Allow only single selections.
        dlg = wx.FileDialog(
            self,
            message="Save file as ...",
            defaultDir=os.path.join(os.environ['zigzag_install_dir'], 'config'), 
            wildcard="Python source (*.py)|*.py",
            style=wx.SAVE
            )
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()

            # Open the file, write the header, the description, and the
            # summary of the stack structure
            saveFile = file(path, "w")
            saveFile.write(_headerForConfigSave)
            saveFile.write(
                "\n__description__ = '%s'" % configDict['description'])
            saveFile.write(
                "\n\n# Structure of the handler stack in this configuration:\n")
            handlerStack = [tpl[0] for tpl in configDict['handlersCfg']]
            for hndlr in handlerStack:
                saveFile.write('#\t' + hndlr + '\n')

            # Now save the configDict dictionary
            saveFile.write('\nconfigDict = \\\n')
            pprint.pprint(configDict, saveFile)

            saveFile.close()
        dlg.Destroy()
        # Make sure the status bar is updated
        self.parent.Notify()

    def OnMnuFileExitMenu(self, event):
        """Handler for the 'Exit' item in the 'File' menu."""
        # Allow the parent window to implement a more complex shutdown
        # than just close()
        self.parent._shutDown()

    def OnMnuViewConfigurationMenu(self, event):
        """Handler for the 'Configuration' item in the 'View' menu."""
        self.parent.GetSelectedProj().showView('config')

    def OnMnuViewResultsMenu(self, event):
        """Handler for the 'Results' item in the 'View' menu."""
        self.parent.GetSelectedProj().showView('results')

    def OnMnuRunRunMenu(self, event):
        """Handler for the 'Run' item in the 'Run' menu."""
        ## Lump together both the loading of the configuration and the actual
        ## run into a separate thread.
        ## For now, allow this thread to run uncontrolled so it cannot be
        ## gracefully terminated by the application and the application cannot
        ## wait for the termination of the thread.
        #def configAndRun():
        #    ctrlr = self.parent.GetSelectedProj().ctrlr
        #    ctrlr.setConfig()
        #    ctrlr.run()

        # Ignore the command if the stack is already running
        if self.parent.GetSelectedProj().ctrlr.runState == 'stopped':
            self.parent.GetSelectedProj().saveConfig()
            self.parent.GetSelectedProj().setConfig()
            ctrlr = self.parent.GetSelectedProj().ctrlr
            thread.start_new_thread(ctrlr.run, ())
        self.parent.Notify()

    def OnMnuRunPauseMenu(self, event):
        """Handler for the 'Pause' item in the 'Run' menu."""
        # Ignore the command unless the stack is running
        if self.parent.GetSelectedProj().ctrlr.runState == 'running':
            self.parent.GetSelectedProj().ctrlr.pauseFlag = True
        self.parent.Notify()

    def OnMnuRunResumeMenu(self, event):
        """Handler for the 'Resume' item in the 'Run' menu."""
        # Ignore the command unless the stack is paused
        if self.parent.GetSelectedProj().ctrlr.runState == 'paused':
            self.parent.GetSelectedProj().ctrlr.pauseFlag = False
        self.parent.Notify()

    def OnMnuRunStopMenu(self, event):
        """Handler for the 'Stop' item in the 'Run' menu."""
        # Ignore the command if the stack is already stopped
        if self.parent.GetSelectedProj().ctrlr.runState != 'stopped':
            self.parent.GetSelectedProj().ctrlr.stopFlag = True
            self.parent.GetSelectedProj().ctrlr.pauseFlag = False
        self.parent.Notify()

    def OnMnuHelpAboutMenu(self, event):
        """Handler for the 'About' item in the 'Help' menu."""
        dlg = wx.MessageDialog(
            parent=self.parent,
            message="Zago is a platform for file management\n\n"
            "Contact: danperl@users.sourceforge.net\n"
            "Web Site: http://pyfmf.sourceforge.net\n\n"
            "Version: %s" % os.environ['zago_version'],
            caption="About Zago",
            style=wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()
