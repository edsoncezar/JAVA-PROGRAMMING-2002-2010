"""The main window of Zago.

Children:
    - a status bar (wx.StatusBar)
    - a menu bar (menus.menuBar)
    - the configuration object (projWin.projObj)
    - a timer for the status bar (wx.PyTimer)"""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx
import menus
import projWin

wxID_ZMAINFRAME = wx.NewId( )
wxID_ZMAINFRAMESTATUSBAR = wx.NewId()

class zMainFrame(wx.Frame):
    """The main window implemented as a subclass of wx.Frame."""
    def __init__(self, parent):
        """Initializer"""
        wx.Frame.__init__(self,
                          id=wxID_ZMAINFRAME,
                          name='zMainFrame',
                          parent=parent,
                          style=wx.SYSTEM_MENU | wx.DEFAULT_FRAME_STYLE,
                          title='Zago')

        # Create and add the status bar
        self.statusBar = wx.StatusBar(id=wxID_ZMAINFRAMESTATUSBAR,
                                      name='statusBar',
                                      parent=self,
                                      style=0)
        self.statusBar.SetFieldsCount(2)
        #self.statusBar.SetStatusText(number=0, text='Status')
        self.statusBar.SetStatusText(number=1, text='Run Status')
        self.statusBar.SetStatusWidths([-1,-1])
        self.SetStatusBar(self.statusBar)
        self.SetStatusBarPane(0)
        
        # Create and add the menu bar
        self.menuBar = menus.menuBar(parent=self)
        self.SetClientSize(wx.Size(600, 500))
        self.SetMenuBar(self.menuBar)

        # Create and add an empty configuration object and set it as the
        # one presently selected.
        self.SetSelectedConfig(projWin.projObj(self))

        # Create and add the timer for the status bar
        self.timer = wx.PyTimer(self.Notify)
        self.timer.Start(1000)
        self.Notify()

    def Notify(self):
        """Handler for the timer associated with the status bar.
        
        Refreshes the run status of the presently selected configuration."""        
        self.statusBar.SetStatusText(
            "Run Status: %s" % self.GetSelectedProj().ctrlr.runState, 1)
        
    def SetSelectedConfig(self, cfg):
        """Set which configuration is selected (in focus).
        
        There is only one configuration for now."""
        self.activeCfg = cfg
        
    def GetSelectedProj(self):
        """Get the configuration that is selected (in focus).
        
        There is only one configuration for now."""
        return self.activeCfg

    def _shutDown(self):
        """Graceful shut down that does more than just Close()"""
        self.timer.Stop()
        self.Close()
