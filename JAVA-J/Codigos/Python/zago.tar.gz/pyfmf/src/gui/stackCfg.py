"""Widget for the configuration of the handlers stack."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx, wx.gizmos
import os

wxID_STACKLIST = wx.NewId()

class stackCfgWin(wx.gizmos.EditableListBox):
    """The widget, defined as a subclass of wx.gizmos.EditableListBox.
    
    Takes a reference to the handler view which is on the right side of
    the main window."""

    def __init__(self, parent, hndlrCfgW):
        """Initializer."""
        wx.gizmos.EditableListBox.__init__(
            self,
            parent=parent,
            label="Handlers in the Stack:",
            style=wx.gizmos.EL_ALLOW_NEW | wx.gizmos.EL_ALLOW_DELETE)

        # Keep references to the ListCtrl and register handlers for it and for
        # the buttons in the EditableListBox.
        self.listCtrl = self.GetListCtrl()
        listCtrlId = self.listCtrl.GetId()
        self.Bind(wx.EVT_LIST_ITEM_SELECTED,
                  self.OnItemSelected,
                  id=listCtrlId)
        self.Bind(wx.EVT_LIST_ITEM_DESELECTED,
                  self.OnItemDeselected,
                  id=listCtrlId)
        delButtonId = self.GetDelButton().GetId()
        self.Bind(wx.EVT_BUTTON, self.OnDelClick, id=delButtonId)
        newButtonId = self.GetNewButton().GetId()
        self.Bind(wx.EVT_BUTTON, self.OnNewClick, id=newButtonId)
        upButtonId = self.GetUpButton().GetId()
        self.Bind(wx.EVT_BUTTON, self.OnUpClick, id=upButtonId)
        downButtonId = self.GetDownButton().GetId()
        self.Bind(wx.EVT_BUTTON, self.OnDownClick, id=downButtonId)

        # Keep a reference to the handler view.
        self.hndlrCfgW = hndlrCfgW

        self.itemIndex = None
        self.selectedHndlr = None
        self.parent = parent
        self.configDict = None
        self.mainSizer = None

    def OnItemSelected(self, event):
        """Handler for selection of an item in the stack."""
        self.hndlrIndex = event.GetIndex()
        if self.hndlrIndex < len(self.GetStrings()) and self.configDict:
            self.hndlrCfgW.loadView(self.hndlrIndex)
        else:
            self.hndlrCfgW.cleanView()
        event.Skip()
    
    def OnItemDeselected(self, event):
        """Handler for de-selection of an item in the stack."""
        if self.hndlrIndex < len(self.GetStrings()) and self.configDict:
            self.hndlrCfgW.saveConfig()
            self.hndlrIndex = None
        event.Skip()
    
    def OnDelClick(self, event):
        """Handler for deletion of an item in the stack."""
        del self.configDict['handlersCfg'][self.hndlrIndex]
        self.hndlrIndex = None
        event.Skip()
    
    def OnNewClick(self, event):
        """Handler for creation of a new item in the stack."""
        import glob, os.path
        import handlers.baseClass as baseClass
        # Clean the view so nothing gets saved in this step, the deselect takes
        # care of that.
        self.hndlrCfgW.cleanView()
        # Build a list of the modules that contain a valid Handler class.
        hndlrList = []
        for hndlrFile in glob.glob(
            os.path.join(os.environ['zigzag_install_dir'], 'handlers', '*.py')):
            modName = os.path.split(os.path.splitext(hndlrFile)[0])[1]
            if modName == 'baseClass' or \
               modName == 'handlerTemplate':
                continue
            impMod = __import__('handlers.'+modName,
                                globals(),
                                locals(),
                                ['Handler'])
            if not vars(impMod).has_key('Handler'):
                continue
            hndlrCls = vars(impMod)['Handler']
            if not issubclass(hndlrCls, (baseClass.Handler,)):
                continue
            #descr = vars(impMod)['__doc__']
            hndlrList.append(modName)
        # Use a single choice dialog.
        dlg = wx.SingleChoiceDialog(
                self,
                'Choose New Handler',
                'Add Handler',
                hndlrList,
                wx.CHOICEDLG_STYLE
                )
        if dlg.ShowModal() == wx.ID_OK:
            modName = dlg.GetStringSelection()
            impMod = __import__('handlers.'+modName,
                                globals(),
                                locals(),
                                ['Handler'])
            # Get the 'Handler' class from the module and create a new,
            # empty configuration for this handler, based on Handler._metaCfg.
            hndlrCls = vars(impMod)['Handler']
            hndlrCfgDict = {}
            for metaCfgData in hndlrCls.getMetaCfg(hndlrCls):
                if metaCfgData.typ == 'string':
                    hndlrCfgDict[metaCfgData.label] = ""
                if metaCfgData.typ == 'sequence':
                    hndlrCfgDict[metaCfgData.label] = []
                if metaCfgData.typ == 'bool':
                    hndlrCfgDict[metaCfgData.label] = False
            self.configDict['handlersCfg'].append((modName, hndlrCfgDict))
            # Append the module name to the list that is displayed.
            hndlrsList = self.GetStrings()
            hndlrsList.append(modName)
            self.SetStrings(hndlrsList)
        dlg.Destroy()
        event.Skip()
    
    def OnUpClick(self, event):
        """Handler for moving an item up in the stack."""
        temp = self.configDict['handlersCfg'][self.hndlrIndex-1]
        self.configDict['handlersCfg'][self.hndlrIndex-1] = \
            self.configDict['handlersCfg'][self.hndlrIndex]
        self.configDict['handlersCfg'][self.hndlrIndex] = temp
        self.hndlrCfgW.cleanView()
        event.Skip()
    
    def OnDownClick(self, event):
        """Handler for moving an item down in the stack."""
        temp = self.configDict['handlersCfg'][self.hndlrIndex+1]
        self.configDict['handlersCfg'][self.hndlrIndex+1] = \
            self.configDict['handlersCfg'][self.hndlrIndex]
        self.configDict['handlersCfg'][self.hndlrIndex] = temp
        self.hndlrCfgW.cleanView()
        event.Skip()
    
    def loadConfig(self, configDict):
        """Load a configuration for viewing."""
        self.configDict = configDict
        self.SetStrings([tpl[0] for tpl in configDict['handlersCfg']])

    def saveConfig(self):
        """Saves what is in the view into the controller's configDict."""
        # No need to do anything, the event handlers keep this part of the
        # configuration up-to-date.
        pass
