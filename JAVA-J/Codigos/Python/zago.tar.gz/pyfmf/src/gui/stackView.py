"""Widget viewing the handlers stack."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx
import handlers.resultsViewer

class stackViewWin(wx.ListBox):
    """The window, defined as a subclass of wx.ListBox.
    
    Takes a reference to the handler view which is on the right side of
    the main window."""

    def __init__(self, parent, hndlrW, controller):
        """Initializer."""
        wx.ListBox.__init__(
            self,
            parent=parent)
        self.Bind(wx.EVT_LISTBOX, self.EvtListBox, self)

        # Keep a reference to the handler view.
        self.hndlrW = hndlrW
        self.ctrlr = controller
        self.itemIndex = None
        self.selectedHndlr = None
        self.parent = parent
        self.configDict = None
        self.hndlrIndex = -1

    def EvtListBox(self, event):
        """Handler for selection of an item in the stack."""
        self.hndlrW.hideRes()
        self.hndlrIndex = event.GetSelection()
        self.showHndlrRes()
        event.Skip()
    
    def loadConfig(self, configDict):
        """Load a configuration for viewing."""
        self.configDict = configDict
        handlerNamesList = [tpl[0] for tpl in configDict['handlersCfg']]
        self.Set(handlerNamesList)
        # Set the index beyond the size of the list so viewing is disabled
        # until an item is explicitly selected
        self.hndlrIndex = len(handlerNamesList)

    def showHndlrRes(self):
        """Show the results of the selected handler."""
        hndlr = self.ctrlr.getHandlerByIndex(self.hndlrIndex)
        # Only subclasses of the resultViewer mixin can be used as viewers
        if isinstance(hndlr, handlers.resultsViewer.ViewerMixin):
            if hndlr.getViewWidget():
                self.hndlrW.showRes(hndlr.getViewWidget())
