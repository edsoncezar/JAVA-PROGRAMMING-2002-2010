#!/usr/bin/env python
"""Top-level script of the Zago application.

Zago is an extensible platform for file management in Python."""

__version__ = "0.2"
__author__ = "Dan Perl"
__author_email__ = "danperl@users.sourceforge.net"
__url__ = "http://pyfmf.sourceforge.net"
__description__ = "An extensible platform for file management in Python."
__copyright__ = "Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>"
__license__ = """Released under the GNU General Public License (GPL).

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place, Suite 330, Boston, MA 02111-1307 USA"""

import sys
import imp
import os

# Add the installation directory ("../") and the controller directory
# ("../ctrlr") to sys.path.  Add the installation directory to environment.
if '__main__' == __name__:
    if hasattr(sys, "frozen") or \
       hasattr(sys, "importers") or \
       imp.is_frozen("__main__"):
        path = sys.executable
    else:
        path = sys.argv[0]
else:
    path = __file__
# Calculate the installation dir as '../..'
pathGoingUp = os.path.dirname(os.path.abspath(path))
for i in range(2):
    pathGoingUp = os.path.split(pathGoingUp)[0]
installDir = os.path.abspath(pathGoingUp)
os.environ['zigzag_install_dir'] = installDir
if not (installDir in sys.path):
    sys.path.insert(0, installDir)
srcDir = os.path.join(installDir, 'src')
if not (srcDir in sys.path):
    sys.path.insert(0, srcDir)
ctrlrDir = os.path.join(installDir, 'src', 'ctrlr')
if not (ctrlrDir in sys.path):
    sys.path.insert(0, ctrlrDir)

import wx
import mainFrame
#import win32traceutil

# Put the version number in the environment so it is available everywhere.
os.environ['zago_version'] = __version__

class ZagoApp(wx.App):
    """The application implemented as a wx.App derived class."""
    def OnInit(self):
        wx.InitAllImageHandlers()
        self.mainWin = mainFrame.zMainFrame(None)
        self.mainWin.Show()
        self.SetTopWindow(self.mainWin)

        return True
    
def main():
    """Main function of the application."""
    #print "Zago - " + __description__
    #print __copyright__
    application = ZagoApp(0)
    application.MainLoop()

if __name__ == '__main__':
    main()
