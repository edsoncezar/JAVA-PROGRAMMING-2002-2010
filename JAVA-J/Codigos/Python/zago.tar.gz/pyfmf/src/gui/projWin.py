"""Windows associated with one project.

The intention is to have multiple projects in future versions."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import wx
import hndlrCfg
import ctrlrCfg
import stackView
import os
import sys
import copy
from zigo import Controller, _defaultConfigDict
import handlers.resultsViewer

class projObj(object):
    """Class that is associated with each project.
    May contain multiple views."""

    class configView (wx.SplitterWindow):
        """The view for configuration."""
        def __init__(self, parent, controller):
            """Initializer of the configuration view.
            
            Takes the controller as an argument."""
            
            # Use a splitter window.  Left side is for the controller
            # configuration, right side is for the handler configuration.
            wx.SplitterWindow.__init__(
                self,
                parent=parent,
                style=wx.SP_3D)

            # Create a panel for the controller and a panel for the handler.
            # Load the configuration into both of them.
            # The controller view uses a reference to the handler view.
            self.hndlrCfgW = hndlrCfg.hndlrCfgWin(
                parent=self)
            self.ctrlrCfgW = ctrlrCfg.ctrlrCfgWin(
                self,
                self.hndlrCfgW)
            self.loadConfig(controller.configDict)
    
            self.SetMinimumPaneSize(150)
            self.SplitVertically(self.ctrlrCfgW, self.hndlrCfgW, 250)
    
        def loadConfig(self, configDict):
            """Load a configuration into the view"""
            self.hndlrCfgW.loadConfig(configDict)
            self.ctrlrCfgW.loadConfig(configDict)
    
        def saveConfig(self):
            """Save the configuration in the view"""
            self.ctrlrCfgW.saveConfig()
            self.hndlrCfgW.saveConfig()
            
        def _layout(self):
            self.UpdateSize()

    class resultsView (wx.SplitterWindow):
        """The view for results."""
        class hndlrResView (wx.Panel):
            def __init__(self, parent):
                """Initializer"""
                wx.Panel.__init__(self, parent)
                self.sizer = wx.BoxSizer(wx.VERTICAL)
                self.SetSizer(self.sizer)
                self.parent = parent
            def clearRes(self):
                """Clear the window's widgets."""
                self.DestroyChildren()
            def loadRes(self, resultsW):
                """"Load a results widget to the window.
                Hide the widget until it is shown individually."""
                #self.sizer.Add(
                #    wx.StaticText(self, label="Results:", style=wx.TE_CENTRE),
                #    0,
                #    wx.EXPAND)
                self.sizer.Add(resultsW, 1, wx.EXPAND)
                self.sizer.Hide(resultsW)
                self.Layout()
            def showRes(self, resultsW):
                """Show an individual results widget."""
                self.sizer.Show(resultsW)
                self.Layout()
            def hideRes(self, resultsW=None):
                """Hide an individual widget or all of them."""
                if resultsW:
                    self.sizer.Hide(resultsW)
                else:
                    for child in self.sizer.GetChildren():
                        self.sizer.Hide(child.GetWindow())
        def __init__(self, parent, controller):
            """Initializer of the results view.
            
            Takes the controller as an argument."""
            
            # Use a splitter window.  Left side is for the stack view
            # right side is for the handler results
            wx.SplitterWindow.__init__(
                self,
                parent=parent,
                style=wx.SP_3D)

            # Create a panel for the controller and a panel for the handler.
            # Load the configuration into both of them.
            # The controller view uses a reference to the handler view.
            self.hndlrW = projObj.resultsView.hndlrResView(
                parent=self)
            self.ctrlrW = stackView.stackViewWin(
                self,
                self.hndlrW,
                controller)
            self.loadConfig(controller.configDict)
    
            self.SetMinimumPaneSize(150)
            self.SplitVertically(self.ctrlrW, self.hndlrW, 250)
            
            self.ctrlr = controller
    
        def loadConfig(self, configDict):
            """Load a configuration into the view"""
            #self.hndlrW.loadConfig(configDict)
            self.ctrlrW.loadConfig(configDict)
            self.hndlrW.clearRes()

        def setConfig(self):
            """Update the results view with a new configuration."""
            self.ctrlrW.loadConfig(self.ctrlr.configDict)
            for hndlr in self.ctrlr.handlersList:
                if isinstance(hndlr, handlers.resultsViewer.ViewerMixin):
                    hndlr.createViewWidget(self.hndlrW)
                    if hndlr.getViewWidget():
                        self.hndlrW.loadRes(hndlr.getViewWidget())
            self.ctrlrW.showHndlrRes()

    def __init__(self, parent):
        """Initializer."""

        self.ctrlr = Controller()
        
        self.sizer = wx.BoxSizer()
        self.cfgView = projObj.configView(parent, self.ctrlr)
        self.resView = projObj.resultsView(parent, self.ctrlr)
        self.sizer.Add(self.cfgView, 1, flag=wx.EXPAND)
        self.sizer.Add(self.resView, 1, flag=wx.EXPAND)

        parent.SetSizer(self.sizer)
        self.showView('config')
        
    def clearConfig(self):
        """Clear the configuration by setting it to default."""
        self.loadConfig(copy.deepcopy(_defaultConfigDict))

    def loadConfig(self, configDict):
        """Load a configuration for viewing."""
        # Clear the configuration dictionary before calling update()
        self.ctrlr.configDict.clear()
        self.ctrlr.configDict.update(copy.deepcopy(configDict))
        self.cfgView.loadConfig(self.ctrlr.configDict)
        self.resView.loadConfig(self.ctrlr.configDict)

    def setConfig(self):
        """Update the controller and the results view with a new configuration."""
        self.ctrlr.setConfig()
        self.resView.setConfig()
        
    def saveConfig(self):
        """Save the configuration from the view into the controller.
        
        Only saves to self.ctrlr.configDict but does not update the
        controller.  That is done by self.ctrlr.setConfig()"""
        self.cfgView.saveConfig()

    def showView(self, view='config'):
        """Show one of the available views: 'config' or 'results'"""
        if view == 'config':
            self.sizer.Hide(self.resView)
            self.sizer.Show(self.cfgView)
            self.sizer.Layout()
        if view == 'results':
            self.sizer.Hide(self.cfgView)
            self.sizer.Show(self.resView)
            self.sizer.Layout()
