#!/usr/bin/env python
"""Handler compares a tree to what is saved in a persistent structure."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os
import string
import time
import baseClass
import sys

class Handler (baseClass.Handler):
    """Determines differences between a traversed tree and a reference tree.

    The reference tree that traversed trees are compared to is determined by
    configuration of the handler.
    
    The handler compares individual directories and files and no state is
    maintained in the traversal of a tree.  This allows more than one
    traversed tree to be compared to the reference tree.
    
    Passes stack data with the key 'status'.  Possible values:
        - 'same' - same as the equivalent node in the reference tree
        - 'diff' - different modification time than the equivalent node in the
                 reference tree
        - 'plus' - in the compared tree, not in the reference tree
        - 'minus' - in the reference tree, not in the compared tree
    """
    
    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='referenceTree',
            description='Tree to which traversed trees are compared.',
            typ='string'),
         baseClass.Handler.metaCfgCls(
            label='log file',
            description='File where differences are logged.',
            typ='string')
         )

    def __init__(self, configDict=None):
        # logFile is initialized here but can be overridden below
        # with a file from the configuration of the handler
        self.logFile = sys.stdout
        # Use a flag for filtering everything through.  If this flag is set,
        # the handler just returns True in all the hook methods.
        self.processThrough = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        # Get the reference tree from the configuration.  It is just the
        # directory at the top of the tree.
        if configDict.has_key('referenceTree'):
            self.referenceTreeRoot = configDict['referenceTree']
            if not os.path.exists(self.referenceTreeRoot):
                self.processThrough = True
        else:
            self.processThrough = True
        # If there is no logFileName in the configuration, differences are
        # logged to sys.stdout.  Otherwise, open the log file for writing.
        if configDict.has_key('log file'):
            fileName = configDict['log file']
            if configDict.has_key('suffix') and configDict['suffix']:
                fileName += '_' + configDict['suffix']
            self.logFile = file(fileName, 'w')

    def finalizeHook(self):
        self.logFile.close( )
        return True

    def beginParentDirHook(self, dirName, subdirNames=None, fileNames=None):
        if self.processThrough:
            return True
        # Calculate the equivalent directory in the reference tree.
        pathAfterTop = string.strip(dirName[len(self.topDir):], os.sep)
        referenceDir = os.path.join(self.referenceTreeRoot, pathAfterTop)

        # Flag the dirName directory as an extra directory in the compared
        # tree if it does not exist in the reference tree.
        if not os.path.exists(referenceDir):
            self.stackData['status'] = 'plus'
            # Finished here.
            return True

        # Add fake entries to the list arguments subdirNames and fileNames
        # for entries that are in the persistent structure but not in the
        # present filesystem.  That way handleChildDirHook and
        # handleFileHook will be invoked for these entries and they will
        # be detected as missing.
        for nodeName in os.listdir(referenceDir):
            fullPathName = os.path.join(dirName, nodeName)
            if not os.path.exists(fullPathName):
                self.logFile.write("Missing: %s\n" % fullPathName)
                if os.path.isdir(os.path.join(referenceDir,nodeName)):
                    if nodeName not in subdirNames:
                        subdirNames.append(nodeName)
                else:
                    if nodeName not in fileNames:
                        fileNames.append(nodeName)

        return True
    
    def handleChildDirHook(self, dirName):
        if self.processThrough:
            return True
        fullPathName = os.path.join(self.parentDir, dirName)
        # Handle the case where dirName is in the reference tree but not
        # in the compared tree.  In this case, dirName is a fake entry
        # added in beginParentDirHook
        if not os.path.exists(fullPathName):
            self.logFile.write("Missing directory: %s\n" % fullPathName)
            self.stackData['status'] = 'minus'
            return True
        # Handle the case where dirName is in the compared tree but not
        # in the reference tree
        pathAfterTop = string.strip(fullPathName[len(self.topDir):], os.sep)
        referenceDir = os.path.join(self.referenceTreeRoot, pathAfterTop)
        if not os.path.exists(referenceDir):
            self.logFile.write("Extra directory: %s\n" % fullPathName)
            self.stackData['status'] = 'plus'
        return True
    
    def handleFileHook(self, fileName):
        if self.processThrough:
            return True
        fullPathName = os.path.join(self.parentDir, fileName)
        # Handle the case where fileName is in the reference tree but not
        # in the compared tree.  In this case, fileName is a fake entry
        # added in beginParentDirHook
        if not os.path.exists(fullPathName):
            self.logFile.write("Missing file: %s\n" % fullPathName)
            self.stackData['status'] = 'minus'
            return True
        
        # Handle the other cases: file is the same, file is different,
        # file is in the compared tree but not in the reference tree.
        pathAfterTop = string.strip(fullPathName[len(self.topDir):], os.sep)
        referenceFile = os.path.join(self.referenceTreeRoot, pathAfterTop)
        modtime = self.modifValue(fileName)
        if modtime != None:
            refModTime = Handler.calcModifValue(referenceFile)
            if refModTime == None:
                # Handle case where file is in compared tree, not in
                # reference tree
                self.logFile.write("Extra file: %s, modTime=%s\n" % \
                                   (fullPathName, time.ctime(modtime)))
                self.stackData['status'] = 'plus'
            else:
                if modtime != refModTime:
                    # Handle case where files are different
                    self.logFile.write(
                        "Modified file: %s, reference modTime=%s, modTime=%s\n" % \
                        (fullPathName,
                         time.ctime(refModTime),
                         time.ctime(modtime)))
                    self.stackData['status'] = 'diff'
                else:
                    # Handle case where files are the same
                    self.stackData['status'] = 'same'
        return True

if '__main__' == __name__:
    handler = Handler()
    print handler

