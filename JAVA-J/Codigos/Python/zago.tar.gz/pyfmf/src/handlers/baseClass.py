#!/usr/bin/env python
"""Module with the base class for all the handlers."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os

class Handler (object):
    """The base class for all the handlers.

    Methods that can be overridden:
        - beginParentDirHook
        - endParentDirHook
        - handleChildDirHook
        - handleFileHook
    Default implementations are provided for these methods."""

    class metaCfgCls (object):
        """Metadata for configuration.  It is used by a GUI to dynamically
        create the configuration dictionary for each handler."""
        def __init__(self, label, description, typ):
            self.label = label
            self.desc = description
            self.typ = typ    # 'string', 'bool', or 'sequence'
        def __repr__(self):
            return "\t(label=%s\n\t desc=%s\n\t typ=%s):" % (
                repr(self.label), repr(self.desc), repr(self.typ))
        
    # The configuration metadata for this handler, in a tuple
    _metaCfg = (
        metaCfgCls(
            label='name',
            description='Optional, unused.  Identifies a handler in the stack.',
            typ='string'),
        #metaCfgCls(
        #    label='suffix',
        #    description='Optional.  Additional identifier for result file ' +
        #        'names, used to differentiate results from different runs.',
        #    typ='string')
        )
    def getMetaCfg(cls):
        return cls._metaCfg
    getMetaCfg = staticmethod(getMetaCfg)

    def __init__(self, configDict=None):
        """Initializer that uses a dictionary to configure the handler."""

        super(Handler, self).__init__(configDict)
        self.nextHandler = None
        self.topDir = ""
        self.parentDir = ""
        self.stackData = {}
        if None == configDict:
            configDict = {}
        self.setConfig(configDict)
    
    def __add__(self, otherHandler):
        """Operator for layering the handlers in a stack.  Right-hand
        member is added in the stack below the left-hand member."""

        # If there is already a nextHandler appended, append the new
        # handler to nextHandler.
        # If this is the last handler in the stack, assign the new
        # handler to nextHandler and set its info to the info of the stack.
        if self.nextHandler:
            self.nextHandler += otherHandler
        else:
            self.nextHandler = otherHandler
            while otherHandler:
                otherHandler.stackData = self.stackData
                otherHandler = otherHandler.nextHandler
        return self

    def __repr__(self):
        import StringIO
        stIo = StringIO.StringIO()
        stIo.write(self.__doc__ + '\n\n')
        for metaCfg in self.getMetaCfg(self.__class__):
            stIo.write(metaCfg)
            if self.configDict.has_key(metaCfg.label):
                stIo.write('\t' + self.configDict[metaCfg.label] +'\n')
            stIo.write('\n\n')
        return stIo.getvalue()

    def setTopDir(self, topDir):
        """Sets the top directory in the handler.
        It recurses into the handlers below it in the stack.  Invokes
        treeTopHook for initialization that is needed for every tree."""
        self.topDir = topDir
        if not self.nextHandler:
            return self.treeTopHook(topDir)
        if self.nextHandler.setTopDir(self.topDir):
            return self.treeTopHook(topDir)
        else:
            return False

    def calcModifValue(fileNamePath):
        """Helper method that calculates the value used to determine if a file
        has been changed or is different from another file.
        
        The value is the modification time of the file but it is possible
        to use another value (eg, MD5 signature) in the future.
        
        Returns the value or None if the file cannot be accessed."""
        try:
            modtime = os.path.getmtime(fileNamePath)
        except OSError, (errno, strerror):
            if os.path.exists(fileNamePath):
                # This could be a fake entry so print an error message
                # only if the file exists
                print "%s -- OS error(%s): %s" % (fileNamePath, errno, strerror)
            return None
        return modtime
    calcModifValue = staticmethod(calcModifValue)

    def modifValue(self, fileName):
        """Helper method to get the value used to determine if a file has
        been changed or is different from another file.
        
        Checks first if the value is not already passed in the stack data
        and only if it is not, it invokes calcModifValue.
        
        Returns the value or None if the file cannot be accessed."""
        fullPathName = os.path.join(self.parentDir, fileName)
        # The value associated with the file is its modification time.
        # This value may have been already determined by another
        # handler and passed as stack data.
        if self.stackData.has_key('modtime'):
            modval = self.stackData['modtime']
        else:
            modval = Handler.calcModifValue(fullPathName)
            self.stackData['modtime'] = modval
        return modval

    # setConfig may be overridden in subclasses, but those
    # methods then have to invoke the super(Handler, self) method
    def setConfig(self, configDict):
        """Updates itself with configDict."""
        if not configDict.has_key('name'):
            configDict['name']=self.__class__.__module__
        self.name = configDict['name']
        self.configDict = configDict

    # The next 6 methods are defaults for subclasses that do not override them
    def treeTopHook(self, topDir):
        """Takes care of initialization that is needed for every tree."""
        return True
    def beginParentDirHook(self, dirName, subdirNames=None, fileNames=None):
        """Handles the parent directory that the 'walk' has reached.
        It is invoked BEFORE handling the directories and files that
        the parent directory contains.
        
        It can modify the subdirNames and fileNames lists, thus affecting
        the traversal of the tree.  It is a feature useful for comparing
        the traversed tree to other trees."""
        return True
    def endParentDirHook(self):
        """Handles the parent directory that the 'walk' has reached.
        It is invoked AFTER handling the directories and files that
        the parent directory contains."""
        return True
    def handleChildDirHook(self, dirName):
        """Handles a child directory contained in the parent directory."""
        return True
    def handleFileHook(self, fileName):
        """Handles a file contained in the parent directory."""
        return True
    def finalizeHook(self):
        """Save all the results if needed and release resources."""
        return True

    # The following methods are wrappers around the hook methods
    # and they are the ones directly invoked by the Controller.
    def beginParentDirWrapper(self, dirName, subdirNames=None, fileNames=None):
        """Invokes beginParentDirHook for this handler and, recursively, for
        each handler below this one in the stack."""
        self.parentDir = dirName
        if not self.nextHandler:
            self.stackData.clear()
            return self.beginParentDirHook(dirName, subdirNames, fileNames)
        if self.nextHandler.beginParentDirWrapper(dirName,
                                                  subdirNames,
                                                  fileNames):
            return self.beginParentDirHook(dirName, subdirNames, fileNames)
        else:
            return False
    def endParentDirWrapper(self):
        """Invokes endParentDirHook for this handler and, recursively, for
        each handler below this one in the stack."""
        self.parentDir = ""
        if self.nextHandler:
            self.nextHandler.endParentDirWrapper( )
        self.endParentDirHook( )
    def handleChildDirWrapper(self, dirName):
        """Invokes handleChildDirHook for this handler and, recursively, for
        each handler below this one in the stack."""
        if not self.nextHandler:
            self.stackData.clear()
            return self.handleChildDirHook(dirName)
        if self.nextHandler.handleChildDirWrapper(dirName):
            return self.handleChildDirHook(dirName)
        else:
            return False
    def handleFileWrapper(self, fileName):
        """Invokes handleFileHook for this handler and, recursively, for
        each handler below this one in the stack."""
        if not self.nextHandler:
            self.stackData.clear()
            return self.handleFileHook(fileName)
        if self.nextHandler.handleFileWrapper(fileName):
            return self.handleFileHook(fileName)
        else:
            return False
    def finalizeWrapper(self):
        """Invokes finalizeHook for this handler and, recursively, for
        each handler below this one in the stack."""
        if not self.nextHandler:
            self.stackData.clear()
            return self.finalizeHook()
        if self.nextHandler.finalizeWrapper():
            return self.finalizeHook()
        else:
            return False

# Simple sanity testing
if '__main__' == __name__:
    a = Handler({'name':'alpha'})
    b = Handler({'name':'beta'})
    c = Handler({'name':'gamma'})
    d = a+b+c
    a.setTopDir('..')
    print a, b, c, d
    print a.name, b.name, c.name, d.name
    print a.nextHandler, b.nextHandler, c.nextHandler, d.nextHandler
    print a.nextHandler.name, b.nextHandler.name, d.nextHandler.name
    print a.beginParentDirWrapper('..'+os.sep+'..')
    print a.handleChildDirWrapper('walkFwk')
    print a.beginParentDirWrapper('walkFwk')
    print a.handleChildDirWrapper('config')
    print a.beginParentDirWrapper('walkFwk'+os.sep+'config')
    print a.handleFileWrapper('ctrlrCfg.py')
