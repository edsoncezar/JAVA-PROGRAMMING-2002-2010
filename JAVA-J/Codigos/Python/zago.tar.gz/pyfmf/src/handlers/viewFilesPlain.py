#!/usr/bin/env python
"""Handler that creates a plain list view of the files."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import baseClass, resultsViewer
import wx
import os

class Handler (baseClass.Handler, resultsViewer.ViewerMixin):
    """Creates a plain list view of the files."""

    # The configuration metadata for this handler
    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='enabled',
            description='This handler can be enabled or disabled.',
            typ='bool'),)

    def __init__(self, configDict=None):
        """Initializer."""
        self.enabled = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        """Updates itself with configDict."""
        super(Handler, self).setConfig(configDict)
        self.enabled = configDict['enabled']

    def handleFileHook(self, fileName):
        """Handles a file contained in the parent directory."""
        if self.enabled:
            fullPathName = os.path.join(self.parentDir, fileName)
            self.viewWidget.AppendText(fullPathName+'\n')
        return True

    def createViewWidget(self, parent):
        """Create the results view widget of this handler."""
        if self.enabled:
            self.viewWidget = wx.TextCtrl(parent, style=wx.TE_MULTILINE)
            self.viewWidget.SetMaxLength(0)

# Simple sanity testing
if '__main__' == __name__:
    handler = Handler()
    print handler
