#!/usr/bin/env python
"""Handler that removes files."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os
import baseClass

class Handler (baseClass.Handler):
    """Removes all the files that are passed in."""

    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='enabled',
            description='This handler can be enabled or disabled.',
            typ='bool'),)

    def __init__(self, configDict=None):
        self.enabled = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        if configDict.has_key('enabled'):
            self.enabled = configDict['enabled']


    def handleFileHook(self, fileName):
        if not self.enabled:
            return True
        fullPathName = os.path.join(self.parentDir, fileName)
        # Check whether it is a fake entry from another handler
        if os.path.exists(fullPathName):
            try:
                os.remove(fullPathName)
            except OSError, (errno, strerror):
                print "%s -- OS error(%s): %s" % (fullPathName,
                                                  errno,
                                                  strerror)
                return False
        return False

if '__main__' == __name__:
    handler = Handler()
    print handler
