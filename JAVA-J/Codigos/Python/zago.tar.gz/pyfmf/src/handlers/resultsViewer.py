#!/usr/bin/env python
"""Module with the mixin class for all the results viewers."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

class ViewerMixin (object):
    """Mixin class for all the results viewer handlers.

    Methods that can be overridden:
        - createViewWidget
        - getViewWidget
    Default implementations are provided for these methods."""

    def __init__(self, configDict=None):
        """Initializer."""
        super(ViewerMixin, self).__init__()
        self.viewWidget = None
    
    def createViewWidget(self, parent):
        """Create the results view widget of this handler."""
        return

    def getViewWidget(self):
        """Get the results view widget for this handler."""
        return self.viewWidget
