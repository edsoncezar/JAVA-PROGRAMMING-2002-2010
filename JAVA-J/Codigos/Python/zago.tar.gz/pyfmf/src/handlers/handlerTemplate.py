#!/usr/bin/env python
"""Template file for handlers.

Un-comment and implement methods as needed."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

__author__ = ""
__author_email__ = ""

import baseClass

class Handler (baseClass.Handler):
    """Un-comment and implement methods as needed."""

    # The configuration metadata for this handler
    #_metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler)  # + more

    #def __init__(self, configDict=None):
    #    """Initializer."""
    #    super(Handler, self).__init__(configDict)
    
    # setConfig may be overridden in subclasses.
    # Do not forget to invoke the super(Handler, self) method
    #def setConfig(self, configDict):
    #    """Updates itself with configDict."""
    #    super(Handler, self).setConfig(configDict)

    # The next 6 methods are defaults for subclasses that do not override them
    #def treeTopHook(self, topDir):
    #    """Takes care of initialization that is needed for every tree."""
    #    return True
    #def beginParentDirHook(self, dirName, subdirNames=None, fileNames=None):
    #    """Handles the parent directory that the 'walk' has reached.
    #    It is invoked BEFORE handling the directories and files that
    #    the parent directory contains."""
    #    return True
    #def endParentDirHook(self):
    #    """Handles the parent directory that the 'walk' has reached.
    #    It is invoked AFTER handling the directories and files that
    #    the parent directory contains."""
    #    return True
    #def handleChildDirHook(self, dirName):
    #    """Handles a child directory contained in the parent directory."""
    #    return True
    #def handleFileHook(self, fileName):
    #    """Handles a file contained in the parent directory."""
    #    return True
    #def finalizeHook(self):
    #    """Save all the results if needed and release resources."""
    #    return True

# Simple sanity testing
if '__main__' == __name__:
    handler = Handler()
    print handler
