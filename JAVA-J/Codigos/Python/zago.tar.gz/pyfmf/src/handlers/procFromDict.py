#!/usr/bin/env python
"""Handler compares the tree to what is saved in a persistent structure."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os
import string
import time
import baseClass
import cPickle
import sys

class Handler (baseClass.Handler):
    """Determines file and directory changes from a previously saved structure.

    Uses the persistent structure created by the 'procBuildDict' handler.
    Creates stack data indicating which files and directories are new,
    deleted, or modified.  Logs all changes into a file.
    
    Passes stack data with the key 'status'.  Possible values:
        - 'same' - unchanged since saved in persistent structure
        - 'diff' - modified since saved in persistent structure
        - 'plus' - added since saved in persistent structure
        - 'minus' - deleted since saved in persistent structure
    """
    
    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='persistence file',
            description='File from which persistent data is retrieved.',
            typ='string'),
         baseClass.Handler.metaCfgCls(
            label='log file',
            description='File where changes are logged.',
            typ='string')
         )

    def __init__(self, configDict=None):
        # logFile is initialized here but can be overridden in setConfig
        # with a file from the configuration of the handler
        self.logFile = sys.stdout
        # The entire files structure is kept in nested dictionaries.
        # filesStructDict is the top dictionary.  Initialize it as
        # an empty dictionary.
        self.filesStructDict = {}
        # As filesStructDict is traversed, the present place in the tree
        # is kept in nodeDict.  Initialize it as the top of the structure.
        self.nodeDict = self.filesStructDict
        # Use a flag for filtering everything through.  If this flag is set,
        # the handler just returns True in all the hook methods.
        self.filterThrough = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        # Get the persistence file name from the configuration
        if configDict.has_key('persistence file') and \
           configDict['persistence file']:
            fileName = configDict['persistence file']
        else:
            self.filterThrough = True
        if configDict.has_key('suffix') and configDict['suffix']:
            fileName += '_' + configDict['suffix']
        if os.access(fileName, os.F_OK):
            persistenceFile = file(fileName, 'r')
            # Load self.filesStructDict with the structure unpickled from
            # the persistence file.
            try:
                self.filesStructDict = cPickle.load(persistenceFile)
            except:
                print 'Could not load pickle file', fileName
                self.filesStructDict = {}
            persistenceFile.close( )
            self.filterThrough = False
        else:
            self.filesStructDict = {}
            self.filterThrough = True
        # Open the log file
        if configDict.has_key('log file'):
            fileName = configDict['log file']
            if configDict.has_key('suffix') and configDict['suffix']:
                fileName += '_' + configDict['suffix']
            self.logFile = file(fileName, 'w')

    def finalizeHook(self):
        self.logFile.close( )
        return True

    def beginParentDirHook(self, dirName, subdirNames=None, fileNames=None):
        if self.filterThrough:
            return True

        # Find the node that corresponds to dirName in filesStructDict.
        # First build a list of the elements in the path and then traverse
        # filesStructDict through each one of these elements.
        # The first element is self.topDir.
        dirPathList = [self.topDir]
        pathAfterTop = string.strip(dirName[len(self.topDir):], os.sep)
        # Handle the case where dirName==self.topDir+os.sep
        if len(pathAfterTop)>0:
            dirPathList.extend(pathAfterTop.split(os.sep))
        self.nodeDict = self.filesStructDict
        # Handle the case where self.topDir is not in the persistent
        # structure
        if not self.filesStructDict.has_key(self.topDir):
            self.logFile.write("New directory: %s\n" % self.topDir)
            # Add node for self.topDir to the structure so it can be
            # traversed
            self.nodeDict[self.topDir] = {}
            self.stackData['status'] = 'plus'
        # Start from the top of self.filesStructDict and traverse down to
        # the node for dirName
        for dirNode in dirPathList:
            if self.nodeDict.has_key(dirNode):
                self.nodeDict = self.nodeDict[dirNode]
            else:
                # If it's not in the persistent structure, flag it as a new
                # directory and flag self.nodeDict as invalid.
                self.stackData['status'] = 'plus'
                self.nodeDict = None
                return True

        # Handle the case where dirName is a fake entry added when
        # beginParentDirHook was called for its parent directory because
        # it is in the persistent structure but it does not exist anymore.
        if not os.path.exists(dirName):
            self.stackData['status'] = 'minus'
        # Add fake entries to the list arguments subdirNames and fileNames
        # for entries that are in the persistent structure but not in the
        # present filesystem.  That way handleChildDirHook and
        # handleFileHook will be invoked for these entries and they will
        # be detected as deleted.
        for nodeName in self.nodeDict:
            fullPathName = os.path.join(dirName, nodeName)
            if not os.path.exists(fullPathName):
                if type(self.nodeDict[nodeName])==dict:
                    if nodeName not in subdirNames:
                        subdirNames.append(nodeName)
                else:
                    if nodeName not in fileNames:
                        fileNames.append(nodeName)

        return True
    
    def handleChildDirHook(self, dirName):
        if self.filterThrough:
            return True
        fullPathName = os.path.join(self.parentDir, dirName)
        # Handle case of deleted directories.  In this case, dirName is a
        # fake entry added in beginParentDirHook.
        if not os.path.exists(fullPathName):
            self.logFile.write("Deleted directory: %s\n" % fullPathName)
            self.stackData['status'] = 'minus'
            return True
        # Handle case of new directories
        if (not self.nodeDict) or (not self.nodeDict.has_key(dirName)):
            self.logFile.write("New directory: %s\n" % fullPathName)
            self.stackData['status'] = 'plus'
        return True
    
    def handleFileHook(self, fileName):
        if self.filterThrough:
            return True
        fullPathName = os.path.join(self.parentDir, fileName)
        # Handle case of deleted files.  In this case, fileName is a
        # fake entry added in beginParentDirHook.
        if not os.path.exists(fullPathName):
            self.logFile.write("Deleted file: %s\n" % fullPathName)
            self.stackData['status'] = 'minus'
            return True
        modtime = self.modifValue(fileName)
        if modtime == None:
            return False
        if self.nodeDict and self.nodeDict.has_key(fileName):
            # Handle case of modified and unmodified files for files that
            # are also in the persistent structure.
            if modtime != self.nodeDict[fileName]:
                self.logFile.write(
                    "Modified file: %s, old modTime=%s, new "
                        "modTime=%s\n" % \
                    (fullPathName,
                     time.ctime(self.nodeDict[fileName]),
                     time.ctime(modtime)))
                self.stackData['status'] = 'diff'
            else:
                self.stackData['status'] = 'same'
        else:
            # Handle case of new files
            self.logFile.write("New file: %s, modTime=%s\n" % \
                               (fullPathName, time.ctime(modtime)))
            self.stackData['status'] = 'plus'
        return True

if '__main__' == __name__:
    handler = Handler()
    print handler
