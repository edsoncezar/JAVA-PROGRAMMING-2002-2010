#!/usr/bin/env python
"""Handler that filters files based on their base names."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import fnmatch
import baseClass

class Handler (baseClass.Handler):
    """Filters files with base names that match any of the patterns in a sequence.

    Uses fnmatch to compare file names to patterns in the configuration."""
    
    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='pattern sequence',
            description='Sequence of patterns for file names to be filtered.',
            typ='sequence'),
         baseClass.Handler.metaCfgCls(
            label='filter in',
            # selection is equivalent to True, deselection is equivalent to
            # False
            description='Select to filter in, deselect to filter out.',
            typ='bool'))

    def __init__(self, configDict=None):
        # Set of patterns to match the directory basenames.  Initialize
        # as empty.
        self.filterSet = []
        # Boolean setting that configures the filter to filter in or out.
        # Initialize to None even if that can be mistaken as 'out'
        self.filterIn = None
        # Use a flag for filtering everything through.  If this flag is set,
        # the handler just returns True in all the hook methods.
        self.filterThrough = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        # Configure filterSet and filterIn.  If any of them is missing
        # from the configuration, just filter everything through.
        if configDict.has_key('pattern sequence'):
            self.filterSet = list(configDict['pattern sequence'])
        if not self.filterSet:
            self.filterThrough = True
        if configDict.has_key('filter in'):
            self.filterIn = configDict['filter in']
        else:
            self.filterThrough = True

    def handleFileHook(self, fileName):
        if self.filterThrough:
            return True
        # If the basename matches any of the patterns, filter in or out
        # based on the value of self.filterIn.
        for fileNamePattern in self.filterSet:
            if fnmatch.fnmatch(fileName, fileNamePattern):
                return self.filterIn
        return not self.filterIn

if '__main__' == __name__:
    handler = Handler()
    print handler

