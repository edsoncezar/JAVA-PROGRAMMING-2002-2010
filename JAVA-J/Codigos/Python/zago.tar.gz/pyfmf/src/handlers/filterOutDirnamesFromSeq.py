#!/usr/bin/env python
"""Deprecated, replaced by filterDirsBasename."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import fnmatch
import baseClass

class Handler (baseClass.Handler):
    """Deprecated, replaced by filterDirsBasename.

    Uses fnmatch to compare directory names to patterns in the configuration."""
    
    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='pattern sequence',
            description='Sequence of patterns for directory names to be ' +
                'filtered out.',
            typ='sequence'),)

    def __init__(self, configDict=None):
        self.filterOutSet = []
        self.filterThrough = False
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        if not configDict.has_key('pattern sequence'):
            filterOutSeq = []
            self.filterThrough = True
        else:
            filterOutSeq = configDict['pattern sequence']
            if not filterOutSeq:
                self.filterThrough = True
        self.filterOutSet = []
        for dirNamePattern in filterOutSeq:
            self.filterOutSet.append(dirNamePattern)

    def handleChildDirHook(self, dirName):
        if self.filterThrough:
            return True
        for dirNamePattern in self.filterOutSet:
            if fnmatch.fnmatch(dirName, dirNamePattern):
                return False
        return True

if '__main__'==__name__:
    handler = Handler()
    print handler
