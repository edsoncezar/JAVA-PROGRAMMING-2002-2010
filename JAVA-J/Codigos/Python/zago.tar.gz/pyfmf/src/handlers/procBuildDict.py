#!/usr/bin/env python
"""Handler that builds a persistent data structure from the tree."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os
import string
import baseClass
import cPickle

class Handler (baseClass.Handler):
    """Builds a persistent structure containing the tree.

    The structure models one tree (all the top directories are branches in
    this single tree) as nested dictionaries.  The top of the structure is
    a dictionary with an element for each one of the top directories.
    All the values associated with directories are dictionaries
    themselves, containing the sub-directories and the files.
    The values associated with files contain information relevant
    to the file (in the present implementation, only modification time).
    The result is a nesting of dictionaries.  For example, a file
    like '/usr/include/sys/wait.h' would be represented in the
    persistent structure by
    self.filesStructDict['/']['usr']['include']['sys']['wait.h'].

    Reasons for not using the 'shelve' module.  First, shelve would
    have to be used with writeback=True because of the nested
    directories.  That means that it is not really more efficient
    than this structure.  Second, using this structure does not
    affect the persistence file until the handler is destroyed.
    This allows other handlers in the stack to use the unchanged
    file while this handler only prepares the changes to the file.
    Using shelve would not allow this.
    """

    _metaCfg = baseClass.Handler.getMetaCfg(baseClass.Handler) + \
        (baseClass.Handler.metaCfgCls(
            label='persistence file',
            description='File in which persistent data is stored',
            typ='string'),)

    def __init__(self, configDict=None):
        # The entire files structure is kept in nested dictionaries.
        # filesStructDict is the top dictionary.  Initialize it as
        # an empty dictionary.
        self.filesStructDict = {}
        # As filesStructDict is traversed, the present place in the tree
        # is kept in nodeDict.  Initialize it as the top of the structure.
        self.nodeDict = self.filesStructDict
        super(Handler, self).__init__(configDict)
    
    def setConfig(self, configDict):
        super(Handler, self).setConfig(configDict)
        self.persistenceFileName = configDict['persistence file']
        if configDict.has_key('suffix') and configDict['suffix']:
            self.persistenceFileName += '_' + configDict['suffix']

    def treeTopHook(self, topDir):
        # Initialize every top directory branch in filesStructDict as an
        # empty dictionary.
        self.filesStructDict[topDir] = {}
        return True
    
    def finalizeHook(self):
        if self.persistenceFileName:
            persistenceFile = file(self.persistenceFileName, 'w')
            cPickle.dump(self.filesStructDict, persistenceFile)
            persistenceFile.close( )
        return True
        
    def beginParentDirHook(self, dirName, subdirNames=None, fileNames=None):
        # Check first if the parent directory exists because handlers are
        # allowed to add fake entries for their processing.
        if not os.path.exists(dirName):
            return True
        # Find the node that corresponds to dirName in filesStructDict.
        # First build a list of the elements in the path and then traverse
        # filesStructDict through each one of these elements.
        # The first element is self.topDir.
        dirPathList = [self.topDir]
        pathAfterTop = string.strip(dirName[len(self.topDir):], os.sep)
        # Handle the case where dirName==self.topDir+os.sep
        if len(pathAfterTop)>0:
            dirPathList.extend(pathAfterTop.split(os.sep))
        # Start from the top of self.filesStructDict and traverse down to
        # the node for dirName
        self.nodeDict = self.filesStructDict
        for dirNode in dirPathList:
            self.nodeDict = self.nodeDict[dirNode]
        return True
    
    def handleChildDirHook(self, dirName):
        # Add the directory as an element in the filesStructDict node for
        # self.parentDir.  Check first if it exists because handlers are
        # allowed to add fake entries for their processing.
        fullPathName = os.path.join(self.parentDir, dirName)
        if os.path.exists(fullPathName):
            self.nodeDict[dirName] = {}
        return True
    
    def handleFileHook(self, fileName):
        # Add the file as an element in the filesStructDict node for
        # self.parentDir.  Check first if it exists because handlers are
        # allowed to add fake entries for their processing.
        modval = self.modifValue(fileName)
        if modval != None:
            self.nodeDict[fileName] = modval
        return True
    
if '__main__' == __name__:
    handler = Handler()
    print handler
