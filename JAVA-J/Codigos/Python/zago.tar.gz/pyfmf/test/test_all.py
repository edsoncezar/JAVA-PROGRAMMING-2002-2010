#!/usr/bin/env python
"""Test suite that runs all the test cases."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import os
import sys
import unittest
sys.path.insert(0, '.')
from testsConfig import testWorkDir
import test_handlers_filterDirsBasename
import test_handlers_filterDirsPath
import test_handlers_filterFilesBasename
import test_handlers_filterFilesBasenameRe
import test_handlers_filterFilesPath
import test_handlers_logAll
import test_handlers_procFromDict
import test_handlers_procBuildDict
import test_handlers_procCompareTree
import test_ctrlr_zigo

def generateTestFiles( ):
    """Helper function for generating the test files."""
    tcList = [
        test_handlers_filterDirsBasename.filterInTestCase,
        test_handlers_filterDirsBasename.filterOutTestCase,
        test_handlers_filterDirsPath.filterInTestCase,
        test_handlers_filterDirsPath.filterOutTestCase,
        test_handlers_filterFilesBasename.filterInTestCase,
        test_handlers_filterFilesBasename.filterOutTestCase,
        test_handlers_filterFilesBasenameRe.filterInTestCase,
        test_handlers_filterFilesBasenameRe.filterOutTestCase,
        test_handlers_filterFilesPath.filterInTestCase,
        test_handlers_filterFilesPath.filterOutTestCase,
        test_handlers_logAll.writeToFileTestCase,
        test_handlers_procBuildDict.buildDictTestCase,
        test_handlers_procFromDict.stackOutputTestCase,
        test_handlers_procFromDict.logFileTestCase,
        test_handlers_procCompareTree.stackOutputTestCase,
        test_handlers_procCompareTree.logFileTestCase
    ]
    for tcClass in tcList:
        tcInst = tcClass( )
        tcInst.generateTestFiles( )

if '__main__' == __name__:
    suite = unittest.TestSuite()
    suite.addTests([
        test_handlers_filterDirsBasename.filterInTestCase("testRunWalk"),
        test_handlers_filterDirsBasename.filterOutTestCase("testRunWalk"),
        test_handlers_filterDirsPath.filterInTestCase("testRunWalk"),
        test_handlers_filterDirsPath.filterOutTestCase("testRunWalk"),
        test_handlers_filterFilesBasename.filterInTestCase("testRunWalk"),
        test_handlers_filterFilesBasename.filterOutTestCase("testRunWalk"),
        test_handlers_filterFilesBasenameRe.filterInTestCase("testRunWalk"),
        test_handlers_filterFilesBasenameRe.filterOutTestCase("testRunWalk"),
        test_handlers_filterFilesPath.filterInTestCase("testRunWalk"),
        test_handlers_filterFilesPath.filterOutTestCase("testRunWalk"),
        test_handlers_logAll.writeToFileTestCase("testRunWalk"),
        test_handlers_procFromDict.stackOutputTestCase("testRunWalk"),
        test_handlers_procFromDict.logFileTestCase("testRunWalk"),
        test_handlers_procBuildDict.buildDictTestCase("testRunWalk"),
        test_handlers_procBuildDict.buildDictTestCase("testDictOut"),
        test_handlers_procCompareTree.stackOutputTestCase("testRunWalk"),
        test_handlers_procCompareTree.logFileTestCase("testRunWalk"),
        test_ctrlr_zigo.ctrlrTestCase("testCtrlrSanity")
        ])
    runner = unittest.TextTestRunner()
    os.chdir(testWorkDir)
    runner.run(suite)
