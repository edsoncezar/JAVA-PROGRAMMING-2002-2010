"""Test case for the 'procFromDict' handler"""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import unittest
import genericTc
import testsConfig
testWorkDir = testsConfig.testWorkDir
import os
from handlers import procFromDict
from handlers import logAll

class stackOutputTestCase (genericTc.baseClassForHandlerTestCase,
                           genericTc.origModifMixin):
    """Testing of the 'procFromDict' handler.  Implements only the
    generic test for the output passed to the stack."""

    def setUp(self):
        self.setUpTree('modified')
        self.tstFileName = 'procFromDict.test'
        self.outFileName = 'procFromDict.out'
        configDict = {
            'name':'wFileP',
            'file name':testWorkDir+os.sep+self.outFileName}
        self.handler = logAll.Handler(configDict)
        configDict = {
            'name':'fDictP',
            'persistence file':testWorkDir+os.sep+'persistentDict.test',
            'log file':testWorkDir+os.sep+'listOfChanges.out'}
        self.handler += procFromDict.Handler(configDict)
        genericTc.baseClassForHandlerTestCase.setUp(self)

class logFileTestCase (genericTc.baseClassForHandlerTestCase,
                       genericTc.origModifMixin):
    """Testing of the 'procFromDict' handler.  Implements only the
    generic test for the output to the log file."""

    def setUp(self):
        self.setUpTree('modified')
        self.tstFileName = 'listOfChanges.test'
        self.outFileName = 'listOfChanges.out'
        configDict = {
            'name':'wFileP',
            'file name':testWorkDir+os.sep+'procFromDict.out'}
        self.handler = logAll.Handler(configDict)
        configDict = {
            'name':'fDictP',
            'persistence file':testWorkDir+os.sep+'persistentDict.test',
            'log file':testWorkDir+os.sep+self.outFileName}
        self.handler += procFromDict.Handler(configDict)
        genericTc.baseClassForHandlerTestCase.setUp(self)

def generateTestFiles( ):
    """Helper function for generating the test files."""
    tcInst = stackOutputTestCase( )
    tcInst.generateTestFiles( )
    tcInst = logFileTestCase( )
    tcInst.generateTestFiles( )

if __name__ == '__main__':
    unittest.main()
