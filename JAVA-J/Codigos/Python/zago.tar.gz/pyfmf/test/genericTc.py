"""Base class for all the test cases."""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import unittest
import os
import tarfile
import testsConfig
testWorkDir = testsConfig.testWorkDir

class baseClassForHandlerTestCase (unittest.TestCase):
    """Generic code for testing any of the handler combinations"""

    handler = None
    topDir = None
    outFileName = None
    tstFileName = None
    outFile = None
    tstFile = None
    msg = None

    def setUp(self):
        self.msg = self.__class__.__module__+'.'+self.__class__.__name__
        self.handler.setTopDir(self.topDir)

    def tearDown(self):
        if self.tstFile: self.tstFile.close()
        if self.outFile: self.outFile.close()

    def runWalk(self):
        for dirPath, dirNames, fileNames in os.walk(self.topDir):
            self.handler.beginParentDirWrapper(dirPath, dirNames, fileNames)
            for dirName in dirNames[:]:
                if not self.handler.handleChildDirWrapper(dirName):
                    del dirNames[dirNames.index(dirName)]
            for fileName in fileNames:
                self.handler.handleFileWrapper(fileName)
            self.handler.endParentDirWrapper( )
        self.handler.finalizeWrapper()

    def generateTestFiles(self):
        self.setUp( )
        self.runWalk( )
        self.tearDown( )
        del self.handler
        os.chdir(testWorkDir)
        os.rename(self.outFileName, self.tstFileName)

    def testRunWalk(self):
        """Generic test for handler stacks with 'writeToFile' at the top"""
        self.runWalk()
        del self.handler
        self.tstFile = file(testWorkDir+os.sep+self.tstFileName)
        self.outFile = file(testWorkDir+os.sep+self.outFileName)
        for testLine in self.tstFile.readlines( ):
            outLine = self.outFile.readline( )
            self.assertEqual(testLine, outLine, msg=self.msg)
        self.assert_("" == self.outFile.readline( ), msg=self.msg)
    
    # Override runTest to fix problems with default instances of test
    # cases when generating test files.
    def runTest(self):
        self.testRunWalk()

class origModifMixin (object):
    """Helper class for test cases that use the 'orig' and 'modified' trees"""

    def setUpTree(self, tree):
        os.chdir(testWorkDir)
        myTar = tarfile.open(tree+'.tar')
        member = myTar.next()
        while member:
            myTar.extract(member)
            member = myTar.next()
        myTar.close()
        os.chdir(tree)
        self.topDir = 'TestRoot'
