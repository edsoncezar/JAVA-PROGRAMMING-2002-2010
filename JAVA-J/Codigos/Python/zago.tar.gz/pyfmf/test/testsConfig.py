"""Configuration used by all the test cases."""

__author__ = "Dan Perl <danperl@users.sourceforge.net>"

import os, sys

testsDir = os.path.dirname(os.path.abspath(__file__))
baseDir = os.path.split(testsDir)[0]
if baseDir not in sys.path: sys.path.append(baseDir)
# calculate srcDir as equivalent of '../src'
srcDir = os.path.join(baseDir, 'src')
if srcDir not in sys.path: sys.path.append(srcDir)
# calculate handlersDir as equivalent of '../src/handlers'
handlersDir = os.path.join(baseDir, 'src', 'handlers')
if handlersDir not in sys.path: sys.path.append(handlersDir)
ctrlrDir = os.path.join(baseDir, 'src', 'ctrlr')
if ctrlrDir not in sys.path: sys.path.append(ctrlrDir)
testWorkDir = testsDir
