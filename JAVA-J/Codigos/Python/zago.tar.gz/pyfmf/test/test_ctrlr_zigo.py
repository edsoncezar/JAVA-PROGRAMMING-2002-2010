"""Sanity test case for the controller class"""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import unittest
import testsConfig
testWorkDir = testsConfig.testWorkDir
import os
import zigo
import genericTc

testRootPath = os.path.join(testWorkDir, 'modified', 'TestRoot')
configDict = \
{'suffix': 'ctrlr',
 'description': 'mock description',
 'handlersCfg': [('logAll',
                  {'name': 'wFileP', 'file name': 'logEverything2'}),
                 ('procFromDict',
                  {'log file': 'listOfChanges',
                   'name': 'fDictP',
                   'persistence file': 'persistentDict'}),
                 ('procBuildDict',
                  {'persistence file': 'persistentDict', 'name': 'bDictP'}),
                 ('logAll',
                  {'name': 'wFileP', 'file name': 'logEverything1'}),
                 ('filterOutFilesFromSeq',
                  {'pattern sequence': (
                    os.path.join(testRootPath,'D_2','D_2_1','F_2_1_1'),),
                   'name': 'fofSeqP'}),
                 ('filterOutDirsFromSeq',
                  {'pattern sequence': (
                    os.path.join(testRootPath,'D_2','D_2_3'),),
                   'name': 'fodSeqP'})],
 'topDirs': [testRootPath],
 'workDir': testWorkDir}

class ctrlrTestCase (unittest.TestCase, genericTc.origModifMixin):
    """Sanity test case for the controller class.
    
    Tests only that handlers can be added based on a configuration and
    that runWalk works, both without any exceptions being thrown.  Results
    from handlers are not tested.  That functionality is tested for each
    handler."""

    def setUp(self):
        self.setUpTree('modified')
        self.ctrlr = zigo.Controller(configDict)
        
    def testCtrlrSanity(self):
        self.ctrlr.run( )

if __name__ == '__main__':
    unittest.main()
