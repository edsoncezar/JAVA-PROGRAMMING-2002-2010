"""Test case for the 'procCompareTree' handler"""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import unittest
import genericTc
import testsConfig
testWorkDir = testsConfig.testWorkDir
import os
import tarfile
from handlers import procCompareTree
from handlers import logAll

class stackOutputTestCase (genericTc.baseClassForHandlerTestCase,
                           genericTc.origModifMixin):
    """Testing of the 'procCompareTree' handler.  Implements only the
    generic test for the output passed to the stack."""

    def setUp(self):
        self.setUpTree('orig')
        self.setUpTree('modified')
        self.tstFileName = 'procCompareTree.test'
        self.outFileName = 'procCompareTree.out'
        configDict = {
            'name':'wFileP',
            'file name':testWorkDir+os.sep+self.outFileName}
        self.handler = logAll.Handler(configDict)
        configDict = {
            'name':'cTreeP',
            'referenceTree':testWorkDir+os.sep+'orig'+os.sep+self.topDir,
            'log file':testWorkDir+os.sep+'listOfDiffs.out'}
        self.handler += procCompareTree.Handler(configDict)
        genericTc.baseClassForHandlerTestCase.setUp(self)

class logFileTestCase (genericTc.baseClassForHandlerTestCase,
                       genericTc.origModifMixin):
    """Testing of the 'procCompareTree' handler.  Implements only the
    generic test for the output to the log file."""

    def setUp(self):
        self.setUpTree('orig')
        self.setUpTree('modified')
        self.tstFileName = 'listOfDiffs.test'
        self.outFileName = 'listOfDiffs.out'
        configDict = {
            'name':'cTreeP',
            'file name':testWorkDir+os.sep+'procCompareTree.out'}
        self.handler = logAll.Handler(configDict)
        configDict = {
            'name':'fDictP',
            'referenceTree':testWorkDir+os.sep+'orig'+os.sep+self.topDir,
            'log file':testWorkDir+os.sep+self.outFileName}
        self.handler += procCompareTree.Handler(configDict)
        genericTc.baseClassForHandlerTestCase.setUp(self)

def generateTestFiles( ):
    """Helper function for generating the test files."""
    tcInst = stackOutputTestCase( )
    tcInst.generateTestFiles( )
    tcInst = logFileTestCase( )
    tcInst.generateTestFiles( )

if __name__ == '__main__':
    unittest.main()
