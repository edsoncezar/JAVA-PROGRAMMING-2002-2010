"""Test case for the 'buildDict' handler"""

# Copyright (c) 2004 Dan Perl <danperl@users.sourceforge.net>
# URL: http://pyfmf.sourceforge.net
# Released under the GNU General Public License (GPL).
# See http://www.opensource.org/licenses/gpl-license.php.
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA

import unittest
import genericTc
import testsConfig
testWorkDir = testsConfig.testWorkDir
import cPickle
import os
from handlers import procBuildDict
from handlers import logAll

def compareDicts(dict1, dict2):
    """Helper function"""
    keys1 = dict1.keys()
    keys2 = dict2.keys()
    numKeys1 = len(keys1)
    numKeys2 = len(keys2)
    if numKeys1 != numKeys2:
        return False
    for key in keys1:
        if key not in keys2:
            return False
        if type(dict1[key]) != type(dict2[key]):
            return False
        if type(dict1[key]) == dict:
            if not compareDicts(dict1[key], dict2[key]):
                return False
        elif type(dict1[key]) == list or type(dict1[key]) == tuple:
            for i in range(len(dict1[key])):
                if dict1[key][i] != dict2[key][i]:
                    return False
        else:
            if dict1[key] != dict2[key]:
                return False
    return True

class buildDictTestCase (genericTc.baseClassForHandlerTestCase,
                         genericTc.origModifMixin):
    """Testing of the 'buildDict' handler."""

    def generateTestFiles(self):
        genericTc.baseClassForHandlerTestCase.generateTestFiles(self)
        os.rename(self.outPersistDict, self.testPersistDict)

    def setUp(self):
        self.setUpTree('orig')
        self.tstFileName = 'buildDict.test'
        self.outFileName = 'buildDict.out'
        configDict = {
            'name':'wFileP',
            'file name':testWorkDir+os.sep+self.outFileName}
        self.handler = logAll.Handler(configDict)
        self.outPersistDict = 'persistentDict.out'
        self.testPersistDict = 'persistentDict.test'
        configDict = {
            'name':'bDictP',
            'persistence file':testWorkDir+os.sep+self.outPersistDict}
        self.handler += procBuildDict.Handler(configDict)
        genericTc.baseClassForHandlerTestCase.setUp(self)

    def testDictOut(self):
        """Test of the 'buildDict' handler based on comparing the
        output pickled dictionary to the dictionary pickled in
        a test file.  Cannot just compare the files because the order of
        elements may not match."""
        self.runWalk()
        del self.handler
        os.chdir(testWorkDir)
        persistenceFile = file(self.testPersistDict, 'r')
        testFilesStructDict = cPickle.load(persistenceFile)
        persistenceFile.close( )
        persistenceFile = file(self.outPersistDict, 'r')
        outFilesStructDict = cPickle.load(persistenceFile)
        persistenceFile.close( )
        self.assert_(compareDicts(testFilesStructDict, outFilesStructDict))

def generateTestFiles( ):
    """Helper function for generating the test files."""
    tcInst = buildDictTestCase( )
    tcInst.generateTestFiles( )

if __name__ == '__main__':
    unittest.main()
