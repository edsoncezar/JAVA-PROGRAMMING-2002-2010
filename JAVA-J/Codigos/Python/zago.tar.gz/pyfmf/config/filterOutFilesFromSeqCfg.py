filterOutSeq = (
    'C:\\Documents and Settings\\*\\NTUSER.DAT*',
    'C:\\Program Files\\ISS\\BlackICE\\log*.enc',
    'D:\\Documents and Settings\\*\\NTUSER.DAT*',
    )
