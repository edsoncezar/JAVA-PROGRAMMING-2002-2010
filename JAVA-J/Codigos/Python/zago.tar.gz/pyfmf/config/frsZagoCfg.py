# Configuration file.
#
# The configuration is entirely contained in a dictionary, 'configDict'.
# This dictionary has four members, with the keys 'description' (optional),
# 'topDirs', 'workDir' (optional), and 'handlersCfg'.
#
# The value associated with 'description' is a string with a short description
# of the configuration.  This entry is optional in configDict and defaults to
# an empty string.
#
# The value associated with 'topDirs' is a list of the roots of directory trees
# that are to be traversed and processed.
#
# The value associated with 'workDir' is the directory where all result files
# are located.  This entry is optional and if it is not specified in configDict
# or if the value is an empty string, the working directory is unchanged from
# the directory where the controller is invoked.
#
# The value associated with 'handlersCfg' is a list of tuples.  Each one of the
# tuples in this list is associated with a handler in the stack.  The order of
# the list follows the order of the stack, top-to-bottom, the first element in
# the list corresponding to the top of the stack and the last element of the
# list corresponding to the bottom of the stack.  Processing is done in reverse
# order, the bottom handler is the first one to process directories and files,
# the top handler is the last one processing.
#
# Each tuple in the list associated with 'handlersCfg' has 2 items.  The first
# item is the name of the module which contains the Handler.  The second item
# is a dictionary used to configure the Handler instance.  To understand what
# members are expected in the dictionary for each Handler class, look at the
# unbound member _metaCfg of that class; it is a tuple of 'metaCfgCls' (a class
# nested in class baseClass.Handler) objects, each object describing a member
# of the dictionary.  These objects have three attributes: 'label', 'desc',
# and 'typ'.  'label' represents the key used in the configuration dictionary,
# 'desc' represents the description of the value, and 'typ' represents the
# type of the value ('string', 'bool', or 'sequence').  A 'sequence' value can
# be either a tuple or a list.
#
# Example of a 'metaCfgCls' object:
#    metaC = baseClass.Handler.metaCfgCls(
#	    label='name'
#	    description='Optional, unused.  Identifies a handler in the stack.'
#	    typ='string')
# In configDict, this object may be represented by an entry:
#    'name': 'fodSeqP'

__description__ = 'Creates tar file for realease of zago'

# Structure of the handler stack in this configuration:
#	procTarFiles
#	viewFilesPlain
#	filterFilesBasename
#	filterDirsPath
#	filterDirsBasename

import os
if '__main__' == __name__:
    if hasattr(sys, "frozen") or \
    hasattr(sys, "importers") or \
    imp.is_frozen("__main__"):
        pathGoingUp = sys.executable
    else:
        pathGoingUp = sys.argv[0]
else:
    pathGoingUp = __file__
# Calculate the installation dir as '..'
pathGoingUp = os.path.dirname(os.path.abspath(pathGoingUp))
for level in range(1):
    pathGoingUp = os.path.split(pathGoingUp)[0]
installDir = os.path.abspath(pathGoingUp)

configDict = \
{'description': 'Creates tar file for realease of zago',
 'handlersCfg': [('procTarFiles', {'file name': 'zago.tar.gz', 'name': ''}),
                 ('viewFilesPlain', {'enabled': True, 'name': ''}),
                 ('filterFilesBasename',
                  {'filter in': True,
                   'name': '',
                   'pattern sequence': ['*.py',
                                        '*.tar',
                                        '*.html',
                                        '*.css',
                                        '*.txt']}),
                 ('filterDirsPath',
                  {'filter in': False,
                   'name': '',
                   'pattern sequence': ['zigzag\\tests\\modified',
                                        'zigzag\\tests\\orig']}),
                 ('filterDirsBasename',
                  {'filter in': False,
                   'name': '',
                   'pattern sequence': ['CVS']})],
 'topDirs': [installDir],
 'workDir': os.path.join(installDir, 'work')}
