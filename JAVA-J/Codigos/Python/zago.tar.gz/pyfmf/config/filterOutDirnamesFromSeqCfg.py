filterOutSeq = (
    'CVS',
    )
