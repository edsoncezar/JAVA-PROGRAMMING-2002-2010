#!/usr/bin/env python
"""Configuration of the handler stack and of each handler.

The configuration is entirely contained in a dictionary, 'configDict'.
This dictionary has four members, with the keys 'description' (optional),
'topDirs', 'workDir' (optional), and 'handlersCfg'.

The value associated with 'description' is a string with a short description
of the configuration.  This entry is optional in configDict and defaults to
an empty string.

The value associated with 'topDirs' is a list of the roots of directory trees
that are to be traversed and processed.

The value associated with 'workDir' is the directory where all result files
are located.  This entry is optional and if it is not specified in configDict
or if the value is an empty string, the working directory is unchanged from
the directory where the controller is invoked.

The value associated with 'handlersCfg' is a list of tuples.  Each one of the
tuples in this list is associated with a handler in the stack.  The order of
the list follows the order of the stack, top-to-bottom, the first element in
the list corresponding to the top of the stack and the last element of the
list corresponding to the bottom of the stack.  Processing is done in reverse
order, the bottom handler is the first one to process directories and files,
the top handler is the last one processing.

Each tuple in the list associated with 'handlersCfg' has 2 items.  The first
item is the name of the module which contains the Handler.  The second item
is a dictionary used to configure the Handler instance.  To understand what
members are expected in the dictionary for each Handler class, look at the
unbound member _metaCfg of that class; it is a tuple of 'metaCfgCls' (a class
nested in class baseClass.Handler) objects, each object describing a member
of the dictionary.  These objects have three attributes: 'label', 'desc',
and 'typ'.  'label' represents the key used in the configuration dictionary,
'desc' represents the description of the value, and 'typ' represents the
type of the value ('string', 'bool', or 'sequence').  A 'sequence' value can
be either a tuple or a list.

Example of a 'metaCfgCls' object::
    metaC = baseClass.Handler.metaCfgCls(
        label='name'
        description='Optional, unused.  Identifies a handler in the stack.'
        typ='string')
In configDict, this object may be represented by an entry::
   'name': 'fodSeqP'

"""

__author__ = "Dan Perl <danperl@users.sourceforge.net>"
__description__ = "Compare trees to persistent structure and save new " \
"persistent structure"

import os
import sys

if '__main__' == __name__:
    if hasattr(sys, "frozen") or \
       hasattr(sys, "importers") or \
       imp.is_frozen("__main__"):
        path = sys.executable
    else:
        path = sys.argv[0]
else:
    path = __file__
cfgDir = os.path.dirname(os.path.abspath(path))
if not (cfgDir in sys.path):
    sys.path.insert(0, cfgDir)

# Configuration of the handler stack
handlersConfigNames = ('logAll',
                   'procFromDict',
                   'procBuildDict',
                   'filterOutFilesFromSeq',
                   #'filterOutFilenamesFromSeq',
                   #'tarFiles',
                   #'filterInFilenamesFromSeq',
                   #'filterOutDirnamesFromSeq',
                   'filterDirsPath'
                   )

# Configuration of each handler.
handlersConfig = {}

handlersConfig['logAll'] = {
    'name':'wFileP',
    'file name':'logEverything'}

handlersConfig['logFilesOnly'] = {
    'name':'lFilesP',
    'file name':'logOfFiles'}

handlersConfig['removeFiles'] = {
    'name':'remFilesP'}

handlersConfig['procBuildDict'] = {
    'name':'bDictP',
    'persistence file':'persistentDict'}

handlersConfig['procFromDict'] = {
    'name':'fDictP',
    'persistence file':'persistentDict',
    'log file':'listOfChanges'}

from filterDirsPathCfg import filterOutSeq
handlersConfig['filterDirsPath'] = {
    'name':'fodSeqP',
    'pattern sequence':filterOutSeq,
    'filter in':False}

from filterOutFilesFromSeqCfg import filterOutSeq
handlersConfig['filterOutFilesFromSeq'] = {
    'name':'fofSeqP',
    'pattern sequence':filterOutSeq}

from filterOutFilenamesFromSeqCfg import filterOutSeq
handlersConfig['filterOutFilenamesFromSeq'] = {
    'name':'fofnSeqP',
    'pattern sequence':filterOutSeq}

from filterOutDirnamesFromSeqCfg import filterOutSeq
handlersConfig['filterOutDirnamesFromSeq'] = {
    'name':'fodnSeqP',
    'pattern sequence':filterOutSeq}

from filterInFilenamesFromSeqCfg import filterInSeq
handlersConfig['filterInFilenamesFromSeq'] = {
    'name':'fifnSeqP',
    'pattern sequence':filterInSeq}

handlersConfig['tarFiles'] = {
    'name':'tFileP',
    'file name':'pyfmf.tar.gz'}

rootList = [
    'C:\\',
    'D:\\',
    'E:\\',
    'F:\\'
    ]

configDict = { }
configDict['topDirs'] = rootList
handlerCfgList = [ ]
for hName in handlersConfigNames:
    handlerCfgList.append((hName, handlersConfig[hName]))
configDict['handlersCfg'] = handlerCfgList

# Calculate workDir as '../work'
dirPath = os.path.dirname(os.path.abspath(__file__))
pathGoingUp = dirPath
for i in range(1):
    pathGoingUp = os.path.split(pathGoingUp)[0]
workDir = os.path.join(pathGoingUp, 'work')
configDict['workDir'] = workDir
if not os.path.exists(workDir):
    os.mkdir(workDir)

configDict['description'] = __description__
