filterInSeq = (
    '*.exe',
    '*.dll',
    '*.jar',
    '*.class',
    '*.so'
    )
