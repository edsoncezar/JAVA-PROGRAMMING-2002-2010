# Configuration file.
#
# The configuration is entirely contained in a dictionary, 'configDict'.
# This dictionary has four members, with the keys 'description' (optional),
# 'topDirs', 'workDir' (optional), and 'handlersCfg'.
#
# The value associated with 'description' is a string with a short description
# of the configuration.  This entry is optional in configDict and defaults to
# an empty string.
#
# The value associated with 'topDirs' is a list of the roots of directory trees
# that are to be traversed and processed.
#
# The value associated with 'workDir' is the directory where all result files
# are located.  This entry is optional and if it is not specified in configDict
# or if the value is an empty string, the working directory is unchanged from
# the directory where the controller is invoked.
#
# The value associated with 'handlersCfg' is a list of tuples.  Each one of the
# tuples in this list is associated with a handler in the stack.  The order of
# the list follows the order of the stack, top-to-bottom, the first element in
# the list corresponding to the top of the stack and the last element of the
# list corresponding to the bottom of the stack.  Processing is done in reverse
# order, the bottom handler is the first one to process directories and files,
# the top handler is the last one processing.
#
# Each tuple in the list associated with 'handlersCfg' has 2 items.  The first
# item is the name of the module which contains the Handler.  The second item
# is a dictionary used to configure the Handler instance.  To understand what
# members are expected in the dictionary for each Handler class, look at the
# unbound member _metaCfg of that class; it is a tuple of 'metaCfgCls' (a class
# nested in class baseClass.Handler) objects, each object describing a member
# of the dictionary.  These objects have three attributes: 'label', 'desc',
# and 'typ'.  'label' represents the key used in the configuration dictionary,
# 'desc' represents the description of the value, and 'typ' represents the
# type of the value ('string', 'bool', or 'sequence').  A 'sequence' value can
# be either a tuple or a list.
#
# Example of a 'metaCfgCls' object:
#    metaC = baseClass.Handler.metaCfgCls(
#	    label='name'
#	    description='Optional, unused.  Identifies a handler in the stack.'
#	    typ='string')
# In configDict, this object may be represented by an entry:
#    'name': 'fodSeqP'

__description__ = 'Example of generated configuration file'

# Structure of the handler stack in this configuration:
#	logAll
#	procFromDict
#	procBuildDict
#	filterOutFilesFromSeq
#	filterDirsPath

configDict = \
{'description': 'Compare trees to persistent structure and save new persistent structure',
 'handlersCfg': [('logAll', {'file name': 'logEverything', 'name': 'wFileP'}),
                 ('procFromDict',
                  {'log file': 'listOfChanges',
                   'name': 'fDictP',
                   'persistence file': 'persistentDict'}),
                 ('procBuildDict',
                  {'persistence file': 'persistentDict', 'name': 'bDictP'}),
                 ('filterOutFilesFromSeq',
                  {'name': 'fofSeqP',
                   'pattern sequence': ('C:\\Documents and Settings\\*\\NTUSER.DAT*',
                                        'C:\\Program Files\\ISS\\BlackICE\\log*.enc',
                                        'D:\\Documents and Settings\\*\\NTUSER.DAT*')}),
                 ('filterDirsPath',
                  {'filter in': False,
                   'in or out': False,
                   'name': 'fodSeqP',
                   'pattern sequence': ['C:\\Documents and Settings\\*\\Application Data\\Microsoft\\Office\\Recent',
                                        'C:\\Documents and Settings\\*\\Application Data\\Mozilla\\Firefox\\Profiles',
                                        'C:\\Documents and Settings\\*\\Local Settings\\History\\History.IE5',
                                        'C:\\Documents and Settings\\*\\Local Settings\\Temp\\bak',
                                        'C:\\Documents and Settings\\*\\Recent',
                                        'C:\\RECYCLER',
                                        'C:\\WINDOWS\\Internet Logs',
                                        'C:\\WINDOWS\\PCHEALTH\\HELPCTR\\DataColl',
                                        'C:\\WINDOWS\\Prefetch',
                                        'C:\\WINDOWS\\system32\\config\\systemprofile\\Local Settings\\Temporary Internet Files',
                                        'D:\\RECYCLER',
                                        'E:\\Application Data\\Maven\\contentFiles',
                                        'E:\\RECYCLER',
                                        'F:\\Documents and Settings\\Dan Perl\\Local Settings\\Temporary Internet Files',
                                        'F:\\Documents and Settings\\Dan Perl\\Local Settings\\Application Data\\Identities',
                                        'F:\\_Restore',
                                        'F:\\RECYCLER',
                                        'F:\\Temp',
                                        'F:\\Recycled',
                                        'F:\\RECENT',
                                        'F:\\Coding',
                                        'F:\\Program Files\\Netscape\\Cache',
                                        'F:\\Temp']})],
 'topDirs': ['C:\\', 'D:\\', 'E:\\', 'F:\\'],
 'workDir': 'F:\\Coding\\sourceforge\\src\\zigzag\\work'}
