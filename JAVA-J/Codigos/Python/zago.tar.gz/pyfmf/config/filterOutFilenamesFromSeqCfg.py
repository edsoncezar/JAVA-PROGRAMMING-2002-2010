filterOutSeq = (
    '*.jpg',
    '*.html',
    '*.htm',
    '*.gif',
    )
