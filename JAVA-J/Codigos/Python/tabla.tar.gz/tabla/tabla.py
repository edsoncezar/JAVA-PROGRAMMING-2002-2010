#!/usr/bin/env python
#

####
# Copyright (C) 1999 cWare, Inc.
#
# This source is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation, version 2.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You can retrieve a copy of the GNU General Public License
# from http://www.gnu.org
#
# cWare, Inc. can be reached electronically via 
# http://www.cwareco.com/
####

import string
import time
import whrandom
import re
import cgi
import sys
import os
import glob
import posix
import posixpath
from crypt import *

startRecord = 0
inRecord = 1
gotRecord = 2
doSave = 0
namesep = "/"
startCol = 1
displayNumberOfCols = 3
nameOfFile = ""
fTableTitle = ""
fTablePasswd = ""
fTitleColor = ""
tableTitle = ""
tablePasswd = ""
tableFiles = {}
titleColor = "#ff0000"
tablesDirectoryPrefix = "/tmp/"
tablesDirectory = ""
tableExt = ".tab"
tableHTMLExt = ".html"
scriptLocation = "/cgi-bin/tabla.py"
defaultCols4NewTable = 3
defaultRows4NewTable = 6
totColSize = 81

def checkpwd (inpasswd):
  if crypt(inpasswd, tablePasswd[0:2]) == tablePasswd:
    return 1
  else:
    return 0

class rcounter:
  def __init__(self, n=1):
    self.n = n

class node:
  def __init__(self, name=""):
    self.name = name
    self.object = {"fullname":""}
    self.parent = None
    self.next = None
    self.first_child = None
    self.last_child = None
  def __repr__(self):
    return "name="+self.name+"\n"

TOP = node("_top_")

def find(t, name):
  if (t == None) or (t.name == name):
    return t
  ret = find(t.first_child, name)  
  if ret == None:
    ret = find(t.next, name)
  return ret

def findFull(t, fullname):
  #if t: print "t=", t.object['fullname'], " fullname=",fullname
  if (t == None) or (t.object == None):
    return None
  if t.object['fullname'] == fullname:
    return t
  ret = findFull(t.first_child, fullname)  
  if ret == None:
    ret = findFull(t.next, fullname)
  return ret

def insert(fullname, object):
  path = re.split(namesep, fullname)
  #print "path=", path
  l = len(path)
  r = TOP
  for n in range(l):
    prev_r = r
    seg = path[l - n - 1]
    r = find(prev_r, seg)
    #print "after find, r=", r, ", prev_r=", prev_r
    if r == None:
      if prev_r == None:
        #print "r & prev_r null, allocating node for seg=", seg
        r = node(seg)
      else:
        #print "prev_r ~null, allocating node for seg=", seg
        r = node(seg)
        lc = prev_r.last_child
        if lc == None:
          prev_r.first_child = r
        else:
          lc.next = r
        prev_r.last_child = r
        r.parent = prev_r
  r.object = object

def writeTree(r, f, colNum=rcounter(0), rowNum=rcounter(0)):
  if (r == None):
    return
  if (r.name != "***"):
    if (r.object['type'] == "column"):
      f.write("\n")
      rowNum.n = 0
      colNum.n = colNum.n + 1
      name = "col%d"%colNum.n
    else:
      rowNum.n = rowNum.n + 1
      name = "r%d"%rowNum.n
    if r.object.has_key(r.name): 
      value = r.object[r.name]
    else:
      value = "-"
    f.write(name+":\t"+value+"\n")
  writeTree(r.first_child, f, colNum, rowNum)  
  writeTree(r.next, f, colNum, rowNum),
  return

def invertFormTable(t):
  columns = countColumns(TOP.first_child)
  colWidth = totColSize/columns
  if colWidth < 20:
    colWidth = 20
  i = 0
  endCol = startCol + displayNumberOfCols
  t_in = t
  row_placeholder = {}
  while (t):
    i = i + 1
    if (i < startCol):
      t = t.next
      continue
    elif (i > endCol):
      break
    row_placeholder[t] = t.first_child
    t = t.next
  i = 0
  t = t_in
  while (t):
    i = i + 1
    if (i < startCol):
      t = t.next
      if (t == None):
        print "</tr>"
        break
      continue
    elif (i > endCol):
      print "</tr>"
      i = 0
      t = t_in
      continue
    r = row_placeholder[t]
    if (i == startCol):
      print "<tr>"
      print "<td align=center><input type=radio name='"+r.name+"' value='Delete_Row'><img src='javascript:x_xbm' width=7 height=14 alt='Delete Row'>"+"<input type=radio name='"+r.name+"' value='Above_Row'><img src='javascript:above_xbm' width=14 height=7 alt='Add Row Above'>"+ "<input type=radio name='"+r.name+"' value='Below_Row'><img src='javascript:below_xbm' width=14 height=7 alt='Add Row Below'></td>"
    #print "row="+r.name+"("+r.object[r.name]+"), col="+t.name
    print "<td><input type=text maxlength=80 name=\""+t.object['fullname']+r.name+"\" value=\""+r.object[r.name]+"\" size=%d"%colWidth+" onBlur='dirty=true'></td>"
    row_placeholder[t] = r.next
    if (r.next == None and (t.next == None or (endCol < i + 1))):
      print "</tr>"
      break
    t = t.next
    if (t == None):
      print "</tr>"
      i = 0
      t = t_in

def deleteRow(t, key):
  t_in = t
  row_placeholder = {}
  while (t):
    row_placeholder[t] = t.first_child
    t = t.next
  t = t_in
  while (t):
    r = row_placeholder[t]
    if (r.name == key):
      r.name = "***"
    row_placeholder[t] = r.next
    if (t.next == None):
      if (r.next == None):
        break
      t = t_in
    else:
      t = t.next

def addRowBelow(t, key):
  t_in = t
  new_r = None
  row_placeholder = {}
  rowNum = 1
  while (t):
    row_placeholder[t] = t.first_child
    t = t.next
  t = t_in
  while (t):
    r = row_placeholder[t]
    if r == None:
      t = t.next
      continue
    #print "<h4>addRowBelow, checking col=",t.name,",looking for row=",key,"r.name=",r.name,"</h4>"
    if (r.name == key) or (t.name[:4] == "tmp_" and r.name == "tmp_"+key):
      #print "<h4>addRowBelow, found row=",r,"in column=",t,"</h4>"
      new_r = node("tmp_r%d"%rowNum)
      new_r.object['type'] = "row"
      tmp_r = r.next
      r.next = new_r
      r.next.next = tmp_r
      row_placeholder[t] = None
      t = t.next
    else:
      row_placeholder[t] = r.next
      t = t.next
      if (t == None) and (r.next != None):
        rowNum = rowNum + 1
        t = t_in

def addRowAbove(t, key):
  t_in = t
  new_r = None
  prev_r = None
  tmp_r = None
  descend = 1
  foundrow = 0
  prevrow_placeholder = {}
  row_placeholder = {}
  rowNum = 1
  while (t):
    if (t.first_child == None):
      new_r = node("tmp_r1")
      new_r.object['type'] = "row"
      t.first_child = new_r
      t.last_child = new_r
      descend = 0
    elif ((t.first_child.name == key) or (t.name[:4] == "tmp_" and t.first_child.name == "tmp_"+key)):
      new_r = node("tmp_r1")
      new_r.object['type'] = "row"
      tmp_r = t.first_child
      t.first_child = new_r
      t.first_child.next = tmp_r
      descend = 0
    prevrow_placeholder[t] = t.first_child
    row_placeholder[t] = t.first_child.next
    t = t.next
  if (descend):
    t = t_in
    while (t):
      r = row_placeholder[t]
      if r == None:
        t = t.next
        continue
      #print "<h4>addRowAbove, checking col=",t.name,",looking for row=",key,"r.name=",r.name,"</h4>"
      if (r.name == key) or (t.name[:4] == "tmp_" and r.name == "tmp_"+key):
        #print "<h4>addRowAbove, found row=",r,"</h4>"
        prev_r = prevrow_placeholder[t]
        new_r = node("tmp_r%d"%rowNum)
        rowNum = rowNum + 1
        new_r.object['type'] = "row"
        prev_r.next = new_r
        prev_r.next.next = r
        row_placeholder[t] = None
        t = t.next
        continue
      prevrow_placeholder[t] = r
      row_placeholder[t] = r.next
      if (t.next == None):
        if (r.next == None):
          break
        t = t_in
      else:
        t = t.next

def addColAfter(t, key):
  t_in = t
  new_t = None
  new_r = None
  prev_r = None
  colNum = 1
  rowCount = 0
  ref_row = t_in.first_child
  while ref_row:
    #if ref_row.name[:4] != "tmp_":
    rowCount = rowCount + 1
    ref_row = ref_row.next
  while (t):
    #print "addColAfter, checking col=",t.name,",looking for col=",key
    if (t.name == key):
      #print "<h4>addColAfter, found col=",t,"</h4>"
      new_t = node("tmp_col%d"%colNum)
      new_t.object['type'] = "column"
      tmp_t = t.next
      t.next = new_t
      t.next.next = tmp_t
      if (tmp_t == None):
        TOP.last_child = new_t 
      break
    colNum = colNum + 1
    t = t.next
  if (new_t != None):
    new_r = node("tmp_r1")
    #print "<h4>addColAfter, adding row=",new_r,"</h4>"
    new_r.object['type'] = "row"
    new_t.first_child = new_r
    prev_r = new_r
    for i in (range(rowCount+1))[2:]:
      new_r = node("tmp_r%d"%i)
      #print "<h4>addColAfter, adding row=",new_r,"</h4>"
      new_r.object['type'] = "row"
      prev_r.next = new_r
      prev_r = new_r
    new_t.last_child = new_r

def addColBefore(t, key):
  t_in = t
  new_t = None
  new_r = None
  tmp_t = None
  colNum = 1
  rowCount = 0
  ref_row = t_in.first_child
  while ref_row:
    #if ref_row.name[:4] != "tmp_":
    rowCount = rowCount + 1
    ref_row = ref_row.next
  if (t == None):
    new_t = node("tmp_col%d"%colNum)
    new_t.object['type'] = "column"
    TOP.first_child = new_t
    TOP.last_child = new_t
  elif (t.name == key):
    new_t = node("tmp_col%d"%colNum)
    new_t.object['type'] = "column"
    tmp_t = TOP.first_child
    TOP.first_child = new_t
    new_t.next = tmp_t
  else:
    prev_t = t
    t = t.next
    colNum = colNum + 1
    while (t):
      #print "checking col=",t.name,",looking for col=",key
      if (t.name == key):
        #print "found col=",t
        new_t = node("tmp_col%d"%colNum)
        new_t.object['type'] = "column"
        prev_t.next = new_t
        prev_t.next.next = t
        break
      prev_t = t
      colNum = colNum + 1
      t = t.next
  if (new_t != None):
    new_r = node("tmp_r1")
    #print "<h4>addColBefore, adding node=tmp_r1</h4>"
    new_r.object['type'] = "row"
    new_t.first_child = new_r
    new_row = new_r
    for i in (range(rowCount+1))[2:]:
      #print "<h4>addColBefore, adding node="+("tmp_r%d"%i)+"</h4>"
      new_r = node("tmp_r%d"%i)
      new_r.object['type'] = "row"
      new_row.next = new_r
      new_row = new_row.next
    new_t.last_child = new_row

def deleteColumn(t, key):
  t_in = t
  row_placeholder = {}
  while (t):
    row_placeholder[t] = t.first_child
    t = t.next
  t = t_in
  while (t):
    r = row_placeholder[t]
    if (t.name == key):
      r.name = "***"
    row_placeholder[t] = r.next
    if (t.next == None):
      if (r.next == None):
        break
      t = t_in
    else:
      t = t.next
  t = t_in
  while (t):
    if (t.name == key):
      t.name = "***"
      break
    t = t.next

def printColorSelector(name, color):
  print "<table>"
  print "  <tr>"
  print "    <td>"
  print "      <input type=text maxlength=80 name=\""+name+"\" size=7 value="+color+" onBlur='dirty=true'>"
  print "    </td>"
  print "  </tr>"
  print "</table>"

def printButtonSemantics():
  print "<table>"
  print "  <tr>"
  print "    <td>"
  print "    <select name=ButtonSemantics size=1>"
  print "      <option>Del/Ins"
  print "      <option>Merge"
  print "      <option>Color"
  print "    </select>"
  print "    </td>"
  print "  </tr>"
  print "</table>"

def printFormHeaders(t):
  columns = countColumns(TOP.first_child)
  colWidth = totColSize/columns
  if colWidth < 20:
    colWidth = 20
  i = 0
  endCol = startCol + displayNumberOfCols
  if endCol > columns:
    endCol = columns
  t_in = t
  print "<tr><td>"
  printColorSelector("TitleColor1",titleColor)
#  print "&nbsp;"
  print "</td>"
  print "<td align=center colspan=",columns," bgcolor=\""+titleColor+"\"><font color=\"#ffffff\" size=4><input type=text maxlength=80 name=Title1 value=\""+tableTitle+"\" size=60 onBlur='dirty=true'></font></td>"
  print "</tr>"
  print "<tr><td>"
#  printButtonSemantics()
  print "&nbsp;"
  print "</td>"
  while (t):
    i = i + 1
    if (i < startCol):
      t = t.next
      continue
    elif (i > endCol):
      break
    print "<td align=center><input type=radio name=\""+t.name+"\" value=\"Delete_Column\"><img src=\"javascript:x_xbm\" width=7 height=14 alt=\"Delete Column\"> "
    print "<input type=radio name=\""+t.name+"\" value=\"Before_Column\"><img src=\"javascript:before_xbm\" width=7 height=14 alt=\"Add Column Before\"> "
    print "<input type=radio name=\""+t.name+"\" value=\"After_Column\"><img src=\"javascript:after_xbm\" width=7 height=14 alt=\"Add Column After\"></td>"
    t = t.next
  print "</tr>\n<tr><td><font size=-1><b>&nbsp;cols",startCol,"-",endCol,"of",columns,"</b></font></td>"
  i = 0
  t = t_in
  while (t):
    i = i + 1
    if (i < startCol):
      t = t.next
      continue
    elif (i > endCol):
      i = 0
      t = t_in
      break
    print "<td><font size=2><input type=text maxlength=80 name=\"text_"+t.name+"\" value=\""+t.object[t.name]+"\" size=%d"%colWidth+" onBlur='dirty=true'></font></td>"
    t = t.next
  print "</tr>"
  print "<tr><td>&nbsp</td></tr>"

def invertTable(t):
  t_in = t
  row_placeholder = {}
  shade = 0
  while (t):
    row_placeholder[t] = t.first_child
    t = t.next
  t = t_in
  while (t):
    r = row_placeholder[t]
    if (t == t_in):
      if shade:
        print "<tr bgcolor=#e0e0e0>"
      else:
        print "<tr>"
      shade = 1 - shade
    #print "row="+r.name+"("+r.object[r.name]+"), col="+t.name
    print "<td>"+r.object[r.name]+"</td>"
    row_placeholder[t] = r.next
    if (r.next == None and t.next == None):
      print "</tr>"
      break
    t = t.next
    if (t == None):
      print "</tr>"
      t = t_in

def printHeaders(t):
  print "<tr>"
  while (t):
    print "<th><font size=2>"+t.object[t.name]+"</font></th>"
    t = t.next
  print "</tr>"

def invertHTMLTable(fout, t):
  t_in = t
  row_placeholder = {}
  shade = 0
  while (t):
    row_placeholder[t] = t.first_child
    t = t.next
  t = t_in
  while (t):
    r = row_placeholder[t]
    if (t == t_in):
      if shade:
        fout.write("<tr bgcolor=#e0e0e0>")
      else:
        fout.write("<tr>")
      shade = 1 - shade
    #fout.write("row="+r.name+"("+r.object[r.name]+"), col="+t.name)
    fout.write("<td>"+r.object[r.name]+"</td>")
    row_placeholder[t] = r.next
    if (r.next == None and t.next == None):
      fout.write("</tr>")
      break
    t = t.next
    if (t == None):
      fout.write("</tr>")
      t = t_in

def printHTMLHeaders(fout, t):
  fout.write("<tr>")
  while (t):
    fout.write("<th><font size=2>"+t.object[t.name]+"</font></th>")
    t = t.next
  fout.write("</tr>")

def countColumns(t):
  i = 0
  while (t):
    i = i + 1
    t = t.next
  return i

def showTable1(type, fullname, action):
  columns = countColumns(TOP.first_child)
  print "<html>"
  print "<head>"
  print "<title>"+tableTitle+"</title>"
  print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">"
  print "</head>"
  print "<body bgcolor=\"#FFFFFF\">"
  print "<table border=1 cellspacing=0 cellpadding=0 >"
  print "<tr><td>"
  print "<table border=1 cellspacing=0 cellpadding=0>"
  print "<tr>"
  print "<td align=center colspan=",columns," bgcolor=\""+titleColor+"\"><font color=\"#ffffff\" size=4>"+tableTitle+"</font></td>"
  print "</tr>"
  printHeaders(TOP.first_child)
  invertTable(TOP.first_child)
  print "</table>"
  print "</table>"
  print "</body>"
  print "</html>"

def showForm1(type, fullname, action):
  columns = countColumns(TOP.first_child)
  print "<html>"
  print "<head>"
  print "<title>TABLA</title>"
  print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">"
  print "<script>"
  print "x_xbm ="
  print "  '#define x_width 7\\n'+"
  print "  '#define x_height 14\\n'+"
  print "  'static char x_bits[] = {\\n'+"
  print "  ' 0x41,0x63,0x63,0x36,0x14,0x14,0x08,0x08,0x14,0x14,0x36,0x63,0x63,0x41,};\\n';"
  print "above_xbm ="
  print "  '#define above_width 14\\n'+"
  print "  '#define above_height 7\\n'+"
  print "  'static char above_bits[] = {\\n'+"
  print "  ' 0x40,0x00,0xe0,0x00,0xf0,0x01,0xf8,0x03,0xfc,0x07,0xfe,0x0f,0xff,0x1f,};\\n';"
  print "after_xbm ="
  print "  '#define after_width 7\\n'+"
  print "  '#define after_height 14\\n'+"
  print "  'static char after_bits[] = {\\n'+"
  print "  ' 0x01,0x03,0x07,0x0f,0x1f,0x3f,0x7f,0x3f,0x1f,0x0f,0x07,0x03,0x01,0x00,};\\n';"
  print "before_xbm ="
  print "  '#define before_width 7\\n'+"
  print "  '#define before_height 14\\n'+"
  print "  'static char before_bits[] = {\\n'+"
  print "  ' 0x40,0x60,0x70,0x78,0x7c,0x7e,0x7f,0x7e,0x7c,0x78,0x70,0x60,0x40,0x00,};\\n';"
  print "below_xbm ="
  print "  '#define below_width 14\\n'+"
  print "  '#define below_height 7\\n'+"
  print "  'static char below_bits[] = {\\n'+"
  print "  ' 0xff,0x1f,0xfe,0x0f,0xfc,0x07,0xf8,0x03,0xf0,0x01,0xe0,0x00,0x40,0x00,};\\n';"
  print "need_passwd = false;"
  print "dirty = false;"
  print "function check_passwd() {"
  print "  if (need_passwd && dirty) {"
  print "      need_passwd = false;"
  print "      if (document.UpdateForm.passwd_program.value == '') {"
  print "        alert('Enter password and resubmit');"
  print "        return false;"
  print "      }"
  print "      dirty = false;"
  print "  }"
  print "  return true;"
  print "}"
  print "</script>"
  print "</head>"
  print "<body bgcolor=\"#FFFFFF\">"
  print "<form name=UpdateForm method=POST onSubmit=\"return check_passwd()\">"
  print "<input type=hidden name=StartCol value="+("%d"%startCol)+">"
  print "<input type=hidden name=NumberOfCols value="+("%d"%displayNumberOfCols)+">"
  print "<input type=hidden name=NameOfFile value=\""+nameOfFile+"\">"
  print "<table border=1 cellspacing=0 cellpadding=0>"
  print "<tr><td align=left>"
  print "<font size=5><b>TABLA (current file: </b>"
  print "<i>"+nameOfFile+"</i><b>)</b></font>"
  print "</td>"
  print "<td align=right>"
  print "<b>Password:</b><input type=password name=\"passwd_program\" size=10 maxsize=10 value=\"\">"
  print "</td>"
  print "<tr><td align=left>"
  print "<table border=0 cellspacing=2 cellpadding=2><tr>"
  print "<td><input type=submit name=Open value=Open></td>"
  print "<td><input type=submit name=Save value=Save onClick='need_passwd=true'</td>"
  print "<td><input type=submit name=SaveAsHTML value='Save as HTML' onClick='need_passwd=true'></td>"
  print "<td><input type=submit name=View value=View></td>"
  print "<td><input type=submit name=Refresh value=Refresh></td>"
  print "<td><input type=reset></td></tr></table></td>"
  print "<td align=right>"
  print "<table border=0 cellspacing=2 cellpadding=2><tr>"
  print "<td><input type=submit name=\"<<Prev\" value=\"<<Prev\" onClick='need_passwd=true'></td>"
  print "<td><input type=submit name=Prev value=Prev onClick='need_passwd=true'></td>"
  print "<td><input type=submit name=Next value=Next onClick='need_passwd=true'></td>"
  print "<td><input type=submit name=\"Next>>\" value=\"Next>>\" onClick='need_passwd=true'></td></tr></table>"
  print "</td></tr>"
  print "<tr><td colspan=2>"
  print "<table border=0 cellspacing=0 cellpadding=0>"
  printFormHeaders(TOP.first_child)
  invertFormTable(TOP.first_child)
  print "</table>"
  print "</table>"
  print "</form>"
  print "</body>"
  print "</html>"

def scrollTable(form, keys, direction, start, howmuch):
    global startCol, nameOfFile
    print "Content-type: text/html\n"
    columns = countColumns(TOP.first_child)
    dirty = saveContent(form, keys)
    if (dirty):
      if form.has_key("passwd_program") and checkpwd(form["passwd_program"].value):
        #print "<h2>Saving table ("+nameOfFile+")</h2>"
        writeFile(nameOfFile)
        getContent(nameOfFile)
      else:
        print "<h2>Enter valid password</h2>"
    startCol = start + (howmuch * direction)
    if (startCol > columns - displayNumberOfCols):
      startCol = columns - displayNumberOfCols
    if (startCol < 1):
      startCol = 1
    showForm1("","",scriptLocation)

def getContent(fname):
  global TOP, tableTitle, tablePasswd, titleColor
  global fTableTitle, fTablePasswd, fTitleColor
  fn = tablesDirectory+fname+tableExt
  TOP = node("_top_")
  TOP.object['type'] = ""
  recordState = 0
  f = open(fn, "r")
  for line in f.readlines():
    m = re.match(r"^\s*#", line)
    if m == None:
      m = re.match(r"title1:\s*(.*)", line)
      if m != None:
        tableTitle = m.group(1)
        fTableTitle = tableTitle
        continue
      m = re.match(r"passwd:\s*(.*)", line)
      if m != None:
        tablePasswd = m.group(1)
        fTablePasswd = tablePasswd
        continue
      m = re.match(r"color1:\s*(.*)", line)
      if m != None:
        titleColor = m.group(1)
        fTitleColor = titleColor
        continue
      m = re.match(r"(.*?):\s*(.*)", line)
      if m != None:
        r = {}
        if recordState == startRecord:
          recordState = inRecord
          r['type'] = "column"
          fullname = m.group(1)
          r['fullname'] = fullname 
          r[m.group(1)] = m.group(2)
          insert(r['fullname'], r)
        else:
          r[m.group(1)] = m.group(2)
          r['type'] = "row"
          r['fullname'] = m.group(1)+namesep+fullname
          insert(r['fullname'], r)
        continue
      m = re.match(r"^$", line)
      if m != None:
        recordState = startRecord
  f.close()

def getContentDefault():
  global TOP, tableTitle, tablePasswd, titleColor
  global fTableTitle, fTablePasswd, fTitleColor
  TOP = node("_top_")
  TOP.object['type'] = ""
  recordState = 0
  tableTitle = "Your Table"
  fTableTitle = tableTitle
  fTablePasswd = tablePasswd
  titleColor = "blue"
  fTitleColor = titleColor
  for col in range(defaultCols4NewTable+1)[1:]:
    r = {}
    r['type'] = "column"
    colname = "col%s"%col
    r['fullname'] = colname 
    r[colname] = "Col#%s Name"%col #col title
    insert(colname, r)
    for row in range(defaultRows4NewTable+1)[1:]:
      r = {}
      r['type'] = "row"
      r['r%s'%row] = "R%s C%s"%(row,col) #cell data
      rowname = "r%s"%row
      cellname = rowname+namesep+colname
      r['fullname'] = cellname
      insert(cellname, r)

def saveContent(form, keys):
  global fTableTitle, fTablePasswd, fTitleColor
  dirty = 0
  if form.has_key("Title1"):
    if fTableTitle != form['Title1'].value:
      #print "<h3>Change in Title1, new value="+form['Title1'].value+", old value="+fTableTitle+"</h3>"
      dirty = 1
      fTableTitle = form['Title1'].value
#    else:
#      print "<h3>No change in Title1</h3>"
  if form.has_key("TitleColor1"):
    if fTitleColor != form['TitleColor1'].value:
      #print "<h3>Change in TitleColor1, new value="+form['TitleColor1'].value+", old value="+fTitleColor+"</h3>"
      dirty = 1
      fTitleColor = form['TitleColor1'].value
#    else:
#      print "<h3>No change in TitleColor1</h3>"

  for key in keys:
    #print "<h2>Checking key "+key+"</h2>"
    fullname = ""
    shortname = ""
    m = re.match(r"(col\d*)(r\d*)", key)
    if m != None:
      fullname = m.group(2)+namesep+m.group(1)
      shortname = m.group(2)
    m = re.match(r"text_(col\d*)", key)
    if m != None:
      fullname = m.group(1)
      shortname = m.group(1)
    if fullname != "":
      #print "<h2>Looking for "+fullname+"</h2>"
      t = findFull(TOP.first_child, fullname)
      if t.object.has_key(shortname):
        if t.object[shortname] != form[key].value:
          #print "<h4>Change in "+fullname+", new value="+form[key].value+", old value="+t.object[shortname]+"</h4>"
          dirty = 1
          t.object[shortname] = form[key].value
  return dirty

def writeFile(fname):
  fn = tablesDirectory+fname+tableExt
  f = open(fn, "w+")
  f.write("#date table created: "+time.ctime(time.time())+"\n")
  f.write("title1:\t"+tableTitle+"\n")
  f.write("passwd:\t"+tablePasswd+"\n")
  f.write("color1:\t"+titleColor+"\n")
  writeTree(TOP.first_child, f)
  f.close()

def writeFileAsHTML(fname):
  fn = tablesDirectory+fname+tableHTMLExt
  f = open(fn, "w+")
  columns = countColumns(TOP.first_child)
  f.write("<html>")
  f.write("<head>")
  f.write("<title>"+tableTitle+"</title>")
  f.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">")
  f.write("</head>")
  f.write("<body bgcolor=\"#FFFFFF\">")
  f.write("<table border=1 cellspacing=0 cellpadding=0 >")
  f.write("<tr><td>")
  f.write("<table border=1 cellspacing=0 cellpadding=0>")
  f.write("<tr>")
  f.write("<td align=center colspan=%d"%columns+" bgcolor=\""+titleColor+"\"><font color=\"#ffffff\" size=4>"+tableTitle+"</font></td>")
  f.write("</tr>")
  printHTMLHeaders(f, TOP.first_child)
  invertHTMLTable(f, TOP.first_child)
  f.write("</table>")
  f.write("</table>")
  f.write("</body>")
  f.write("</html>")
  f.close()

def getTitles(fname):
  global TOP, tableTitle, tableFiles
  f = open(fname, "r")
  for line in f.readlines():
    m = re.match(r"^\s*#", line)
    if m == None:
      m = re.match(r"title1:\s*(.*)", line)
      if m != None:
        tableTitle = m.group(1)
        break
  f.close()
  tableFiles[tableTitle] = [posixpath.splitext(posixpath.basename(fname))[0], tableTitle]

def openFileDialog(script):
  print "<html>"
  print "<head>"
  print "<title>TABLA</title>"
  print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">"
  print "<script>"
  print "function select_button(btn) {"
  print "  document.openFileForm.OpenFile.sel_status = 'No';"
  print "  document.openFileForm.NewFile.sel_status = 'No';"
  print "  document.openFileForm.CancelOpen.sel_status = 'No';"
  print "  btn.sel_status = 'Yes';"
  print "}"
  print "function check_filename() {"
  #print "  alert('check_filename, CancelOpen='+document.openFileForm.CancelOpen.sel_status+', NewFile='+document.openFileForm.NewFile.sel_status+' OpenFile='+document.openFileForm.OpenFile.sel_status);"
  print "  f1 = document.openFileForm.SpecifyFileName.value;"
  print "  if (document.openFileForm.CancelOpen.sel_status == 'Yes')"
  print "    return false;"
  print "  if (f1 == '') {"
  print "    f1 = prompt('Enter file name:','');"
  print "    if (f1 == null)"
  print "      f1 = '';"
  print "    document.openFileForm.SpecifyFileName.value = f1;"
  print "    if (f1 == '')"
  print "      return false;"
  print "  }"
  print "  if (document.openFileForm.NewFile.sel_status == 'Yes') {"
  print "    if (document.openFileForm.SpecifyPasswd.value == '') {"
  print "      alert('You must enter a password for a new table');"
  print "      return false;"
  print "    }"
  print "    return confirm('Do you wish to create '+f1+'?');"
  print "  }"
  print "  return true;"
  print "}"
  print "</script>"
  print "</head>"
  print "<body bgcolor=\"#FFFFFF\">"
  print "<center><h1>TABLA</h1></center>"
  print "<h2>Specify table to open:</h2>"
  print "<form name=openFileForm action="+script+" onSubmit='return check_filename()'>"
  #print "<form name=openFileForm action="+script+">"
  print "<table border=0 cellspacing=0 cellpadding=0>"
  print "<tr>"
  print "<td colspan=2>Enter file name:</td>"
  print "<td><input type=text size=40 maxlength=80 name=SpecifyFileName value='"+nameOfFile+"'></td>"
  print "</tr>"
  print "<tr>"
  print "<td colspan=2>Or choose table here:</td>"
  print "<td><select name=SelectFile size=1 onChange='document.openFileForm.SpecifyFileName.value=this.options[this.selectedIndex].value'>"
  list = glob.glob(tablesDirectory+"*.tab")
  for file in list:
    getTitles(file)
  K = tableFiles.keys()
  K.sort()
  for title in K:
    val = tableFiles[title]
    if val[0] == nameOfFile:
      print "<option value=\""+val[0]+"\" selected>"+val[1]+" ("+val[0]+")"
    else:
      print "<option value=\""+val[0]+"\">"+val[1]+" ("+val[0]+")"
  print "</select></td>"
  print "</tr>"
  print "<tr>"
  print "<tr>"
  print "<td colspan=2>Enter password for new table:&nbsp;</td>"
  print "<td><input type=text size=40 maxlength=80 name=SpecifyPasswd value=''></td>"
  print "</tr>"
  print "<td><input type=submit name=OpenFile value=Open onClick='select_button(this)'></td>"
  print "<td><input type=submit name=NewFile value=New onClick='select_button(this)'></td>"
  print "<td><input type=submit name=CancelOpen value=Cancel onClick='select_button(this)'></td>"
  print "</tr>"
  print "</table>"
  print "</form>"
  print "</body>"
  print "</html>"

if __name__ == '__main__':
  #print "Content-type: text/html\n"
  tablesDirectory = tablesDirectoryPrefix + os.environ['REMOTE_ADDR']
  if not posixpath.isdir(tablesDirectory):
    posix.mkdir(tablesDirectory)
  tablesDirectory = tablesDirectory + "/"
  form = cgi.FieldStorage()
  keys = form.keys()
  if form.has_key("NameOfFile"):
    nameOfFile = form['NameOfFile'].value
  if form.has_key("Save") or form.has_key("SaveAsHTML"):
    doSave = 1
  if nameOfFile == "":
    if form.has_key("OpenFile") and form.has_key("SpecifyFileName"):
      print "Content-type: text/html\n"
      nameOfFile = form['SpecifyFileName'].value
      if not posixpath.isfile(tablesDirectory+nameOfFile+tableExt):
        print "<h2>File does not exist, please select another name.</h2>"
        openFileDialog(scriptLocation)
      else:
        getContent(nameOfFile)
        showForm1("","",scriptLocation)
    elif form.has_key("NewFile") and form.has_key("SpecifyFileName"):
      print "Content-type: text/html\n"
      nameOfFile = form['SpecifyFileName'].value
      if posixpath.isfile(tablesDirectory+nameOfFile+tableExt):
        print "<h2>File exists, please select another name.</h2>"
        openFileDialog(scriptLocation)
      else:
        getContentDefault()
        domain = "01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ./"
        salt = domain[whrandom.choice(range(len(domain)))] + domain[whrandom.choice(range(len(domain)))]
        tablePasswd = crypt(form['SpecifyPasswd'].value,salt)
        writeFile(nameOfFile)
        showForm1("","",scriptLocation)
    else:
      print "Content-type: text/html\n"
      openFileDialog(scriptLocation)
    sys.exit(0)
  #print "Content-type: text/html\n"
  #cgi.print_environ()
  #sys.exit(0)
  getContent(nameOfFile)

  if form.has_key("Title1"):
    tableTitle = form['Title1'].value
  if form.has_key("TitleColor1"):
    titleColor = form['TitleColor1'].value

  if form.has_key("View"):
    print "Content-type: text/html\n"
    showTable1("","",scriptLocation)
  elif form.has_key("Refresh"):
    print "Content-type: text/html\n"
    getContent(nameOfFile)
    showForm1("","",scriptLocation)
  elif form.has_key("OpenFile") and form.has_key("SpecifyFileName"):
    print "Content-type: text/html\n"
    #for key in keys:
    #  print "<h2>key=",key,", value=",form[key].value,"</h2>"
    nameOfFile = form['SpecifyFileName'].value
    #print "<h1>Open File="+nameOfFile+"<h1>"
    getContent(nameOfFile)
    showForm1("","",scriptLocation)
  elif form.has_key("Open"):
    print "Content-type: text/html\n"
    #print "<h1>Open...<h1>"
    openFileDialog(scriptLocation)
  elif form.has_key("Prev"):
    scrollTable(form, keys, -1,string.atoi(form['StartCol'].value), 1)
  elif form.has_key("Next"):
    scrollTable(form, keys, 1,string.atoi(form['StartCol'].value), 1)
  elif form.has_key("<<Prev"):
    scrollTable(form, keys, -1,string.atoi(form['StartCol'].value), 4)
  elif form.has_key("Next>>"):
    scrollTable(form, keys, 1,string.atoi(form['StartCol'].value), 4)
  elif doSave:
    dirty = saveContent(form, keys)
    print "Content-type: text/html\n"
    #print "<h1>Saving Table...<h1>"
    if form.has_key("passwd_program") and checkpwd(form["passwd_program"].value):
      for key in keys:
        #print "<h2>key=",key,", value=",form[key].value,"</h2>"
        if form[key].value == "Delete_Row":
          #print "<h2>Deleting Row..."+key+"</h2>"
          deleteRow(TOP.first_child, key)
          dirty = 1
        elif form[key].value == "Above_Row":
          #print "<h2>Adding Row Above..."+key+"</h2>"
          addRowAbove(TOP.first_child, key)
          dirty = 1
        elif form[key].value == "Below_Row":
          #print "<h2>Adding Row Below..."+key+"</h2>"
          addRowBelow(TOP.first_child, key)
          dirty = 1
        elif form[key].value == "Delete_Column":
          #print "<h2>Deleting Column..."+key+"</h2>"
          deleteColumn(TOP.first_child, key)
          dirty = 1
        elif form[key].value == "Before_Column":
          #print "<h2>Adding Column Before..."+key+"</h2>"
          addColBefore(TOP.first_child, key)
          dirty = 1
        elif form[key].value == "After_Column":
          #print "<h2>Adding Column After..."+key+"</h2>"
          addColAfter(TOP.first_child, key)
          dirty = 1
      if (dirty):
        writeFile(nameOfFile)
        getContent(nameOfFile)
        if form.has_key("SaveAsHTML"):
          writeFileAsHTML(nameOfFile)
          getContent(nameOfFile)
      showForm1("","",scriptLocation)
    else:
      print "Content-type: text/html\n"
      print "<h2>Enter valid password</h2>"
  else:
    print "Content-type: text/html\n"
    #print "<h2>Invalid request</h2>"
    showForm1("","",scriptLocation)
  
